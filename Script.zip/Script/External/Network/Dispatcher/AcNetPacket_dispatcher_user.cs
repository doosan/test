using UnityEngine;
using System;
using System.Collections.Generic;
using Lidgren.Network;
using System.Linq;
using ForuOnes.T3.LuckyTeenPatti;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// AcNetPacket_dispatcher_common
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

public class AcNetPacket_dispatcher_user : AcNetPacket_dispatcher_base
{
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // ����
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region ����

    public static AcNetPacket_dispatcher_user Instance;

    #endregion

    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // ����
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region ����

    public void Awake()
    {
        Instance = this;
    }

    #endregion

    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // ��Ʈ��ũ �̺�Ʈ
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region ��Ʈ��ũ �̺�Ʈ �ڵ鷯�� ���

    public void RegisterMessageHandlers(AcNetFacade netFacade)
    {
        _netFacade = netFacade;

        RegisterMessageHandler<AcNetDataSC_notifyUserStatChange>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_UserStatChange, NotifyUserStatChange);
        RegisterMessageHandler<AcNetDataSC_notifyUserInventoryChange>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_UserInventoryChange, NotifyUserInventoryChange);
        RegisterMessageHandler<AcNetDataSC_notifyMultiSlotInfo>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_MultiSlotInfo, NotifyMultiSlotInfo);
        RegisterMessageHandler<AcNetDataSC_notifyUserLeagueUpdateInfo>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_UserLeagueUpdate, NotifyUserLeagueUpdate);
        RegisterMessageHandler<AcNetDataSC_notifyPostNewAdd>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_PostNewAdd, NotifyPostNewAdd);
        RegisterMessageHandler<AcNetDataSC_reqLaytancyPacket>(ePeerType.GamePeer, AcNetMessageHeaders.SCReq_LatancyPacket, RequestLatancyPacket);

        RegisterMessageHandler<AcNetDataSC_notifySafeBuyInOutInfo>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_SafeBuyInOutInfo, NotifySafeBuyInOutInfo);
        RegisterMessageHandler<AcNetDataSC_notifyLuckyPointBuyInOutInfo>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_LuckyPointBuyInOutInfo, NotifyLuckyPointBuyInOutInfo);

        RegisterMessageHandler<AcNetDataSC_notifyFriendRequest>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_FriendRequest, NotifyFriendRequest);
        RegisterMessageHandler<AcNetDataSC_notifyFriendAdd>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_FriendAdd, NotifyFriendAdd);
        RegisterMessageHandler<AcNetDataSC_notifyFriendRemove>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_FriendRemove, NotifyFriendRemove);
        RegisterMessageHandler<AcNetDataSC_notifyFriendLogin>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_FriendLogin, NotifyFriendLogin);
        RegisterMessageHandler<AcNetDataSC_notifyFriendTalk>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_FriendTalk, NotifyFriendTalk);
        RegisterMessageHandler<AcNetDataSC_notifyFriendPrivateRoomInvite>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_FriendPrivateRoomInvite, NotifyFriendPrivateRoomInvite);
        RegisterMessageHandler<AcNetDataSC_notifyFriendInviteTotalCount>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_FriendInviteTotalCount, NotifyFriendInviteTotalCount);
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // ����
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region ���� ���� ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // ���� ���� ����
    void NotifyUserStatChange(AcNetDataSC_notifyUserStatChange inMsg)
    {
        if (AcUserInfo._netData_user._uId == inMsg._userUId)
        {

            switch (inMsg._updateType)
            {
                case eUserUpdateType.TYPE_DIAMOND:
                    AcUserInfo._netData_user.Diamond = inMsg._updateValue;
                    break;

                case eUserUpdateType.TYPE_CHIP:
                    var safe = AcUserInfo._netData_user._safeInfoList;
                    for (int i = 0; i < safe.Count; i++)
                    {
                        if (safe[i]._number == inMsg._safeNumber)
                        {
                            safe[i].Chip = inMsg._updateValue;
                            break;
                        }
                    }
                    break;

                case eUserUpdateType.TYPE_LUCKYPOINT:
                    if (inMsg._safeNumber == 0)
                    {
                        AcUserInfo._netData_user.LuckyPoint = inMsg._updateValue;
                    }
                    else if(inMsg._safeNumber == 1)
                    {
                        AcUserInfo._netData_user.LuckyPointBuyIn = inMsg._updateValue;
                    }
                    break;
            }
        }
    }

    #endregion

    #region ���� �κ��丮 ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // ���� ���� ����
    void NotifyUserInventoryChange(AcNetDataSC_notifyUserInventoryChange inMsg)
    {
        // ������ �κ��丮 ����
        if (AcUserInfo._netData_inventory != null)
        {
            for (int i = 0; i < inMsg._itemChangeInfoList.Count; i++)
            {
                var item = AcUserInfo._netData_inventory._itemList.Where(data => data._uId == inMsg._itemChangeInfoList[i]._itemUId).FirstOrDefault();

                if (item == null && inMsg._itemChangeInfoList[i]._count != 0)
                {
                    item = new AcNetData_ItemInfo();
                    item._uId = inMsg._itemChangeInfoList[i]._itemUId;
                    item._itemDataId = inMsg._itemChangeInfoList[i]._itemDataId;
                    item._count = inMsg._itemChangeInfoList[i]._count;
                    item._timeLimitOn = inMsg._itemChangeInfoList[i]._timeLimitOn;
                    item._timeLimitEndDate = inMsg._itemChangeInfoList[i]._timeLimitEndDate;

                    AcUserInfo._netData_inventory._itemList.Add(item);
                    PlayerDataManager.Instance.AddNewItem(item._uId);
                }
                else if (item != null && inMsg._itemChangeInfoList[i]._count == 0)
                {
                    item._count = inMsg._itemChangeInfoList[i]._count;

                    AcUserInfo._netData_inventory._itemList.Remove(item);
                    PlayerDataManager.Instance.RemoveNewItem(item._uId);
                }
                else if (item != null)
                {
                    item._count = inMsg._itemChangeInfoList[i]._count;
                    item._timeLimitOn = inMsg._itemChangeInfoList[i]._timeLimitOn;
                    item._timeLimitEndDate = inMsg._itemChangeInfoList[i]._timeLimitEndDate;
                }
            }
        }
    }

    #endregion

    #region ��Ƽ���� ���� ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    void NotifyMultiSlotInfo(AcNetDataSC_notifyMultiSlotInfo inMsg)
    {
        Debug.Log("Server Notify: MultiSlotInfo " + inMsg._multiSlotInfo._number);

        for (int i = 0; i < AcUserInfo._netData_user._multiSlotInfoList.Count; i++)
        {
            if (AcUserInfo._netData_user._multiSlotInfoList[i]._uId == inMsg._multiSlotInfo._uId)
            {
                AcUserInfo._netData_user._multiSlotInfoList[i]._autoEndDateTime = inMsg._multiSlotInfo._autoEndDateTime;
                AcUserInfo._netData_user._multiSlotInfoList[i]._multiEndDateTime = inMsg._multiSlotInfo._multiEndDateTime;
                break;
            }
        }
    }

    #endregion

    #region ���� ���� ������Ʈ ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // ���� ���� ������Ʈ ����
    void NotifyUserLeagueUpdate(AcNetDataSC_notifyUserLeagueUpdateInfo inMsg)
    {
        if (AcUserInfo._netData_user._uId == inMsg._userLeagueInfo._userUId)
        {
            AcUserInfo._netData_user._leagueGradeType = inMsg._userLeagueInfo._gradeType;
            AcUserInfo._netData_user._bestLeagueGradeType = inMsg._userLeagueInfo._bestLeagueGradeType;
            AcUserInfo._netData_user._bestLeagueRankNumber = inMsg._userLeagueInfo._bestLeagueRankNumber;
            AcUserInfo._netData_user._leagueRewardInfo = inMsg._leagueRewardInfo;

            if (ForuOnes.T3.LuckyTeenPatti.OutGameManager.Instance != null)
                ForuOnes.T3.LuckyTeenPatti.OutGameManager.Instance.CheckLeagueReward();
        }
    }

    #endregion

    #region ���� ���� �߰� ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // ���� ���� �߰� ����
    void NotifyPostNewAdd(AcNetDataSC_notifyPostNewAdd inMsg)
    {
        if (AcUserInfo._netData_postbox != null)
        {
            AcUserInfo._netData_postbox._postList.Add(inMsg._postInfo);
        }
    }

    #endregion

    #region �����Ͻ� ��Ŷ ��û

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // �����Ͻ� ��Ŷ ��û
    void RequestLatancyPacket(AcNetDataSC_reqLaytancyPacket inMsg)
    {
        var outMsg = new AcNetDataCS_resLaytancyPacket();
        outMsg._packetIndex = inMsg._packetIndex;

        AcNetFacade.Instance.SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSRes_LatancyPacket, outMsg);

    }

    #endregion

    #region �ݰ� Buy In/Out ���� ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // �ݰ� Buy In/Out ���� ����
    void NotifySafeBuyInOutInfo(AcNetDataSC_notifySafeBuyInOutInfo inMsg)
    {
        // �ݰ� ���� ������Ʈ
        AcUserInfo._netData_user._safeInfoList[0] = inMsg._mainSafeInfo;    // ����
        for (int i = 1; i < AcUserInfo._netData_user._safeInfoList.Count; i++)
        {
            if (AcUserInfo._netData_user._safeInfoList[i]._number == inMsg._changeSafeInfo._number)
            {
                AcUserInfo._netData_user._safeInfoList[i] = inMsg._changeSafeInfo;
                break;
            }
        }
    }

    #endregion

    #region ��Ű����Ʈ Buy In/Out ���� ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // ��Ű����Ʈ Buy In/Out ���� ����
    void NotifyLuckyPointBuyInOutInfo(AcNetDataSC_notifyLuckyPointBuyInOutInfo inMsg)
    {
        AcUserInfo._netData_user._luckyPointInfo = inMsg._mainInfo;    
        AcUserInfo._netData_user._luckyPointInfo_BuyIn = inMsg._buyInInfo;
    }

    #endregion

    #region ģ�� ��û ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // ģ�� ��û ����
    void NotifyFriendRequest(AcNetDataSC_notifyFriendRequest inMsg)
    {
        AcUserInfo._friendRequestList.Add(inMsg._friendRequestInfo);
    }

    #endregion

    #region ģ�� �߰� ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // ģ�� �߰� ����
    void NotifyFriendAdd(AcNetDataSC_notifyFriendAdd inMsg)
    {
        if (AcUserInfo._friendList.Any(data => data._friendUserUId == inMsg._friendInfo._friendUserUId) == false)
        {
            AcUserInfo._friendList.Add(inMsg._friendInfo);
            ForuOnes.T3.LuckyTeenPatti.PlayerDataManager.Instance.CheckFriends();
        }

        // �������� ��û�� ģ���� ���� ��û�� �Ѵ� ������ �����Ƿ�(DB�� �������� �˾Ƽ� ������)
        AcUserInfo._friendRequestList.RemoveAll(data => data._requestUserUId == inMsg._friendInfo._friendUserUId);
    }

    #endregion

    #region ģ�� ���� ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // ģ�� ���� ����
    void NotifyFriendRemove(AcNetDataSC_notifyFriendRemove inMsg)
    {
        AcUserInfo._friendList.RemoveAll(data => data._uId == inMsg._friendUId);
        ForuOnes.T3.LuckyTeenPatti.PlayerDataManager.Instance.CheckFriends();
    }

    #endregion

    #region ģ�� �α��� ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // ģ�� �α��� ����
    void NotifyFriendLogin(AcNetDataSC_notifyFriendLogin inMsg)
    {
        for (int i = 0; i < AcUserInfo._friendList.Count; i++)
        {
            if (AcUserInfo._friendList[i]._friendUserUId == inMsg._friendUserUId)
            {
                AcUserInfo._friendList[i]._userState = inMsg._userState;
                ForuOnes.T3.LuckyTeenPatti.PlayerDataManager.Instance.CheckFriends();

                if(ForuOnes.T3.LuckyTeenPatti.LoginAlertManager.Instance != null)
                {
                    if(inMsg._userState != eUserState.STATE_OFFLINE)
                    {
                        ForuOnes.T3.LuckyTeenPatti.LoginAlertManager.Instance.AddLogin(inMsg._friendUserUId);
                    }
                }

                break;
            }
        }
    }

    #endregion

    #region ģ�� ��ȭ ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // ģ�� ��ȭ ����
    void NotifyFriendTalk(AcNetDataSC_notifyFriendTalk inMsg)
    {
        AcNetData_FriendInfo friendInfo = AcUserInfo._friendList.Where(x => x._friendUserUId == inMsg._talkInfo._userUId).FirstOrDefault();

        if (friendInfo != null)
        {
            if (!ForuOnes.T3.LuckyTeenPatti.PlayerDataManager.Instance.IsBlockChatList(inMsg._talkInfo._userUId))
            {
                ForuOnes.T3.LuckyTeenPatti.ChatInfo chatInfo = new ForuOnes.T3.LuckyTeenPatti.ChatInfo();
                chatInfo._userUId = inMsg._talkInfo._userUId;
                chatInfo._talkStr = inMsg._talkInfo._talkStr;
                chatInfo._nickName = friendInfo._friendNickName;
                chatInfo._uId = friendInfo._friendUserId;
                chatInfo._picturerId = friendInfo._friendPictureDataId;

                ForuOnes.T3.LuckyTeenPatti.PlayerDataManager.Instance.AddChatInfo(inMsg._talkInfo._userUId, chatInfo, false);
            }
        }
    }

    #endregion

    #region ģ�� ��й� �ʴ� ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // ģ�� ��й� �ʴ� ����
    void NotifyFriendPrivateRoomInvite(AcNetDataSC_notifyFriendPrivateRoomInvite inMsg)
    {
        if (AcUserInfo._friendList.Any(data => data._friendUserUId == inMsg._friendUserUId) == true)
        {
            // inMsg._gameRoomDataId
            // inMsg._friendUserUId;
            // inMsg._roomIndex;

            // inMsg._serverChange;
            // inMsg._gameServerIP;
            // inMsg._gameServerPort;

            if (ForuOnes.T3.LuckyTeenPatti.InviteAlertManager.Instance != null)
                ForuOnes.T3.LuckyTeenPatti.InviteAlertManager.Instance.OnAlert(inMsg);
        }
    }

    #endregion

    #region ģ�� �� �ʴ� �� ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // ģ�� �� �ʴ� �� ����
    void NotifyFriendInviteTotalCount(AcNetDataSC_notifyFriendInviteTotalCount inMsg)
    {
        if (AcUserInfo._userfriendInviteInfo != null)
        {
            AcUserInfo._userfriendInviteInfo._inviteTotalCount = inMsg._InviteTotalCount;
        }
    }

    #endregion
}
