using UnityEngine;
using System;
using System.Collections.Generic;
using Lidgren.Network;
using System.Linq;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// AcNetPacket_dispatcher_common
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

public class AcNetPacket_dispatcher_rank : AcNetPacket_dispatcher_base
{
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 변수
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 변수

    public static AcNetPacket_dispatcher_rank Instance;

    #endregion

    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 메인
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 메인

    public void Awake()
    {
        Instance = this;
    }

    #endregion

    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 네트워크 이벤트
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 네트워크 이벤트 핸들러들 등록

    public void RegisterMessageHandlers(AcNetFacade netFacade)
    {
        _netFacade = netFacade;

        RegisterMessageHandler<AcNetDataSC_notifyTOTChampionShipStateInfo>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_TOTChampionShipStateInfo, NotifyTOTChampionShipStateInfo);
        RegisterMessageHandler<AcNetDataSC_notifyUserTOTRankUpdateInfo>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_UserTOTRankInfoUpdate, NotifyUserTOTRankUpdateInfo);
        RegisterMessageHandler<AcNetDataSC_notifyUserTOTChampionShipUpdateInfo>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_UserTOTChampionShipInfoUpdate, NotifyUserTOTChampionShipUpdateInfo);
    }

    #endregion

    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // TOT 챔피언쉽
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region TOT 챔피언쉽 상태 정보 공지

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // TOT 챔피언쉽 상태 정보 공지
    void NotifyTOTChampionShipStateInfo(AcNetDataSC_notifyTOTChampionShipStateInfo inMsg)
    {
        AcUserInfo._tOTChampionShipState = inMsg._tOTChampionShipState;
        if (AcUserInfo._tOTChampionShipState == eTOTChampionShipState.STATE_START)
        {
            AcUserInfo._tOTChampionShipEndDateTime = inMsg._tOTChampionShipEndDateTime;
            AcUserInfo._tOTChampionShipGameModeDataId = inMsg._tOTChampionShipGameModeDataId;

            // 유저 챔피언쉽 랭크 정보 요청
            AcNetFacade.Instance.SendPacket_req_simpleTOTChampionShipUserList();
        }
    }

    #endregion

    #region TOT 챔피언쉽 정보 업데이트 공지

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // TOT 챔피언쉽 정보 업데이트 공지
    void NotifyUserTOTRankUpdateInfo(AcNetDataSC_notifyUserTOTRankUpdateInfo inMsg)
    {
        AcUserInfo._myTOTRankRewardInfo = inMsg._tOTRankRewardInfo;
    }

    #endregion

    #region TOT 챔피언쉽 정보 업데이트 공지

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // TOT 챔피언쉽 정보 업데이트 공지
    void NotifyUserTOTChampionShipUpdateInfo(AcNetDataSC_notifyUserTOTChampionShipUpdateInfo inMsg)
    {
        //AcUserInfo._myTOTChampionShipUserInfo = inMsg._tOTChampionShipUserInfo;
        AcUserInfo._myTOTChampionShipRewardInfo = inMsg._tOTChampionShipRewardInfo;
    }

    #endregion

}
