using UnityEngine;
using System;
using System.Collections.Generic;
using Lidgren.Network;
using ForuOnes.T3.LuckyTeenPatti;
using ForuOnes.T3.LuckyTeenPatti.Table;
using System.Linq;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// AcNetPacket_dispatcher_common
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

public class AcNetPacket_dispatcher_lobby : AcNetPacket_dispatcher_base
{
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 변수
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 변수

    public static AcNetPacket_dispatcher_lobby Instance;

    #endregion

    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 메인
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 메인

    public void Awake()
    {
        Instance = this;
    }

    #endregion

    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 네트워크 이벤트
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 네트워크 이벤트 핸들러들 등록

    public void RegisterMessageHandlers(AcNetFacade netFacade)
    {
        _netFacade = netFacade;

        RegisterMessageHandler<AcNetDataSC_notifyRoomState>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_RoomStateChange, NotifyRoomStateChange);
        RegisterMessageHandler<AcNetDataSC_notifyRoomSlotInfo>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_RoomSlotInfo, NotifyRoomSlotInfo);
        RegisterMessageHandler<AcNetDataSC_notifyRoomGameStart>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_RoomGameStart, NotifyRoomGameStart);
        RegisterMessageHandler<AcNetDataSC_notifyRoomGameEnd>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_RoomGameEnd, NotifyRoomGameEnd);
        RegisterMessageHandler<AcNetDataSC_notifyRoomSlotStateInfo>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_RoomSlotStateChange, NotifyRoomSlotStateChange);
        RegisterMessageHandler<AcNetDataSC_notifyRoomSlotUserBalanceInfo>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_RoomSlotUserBalanceInfo, NotifyRoomSlotUserBalanceInfo);
        RegisterMessageHandler<AcNetDataSC_notifyRoomSlotLackBalanceStandUp>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_RoomSlotLackBalanceStandUp, NotifyRoomSlotLackBalanceStandUp);
        RegisterMessageHandler<AcNetDataSC_notifyRoomSlotLackMultiTimeStandUp>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_RoomSlotLackMultiTimeStandUp, NotifyRoomSlotLackMultiTimeStandUp);
        RegisterMessageHandler<AcNetDataSC_notifyRoomSlotSafeChipMaxVolumeStandUp>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_RoomSlotSafeChipMaxVolumeStandUp, NotifyRoomSlotSafeChipMaxVolumeStandUp);
        RegisterMessageHandler<AcNetDataSC_notifyRoomSlotAutoStandUp>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_RoomSlotAutoStandUp, NotifyRoomSlotAutoStandUp);
        //RegisterMessageHandler<AcNetDataSC_notifyLeagueStart>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_LeagueStart, NotifyLeagueStart);
        //RegisterMessageHandler<AcNetDataSC_notifyLeagueEnd>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_LeagueEnd, NotifyLeagueEnd);
        RegisterMessageHandler<AcNetDataSC_notifyRoomPrivatePlayStateChange>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_RoomPrivatePlayStateChange, NotifyRoomPrivatePlayStateChange);
        RegisterMessageHandler<AcNetDataSC_notifyRoomMasterChange>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_RoomMasterChange, NotifyRoomMasterChange);
        RegisterMessageHandler<AcNetDataSC_notifyForceLeaveRoom>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_RoomForceLeave, NotifyRoomForceLeaveInfo);

        RegisterMessageHandler<AcNetDataSC_notifyRoomSlotTicketBalanceInfo>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_RoomSlotTicketBalanceInfo, NotifyRoomSlotTicketBalanceInfo);
        RegisterMessageHandler<AcNetDataSC_notifyRoomSlotUserBalanceMaxLimitFix>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_RoomSlotUserBalanceMaxLimitFix, NotifyRoomSlotUserBalanceMaxLimitFix);

        // 혹시 몰라서 두곳 다
        RegisterMessageHandler<AcNetDataSC_notifyBBSNoticeInfo>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_BBSNoticeInfo, NotifyBBSNoticeInfo);

        RegisterMessageHandler<AcNetDataSC_notifyPaymentVerifyNonGiveGoods>(ePeerType.LoginPeer, AcNetMessageHeaders.SCNotify_PaymentVerifyNonGiveGoods, NotifyPaymentVerifyNonGiveGoods);

        RegisterMessageHandler<AcNetDataSC_notifyMissionInfoUpdate>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_MissionInfoUpdate, NotifyMissionInfoUpdate);

        RegisterMessageHandler<AcNetDataSC_notifyTutorialBaseEnableComplete>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_TutorialBaseEnableComplete, NotifyTutorialBaseEnableComplete);
        RegisterMessageHandler<AcNetDataSC_notifyTutorialGaneshaEnableComplete>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_TutorialGaneshaEnableComplete, NotifyTutorialGaneshaEnableComplete);

        RegisterMessageHandler<AcNetDataSC_notifyContentLockInfo>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_ContentLockInfo, NotifyContentLockInfo);

        RegisterMessageHandler<AcNetDataSC_notifyChannelRoomOpen>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_ChannelGameRoomOpen, NotifyChannelGameRoomOpen);

        RegisterMessageHandler<AcNetDataSC_notifyBuffUpdate>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_BuffUpdate, NotifyBuffUpdateInfo);

        RegisterMessageHandler<AcNetDataSC_notifyUserLimitProductInfo>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_UserLimitProductInfo, NotifyUserLimitProductInfo);

        RegisterMessageHandler<AcNetDataSC_notifyUserAllInEventClear>(ePeerType.GamePeer, AcNetMessageHeaders.SSNotify_UserAllInEventClear, NotifyUserAllInEventClear);
    }

    #endregion

    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 방
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 방 상태 변경

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 방 상태 변경
    void NotifyRoomStateChange(AcNetDataSC_notifyRoomState inMsg)
    {
     
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            findRoom._netData_room._state = inMsg._roomState;

            switch(findRoom._netData_room._state)
            {
                case eRoomState.STATE_WAIT:
                    // 대기(카운트 다운중에 다시 이상태가 오면 카운트다운 취소)
                    //var findGame = NetworkTest.Instance.FindRootGame(inMsg._roomIndex);
                    //if(findGame != null)
                    //{
                    //    findGame.ChangeState(eGameSceneState.STATE_ROOMGAMEWAIT);
                    //}
                    break;

                case eRoomState.STATE_COUNTDOWN:
                    // 게임시작 카운트다운
                    findRoom._netData_room._turnEndDateTime = inMsg._gameStartDateTime;
                    break;

                case eRoomState.STATE_GAMEPLAY:
                    // 게임 시작됨
                    break;

                case eRoomState.STATE_REMOVE:
                    // 방 삭제예정(이상태가 올일은 없을듯..)
                    break;
            }
        }
    }

    #endregion

    #region 방 슬롯 정보 공지

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 방 슬롯 정보 공지
    void NotifyRoomSlotInfo(AcNetDataSC_notifyRoomSlotInfo inMsg)
    {
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
       
        if (findRoom != null)
        {
            for (int i = 0; i < findRoom._netData_room._slotList.Count; i++)
            {
                if(findRoom._netData_room._slotList[i]._number == inMsg._roomSlotInfo._number)
                {
                    findRoom._netData_room._slotList[i]._state = inMsg._roomSlotInfo._state;
                    findRoom._netData_room._slotList[i]._userInfo = inMsg._roomSlotInfo._userInfo;
                    findRoom._netData_room._slotList[i]._fold = inMsg._roomSlotInfo._fold;
                    findRoom._netData_room._slotList[i]._cardSee = inMsg._roomSlotInfo._cardSee;
                    //findRoom._netData_room._slotList[i]._emoticonList = inMsg._roomSlotInfo._emoticonList;

                    if(inMsg._roomSlotInfo._state == eRoomSlotState.STATE_WAIT)
                    {
                        findRoom._netData_room._slotList[i]._emoticonList.Clear();
                    }

                    if (inMsg._roomSlotInfo._userInfo._uId == AcUserInfo._netData_user._uId)
                    {
                        // 내슬롯
                        findRoom._mySlotNumber = inMsg._roomSlotInfo._number;
                    }
                    if (InGameManager.Instance != null)
                        InGameManager.Instance.SetPlayerSlot(inMsg);
                    break;
                }
            }


        }
    }

    #endregion

    #region 방 게임 시작 공지

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 방 게임 시작 공지
    void NotifyRoomGameStart(AcNetDataSC_notifyRoomGameStart inMsg)
    {
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            findRoom._netData_room._dealerSlotNumber = inMsg._dealerSlotNumber;
            findRoom._netData_room._totalPot = 0;
            findRoom._bettingEnable = true;
        }
    }

    #endregion

    #region 방 게임 끝남 공지

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 방 게임 끝남 공지
    void NotifyRoomGameEnd(AcNetDataSC_notifyRoomGameEnd inMsg)
    {
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {

        }
    }

    #endregion

    #region 방 슬롯 상태 변경 공지

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 방 슬롯 상태 변경 공지
    void NotifyRoomSlotStateChange(AcNetDataSC_notifyRoomSlotStateInfo inMsg)
    {
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            for (int i = 0; i < inMsg._roomSlotStateInfo.Count; i++)
            {
                for (int k = 0; k < findRoom._netData_room._slotList.Count; k++)
                {
                    if (findRoom._netData_room._slotList[k]._number == inMsg._roomSlotStateInfo[i]._number)
                    {
                        findRoom._netData_room._slotList[k]._state = inMsg._roomSlotStateInfo[i]._state;
                        break;
                    }
                }
            }
        }
    }

    #endregion

    #region 방 슬롯 유저 재화 정보 공지

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 방 슬롯 유저 재화 정보 공지
    void NotifyRoomSlotUserBalanceInfo(AcNetDataSC_notifyRoomSlotUserBalanceInfo inMsg)
    {
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            if (InGameManager.Instance != null)
            {
                Room room = InGameManager.Instance.GetRoom(inMsg._roomIndex);

                if (room != null)
                {
                    room.SetPlayerChip(inMsg);
                }
            }

            for (int i = 0; i < inMsg._roomSlotUserBalanceInfoList.Count; i++)
            {
                for (int k = 0; k < findRoom._netData_room._slotList.Count; k++)
                {
                    if (findRoom._netData_room._slotList[k]._number == inMsg._roomSlotUserBalanceInfoList[i]._number &&
                        findRoom._netData_room._slotList[k]._userInfo != null &&
                        findRoom._netData_room._slotList[k]._userInfo._uId == inMsg._roomSlotUserBalanceInfoList[i]._userUId)
                    {
                        findRoom._netData_room._slotList[k]._userInfo._balance = inMsg._roomSlotUserBalanceInfoList[i]._balance;
                        
                        break;
                    }
                }
            }
        }
    }

    #endregion

    #region 방 슬롯 재화 부족 일으킴 공지

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 방 슬롯 재화 부족 일으킴 공지
    void NotifyRoomSlotLackBalanceStandUp(AcNetDataSC_notifyRoomSlotLackBalanceStandUp inMsg)
    {
        Debug.Log("재화 부족");
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            for (int i = 0; i < findRoom._netData_room._slotList.Count; i++)
            {
                if (findRoom._netData_room._slotList[i]._number == inMsg._slotNumber)
                {
                    Room room = InGameManager.Instance.GetRoom(inMsg._roomIndex);
                    if (room != null)
                        room.ForceStandUpPlayer(110045);
                    break;
                }
            }
        }
    }

    #endregion

    #region 방 슬롯 금고 시간 부족 일으킴 공지

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 방 슬롯 멀티 시간 부족 일으킴 공지
    void NotifyRoomSlotLackMultiTimeStandUp(AcNetDataSC_notifyRoomSlotLackMultiTimeStandUp inMsg)
    {
        Debug.Log("멀티시간 부족");
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            for (int i = 0; i < findRoom._netData_room._slotList.Count; i++)
            {
                if (findRoom._netData_room._slotList[i]._number == inMsg._slotNumber)
                {
                    Room room = InGameManager.Instance.GetRoom(inMsg._roomIndex);
                    if (room != null)
                        room.ForceStandUpPlayer(110046);
                    break;
                }
            }
        }
    }

    #endregion

    #region 방 슬롯 금고 칩 최대치로 일으킴 공지

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 방 슬롯 금고 칩 최대치로 일으킴 공지
    void NotifyRoomSlotSafeChipMaxVolumeStandUp(AcNetDataSC_notifyRoomSlotSafeChipMaxVolumeStandUp inMsg)
    {
        Debug.Log("칩 최대치");
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            for (int i = 0; i < findRoom._netData_room._slotList.Count; i++)
            {
                if (findRoom._netData_room._slotList[i]._number == inMsg._slotNumber)
                {
                    Room room = InGameManager.Instance.GetRoom(inMsg._roomIndex);
                    if (room != null)
                        room.ForceStandUpPlayer(110044);
                    // 일으킴 이벤트
                    break;
                }
            }
        }
    }

    #endregion

    #region 방 슬롯 자동 일으킴 공지(게임 플레이 안했을때, 접속 끊겼을때)

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 방 슬롯 금고 칩 최대치로 일으킴 공지
    void NotifyRoomSlotAutoStandUp(AcNetDataSC_notifyRoomSlotAutoStandUp inMsg)
    {
        Debug.Log("플레이 안했을때, 접속 끊겼을때");
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            for (int i = 0; i < findRoom._netData_room._slotList.Count; i++)
            {
                if (findRoom._netData_room._slotList[i]._number == inMsg._slotNumber)
                {
                    Room room = InGameManager.Instance.GetRoom(inMsg._roomIndex);
                    if (room != null)
                        room.ForceStandUpPlayer(110043);
                    break;
                }
            }

           
        }
    }

    #endregion

    #region 방 비밀방 플레이 상태 변경 공지

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 방 비밀방 플레이 상태 변경 공지
    void NotifyRoomPrivatePlayStateChange(AcNetDataSC_notifyRoomPrivatePlayStateChange inMsg)
    {
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            findRoom._netData_room._privateRoomPlayState = inMsg._privateRoomPlayState;
        }
    }

    #endregion

    #region 방 마스터 유저 변경 공지

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 방 마스터 유저 변경 공지
    void NotifyRoomMasterChange(AcNetDataSC_notifyRoomMasterChange inMsg)
    {
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            findRoom._netData_room._masterUserUId = inMsg._masterUserUId;

            if (InGameManager.Instance != null)
                InGameManager.Instance.ChangeMaster(inMsg);
        }
    }

    #endregion

    #region 방 강제 퇴장 공지

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 방 강제 퇴장 공지
    void NotifyRoomForceLeaveInfo(AcNetDataSC_notifyForceLeaveRoom inMsg)
    {
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            // 방 나가기 처리
            if (AcUserInfo._enterRoomDic.ContainsKey(inMsg._roomIndex) == true)
            {
                AcUserInfo._enterRoomDic.Remove(inMsg._roomIndex);
            }

            if(inMsg._userRoomLeaveType == eUserRoomLeaveType.TYPE_FORCE || inMsg._userRoomLeaveType == eUserRoomLeaveType.TYPE_TURNLIMITTIMEFORCE)
            {
                InGameManager.Instance.ForceExitRoom(inMsg);
            }

            // inMsg._userRoomLeaveType 스위칭인지 강제로 퇴장 된건지 확인
        }
    }

    #endregion

    #region 방 슬롯 티켓 발란스 정보 공지

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 방 슬롯 티켓 발란스 정보 공지
    void NotifyRoomSlotTicketBalanceInfo(AcNetDataSC_notifyRoomSlotTicketBalanceInfo inMsg)
    {
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            for (int i = 0; i < findRoom._netData_room._slotList.Count; i++)
            {
                if (findRoom._netData_room._slotList[i]._number == inMsg._slotNumber &&
                    findRoom._netData_room._slotList[i]._userInfo != null &&
                    findRoom._netData_room._slotList[i]._userInfo._uId == inMsg._userUId)
                {
                    findRoom._netData_room._slotList[i]._userInfo._ticketBalance = inMsg._ticketBalance;
                    break;
                }
            }
        }
    }

    #endregion

    #region 방 슬롯 유저 맥스칩에 의해서 BuyIn 금액 변경된것 공지

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 방 슬롯 유저 맥스칩에 의해서 BuyIn 금액 변경된것 공지
    void NotifyRoomSlotUserBalanceMaxLimitFix(AcNetDataSC_notifyRoomSlotUserBalanceMaxLimitFix inMsg)
    {
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            if (InGameManager.Instance != null)
            {
                Room room = InGameManager.Instance.GetRoom(inMsg._roomIndex);

                if (room != null)
                {
                    InGameManager.Instance.BalanceMaxLimitFix(inMsg);
                    // 연출
                }
            }
        }
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 공지
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 공지 정보 공지

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 공지 정보 공지
    void NotifyBBSNoticeInfo(AcNetDataSC_notifyBBSNoticeInfo inMsg)
    {
        AcUserInfo._noticeList.Add(inMsg._noticeStr);
        Debug.Log("Server Notice: " + inMsg._noticeStr);
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 결제
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 결제 확인 되었지만 미지급된 상품 지급 공지

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 결제 확인 되었지만 미지급된 상품 지급 공지
    void NotifyPaymentVerifyNonGiveGoods(AcNetDataSC_notifyPaymentVerifyNonGiveGoods inMsg)
    {
        if (inMsg._result == eGameResult.RESULT_OK)
        {
            // 아이템 인벤토리 수정
            if (AcUserInfo._netData_inventory != null)
            {
                for (int i = 0; i < inMsg._itemChangeInfoList.Count; i++)
                {
                    var item = AcUserInfo._netData_inventory._itemList.Where(data => data._uId == inMsg._itemChangeInfoList[i]._itemUId).FirstOrDefault();

                    if (item == null && inMsg._itemChangeInfoList[i]._count != 0)
                    {
                        item = new AcNetData_ItemInfo();
                        item._uId = inMsg._itemChangeInfoList[i]._itemUId;
                        item._itemDataId = inMsg._itemChangeInfoList[i]._itemDataId;
                        item._count = inMsg._itemChangeInfoList[i]._count;

                        AcUserInfo._netData_inventory._itemList.Add(item);
                        PlayerDataManager.Instance.AddNewItem(item._uId);
                    }
                    else if (item != null && inMsg._itemChangeInfoList[i]._count == 0)
                    {
                        item._count = inMsg._itemChangeInfoList[i]._count;
                        AcUserInfo._netData_inventory._itemList.Remove(item);
                        PlayerDataManager.Instance.RemoveNewItem(item._uId);
                    }
                    else if (item != null)
                    {
                        item._count = inMsg._itemChangeInfoList[i]._count;
                    }
                }
            }

            AcUserInfo._nonGiveGoodsShopItemDic.Add(inMsg._shopDataId, inMsg._itemAcquireInfoList);
        }
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 미션
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 미션 업데이트 공지

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 미션 업데이트 공지
    void NotifyMissionInfoUpdate(AcNetDataSC_notifyMissionInfoUpdate inMsg)
    {
        if (inMsg._result == eGameResult.RESULT_OK)
        {
            if (AcUserInfo._missionInfoList != null)
            {
                for (int i = 0; i < inMsg._missionUpdateList.Count; i++)
                {
                    var missionInfo = AcUserInfo._missionInfoList.Where(data => data._uId == inMsg._missionUpdateList[i]._uId).FirstOrDefault();

                    if (missionInfo == null)
                    {
                        AcUserInfo._missionInfoList.Add(inMsg._missionUpdateList[i]);
                    }
                    else if (missionInfo != null)
                    {
                        missionInfo._missionCount = inMsg._missionUpdateList[i]._missionCount;
                        missionInfo._missionComplete = inMsg._missionUpdateList[i]._missionComplete;

                        // 치트 때문에 추가
                        if(missionInfo._noticePopUp == true && missionInfo._missionComplete == false)
                        {
                            MissionBaseTableData data = MissionBaseTable.Instance.GetData(missionInfo._missionDataId);
                            if (missionInfo._missionCount < data.MissionCompleteValue)
                            {
                                missionInfo._noticePopUp = false;
                            }
                        }

                        if (!missionInfo._noticePopUp)
                        {
                            MissionBaseTableData data = MissionBaseTable.Instance.GetData(missionInfo._missionDataId);

                            if (missionInfo._missionCount >= data.MissionCompleteValue)
                            {
                                missionInfo._noticePopUp = true;
                                PlayerDataManager.Instance.AddMission(missionInfo);
                            }
                        }
                    }

                }
            }
        }
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 튜토리얼
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 튜토리얼 베이스 완료 가능 공지

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 튜토리얼 베이스 완료 가능 공지
    void NotifyTutorialBaseEnableComplete(AcNetDataSC_notifyTutorialBaseEnableComplete inMsg)
    {
        if (AcUserInfo._tutorialCompleteInfo._tutorialEnableCompleteBaseIdList.Any(data => data == inMsg._tutorialBaseDataId) == false)
        {
            AcUserInfo._tutorialCompleteInfo._tutorialEnableCompleteBaseIdList.Add(inMsg._tutorialBaseDataId);
            Debug.Log(inMsg._tutorialBaseDataId);
            if (TutorialBaseTable.Instance.GetData(inMsg._tutorialBaseDataId).GaneshaAction == "None")
                AcNetFacade.Instance.SendPacket_req_tutorialBaseRewardAcquire(inMsg._tutorialBaseDataId);
        }
    }

    #endregion

    #region 튜토리얼 가네샤 완료 가능 공지

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 튜토리얼 가네샤 완료 가능 공지
    void NotifyTutorialGaneshaEnableComplete(AcNetDataSC_notifyTutorialGaneshaEnableComplete inMsg)
    {
        if (AcUserInfo._tutorialCompleteInfo._tutorialEnableCompleteGaneshaIdList.Any(data => data == inMsg._tutorialGaneshaDataId) == false)
        {
            AcUserInfo._tutorialCompleteInfo._tutorialEnableCompleteGaneshaIdList.Add(inMsg._tutorialGaneshaDataId);

            if (InGameManager.Instance != null)
                InGameManager.Instance.OnGanesha(inMsg._tutorialGaneshaDataId);
        }
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 컨텐츠 잠금 정보
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 컨텐츠 잠금 정보

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 공지 정보 공지
    void NotifyContentLockInfo(AcNetDataSC_notifyContentLockInfo inMsg)
    {
        AcUserInfo._contentMainLockInfoList = inMsg._contentMainLockInfoList;
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 채널 정보
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 채널 게임 룸 오픈 공지

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 공지 정보 공지
    void NotifyChannelGameRoomOpen(AcNetDataSC_notifyChannelRoomOpen inMsg)
    {
        // 방금 오픈된 채널룸 Id 리스트
        //inMsg._channelRoomDataIdList;
        if (InGameManager.Instance != null)
        {
            if(UIManager.Instance.IsActiveSelf(eGameUI.InGame_UI))
            {
                UIManager.Instance.GetUIWindow<InGameUI>(eGameUI.InGame_UI).OnBootOpenPanel(inMsg._channelRoomDataIdList);
            }

            if(InGameManager.Instance._outGame.activeSelf)
            {
                InGameManager.Instance._outGameUI.OnBootOpenPanel(inMsg._channelRoomDataIdList);
            }
        }
        Debug.Log("채널 룸 오픈 공지 옴" + string.Join(", ", inMsg._channelRoomDataIdList.ToArray()));
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 버프
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 버프 정보 업데이트 공지

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 버프 정보 업데이트 공지
    void NotifyBuffUpdateInfo(AcNetDataSC_notifyBuffUpdate inMsg)
    {
        // 버프 업데이트
        for (int i = 0; i < inMsg._updateBuffInfoList.Count; i++)
        {
            bool newBuff = true;
            for (int k = 0; k < AcUserInfo._buffInfoList.Count; k++)
            {
                if (AcUserInfo._buffInfoList[k]._uId == inMsg._updateBuffInfoList[i]._uId)
                {
                    newBuff = false;

                    AcUserInfo._buffInfoList[k]._registerDateTime = inMsg._updateBuffInfoList[i]._registerDateTime;
                    AcUserInfo._buffInfoList[k]._startDateTime = inMsg._updateBuffInfoList[i]._registerDateTime;
                    AcUserInfo._buffInfoList[k]._endDateTime = inMsg._updateBuffInfoList[i]._endDateTime;
                }
            }

            if (newBuff == true)
            {
                AcUserInfo._buffInfoList.Add(inMsg._updateBuffInfoList[i]);
            }
        }

        // 버프 제거
        for (int i = 0; i < inMsg._removeBuffInfoList.Count; i++)
        {
            for (int k = 0; k < AcUserInfo._buffInfoList.Count; k++)
            {
                if (AcUserInfo._buffInfoList[k]._uId == inMsg._removeBuffInfoList[i])
                {
                    AcUserInfo._buffInfoList.RemoveAt(k);
                    break;
                }
            }
        }

        for (int i = 0; i < inMsg._updateBuffInfoList.Count; i++)
        {
            InGameManager.Instance.RefreshBuffPanel(BuffBaseTable.Instance.GetData(inMsg._updateBuffInfoList[i]._buffDataId).BuffType);
        }
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 구매 제한 상품 
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 구매 제한 상품 정보 공지

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    void NotifyUserLimitProductInfo(AcNetDataSC_notifyUserLimitProductInfo inMsg)
    {
        var userLimitProductInfo = AcUserInfo._userLimitProductInfoList.Where(data => data._shopDataId == inMsg._userLimitProductInfo._shopDataId).FirstOrDefault();
        if(userLimitProductInfo != null)
        {
            userLimitProductInfo._count = inMsg._userLimitProductInfo._count;
        }
        else
        {
            AcUserInfo._userLimitProductInfoList.Add(inMsg._userLimitProductInfo);
        }
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 이벤트
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 올인 이벤트 팝업 공지

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    void NotifyUserAllInEventClear(AcNetDataSC_notifyUserAllInEventClear inMsg)
    {
        AcUserInfo._eventAllInClearCount = Math.Max(inMsg._allInCount, AcUserInfo._eventAllInClearCount);
    }

    #endregion
}
