using UnityEngine;
using System;
using System.Collections.Generic;
using Lidgren.Network;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// AcNetPacket_dispatcher_common
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

public class AcNetPacket_dispatcher_base : MonoBehaviour
{
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// ����
	//
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


    #region ����

    public static AcNetFacade _netFacade;

    #endregion

	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// ��Ʈ��ũ �̺�Ʈ
	//
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	#region ��Ʈ��ũ �̺�Ʈ �ڵ鷯�� ���

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public void RegisterMessageHandler<T>(ePeerType peerType, ushort msgId, Action<T> dispatch) where T : AcNetData_base, new()
    {
        _netFacade.RegisterMessageHandler(peerType, msgId, (inMsg) =>
        {
            DispatchMessageHandler<T>(msgId, inMsg, dispatch);
        });
    }

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public void DispatchMessageHandler<T>(ushort msgId, NetIncomingMessage message, Action<T> dispatch) where T : AcNetData_base, new()
    {
        T data = new T();
        data.Parse(message);
        dispatch(data);
    }

	#endregion
}
