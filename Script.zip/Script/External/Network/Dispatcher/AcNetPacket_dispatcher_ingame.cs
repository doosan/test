using UnityEngine;
using System;
using System.Collections.Generic;
using Lidgren.Network;
using ForuOnes.T3.LuckyTeenPatti;
using ForuOnes.T3.LuckyTeenPatti.Table;
using System.Linq;
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// AcNetPacket_dispatcher_common
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

public class AcNetPacket_dispatcher_ingame : AcNetPacket_dispatcher_base
{
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // ����
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region ����

    public static AcNetPacket_dispatcher_ingame Instance;

    #endregion

    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // ����
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region ����

    public void Awake()
    {
        Instance = this;
    }
    
    #endregion

    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // ��Ʈ��ũ �̺�Ʈ
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region ��Ʈ��ũ �̺�Ʈ �ڵ鷯�� ���

    public void RegisterMessageHandlers(AcNetFacade netFacade)
    {
        _netFacade = netFacade;

        RegisterMessageHandler<AcNetDataSC_notifyCurrentTurn>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_CurrentTurn, NotifyCurrentTurn);
        RegisterMessageHandler<AcNetDataSC_notifyBetting>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_Betting, NotifyBetting);
        RegisterMessageHandler<AcNetDataSC_notifyCardSee>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_CardSee, NotifyCardSee);
        RegisterMessageHandler<AcNetDataSC_notifyForceCardSee>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_ForceCardSee, NotifyForceCardSee);
        RegisterMessageHandler<AcNetDataSC_notifySideShowAccept>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_SideShowAccept, NotifySideShowAccept);
        RegisterMessageHandler<AcNetDataSC_notifyAllInAccept>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_AllInAccept, NotifyAllInAccept);
        RegisterMessageHandler<AcNetDataSC_notifySafeMoveChip>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_SafeMoveChip, NotifySafeMoveChip);
        RegisterMessageHandler<AcNetDataSC_notifyAnimation>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_Animation, NotifyAnimation);
        RegisterMessageHandler<AcNetDataSC_notifyDealerTip>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_DealerTip, NotifyDealerTip);
        RegisterMessageHandler<AcNetDataSC_notifyRoundState>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_RoundState, NotifyRoundState);
        RegisterMessageHandler<AcNetDataSC_notifyShowDownType>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_ShowDownType, NotifyShowDownType);
        RegisterMessageHandler<AcNetDataSC_notifyDeckReceive>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_CardReceive, NotifyCardReceive);
        RegisterMessageHandler<AcNetDataSC_notifyGameResult>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_GameResult, NotifyGameResult);
        RegisterMessageHandler<AcNetDataSC_notifyTotalPot>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_TotalPot, NotifyTotalPot);
        RegisterMessageHandler<AcNetDataSC_notifyBettingEnable>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_BettingEnable, NotifyBettingEnable);
        RegisterMessageHandler<AcNetDataSC_notifyRoomTalk>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_RoomTalk, NotifyRoomTalk);
        RegisterMessageHandler<AcNetDataSC_notifyRoomGameRoomDataChange>(ePeerType.GamePeer, AcNetMessageHeaders.SCNotify_RoomGameRoomDataChange, NotifyRoomGameRoomDataChange);
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // �ΰ���
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region ���� �� ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // ���� �� ����
    void NotifyCurrentTurn(AcNetDataSC_notifyCurrentTurn inMsg)
    {
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            findRoom._netData_room._currentTurnSlotNumber = inMsg._currentTurnSlotNumber;
            findRoom._netData_room._totalPot = inMsg._totalPot;
            findRoom._netData_room._circleCount = inMsg._circleCount;
            findRoom._netData_room._turnEndDateTime = AcUserInfo.ServerDateTime.AddSeconds(findRoom._netData_room._turnLimitSecond);

            if (InGameManager.Instance != null)
                InGameManager.Instance.Turn(inMsg);
        }            
    }

    #endregion

    #region ���� ���� ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // ���� ���� ����
    void NotifyBetting(AcNetDataSC_notifyBetting inMsg)
    {
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            findRoom._netData_room._totalPot = inMsg._totalPot;
            findRoom._netData_room._stakeChip = inMsg._stakeBalance;
            findRoom._netData_room._slotList[inMsg._slotNumber]._userInfo._balance = inMsg._bettingUserBalance;
            findRoom._netData_room._slotList[inMsg._slotNumber]._totalBettingBalance += inMsg._bettingBalance;
            findRoom._netData_room._slotList[inMsg._slotNumber]._prevBettingBalance = inMsg._bettingBalance;
            findRoom._netData_room._prevBettingBalance = inMsg._bettingBalance;

            if (inMsg._bettingType == eBettingType.TYPE_FOLD)
            {
                findRoom._netData_room._slotList[inMsg._slotNumber]._fold = true;
            }
            else if(inMsg._bettingType == eBettingType.TYPE_SIDESHOW)
            {
                findRoom._netData_room._sideShowSrcSlotNumber = inMsg._sideShowSrcSlotNumber;
                findRoom._netData_room._sideShowDstSlotNumber = inMsg._sideShowDstSlotNumber;

                findRoom._sideShowAccept = false;
                findRoom._sideShowResult = false;
            }
            else if(inMsg._bettingType == eBettingType.TYPE_ALLINPOTLIMIT || inMsg._bettingType == eBettingType.TYPE_ALLIN)
            {
                findRoom._netData_room._allInActiveSlotNumber = inMsg._slotNumber;
                findRoom._netData_room._allInChipSlotList = inMsg._allInChipSlotList;
                findRoom._netData_room._slotList.ForEach(data => data._allInAccept = false);
                findRoom._netData_room._slotList[inMsg._slotNumber]._allInAccept = true;
            }

            if (InGameManager.Instance != null)
                InGameManager.Instance.Betting(inMsg);
            // inMsg._bettingType; // ���� Ÿ��(��, ������, ���� ���)
            // inMsg._slotNumber; // ������ ���� �ѹ�
        }

        if(inMsg._bettingType == eBettingType.TYPE_ANTE)
        {
            // ������ ��
        }
    }

    #endregion

    #region ���� ī�� ���� ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // ���� ī�� ���� ����
    void NotifyCardSee(AcNetDataSC_notifyCardSee inMsg)
    {
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            findRoom._netData_room._slotList[inMsg._slotNumber]._cardSee = true;
            if (InGameManager.Instance != null)
                InGameManager.Instance.CardSee(inMsg);
        }
    }

    #endregion

    #region ���� ���� ī�� ���� ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // ���� ���� ī�� ���� ����
    void NotifyForceCardSee(AcNetDataSC_notifyForceCardSee inMsg)
    {
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            findRoom._netData_room._slotList[inMsg._slotNumber]._cardSee = true;
            if (InGameManager.Instance != null)
                InGameManager.Instance.CardSee(inMsg);
        }
    }

    #endregion

    #region ���� ���̵�� ���� ���� ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // ���� ���̵�� ���� ���� ����
    void NotifySideShowAccept(AcNetDataSC_notifySideShowAccept inMsg)
    {
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            //if(inMsg._accept == true)
            {
                findRoom._sideShowResult = true;
                findRoom._sideShowAccept = inMsg._accept;
                findRoom._sideShowGameResultType = inMsg._gameResultType;
                if (InGameManager.Instance != null)
                    InGameManager.Instance.SideShowResult(inMsg);
                //if (inMsg._gameResultType == eGameResultType.TYPE_WIN)
                //{
                //    // ��û �� ����� �̱�
                //    findRoom._netData_room._slotList[inMsg._sideShowDstSlotNumber]._fold = true;
                //}
                //else if (inMsg._gameResultType == eGameResultType.TYPE_LOSE)
                //{
                //    // ��û ���� ����� �̱�
                //    findRoom._netData_room._slotList[inMsg._sideShowSrcSlotNumber]._fold = true;
                //}
                
            }
        }
    }

    #endregion

    #region ���� ���� ���� ���� ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // ���� ���� ���� ���� ����
    void NotifyAllInAccept(AcNetDataSC_notifyAllInAccept inMsg)
    {
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            //inMsg._accept // ���� ����
            //inMsg._allinChip; // ���ε� Ĩ ��
            //inMsg._allInUserSlotNumber; // ���� �������� ������ ����

            if (inMsg._accept == true)
            {
                findRoom._netData_room._slotList[inMsg._allInUserSlotNumber]._allInAccept = inMsg._accept;
                findRoom._netData_room._totalPot = inMsg._totalPot;
            }
        }
    }

    #endregion

    #region ���� �ݰ� Ĩ �̵� ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // ���� �ݰ� Ĩ �̵� ����
    void NotifySafeMoveChip(AcNetDataSC_notifySafeMoveChip inMsg)
    {
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            findRoom._netData_room._slotList[inMsg._slotNumber]._userInfo._balance = inMsg._safeChip; // ���� ���� Ĩ
        }
    }

    #endregion

    #region ���� �ִϸ��̼� ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // ���� �ִϸ��̼� ����
    void NotifyAnimation(AcNetDataSC_notifyAnimation inMsg)
    {
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            findRoom._netData_room._slotList[inMsg._dstSlotNumber]._userInfo._balance = inMsg._userSafeChip;

            GameEmoticonTableData data = GameEmoticonTable.Instance.GetData(inMsg._animationId);
            if (data.EmoticonType == eEmoticonType.TYPE_CLEAR)
            {
                findRoom._netData_room._slotList[inMsg._dstSlotNumber]._emoticonList.Clear();
            }
            else
            {
                if (findRoom._netData_room._slotList[inMsg._dstSlotNumber]._emoticonList.Any(d => d == inMsg._animationId) == false)
                {
                    findRoom._netData_room._slotList[inMsg._dstSlotNumber]._emoticonList.Add(inMsg._animationId);
                }
            }

            if (InGameManager.Instance != null)
                InGameManager.Instance.Emoticon(inMsg);

            //inMsg._dstSlotNumber; // Ÿ���ִ� �ִϸ��̼��϶���
            //inMsg._animationId;
        }
    }

    #endregion

    #region ���� ���� �� ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // ���� ���� �� ����
    void NotifyDealerTip(AcNetDataSC_notifyDealerTip inMsg)
    {
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            findRoom._netData_room._slotList[inMsg._slotNumber]._userInfo._balance = inMsg._userSafeChip;
            if (InGameManager.Instance != null)
                InGameManager.Instance.DealerTip(inMsg);
        }
    }

    #endregion

    #region ���� ���� ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // ���� ���� ����
    void NotifyRoundState(AcNetDataSC_notifyRoundState inMsg)
    {
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            findRoom._currentRoundState = inMsg._roundState;

            switch (findRoom._currentRoundState)
            {
                case eRoundState.STATE_GAMESTART:
                    // ���ӽ��� ���� 
                    findRoom._userDeckList.Clear();
                    findRoom._userJokerDeckList.Clear();
                    for (int i = 0; i < findRoom._netData_room._slotList.Count; i++)
                    {
                        findRoom._netData_room._circleCount = 0;

                        findRoom._userDeckList.Add(new List<AcNetData_DeckInfo>());
                        findRoom._userJokerDeckList.Add(new AcNetData_DeckInfo());
                        findRoom._netData_room._slotList[i]._fold = false;
                        findRoom._netData_room._slotList[i]._cardSee = false;
                        findRoom._netData_room._slotList[i]._allInAccept = false;
                        findRoom._netData_room._slotList[i]._totalBettingBalance = 0;

                        var tempDeckInfo = new AcNetData_DeckInfo();
                        tempDeckInfo._deckNumber = 0;
                        tempDeckInfo._genealogyType = eGenealogyType.TYPE_NONE;
                        tempDeckInfo._genealogyCardNumber = 2;
                        for (int k = 0; k < 3; k++)
                        {
                            tempDeckInfo._cardList.Add(new AcNetData_CardInfo() { _number = 2, _shapeType = eCardShapeType.TYPE_SPADE });
                        }
                        findRoom._userDeckList[i].Add(tempDeckInfo);

                        tempDeckInfo = new AcNetData_DeckInfo();
                        tempDeckInfo._deckNumber = 0;
                        tempDeckInfo._genealogyType = eGenealogyType.TYPE_NONE;
                        tempDeckInfo._genealogyCardNumber = 2;
                        for (int k = 0; k < 3; k++)
                        {
                            tempDeckInfo._cardList.Add(new AcNetData_CardInfo() { _number = 2, _shapeType = eCardShapeType.TYPE_SPADE });
                        }
                        findRoom._userJokerDeckList.Add(tempDeckInfo);
                    }

                    findRoom._netData_room._showDownType = eShowDownType.TYPE_NONE;

                    //var startGame = NetworkTest.Instance.FindRootGame(inMsg._roomIndex);
                    //startGame.ChangeState(eGameSceneState.STATE_ROOMGAMEPLAY);
                    break;

                case eRoundState.STATE_DEFAULTCARDRECEIVE:
                    // �⺻ ī�� 3�� �޴� ����
                    for (int i = 0; i < findRoom._netData_room._slotList.Count; i++)
                    {
                        // findRoom._netData_room._slotList[i]._deckList[0]._genealogyType;
                        // findRoom._netData_room._slotList[i]._deckList[0]._cardList;
                        // findRoom._netData_room._slotList[i]._cardSee;
                    }
                    break;

                case eRoundState.STATE_AUTOBETTING:
                    // ���� �ڵ� �����ϴ� ����
                    break;

                case eRoundState.STATE_USERTURN:
                    // ���� �����ϴ� ����
                    break;

                case eRoundState.STATE_SIDESHOW:
                    // ���̵�� ��û ����
                    findRoom._netData_room._turnEndDateTime = AcUserInfo.ServerDateTime.AddSeconds(GameConfigTable.Instance.GetConfigValue(eConfigType.TYPE_SIDESHOWLIMITTIME));
                    break;

                case eRoundState.STATE_ALLINPOTLIMIT:
                    // ���� �̸��� ��û ����
                    findRoom._netData_room._turnEndDateTime = AcUserInfo.ServerDateTime.AddSeconds(GameConfigTable.Instance.GetConfigValue(eConfigType.TYPE_ALLINLIMITTIME));
                    break;

                case eRoundState.STATE_ALLIN:
                    // ���� ��û ����
                    findRoom._netData_room._turnEndDateTime = AcUserInfo.ServerDateTime.AddSeconds(GameConfigTable.Instance.GetConfigValue(eConfigType.TYPE_ALLINLIMITTIME));
                    break;

                case eRoundState.STATE_SHOWDOWN:
                case eRoundState.STATE_SHOWDOWNSKIP:
                    //for (int i = 0; i < findRoom._netData_room._slotList.Count; i++)
                    {
                        //Debug.Log(findRoom._userDeckList[0][0]._cardList[0].CardIndex);
                        //Debug.Log(findRoom._userDeckList[1][0]._cardList[0].CardIndex);
                    }
                        // ī�� ��ü ���� ����
                        break;

                case eRoundState.STATE_GAMERESULT:
                    //var resultGame = NetworkTest.Instance.FindRootGame(inMsg._roomIndex);
                    //resultGame.ChangeState(eGameSceneState.STATE_ROOMGAMERESULT);
                    // ���Ӱ�� ���� 
                    break;
                case eRoundState.STATE_GAMEEND:
                    findRoom._netData_room._totalPot = 0;
                    break;
            }
            if (InGameManager.Instance != null)
                InGameManager.Instance.SetRoundState(inMsg);
        }
    }

    #endregion

    #region ��ٿ� Ÿ�� ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // ��ٿ� Ÿ�� ����
    void NotifyShowDownType(AcNetDataSC_notifyShowDownType inMsg)
    {
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            findRoom._netData_room._showDownType = inMsg._showDownType;
            if (InGameManager.Instance != null)
                InGameManager.Instance.ShowDownType(inMsg);
        }
    }

    #endregion

    #region ī�� �ޱ� ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // ī�� �ޱ� ����
    void NotifyCardReceive(AcNetDataSC_notifyDeckReceive inMsg)
    {
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            for (int i = 0; i < findRoom._userDeckList.Count; i++)
            {
                if (i != inMsg._slotNumber)
                    continue;

                var cardAdd = false;
                for (int k = 0; k < findRoom._userDeckList[i].Count; k++)
                {
                    if (findRoom._userDeckList[i][k]._deckNumber == inMsg._deckInfo._deckNumber)
                    {
                        findRoom._userDeckList[i][k]._cardList.Clear();
                        findRoom._userDeckList[i][k]._cardList.AddRange(inMsg._deckInfo._cardList);
                        findRoom._userDeckList[i][k]._genealogyType = inMsg._deckInfo._genealogyType;
                        findRoom._userDeckList[i][k]._genealogyCardNumber = inMsg._deckInfo._genealogyCardNumber;
                        cardAdd = true;
                        break;
                    }
                }

                if (cardAdd == false)
                {
                    findRoom._userDeckList[i].Add(inMsg._deckInfo);
                }

                break;
            }

            // ��Ŀ
            for (int i = 0; i < findRoom._userJokerDeckList.Count; i++)
            {
                if (i != inMsg._slotNumber)
                    continue;

                if (findRoom._userJokerDeckList[i]._deckNumber == inMsg._deckInfo_joker._deckNumber)
                {
                    findRoom._userJokerDeckList[i]._cardList.Clear();
                    findRoom._userJokerDeckList[i]._cardList.AddRange(inMsg._deckInfo_joker._cardList);
                    break;
                }
            }
        }
    }

    #endregion

    #region ���� ��� ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // ���� ��� ����
    void NotifyGameResult(AcNetDataSC_notifyGameResult inMsg)
    {
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            findRoom._winnerReceiveBalance = inMsg._winnerReceiveBalance;
            findRoom._winnerSlotNumberList = inMsg._winnerSlotNumberList;
            findRoom._leaguePointList = inMsg._leaguePointList;
            findRoom._penaltyInfoList = inMsg._penaltyInfoList;

            if (findRoom.IsPlay() == true)
            {
                if (inMsg._winnerSlotNumberList.Any(data => data == findRoom._mySlotNumber) == true)
                {
                    AcUserInfo._netData_user._winCount++;
                }
                else
                {
                    AcUserInfo._netData_user._loseCount++;
                }
            }
        }
    }
    
    #endregion

    #region ��Ż�� ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // ��Ż�� ����
    void NotifyTotalPot(AcNetDataSC_notifyTotalPot inMsg)
    {
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            findRoom._netData_room._totalPot = inMsg._totalPot;
        }
    }

    #endregion

    #region ���� ���ɿ��� ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // �ػ罺 Ȧ�� ���� ���ɿ��� ����
    void NotifyBettingEnable(AcNetDataSC_notifyBettingEnable inMsg)
    {
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            findRoom._bettingEnable = inMsg._bettingEnable;
        }
    }

    #endregion

    #region �� ä�� ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // �� ä�� ����
    void NotifyRoomTalk(AcNetDataSC_notifyRoomTalk inMsg)
    {
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            //findRoom._roomTalkInfoList.Add(inMsg._talkInfo);

            var slotInfo = findRoom._netData_room._slotList.Where(x => x._userInfo._uId == inMsg._talkInfo._userUId).FirstOrDefault();
            if (slotInfo != null)
            {
                if (!PlayerDataManager.Instance.IsBlockChatList(inMsg._talkInfo._userUId))
                {
                    ChatInfo chatInfo = new ChatInfo();
                    chatInfo._userUId = inMsg._talkInfo._userUId;
                    chatInfo._talkStr = inMsg._talkInfo._talkStr;
                    chatInfo._nickName = slotInfo._userInfo._nickName;
                    chatInfo._uId = slotInfo._userInfo._userId;
                    chatInfo._picturerId = slotInfo._userInfo._pictureDataId;

                    PlayerDataManager.Instance.AddChatInfo(findRoom._multiGameOrder, chatInfo, true);
                }
            }
        }
    }

    #endregion

    #region �� ���ӷ� ������ ���� ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // �� ���ӷ� ������ ���� ����
    void NotifyRoomGameRoomDataChange(AcNetDataSC_notifyRoomGameRoomDataChange inMsg)
    {
        var findRoom = AcUserInfo.GetEnterRoom(inMsg._roomIndex);
        if (findRoom != null)
        {
            findRoom._netData_room._roomDataId = inMsg._gameRoomDataId;

            if (InGameManager.Instance != null)
                InGameManager.Instance.SetGameDataId(inMsg);
        }
    }

    #endregion
}
