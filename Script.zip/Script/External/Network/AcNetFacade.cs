﻿using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Lidgren.Network;
using UnityEngine.Networking;
using ForuOnes.T3.LuckyTeenPatti;
using ForuOnes.T3.LuckyTeenPatti.Table;
using System.Text;
using System.Net;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// AcNetFacade
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

public class AcNetFacade : JNetPeer
{
    public static AcNetFacade Instance;

    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 변수
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 변수

    public NetClient _netLoginClient;
    public NetClient _netGameClient;
    //public NetClient _netRankClient;

    public AcNetResultExecute _netResultExecute;

    private AcNetPacket_dispatcher _packet_dispatcher;

    public Action<int> _loginConnectCallbackFunc = null;
    public Action<int> _gameConnectCallbackFunc = null;
    //public Action<int> _rankConnectCallbackFunc = null;

    #endregion

    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 프로퍼티
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 프로퍼티

    // login
    public NetConnection _loginServerConnection
    { get { return _netLoginClient.ServerConnection; } }
    public NetConnectionStatus _loginConnectionStatus
    { get { return _netLoginClient.ConnectionStatus; } }
    public virtual bool IsLoginConnected
    { get { return _loginConnectionStatus == NetConnectionStatus.Connected; } }
    Action<string> LoginDisconnectionCallBack { get; set; }

    // game
    public NetConnection _gameServerConnection
    { get { return _netGameClient.ServerConnection; } }
    public NetConnectionStatus _gameConnectionStatus
    { get { return _netGameClient.ConnectionStatus; } }
    public virtual bool IsGameConnected
    { get { return _gameConnectionStatus == NetConnectionStatus.Connected; } }
    Action<string> GameDisconnectionCallBack { get; set; }
    Action GameServerChangeCallBack { get; set; }

    // rank
    //public NetConnection _rankServerConnection
    //{ get { return _netRankClient.ServerConnection; } }
    //public NetConnectionStatus _rankConnectionStatus
    //{ get { return _netRankClient.ConnectionStatus; } }
    //public virtual bool IsRankConnected
    //{ get { return _rankConnectionStatus == NetConnectionStatus.Connected; } }
    //Action<string> RankDisconnectionCallBack { get; set; }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 메인 함수
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 메인 함수

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void Awake()
    {
        Instance = this;

        _netResultExecute = new AcNetResultExecute();

        InitPeerPack();

        createDispathers();

        DontDestroyOnLoad(gameObject);

        StartCoroutine(UpdatePingPong());
    }

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    protected void createDispathers()
    {
        _packet_dispatcher = gameObject.AddComponent<AcNetPacket_dispatcher>();
        _packet_dispatcher.Initialize(this);
    }

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public void OnApplicationQuit()
    {
        //SendPacket_Logout();
        //DisconnectLoginServer();
        //DisconnectGameServer();
        //DisconnectRankServer();
    }

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public IEnumerator UpdatePingPong()
    {
        while (true)
        {
            //if (IsLoginConnected == true)
            //{
            //    SendPacket_req_ping(ePeerType.LoginPeer);
            //}

            //if (IsRankConnected == true)
            //{
            //    SendPacket_req_ping(ePeerType.RankPeer);
            //}

            if (IsGameConnected == true)
            {
                SendPacket_req_ping(ePeerType.GamePeer);
            }

            yield return new WaitForSeconds(10);
        }
    }

    #endregion

    #region NetPeer 패킷 클리어

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public void ClearPeerPacket()
    {
        foreach (var keyValuePair in _peerPackList)
        {
            ClearPeerMessage(keyValuePair.Value);
        }
    }

    #endregion

    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 패킷 메시지 
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 패킷 메시지

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    protected NetOutgoingMessage CreateMessage(ePeerType peerType, ushort msgId)
    {
        var msg = _peerPackList[peerType]._peer.CreateMessage();
        msg.Write(msgId);

        return msg;
    }

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    protected void SendMessage(ePeerType peerType, NetOutgoingMessage msg)
    {
        var client = (NetClient)_peerPackList[peerType]._peer;

        // Encryption
        //var encryption = new NetAESEncryption(client, "temp24qw");
        //msg.Encrypt(encryption);

        client.SendMessage(msg, NetDeliveryMethod.ReliableOrdered, 1);
    }

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public void SendMessage(ePeerType peerType, ushort msgId, AcNetData_base netData = null)
    {
        var outMsg = CreateMessage(peerType, msgId);
        if (null == netData)
            netData = new AcNetData_base();

        //netData._messageIndex = _peerPackList[peerType]._messageIndex++;
        netData.Packing(outMsg);

        SendMessage(peerType, outMsg);
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 네트워크 초기화 & 연결 
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 피어 패키지 초기화
    void InitPeerPack()
    {
        // 로그인서버 Peer
        var loginPeerPack = new ConnectPeerPack();
        _netLoginClient = new NetClient(new NetPeerConfiguration("LTPServer"));
        _netLoginClient.Start();

        loginPeerPack._peer = _netLoginClient;
        loginPeerPack.Connected += (c) =>
        {
            Debug.Log("Connected to LoginServer");
            SendPacket_req_certification(ePeerType.LoginPeer, _loginConnectCallbackFunc);
        };

        loginPeerPack.Disconnected += (c, r) =>
        {
            loginPeerPack._messageIndex = 0;
            //DisconnectGameServer(r);
            //DisconnectRankServer(r);
            Debug.Log("Disconnected from server");

            if (LoginDisconnectionCallBack != null)
                LoginDisconnectionCallBack(r);
            //Func<int, string> getString = T3.LocalizationSentenceTable.Instance.GetString;
            //if (!ForuOnes.T3.LuckyTeenPatti.PlayerPrefsManager.Instance.logOut)
            //    ForuOnes.T3.LuckyTeenPatti.MessageBoxManager.Instance.OnMessageBoxUI(getString(110028), getString(30011), "", () => UnityEngine.SceneManagement.SceneManager.LoadSceneAsync("02.Login"), null, true, false);
        };

        SetPeer(ePeerType.LoginPeer, loginPeerPack);

        // 게임서버 Peer
        var gamePeerPack = new ConnectPeerPack();
        var config = new NetPeerConfiguration("LTPServer");
        config.ReceiveBufferSize = 1048576;
        _netGameClient = new NetClient(config);
        _netGameClient.Start();

        gamePeerPack._peer = _netGameClient;
        gamePeerPack.Connected += (c) =>
        {
            Debug.Log("Connected to GameServer");
            SendPacket_req_certification(ePeerType.GamePeer, _gameConnectCallbackFunc);
        };
        gamePeerPack.Disconnected += (c, r) =>
        {
            Debug.Log("Disconnected from GameServer");
            //DisconnectLoginServer(r);
            //DisconnectRankServer(r);
            gamePeerPack._messageIndex = 0;

            if (GameDisconnectionCallBack != null)
                GameDisconnectionCallBack(r);

            AcUserInfo._isLogin = false;
            AcUserInfo._TOTRankRefreshIndex = 0;
            AcUserInfo._chipRankRefreshIndex = 0;
            AcUserInfo._friendList.Clear();
            AcUserInfo._friendRequestList.Clear();
            AcUserInfo._friendTalkDicList.Clear();

            //Func<int, string> getString = T3.LocalizationSentenceTable.Instance.GetString;
            //if (!ForuOnes.T3.LuckyTeenPatti.PlayerPrefsManager.Instance.logOut)
            //    ForuOnes.T3.LuckyTeenPatti.MessageBoxManager.Instance.OnMessageBoxUI(getString(110028), getString(30011), "", () => UnityEngine.SceneManagement.SceneManager.LoadSceneAsync("02.Login"), null, true, false);
        };

        SetPeer(ePeerType.GamePeer, gamePeerPack);

        // 랭크서버 Peer
        //var rankPeerPack = new ConnectPeerPack();
        //_netRankClient = new NetClient(new NetPeerConfiguration("LTPServer"));
        //_netRankClient.Start();

        //rankPeerPack._peer = _netRankClient;
        //rankPeerPack.Connected += (c) =>
        //{
        //    Debug.Log("Connected to RankServer");
        //    SendPacket_req_certification(ePeerType.RankPeer, _rankConnectCallbackFunc);
        //};
        //rankPeerPack.Disconnected += (c, r) =>
        //{
        //    Debug.Log("Disconnected from RankServer");
        //    DisconnectLoginServer(r);
        //    DisconnectGameServer(r);

        //    rankPeerPack._messageIndex = 0;

        //    if (RankDisconnectionCallBack != null)
        //        RankDisconnectionCallBack(r);
        //};

        //SetPeer(ePeerType.RankPeer, rankPeerPack);
    }

    #endregion

    #region 연결 / 연결끊기

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void ConnectLoginServer(Action<int> fun_res)
    {
        Debug.Log("LoginServer connect try");
        if (IsLoginConnected)
        {
            Debug.Log("LoginServer already connect");
            fun_res(2);
        }
        else
        {
            Debug.Log("AcNetworkBase._remoteIP = " + AcNetworkBase._remoteIP_Login);
            Debug.Log("AcNetworkBase._remotePort = " + AcNetworkBase._listenPort_Login);
            _netLoginClient.Connect(AcNetworkBase._remoteIP_Login, AcNetworkBase._listenPort_Login);
            _loginConnectCallbackFunc = fun_res;
        }
    }

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void DisconnectLoginServer(string byeMessage = "bye")
    {
        Debug.Log("DisconnectLoginServer");

        if (_netLoginClient != null)
            _netLoginClient.Disconnect(byeMessage);

        _peerPackList[ePeerType.LoginPeer]._messageIndex = 0;
    }

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void ConnectGameServer(string remoteIP, int remotePort, Action<int> fun_res)
    {
        Debug.Log("GameServer connect try");
        if (IsGameConnected)
        {
            Debug.Log("GameServer already connect");
            fun_res(2);
        }
        else
        {
            Debug.Log("AcNetworkBase._remoteIP = " + remoteIP);
            Debug.Log("AcNetworkBase._remotePort = " + remotePort);
            _gameConnectCallbackFunc = fun_res;
            _netGameClient.Connect(remoteIP, remotePort);
        }
    }

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void DisconnectGameServer(string byeMessage = "bye")
    {
        Debug.Log("접속 해제");

        if (_netGameClient != null)
            _netGameClient.Disconnect(byeMessage);

        _peerPackList[ePeerType.GamePeer]._messageIndex = 0;
    }

    ////------------------------------------------------------------------------------------------------------------------------------------------------------
    //public virtual void ConnectRankServer(string remoteIP, int remotePort, Action<int> fun_res)
    //{
    //    Debug.Log("RankServer connect try");
    //    if (IsRankConnected)
    //    {
    //        Debug.Log("RankServer already connect");
    //        fun_res(1);
    //    }
    //    else
    //    {
    //        Debug.Log("AcNetworkBase._remoteIP = " + remoteIP);
    //        Debug.Log("AcNetworkBase._remotePort = " + remotePort);
    //        _rankConnectCallbackFunc = fun_res;
    //        _netRankClient.Connect(remoteIP, remotePort);
    //    }
    //}

    ////------------------------------------------------------------------------------------------------------------------------------------------------------
    //public virtual void DisconnectRankServer(string byeMessage = "bye")
    //{
    //    Debug.Log("접속 해제");

    //    if (_netRankClient != null)
    //        _netRankClient.Disconnect(byeMessage);

    //    _peerPackList[ePeerType.RankPeer]._messageIndex = 0;
    //}
    #endregion

    #region 연결 끊김 콜백 등록

    //public void RegisterLoginDisconnectionCallBack(Action<string> func)
    //{
    //    LoginDisconnectionCallBack = func;
    //}

    public void RegisterGameDisconnectionCallBack(Action<string> func)
    {
        GameDisconnectionCallBack = func;
    }

    //public void RegisterRankDisconnectionCallBack(Action<string> func)
    //{
    //    RankDisconnectionCallBack = func;
    //}

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 입장 (버전체크 / 로그인 / 가입)
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 서버인증서 확인

    ////------------------------------------------------------------------------------------------------------------------------------------------------------
    //class AcceptAllCertificatesSignedWithASpecificKeyPublicKey : CertificateHandler
    //{
    //    protected override bool ValidateCertificate(byte[] certificateData)
    //    {
    //        return true;
    //    }
    //}

    #endregion

    #region 서버 점검 확인

    //public virtual IEnumerator SendPacket_req_serverCheckInfo(string mACAddress, Action<eGameResult, string> fun_res = null)
    //{
    //    string url = string.Format("http://{0}:{1}/Login/ServerConnectionInfoCheck", AcNetworkBase._remoteIP_Login, AcNetworkBase._listenPort_Http_Login);
    //    AcNetDataCS_reqServerConnectionInfoCheck outMsg = new AcNetDataCS_reqServerConnectionInfoCheck();
    //    outMsg._version = AcNetworkBase._clientVersion;
    //    outMsg._mACAddress = mACAddress;

    //    byte[] bytes = Encoding.UTF8.GetBytes(JsonUtility.ToJson(outMsg));
    //    UnityWebRequest www = UnityWebRequest.Put(url, bytes);
    //    www.timeout = 10;
    //    www.method = "POST";
    //    www.SetRequestHeader("Content-Type", "application/json");
    //    www.certificateHandler = new AcceptAllCertificatesSignedWithASpecificKeyPublicKey();

    //    yield return www.SendWebRequest();

    //    if (string.IsNullOrEmpty(www.error))
    //    {
    //        if (www.isNetworkError || www.isHttpError)
    //        {
    //            fun_res(eGameResult.RESULT_UNEXPECTED, "Network Error");
    //        }
    //        else
    //        {
    //            var inMsg = JsonUtility.FromJson<AcNetDataSC_resServerConnectionInfoCheck>(www.downloadHandler.text);
    //            fun_res(inMsg._result, inMsg._serverCheckString);
    //        }
    //    }
    //    else
    //    {
    //        fun_res(eGameResult.RESULT_UNEXPECTED, www.error);
    //    }
    //}

    #endregion

    #region 로그인 요청

    ////------------------------------------------------------------------------------------------------------------------------------------------------------
    //public virtual IEnumerator SendPacket_login(string userId, eAccountLinkType accountLinkType, string nickName, byte OS, string OSVersion, string deviceCode, string mACAddress, string systemLanguageType, Action<eGameResult> fun_res = null)
    //{
    //    string url = string.Format("http://{0}:{1}/Login/Login", AcNetworkBase._remoteIP_Login, AcNetworkBase._listenPort_Http_Login);

    //    //--------------------------------------------------------------------
    //    // 로그인서버 로그인            
    //    var reqLogin = new AcNetDataCS_reqLSLogin();
    //    reqLogin._userId = userId;
    //    reqLogin._accoundLinkType = accoundLinkType;
    //    reqLogin._nickName = nickName;
    //    reqLogin._OS = OS;
    //    reqLogin._OSVersion = OSVersion;
    //    reqLogin._systemLanguageType = systemLanguageType;
    //    reqLogin._deviceCode = deviceCode;
    //    reqLogin._clientVersion = AcNetworkBase._clientVersion;
    //    reqLogin._mACAddress = mACAddress;

    //    byte[] bytes = Encoding.UTF8.GetBytes(JsonUtility.ToJson(reqLogin));
    //    UnityWebRequest www = UnityWebRequest.Put(url, bytes);
    //    www.timeout = 10;
    //    www.method = "POST";
    //    www.SetRequestHeader("Content-Type", "application/json");
    //    www.certificateHandler = new AcceptAllCertificatesSignedWithASpecificKeyPublicKey();

    //    yield return www.SendWebRequest();

    //    if (string.IsNullOrEmpty(www.error) == false || www.isNetworkError || www.isHttpError)
    //    {
    //        fun_res(eGameResult.RESULT_FAIL);
    //        yield break;
    //    }

    //    var inMsg = JsonUtility.FromJson<AcNetDataSC_resLSLogin>(www.downloadHandler.text);
    //    if (inMsg._result == eGameResult.RESULT_OK)
    //    {
    //        Debug.Log("로그인 서버 로그인 성공");

    //        // 게임서버 주소 확인
    //        if (string.IsNullOrEmpty(inMsg._gameServerIP) || inMsg._gameServerPort == 0)
    //        {
    //            fun_res(eGameResult.RESULT_NOTEXISTGAMESERVER);
    //            yield break;
    //        }

    //        //--------------------------------------------------------------------
    //        // 게임서버 연결	
    //        ConnectGameServer(inMsg._gameServerIP, inMsg._gameServerPort, conGameRes =>
    //        {
    //            if (conGameRes != 2)
    //                return;

    //            Debug.Log("게임서버 접속 성공");

    //            //--------------------------------------------------------------------
    //            // 게임서버 로그인	
    //            var reqGameServerLogin = new AcNetDataCS_reqLogin();
    //            reqGameServerLogin._userId = userId;
    //            reqGameServerLogin._loginToken = inMsg._loginToken;
    //            reqGameServerLogin._accoundLinkType = accoundLinkType;
    //            reqGameServerLogin._nickName = nickName;
    //            reqGameServerLogin._deviceCode = deviceCode;
    //            reqGameServerLogin._mACAddress = mACAddress;

    //            SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_Login, reqGameServerLogin);

    //            RegisterMessageHandler<AcNetDataSC_resLogin>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_Login, (inMsg2) =>
    //            {
    //                if (inMsg2._result == eGameResult.RESULT_OK || inMsg2._result == eGameResult.RESULT_LOGIN_USERPROFILEREGISTER || inMsg2._result == eGameResult.RESULT_LOGIN_SERVERRECONNECTION)
    //                {
    //                    // 로그인 성공
    //                    AcUserInfo._isLogin = true;

    //                    // 공지 게시판 정보
    //                    AcUserInfo._noticeBoardList = inMsg2._BBSNoticeInfoList;

    //                    // 배너 정보
    //                    AcUserInfo._bannerList = inMsg2._BBSBannerInfoList;

    //                    // 챔피언쉽 정보
    //                    AcUserInfo._tOTChampionShipState = inMsg2._tOTChampionShipState;
    //                    if (inMsg2._tOTChampionShipState == eTOTChampionShipState.STATE_START)
    //                    {
    //                        AcUserInfo._tOTChampionShipEndDateTime = inMsg2._tOTChampionShipEndDateTime;
    //                        AcUserInfo._tOTChampionShipGameModeDataId = inMsg2._tOTChampionShipGameModeDataId;

    //                        // 유저 챔피언쉽 랭크 정보 요청
    //                        SendPacket_req_simpleTOTChampionShipUserList();
    //                    }

    //                    // 재연결일수도 있으므로 방정보는 항상 비움
    //                    AcUserInfo._enterRoomDic.Clear();

    //                    //--------------------------------------------------------------------
    //                    // 5. 서버 시간 요청
    //                    Debug.Log("서버 시간 요청");
    //                    SendPacket_req_serverDatetime();

    //                    //--------------------------------------------------------------------
    //                    // 6. 유저 정보 요청
    //                    Debug.Log("유저 정보 요청");
    //                    SendPacket_req_userInfo(userId, (inMsg3) =>
    //                    {
    //                        if (inMsg3 == eGameResult.RESULT_OK)
    //                        {
    //                            Debug.Log("유저 정보 요청 성공");

    //                            if (fun_res != null)
    //                            {
    //                                //if (inMsg2._result == eGameResult.RESULT_LOGIN_USERPROFILEREGISTER)
    //                                //{
    //                                fun_res(inMsg2._result);
    //                                //}
    //                                //else
    //                                //{
    //                                //    fun_res(inMsg._result);
    //                                //}
    //                                //if (_test == 1)
    //                                //{
    //                                //    SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_Login, reqLogin);
    //                                //    _test--;
    //                                //    Debug.Log("재접속!!!!");
    //                                //}
    //                            }
    //                        }
    //                        else
    //                        {
    //                            Debug.Log("유저 정보 요청 실패: " + inMsg3);
    //                            if (fun_res != null)
    //                                fun_res(inMsg3);
    //                        }
    //                    });
    //                }
    //                else
    //                {
    //                    Debug.Log("게임서버 로그인 실패:" + inMsg2._result);
    //                    DisconnectLoginServer();
    //                    DisconnectGameServer();
    //                    if (fun_res != null)
    //                        fun_res(inMsg2._result);
    //                    return;
    //                }
    //            });
    //        });
    //    }
    //    else
    //    {
    //        Debug.Log("로그인서버 로그인 실패:" + inMsg._result);

    //        if (fun_res != null)
    //            fun_res(inMsg._result);
    //    }
    //}

    #endregion

    #region 계정생성 요청

    ////------------------------------------------------------------------------------------------------------------------------------------------------------
    //public virtual IEnumerator SendPacket_account(string userId, eAccountLinkType accountLinkType, string nickName, byte OS, string systemLanguageType, string deviceCode, string macAddress, Action<eGameResult> fun_res = null)
    //{
    //    string url = string.Format("http://{0}:{1}/Login/Account", AcNetworkBase._remoteIP_Login, AcNetworkBase._listenPort_Http_Login);

    //    //--------------------------------------------------------------------
    //    // 로그인서버 계정 생성 요청       
    //    var outMsg = new AcNetDataCS_reqAccount();
    //    outMsg._userId = userId;
    //    outMsg._accountLinkType = accountLinkType;
    //    outMsg._nickName = nickName;
    //    outMsg._OS = OS;
    //    outMsg._systemLanguageType = systemLanguageType;
    //    outMsg._deviceCode = deviceCode;
    //    outMsg._macAddress = macAddress;

    //    byte[] bytes = Encoding.UTF8.GetBytes(JsonUtility.ToJson(outMsg));
    //    UnityWebRequest www = UnityWebRequest.Put(url, bytes);
    //    www.timeout = 10;
    //    www.method = "POST";
    //    www.SetRequestHeader("Content-Type", "application/json");
    //    www.certificateHandler = new AcceptAllCertificatesSignedWithASpecificKeyPublicKey();

    //    yield return www.SendWebRequest();

    //    if (string.IsNullOrEmpty(www.error))
    //    {
    //        if (www.isNetworkError || www.isHttpError)
    //        {
    //            fun_res(eGameResult.RESULT_NETWORKERROR);
    //        }
    //        else
    //        {
    //            var inMsg = JsonUtility.FromJson<AcNetDataSC_resAccount>(www.downloadHandler.text);

    //            if (inMsg._result == eGameResult.RESULT_OK)
    //            {
    //                Debug.Log("계정 생성 성공");
    //            }
    //            else
    //            {
    //                Debug.Log("계정 생성 실패:" + inMsg._result);
    //            }

    //            if (fun_res != null)
    //                fun_res(inMsg._result);
    //        }
    //    }
    //    else
    //    {
    //        fun_res(eGameResult.RESULT_NETWORKERROR);
    //    }
    //}

    #endregion

    #region 서버 약관 확인

    public void SendPacket_req_CheckPrivacyPolicy(DateTime acceptDatetime, Action<eGameResult, string> func)
    {
        StartCoroutine(SendPacket_req_PrivacyPolicyDateTimeInfo(acceptDatetime, (res) =>
        {
            if (res == eGameResult.RESULT_NEEDPRIVACYPOLICYACCEPT)
            {
                StartCoroutine(SendPacket_req_PrivacyPolicyContentsInfo(func));
            }
            else
            {
                func(eGameResult.RESULT_OK, "");
            }
        }));
    }

    public IEnumerator SendPacket_req_PrivacyPolicyDateTimeInfo(DateTime acceptDatetime, Action<eGameResult> func)
    {
        UnityWebRequest www = UnityWebRequest.Get(AcNetworkBase._remoteWebAdress_PrivacyPolicy + "/PrivacyPolicyDateTime.json");
        www.timeout = 5;
        yield return www.SendWebRequest();

        if (string.IsNullOrEmpty(www.error))
        {
            if (www.isNetworkError || www.isHttpError)
            {
                func(eGameResult.RESULT_UNEXPECTED);
            }
            else
            {
                var jsonDataInfo = JsonUtility.FromJson<LTPServerPrivacyPolicy_DateTimeInfo>(www.downloadHandler.text);
                var jsonDatetime = DateTime.Parse(jsonDataInfo.DateTime);
                if (acceptDatetime < jsonDatetime)
                {
                    func(eGameResult.RESULT_NEEDPRIVACYPOLICYACCEPT);
                }
                else
                {
                    func(eGameResult.RESULT_OK);
                }
            }
        }
        else
        {
            func(eGameResult.RESULT_UNEXPECTED);
        }
    }

    public IEnumerator SendPacket_req_PrivacyPolicyContentsInfo(Action<eGameResult, string> func)
    {
        UnityWebRequest www = UnityWebRequest.Get(AcNetworkBase._remoteWebAdress_PrivacyPolicy + "/PrivacyPolicyContent.json");
        www.timeout = 5;
        yield return www.SendWebRequest();

        if (string.IsNullOrEmpty(www.error))
        {
            if (www.isNetworkError || www.isHttpError)
            {
                func(eGameResult.RESULT_UNEXPECTED, "");
            }
            else
            {
                var jsonDataInfo = JsonUtility.FromJson<LTPServerPrivacyPolicy_ContentsInfo>(www.downloadHandler.text);
                func(eGameResult.RESULT_NEEDPRIVACYPOLICYACCEPT, jsonDataInfo.Contents);
            }
        }
        else
        {
            func(eGameResult.RESULT_UNEXPECTED, "");
        }
    }

    #endregion

    #region 유저 약관 수락 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 유저 약관 수락 요청
    public virtual void SendPacket_req_userPolicyAccept(Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqUserPolicyAccept();

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_UserPolicyAccept, outMsg);

        RegisterMessageHandler<AcNetDataSC_resUserPolicyAccept>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_UserPolicyAccept, (inMsg) =>
        {
            Debug.Log("[Network] 유저약관 수락 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._netData_user._accpetPolicyDateTime = inMsg._accpetPolicyDateTime;
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 버전 체크

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_checkServerConnectionInfo(string deviceId, Action<eGameResult, string> fun_res = null)
    {
        //--------------------------------------------------------------------
        // 1. 연결			
        ConnectLoginServer(res =>
        {
            if (res != 2)
                return;

            Debug.Log("접속 성공");

            //--------------------------------------------------------------------
            // 2. 버전 체크 요청
            SendPacket_req_serverConnectionInfoCheck(deviceId, (res2, serverCheckString) =>
            {
                if (fun_res != null)
                    fun_res(res2, serverCheckString);
            });
        });
    }

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_serverConnectionInfoCheck(string mACAddress, Action<eGameResult, string> fun_res = null)
    {
        var reqPaket = new AcNetDataCS_reqServerConnectionInfoCheck();
        reqPaket._version = AcNetworkBase._clientVersion;
        reqPaket._mACAddress = mACAddress;

        SendMessage(ePeerType.LoginPeer, AcNetMessageHeaders.CSReq_ServerConnectionInfoCheck, reqPaket);

        RegisterMessageHandler<AcNetDataSC_resServerConnectionInfoCheck>(ePeerType.LoginPeer, AcNetMessageHeaders.SCRes_ServerConnectionInfoCheck, (inMsg) =>
        {
            Debug.Log("[네트워크] 서버 연결 정보 체크: " + inMsg._result);

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._serverCheckString);
        });
    }

    #endregion

    #region Ping & Pong

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_ping(ePeerType peerType, Action<eGameResult> fun_res = null)
    {
        var reqPaket = new AcNetDataCS_reqPing();
        SendMessage(peerType, AcNetMessageHeaders.CSReq_Ping, reqPaket);

        RegisterMessageHandler<AcNetDataSC_resPong>(peerType, AcNetMessageHeaders.SCRes_Pong, (inMsg) =>
        {
            // info: 콜백 호출 안되게 막음
        });
    }

    #endregion

    #region 네트워크 인증
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_certification(ePeerType peerType, Action<int> fun_res)
    {
        var reqPaket = new AcNetData_Certification();
        reqPaket._netType = eCertificationType.TYPE_CLIENT;

        SendMessage(peerType, AcNetMessageHeaders.CSSReq_Certification, reqPaket);

        RegisterMessageHandler<AcNetDataSC_response>(peerType, AcNetMessageHeaders.SCSRes_Certification, (inMsg) =>
        {
            _peerPackList[peerType]._messageIndex = 0;

            //SendPacket_req_Debug("시스템 메모리 : " + SystemInfo.systemMemorySize);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                Debug.Log("[네트워크] 네트워크 인증 성공");
                fun_res(2);
            }
            else
            {
                Debug.Log("[네트워크] 네트워크 인증 실패");
                fun_res(0);
            }

        });
    }

    #endregion

    #region 서버 시간 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_serverDatetime()
    {
        var reqPaket = new AcNetDataCS_reqServerDateTime();
        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_ServerDateTime, reqPaket);

        RegisterMessageHandler<AcNetDataSC_resServerDateTime>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_ServerDateTime, (inMsg) =>
        {
            AcUserInfo._serverSubtract_Milliseconds = inMsg._serverDate.Subtract(DateTime.Now).TotalMilliseconds;
            AcUserInfo._serverSubtract_Milliseconds += 19; // 시간 보정

            Debug.Log("[네트워크] 서버 시간 가저오기 성공 " + AcUserInfo._serverSubtract_Milliseconds);
            Debug.Log("[네트워크] 로컬 시간:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"));
            Debug.Log("[네트워크] 서버 시간:" + AcUserInfo.ServerDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
        });
    }

    #endregion

    #region 로그인 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_login(string userId, eAccountLinkType accountLinkType, string nickName, byte OS, string OSVersion, string deviceCode, string mACAddress, string systemLanguageType, Action<eGameResult> fun_res = null)
    {
        //--------------------------------------------------------------------
        // 1. 로그인서버 연결			
        ConnectLoginServer(res =>
        {
            if (res != 2)
                return;

            Debug.Log("로그인서버 접속 성공");

            //--------------------------------------------------------------------
            // 2. 로그인서버 로그인      
            var reqLogin = new AcNetDataCS_reqLSLogin();
            reqLogin._userId = userId;
            reqLogin._accountLinkType = accountLinkType;
            reqLogin._nickName = nickName;
            reqLogin._OS = OS;
            reqLogin._OSVersion = OSVersion;
            reqLogin._systemLanguageType = systemLanguageType;
            reqLogin._deviceCode = deviceCode;
            reqLogin._clientVersion = AcNetworkBase._clientVersion;
            reqLogin._mACAddress = mACAddress;

            SendMessage(ePeerType.LoginPeer, AcNetMessageHeaders.CSReq_Login, reqLogin);

            RegisterMessageHandler<AcNetDataSC_resLSLogin>(ePeerType.LoginPeer, AcNetMessageHeaders.SCRes_Login, (inMsg) =>
            {
                // 로그인 토큰 저장
                AcUserInfo._loginToken = inMsg._loginToken;

                if (inMsg._result == eGameResult.RESULT_OK)
                {
                    // 로그인 서버는 연결 종료
                    DisconnectLoginServer();

                    Debug.Log("로그인 성공");

                    if (inMsg._gameServerIP == "" || inMsg._gameServerPort == 0)
                    {
                        fun_res(eGameResult.RESULT_UNEXPECTED);
                        return;
                    }

                    //--------------------------------------------------------------------
                    // 게임서버 연결	
                    ConnectGameServer(inMsg._gameServerIP, inMsg._gameServerPort, conGameRes =>
                    {
                        if (conGameRes != 2)
                            return;

                        Debug.Log("게임서버 접속 성공");

                        //--------------------------------------------------------------------
                        // 게임서버 로그인	
                        var reqGameServerLogin = new AcNetDataCS_reqLogin();
                        reqGameServerLogin._userId = userId;
                        reqGameServerLogin._loginToken = inMsg._loginToken;
                        reqGameServerLogin._accoundLinkType = accountLinkType;
                        reqGameServerLogin._nickName = nickName;
                        reqGameServerLogin._deviceCode = deviceCode;
                        reqGameServerLogin._mACAddress = mACAddress;

                        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_Login, reqGameServerLogin);

                        RegisterMessageHandler<AcNetDataSC_resLogin>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_Login, (inMsg2) =>
                        {
                            if (inMsg2._result == eGameResult.RESULT_OK || inMsg2._result == eGameResult.RESULT_LOGIN_USERPROFILEREGISTER || inMsg2._result == eGameResult.RESULT_LOGIN_SERVERRECONNECTION)
                            {
                                // 로그인 성공
                                AcUserInfo._isLogin = true;

                                // 공지 게시판 정보
                                AcUserInfo._noticeBoardList = inMsg2._BBSNoticeInfoList;
                                
                                // 배너 정보
                                AcUserInfo._bannerList = inMsg2._BBSBannerInfoList;

                                // 챔피언쉽 정보
                                AcUserInfo._tOTChampionShipState = inMsg2._tOTChampionShipState;
                                if (inMsg2._tOTChampionShipState == eTOTChampionShipState.STATE_START)
                                {
                                    AcUserInfo._tOTChampionShipEndDateTime = inMsg2._tOTChampionShipEndDateTime;
                                    AcUserInfo._tOTChampionShipGameModeDataId = inMsg2._tOTChampionShipGameModeDataId;

                                    // 유저 챔피언쉽 랭크 정보 요청
                                    SendPacket_req_simpleTOTChampionShipUserList();
                                }

                                // 재연결일수도 있으므로 방정보는 항상 비움
                                AcUserInfo._enterRoomDic.Clear();

                                //--------------------------------------------------------------------
                                // 5. 서버 시간 요청
                                Debug.Log("서버 시간 요청");
                                SendPacket_req_serverDatetime();

                                //--------------------------------------------------------------------
                                // 6. 유저 정보 요청
                                Debug.Log("유저 정보 요청");
                                SendPacket_req_userInfo(userId, (inMsg3) =>
                                {
                                    if (inMsg3 == eGameResult.RESULT_OK)
                                    {
                                        Debug.Log("유저 정보 요청 성공");

                                        //Debug.Log(AcUserInfo._netData_user._payTMLastUseRewardDataId);

                                        AcUserInfo._netData_user._payTMLastUseRewardDataId = ShopPayTMRewardTable.Instance.GetValidIndex(AcUserInfo._netData_user._payTMLastUseRewardDataId);

                                        //Debug.Log(AcUserInfo._netData_user._payTMLastUseRewardDataId);

                                        //Debug.Log(ShopPayTMRewardTable.Instance.GetNextValidIndex(AcUserInfo._netData_user._payTMLastUseRewardDataId));

                                        //Debug.Log(AcUserInfo._netData_user._payTMLastUseRewardDataId);

                                        

                                        if (fun_res != null)
                                        {
                                            //if (inMsg2._result == eGameResult.RESULT_LOGIN_USERPROFILEREGISTER)
                                            //{
                                            fun_res(inMsg2._result);
                                            //}
                                            //else
                                            //{
                                            //    fun_res(inMsg._result);
                                            //}
                                        }
                                    }
                                    else
                                    {
                                        Debug.Log("유저 정보 요청 실패: " + inMsg3);
                                        if (fun_res != null)
                                            fun_res(inMsg3);
                                    }
                                });
                            }
                            else
                            {
                                Debug.Log("게임서버 로그인 실패:" + inMsg2._result);
                                DisconnectLoginServer();
                                DisconnectGameServer();
                                if (fun_res != null)
                                    fun_res(inMsg2._result);
                                return;
                            }
                        });
                    });
                }
                else
                {
                    Debug.Log("로그인서버 로그인 실패:" + inMsg._result);

                    if (fun_res != null)
                        fun_res(inMsg._result);
                }
            });
        });
    }

    #endregion

    #region 로그아웃 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 로그아웃 요청
    public virtual void SendPacket_Logout(Action<eGameResult> fun_res = null)
    {
        // 유저 옵션 정보 알림
        if (AcUserInfo._netData_user != null)
        {
            SendPacket_req_optionInfoSave(AcUserInfo._netData_user._userOptionInfo);
        }

        var reqLogout = new AcNetDataCS_reqLogout();
        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_Logout, reqLogout);

        AcUserInfo._TOTRankRefreshIndex = 0;
        AcUserInfo._chipRankRefreshIndex = 0;
        AcUserInfo._isLogin = false;
        AcUserInfo._friendList.Clear();
        AcUserInfo._friendRequestList.Clear();
        AcUserInfo._friendTalkDicList.Clear();

        //RegisterMessageHandler<AcNetDataSC_resLogout>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_Logout, (inMsg) =>
        //{
        //    AcUserInfo._TOTRankRefreshIndex = 0;
        //    AcUserInfo._chipRankRefreshIndex = 0;

        //    if (fun_res != null)
        //        fun_res(inMsg._result);
        //});
    }

    #endregion

    #region 재연결 정보 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 재연결 정보 요청
    public virtual void SendPacket_req_reconnectionInfo(Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqReconnectionInfo();

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_ReconnectionInfo, outMsg);

        RegisterMessageHandler<AcNetDataSC_resReconnectionInfo>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_ReconnectionInfo, (inMsg) =>
        {
            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._mainRoomIndex = inMsg._reconnectionInfo._mainRoomIndex;
                for (int i = 0; i < inMsg._reconnectionInfo._roomInfoList.Count; i++)
                {
                    AcUserInfo._enterRoomDic.Add(inMsg._reconnectionInfo._roomInfoList[i]._roomIndex, new AcEnterRoomInfo(inMsg._reconnectionInfo._roomInfoNumberList[i], inMsg._reconnectionInfo._roomInfoList[i]));
                }
            }

            fun_res(inMsg._result);
        });
    }

    #endregion

    #region 게임서버 변경 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_gameServerChange(string userId, eAccountLinkType accountLinkType, string nickName, byte OS, string OSVersion, string deviceCode, string mACAddress, string systemLanguageType, Action<eGameResult> fun_res = null)
    {
        var reqGameServerChange = new AcNetDataCS_reqGameServerChange();
        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_GameServerChange, reqGameServerChange);

        Action func = () =>
        {
            SendPacket_login(userId, accountLinkType, nickName, OS, OSVersion, deviceCode, mACAddress, systemLanguageType, fun_res);
        };

        GameServerChangeCallBack = func;
    }

    #endregion

    #region 랭크서버 로그인
    ////------------------------------------------------------------------------------------------------------------------------------------------------------
    //// 랭크서버 로그인
    //public virtual void SendPacket_req_rankLogin(string userId, byte OS, string deviceCode, string macAddress, Action<eGameResult> fun_res = null)
    //{
    //    ConnectRankServer(AcNetworkBase._remoteIP_Rank, AcNetworkBase._listenPort_Rank, conRankRes =>
    //    {
    //        if (conRankRes != 2)
    //            return;

    //        Debug.Log("랭크서버 접속 성공");

    //        var reqLogin = new AcNetDataCS_reqLogin();
    //        reqLogin._userId = userId;
    //        reqLogin._OS = OS;
    //        reqLogin._deviceCode = deviceCode;
    //        reqLogin._clientVersion = AcNetworkBase._clientVersion;
    //        reqLogin._macAddress = macAddress;
    //        SendMessage(ePeerType.RankPeer, AcNetMessageHeaders.CSReq_Login, reqLogin);

    //        //--------------------------------------------------------------------
    //        // 4. 랭크서버 로그인	
    //        SendMessage(ePeerType.RankPeer, AcNetMessageHeaders.CSReq_Login, reqLogin);
    //        RegisterMessageHandler<AcNetDataSC_resLogin>(ePeerType.RankPeer, AcNetMessageHeaders.SCRes_Login, (inMsg) =>
    //        {
    //            if (inMsg._result == eGameResult.RESULT_OK)
    //            {
    //                Debug.Log("랭크서버 로그인 성공");
    //            }
    //            else
    //            {
    //                Debug.Log("랭크서버 로그인 실패");
    //            }
    //        });
    //    });

    //}

    #endregion

    #region 계정생성 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_account(string userId, eAccountLinkType accountLinkType, string nickName, byte OS, string systemLanguageType, string deviceCode, string macAddress, Action<eGameResult> fun_res = null)
    {
        //--------------------------------------------------------------------
        // 1. 로그인서버 연결			
        ConnectLoginServer(res =>
        {
            if (res != 2)
                return;

            Debug.Log("로그인서버 접속 성공");

            //--------------------------------------------------------------------
            // 2. 로그인서버 계정 생성 요청       
            var outMsg = new AcNetDataCS_reqAccount();
            outMsg._userId = userId;
            outMsg._accountLinkType = accountLinkType;
            outMsg._nickName = nickName;
            outMsg._OS = OS;
            outMsg._systemLanguageType = systemLanguageType;
            outMsg._deviceCode = deviceCode;
            outMsg._macAddress = macAddress;

            SendMessage(ePeerType.LoginPeer, AcNetMessageHeaders.CSReq_Account, outMsg);

            RegisterMessageHandler<AcNetDataSC_resAccount>(ePeerType.LoginPeer, AcNetMessageHeaders.SCRes_Account, (inMsg) =>
            {
                if (inMsg._result == eGameResult.RESULT_OK)
                {
                    Debug.Log("계정 생성 성공");
                }
                else
                {
                    Debug.Log("계정 생성 실패:" + inMsg._result);
                    return;
                }

                if (fun_res != null)
                    fun_res(inMsg._result);
            });
        });
    }

    #endregion

    #region 유저 프로필 등록 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 유저 프로필 등록 요청
    public virtual void SendPacket_req_userProfileRegister(string nickName, int avatarDataId, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqUserProfileRegister();
        outMsg._nickName = nickName;
        outMsg._avatarDataId = avatarDataId;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_UserProfileRegister, outMsg);

        RegisterMessageHandler<AcNetDataSC_resUserProfileRegister>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_UserProfileRegister, (inMsg) =>
        {
            Debug.Log("[Network] 유저 프로필 등록 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._netData_user._nickName = inMsg._nickName;
                AcUserInfo._netData_user._avatarDataId = inMsg._avatarDataId;
                AcUserInfo._netData_user._pictureDataId = inMsg._pictureDataId;
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 유저 자동 정보 저장 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 유저 자동 정보 저장 요청
    public virtual void SendPacket_req_setAutoInfoSave(AcNetData_SetAutoInfo setAutoInfo, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqSetAutoInfoSave();
        outMsg._setAutoInfo = setAutoInfo;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_SetAutoInfoSave, outMsg);

        RegisterMessageHandler<AcNetDataSC_resSetAutoInfoSave>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_SetAutoInfoSave, (inMsg) =>
        {
            Debug.Log("[Network] 유저 자동 정보 저장 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                for (int i = 0; i < AcUserInfo._netData_user._setAutoInfoList.Count; i++)
                {
                    if (AcUserInfo._netData_user._setAutoInfoList[i]._uId == inMsg._setAutoInfo._uId)
                    {
                        AcUserInfo._netData_user._setAutoInfoList[i] = inMsg._setAutoInfo;
                        break;
                    }
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 유저 AutoSetting 선택 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 유저 AutoSetting 선택 요청
    public virtual void SendPacket_req_SetAutoSettingSelect(int slotNumber, int settingNumber)
    {
        var outMsg = new AcNetDataCS_reqSetAutoSettingSelect();
        outMsg._number = slotNumber;
        outMsg._settingNumber = settingNumber;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_SetAutoSettingSelect, outMsg);

        for (int i = 0; i < AcUserInfo._netData_user._multiSlotInfoList.Count; i++)
        {
            if (AcUserInfo._netData_user._multiSlotInfoList[i]._number == slotNumber)
            {
                AcUserInfo._netData_user._multiSlotInfoList[i]._autoSettingSelectNumber = settingNumber;
            }
        }
    }

    #endregion

    #region 유저 자동 정보 저장 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 유저 자동 정보 저장 요청
    public virtual void SendPacket_req_setAutoInfoReset(int settingNumber, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqSetAutoSettingReset();
        outMsg._settingNumber = settingNumber;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_SetAutoSettingReset, outMsg);

        RegisterMessageHandler<AcNetDataSC_resSetAutoSettingReset>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_SetAutoSettingReset, (inMsg) =>
        {
            Debug.Log("[Network] 유저 자동 정보 리셋 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                for (int i = 0; i < AcUserInfo._netData_user._setAutoInfoList.Count; i++)
                {
                    if (AcUserInfo._netData_user._setAutoInfoList[i]._uId == inMsg._setAutoInfo._uId)
                    {
                        AcUserInfo._netData_user._setAutoInfoList[i] = inMsg._setAutoInfo;
                        break;
                    }
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 유저 옵션 정보 저장 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 유저 옵션 정보 저장 요청
    public virtual void SendPacket_req_optionInfoSave(AcNetData_UserOptionInfo optionInfo, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqUserOptionInfoSave();
        optionInfo._pushToeken = AcUserInfo._pushToken;
        outMsg._optionInfo = optionInfo;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_UserOptionInfoSave, outMsg);
        //SendMessage(ePeerType.RankPeer, AcNetMessageHeaders.CSReq_UserOptionInfoSave, outMsg);
    }

    #endregion

    #region 유저 초상화 변경 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 유저 초상화 변경 요청
    public virtual void SendPacket_req_pictureChange(int pictureDataId, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqUserPictureChange();
        outMsg._pictureDataId = pictureDataId;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_UserPictureChange, outMsg);
        RegisterMessageHandler<AcNetDataSC_resUserPictureChange>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_UserPictureChange, (inMsg) =>
        {
            Debug.Log("[Network] 유저 초상화 변경 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._netData_user._pictureDataId = inMsg._pictureDataId;
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 유저 
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 본인 정보 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 본인 유저 정보 요청
    public virtual void SendPacket_req_userInfo(string userId, Action<eGameResult> fun_res = null)
    {
        var userInfo = new AcNetDataCS_reqUserInfo();
        userInfo._userId = userId;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_UserInfo, userInfo);

        RegisterMessageHandler<AcNetDataSC_resUserInfo>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_UserInfo, (inMsg) =>
        {
            Debug.Log("[Network] 유저 정보 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._netData_user = inMsg._userInfo;
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 계정 연결 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 계정 연결 요청
    public virtual void SendPacket_req_accountLink(string linkUserId, string nickName, eAccountLinkType accountLinkType, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqAccountLink();
        outMsg._userId = AcUserInfo._netData_user._userId;
        outMsg._linkUserId = linkUserId;
        outMsg._nickName = nickName;
        outMsg._accountLinkType = accountLinkType;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_AccountLink, outMsg);

        RegisterMessageHandler<AcNetDataSC_resAccountLink>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_AccountLink, (inMsg) =>
        {
            Debug.Log("[Network] 계정 인증 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._netData_user._userId = inMsg._linkUserId;
                AcUserInfo._netData_user._nickName = inMsg._nickName;
                AcUserInfo._netData_user._accountLinkType = accountLinkType;
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 유저 프로필 정보 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 유저 프로필 정보 요청
    public virtual void SendPacket_req_userProfileInfo(long targetUserUId, Action<eGameResult, AcNetData_UserProfileInfo> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqUserProfileInfo();
        outMsg._targetUserUId = targetUserUId;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_UserProfileInfo, outMsg);

        RegisterMessageHandler<AcNetDataSC_resUserProfileInfo>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_UserProfileInfo, (inMsg) =>
        {
            Debug.Log("[Network] 유저 프로필 정보 응답: " + inMsg._result);

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._userProfileInfo);

        });
    }

    #endregion

    #region 유저 데일리 보상 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 유저 데일리 보상 요청
    //public virtual void SendPacket_req_userDailyReward(Action<eGameResult, long> fun_res = null)
    //{
    //    var outMsg = new AcNetDataCS_reqUserDailyReward();
    //    SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_UserDailyReward, outMsg);

    //    RegisterMessageHandler<AcNetDataSC_resUserDailyReward>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_UserDailyReward, (inMsg) =>
    //    {
    //        Debug.Log("[Network] 유저 데일리 보상 요청 응답: " + inMsg._result);

    //        if (inMsg._result == eGameResult.RESULT_OK)
    //        {
    //            AcUserInfo._netData_user._dailyRewardDate = inMsg._rewardReceiveDate;
    //        }

    //        if (fun_res != null)
    //            fun_res(inMsg._result, inMsg._rewardChip);
    //    });
    //}

    #endregion

    #region 로비에 있다고 알림
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 로비에 있다고 알림
    public virtual void SendPacket_notify_userInLobby()
    {
        var outMsg = new AcNetDataCS_notifyUserInLobby();
        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSNotify_UserInLobby, outMsg);
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 금고
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 금고 예금 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_safeDeposit(int safeSlotNumber, long depositChip, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqSafeDeposit();
        outMsg._safeSlotNumber = safeSlotNumber;
        outMsg._depositChip = depositChip;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_SafeDeposit, outMsg);

        RegisterMessageHandler<AcNetDataSC_resSafeDeposit>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_SafeDeposit, (inMsg) =>
        {
            Debug.Log("[Network] 금고 예금 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                // 금고 정보 업데이트
                AcUserInfo._netData_user._safeInfoList[0] = inMsg._mainSafeInfo;    // 메인
                for (int i = 1; i < AcUserInfo._netData_user._safeInfoList.Count; i++)
                {
                    if (AcUserInfo._netData_user._safeInfoList[i]._number == inMsg._changeSafeInfo._number)
                    {
                        AcUserInfo._netData_user._safeInfoList[i] = inMsg._changeSafeInfo;
                        break;
                    }
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 금고 출금 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_safeWithdraw(int safeSlotNumber, long withdrawChip, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqSafeWithdraw();
        outMsg._safeSlotNumber = safeSlotNumber;
        outMsg._withdrawChip = withdrawChip;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_SafeWithdraw, outMsg);

        RegisterMessageHandler<AcNetDataSC_resSafeWithdraw>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_SafeWithdraw, (inMsg) =>
        {
            Debug.Log("[Network] 아이템 출금 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                // 금고 정보 업데이트
                AcUserInfo._netData_user._safeInfoList[0] = inMsg._mainSafeInfo;    // 메인
                for (int i = 1; i < AcUserInfo._netData_user._safeInfoList.Count; i++)
                {
                    if (AcUserInfo._netData_user._safeInfoList[i]._number == inMsg._changeSafeInfo._number)
                    {
                        AcUserInfo._netData_user._safeInfoList[i] = inMsg._changeSafeInfo;
                        break;
                    }
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 금고 이전과 같은 칩 Buy In 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_safeBuyInSameChipBefore(int safeSlotNumber, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqSafeBuyInSameChipBefore();
        outMsg._safeSlotNumber = safeSlotNumber;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_SafeBuyInSameChipBefore, outMsg);

        RegisterMessageHandler<AcNetDataSC_resSafeBuyInSameChipBefore>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_SafeBuyInSameChipBefore, (inMsg) =>
        {
            Debug.Log("[Network] 금고 이전과 같은 칩 Buy In 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                // 금고 정보 업데이트
                AcUserInfo._netData_user._safeInfoList[0] = inMsg._mainSafeInfo;    // 메인
                for (int i = 1; i < AcUserInfo._netData_user._safeInfoList.Count; i++)
                {
                    if (AcUserInfo._netData_user._safeInfoList[i]._number == inMsg._changeSafeInfo._number)
                    {
                        AcUserInfo._netData_user._safeInfoList[i] = inMsg._changeSafeInfo;
                        break;
                    }
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 아이템
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 인벤토리 정보 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 인벤토리 정보 요청
    public virtual void SendPacket_req_inventoryInfo(Action<eGameResult> fun_res = null)
    {
        var inventoryInfo = new AcNetDataCS_reqInventoryInfo();

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_InventoryInfo, inventoryInfo);

        RegisterMessageHandler<AcNetDataSC_resInventoryInfo>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_InventoryInfo, (inMsg) =>
        {
            Debug.Log("[Network] 인벤토리 정보 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._netData_inventory = inMsg._inventoryInfo;
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 아이템 장착 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 인벤토리 정보 요청
    public virtual void SendPacket_req_itemEquip(Dictionary<eItemEquipType, List<string>> itemEquipDic, Action<eGameResult> fun_res = null)
    {
        var ItemEquip = new AcNetDataCS_reqItemEquip();
        ItemEquip._itemEquipDic = itemEquipDic;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_ItemEquip, ItemEquip);

        RegisterMessageHandler<AcNetDataSC_resItemEquip>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_ItemEquip, (inMsg) =>
        {
            Debug.Log("[Network] 아이템 장착 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                // 아이템 장착 수정
                if (AcUserInfo._netData_inventory != null)
                {
                    AcUserInfo._netData_inventory._itemEquipInfo = inMsg._itemEquipInfo;
                }
            }


            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 아이템 장착 해제 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 인벤토리 정보 요청
    public virtual void SendPacket_req_itemUnEquip(int slotNumber, eItemEquipType itemEquipType, Action<eGameResult, eItemEquipType, int> fun_res = null)
    {
        var ItemEquip = new AcNetDataCS_reqItemUnEquip();
        ItemEquip._itemEquipType = itemEquipType;
        ItemEquip._slotNumber = slotNumber;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_ItemUnEquip, ItemEquip);

        RegisterMessageHandler<AcNetDataSC_resItemUnEquip>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_ItemUnEquip, (inMsg) =>
        {
            Debug.Log("[Network] 아이템 장착 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                // 아이템 장착 수정
                if (AcUserInfo._netData_inventory != null)
                {
                    var itemEquipInfo = AcUserInfo._netData_inventory._itemEquipInfo;
                    if (itemEquipInfo._itemEquipDic.ContainsKey(inMsg._itemEquipType) == true)
                    {
                        var itemEquipSlotList = itemEquipInfo._itemEquipDic[inMsg._itemEquipType];
                        if (itemEquipSlotList.Count >= inMsg._slotNumber)
                        {
                            itemEquipSlotList[inMsg._slotNumber] = "";
                        }
                    }
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._itemEquipType, inMsg._slotNumber);
        });
    }

    #endregion

    #region 아이템 판매 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 인벤토리 정보 요청
    // 코스튬만 itemUID에 넣고 나머지는 다 itemDataId 사용
    public virtual void SendPacket_req_itemSell(string itemUId, int itemDataId, long count, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqItemSell();
        outMsg._itemUId = itemUId;
        outMsg._itemDataId = itemDataId;
        outMsg._count = count;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_ItemSell, outMsg);

        RegisterMessageHandler<AcNetDataSC_resItemSell>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_ItemSell, (inMsg) =>
        {
            Debug.Log("[Network] 아이템 판매 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                // 아이템 인벤토리 수정
                if (AcUserInfo._netData_inventory != null)
                {
                    for (int i = 0; i < inMsg._itemChangeInfoList.Count; i++)
                    {
                        var item = AcUserInfo._netData_inventory._itemList.Where(data => data._uId == inMsg._itemChangeInfoList[i]._itemUId).FirstOrDefault();

                        if (item == null && inMsg._itemChangeInfoList[i]._count != 0)
                        {
                            item = new AcNetData_ItemInfo();
                            item._uId = inMsg._itemChangeInfoList[i]._itemUId;
                            item._itemDataId = inMsg._itemChangeInfoList[i]._itemDataId;
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            item._timeLimitOn = inMsg._itemChangeInfoList[i]._timeLimitOn;
                            item._timeLimitEndDate = inMsg._itemChangeInfoList[i]._timeLimitEndDate;

                            AcUserInfo._netData_inventory._itemList.Add(item);
                            PlayerDataManager.Instance.AddNewItem(item._uId);
                        }
                        else if (item != null && inMsg._itemChangeInfoList[i]._count == 0)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            AcUserInfo._netData_inventory._itemList.Remove(item);
                            PlayerDataManager.Instance.RemoveNewItem(item._uId);
                        }
                        else if (item != null)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                        }
                    }
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 아이템 금고 사용 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 아이템 금고 사용 요청
    public virtual void SendPacket_req_itemSafeUse(int itemDataId, long count, int safeSlotNumber, long safeChip, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqItemSafeUse();
        outMsg._itemDataId = itemDataId;
        outMsg._count = count;
        outMsg._safeSlotNumber = safeSlotNumber;
        outMsg._safeChip = safeChip;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_ItemSafeUse, outMsg);

        RegisterMessageHandler<AcNetDataSC_resItemSafeUse>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_ItemSafeUse, (inMsg) =>
        {
            Debug.Log("[Network] 아이템 금고 사용 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                // 금고 정보 업데이트
                AcUserInfo._netData_user._safeInfoList[0] = inMsg._mainSafeInfo;    // 메인
                for (int i = 1; i < AcUserInfo._netData_user._safeInfoList.Count; i++)
                {
                    if (AcUserInfo._netData_user._safeInfoList[i]._number == inMsg._changeSafeInfo._number)
                    {
                        AcUserInfo._netData_user._safeInfoList[i] = inMsg._changeSafeInfo;
                        break;
                    }
                }

                // 아이템 인벤토리 수정
                if (AcUserInfo._netData_inventory != null)
                {
                    for (int i = 0; i < inMsg._itemChangeInfoList.Count; i++)
                    {
                        var item = AcUserInfo._netData_inventory._itemList.Where(data => data._uId == inMsg._itemChangeInfoList[i]._itemUId).FirstOrDefault();

                        if (item == null && inMsg._itemChangeInfoList[i]._count != 0)
                        {
                            item = new AcNetData_ItemInfo();
                            item._uId = inMsg._itemChangeInfoList[i]._itemUId;
                            item._itemDataId = inMsg._itemChangeInfoList[i]._itemDataId;
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            item._timeLimitOn = inMsg._itemChangeInfoList[i]._timeLimitOn;
                            item._timeLimitEndDate = inMsg._itemChangeInfoList[i]._timeLimitEndDate;

                            AcUserInfo._netData_inventory._itemList.Add(item);
                            PlayerDataManager.Instance.AddNewItem(item._uId);
                        }
                        else if (item != null && inMsg._itemChangeInfoList[i]._count == 0)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            AcUserInfo._netData_inventory._itemList.Remove(item);
                            PlayerDataManager.Instance.RemoveNewItem(item._uId);
                        }
                        else if (item != null)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                        }
                    }
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 아이템 사용 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 아이템 사용 요청
    public virtual void SendPacket_req_itemUse(string itemUId, Action<eGameResult, List<AcNetData_ItemAcquireInfo>> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqItemUse();
        outMsg._itemUId = itemUId;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_ItemUse, outMsg);

        RegisterMessageHandler<AcNetDataSC_resItemUse>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_ItemUse, (inMsg) =>
        {
            Debug.Log("[Network] 아이템 사용 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                // 아이템 인벤토리 수정
                if (AcUserInfo._netData_inventory != null)
                {
                    for (int i = 0; i < inMsg._itemChangeInfoList.Count; i++)
                    {
                        var item = AcUserInfo._netData_inventory._itemList.Where(data => data._uId == inMsg._itemChangeInfoList[i]._itemUId).FirstOrDefault();

                        if (item == null && inMsg._itemChangeInfoList[i]._count != 0)
                        {
                            item = new AcNetData_ItemInfo();
                            item._uId = inMsg._itemChangeInfoList[i]._itemUId;
                            item._itemDataId = inMsg._itemChangeInfoList[i]._itemDataId;
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            item._timeLimitOn = inMsg._itemChangeInfoList[i]._timeLimitOn;
                            item._timeLimitEndDate = inMsg._itemChangeInfoList[i]._timeLimitEndDate;

                            AcUserInfo._netData_inventory._itemList.Add(item);
                            PlayerDataManager.Instance.AddNewItem(item._uId);
                        }
                        else if (item != null && inMsg._itemChangeInfoList[i]._count == 0)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            AcUserInfo._netData_inventory._itemList.Remove(item);
                            PlayerDataManager.Instance.RemoveNewItem(item._uId);
                        }
                        else if (item != null)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                        }
                    }
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._itemAcquireInfoList);
        });
    }

    #endregion

    #region 아이템 조각 제작 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 아이템 조각 제작 요청
    public virtual void SendPacket_req_itemPieceCraft(int itemDataId, long craftCount, Action<eGameResult, List<AcNetData_ItemAcquireInfo>> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqItemPieceCraft();
        outMsg._itemDataId = itemDataId;
        outMsg._craftCount = craftCount;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_ItemPieceCraft, outMsg);

        RegisterMessageHandler<AcNetDataSC_resItemPieceCraft>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_ItemPieceCraft, (inMsg) =>
        {
            Debug.Log("[Network] 아이템 조각 제작 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                // 아이템 인벤토리 수정
                if (AcUserInfo._netData_inventory != null)
                {
                    for (int i = 0; i < inMsg._itemChangeInfoList.Count; i++)
                    {
                        var item = AcUserInfo._netData_inventory._itemList.Where(data => data._uId == inMsg._itemChangeInfoList[i]._itemUId).FirstOrDefault();

                        if (item == null && inMsg._itemChangeInfoList[i]._count != 0)
                        {
                            item = new AcNetData_ItemInfo();
                            item._uId = inMsg._itemChangeInfoList[i]._itemUId;
                            item._itemDataId = inMsg._itemChangeInfoList[i]._itemDataId;
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            item._timeLimitOn = inMsg._itemChangeInfoList[i]._timeLimitOn;
                            item._timeLimitEndDate = inMsg._itemChangeInfoList[i]._timeLimitEndDate;

                            AcUserInfo._netData_inventory._itemList.Add(item);
                            PlayerDataManager.Instance.AddNewItem(item._uId);
                        }
                        else if (item != null && inMsg._itemChangeInfoList[i]._count == 0)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            AcUserInfo._netData_inventory._itemList.Remove(item);
                            PlayerDataManager.Instance.RemoveNewItem(item._uId);
                        }
                        else if (item != null)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                        }
                    }
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._itemAcquireInfoList);
        });
    }

    #endregion

    #region 아이템 멀티OR오토 사용 티켓 사용 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 아이템 멀티OR오토 사용 티켓 사용 요청
    public virtual void SendPacket_req_itemMultiAutoUseTicketUse(int itemDataId, int multiSlotNumber, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqItemMultiAutoUseTicketUse();
        outMsg._itemDataId = itemDataId;
        outMsg._multiSlotNumber = multiSlotNumber;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_ItemMultiAutoUseTicketUse, outMsg);

        RegisterMessageHandler<AcNetDataSC_resItemMultiAutoUseTicketUse>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_ItemMultiAutoUseTicketUse, (inMsg) =>
        {
            Debug.Log("[Network] 아이템 멀티OR오토 사용 티켓 사용 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                // 아이템 인벤토리 수정
                if (AcUserInfo._netData_inventory != null)
                {
                    for (int i = 0; i < inMsg._itemChangeInfoList.Count; i++)
                    {
                        var item = AcUserInfo._netData_inventory._itemList.Where(data => data._uId == inMsg._itemChangeInfoList[i]._itemUId).FirstOrDefault();

                        if (item == null && inMsg._itemChangeInfoList[i]._count != 0)
                        {
                            item = new AcNetData_ItemInfo();
                            item._uId = inMsg._itemChangeInfoList[i]._itemUId;
                            item._itemDataId = inMsg._itemChangeInfoList[i]._itemDataId;
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            item._timeLimitOn = inMsg._itemChangeInfoList[i]._timeLimitOn;
                            item._timeLimitEndDate = inMsg._itemChangeInfoList[i]._timeLimitEndDate;

                            AcUserInfo._netData_inventory._itemList.Add(item);
                            PlayerDataManager.Instance.AddNewItem(item._uId);
                        }
                        else if (item != null && inMsg._itemChangeInfoList[i]._count == 0)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            AcUserInfo._netData_inventory._itemList.Remove(item);
                            PlayerDataManager.Instance.RemoveNewItem(item._uId);
                        }
                        else if (item != null)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                        }
                    }
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 상점
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 상점 아이템 구매 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 상점 아이템 구매 요청
    public virtual void SendPacket_req_shopItemBuy(int shopDataId, Action<eGameResult, List<AcNetData_ItemAcquireInfo>> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqShopItemBuy();
        outMsg._shopDataId = shopDataId;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_ShopItemBuy, outMsg);

        RegisterMessageHandler<AcNetDataSC_resShopItemBuy>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_ShopItemBuy, (inMsg) =>
        {
            Debug.Log("[Network] 상점 아이템 구매 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                // 아이템 인벤토리 수정
                if (AcUserInfo._netData_inventory != null)
                {
                    for (int i = 0; i < inMsg._itemChangeInfoList.Count; i++)
                    {
                        var item = AcUserInfo._netData_inventory._itemList.Where(data => data._uId == inMsg._itemChangeInfoList[i]._itemUId).FirstOrDefault();

                        if (item == null && inMsg._itemChangeInfoList[i]._count != 0)
                        {
                            item = new AcNetData_ItemInfo();
                            item._uId = inMsg._itemChangeInfoList[i]._itemUId;
                            item._itemDataId = inMsg._itemChangeInfoList[i]._itemDataId;
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            item._timeLimitOn = inMsg._itemChangeInfoList[i]._timeLimitOn;
                            item._timeLimitEndDate = inMsg._itemChangeInfoList[i]._timeLimitEndDate;

                            AcUserInfo._netData_inventory._itemList.Add(item);
                            PlayerDataManager.Instance.AddNewItem(item._uId);
                        }
                        else if (item != null && inMsg._itemChangeInfoList[i]._count == 0)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            AcUserInfo._netData_inventory._itemList.Remove(item);
                            PlayerDataManager.Instance.RemoveNewItem(item._uId);
                        }
                        else if (item != null)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                        }
                    }
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._itemAcquireInfoList);
        });
    }

    #endregion

    #region 상점 가차 구매 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 상점 가차 구매 요청
    public virtual void SendPacket_req_shopGachaBuy(int shopGachaDataId, Action<eGameResult, List<AcNetData_ItemAcquireInfo>> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqShopGachaBuy();
        outMsg._shopGachaDataId = shopGachaDataId;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_ShopGachaBuy, outMsg);

        RegisterMessageHandler<AcNetDataSC_resShopItemBuy>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_ShopGachaBuy, (inMsg) =>
        {
            Debug.Log("[Network] 상점 가차 구매 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                // 아이템 인벤토리 수정
                if (AcUserInfo._netData_inventory != null)
                {
                    for (int i = 0; i < inMsg._itemChangeInfoList.Count; i++)
                    {
                        var item = AcUserInfo._netData_inventory._itemList.Where(data => data._uId == inMsg._itemChangeInfoList[i]._itemUId).FirstOrDefault();

                        if (item == null && inMsg._itemChangeInfoList[i]._count != 0)
                        {
                            item = new AcNetData_ItemInfo();
                            item._uId = inMsg._itemChangeInfoList[i]._itemUId;
                            item._itemDataId = inMsg._itemChangeInfoList[i]._itemDataId;
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            item._timeLimitOn = inMsg._itemChangeInfoList[i]._timeLimitOn;
                            item._timeLimitEndDate = inMsg._itemChangeInfoList[i]._timeLimitEndDate;

                            AcUserInfo._netData_inventory._itemList.Add(item);
                            PlayerDataManager.Instance.AddNewItem(item._uId);
                        }
                        else if (item != null && inMsg._itemChangeInfoList[i]._count == 0)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            AcUserInfo._netData_inventory._itemList.Remove(item);
                            PlayerDataManager.Instance.RemoveNewItem(item._uId);
                        }
                        else if (item != null)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                        }
                    }
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._itemAcquireInfoList);
        });
    }

    #endregion

    #region 유저 구매 제한 상품 정보 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 상점 아이템 구매 요청
    public virtual void SendPacket_req_shopLimitProductInfoList(Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqUserLimitProductInfoList();

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_UserLimitProductInfoList, outMsg);

        RegisterMessageHandler<AcNetDataSC_resUserLimitProductInfoList>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_UserLimitProductInfoList, (inMsg) =>
        {
            Debug.Log("[Network] 유저 구매 제한 상품 정보 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._userLimitProductInfoList = inMsg._userLimitProductInfoList;
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 우편
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 우체통 정보 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 우체통 정보 요청
    public virtual void SendPacket_req_postBoxInfo(Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqPostBoxInfo();

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_PostBoxInfo, outMsg);

        RegisterMessageHandler<AcNetDataSC_resPostBoxInfo>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_PostBoxInfo, (inMsg) =>
        {
            Debug.Log("[Network] 우체통 정보 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._netData_postbox = inMsg._postBoxInfo;
                AcUserInfo._netData_postbox._postList = AcUserInfo._netData_postbox._postList.OrderBy(data => data._regDate).ToList();
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 우편 아이템 획득 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 우편 아이템 획득 요청
    public virtual void SendPacket_req_postItemAcquire(string postUId, Action<eGameResult, List<AcNetData_ItemAcquireInfo>> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqPostItemAcquire();
        outMsg._postUId = postUId;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_PostItemAcquire, outMsg);

        RegisterMessageHandler<AcNetDataSC_resPostItemAcquire>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_PostItemAcquire, (inMsg) =>
        {
            Debug.Log("[Network] 우편 아이템 획득 응답: " + inMsg._result);

            // 우편 삭제
            AcUserInfo._netData_postbox._postList.RemoveAll(data => data._uId == inMsg._acquirePostUId);
            if (inMsg._result == eGameResult.RESULT_OK)
            {
                // 아이템 인벤토리 수정
                if (AcUserInfo._netData_inventory != null)
                {
                    for (int i = 0; i < inMsg._itemChangeInfoList.Count; i++)
                    {
                        var item = AcUserInfo._netData_inventory._itemList.Where(data => data._uId == inMsg._itemChangeInfoList[i]._itemUId).FirstOrDefault();

                        if (item == null && inMsg._itemChangeInfoList[i]._count != 0)
                        {
                            item = new AcNetData_ItemInfo();
                            item._uId = inMsg._itemChangeInfoList[i]._itemUId;
                            item._itemDataId = inMsg._itemChangeInfoList[i]._itemDataId;
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            item._timeLimitOn = inMsg._itemChangeInfoList[i]._timeLimitOn;
                            item._timeLimitEndDate = inMsg._itemChangeInfoList[i]._timeLimitEndDate;

                            AcUserInfo._netData_inventory._itemList.Add(item);
                            PlayerDataManager.Instance.AddNewItem(item._uId);
                        }
                        else if (item != null && inMsg._itemChangeInfoList[i]._count == 0)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            AcUserInfo._netData_inventory._itemList.Remove(item);
                            PlayerDataManager.Instance.RemoveNewItem(item._uId);
                        }
                        else if (item != null)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                        }
                    }
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._itemAcquireInfoList);
        });
    }

    #endregion

    #region 우편 삭제 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 우편 삭제 요청
    public virtual void SendPacket_req_postRemove(string postUId, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqPostRemove();
        outMsg._postUId = postUId;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_PostRemove, outMsg);

        RegisterMessageHandler<AcNetDataSC_resPostRemove>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_PostRemove, (inMsg) =>
        {
            Debug.Log("[Network] 우편 삭제 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                // 아이템 획득한 우편 삭제
                AcUserInfo._netData_postbox._postList.RemoveAll(data => data._uId == inMsg._postUId);
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 우편 읽음 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 우편 읽음 요청
    public virtual void SendPacket_req_postRead(string postUId, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqPostRead();
        outMsg._postUId = postUId;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_PostRead, outMsg);

        RegisterMessageHandler<AcNetDataSC_resPostRead>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_PostRead, (inMsg) =>
        {
            Debug.Log("[Network] 우편 읽음 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                // 아이템 읽음 표시
                for (int i = 0; i < AcUserInfo._netData_postbox._postList.Count; i++)
                {
                    if (AcUserInfo._netData_postbox._postList[i]._uId == inMsg._postUId)
                    {
                        AcUserInfo._netData_postbox._postList[i]._postRead = true;
                        break;
                    }
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 방정보
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 방 메인 선택 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 방 메인 선택 요청
    public virtual void SendPacket_req_roomMainSelect(long roomIndex, Action<eGameResult, long> fun_res = null)
    {       
        var outMsg = new AcNetDataCS_reqRoomMainSelect();
        outMsg._roomIndex = roomIndex;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_RoomMainSelect, outMsg);

        RegisterMessageHandler<AcNetDataSC_resRoomMainSelect>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_RoomMainSelect, (inMsg) =>
        {
            Debug.Log("[Network] 방 메인 선택 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._mainRoomIndex = inMsg._roomIndex;
            }

            if (fun_res != null)
                fun_res(inMsg._result, AcUserInfo._mainRoomIndex);
        });
    }

    #endregion

    #region 방 비밀방 생성 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 방 비밀방 생성 요청
    public virtual void SendPacket_req_roomPrivateCreate(int gameModeDataInfoId, bool isAutoBootChip, int gameRoomDataInfoId, int turnLimitSecond, int blindLimitCount, bool isPotLimit
                                                    , Action<eGameResult, long> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqCreatePrivateRoom();
        outMsg._gameModeDataInfoId = gameModeDataInfoId;
        outMsg._isAutoBootChip = isAutoBootChip;
        outMsg._gameRoomDataInfoId = gameRoomDataInfoId;
        outMsg._turnLimitSecond = turnLimitSecond;
        outMsg._blindLimitCount = blindLimitCount;
        outMsg._isPotLimit = isPotLimit;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_RoomPrivateCreate, outMsg);

        RegisterMessageHandler<AcNetDataSC_resCreatePrivateRoom>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_RoomPrivateCreate, (inMsg) =>
        {
            Debug.Log("[Network] 비밀 방 생성 요청 응답: " + inMsg._result);
            long enterRoomIndex = 0;

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                if (AcUserInfo._enterRoomDic.ContainsKey(inMsg._roomInfo._roomIndex) == false)
                {
                    AcUserInfo._enterRoomDic.Add(inMsg._roomInfo._roomIndex, new AcEnterRoomInfo(0, inMsg._roomInfo));
                }

                enterRoomIndex = inMsg._roomInfo._roomIndex;
            }

            if (fun_res != null)
                fun_res(inMsg._result, enterRoomIndex);
        });
    }

    #endregion

    #region 방 입장 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 방 입장 요청
    public virtual void SendPacket_req_roomEnter(long roomIndex, int multiGameOrder, long buyInChip, Action<eGameResult, long> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqEnterRoom();
        outMsg._roomIndex = roomIndex;
        outMsg._multiGameOrder = multiGameOrder;
        outMsg._buyInChip = buyInChip;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_RoomEnter, outMsg);

        RegisterMessageHandler<AcNetDataSC_resEnterRoom>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_RoomEnter, (inMsg) =>
        {
            Debug.Log("[Network] 방 입장 요청 응답: " + inMsg._result);
            long enterRoomIndex = 0;

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                if (AcUserInfo._enterRoomDic.ContainsKey(inMsg._roomInfo._roomIndex) == false)
                {
                    AcUserInfo._enterRoomDic.Add(inMsg._roomInfo._roomIndex, new AcEnterRoomInfo(inMsg._multiGameOrder, inMsg._roomInfo));
                    enterRoomIndex = inMsg._roomInfo._roomIndex;
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result, enterRoomIndex);
        });
    }

    #endregion

    #region 방 빠른입장 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 방 입장 요청
    public virtual void SendPacket_req_roomQuickEnter(int multiGameOrder, int gameModeDataInfoId, int gameDataId, long buyInChip, string ticketItemUId, Action<eGameResult, long, int> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqQuickEnterRoom();
        outMsg._multiGameOrder = multiGameOrder;
        outMsg._gameModeDataInfoId = gameModeDataInfoId;
        outMsg._gameDataId = gameDataId;
        outMsg._buyInBalance = buyInChip;
        outMsg._ticketItemUId = ticketItemUId;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_RoomQuickEnter, outMsg);

        RegisterMessageHandler<AcNetDataSC_resQuickEnterRoom>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_RoomQuickEnter, (inMsg) =>
        {
            Debug.Log("[Network] 방 빠른입장 요청 응답: " + inMsg._result);
            long enterRoomIndex = 0;

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                if (AcUserInfo._enterRoomDic.ContainsKey(inMsg._roomInfo._roomIndex) == false)
                {
                    AcUserInfo._enterRoomDic.Add(inMsg._roomInfo._roomIndex, new AcEnterRoomInfo(inMsg._multiGameOrder, inMsg._roomInfo));

                    enterRoomIndex = inMsg._roomInfo._roomIndex;
                }

                if (inMsg._recommendGameRoomDataId > 1)
                {
                    Debug.Log("방 빠른입장 추천 채널 있음: " + inMsg._recommendGameRoomDataId);
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result, enterRoomIndex, inMsg._recommendGameRoomDataId);
        });
    }

    #endregion

    #region 방 추천 입장 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 방 추천 입장 요청
    public virtual void SendPacket_req_roomRecommendEnter(int multiGameOrder, int gameModeDataId, int gameRoomDataId, Action<eGameResult, long> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqRecommendEnterRoom();
        outMsg._multiGameOrder = multiGameOrder;
        outMsg._gameModeDataId = gameModeDataId;
        outMsg._gameRoomDataId = gameRoomDataId;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_RoomRecommendEnter, outMsg);

        RegisterMessageHandler<AcNetDataSC_resRecommendEnterRoom>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_RoomRecommendEnter, (inMsg) =>
        {
            Debug.Log("[Network] 방 추천 입장 요청 응답: " + inMsg._result);
            long enterRoomIndex = 0;

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                // 있던 방 제거
                if (AcUserInfo._enterRoomDic.ContainsKey(inMsg._leaveRoomIndex) == true)
                {
                    AcUserInfo._enterRoomDic.Remove(inMsg._leaveRoomIndex);
                }

                // 입장
                if (AcUserInfo._enterRoomDic.ContainsKey(inMsg._roomInfo._roomIndex) == false)
                {
                    AcUserInfo._enterRoomDic.Add(inMsg._roomInfo._roomIndex, new AcEnterRoomInfo(inMsg._multiGameOrder, inMsg._roomInfo));

                    enterRoomIndex = inMsg._roomInfo._roomIndex;
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result, enterRoomIndex);
        });
    }

    #endregion

    #region 방 스위칭 입장 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 방 스위칭 입장 요청
    public virtual void SendPacket_req_roomSwitchingEnter(long roomIndex, bool gradeUpSwitching, Action<eGameResult> fun_middle_res = null, Action<eGameResult, long, int> fun_final_res = null)
    {
        var outMsg = new AcNetDataCS_reqSwitchingEnterRoom();
        outMsg._roomIndex = roomIndex;
        outMsg._gradeUpSwitching = gradeUpSwitching;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_RoomSwitchingEnter, outMsg);

        RegisterMessageHandler<AcNetDataSC_resSwitchingEnterRoomEnable>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_RoomSwitchingEnterEnable, (inMsg) =>
        {
            Debug.Log("[Network] 방 스위칭 입장 요청 가능 여부 응답: " + inMsg._result);
            fun_middle_res(inMsg._result);
        });

        RegisterMessageHandler<AcNetDataSC_resSwitchingEnterRoom>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_RoomSwitchingEnter, (inMsg) =>
        {
            Debug.Log("[Network] 방 스위칭 입장 요청 응답: " + inMsg._result);
            long enterRoomIndex = 0;

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                // 있던 방 제거
                if (AcUserInfo._enterRoomDic.ContainsKey(inMsg._leaveRoomIndex) == true)
                {
                    AcUserInfo._enterRoomDic.Remove(inMsg._leaveRoomIndex);
                }

                // 입장
                if (AcUserInfo._enterRoomDic.ContainsKey(inMsg._roomInfo._roomIndex) == false)
                {
                    AcUserInfo._enterRoomDic.Add(inMsg._roomInfo._roomIndex, new AcEnterRoomInfo(inMsg._multiGameOrder, inMsg._roomInfo));

                    enterRoomIndex = inMsg._roomInfo._roomIndex;
                }

                if (inMsg._recommendGameRoomDataId > 1)
                {
                    Debug.Log("방 빠른입장 추천 채널 있음: " + inMsg._recommendGameRoomDataId);
                }
            }

            if (fun_final_res != null)
                fun_final_res(inMsg._result, enterRoomIndex, inMsg._recommendGameRoomDataId);
        });
    }

    #endregion

    #region 방 나가기 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 방 나가기 요청
    public virtual void SendPacket_req_leaveRoom(long roomIndex, Action<eGameResult, long, long, long, long> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqLeaveRoom();
        outMsg._roomIndex = roomIndex;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_RoomLeave, outMsg);

        RegisterMessageHandler<AcNetDataSC_resLeaveRoom>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_RoomLeave, (inMsg) =>
        {
            Debug.Log("[Network] 게임 나가기 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                // 방 나가기 처리
                if (AcUserInfo._enterRoomDic.ContainsKey(inMsg._roomIndex) == true)
                {
                    AcUserInfo._enterRoomDic.Remove(inMsg._roomIndex);
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._roomIndex, inMsg._totalChangeBalance, inMsg._totalChangeLP, inMsg._totalChangeBuffLP);
        });
    }

    #endregion

    #region 방 리스트 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 게임 리스트 요청
    public virtual void SendPacket_req_roomList(eGameType gameType, Action<eGameResult, List<AcNetData_RoomSimpleInfo>> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqRoomList();
        outMsg._pageNumber = 0;
        outMsg._gameType = gameType;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_RoomList, outMsg);

        RegisterMessageHandler<AcNetDataSC_resRoomList>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_RoomList, (inMsg) =>
        {
            Debug.Log("[Network] 방 리스트 요청 응답: " + inMsg._result);

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._roomInfoList);
        });
    }

    #endregion

    #region 입장 가능 채널 정보 요청
    
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_enableEnterChannelInfo(int gameModeDataId, Action<eGameResult, int, List<AcNetData_EnableEnterChannelInfo>> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqEnableEnterChannelInfo();
        outMsg._gameModeDataId = gameModeDataId;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_EnableEnterChannelInfo, outMsg);

        RegisterMessageHandler<AcNetDataSC_resEnableEnterChannelInfo>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_EnableEnterChannelInfo, (inMsg) =>
        {
            Debug.Log("[Network] 입장 가능 채널 정보 요청: " + inMsg._result);

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._gameModeDataId, inMsg._enableEnterChannelInfoList);
        });
    }

    #endregion

    #region 입장 가능 상위 채널 정보 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_enableEnterHighGradeChannel(long roomIndex, Action<eGameResult, int, int> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqEnableEnterHighGradeChannel();
        outMsg._roomIndex = roomIndex;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_EnableEnterHighGradeChannel, outMsg);

        RegisterMessageHandler<AcNetDataSC_resEnableEnterHighGradeChannel>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_EnableEnterHighGradeChannel, (inMsg) =>
        {
            Debug.Log("[Network] 입장 가능 상위 채널 정보 요청: " + inMsg._result);

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._gameModeDataId, inMsg._gameDataId);
        });
    }

    #endregion

    #region 방 슬롯 착석 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 방 슬롯 착석 요청
    public virtual void SendPacket_req_RoomSlotAttend(long roomIndex, int attendSlotNumber, Action<eGameResult, long> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqAttendRoomSlot();
        outMsg._roomIndex = roomIndex;
        outMsg._attendSlotNumber = attendSlotNumber;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_RoomSlotAttend, outMsg);

        RegisterMessageHandler<AcNetDataSC_resAttendRoomSlot>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_RoomSlotAttend, (inMsg) =>
        {
            Debug.Log(string.Format("[Network] 방 슬롯 착석 요청 응답 RoomIndex:{0}, Result:{1}", inMsg._roomIndex, inMsg._result));

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._roomIndex);
        });
    }

    #endregion

    #region 방 슬롯 일어나기 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 방 슬롯 착석 요청
    public virtual void SendPacket_req_roomSlotStandUp(long roomIndex, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqStandUpRoomSlot();
        outMsg._roomIndex = roomIndex;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_RoomSlotStandUp, outMsg);

        RegisterMessageHandler<AcNetDataSC_resAttendRoomSlot>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_RoomSlotStandUp, (inMsg) =>
        {
            Debug.Log("[Network] 방 슬롯 일어나기 요청 응답: " + inMsg._result);

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 방 채팅 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 방 채팅 요청
    public virtual void SendPacket_req_roomTalk(long roomIndex, string talkStr, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqRoomTalk();
        outMsg._roomIndex = roomIndex;
        outMsg._talkStr = talkStr;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_RoomTalk, outMsg);
        RegisterMessageHandler<AcNetDataSC_resRoomTalk>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_RoomTalk, (inMsg) =>
        {
            Debug.Log(string.Format("[Network] 방 채팅 요청 응답 Result:{0}", inMsg._result));

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 방 비밀방 플레이 상태 변경 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 방 비밀방 플레이 상태 변경 요청
    public virtual void SendPacket_req_roomPrivatePlayStateChange(long roomIndex, ePrivateRoomPlayState privateRoomPlayState, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqRoomPrivatePlayStateChange();
        outMsg._roomIndex = roomIndex;
        outMsg._privateRoomPlayState = privateRoomPlayState;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_RoomPrivatePlayStateChange, outMsg);

        RegisterMessageHandler<AcNetDataSC_resRoomPrivatePlayStateChange>(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_RoomPrivatePlayStateChange, (inMsg) =>
        {
            Debug.Log("[Network] 비밀 방 플레이 상태 변경 요청 응답: " + inMsg._result);

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 인게임
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 배팅 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 배팅 요청
    public virtual void SendPacket_req_betting(long roomIndex, eBettingType bettingType, long balance, Action<eGameResult, long> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqBetting();
        outMsg._roomIndex = roomIndex;
        outMsg._bettingType = bettingType;
        outMsg._balance = balance;

        //Debug.Log(bettingType);
        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_Betting, outMsg);

        RegisterMessageHandler<AcNetDataSC_resBetting>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_Betting, (inMsg) =>
        {
            Debug.Log("[Network] 배팅요청 응답: " + inMsg._result);

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._roomIndex);
        });
    }

    #endregion

    #region 카드 보기 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 배팅 요청
    public virtual void SendPacket_req_cardSee(long roomIndex, Action<eGameResult, long> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqCardSee();
        outMsg._roomIndex = roomIndex;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_CardSee, outMsg);

        RegisterMessageHandler<AcNetDataSC_resCardSee>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_CardSee, (inMsg) =>
        {
            Debug.Log("[Network] 카드 보기 응답: " + inMsg._result);

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._roomIndex);
        });
    }

    #endregion

    #region 사이드 쇼 수락 여부 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 배팅 요청
    public virtual void SendPacket_req_sideShowAccept(long roomIndex, bool accept, Action<eGameResult, long> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqSideShowAccept();
        outMsg._roomIndex = roomIndex;
        outMsg._accept = accept;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_SideShowAccept, outMsg);

        RegisterMessageHandler<AcNetDataSC_resCardSee>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_SideShowAccept, (inMsg) =>
        {
            Debug.Log("[Network] 사이드 쇼 수락 여부 요청 응답: " + inMsg._result);

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._roomIndex);
        });
    }

    #endregion

    #region 올인 수락 여부 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 올인 수락 여부 요청
    public virtual void SendPacket_req_allInAccept(long roomIndex, bool accept, Action<eGameResult, long> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqAllInAccept();
        outMsg._roomIndex = roomIndex;
        outMsg._accept = accept;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_AllInAccept, outMsg);

        RegisterMessageHandler<AcNetDataSC_resCardSee>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_AllInAccept, (inMsg) =>
        {
            Debug.Log("[Network] 올인 수락 여부 요청 응답: " + inMsg._result);

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._roomIndex);
        });
    }

    #endregion

    #region 애니메이션 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 애니메이션 요청
    public virtual void SendPacket_req_animation(long roomIndex, int dstSlotNumber, int animationId, Action<eGameResult> fun_res = null)
    {
        Debug.Log(roomIndex);
        var outMsg = new AcNetDataCS_reqAnimation();
        outMsg._roomIndex = roomIndex;
        outMsg._animationId = animationId;
        outMsg._dstSlotNumber = dstSlotNumber; // 타겟 없으면 -1

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_Animation, outMsg);
        RegisterMessageHandler<AcNetDataSC_resAnimation>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_Animation, (inMsg) =>
        {
            Debug.Log("[Network] 애니메이션 요청 응답: " + inMsg._result);

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 딜러 팁 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 애니메이션 요청
    public virtual void SendPacket_req_dealerTip(long roomIndex, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqDealerTip();
        outMsg._roomIndex = roomIndex;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_DealerTip, outMsg);
        RegisterMessageHandler<AcNetDataSC_resDealerTip>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_DealerTip, (inMsg) =>
        {
            Debug.Log("[Network] 딜러 팁 요청 응답: " + inMsg._result);

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region Auto 저장 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // Auto 저장 요청
    public virtual void SendPacket_req_autoSave(int number, bool auto)
    {
        var outMsg = new AcNetDataCS_reqAutoInfoSave();
        outMsg._number = number;
        outMsg._auto = auto;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_AutoInfoSave, outMsg);

        for (int i = 0; i < AcUserInfo._netData_user._multiSlotInfoList.Count; i++)
        {
            if (AcUserInfo._netData_user._multiSlotInfoList[i]._number == number)
            {
                AcUserInfo._netData_user._multiSlotInfoList[i]._autoUse = auto;
            }
        }
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // High or Low
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    //#region High or Low 게임 플레이 요청
    
    ////------------------------------------------------------------------------------------------------------------------------------------------------------
    //public virtual void SendPacket_req_HighOrLowGamePlay(long bettingLuckyPoint, eHighOrLowSelectType selectType, Action<eGameResult, AcNetData_CardInfo, eGameResultType, long> fun_res = null)
    //{
    //    var outMsg = new AcNetDataCS_reqHighOrLowGamePlay();
    //    outMsg._bettingLuckyPoint = bettingLuckyPoint;
    //    outMsg._selectType = selectType;

    //    SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_HighOrLowGamePlay, outMsg);

    //    RegisterMessageHandler<AcNetDataSC_resHighOrLowGamePlay>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_HighOrLowGamePlay, (inMsg) =>
    //    {
    //        Debug.Log("[Network] High or Low 게임 플레이 요청 응답: " + inMsg._result);

    //        if (fun_res != null)
    //            fun_res(inMsg._result, inMsg._resultCardInfo, inMsg._gameResultType, inMsg._changeLuckyPoint);
    //    });
    //}

    //#endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 랭크
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region TOT 랭크 유저 리스트 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 랭크 유저 리스트 요청
    public virtual void SendPacket_req_rankUserList(Action<eGameResult> fun_res = null)
    {
        if (IsGameConnected == false)
        {
            fun_res(eGameResult.RESULT_FAIL);
        }

        var outMsg = new AcNetDataCS_reqRankUserList();
        outMsg._TOTRankRefreshIndex = AcUserInfo._TOTRankRefreshIndex;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_RankUserList, outMsg);

        RegisterMessageHandler<AcNetDataSC_resRankUserList>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_RankUserList, (inMsg) =>
        {
            //Debug.Log("[Network] 랭크 유저 리스트 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._rankUserList = inMsg._rankUserList;
                AcUserInfo._myRankUserInfo = inMsg._myRankUserInfo;
                AcUserInfo._TOTRankRefreshIndex = inMsg._TOTRankRefreshIndex;
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 리그 그룹 정보 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 리그 그룹 정보 요청
    public virtual void SendPacket_req_leagueGroupInfo(Action<eGameResult> fun_res = null)
    {
        if(IsGameConnected == false)
        {
            fun_res(eGameResult.RESULT_FAIL);
        }

        var outMsg = new AcNetDataCS_reqLeagueGroupInfo();

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_LeagueGroupInfo, outMsg);

        RegisterMessageHandler<AcNetDataSC_resLeagueGroupInfo>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_LeagueGroupInfo, (inMsg) =>
        {
            Debug.Log("[Network] 리그 그룹 정보 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._leagueGroupInfo = inMsg._leagueGroupInfo;
                AcUserInfo._leagueCalcRestSecond = inMsg._leagueCalcRestSecond;
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 심플 리그 그룹 정보 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 리그 그룹 정보 요청
    public virtual void SendPacket_req_simpleLeagueGroupInfo(Action<AcNetDataSC_resSimpleLeagueGroupInfo> fun_res = null)
    {
        if (IsGameConnected == false)
        {
            fun_res(new AcNetDataSC_resSimpleLeagueGroupInfo() { _result = eGameResult.RESULT_FAIL } );
        }

        var outMsg = new AcNetDataCS_reqSimpleLeagueGroupInfo();

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_SimpleLeagueGroupInfo, outMsg);

        RegisterMessageHandler<AcNetDataSC_resSimpleLeagueGroupInfo>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_SimpleLeagueGroupInfo, (inMsg) =>
        {
            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._simpleLeagueGroupInfo = inMsg._leagueGroupInfo;
            }

            if (fun_res != null)
                fun_res(inMsg);
        });
    }

    #endregion

    #region 리그보상 획득 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 리그보상 획득 요청
    public virtual void SendPacket_req_leagueRewardAcquire(Action<eGameResult, long, long, List<AcNetData_ItemAcquireInfo>> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqUserLeagueRewardAcquire();

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_UserLeagueRewardAcquire, outMsg);

        RegisterMessageHandler<AcNetDataSC_resUserLeagueRewardAcquire>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_UserLeagueRewardAcquire, (inMsg) =>
        {
            Debug.Log("[Network] 리그보상 획득 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                // 보상 받음 처리
                AcUserInfo._netData_user._leagueRewardInfo._receive = true;

                // 아이템 인벤토리 수정
                if (AcUserInfo._netData_inventory != null)
                {
                    for (int i = 0; i < inMsg._itemChangeInfoList.Count; i++)
                    {
                        var item = AcUserInfo._netData_inventory._itemList.Where(data => data._uId == inMsg._itemChangeInfoList[i]._itemUId).FirstOrDefault();

                        if (item == null && inMsg._itemChangeInfoList[i]._count != 0)
                        {
                            item = new AcNetData_ItemInfo();
                            item._uId = inMsg._itemChangeInfoList[i]._itemUId;
                            item._itemDataId = inMsg._itemChangeInfoList[i]._itemDataId;
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            item._timeLimitOn = inMsg._itemChangeInfoList[i]._timeLimitOn;
                            item._timeLimitEndDate = inMsg._itemChangeInfoList[i]._timeLimitEndDate;

                            AcUserInfo._netData_inventory._itemList.Add(item);
                            PlayerDataManager.Instance.AddNewItem(item._uId);
                        }
                        else if (item != null && inMsg._itemChangeInfoList[i]._count == 0)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            AcUserInfo._netData_inventory._itemList.Remove(item);
                            PlayerDataManager.Instance.RemoveNewItem(item._uId);
                        }
                        else if (item != null)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                        }
                    }
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._prizeChip, inMsg._luckyPoint, inMsg._itemAcquireInfoList);
        });
    }

    #endregion

    #region 칩 랭크 유저 리스트 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 칩 랭크 유저 리스트 요청
    public virtual void SendPacket_req_chipRankUserList(Action<eGameResult> fun_res = null)
    {
        if (IsGameConnected == false)
        {
            fun_res(eGameResult.RESULT_FAIL);
        }

        var outMsg = new AcNetDataCS_reqChipRankUserList();
        outMsg._chipRankRefreshIndex = AcUserInfo._chipRankRefreshIndex;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_ChipRankUserList, outMsg);

        RegisterMessageHandler<AcNetDataSC_resChipRankUserList>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_ChipRankUserList, (inMsg) =>
        {
            //Debug.Log("[Network] 칩 랭크 유저 리스트 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._chipRankRefreshIndex = inMsg._chipRankRefreshIndex;
                AcUserInfo._chipRankUserList = inMsg._rankUserList;
                AcUserInfo._myChipRankUserInfo = inMsg._myRankUserInfo;
            }
            else if(inMsg._result == eGameResult.RESULT_RANKNOTREFRESH)
            {
                // 랭크 갱신 안됨
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region TOT 챔피언쉽 유저 리스트 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // TOT 챔피언쉽 유저 리스트 요청
    public virtual void SendPacket_req_tOTChampionShipList(eTOTChampionShipGradeType tOTChampionShipType, Action<eGameResult> fun_res = null)
    {
        if (IsGameConnected == false)
        {
            fun_res(eGameResult.RESULT_FAIL);
        }

        var outMsg = new AcNetDataCS_reqTOTChampionShipUserList();
        outMsg._tOTChampionShipType = tOTChampionShipType;
        outMsg._tOTChampionShipRankRefreshIndex = AcUserInfo._tOTChampionShipRankRefreshIndex;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_TOTChampionShipUserList, outMsg);

        RegisterMessageHandler<AcNetDataSC_resTOTChampionShipUserList>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_TOTChampionShipUserList, (inMsg) =>
        {
            Debug.Log("[Network] TOT 챔피언쉽 정보 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._tOTchampionShipUserList = inMsg._userInfoList;
                AcUserInfo._myTOTChampionShipUserInfo = inMsg._myUserInfo;
                AcUserInfo._tOTChampionShipRankRefreshIndex = inMsg._tOTChampionShipRankRefreshIndex;
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 심플 TOT 챔피언쉽 유저 리스트 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 심플 TOT 챔피언쉽 유저 리스트 요청
    public virtual void SendPacket_req_simpleTOTChampionShipUserList(Action<eGameResult> fun_res = null)
    {
        if (IsGameConnected == false)
        {
            fun_res(eGameResult.RESULT_FAIL);
        }

        var outMsg = new AcNetDataCS_reqSimpleTOTChampionShipUserList();
        outMsg._tOTChampionShipRankRefreshIndex = AcUserInfo._tOTChampionShipSimpleRankRefreshIndex;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_SimpleTOTChampionShipUserList, outMsg);

        RegisterMessageHandler<AcNetDataSC_resSimpleTOTChampionShipUserList>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_SimpleTOTChampionShipUserList, (inMsg) =>
        {
            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._simpleTOTChampionShipUserList = inMsg._userInfoList;
                AcUserInfo._mySimpleTOTChampionShipUserInfo = inMsg._myUserInfo;
                AcUserInfo._tOTChampionShipSimpleRankRefreshIndex = inMsg._tOTChampionShipRankRefreshIndex;
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region TOT 랭크 보상 획득 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_tOTRankRewardAcquire(Action<eGameResult, List<AcNetData_ItemAcquireInfo>> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqUserTOTRankRewardAcquire();

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_UserTOTRankRewardAcquire, outMsg);

        RegisterMessageHandler<AcNetDataSC_resUserTOTRankRewardAcquire>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_UserTOTRankRewardAcquire, (inMsg) =>
        {
            Debug.Log("[Network] TOT 랭크 보상 획득 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                // 보상 받음 처리
                AcUserInfo._netData_user._tOTRankRewardInfo._receive = true;

                // 아이템 인벤토리 수정
                if (AcUserInfo._netData_inventory != null)
                {
                    for (int i = 0; i < inMsg._itemChangeInfoList.Count; i++)
                    {
                        var item = AcUserInfo._netData_inventory._itemList.Where(data => data._uId == inMsg._itemChangeInfoList[i]._itemUId).FirstOrDefault();

                        if (item == null && inMsg._itemChangeInfoList[i]._count != 0)
                        {
                            item = new AcNetData_ItemInfo();
                            item._uId = inMsg._itemChangeInfoList[i]._itemUId;
                            item._itemDataId = inMsg._itemChangeInfoList[i]._itemDataId;
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            item._timeLimitOn = inMsg._itemChangeInfoList[i]._timeLimitOn;
                            item._timeLimitEndDate = inMsg._itemChangeInfoList[i]._timeLimitEndDate;

                            AcUserInfo._netData_inventory._itemList.Add(item);
                            PlayerDataManager.Instance.AddNewItem(item._uId);
                        }
                        else if (item != null && inMsg._itemChangeInfoList[i]._count == 0)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            AcUserInfo._netData_inventory._itemList.Remove(item);
                            PlayerDataManager.Instance.RemoveNewItem(item._uId);
                        }
                        else if (item != null)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                        }
                    }
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._itemAcquireInfoList);
        });
    }

    #endregion

    #region TOT 챔피언쉽 보상 획득 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_tOTChampionShipRewardAcquire(Action<eGameResult, List<AcNetData_ItemAcquireInfo>> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqUserTOTChampionShipRewardAcquire();

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_UserTOTChampionShipRewardAcquire, outMsg);

        RegisterMessageHandler<AcNetDataSC_resUserTOTChampionShipRewardAcquire>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_UserTOTChampionShipRewardAcquire, (inMsg) =>
        {
            Debug.Log("[Network] TOT 챔피언쉽 보상 획득 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                // 보상 받음 처리
                AcUserInfo._netData_user._tOTChampionShipRewardInfo._receive = true;

                // 아이템 인벤토리 수정
                if (AcUserInfo._netData_inventory != null)
                {
                    for (int i = 0; i < inMsg._itemChangeInfoList.Count; i++)
                    {
                        var item = AcUserInfo._netData_inventory._itemList.Where(data => data._uId == inMsg._itemChangeInfoList[i]._itemUId).FirstOrDefault();

                        if (item == null && inMsg._itemChangeInfoList[i]._count != 0)
                        {
                            item = new AcNetData_ItemInfo();
                            item._uId = inMsg._itemChangeInfoList[i]._itemUId;
                            item._itemDataId = inMsg._itemChangeInfoList[i]._itemDataId;
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            item._timeLimitOn = inMsg._itemChangeInfoList[i]._timeLimitOn;
                            item._timeLimitEndDate = inMsg._itemChangeInfoList[i]._timeLimitEndDate;

                            AcUserInfo._netData_inventory._itemList.Add(item);
                            PlayerDataManager.Instance.AddNewItem(item._uId);
                        }
                        else if (item != null && inMsg._itemChangeInfoList[i]._count == 0)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            AcUserInfo._netData_inventory._itemList.Remove(item);
                            PlayerDataManager.Instance.RemoveNewItem(item._uId);
                        }
                        else if (item != null)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                        }
                    }
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._itemAcquireInfoList);
        });
    }

    #endregion

    #region TOT 챔피언쉽 Buy-In 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_tOTChampionShipBuyIn(eTOTChampionShipBuyInType buyInType, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqTOTChampionShipBuyIn();
        outMsg._buyInType = buyInType;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_TOTChampionShipBuyIn, outMsg);

        RegisterMessageHandler<AcNetDataSC_resTOTChampionShipBuyIn>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_TOTChampionShipBuyIn, (inMsg) =>
        {
            Debug.Log("[Network] TOT 챔피언쉽 Buy-In 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                // 아이템 인벤토리 수정
                if (AcUserInfo._netData_inventory != null)
                {
                    for (int i = 0; i < inMsg._itemChangeInfoList.Count; i++)
                    {
                        var item = AcUserInfo._netData_inventory._itemList.Where(data => data._uId == inMsg._itemChangeInfoList[i]._itemUId).FirstOrDefault();

                        if (item == null && inMsg._itemChangeInfoList[i]._count != 0)
                        {
                            item = new AcNetData_ItemInfo();
                            item._uId = inMsg._itemChangeInfoList[i]._itemUId;
                            item._itemDataId = inMsg._itemChangeInfoList[i]._itemDataId;
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            item._timeLimitOn = inMsg._itemChangeInfoList[i]._timeLimitOn;
                            item._timeLimitEndDate = inMsg._itemChangeInfoList[i]._timeLimitEndDate;

                            AcUserInfo._netData_inventory._itemList.Add(item);
                            PlayerDataManager.Instance.AddNewItem(item._uId);
                        }
                        else if (item != null && inMsg._itemChangeInfoList[i]._count == 0)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            AcUserInfo._netData_inventory._itemList.Remove(item);
                            PlayerDataManager.Instance.RemoveNewItem(item._uId);
                        }
                        else if (item != null)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                        }
                    }
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 누적 럭키포인트 정보 요청 

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_accumulateLuckyPoint(Action<eGameResult, long> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqAccumulateLuckyPointInfo();

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_AccumulateLuckyPointInfo, outMsg);

        RegisterMessageHandler<AcNetDataSC_resAccumulateLuckyPointInfo>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_AccumulateLuckyPointInfo, (inMsg) =>
        {
            Debug.Log("[Network] 누적 럭키포인트 정보 요청 응답: " + inMsg._result);

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._accumulateLuckyPoint);
        });
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 슬롯머신
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 슬롯머신 잭팟포인트 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_slotMachineJackPotPoint(Action<long> fun_res = null)
    {
        if (IsGameConnected == false)
        {
            fun_res(0);
        }

        var outMsg = new AcNetDataCS_reqSlotMachineJackPotPoint();

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_SlotMachineJackPotPoint, outMsg);

        RegisterMessageHandler<AcNetDataSC_resSlotMachineJackPotPoint>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_SlotMachineJackPotPoint, (inMsg) =>
        {
            if (fun_res != null)
                fun_res(inMsg._jackPotPoint);
        });
    }

    #endregion

    #region 슬롯머신 플레이 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_slotMachinePlay(long bettingPoint, Action<eGameResult, AcNetDataSC_resSlotMachinePlay> fun_res = null)
    {
        if (IsGameConnected == false)
        {
            fun_res(eGameResult.RESULT_FAIL, null);
        }

        var outMsg = new AcNetDataCS_reqSlotMachinePlay();
        outMsg._slotMachineDataId = 1;
        outMsg._bettingPoint = bettingPoint;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_SlotMachinePlay, outMsg);

        RegisterMessageHandler<AcNetDataSC_resSlotMachinePlay>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_SlotMachinePlay, (inMsg) =>
        {
            Debug.Log("[Network] 슬롯머신 플레이 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._symbolDataIdList = inMsg._symbolDataIdList;
                AcUserInfo._rewardDataIdList = inMsg._rewardDataIdList;
            }

            if (fun_res != null)
                fun_res(inMsg._result, inMsg);
        });
    }

    #endregion

    #region 슬롯머신 출석 플레이 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_slotMachineAttendancePlay(Action<eGameResult, AcNetDataSC_resSlotMachineAttendancePlay> fun_res = null)
    {
        if (IsGameConnected == false)
        {
            fun_res(eGameResult.RESULT_FAIL, null);
        }

        var outMsg = new AcNetDataCS_reqSlotMachinePlay();
        outMsg._slotMachineDataId = 2;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_SlotMachinePlay, outMsg);

        RegisterMessageHandler<AcNetDataSC_resSlotMachineAttendancePlay>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_SlotMachineAttendancePlay, (inMsg) =>
        {
            Debug.Log("[Network] 슬롯머신 플레이 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._attendanceSymbolDataIdList = inMsg._symbolDataIdList;
                AcUserInfo._netData_user._lastAttendanceDate = inMsg._lastAttendanceDate;
                AcUserInfo._netData_user._attendanceSlotMachineEnableCount = inMsg._attendanceSlotMachineEnableCount;
                AcUserInfo._netData_user._attendanceAccumulateCount = inMsg._attendanceAccumulateCount;
            }

            if (fun_res != null)
                fun_res(inMsg._result, inMsg);
        });
    }

    #endregion

    #region 슬롯머신 플레이 보상 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_slotMachinePlayReward(long rewardUId, Action<eGameResult, long> fun_res = null)
    {
        if (IsGameConnected == false)
        {
            fun_res(eGameResult.RESULT_FAIL, 0);
        }

        var outMsg = new AcNetDataCS_reqSlotMachinePlayReward();
        outMsg._rewardUid = rewardUId;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_SlotMachinePlayReward, outMsg);

        RegisterMessageHandler<AcNetDataSC_resSlotMachinePlayReward>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_SlotMachinePlayReward, (inMsg) =>
        {
            Debug.Log("[Network] 슬롯머신 플레이 보상 응답: " + inMsg._result);

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._acquireValue);
        });
    }

    #endregion

    #region 슬롯머신 룰렛 플레이 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_slotMachineRoulettePlay(Action<eGameResult, AcNetDataSC_resSlotMachineRoulettePlay> fun_res = null)
    {
        if (IsGameConnected == false)
        {
            fun_res(eGameResult.RESULT_FAIL, null);
        }

        var outMsg = new AcNetDataCS_reqSlotMachinePlay();
        outMsg._slotMachineDataId = 3;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_SlotMachinePlay, outMsg);

        RegisterMessageHandler<AcNetDataSC_resSlotMachineRoulettePlay>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_SlotMachineRoulettePlay, (inMsg) =>
        {
            Debug.Log("[Network] 슬롯머신 룰렛 플레이 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._rouletteSymbolDataId = inMsg._symbolDataId;
                AcUserInfo._netData_user._rouletteFeverCount = inMsg._rouletteFeverCount;
                AcUserInfo._netData_user._rouletteFreeCount = inMsg._rouletteFreeCount;
                AcUserInfo._netData_user._rouletteFreeUpdateDateTime = inMsg._rouletteFreeUpdateDateTime;
            }

            if (fun_res != null)
                fun_res(inMsg._result, inMsg);
        });
    }

    #endregion

    #region 슬롯머신 룰렛 플레이 보상 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_slotMachineRoulettePlayReward(long rewardUId, Action<eGameResult, long> fun_res = null)
    {
        if (IsGameConnected == false)
        {
            fun_res(eGameResult.RESULT_FAIL, 0);
        }

        var outMsg = new AcNetDataCS_reqSlotMachineRoulettePlayReward();
        outMsg._rewardUid = rewardUId;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_SlotMachineRoulettePlayReward, outMsg);

        RegisterMessageHandler<AcNetDataSC_resSlotMachineRoulettePlayReward>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_SlotMachineRoulettePlayReward, (inMsg) =>
        {
            Debug.Log("[Network] 슬롯머신 룰렛 플레이 보상 응답: " + inMsg._result);

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._acquireValue);
        });
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 미션
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 미션 리스트 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 미션 리스트 요청
    public virtual void SendPacket_req_missionList(Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqMissionList();

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_MissionList, outMsg);

        RegisterMessageHandler<AcNetDataSC_resMissionList>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_MissionList, (inMsg) =>
        {
            Debug.Log("[Network] 미션 리스트 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._missionInfoList = inMsg._missionInfoList;
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 미션 보상 획득 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 미션 보상 획득 요청
    public virtual void SendPacket_req_missionRewardAcquire(int missionDataId, Action<eGameResult, int, List<AcNetData_ItemAcquireInfo>> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqMissionRewardAcquire();
        outMsg._missionDataId = missionDataId;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_MissionRewardAcquire, outMsg);

        RegisterMessageHandler<AcNetDataSC_resMissionRewardAcquire>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_MissionRewardAcquire, (inMsg) =>
        {
            Debug.Log("[Network] 미션 보상 획득 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                // 미션 업데이트
                if (AcUserInfo._missionInfoList != null)
                {
                    for (int i = 0; i < inMsg._missionChangeInfoList.Count; i++)
                    {
                        var missionInfo = AcUserInfo._missionInfoList.Where(data => data._uId == inMsg._missionChangeInfoList[i]._uId).FirstOrDefault();

                        if (missionInfo == null)
                        {
                            AcUserInfo._missionInfoList.Add(inMsg._missionChangeInfoList[i]);
                        }
                        else if (missionInfo != null)
                        {
                            if (inMsg._missionChangeInfoList[i]._missionComplete == true && inMsg._missionChangeInfoList[i]._endMission == false)
                            {
                                AcUserInfo._missionInfoList.Remove(missionInfo);
                            }

                            missionInfo._missionCount = inMsg._missionChangeInfoList[i]._missionCount;
                            missionInfo._missionComplete = inMsg._missionChangeInfoList[i]._missionComplete;
                        }
                    }
                }

                // 아이템 인벤토리 수정
                if (AcUserInfo._netData_inventory != null)
                {
                    for (int i = 0; i < inMsg._itemChangeInfoList.Count; i++)
                    {
                        var item = AcUserInfo._netData_inventory._itemList.Where(data => data._uId == inMsg._itemChangeInfoList[i]._itemUId).FirstOrDefault();

                        if (item == null && inMsg._itemChangeInfoList[i]._count != 0)
                        {
                            item = new AcNetData_ItemInfo();
                            item._uId = inMsg._itemChangeInfoList[i]._itemUId;
                            item._itemDataId = inMsg._itemChangeInfoList[i]._itemDataId;
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            item._timeLimitOn = inMsg._itemChangeInfoList[i]._timeLimitOn;
                            item._timeLimitEndDate = inMsg._itemChangeInfoList[i]._timeLimitEndDate;

                            AcUserInfo._netData_inventory._itemList.Add(item);
                            PlayerDataManager.Instance.AddNewItem(item._uId);
                        }
                        else if (item != null && inMsg._itemChangeInfoList[i]._count == 0)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            AcUserInfo._netData_inventory._itemList.Remove(item);
                            PlayerDataManager.Instance.RemoveNewItem(item._uId);
                        }
                        else if (item != null)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                        }
                    }
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._missionDataId, inMsg._itemAcquireInfoList);
        });
    }

    #endregion

    #region 미션 갱신 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 미션 갱신 요청
    public virtual void SendPacket_req_missionRefresh(Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqMissionRefresh();

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_MissionRefresh, outMsg);
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 공유 보상
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 공유 보상 정보 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_shareRewardInfo(Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqShareRewardInfo();

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_ShareRewardInfo, outMsg);

        RegisterMessageHandler<AcNetDataSC_resShareRewardInfo>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_ShareRewardInfo, (inMsg) =>
        {
            Debug.Log("[Network] 공유 보상 정보 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._shareRewardInfo = inMsg._shareRewardInfo;
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 공유 보상 획득 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_shareRewardAcquire(int missionDataId, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqShareRewardAcquire();
        outMsg._missionDataId = missionDataId;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_ShareRewardAcquire, outMsg);

        RegisterMessageHandler<AcNetDataSC_resShareRewardAcquire>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_ShareRewardAcquire, (inMsg) =>
        {
            Debug.Log("[Network] 공유 보상 획득 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                // 공유 보상 정보 업데이트
                if (AcUserInfo._shareRewardInfo != null)
                {
                    AcUserInfo._shareRewardInfo._receiveRewardDataIdList.Add(inMsg._missionDataId);
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 로그
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 버튼 로그 저장 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 버튼 로그 저장 요청
    public virtual void SendPacket_req_logButtonClick(eButtonType buttonType, int value = 0, Action<eGameResult> fun_res = null)
    {
        var logData = new AsLog_ButtonClick();
        logData._buttonType = buttonType;
        logData._value = value;

        if (AcUserInfo._netData_user != null)
            logData._userUId = AcUserInfo._netData_user._uId;

        var outMsg = logData.CreateRequestPacket();
        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_LogSave, outMsg);
    }

    #endregion

    #region 친구 초대 설치 로그 저장 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 친구 초대 설치 로그 저장 요청
    public virtual IEnumerator SendPacket_req_logFriendInviteInstall(string deviceCode, string inviteCode, Action<eGameResult> fun_res = null)
    {
        var logData = new AsLog_FriendInviteInstallInfo();
        logData.DeviceCode = deviceCode;
        logData.InviteCode = inviteCode;

        byte[] bytes = System.Text.Encoding.ASCII.GetBytes(logData.CreateLogJson());

        using (UnityWebRequest www = new UnityWebRequest(AcNetworkBase._remoteWebAdress_Log, UnityWebRequest.kHttpVerbPOST))
        {
            UploadHandlerRaw uH = new UploadHandlerRaw(bytes);
            DownloadHandlerBuffer dH = new DownloadHandlerBuffer();

            www.uploadHandler = uH;
            www.downloadHandler = dH;
            www.SetRequestHeader("Content-Type", "application/json");
            yield return www.SendWebRequest();

            if (www.isHttpError || www.isNetworkError)
            {
                Debug.Log(www.error);
            }
            else
            {
                Debug.Log(www.ToString());
                Debug.Log(www.downloadHandler.text);
            }
        }
    }

    #endregion

    #region 로그인 보안 실패 로그 저장 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 로그인 보안 실패 로그 저장 요청
    public virtual IEnumerator SendPacket_req_LoginSecurityFail(string mACAddress, eLoginSecurityFailType loginSecurityFailType, int value = 0, Action<eGameResult> fun_res = null)
    {
        var logData = new AsLog_LoginSecurityFail();
        logData.MACAddress = mACAddress;
        logData.LoginSecurityFailType = loginSecurityFailType;

        byte[] bytes = System.Text.Encoding.ASCII.GetBytes(logData.CreateLogJson());

        using (UnityWebRequest www = new UnityWebRequest(AcNetworkBase._remoteWebAdress_Log, UnityWebRequest.kHttpVerbPOST))
        {
            UploadHandlerRaw uH = new UploadHandlerRaw(bytes);
            DownloadHandlerBuffer dH = new DownloadHandlerBuffer();

            www.uploadHandler = uH;
            www.downloadHandler = dH;
            www.SetRequestHeader("Content-Type", "application/json");
            yield return www.SendWebRequest();

            if (www.isHttpError || www.isNetworkError)
            {
                Debug.Log(www.error);
            }
            else
            {
                Debug.Log(www.ToString());
                Debug.Log(www.downloadHandler.text);
            }
        }
    }

    #endregion

    #region 정책 로그 저장 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 정책 로그 저장 요청
    public virtual IEnumerator SendPacket_req_logTermsOfService(string mACAddress, eTermsOfServiceLogType termsOfServiceLogType, int value = 0, Action<eGameResult> fun_res = null)
    {
        var logData = new AsLog_TermsOfService();
        logData.MACAddress = mACAddress;
        logData.TermsOfServiceLogType = termsOfServiceLogType;

        byte[] bytes = System.Text.Encoding.ASCII.GetBytes(logData.CreateLogJson());

        using (UnityWebRequest www = new UnityWebRequest(AcNetworkBase._remoteWebAdress_Log, UnityWebRequest.kHttpVerbPOST))
        {
            UploadHandlerRaw uH = new UploadHandlerRaw(bytes);
            DownloadHandlerBuffer dH = new DownloadHandlerBuffer();

            www.uploadHandler = uH;
            www.downloadHandler = dH;
            www.SetRequestHeader("Content-Type", "application/json");
            yield return www.SendWebRequest();

            if (www.isHttpError || www.isNetworkError)
            {
                Debug.Log(www.error);
            }
            else
            {
                Debug.Log(www.ToString());
                Debug.Log(www.downloadHandler.text);
            }
        }
    }

    #endregion

    #region 유저 아이템 치팅 로그 저장 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 로그인 보안 실패 로그 저장 요청
    public virtual IEnumerator SendPacket_req_ItemCheatingLog(long userUId, int itemIndex, long itemCountOriginal, long itemCountChange, Action<eGameResult> fun_res = null)
    {
        var logData = new AsLog_ItemCheating();
        logData.UserUId = userUId;
        logData.ItemIndex = itemIndex;
        logData.ItemCountOriginal = itemCountOriginal;
        logData.ItemCountChange = itemCountChange;

        byte[] bytes = System.Text.Encoding.ASCII.GetBytes(logData.CreateLogJson());

        using (UnityWebRequest www = new UnityWebRequest(AcNetworkBase._remoteWebAdress_Log, UnityWebRequest.kHttpVerbPOST))
        {
            UploadHandlerRaw uH = new UploadHandlerRaw(bytes);
            DownloadHandlerBuffer dH = new DownloadHandlerBuffer();

            www.uploadHandler = uH;
            www.downloadHandler = dH;
            www.SetRequestHeader("Content-Type", "application/json");
            yield return www.SendWebRequest();

            if (www.isHttpError || www.isNetworkError)
            {
                Debug.Log(www.error);
            }
            else
            {
                Debug.Log(www.ToString());
                Debug.Log(www.downloadHandler.text);
            }
        }
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 설문조사
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 설문조사 참여 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 설문조사 참여 요청
    public virtual void SendPacket_req_research(int researchDataId, int answerNumber, string answerString, Action<eGameResult, int, List<AcNetData_ItemAcquireInfo>> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqUserResearch();
        outMsg._researchDataId = researchDataId;
        outMsg._answerNumber = answerNumber;
        outMsg._answerString = answerString;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_UserResearch, outMsg);

        RegisterMessageHandler<AcNetDataSC_resUserResearch>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_UserResearch, (inMsg) =>
        {
            Debug.Log("[Network] 설문조사 참여 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                // 아이템 인벤토리 수정
                if (AcUserInfo._netData_inventory != null)
                {
                    for (int i = 0; i < inMsg._itemChangeInfoList.Count; i++)
                    {
                        var item = AcUserInfo._netData_inventory._itemList.Where(data => data._uId == inMsg._itemChangeInfoList[i]._itemUId).FirstOrDefault();

                        if (item == null && inMsg._itemChangeInfoList[i]._count != 0)
                        {
                            item = new AcNetData_ItemInfo();
                            item._uId = inMsg._itemChangeInfoList[i]._itemUId;
                            item._itemDataId = inMsg._itemChangeInfoList[i]._itemDataId;
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            item._timeLimitOn = inMsg._itemChangeInfoList[i]._timeLimitOn;
                            item._timeLimitEndDate = inMsg._itemChangeInfoList[i]._timeLimitEndDate;

                            AcUserInfo._netData_inventory._itemList.Add(item);
                            PlayerDataManager.Instance.AddNewItem(item._uId);
                        }
                        else if (item != null && inMsg._itemChangeInfoList[i]._count == 0)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            AcUserInfo._netData_inventory._itemList.Remove(item);
                            PlayerDataManager.Instance.RemoveNewItem(item._uId);
                        }
                        else if (item != null)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                        }
                    }
                }

                var researchInfo = AcUserInfo._netData_user._researchInfoList.Where(data => data._researchType == inMsg._researchType).FirstOrDefault();
                if (researchInfo == null)
                {
                    researchInfo = new AcNetData_ResearchInfo();
                    researchInfo._researchType = inMsg._researchType;
                    AcUserInfo._netData_user._researchInfoList.Add(researchInfo);
                }

                researchInfo._researchDate = inMsg._researchDate;
                researchInfo._researchDataIdList.Add(inMsg._researchDataId);
            }

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._researchDataId, inMsg._itemAcquireInfoList);
        });
    }

    #endregion

    #region 설문조사 끝 부족칩 보상 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 설문조사 끝 부족칩 보상 요청
    public virtual void SendPacket_req_researchEndLackChipReward(Action<eGameResult, long> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqUserResearchEndLackChipReward();

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_UserResearchEndLackChipReward, outMsg);

        RegisterMessageHandler<AcNetDataSC_resUserResearchEndLackChipReward>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_UserResearchEndLackChipReward, (inMsg) =>
        {
            Debug.Log("[Network] 설문조사 끝 부족칩 보상 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {

            }

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._rewardChip);
        });
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 설문조사
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 레이턴시 로그인 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 레이턴시 로그인 요청
    public virtual void SendPacket_req_latancyLogin(string deviceInfo, string location, string networkInfo)
    {
        var outMsg = new AcNetDataCS_reqLaytancyLogin();
        outMsg._deviceInfo = deviceInfo;
        outMsg._location = location;
        outMsg._networkInfo = networkInfo;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_LatancyLogin, outMsg);
    }

    #endregion

    #region 레이턴시 로그아웃 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 레이턴시 로그아웃 요청
    public virtual void SendPacket_req_latancyLogout(string deviceInfo, string location, string networkInfo)
    {
        var outMsg = new AcNetDataCS_reqLaytancyLogout();
        outMsg._deviceInfo = deviceInfo;
        outMsg._location = location;
        outMsg._networkInfo = networkInfo;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_LatancyLogout, outMsg);
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 결제
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 결제 아이디 발급 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 결제 아이디 발급 요청
    public virtual void SendPacket_req_paymentId(ePaymentType paymentType, int shopDataId, Action<eGameResult, string> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqPaymentId();
        outMsg._paymentType = paymentType;
        outMsg._shopDataId = shopDataId;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_PaymentId, outMsg);
        RegisterMessageHandler<AcNetDataSC_resPaymentId>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_PaymentId, (inMsg) =>
        {
            Debug.Log("[Network] 결제 아이디 발급 요청 응답: " + inMsg._result);

            
            if (fun_res != null)
                fun_res(inMsg._result, inMsg._paymentId);
        });
    }

    #endregion

    #region 결제 확인 및 아이템 지급 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 결제 확인 및 아이템 지급 요청
    public virtual void SendPacket_req_paymentVerify(string receipt, ePaymentType paymentType, Action<eGameResult, List<AcNetData_ItemAcquireInfo>> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqPaymentVerify();
        outMsg._receipt = receipt;
        outMsg._paymentType = paymentType;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_PaymentVerify, outMsg);
        RegisterMessageHandler<AcNetDataSC_resPaymentVerify>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_PaymentVerify, (inMsg) =>
        {
            Debug.Log("[Network] 결제 확인 및 아이템 지급 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                // 아이템 인벤토리 수정
                if (AcUserInfo._netData_inventory != null)
                {
                    for (int i = 0; i < inMsg._itemChangeInfoList.Count; i++)
                    {
                        var item = AcUserInfo._netData_inventory._itemList.Where(data => data._uId == inMsg._itemChangeInfoList[i]._itemUId).FirstOrDefault();

                        if (item == null && inMsg._itemChangeInfoList[i]._count != 0)
                        {
                            item = new AcNetData_ItemInfo();
                            item._uId = inMsg._itemChangeInfoList[i]._itemUId;
                            item._itemDataId = inMsg._itemChangeInfoList[i]._itemDataId;
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            item._timeLimitOn = inMsg._itemChangeInfoList[i]._timeLimitOn;
                            item._timeLimitEndDate = inMsg._itemChangeInfoList[i]._timeLimitEndDate;

                            AcUserInfo._netData_inventory._itemList.Add(item);
                            PlayerDataManager.Instance.AddNewItem(item._uId);
                        }
                        else if (item != null && inMsg._itemChangeInfoList[i]._count == 0)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            AcUserInfo._netData_inventory._itemList.Remove(item);
                            PlayerDataManager.Instance.RemoveNewItem(item._uId);
                        }
                        else if (item != null)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                        }
                    }
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._itemAcquireInfoList);
        });
    }

    #endregion

    #region 결제 취소 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 결제 취소 요청
    public virtual void SendPacket_req_paymentCancel(string paymentId, Action<eGameResult, string> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqPaymentCancel();
        outMsg._paymentId = paymentId;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_PaymentCancel, outMsg);
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // PayTM
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region PayTM 사용 동의 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_payTMUseAgreement(Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqPayTMUseAgreement();

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_PayTMUseAgreement, outMsg);
        RegisterMessageHandler<AcNetDataSC_resPayTMUseAgreement>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_PayTMUseAgreement, (inMsg) =>
        {
            Debug.Log("[Network] PayTM 사용 동의 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._netData_user._payTMUseAgreement = true;
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region PayTM OTP 전송 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_payTMOTPSend(string phoneNumber, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqPayTMOTPMessageSend();
        outMsg._phoneNumber = phoneNumber;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_PayTMOTPMessageSend, outMsg);

        if (fun_res != null)
        {
            fun_res(eGameResult.RESULT_OK);
        }
    }

    #endregion

    #region PayTM OTP 재전송 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_payTMOTPResend(string phoneNumber, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqPayTMOTPMessageResend();
        outMsg._phoneNumber = phoneNumber;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_PayTMOTPMessageResend, outMsg);

        if (fun_res != null)
        {
            fun_res(eGameResult.RESULT_OK);
        }
    }

    #endregion

    #region PayTM 정보 등록 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_payTMRegister(string password, string mailAddress, string phoneNumber, string otpStr, Action<eGameResult, string> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqPayTMInfoRegister();
        outMsg._password = password;
        outMsg._mailAddress = mailAddress;
        outMsg._phoneNumber = phoneNumber;
        outMsg._otpStr = otpStr;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_PayTMInfoRegister, outMsg);
        RegisterMessageHandler<AcNetDataSC_resPayTMInfoRegister>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_PayTMInfoRegister, (inMsg) =>
        {
            Debug.Log("[Network] PayTM 정보 등록 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._netData_user._payTMPhoneNumber = inMsg._phoneNumber;
            }

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._errorMessage);
        });
    }

    #endregion

    #region PayTM 폰번호 변경 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_payTMPhoneNumberChange(string password, string phoneNumber, string otpStr, Action<eGameResult, string> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqPayTMPhoneNumberChange();
        outMsg._password = password;
        outMsg._phoneNumber = phoneNumber;
        outMsg._otpStr = otpStr;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_PayTMPhoneNumberChange, outMsg);
        RegisterMessageHandler<AcNetDataSC_resPayTMInfoRegister>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_PayTMPhoneNumberChange, (inMsg) =>
        {
            Debug.Log("[Network] PayTM 폰번호 변경 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._netData_user._payTMPhoneNumber = inMsg._phoneNumber;
            }

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._errorMessage);
        });
    }

    #endregion

    #region PayTM 비밀번호 변경 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_payTMPasswordChange(string password, string otpStr, Action<eGameResult, string> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqPayTMPasswordChange();
        outMsg._password = password;
        outMsg._otpStr = otpStr;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_PayTMPasswordChange, outMsg);
        RegisterMessageHandler<AcNetDataSC_resPayTMPasswordChange>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_PayTMPasswordChange, (inMsg) =>
        {
            Debug.Log("[Network] PayTM 비밀번호 변경 요청 응답: " + inMsg._result);

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._errorMessage);
        });
    }

    #endregion

    #region PayTM 환전 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_payTMExchange(string password, int rewardDataId, Action<eGameResult, string> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqPayTMExchange();
        outMsg._password = password;
        outMsg._dataId = rewardDataId;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_PayTMExchange, outMsg);
        RegisterMessageHandler<AcNetDataSC_resPayTMExchange>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_PayTMExchange, (inMsg) =>
        {
            Debug.Log("[Network] PayTM 환전 요청 응답: " + inMsg._result);

            if (fun_res != null)
            {
                if (inMsg._result == eGameResult.RESULT_OK)
                { 
                    if(AcUserInfo._netData_user._payTMLastUseRewardDataId < inMsg._lastUseRewardDataId)
                    {
                        AcUserInfo._netData_user._payTMLastUseRewardDataId = inMsg._lastUseRewardDataId;
                    }

                    fun_res(inMsg._result, inMsg._shareRewardToken);
                }
                else
                {
                    fun_res(inMsg._result, inMsg._errorCode);
                }
            }
        });
    }

    #endregion

    #region PayTM 아이템 환전 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_payTMItemExchange(string password, int itemDataId, long itemCount, Action<eGameResult, string> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqPayTMExchange();
        outMsg._password = password;
        outMsg._dataId = itemDataId;
        outMsg._itemCount = itemCount;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_PayTMExchange, outMsg);
        RegisterMessageHandler<AcNetDataSC_resPayTMExchange>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_PayTMExchange, (inMsg) =>
        {
            Debug.Log("[Network] PayTM 아이템 환전 요청 응답: " + inMsg._result);

            if (fun_res != null)
            {
                if (inMsg._result == eGameResult.RESULT_OK)
                {
                    fun_res(inMsg._result, "");
                }
                else
                {
                    fun_res(inMsg._result, inMsg._errorCode);
                }
            }
        });
    }

    #endregion

    #region PayTM 공유 보상 획득 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_payTMShareRewardAcquire(string shareRewardToken, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqPayTMShareRewardAcquire();
        outMsg._shareRewardToken = shareRewardToken;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_PayTMShareRewardAcquire, outMsg);

        RegisterMessageHandler<AcNetDataSC_resPayTMShareRewardAcquire>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_PayTMShareRewardAcquire, (inMsg) =>
        {
            Debug.Log("[Network] PayTM 공유 보상 획득 요청 응답: " + inMsg._result);

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 친구
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 친구 리스트 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 친구 리스트 요청
    public virtual void SendPacket_req_friendList(Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqFriendList();

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_FriendList, outMsg);
        RegisterMessageHandler<AcNetDataSC_resFriendList>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_FriendList, (inMsg) =>
        {
            Debug.Log("[Network] 친구 리스트 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._friendList = inMsg._friendList;
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 친구 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 친구 요청
    public virtual void SendPacket_req_friendRequest(long friendUserUId, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqFriendRequest();
        outMsg._dstUserUId = friendUserUId;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_FriendRequest, outMsg);
        RegisterMessageHandler<AcNetDataSC_resFriendRequest>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_FriendRequest, (inMsg) =>
        {
            Debug.Log("[Network] 친구 요청 응답: " + inMsg._result);

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 친구 요청 리스트 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 친구 리스트 요청
    public virtual void SendPacket_req_friendRequestList(Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqFriendList();

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_FriendRequestList, outMsg);
        RegisterMessageHandler<AcNetDataSC_resFriendRequestList>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_FriendRequestList, (inMsg) =>
        {
            Debug.Log("[Network] 친구 리스트 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._friendRequestList = inMsg._friendRequestList;
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 친구 요청 수락여부 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 친구 요청 수락여부 요청
    public virtual void SendPacket_req_friendRequestAccept(long requestUId, bool accept, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqFriendRequestAccept();
        outMsg._requestUId = requestUId;
        outMsg._accept = accept;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_FriendRequestAccept, outMsg);
        RegisterMessageHandler<AcNetDataSC_resFriendRequestAccept>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_FriendRequestAccept, (inMsg) =>
        {
            Debug.Log("[Network] 친구 요청 수락여부 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._friendRequestList.RemoveAll(data => data._uId == inMsg._requestUId);
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 친구 삭제 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 친구 삭제 요청
    public virtual void SendPacket_req_friendRemove(long friendUId, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqFriendRemove();
        outMsg._friendUId = friendUId;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_FriendRemove, outMsg);
        RegisterMessageHandler<AcNetDataSC_resFriendRemove>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_FriendRemove, (inMsg) =>
        {
            Debug.Log("[Network] 친구 삭제 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._friendList.RemoveAll(data => data._uId == inMsg._friendUId);
                ForuOnes.T3.LuckyTeenPatti.PlayerDataManager.Instance.CheckFriends();
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 친구 상태정보 리스트 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 친구 상태정보 리스트 요청
    public virtual void SendPacket_req_friendUserStateInfoList(Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqFriendUserStateInfoList();

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_FriendUserStateInfoList, outMsg);
        RegisterMessageHandler<AcNetDataSC_resFriendUserStateInfoList>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_FriendUserStateInfoList, (inMsg) =>
        {
            Debug.Log("[Network] 친구 상태정보 리스트 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                var friendUserStateInfoList = inMsg._friendUserStateInfoList;
                for (int i = 0; i < friendUserStateInfoList.Count; i++)
                {
                    for (int k = 0; k < AcUserInfo._friendList.Count; k++)
                    {
                        if (AcUserInfo._friendList[k]._uId == friendUserStateInfoList[i]._friendUId)
                        {
                            AcUserInfo._friendList[k]._userState = friendUserStateInfoList[k]._userState;
                            break;
                        }
                    }
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 유저 상태정보 알림

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 유저 상태정보 알림
    public virtual void SendPacket_req_userStateInfo(eUserState userState)
    {
        var outMsg = new AcNetDataCS_notifyUserStateInfo();
        outMsg._userState = userState;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSNotify_UserStateInfo, outMsg);
    }

    #endregion

    #region 친구 싱크 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 친구 싱크 요청
    public virtual void SendPacket_req_friendSync(List<string> addFriendUserIdList, List<long> changeFriendUserUIdList, List<long> removeFriendUserUIdList, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqFriendSync();
        outMsg._addFriendUserIdList = addFriendUserIdList;
        outMsg._changeFriendUserUIdList = changeFriendUserUIdList;
        outMsg._removeFriendUserUIdList = removeFriendUserUIdList;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_FriendSync, outMsg);
        RegisterMessageHandler<AcNetDataSC_resFriendSync>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_FriendSync, (inMsg) =>
        {
            Debug.Log("[Network] 친구 싱크 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._friendList = inMsg._friendList;
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 친구 선물 보내기 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 친구 선물 보내기 요청
    public virtual void SendPacket_req_friendGiftSend(List<long> friendUIdList, Action<List<AcNetData_FriendSendGiftResultInfo>> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqFriendSendGift();
        outMsg._friendUIdList = friendUIdList;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_FriendSendGift, outMsg);
        RegisterMessageHandler<AcNetDataSC_resFriendSendGift>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_FriendSendGift, (inMsg) =>
        {
            Debug.Log("[Network] 친구 선물 보내기 요청 응답: " + inMsg._result);

            // 선물보내기 성공한 친구정보 보낸날짜 갱신
            for (int i = 0; i < inMsg._resultInfoList.Count; i++)
            {
                if (inMsg._resultInfoList[i]._result == eGameResult.RESULT_OK)
                {
                    var friendInfo = AcUserInfo._friendList.Where(data => data._uId == inMsg._resultInfoList[i]._friendUId).FirstOrDefault();
                    if (friendInfo != null)
                    {
                        friendInfo._sendGiftDateTime = inMsg._resultInfoList[i]._sendGiftDateTime;
                    }
                }
            }

            if (fun_res != null)
                fun_res(inMsg._resultInfoList);
        });
    }

    #endregion

    #region 친구 초대 정보 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 친구 초대 정보 요청
    public virtual void SendPacket_req_friendInviteInfo(Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqFriendInviteInfo();

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_FriendInviteInfo, outMsg);
        RegisterMessageHandler<AcNetDataSC_resFriendInviteInfo>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_FriendInviteInfo, (inMsg) =>
        {
            Debug.Log("[Network] 친구 초대 정보 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._userfriendInviteInfo = inMsg._userfriendInviteInfo;
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 친구 초대 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 친구 초대 요청
    public virtual void SendPacket_req_friendRecommend(string inviteCode, string deviceCode, Action<eGameResult> fun_res = null)
    {
        Debug.Log("[Network] 친구 추천 요청");
        var outMsg = new AcNetDataCS_reqFriendRecommend();
        outMsg._inviteCode = inviteCode;
        outMsg._deviceCode = deviceCode;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_FriendRecommend, outMsg);
        RegisterMessageHandler<AcNetDataSC_resFriendRecommend>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_FriendRecommend, (inMsg) =>
        {
            Debug.Log("[Network] 친구 추천 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                //AcUserInfo._userfriendInviteInfo._registerInviteCode = inMsg._userfriendInviteInfo._registerInviteCode;
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 친구 초대 보상 획득 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 친구 초대 보상 획득 요청
    public virtual void SendPacket_req_friendInviteRewardAcquire(int friendRewardDataId, Action<eGameResult, int, List<AcNetData_ItemAcquireInfo>> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqFriendInviteRewardAcquire();
        outMsg._friendRewardDataId = friendRewardDataId;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_FriendInviteRewardAcquire, outMsg);
        RegisterMessageHandler<AcNetDataSC_resFriendInviteRewardAcquire>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_FriendInviteRewardAcquire, (inMsg) =>
        {
            Debug.Log("[Network] 친구 초대 보상 획득 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._userfriendInviteInfo._inviteRewardAcquireDataIdList = inMsg._inviteRewardAcquireDataIdList;

                // 아이템 인벤토리 수정
                if (AcUserInfo._netData_inventory != null)
                {
                    for (int i = 0; i < inMsg._itemChangeInfoList.Count; i++)
                    {
                        var item = AcUserInfo._netData_inventory._itemList.Where(data => data._uId == inMsg._itemChangeInfoList[i]._itemUId).FirstOrDefault();

                        if (item == null && inMsg._itemChangeInfoList[i]._count != 0)
                        {
                            item = new AcNetData_ItemInfo();
                            item._uId = inMsg._itemChangeInfoList[i]._itemUId;
                            item._itemDataId = inMsg._itemChangeInfoList[i]._itemDataId;
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            item._timeLimitOn = inMsg._itemChangeInfoList[i]._timeLimitOn;
                            item._timeLimitEndDate = inMsg._itemChangeInfoList[i]._timeLimitEndDate;

                            AcUserInfo._netData_inventory._itemList.Add(item);
                            PlayerDataManager.Instance.AddNewItem(item._uId);
                        }
                        else if (item != null && inMsg._itemChangeInfoList[i]._count == 0)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            AcUserInfo._netData_inventory._itemList.Remove(item);
                            PlayerDataManager.Instance.RemoveNewItem(item._uId);
                        }
                        else if (item != null)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                        }
                    }
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._friendRewardDataId, inMsg._itemAcquireInfoList);
        });
    }

    #endregion

    #region 친구 대화 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 친구 대화 요청
    public virtual void SendPacket_req_friendTalk(long friendUserUId, string talkStr, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqFriendTalk();
        outMsg._friendUserUId = friendUserUId;
        outMsg._talkStr = talkStr;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_FriendTalk, outMsg);
        RegisterMessageHandler<AcNetDataSC_resFriendTalk>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_FriendTalk, (inMsg) =>
        {
            Debug.Log("[Network] 친구 대화 요청 응답: " + inMsg._result);

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 친구 비밀방 초대 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 친구 비밀방 초대 요청
    public virtual void SendPacket_req_friendPrivateRoomInvite(long friendUserUId, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqFriendPrivateRoomInvite();
        outMsg._friendUserUId = friendUserUId;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_FriendPrivateRoomInvite, outMsg);
        RegisterMessageHandler<AcNetDataSC_resFriendTalk>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_FriendPrivateRoomInvite, (inMsg) =>
        {
            Debug.Log("[Network] 친구 비밀방 초대 요청 응답: " + inMsg._result);

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 가네샤
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 가네샤 팁 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 가네샤 팁 요청
    public virtual void SendPacket_req_ganeshaTip(Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqGaneshaTip();
        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_GaneshaTip, outMsg);

        RegisterMessageHandler<AcNetDataSC_resGaneshaTip>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_GaneshaTip, (inMsg) =>
        {
            Debug.Log("[Network] 가네샤 팁 요청 응답: " + inMsg._result);

            if(inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._netData_user._ganeshaPocketChip = inMsg._ganeshaPocketChip;
            }

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion

    #region 가네샤 주머니 LP 변환 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 가네샤 팁 요청
    public virtual void SendPacket_req_ganeshaPocketConvertLP(Action<eGameResult, long> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqGaneshaPocketConvertLP();
        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_GaneshaPocketConvertLP, outMsg);

        RegisterMessageHandler<AcNetDataSC_resGaneshaPocketConvertLP>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_GaneshaPocketConvertLP, (inMsg) =>
        {
            Debug.Log("[Network] 가네샤 주머니 LP 변환 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._netData_user._ganeshaPocketChip = inMsg._ganeshaPocketChip;
            }

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._convertLP);
        });
    }

    #endregion



    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 튜토리얼
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 튜토리얼 완료 가능 리스트 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 튜토리얼 완료 가능 리스트 요청
    public virtual void SendPacket_req_tutorialCompleteInfo(Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqTutorialCompleteInfo();

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_TutorialCompleteInfo, outMsg);

        RegisterMessageHandler<AcNetDataSC_resTutorialCompleteInfo>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_TutorialCompleteInfo, (inMsg) =>
        {
            Debug.Log("[Network] 튜토리얼 완료 가능 리스트 응답: " + eGameResult.RESULT_OK);

            AcUserInfo._tutorialCompleteInfo = inMsg;

            if (fun_res != null)
                fun_res(eGameResult.RESULT_OK);
        });
    }

    #endregion

    #region 튜토리얼 베이스 보상 획득 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 튜토리얼 베이스 보상 획득 요청
    public virtual void SendPacket_req_tutorialBaseRewardAcquire(int tutorialBaseDataId, Action<eGameResult, int, List<AcNetData_ItemAcquireInfo>> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqTutorialBaseRewardAcquire();
        outMsg._tutorialBaseDataId = tutorialBaseDataId;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_TutorialBaseRewardAcquire, outMsg);

        RegisterMessageHandler<AcNetDataSC_resTutorialBaseRewardAcquire>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_TutorialBaseRewardAcquire, (inMsg) =>
        {
            Debug.Log("[Network] 튜토리얼 베이스 보상 획득 요청 응답: " + inMsg._result);

            // 완료 가능 튜토리얼 리스트에서 삭제
            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._tutorialCompleteInfo._tutorialEnableCompleteBaseIdList.RemoveAll(data => data == inMsg._tutorialBaseDataId);
                AcUserInfo._tutorialCompleteInfo._tutorialCompleteBaseIdList.Add(inMsg._tutorialBaseDataId);
            }

            // 아이템 인벤토리 수정
            if (AcUserInfo._netData_inventory != null)
            {
                for (int i = 0; i < inMsg._itemChangeInfoList.Count; i++)
                {
                    var item = AcUserInfo._netData_inventory._itemList.Where(data => data._uId == inMsg._itemChangeInfoList[i]._itemUId).FirstOrDefault();

                    if (item == null && inMsg._itemChangeInfoList[i]._count != 0)
                    {
                        item = new AcNetData_ItemInfo();
                        item._uId = inMsg._itemChangeInfoList[i]._itemUId;
                        item._itemDataId = inMsg._itemChangeInfoList[i]._itemDataId;
                        item._count = inMsg._itemChangeInfoList[i]._count;
                        item._timeLimitOn = inMsg._itemChangeInfoList[i]._timeLimitOn;
                        item._timeLimitEndDate = inMsg._itemChangeInfoList[i]._timeLimitEndDate;

                        AcUserInfo._netData_inventory._itemList.Add(item);
                        PlayerDataManager.Instance.AddNewItem(item._uId);
                    }
                    else if (item != null && inMsg._itemChangeInfoList[i]._count == 0)
                    {
                        item._count = inMsg._itemChangeInfoList[i]._count;
                        AcUserInfo._netData_inventory._itemList.Remove(item);
                        PlayerDataManager.Instance.RemoveNewItem(item._uId);
                    }
                    else if (item != null)
                    {
                        item._count = inMsg._itemChangeInfoList[i]._count;
                    }
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._tutorialBaseDataId, inMsg._itemAcquireInfoList);
        });
    }

    #endregion

    #region 튜토리얼 가네샤 보상 획득 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 튜토리얼 가네샤 보상 획득 요청
    public virtual void SendPacket_req_tutorialGaneshaRewardAcquire(int tutorialGaneshaDataId, Action<eGameResult, int, List<AcNetData_ItemAcquireInfo>> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqTutorialGaneshaRewardAcquire();
        outMsg._tutorialGaneshaDataId = tutorialGaneshaDataId;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_TutorialGaneshaRewardAcquire, outMsg);

        RegisterMessageHandler<AcNetDataSC_resTutorialGaneshaRewardAcquire>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_TutorialGaneshaRewardAcquire, (inMsg) =>
        {
            Debug.Log("[Network] 튜토리얼 베이스 보상 획득 요청 응답: " + inMsg._result);

            // 완료 가능 튜토리얼 리스트에서 삭제
            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._tutorialCompleteInfo._tutorialEnableCompleteGaneshaIdList.RemoveAll(data => data == inMsg._tutorialGaneshaDataId);
                AcUserInfo._tutorialCompleteInfo._tutorialCompleteGaneshaIdList.Add(inMsg._tutorialGaneshaDataId);
            }

            // 아이템 인벤토리 수정
            if (AcUserInfo._netData_inventory != null)
            {
                for (int i = 0; i < inMsg._itemChangeInfoList.Count; i++)
                {
                    var item = AcUserInfo._netData_inventory._itemList.Where(data => data._uId == inMsg._itemChangeInfoList[i]._itemUId).FirstOrDefault();

                    if (item == null && inMsg._itemChangeInfoList[i]._count != 0)
                    {
                        item = new AcNetData_ItemInfo();
                        item._uId = inMsg._itemChangeInfoList[i]._itemUId;
                        item._itemDataId = inMsg._itemChangeInfoList[i]._itemDataId;
                        item._count = inMsg._itemChangeInfoList[i]._count;
                        item._timeLimitOn = inMsg._itemChangeInfoList[i]._timeLimitOn;
                        item._timeLimitEndDate = inMsg._itemChangeInfoList[i]._timeLimitEndDate;

                        AcUserInfo._netData_inventory._itemList.Add(item);
                        PlayerDataManager.Instance.AddNewItem(item._uId);
                    }
                    else if (item != null && inMsg._itemChangeInfoList[i]._count == 0)
                    {
                        item._count = inMsg._itemChangeInfoList[i]._count;
                        AcUserInfo._netData_inventory._itemList.Remove(item);
                        PlayerDataManager.Instance.RemoveNewItem(item._uId);
                    }
                    else if (item != null)
                    {
                        item._count = inMsg._itemChangeInfoList[i]._count;
                    }
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._tutorialGaneshaDataId, inMsg._itemAcquireInfoList);
        });
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 광고보상
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 광고 보상 획득 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_aDRewardRewardAcquire(Action<eGameResult, long> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqADRewardAcquire();

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_ADRewardAcquire, outMsg);

        RegisterMessageHandler<AcNetDataSC_resADRewardAcquire>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_ADRewardAcquire, (inMsg) =>
        {
            Debug.Log("[Network] 광고 보상 획득 요청 응답: " + inMsg._result);

            // 완료 가능 튜토리얼 리스트에서 삭제
            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._netData_user._aDRewardLastRewardLevel = inMsg._aDRewardLastRewardLevel;

                if (inMsg._updateDateTime == true)
                {
                    AcUserInfo._netData_user._aDRewardLastUpdateDateTime = inMsg._aDRewardLastUpdateDateTime;
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._aDRewardValue);
        });
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 칩부족 보상
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 칩부족 보상 획득 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_emptyChipRewardRewardAcquire(Action<eGameResult, long> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqEmptyChipRewardAcquire();

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_EmptyChipRewardAcquire, outMsg);

        RegisterMessageHandler<AcNetDataSC_resEmptyChipRewardAcquire>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_EmptyChipRewardAcquire, (inMsg) =>
        {
            Debug.Log("[Network] 칩부족 보상 획득 요청 응답: " + inMsg._result);

            // 완료 가능 튜토리얼 리스트에서 삭제
            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._netData_user._emptyChipRewardRemainCount = inMsg._emptyChipRewardRemainCount;

                if (inMsg._updateDateTime == true)
                {
                    AcUserInfo._netData_user._emptyChipRewardLastUpdateDateTime = inMsg._emptyChipRewardLastUpdateDateTime;
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._emptyChipRewardChip);
        });
    }

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_emptyChipDoubleRewardRewardAcquire(Action<eGameResult, long> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqEmptyChipRewardAcquire();

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_EmptyChipDoubleRewardAcquire, outMsg);

        RegisterMessageHandler<AcNetDataSC_resEmptyChipRewardAcquire>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_EmptyChipRewardAcquire, (inMsg) =>
        {
            Debug.Log("[Network] 칩부족 보상 획득 요청 응답: " + inMsg._result);

            // 완료 가능 튜토리얼 리스트에서 삭제
            if (inMsg._result == eGameResult.RESULT_OK)
            {
                AcUserInfo._netData_user._emptyChipRewardRemainCount = inMsg._emptyChipRewardRemainCount;

                if (inMsg._updateDateTime == true)
                {
                    AcUserInfo._netData_user._emptyChipRewardLastUpdateDateTime = inMsg._emptyChipRewardLastUpdateDateTime;
                }
            }

            if (fun_res != null)
                fun_res(inMsg._result, inMsg._emptyChipRewardChip);
        });
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 컨텐츠 잠금
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 컨텐츠 잠금 확인 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_contentsLockCheck(eContentMainLockType mainLockType, int dataId, Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqContentsLockCheck();
        outMsg._mainLockType = mainLockType;
        outMsg._dataId = dataId;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_ContentsLockCheck, outMsg);

        RegisterMessageHandler<AcNetDataSC_resContentsLockCheck>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_ContentsLockCheck, (inMsg) =>
        {
            Debug.Log("[Network] 컨텐츠 잠금 확인 요청 응답: " + inMsg._result);

            if (fun_res != null)
                fun_res(inMsg._result);
        });
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 버프 
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 버프 정보 리스트 요청

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_buffInfoList(Action<eGameResult> fun_res = null)
    {
        var outMsg = new AcNetDataCS_reqBuffInfoList();
        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_BuffInfoList, outMsg);

        RegisterMessageHandler<AcNetDataSC_resBuffInfoList>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_BuffInfoList, (inMsg) =>
        {
            Debug.Log("[Network] 버프 정보 리스트 요청 응답: " + inMsg._result);

            AcUserInfo._buffInfoList = inMsg._buffInfoList;
            
            // 버프 종료 시간 확인
            for (int i = AcUserInfo._buffInfoList.Count - 1; i >= 0; i--)
            {
                Debug.Log(AcUserInfo._buffInfoList[i]._buffDataId);
                if (AcUserInfo._buffInfoList[i]._endDateTime < AcUserInfo.ServerDateTime)
                {
                    AcUserInfo._buffInfoList.RemoveAt(i);
                }
            }

            if (fun_res != null)
                fun_res(eGameResult.RESULT_OK);
        });
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 디버깅
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region [C->S] 디버깅 요청
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_Debug(string writeString)
    {
        var reqPacket = new AcNetData_Debug();
        reqPacket._writeString = writeString;

        SendMessage(ePeerType.LoginPeer, AcNetMessageHeaders.CSReq_DebugWriteLine, reqPacket);
    }

    #endregion

    #region [C->S] 디버깅 커맨드
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void SendPacket_req_DebugCommand(string writeString)
    {
        var reqPacket = new AcNetDataCS_reqDebugCommand();
        reqPacket._writeString = writeString;

        SendMessage(ePeerType.GamePeer, AcNetMessageHeaders.CSReq_DebugCommand, reqPacket);
        RegisterMessageHandler<AcNetDataSC_resDebugCommand>(ePeerType.GamePeer, AcNetMessageHeaders.SCRes_DebugCommand, (inMsg) =>
        {
            Debug.Log("[Network] 디버깅 커맨드 요청 응답: " + inMsg._result);

            if (inMsg._result == eGameResult.RESULT_OK)
            {
                // 아이템 인벤토리 수정
                if (AcUserInfo._netData_inventory != null)
                {
                    for (int i = 0; i < inMsg._itemChangeInfoList.Count; i++)
                    {
                        var item = AcUserInfo._netData_inventory._itemList.Where(data => data._uId == inMsg._itemChangeInfoList[i]._itemUId).FirstOrDefault();

                        if (item == null && inMsg._itemChangeInfoList[i]._count != 0)
                        {
                            item = new AcNetData_ItemInfo();
                            item._uId = inMsg._itemChangeInfoList[i]._itemUId;
                            item._itemDataId = inMsg._itemChangeInfoList[i]._itemDataId;
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            item._timeLimitOn = inMsg._itemChangeInfoList[i]._timeLimitOn;
                            item._timeLimitEndDate = inMsg._itemChangeInfoList[i]._timeLimitEndDate;

                            AcUserInfo._netData_inventory._itemList.Add(item);
                            PlayerDataManager.Instance.AddNewItem(item._uId);
                        }
                        else if (item != null && inMsg._itemChangeInfoList[i]._count == 0)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                            AcUserInfo._netData_inventory._itemList.Remove(item);
                            PlayerDataManager.Instance.RemoveNewItem(item._uId);
                        }
                        else if (item != null)
                        {
                            item._count = inMsg._itemChangeInfoList[i]._count;
                        }
                    }
                }

                //
                if (inMsg._writeString.Contains("/attendanceset") == true)
                {
                    AcUserInfo._netData_user._lastAttendanceDate = inMsg._dateTime;
                    AcUserInfo._netData_user._attendanceAccumulateCount = inMsg._integerValue;
                }
                
            }
        });
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 슬랙
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 슬랙 메시지 보내기

    class AsSlackNotifyMessage_Body
    {
        public List<AsSlackNotifyMessage_Attachment> attachments = new List<AsSlackNotifyMessage_Attachment>();
    }

    class AsSlackNotifyMessage_Attachment
    {
        public string fallback;
        public string author_name;
        public string title;
        public string text;
        public string color;
    }

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 로그인 보안 실패 로그 저장 요청
    public virtual IEnumerator SendPacket_req_slackMessage(string channelId, string boardColor, string authorName, string title, string message)
    {
        AsSlackNotifyMessage_Attachment attachment = new AsSlackNotifyMessage_Attachment();
        attachment.fallback = "Plan a vacation";
        attachment.author_name = authorName;
        attachment.title = title;
        attachment.text = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss") + "\n" + message;
        attachment.color = boardColor;

        AsSlackNotifyMessage_Body sendPacket = new AsSlackNotifyMessage_Body();
        sendPacket.attachments.Add(attachment);

        byte[] bytes = Encoding.ASCII.GetBytes(Newtonsoft.Json.JsonConvert.SerializeObject(sendPacket));

        using (UnityWebRequest www = new UnityWebRequest("https://hooks.slack.com/services/" + channelId, UnityWebRequest.kHttpVerbPOST))
        {
            UploadHandlerRaw uH = new UploadHandlerRaw(bytes);
            DownloadHandlerBuffer dH = new DownloadHandlerBuffer();

            www.uploadHandler = uH;
            www.downloadHandler = dH;
            www.SetRequestHeader("Content-Type", "application/json");
            yield return www.SendWebRequest();

            if (www.isHttpError || www.isNetworkError)
            {
                Debug.Log(www.error);
            }
            else
            {
                Debug.Log(www.ToString());
                Debug.Log(www.downloadHandler.text);
            }
        }
    }

    #endregion
}
