
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// Account Log
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

//----------------------------------------------------------------
using System;

public class AsLog_Account : AsLog_Base
{
    public long UserUId { get; set; }
    public byte OS { get; set; }
    public string SystemLanguageType { get; set; }
    public string MacAddress { get; set; }
    public string DeviceCode { get; set; }
    public byte AccountCode { get; set; }
    public long StartDiamond { get; set; }
    public long StartLP { get; set; }
    public long StartChip { get; set; }

    public AsLog_Account() { _mainLogType = 1; _subLogType = 1; }
}

//----------------------------------------------------------------
public class AsLog_Login : AsLog_Base
{
    public long UserUId { get; set; }
    public byte OS { get; set; }
    public string OSVersion { get; set; }
    public string SystemLanguageType { get; set; }
    public string DeviceCode { get; set; }
    public byte AccountCode { get; set; }
    public float ClientVersion { get; set; }
    public string MacAddress { get; set; }

    public AsLog_Login() { _mainLogType = 1; _subLogType = 2; }
}

//----------------------------------------------------------------
public class AsLog_Logout : AsLog_Base
{
    public long UserUId { get; set; }
    public string MACAddress { get; set; }
    public string DeviceCode { get; set; }
    public eUserLogOutType LogoutType { get; set; }
    public eLanguageType LanguageType { get; set; }
    public byte OptionPushStates { get; set; }
    public long LastTotalChip { get; set; }

    public AsLog_Logout() { _mainLogType = 1; _subLogType = 3; }
}

//----------------------------------------------------------------
public class AsLog_Patch : AsLog_Base
{
    public float BeforeVersion { get; set; }
    public float AfterVersion { get; set; }
    public string EndDateTime { get; set; }
    public string DeviceCode { get; set; }
    public byte PatchRetryCount { get; set; }
    public byte ErrorType { get; set; }

    public AsLog_Patch() { _mainLogType = 1; _subLogType = 4; }
}

//----------------------------------------------------------------
public class AsLog_AccountLink : AsLog_Base
{
    public long UserUId { get; set; }
    public eAccountLinkType AccountLinkType { get; set; }
    public int TransitionDay { get; set; }
    public long RewardChip { get; set; }
    public long BeforeChip { get; set; }
    public long AfterChip { get; set; }
    public string DeviceCode { get; set; }
    public string MacAddress { get; set; }

    public AsLog_AccountLink() { _mainLogType = 1; _subLogType = 5; }
}

//----------------------------------------------------------------
public class AsLog_ProfileRegister : AsLog_Base
{
    public long UserUId { get; set; }
    public int TransitionDay { get; set; }
    public string NickName { get; set; }
    public int AvatarDataId { get; set; }
    public int PictureDataId { get; set; }
    public long BeforeChip { get; set; }
    public long AfterChip { get; set; }
    public long RewardChip { get; set; }

    public AsLog_ProfileRegister() { _mainLogType = 1; _subLogType = 6; }
}