//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// Base Log
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

using System;

public class AsLog_Json
{
    public DateTime _dateTime;
    public byte _mainLogType;
    public byte _subLogType;
    public string _logStr;
}

public class AsLog_Base
{
#if UNITY_EDITOR || UNITY_ANDROID || UNITY_IOS || UNITY_WEBGL
#else
    [Newtonsoft.Json.JsonIgnore]
#endif
    public DateTime _dateTime;

#if UNITY_EDITOR || UNITY_ANDROID || UNITY_IOS || UNITY_WEBGL
#else
    [Newtonsoft.Json.JsonIgnore]
#endif
    public byte _mainLogType;

#if UNITY_EDITOR || UNITY_ANDROID || UNITY_IOS || UNITY_WEBGL
#else
    [Newtonsoft.Json.JsonIgnore]
#endif
    public byte _subLogType;

    public AsLog_Base() { _dateTime = DateTime.Now; }

#if !ADMINTOOL
    //----------------------------------------------------------------
    public virtual AcNetDataCS_reqLogSave CreateRequestPacket()
    {
        var reqPacket = new AcNetDataCS_reqLogSave();
        reqPacket._dateTime = _dateTime;
        reqPacket._mainLogType = _mainLogType;
        reqPacket._subLogType = _subLogType;

#if UNITY_EDITOR || UNITY_ANDROID || UNITY_IOS || UNITY_WEBGL
        reqPacket._logStr = UnityEngine.JsonUtility.ToJson(this);
#else
        reqPacket._logStr = Newtonsoft.Json.JsonConvert.SerializeObject(this);
#endif

        return reqPacket;
    }

    //----------------------------------------------------------------
    public string CreateLogStr()
    {
        var resultStr = "";

#if UNITY_EDITOR || UNITY_ANDROID || UNITY_IOS || UNITY_WEBGL
        resultStr = UnityEngine.JsonUtility.ToJson(this);
#else
        resultStr = Newtonsoft.Json.JsonConvert.SerializeObject(this);
#endif
        return resultStr;
    }

#endif

    //----------------------------------------------------------------
    public string CreateLogJson()
    {
        var resultStr = "";

        AsLog_Json logJson = new AsLog_Json();
        logJson._dateTime = _dateTime;
        logJson._mainLogType = _mainLogType;
        logJson._subLogType = _subLogType;
        logJson._logStr = Newtonsoft.Json.JsonConvert.SerializeObject(this);

        resultStr = Newtonsoft.Json.JsonConvert.SerializeObject(logJson);

        return resultStr;
    }
}
