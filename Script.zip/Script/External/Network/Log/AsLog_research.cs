using System.Collections.Generic;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// Research Log
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

//----------------------------------------------------------------
public class AsLog_Research : AsLog_Base
{
    public long UserUId { get; set; }
    public eResearchType ResearchType { get; set; }
    public int ResearchIndex { get; set; }
    public int AnswerNumber { get; set; }
    public string AnswerString { get; set; }
    public long RewardChip { get; set; }
    public long BeforeMainChip { get; set; }
    public long AfterMainChip { get; set; }
    public int RewardItemIndex { get; set; }

    public List<AsLog_ItemAcquireItemInfo> ItemAcuireInfo { get; set; }

    public AsLog_Research() { _mainLogType = 7; _subLogType = 1; ItemAcuireInfo = new List<AsLog_ItemAcquireItemInfo>(); }
}

//----------------------------------------------------------------
public class AsLog_ResearchEndLackChipReward : AsLog_Base
{
    public long UserUId { get; set; }
    public long RewardChip { get; set; }
    public long BeforeMainChip { get; set; }
    public long AfterMainChip { get; set; }

    public AsLog_ResearchEndLackChipReward() { _mainLogType = 7; _subLogType = 2; }
}