using System.Collections.Generic;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// Item Log
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

//----------------------------------------------------------------

public class AsLog_ItemAcquireItemInfo
{
    public string ItemUId { get; set; }
    public long BeforeItemValue { get; set; }
    public long AfterItemValue { get; set; }
}

public class AsLog_ItemAcquire : AsLog_Base
{
    public long UserUId { get; set; }
    public eLogItemEventType RootEventType { get; set; }
    public eLogItemEventType ParentEventType { get; set; }
    public eItemType ItemType { get; set; }
    public int ItemSubType { get; set; }
    public int ItemIndex { get; set; }
    public long AcquireValue { get; set; }
    public string ParentUId { get; set; }
    public int ParentDataId { get; set; }
    public string ItemUId { get; set; }
    public long BeforeItemValue { get; set; }
    public long AfterItemValue { get; set; }

    public AsLog_ItemAcquire() { _mainLogType = 3; _subLogType = 1; }
}

//----------------------------------------------------------------
public class AsLog_ItemRandomBoxItemInfo
{
    public int ItemIndex { get; set; }
    public long ItemValue { get; set; }
}

public class AsLog_ItemRandomBox : AsLog_Base
{
    public long UserUId { get; set; }
    public string RandomBoxUId { get; set; }
    public eLogItemEventType EventType { get; set; }
    public int RewardItemIndex { get; set; }
    public eItemType NeedGoodsType { get; set; }
    public int NeedGoodsItemIndex { get; set; }
    public long NeedGoodsItemValue { get; set; }
    public long BeforeNeedGoodsValue { get; set; }
    public long AfterNeedGoodsValue { get; set; }

    public AsLog_ItemRandomBox() { _mainLogType = 3; _subLogType = 4; }
}

public class AsLog_ShopBuy : AsLog_Base
{
    public long UserUId { get; set; }
    public string ShopBuyUId { get; set; }
    public string FromString { get; set; }
    public eShopType ShopType { get; set; }
    public int ShopPaymentId { get; set; }
    public int ShopBaseId { get; set; }
    public eStoreType StoreType { get; set; }
    public eNeedGoodsType NeedGoodsType { get; set; }
    public eItemType NeedGoodsItemType { get; set; }
    public int NeedGoodsItemIndex { get; set; }
    public long NeedGoodsItemValue { get; set; }
    public long BeforeNeedGoodsValue { get; set; }
    public long AfterNeedGoodsValue { get; set; }

    public long RewardItemIndex { get; set; }
    public long RewardItemValue { get; set; }
    public eItemType RewardItemType { get; set; }
    public bool FirstPayment { get; set; }

    public AsLog_ShopBuy() { _mainLogType = 3; _subLogType = 5; }
}

//----------------------------------------------------------------
public class AsLog_ItemSellItemInfo
{
    public string ItemUId { get; set; }
    public long BeforeItemValue { get; set; }
    public long AfterItemValue { get; set; }
}

public class AsLog_ItemSell : AsLog_Base
{
    public long UserUId { get; set; }
    public eItemType ItemType { get; set; }
    public int ItemSubType { get; set; }
    public int ItemIndex { get; set; }
    public string ItemUID { get; set; }
    public long ItemSellChip { get; set; }
    public long ItemSellValue{ get; set; }
    public long BeforeItemValue { get; set; }
    public long AfterItemValue { get; set; }
    public long AllSellPrice { get; set; }
    public long BeforeChipValue { get; set; }
    public long AfterChipValue { get; set; }

    public List<AsLog_ItemSellItemInfo> ItemSellInfo { get; set; }

    public AsLog_ItemSell() { _mainLogType = 3; _subLogType = 2; ItemSellInfo = new List<AsLog_ItemSellItemInfo>(); }
}

//----------------------------------------------------------------
public class AsLog_ItemCraftMatarialInfo
{
    public string MaterialItemUID { get; set; }
    public long BeforeMaterialItemvalue { get; set; }
    public long AfterMaterialItemvalue { get; set; }
}

public class AsLog_ItemCraftResultInfo
{
    public string ResultCraftItemUID { get; set; }
    public long BeforeResultCraftItemValue { get; set; }
    public long AfterResultCraftItemValue { get; set; }
}

public class AsLog_ItemCraft : AsLog_Base
{
    public long UserUId { get; set; }
    public int MaterialItemIndex { get; set; }
    public int CraftIndex { get; set; }
    public long CraftNeedValue { get; set; }
    public int ResultCraftItemIndex { get; set; }
    public long ResultCraftItemValue { get; set; }

    public List<AsLog_ItemCraftMatarialInfo> ItemCraftMatarialInfo { get; set; }
    public List<AsLog_ItemCraftResultInfo> ItemCraftResultInfo { get; set; } 

    public AsLog_ItemCraft() { _mainLogType = 3; _subLogType = 3; ItemCraftMatarialInfo = new List<AsLog_ItemCraftMatarialInfo>(); ItemCraftResultInfo = new List<AsLog_ItemCraftResultInfo>(); }
}