using System;
using System.Collections.Generic;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// Common Log
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

//----------------------------------------------------------------
public class AsLog_MaximumCurrentUser : AsLog_Base
{
    public long UserCount { get; set; }

    public AsLog_MaximumCurrentUser() { _mainLogType = 8; _subLogType = 1; }
}


//----------------------------------------------------------------
public class AsLog_LatancyLogin : AsLog_Base
{
    public long LatancyUId { get; set; }
    public long UserUId { get; set; }
    public string DeviceInfo { get; set; }
    public string Location { get; set; }
    public string NetworkInfo { get; set; }

    public AsLog_LatancyLogin() { _mainLogType = 8; _subLogType = 2; }
}

//----------------------------------------------------------------
public class AsLog_LatancyLivePacket : AsLog_Base
{
    public double M { get; set; }   // �ɸ� �и�����
}

//----------------------------------------------------------------
public class AsLog_LatancyLogout : AsLog_Base
{
    public long LatancyUId { get; set; }
    public long UserUId { get; set; }
    public long PacketCount { get; set; }

    public List<AsLog_LatancyLivePacket> PacketInfoList { get; set; }

    public AsLog_LatancyLogout() { _mainLogType = 8; _subLogType = 3; PacketInfoList = new List<AsLog_LatancyLivePacket>(); }
}

//----------------------------------------------------------------
public class AsLog_ServerTotalChip : AsLog_Base
{
    public long TotalChip { get; set; }

    public AsLog_ServerTotalChip() { _mainLogType = 8; _subLogType = 4; }
}

//----------------------------------------------------------------
public class AsLog_ServerTotalDiamond : AsLog_Base
{
    public long TotalDiamond { get; set; }

    public AsLog_ServerTotalDiamond() { _mainLogType = 8; _subLogType = 5; }
}

//----------------------------------------------------------------
public class AsLog_DailyReward : AsLog_Base
{
    public long UserUId { get; set; }
    public long RewardChip { get; set; }

    public AsLog_DailyReward() { _mainLogType = 8; _subLogType = 6; }
}

//----------------------------------------------------------------
public class AsLog_ButtonClick : AsLog_Base
{
    public long _userUId;
    public eButtonType _buttonType;
    public int _value;

    public AsLog_ButtonClick() { _mainLogType = 8; _subLogType = 7; }

#if !ADMINTOOL
    //----------------------------------------------------------------
    public override AcNetDataCS_reqLogSave CreateRequestPacket()
    {
        var reqPacket = new AcNetDataCS_reqLogSave();
        reqPacket._dateTime = _dateTime;
        reqPacket._mainLogType = _mainLogType;
        reqPacket._subLogType = _subLogType;

#if UNITY_EDITOR || UNITY_ANDROID || UNITY_IOS || UNITY_WEBGL
        reqPacket._logStr = UnityEngine.JsonUtility.ToJson(this);
#else
        reqPacket._logStr = Newtonsoft.Json.JsonConvert.SerializeObject(this);
#endif

        return reqPacket;
    }
#endif
}

//----------------------------------------------------------------
public class AsLog_ADViewReward : AsLog_Base
{
    public long UserUId { get; set; }
    public long BeforeValue { get; set; }
    public long ChangeValue { get; set; }
    public long AfterValue { get; set; }

    public AsLog_ADViewReward() { _mainLogType = 8; _subLogType = 8; }
}

//----------------------------------------------------------------
public class AsLog_EmoticonUse : AsLog_Base
{
    public long UserUId { get; set; }
    public int EmoticonDataId { get; set; }
    public long BeforeValue { get; set; }
    public long ChangeValue { get; set; }
    public long AfterValue { get; set; }

    public AsLog_EmoticonUse() { _mainLogType = 8; _subLogType = 9; }
}

//----------------------------------------------------------------
public class AsLog_ServerCurrentUser : AsLog_Base
{
    public long UserCount { get; set; }

    public AsLog_ServerCurrentUser() { _mainLogType = 8; _subLogType = 10; }
}

//----------------------------------------------------------------
public class AsLog_LoginSecurityFail : AsLog_Base
{
    public string MACAddress { get; set; }
    public eLoginSecurityFailType LoginSecurityFailType { get; set; }

    public AsLog_LoginSecurityFail() { _mainLogType = 8; _subLogType = 11; }
}

//----------------------------------------------------------------
public class AsLog_TermsOfService : AsLog_Base
{
    public string MACAddress { get; set; }
    public eTermsOfServiceLogType TermsOfServiceLogType { get; set; }

    public AsLog_TermsOfService() { _mainLogType = 8; _subLogType = 12; }
}

//----------------------------------------------------------------
public class AsLog_ItemCheating : AsLog_Base
{
    public long UserUId { get; set; }
    public int ItemIndex { get; set; }
    public long ItemCountOriginal { get; set; }
    public long ItemCountChange { get; set; }
    public string StringInfo { get; set; }

    public AsLog_ItemCheating() { _mainLogType = 8; _subLogType = 13; }
}

//----------------------------------------------------------------
public class AsLog_SlotMachinePlay : AsLog_Base
{
    public long UserUId { get; set; }
    public int SlotMachineDataId { get; set; }
    public eSlotMachineType SlotMachineType { get; set; }
    public eItemType NeedItemType { get; set; }
    public eGoodsType NeedItemGoodsType { get; set; }
    public long NeedItemBeforeValue { get; set; }
    public long NeedItemValue { get; set; }
    public long NeedItemAfterValue { get; set; }
    public string MadeRecord { get; set; }
    public long RewardUId { get; set; }
    public int AttendanceBonusDay { get; set; }
    public int AttendanceBonusValue { get; set; }

    public AsLog_SlotMachinePlay() { _mainLogType = 12; _subLogType = 1; }
}

//----------------------------------------------------------------
public class AsLog_SlotMachineReward : AsLog_Base
{
    public long UserUId { get; set; }
    public eSlotMachineType SlotMachineType { get; set; }
    public long RewardUId { get; set; }
    public eItemType RewardItemType { get; set; }
    public eGoodsType RewardItemGoodsType { get; set; }
    public long RewardBeforeValue { get; set; }
    public long RewardValue { get; set; }
    public long RewardAfterValue { get; set; }

    public bool FreeMode { get; set; }
    public int RewardDayCount { get; set; }

    public AsLog_SlotMachineReward() { _mainLogType = 12; _subLogType = 2; }
}

//----------------------------------------------------------------
public class AsLog_GaneshaTip : AsLog_Base
{
    public long UserUId { get; set; }
    public long TipValue { get; set; }
    public long BeforeValue { get; set; }
    public long AfterValue { get; set; }
    public long BeforePocketValue { get; set; }
    public long AfterPocketValue { get; set; }

    public AsLog_GaneshaTip() { _mainLogType = 13; _subLogType = 1; }
}

//----------------------------------------------------------------
public class AsLog_GaneshaPocketConvertLP : AsLog_Base
{
    public long UserUId { get; set; }

    public long BeforePocketValue { get; set; }
    public long ChangePocketValue { get; set; }
    public long AfterPocketValue { get; set; }

    public long BeforeLuckyPoint { get; set; }
    public long ChangeLuckyPoint { get; set; }
    public long AfterLuckyPoint { get; set; }

    public AsLog_GaneshaPocketConvertLP() { _mainLogType = 13; _subLogType = 2; }
}

//----------------------------------------------------------------
public class AsLog_PostSend : AsLog_Base
{
    public long UserUId { get; set; }
    public string PostUId { get; set; }
    public ePostSendType SendType { get; set; }
    public int ItemDataId { get; set; }
    public long ItemCount { get; set; }
    public eItemType ItemType { get; set; }
    public ePostPeriodType PeriodType { get; set; }
    public DateTime EndDatetime { get; set; }

    public AsLog_PostSend() { _mainLogType = 14; _subLogType = 1; }
}

//----------------------------------------------------------------
public class AsLog_PostItemAcquire : AsLog_Base
{
    public long UserUId { get; set; }
    public string PostUId { get; set; }
    public ePostSendType SendType { get; set; }
    public int ItemDataId { get; set; }
    public long ItemCount { get; set; }
    public eItemType ItemType { get; set; }

    public AsLog_PostItemAcquire() { _mainLogType = 14; _subLogType = 2; }
}

//----------------------------------------------------------------
public class AsLog_PostRemove : AsLog_Base
{
    public long UserUId { get; set; }
    public string PostUId { get; set; }
    public ePostSendType SendType { get; set; }
    public int ItemDataId { get; set; }
    public long ItemCount { get; set; }
    public eItemType ItemType { get; set; }
    public ePostPeriodType PeriodType { get; set; }
    public DateTime EndDatetime { get; set; }

    public AsLog_PostRemove() { _mainLogType = 14; _subLogType = 3; }
}