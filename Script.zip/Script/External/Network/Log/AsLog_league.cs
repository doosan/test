using System.Collections.Generic;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// League Log
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

//----------------------------------------------------------------

public class AsLog_LeagueStartUserInfo
{
    public long UserUId { get; set; }
    public int Rank { get; set; }
    public long LP { get; set; }
}

public class AsLog_LeagueStart : AsLog_Base
{
    public long LeagueId { get; set; }
    public string GroupId { get; set; }

#if !UNITY_EDITOR && !UNITY_ANDROID && !UNITY_IOS && !UNITY_WEBGL
    [Newtonsoft.Json.JsonProperty(PropertyName = "LGT")]
#endif
    public eLeagueGradeType LeagueGradeType { get; set; }

    public int UserCount { get; set; }

    public List<AsLog_LeagueStartUserInfo> UserInfo { get; set; }

    public AsLog_LeagueStart() { _mainLogType = 4; _subLogType = 1; UserInfo = new List<AsLog_LeagueStartUserInfo>(); }
}

//----------------------------------------------------------------
public class AsLog_LeagueEndUserInfo
{
    public long UserUId { get; set; }
    public int Rank { get; set; }
    public long Point { get; set; }
    public long LuckyPoint { get; set; }
    public long SavePrize { get; set; }
    public string RGPrizeChip { get; set; }
    public int RGItemId { get; set; }
    public long RGItemValue { get; set; }
}

public class AsLog_LeagueEnd : AsLog_Base
{
    public long LeagueId { get; set; }
    public string GroupId { get; set; }
#if !UNITY_EDITOR && !UNITY_ANDROID && !UNITY_IOS && !UNITY_WEBGL
    [Newtonsoft.Json.JsonProperty(PropertyName = "LGT")]
#endif
    public eLeagueGradeType LeagueGradeType { get; set; }
    public int UserCount { get; set; }
    public long SavePrize { get; set; }
    public long TotalGivePrize { get; set; }        // ������ �����ϱ�ε� ���
    public long TotalGiveLuckyPoint { get; set; }        // ������ �����ϱ�ε� ��Ű����Ʈ

    public List<AsLog_LeagueEndUserInfo> UserInfo { get; set; }

    public AsLog_LeagueEnd() { _mainLogType = 4; _subLogType = 2; UserInfo = new List<AsLog_LeagueEndUserInfo>(); }
}

//----------------------------------------------------------------
public class AsLog_LeagueRewardAcquire : AsLog_Base
{
    public long LeagueId { get; set; }
    public long UserUId { get; set; }
    public eLeagueGradeType UserLeagueGradeType { get; set; }
    public int UserRank { get; set; }
    public long RGPrizeChip { get; set; }
    public int RGItemId { get; set; }
    public long RGItemValue { get; set; }
    public long BeforeChip { get; set; }
    public long AfterChip { get; set; }
    public long RGLuckyPoint { get; set; }
    public long BeforeLuckyPoint { get; set; }
    public long AfterLuckyPoint { get; set; }

    public AsLog_LeagueRewardAcquire() { _mainLogType = 4; _subLogType = 3; }
}