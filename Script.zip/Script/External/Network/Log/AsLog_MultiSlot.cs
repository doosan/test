using System;
using System.Collections.Generic;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// MultiSlot Log
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

//----------------------------------------------------------------

public class AsLog_MultiSlotChargeInfo : AsLog_Base
{
    public long UserUId { get; set; }
    public int SlotNumber { get; set; }
    public eMultiSlotChargeType ChargeType { get; set; }
    public int ItemIndex { get; set; }
    public int ChargeTime { get; set; }
    public DateTime BeforeChargeTime { get; set; }
    public DateTime AfterChargeTime { get; set; }
    public long BeforeItemValue { get; set; }
    public long AfterItemValue { get; set; }

    public AsLog_MultiSlotChargeInfo() { _mainLogType = 11; _subLogType = 1; }
}