using System;
using System.Collections.Generic;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// Game Log
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

//----------------------------------------------------------------
public class AsLog_RoomPlay : AsLog_Base
{
    public long RoomId { get; set; }
    public int RoomInfoIndex { get; set; }
    public long BootChip { get; set; }
    public string GameGuid { get; set; }
    public eGameType GameMode { get; set; }
    public eRoomOpenType RoomOpenType { get; set; }
    public string EndDateTime { get; set; }
    public int LastTurn { get; set; }
    public long AllBatChip { get; set; }
    public long DealerCost { get; set; }
    public long InvalidDivisionChip { get; set; }
    public long InvalidDealerChip { get; set; }
    public long GivingWinnerChip { get; set; }
    public string WinnerPlayerUId { get; set; }
    public byte PlayerCount { get; set; }
    public List<long> UserUIdList { get; set; } 
    public string PlayRecode { get; set; }

#if UNITY_EDITOR || UNITY_ANDROID || UNITY_IOS || UNITY_WEBGL
    //[System.NonSerialized] 
#else
    [Newtonsoft.Json.JsonIgnore]
#endif
    public List<AsLog_UserPlay> UserPlayList { get; set; }

    public AsLog_RoomPlay() { _mainLogType = 2; _subLogType = 1; UserUIdList = new List<long>(); UserPlayList = new List<AsLog_UserPlay>(); }

    public void Reset()
    {
        GameGuid = "";
        EndDateTime = "";
        LastTurn = 0;
        AllBatChip = 0;
        DealerCost = 0;
        GivingWinnerChip = 0;
        WinnerPlayerUId = "";
        PlayerCount = 0;
        UserUIdList.Clear();
        PlayRecode = "";
        UserPlayList.ForEach(data => data.Reset());
    }
}

//----------------------------------------------------------------
public class AsLog_UserPlay : AsLog_Base
{
    public long UserUId { get; set; }
    public eLeagueGradeType UserLGType { get; set; }    // League Grade
    public string EndDateTime { get; set; }
    public double MeanTurnTime { get; set; }     // ��
    public int GameSlotId { get; set; }
    public int AutoType { get; set; }
    public eSetAutoSettingType AutoSettingType { get; set; }
    public int MainRoomType { get; set; }
    public long RoomId { get; set; }
    public int RoomInfoIndex { get; set; }
    public string GameGuid { get; set; }
    public eGameType GameType { get; set; }
    public eGameResultType GameResultType { get; set; }
    public eGameResultReasonType GameResultReasonType { get; set; }
    public long BeforeChip { get; set; }
    public long AfterChip { get; set; }
    public long BeforeTotalChip { get; set; }
    public long AfterTotalChip { get; set; }
    public long WinLoseChip { get; set; }
    public long DealerCost { get; set; }
    public long DealerTip { get; set; }
    public long TotalBettingChip { get; set; }
    public long GetLeaguePoint { get; set; }
    public long GetLuckyPoint { get; set; }
    public long BeforeLuckyPoint { get; set; }
    public long AfterLuckyPoint { get; set; }
    public long SavePrizePoolChip { get; set; }
    public string DepositChip { get; set; }
    public string BlindBettingInfo { get; set; }
    public int SeenTurn { get; set; }
    public string FoldHand { get; set; }
    public string BettingHand { get; set; }
    public string SideShowHand { get; set; }
    public string SideShowAcceptHand { get; set; }
    public string SideShowRefuseHand { get; set; }
    public string AllInHand { get; set; }
    public string AllInAcceptHand { get; set; }
    public string AllInRefuseHand { get; set; }
    public string ShowHand { get; set; }

#if UNITY_EDITOR || UNITY_ANDROID || UNITY_IOS || UNITY_WEBGL
    //[System.NonSerialized] 
#else
    [Newtonsoft.Json.JsonIgnore]
#endif
    public AsLog_MadeWinLose MadeWinLose { get; set; }

#if UNITY_EDITOR || UNITY_ANDROID || UNITY_IOS || UNITY_WEBGL
    //[System.NonSerialized] 
#else
    [Newtonsoft.Json.JsonIgnore]
#endif
    public AsLog_AutoWinLose AutoWinLose { get; set; }


    public AsLog_UserPlay() { _mainLogType = 2; _subLogType = 2; MadeWinLose = new AsLog_MadeWinLose(); AutoWinLose = new AsLog_AutoWinLose(); }

    public void Reset()
    {
        UserUId = 0;
        UserLGType = eLeagueGradeType.TYPE_LUCKY;
        EndDateTime = "";
        MeanTurnTime = 0;
        GameSlotId = 0;
        AutoType = 0;
        AutoSettingType = eSetAutoSettingType.TYPE_CUSTOM;
        GameGuid = "";
        GameResultType = eGameResultType.TYPE_LOSE;
        GameResultReasonType = eGameResultReasonType.TYPE_NONE;
        BeforeChip = 0;
        AfterChip = 0;
        BeforeTotalChip = 0;
        AfterTotalChip = 0;
        WinLoseChip = 0;
        DealerCost = 0;
        DealerTip = 0;
        TotalBettingChip = 0;
        GetLeaguePoint = 0;
        GetLuckyPoint = 0;
        BeforeLuckyPoint = 0;
        AfterLuckyPoint = 0;

        SavePrizePoolChip = 0;
        DepositChip = "";
        BlindBettingInfo = "";
        SeenTurn = 0;
        FoldHand = "";
        BettingHand = "";
        SideShowHand = "";
        SideShowAcceptHand = "";
        SideShowRefuseHand = "";
        AllInHand = "";
        AllInAcceptHand = "";
        AllInRefuseHand = "";
        ShowHand = "";
    }
}


//----------------------------------------------------------------
public class AsLog_MadeWinLose : AsLog_Base
{
    public eGameType GameMode { get; set; }
    public string Made { get; set; }
    public byte WinLoseType { get; set; }

    public AsLog_MadeWinLose() { _mainLogType = 2; _subLogType = 3; }
}

//----------------------------------------------------------------
public class AsLog_AutoWinLose : AsLog_Base
{
    public eGameType GameMode { get; set; }
    public string AutoSet { get; set; }
    public byte WinLoseType { get; set; }

    public AsLog_AutoWinLose() { _mainLogType = 2; _subLogType = 4; }
}

////----------------------------------------------------------------
//public class AsLog_BotChangeChip : AsLog_Base
//{
//    public eGameType GameMode { get; set; }
//    public long ChangeChip { get; set; }

//    public AsLog_BotChangeChip() { _mainLogType = 2; _subLogType = 5; }
//}

//----------------------------------------------------------------
public class AsLog_LeaguePointAccumulate : AsLog_Base
{
    public long UserUId { get; set; }
    public int MultiSlotNumber { get; set; }
    public long TotalBettingChip { get; set; }
    public long BeforeLuckyPoint { get; set; }
    public long AfterLuckyPoint { get; set; }
    public long GetLuckyPoint { get; set; }

    public DateTime LeagueStartDateTime { get; set; }
    public eLeagueGradeType LeagueGradeType { get; set; }
    public long GetPrizeChip { get; set; }

    public AsLog_LeaguePointAccumulate() { _mainLogType = 2; _subLogType = 6; }
}

//----------------------------------------------------------------
public class AsLog_DealerTip : AsLog_Base
{
    public long UserUId { get; set; }
    public long RoomIndex { get; set; }
    public int RoomDataId { get; set; }
    public long DealerTip { get; set; }
    public long BeforeChip { get; set; }
    public long AfterChip { get; set; }

    public AsLog_DealerTip() { _mainLogType = 2; _subLogType = 7; }
}