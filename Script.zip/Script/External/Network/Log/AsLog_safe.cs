using System.Collections.Generic;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// Safe Log
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

//----------------------------------------------------------------
public class AsLog_SafeEquipAfterSafeItemInfo
{
    public string AfterSafeItemUId { get; set; }
    public long BeforeItemValue { get; set; }
    public long AfterItemValue { get; set; }
}

public class AsLog_SafeEquip : AsLog_Base
{
    public long UserUId { get; set; }
    public int SafeNumber { get; set; }
    //public eSafeType BeforeSafeType { get; set; }
    public long BeforeRestTime { get; set; }
    public long BeforeMaxVolume { get; set; }
    public int AfterSafeItemIndex { get; set; }
    public List<AsLog_SafeEquipAfterSafeItemInfo> AfterSafeItemInfo { get; set; }
    //public eSafeType AfterSafeType { get; set; }

    public long SafeMaxVolume { get; set; }
    public long SafeMaxChargeChip { get; set; }
    public long RestTime { get; set; }
    public long BeforeInSafeChip { get; set; }
    public long AutoWithdrawOverChip { get; set; }
    public double WithdrawTexRate { get; set; }
    public long WithdrawTexChip { get; set; }
    public long AfterInSafeChip { get; set; }

    public AsLog_SafeEquip() { _mainLogType = 5; _subLogType = 1; AfterSafeItemInfo = new List<AsLog_SafeEquipAfterSafeItemInfo>(); }
}

//----------------------------------------------------------------
public class AsLog_SafeChargeAfterSafeItemInfo
{
    public string AfterSafeItemUId { get; set; }
    public long BeforeItemValue { get; set; }
    public long AfterItemValue { get; set; }
}

public class AsLog_SafeCharge : AsLog_Base
{
    public long UserUId { get; set; }
    public int SafeNumber { get; set; }
    //public eSafeType ChargeSafeType { get; set; }
    public long MaxRestTime { get; set; }
    public long NowRestTime { get; set; }
    public int ChargeSafeItemIndex { get; set; }
    public long ChargeRestTime { get; set; }
    public long ChargeItemValue { get; set; }
    public long AllChargeTime { get; set; }
    public long AfterRestTime { get; set; }

    public List<AsLog_SafeChargeAfterSafeItemInfo> AfterSafeItemInfo { get; set; }

    public AsLog_SafeCharge() { _mainLogType = 5; _subLogType = 2; AfterSafeItemInfo = new List<AsLog_SafeChargeAfterSafeItemInfo>(); }
}

//----------------------------------------------------------------
public class AsLog_SafeDeposit : AsLog_Base
{
    public long UserUId { get; set; }
    public int SafeNumber { get; set; }
    //public eSafeType SafeType { get; set; }
    public long MaxVolume { get; set; }
    public long MaxChargeVolume { get; set; }
    public long BeforeInSafeChip { get; set; }
    public long BeforeMainChip { get; set; }
    public long ChargeChip { get; set; }
    public long AfterInsafeChip { get; set; }
    public long AfterMainChip { get; set; }

    public AsLog_SafeDeposit() { _mainLogType = 5; _subLogType = 3; }
}

//----------------------------------------------------------------
public class AsLog_SafeWithdraw : AsLog_Base
{
    public long UserUId { get; set; }
    public int SafeNumber { get; set; }
    //public eSafeType SafeType { get; set; }
    public long MaxVolume { get; set; }
    public long MaxChargeVolume { get; set; }
    public long BeforeInSafeChip { get; set; }
    public long BeforeMainChip { get; set; }
    public long WithdrawChip { get; set; }
    public long AfterInsafeChip { get; set; }
    public long AfterMainChip { get; set; }

    public AsLog_SafeWithdraw() { _mainLogType = 5; _subLogType = 4; }
}