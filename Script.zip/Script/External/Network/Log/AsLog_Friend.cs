using System;
using System.Collections.Generic;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// Friend Log
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

//----------------------------------------------------------------
public class AsLog_FriendRecommendInfo : AsLog_Base
{
    public long UserUId { get; set; }
    public string InviteCode { get; set; }
    public string DeviceCode { get; set; }
    public long DstUserUId { get; set; }
    public int DstUserInviteTotalCount { get; set; }

    public AsLog_FriendRecommendInfo() { _mainLogType = 10; _subLogType = 1; }
}

//----------------------------------------------------------------
public class AsLog_FriendInviteRewardAcquireInfo : AsLog_Base
{
    public long UserUId { get; set; }
    public int FriendInviteRewardDataId { get; set; }
    public int InviteCount { get; set; }
    public int RewardItemId { get; set; }
    public long RewardItemValue { get; set; }

    public AsLog_FriendInviteRewardAcquireInfo() { _mainLogType = 10; _subLogType = 2; }
}

//----------------------------------------------------------------
public class AsLog_FriendInviteInstallInfo : AsLog_Base
{
    public string DeviceCode { get; set; }
    public string InviteCode { get; set; }

    public AsLog_FriendInviteInstallInfo() { _mainLogType = 10; _subLogType = 3; }
}
