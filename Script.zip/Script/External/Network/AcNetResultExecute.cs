﻿using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Lidgren.Network;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// AcNetResultExcute
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

public class AcNetResultExecute
{
    public static AcNetResultExecute Instance;

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public AcNetResultExecute()
    {
        Instance = this; 
    }

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public void NetResultExecute(eGameResult result)
    {
        // 결과
        //if (result != eGameResult.RESULT_OK)
        //    Debug.Log("NetResult: " + result);

        Func<int, string> getString = ForuOnes.T3.LuckyTeenPatti.Table.LocalizationSentenceTable.Instance.GetString;

        if(result == eGameResult.RESULT_LACKCHIP)
        {
            ForuOnes.T3.LuckyTeenPatti.UIManager.Instance.FinishLoading();
            ForuOnes.T3.LuckyTeenPatti.MessageBoxManager.Instance.OnMessageBoxUI(getString(110010), getString(30011), getString(30010), null, null, true, false);
        }

        else if(result == eGameResult.RESULT_LACKLUCKYPOINT)
        {
            ForuOnes.T3.LuckyTeenPatti.UIManager.Instance.FinishLoading();
            ForuOnes.T3.LuckyTeenPatti.MessageBoxManager.Instance.OnMessageBoxUI(getString(110067), getString(30011), getString(30010), null, null, true, false);
        }

        else if(result == eGameResult.RESULT_LACKDIAMOND)
        {
            ForuOnes.T3.LuckyTeenPatti.UIManager.Instance.FinishLoading();
            ForuOnes.T3.LuckyTeenPatti.MessageBoxManager.Instance.OnMessageBoxUI(getString(110113), getString(30011), getString(30010), null, null, true, false);
        }

        else if(result == eGameResult.RESULT_SAFE_LACKTIME)
        {
            ForuOnes.T3.LuckyTeenPatti.UIManager.Instance.FinishLoading();
            ForuOnes.T3.LuckyTeenPatti.MessageBoxManager.Instance.OnMessageBoxUI(getString(110008), getString(30011), getString(30010), null, null, true, false);
        }

        else if(result == eGameResult.RESULT_SAFE_MAXCHARGECHIP)
        {
            ForuOnes.T3.LuckyTeenPatti.UIManager.Instance.FinishLoading();
            ForuOnes.T3.LuckyTeenPatti.MessageBoxManager.Instance.OnMessageBoxUI(getString(110009), getString(30011), getString(30010), null, null, true, false);
        }
        //else if (result == eGameResult.RESULT_ITEM_DATEEXPIRE)
        //{
        //    ForuOnes.T3.LuckyTeenPatti.UIManager.Instance.FinishLoading();
        //    ForuOnes.T3.LuckyTeenPatti.MessageBoxManager.Instance.OnMessageBoxUI(getString(110107), getString(30011), getString(30010), null, null, true, false);
        //}
    }
}
