using System.Collections.Generic;
using System;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// base
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region base

public class AcHttpData_base : AcNetData_base
{
    public string HashCode { get; set; }
}

#endregion

#region base

public class AcHttpData_reqRoomCount : AcHttpData_base
{
    public int BootChip { get; set; }
}

#endregion

#region ���� �������� ��û

//-----------------------------------------------------------------------------------------------------------------------------------------------------
public class AcNetDataTS_reqUserDisconnect : AcHttpData_base
{
    public long UserUId { get; set; }
}

#endregion