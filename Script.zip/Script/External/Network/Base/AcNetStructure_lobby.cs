using System.Collections.Generic;
using System;
using Lidgren.Network;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region Check ClientVersion

public class AcNetDataCS_reqServerConnectionInfoCheck : AcNetData_base
{
    public float _version;
    public string _mACAddress;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _version = inMsg.ReadFloat();
        _mACAddress = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_version);
        outMsg.Write(_mACAddress);
    }
    #endregion

}

public class AcNetDataSC_resServerConnectionInfoCheck : AcNetData_base
{
    public string _serverCheckString;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);

        _serverCheckString = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);

        outMsg.Write(_serverCheckString);
    }
    #endregion
}

#endregion

#region ���� �ð�

public class AcNetDataCS_reqServerDateTime : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
    }
    #endregion
}

public class AcNetDataSC_resServerDateTime : AcNetData_base
{
    public DateTime _serverDate;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _serverDate = DateTime.Parse(inMsg.ReadString());
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_serverDate.ToString("yyyy-MM-dd HH:mm:ss.fff"));
    }
    #endregion
}

#endregion

#region Ping&Pong

public class AcNetDataCS_reqPing : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSC_resPong : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// �α���
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ���� ����

public class AcNetDataCS_reqAccount : AcNetData_base
{
    public string _userId;

    public eAccountLinkType _accountLinkType;
    public string _nickName;
    public byte _OS;
    public string _systemLanguageType;
    public string _deviceCode;
    public string _macAddress;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userId = inMsg.ReadString();
        _accountLinkType = (eAccountLinkType)inMsg.ReadByte();
        _nickName = inMsg.ReadString();

        _OS = inMsg.ReadByte();
        _systemLanguageType = inMsg.ReadString();
        _deviceCode = inMsg.ReadString();
        _macAddress = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userId);
        outMsg.Write((byte)_accountLinkType);
        outMsg.Write(_nickName);

        outMsg.Write(_OS);
        outMsg.Write(_systemLanguageType);
        outMsg.Write(_deviceCode);
        outMsg.Write(_macAddress);
    }
    #endregion
}

public class AcNetDataSC_resAccount : AcNetData_base
{
    public string _userId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);
        _userId = inMsg.ReadString();
        
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);
        outMsg.Write(_userId);
    }
    #endregion
}

#endregion

#region �α��� ���� �α���


public class AcNetDataCS_reqLSLogin : AcNetData_base
{
    public string _userId;
    public eAccountLinkType _accountLinkType;
    public string _nickName;

    public byte _OS;
    public string _OSVersion;
    public string _systemLanguageType;
    public string _deviceCode;
    public float _clientVersion;
    public string _mACAddress;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userId = inMsg.ReadString();
        _accountLinkType = (eAccountLinkType)inMsg.ReadByte();
        _nickName = inMsg.ReadString();

        _OS = inMsg.ReadByte();
        _OSVersion = inMsg.ReadString();
        _systemLanguageType = inMsg.ReadString();
        _deviceCode = inMsg.ReadString();
        _clientVersion = inMsg.ReadFloat();
        _mACAddress = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userId);
        outMsg.Write((byte)_accountLinkType);
        outMsg.Write(_nickName);

        outMsg.Write(_OS);
        outMsg.Write(_OSVersion);
        outMsg.Write(_systemLanguageType);
        outMsg.Write(_deviceCode);
        outMsg.Write(_clientVersion);
        outMsg.Write(_mACAddress);
    }
    #endregion
}

public class AcNetDataSC_resLSLogin : AcNetData_base
{
    public string _gameServerIP;
    public int _gameServerPort;
    public string _loginToken;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);
        _gameServerIP = inMsg.ReadString();
        _gameServerPort = inMsg.ReadInt32();
        _loginToken = inMsg.ReadString();

    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);
        outMsg.Write(_gameServerIP);
        outMsg.Write(_gameServerPort);
        outMsg.Write(_loginToken);
    }
    #endregion
}

#endregion

#region �α���

public class AcNetDataCS_reqLogin : AcNetData_base
{
    public string _userId;
    public string _loginToken;
    public eAccountLinkType _accoundLinkType;
    public string _nickName;

    public string _deviceCode;
    public string _mACAddress;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        _userId = inMsg.ReadString();
        _loginToken = inMsg.ReadString();
        _accoundLinkType = (eAccountLinkType)inMsg.ReadByte();
        _nickName = inMsg.ReadString();

        _deviceCode = inMsg.ReadString();
        _mACAddress = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        outMsg.Write(_userId);
        outMsg.Write(_loginToken);
        outMsg.Write((byte)_accoundLinkType);
        outMsg.Write(_nickName);

        outMsg.Write(_deviceCode);
        outMsg.Write(_mACAddress);
    }
    #endregion
}

public class AcNetDataSC_resLogin : AcNetData_base
{
    public List<AcNetData_BBSNoticeSimpleInfo> _BBSNoticeInfoList = new List<AcNetData_BBSNoticeSimpleInfo>();
    public List<AcNetData_BBSBannerSimpleInfo> _BBSBannerInfoList = new List<AcNetData_BBSBannerSimpleInfo>();
    public eTOTChampionShipState _tOTChampionShipState;
    public DateTime _tOTChampionShipEndDateTime;
    public int _tOTChampionShipGameModeDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        ListParse(inMsg, _BBSNoticeInfoList);
        ListParse(inMsg, _BBSBannerInfoList);

        _tOTChampionShipState = (eTOTChampionShipState)inMsg.ReadByte();
        if (_tOTChampionShipState == eTOTChampionShipState.STATE_START)
        {
            _tOTChampionShipEndDateTime = DateTime.Parse(inMsg.ReadString());
            _tOTChampionShipGameModeDataId = inMsg.ReadInt32();
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        ListPacking(outMsg, _BBSNoticeInfoList);
        ListPacking(outMsg, _BBSBannerInfoList);

        outMsg.Write((byte)_tOTChampionShipState);
        if (_tOTChampionShipState == eTOTChampionShipState.STATE_START)
        {
            outMsg.Write(_tOTChampionShipEndDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
            outMsg.Write(_tOTChampionShipGameModeDataId);
        }
    }
    #endregion
}

public class AcNetDataSS_resLogin : AcNetData_base
{
    public AcNetData_UserInfo _userInfo = new AcNetData_UserInfo();
    public AcNetData_InventoryInfo _inventoryInfo = new AcNetData_InventoryInfo();
    public AcNetData_PostBoxInfo _postBoxInfo = new AcNetData_PostBoxInfo();
    public List<AcNetData_PaymentInfo> _paymentInfoList = new List<AcNetData_PaymentInfo>();
    public List<AcNetData_MissionInfo> _missionInfoList = new List<AcNetData_MissionInfo>();
    public List<AcNetData_TutorialBaseInfo> _tutorialBaseInfoList = new List<AcNetData_TutorialBaseInfo>();
    public List<AcNetData_TutorialGaneshaInfo> _tutorialGaneshaInfoList = new List<AcNetData_TutorialGaneshaInfo>();
    public string _mACAddress;
    public string _deviceCode;
    public AcNetData_PayTMInfo _payTMInfo = new AcNetData_PayTMInfo();
    public List<AcNetData_PayTMExchangeInfo> _uncompletePayTMExchangeInfoList = new List<AcNetData_PayTMExchangeInfo>();
    public string _loginToken;
    public AcNetData_ShareRewardInfo _shareRewardInfo = new AcNetData_ShareRewardInfo();
    public List<AcNetData_UserEventInfo> _userEventInfoList = new List<AcNetData_UserEventInfo>();
    public List<AcNetData_BuffInfo> _buffInfoList = new List<AcNetData_BuffInfo>();
    public List<AcNetData_UserLimitProductInfo> _userLimitProductInfoList = new List<AcNetData_UserLimitProductInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _userInfo.Parse(inMsg);
            _inventoryInfo.Parse(inMsg);
            _postBoxInfo.Parse(inMsg);
            ListParse(inMsg, _paymentInfoList);
            ListParse(inMsg, _missionInfoList);
            ListParse(inMsg, _tutorialBaseInfoList);
            ListParse(inMsg, _tutorialGaneshaInfoList);
            _mACAddress = inMsg.ReadString();
            _deviceCode = inMsg.ReadString();
            _payTMInfo.Parse(inMsg);
            ListParse(inMsg, _uncompletePayTMExchangeInfoList);
            _loginToken = inMsg.ReadString();
            _shareRewardInfo.Parse(inMsg);
            ListParse(inMsg, _userEventInfoList);
            ListParse(inMsg, _buffInfoList);
            ListParse(inMsg, _userLimitProductInfoList);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _userInfo.Packing(outMsg);
            _inventoryInfo.Packing(outMsg);
            _postBoxInfo.Packing(outMsg);
            ListPacking(outMsg, _paymentInfoList);
            ListPacking(outMsg, _missionInfoList);
            ListPacking(outMsg, _tutorialBaseInfoList);
            ListPacking(outMsg, _tutorialGaneshaInfoList);
            outMsg.Write(_mACAddress);
            outMsg.Write(_deviceCode);
            _payTMInfo.Packing(outMsg);
            ListPacking(outMsg, _uncompletePayTMExchangeInfoList);
            outMsg.Write(_loginToken);
            _shareRewardInfo.Packing(outMsg);
            ListPacking(outMsg, _userEventInfoList);
            ListPacking(outMsg, _buffInfoList);
            ListPacking(outMsg, _userLimitProductInfoList);
        }
    }
    #endregion
}

#endregion

#region �α׾ƿ�

//public static byte CSReq_Logout;						// [C->S] [����] �α׾ƿ� ��û
public class AcNetDataCS_reqLogout : AcNetData_base
{
    public string _userId;
    public string _pass;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        _userId = inMsg.ReadString();
        _pass = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        outMsg.Write(_userId);
        outMsg.Write(_pass);
    }
    #endregion
}

//public static byte SCRes_Logout;						// [S->C] [����] �α׾ƿ� ����
public class AcNetDataSC_resLogout : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
    }
    #endregion
}

#endregion

#region �翬�� ���� ��û

public class AcNetDataCS_reqReconnectionInfo : AcNetData_base
{
    
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSC_resReconnectionInfo : AcNetData_base
{
    public AcNetData_ReconnectionInfo _reconnectionInfo = new AcNetData_ReconnectionInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        _reconnectionInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        _reconnectionInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region ���� ���� ���� ��û

public class AcNetDataCS_reqGameServerChange : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

#endregion

#region ������ ������� ����

public class AcNetDataSC_notifyContentLockInfo : AcNetData_base
{
    public List<AcNetData_ContentMainLockInfo> _contentMainLockInfoList = new List<AcNetData_ContentMainLockInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        ListParse(inMsg, _contentMainLockInfoList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        ListPacking(outMsg, _contentMainLockInfoList);
    }
    #endregion
}

#endregion

#region ������ ������� Ȯ�� ��û

public class AcNetDataCS_reqContentsLockCheck : AcNetData_base
{
    public eContentMainLockType _mainLockType;
    public int _dataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _mainLockType = (eContentMainLockType)inMsg.ReadByte();
        _dataId = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_mainLockType);
        outMsg.Write(_dataId);
    }
    #endregion
}

public class AcNetDataSC_resContentsLockCheck : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ���� ����

public class AcNetDataCS_reqUserInfo : AcNetData_base
{
    public string _userId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userId = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userId);
    }
    #endregion
}

public class AcNetDataSC_resUserInfo : AcNetData_base
{
	public long _uId;
	public AcNetData_UserInfo _userInfo = new AcNetData_UserInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
	{
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _uId = inMsg.ReadInt64();
            _userInfo.Parse(inMsg);
        }
	}
	#endregion

	#region �޽��� ��ŷ
	//----------------------------------------------------------------
	public override void Packing(NetOutgoingMessage outMsg)
	{
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write(_uId);
            _userInfo.Packing(outMsg);
        }
	}
	#endregion
}


#endregion

#region ���� ������ ���

public class AcNetDataCS_reqUserProfileRegister : AcNetData_base
{
    public string _nickName;
    public int _avatarDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _nickName = inMsg.ReadString();
        _avatarDataId = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_nickName);
        outMsg.Write(_avatarDataId);
    }
    #endregion
}

public class AcNetDataSS_reqUserProfileRegister : AcNetData_base
{
    public long _userUId;
    public string _nickName;
    public int _avatarDataId;
    public int _pictureDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        _userUId = inMsg.ReadInt64();
        _nickName = inMsg.ReadString();
        _avatarDataId = inMsg.ReadInt32();
        _pictureDataId = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        outMsg.Write(_userUId);
        outMsg.Write(_nickName);
        outMsg.Write(_avatarDataId);
        outMsg.Write(_pictureDataId);
    }
    #endregion
}

public class AcNetDataSC_resUserProfileRegister : AcNetData_base
{
    public string _nickName;
    public int _avatarDataId;
    public int _pictureDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _nickName = inMsg.ReadString();
            _avatarDataId = inMsg.ReadInt32();
            _pictureDataId = inMsg.ReadInt32();
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            
            outMsg.Write(_nickName);
            outMsg.Write(_avatarDataId);
            outMsg.Write(_pictureDataId);
        }
    }
    #endregion
}

#endregion

#region ���� ������ ���� ��û

public class AcNetDataCS_reqUserProfileInfo : AcNetData_base
{
    public long _targetUserUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        _targetUserUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        outMsg.Write(_targetUserUId);
    }
    #endregion
}

public class AcNetDataSC_resUserProfileInfo : AcNetData_base
{
    public AcNetData_UserProfileInfo _userProfileInfo = new AcNetData_UserProfileInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _userProfileInfo.Parse(inMsg);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _userProfileInfo.Packing(outMsg);
        }
    }
    #endregion
}

#endregion

#region ���� ���� ���� ��û

public class AcNetDataCS_reqUserLeagueInfo : AcNetData_base
{
    public long _targetUserUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        _targetUserUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        outMsg.Write(_targetUserUId);
    }
    #endregion
}

public class AcNetDataSC_resUserLeagueInfo : AcNetData_base
{
    public AcNetData_SimpleUserLeagueInfo _userLeagueInfo = new AcNetData_SimpleUserLeagueInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _userLeagueInfo.Parse(inMsg);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _userLeagueInfo.Packing(outMsg);
        }
    }
    #endregion
}

#endregion

#region ���� �ʻ�ȭ ���� ��û

public class AcNetDataCS_reqUserPictureChange : AcNetData_base
{
    public int _pictureDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _pictureDataId = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_pictureDataId);
    }
    #endregion
}

public class AcNetDataSC_resUserPictureChange : AcNetData_base
{
    public int _pictureDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _pictureDataId = inMsg.ReadInt32();
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write(_pictureDataId);
        }
    }
    #endregion
}

#endregion

#region ���� �Ϸ� ���� ȹ�� ��û

public class AcNetDataCS_reqUserDailyReward : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSC_resUserDailyReward : AcNetData_base
{
    public DateTime _rewardReceiveDate;
    public long _rewardChip;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _rewardReceiveDate = DateTime.Parse(inMsg.ReadString());
            _rewardChip = inMsg.ReadInt64();
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write(_rewardReceiveDate.ToString("yyyy-MM-dd HH:mm:ss.fff"));
            outMsg.Write(_rewardChip);
        }
    }
    #endregion
}

#endregion

#region ���� ��� ���� ��û

public class AcNetDataCS_reqUserPolicyAccept : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSS_reqUserPolicyAccept : AcNetData_base
{
    public long _userUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ProxyParse(inMsg);

        _userUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ProxyPacking(outMsg);

        outMsg.Write(_userUId);
    }
    #endregion
}

public class AcNetDataSC_resUserPolicyAccept : AcNetData_base
{
    public DateTime _accpetPolicyDateTime;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _accpetPolicyDateTime = DateTime.Parse(inMsg.ReadString());
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write(_accpetPolicyDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
        }
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// ��
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ��� �� ���� ��û

public class AcNetDataCS_reqCreatePrivateRoom : AcNetData_base
{
    public int _gameModeDataInfoId;
    public bool _isAutoBootChip;
    public int _gameRoomDataInfoId;
    public int _turnLimitSecond;
    public int _blindLimitCount;
    public bool _isPotLimit;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _gameModeDataInfoId = inMsg.ReadInt32();
        _isAutoBootChip = inMsg.ReadBoolean();

        if (_isAutoBootChip == false)
        {
            _gameRoomDataInfoId = inMsg.ReadInt32();
        }

        _turnLimitSecond = inMsg.ReadInt32();
        _blindLimitCount = inMsg.ReadInt32();
        _isPotLimit = inMsg.ReadBoolean();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_gameModeDataInfoId);
        outMsg.Write(_isAutoBootChip);

        if (_isAutoBootChip == false)
        {
            outMsg.Write(_gameRoomDataInfoId);
        }

        outMsg.Write(_turnLimitSecond);
        outMsg.Write(_blindLimitCount);
        outMsg.Write(_isPotLimit);
    }
    #endregion
}

public class AcNetDataSC_resCreatePrivateRoom : AcNetData_base
{
    public AcNetData_RoomInfo _roomInfo;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _roomInfo = new AcNetData_RoomInfo();
            _roomInfo.Parse(inMsg);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _roomInfo.Packing(outMsg);
        }
    }
    #endregion
}

#endregion

#region �� ���� ��û

public class AcNetDataCS_reqEnterRoom : AcNetData_base
{
    public long _roomIndex;
    public int _multiGameOrder;
    public long _buyInChip;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _multiGameOrder = inMsg.ReadByte();
        _buyInChip = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write((byte)_multiGameOrder);
        outMsg.Write(_buyInChip);
    }
    #endregion
}

public class AcNetDataSC_resEnterRoom : AcNetData_base
{
    public int _multiGameOrder;
    public AcNetData_RoomInfo _roomInfo;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _multiGameOrder = inMsg.ReadByte();
            _roomInfo = new AcNetData_RoomInfo();
            _roomInfo.Parse(inMsg);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write((byte)_multiGameOrder);
            _roomInfo.Packing(outMsg);
        }
    }
    #endregion
}
#endregion

#region �� �������� ��û

public class AcNetDataCS_reqQuickEnterRoom : AcNetData_base
{
    public int _multiGameOrder;
    public int _gameModeDataInfoId;
    public int _gameDataId;
    public long _buyInBalance;
    public string _ticketItemUId;
    public bool _testEnter;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _multiGameOrder = inMsg.ReadByte();
        _gameModeDataInfoId = inMsg.ReadInt32();
        _gameDataId = inMsg.ReadInt32();
        _buyInBalance = inMsg.ReadInt64();
        _ticketItemUId = inMsg.ReadString();
        _testEnter = inMsg.ReadBoolean();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_multiGameOrder);
        outMsg.Write(_gameModeDataInfoId);
        outMsg.Write(_gameDataId);
        outMsg.Write(_buyInBalance);
        outMsg.Write(_ticketItemUId);
        outMsg.Write(_testEnter);
    }
    #endregion
}

public class AcNetDataSC_resQuickEnterRoom : AcNetData_base
{
    public int _multiGameOrder;
    public AcNetData_RoomInfo _roomInfo;
    public int _recommendGameRoomDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _multiGameOrder = inMsg.ReadByte();
            _roomInfo = new AcNetData_RoomInfo();
            _roomInfo.Parse(inMsg);
            _recommendGameRoomDataId = inMsg.ReadInt32(); // 2.04v
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write((byte)_multiGameOrder);
            _roomInfo.Packing(outMsg);
            outMsg.Write(_recommendGameRoomDataId); // 2.04v
        }
    }
    #endregion
}
#endregion

#region �� ����Ī ���� ��û

public class AcNetDataCS_reqSwitchingEnterRoom : AcNetData_base
{
    public long _roomIndex;
    public bool _gradeUpSwitching;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _gradeUpSwitching = inMsg.ReadBoolean();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write(_gradeUpSwitching);
    }
    #endregion
}

public class AcNetDataSC_resSwitchingEnterRoomEnable : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSC_resSwitchingEnterRoom : AcNetData_base
{
    public int _multiGameOrder;
    public long _leaveRoomIndex;
    public AcNetData_RoomInfo _roomInfo;
    public int _recommendGameRoomDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _multiGameOrder = inMsg.ReadByte();
            _leaveRoomIndex = inMsg.ReadInt64();
            _roomInfo = new AcNetData_RoomInfo();
            _roomInfo.Parse(inMsg);
            _recommendGameRoomDataId = inMsg.ReadInt32();
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write((byte)_multiGameOrder);
            outMsg.Write(_leaveRoomIndex);
            _roomInfo.Packing(outMsg);
            outMsg.Write(_recommendGameRoomDataId);
        }
    }
    #endregion
}
#endregion

#region �� ��õ ���� ��û

public class AcNetDataCS_reqRecommendEnterRoom : AcNetData_base
{
    public int _multiGameOrder;
    public int _gameModeDataId;
    public int _gameRoomDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _multiGameOrder = inMsg.ReadByte();
        _gameModeDataId = inMsg.ReadInt32();
        _gameRoomDataId = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_multiGameOrder);
        outMsg.Write(_gameModeDataId);
        outMsg.Write(_gameRoomDataId);
    }
    #endregion
}

public class AcNetDataSC_resRecommendEnterRoom : AcNetData_base
{
    public int _multiGameOrder;
    public long _leaveRoomIndex;
    public AcNetData_RoomInfo _roomInfo;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _multiGameOrder = inMsg.ReadByte();
            _leaveRoomIndex = inMsg.ReadInt64();
            _roomInfo = new AcNetData_RoomInfo();
            _roomInfo.Parse(inMsg);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write((byte)_multiGameOrder);
            outMsg.Write(_leaveRoomIndex);
            _roomInfo.Packing(outMsg);
        }
    }
    #endregion
}
#endregion

#region �� ������ ��û

public class AcNetDataCS_reqLeaveRoom : AcNetData_base
{
    public long _roomIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
    }
    #endregion
}

public class AcNetDataSC_resLeaveRoom : AcNetData_base
{
    public long _roomIndex;
    public long _totalChangeBalance;
    public long _totalChangeLP;
    public long _totalChangeBuffLP;
    public long _totalDealerCostLP;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        _roomIndex = inMsg.ReadInt64();
        _totalChangeBalance = inMsg.ReadInt64();
        _totalChangeLP = inMsg.ReadInt64();
        _totalChangeBuffLP = inMsg.ReadInt64();
        _totalDealerCostLP = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        outMsg.Write(_roomIndex);
        outMsg.Write(_totalChangeBalance);
        outMsg.Write(_totalChangeLP);
        outMsg.Write(_totalChangeBuffLP);
        outMsg.Write(_totalDealerCostLP);
    }
    #endregion
}

public class AcNetDataSC_notifyForceLeaveRoom : AcNetData_base
{
    public long _roomIndex;
    public eUserRoomLeaveType _userRoomLeaveType;
    public long _totalChangeBalance;
    public long _totalChangeLP;
    public long _totalChangeBuffLP;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);

        _roomIndex = inMsg.ReadInt64();
        _userRoomLeaveType = (eUserRoomLeaveType)inMsg.ReadByte();
        _totalChangeBalance = inMsg.ReadInt64();
        _totalChangeLP = inMsg.ReadInt64();
        _totalChangeBuffLP = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);

        outMsg.Write(_roomIndex);
        outMsg.Write((byte)_userRoomLeaveType);
        outMsg.Write(_totalChangeBalance);
        outMsg.Write(_totalChangeLP);
        outMsg.Write(_totalChangeBuffLP);
    }
    #endregion
}

#endregion

#region �� ����Ʈ ��û

public class AcNetDataCS_reqRoomList : AcNetData_base
{
    public eGameType _gameType;
    public int _pageNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        _gameType = (eGameType)inMsg.ReadByte();
        _pageNumber = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        outMsg.Write((byte)_gameType);
        outMsg.Write(_pageNumber);
    }
    #endregion
}

public class AcNetDataSC_resRoomList : AcNetData_base
{
    public List<AcNetData_RoomSimpleInfo> _roomInfoList = new List<AcNetData_RoomSimpleInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if(_result == eGameResult.RESULT_OK)
        {
            ListParse<AcNetData_RoomSimpleInfo>(inMsg, _roomInfoList);
        }
        
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            ListPacking<AcNetData_RoomSimpleInfo>(outMsg, _roomInfoList);
        }
    }
    #endregion
}

#endregion

#region �� ���� ��û

public class AcNetDataCS_reqAttendRoomSlot : AcNetData_base
{
    public long _roomIndex;
    public int _attendSlotNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _attendSlotNumber = inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write((byte)_attendSlotNumber);
    }
    #endregion
}

public class AcNetDataSC_resAttendRoomSlot : AcNetData_base
{
    public long _roomIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        _roomIndex = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        outMsg.Write(_roomIndex);
    }
    #endregion
}
#endregion

#region �� �Ͼ�� ��û

public class AcNetDataCS_reqStandUpRoomSlot : AcNetData_base
{
    public long _roomIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
    }
    #endregion
}

public class AcNetDataSC_resStandUpRoomSlot : AcNetData_base
{
    public long _roomIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        _roomIndex = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        outMsg.Write(_roomIndex);
    }
    #endregion
}
#endregion

#region �� �������� ����

public class AcNetDataSC_notifyRoomSlotInfo : AcNetData_base
{
    public long _roomIndex;
    public AcNetData_RoomSlotInfo _roomSlotInfo = new AcNetData_RoomSlotInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _roomSlotInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        _roomSlotInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region �� ���� ���� ����

public class AcNetDataSC_notifyRoomSlotStateInfo : AcNetData_base
{
    public long _roomIndex;
    public List<AcNetData_RoomSlotStateInfo> _roomSlotStateInfo = new List<AcNetData_RoomSlotStateInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();

        ListParse<AcNetData_RoomSlotStateInfo>(inMsg, _roomSlotStateInfo);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);

        ListPacking<AcNetData_RoomSlotStateInfo>(outMsg, _roomSlotStateInfo);
    }
    #endregion
}

#endregion

#region �� ���� ����

public class AcNetDataSC_notifyRoomState : AcNetData_base
{
    public long _roomIndex;
    public eRoomState _roomState;

    public DateTime _gameStartDateTime;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _roomState = (eRoomState)inMsg.ReadByte();

        if (_roomState == eRoomState.STATE_COUNTDOWN)
        {
            _gameStartDateTime = DateTime.Parse(inMsg.ReadString());
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write((byte)_roomState);

        if (_roomState == eRoomState.STATE_COUNTDOWN)
        {
            outMsg.Write(_gameStartDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
        }
    }
    #endregion
}

#endregion

#region �� ���� ���� Ĩ ���� ����

public class AcNetDataSC_notifyRoomSlotUserBalanceInfo : AcNetData_base
{
    public long _roomIndex;
    public List<AcNetData_RoomSlotUserBalanceInfo> _roomSlotUserBalanceInfoList = new List<AcNetData_RoomSlotUserBalanceInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();

        ListParse<AcNetData_RoomSlotUserBalanceInfo>(inMsg, _roomSlotUserBalanceInfoList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);

        ListPacking<AcNetData_RoomSlotUserBalanceInfo>(outMsg, _roomSlotUserBalanceInfoList);
    }
    #endregion
}

#endregion

#region �� ���� ��ȭ ���� ����Ŵ ����

public class AcNetDataSC_notifyRoomSlotLackBalanceStandUp : AcNetData_base
{
    public long _roomIndex;
    public int _slotNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _slotNumber = inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write((byte)_slotNumber);
    }
    #endregion
}

#endregion

#region �� ���� �ڵ� ����Ŵ ����

public class AcNetDataSC_notifyRoomSlotAutoStandUp : AcNetData_base
{
    public long _roomIndex;
    public int _slotNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _slotNumber = inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write((byte)_slotNumber);
    }
    #endregion
}

#endregion

#region �� ���� ��Ƽ �ð��������� ����Ŵ ����

public class AcNetDataSC_notifyRoomSlotLackMultiTimeStandUp : AcNetData_base
{
    public long _roomIndex;
    public int _slotNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _slotNumber = inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write((byte)_slotNumber);
    }
    #endregion
}

#endregion

#region �� ���� �ݰ� Ĩ �ִ�ġ�� ����Ŵ ����

public class AcNetDataSC_notifyRoomSlotSafeChipMaxVolumeStandUp : AcNetData_base
{
    public long _roomIndex;
    public int _slotNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _slotNumber = inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write((byte)_slotNumber);
    }
    #endregion
}

#endregion

#region �� ���� ���� ����

public class AcNetDataSC_notifyRoomSlotTicketBalanceInfo : AcNetData_base
{
    public long _roomIndex;
    public int _slotNumber;
    public long _userUId;
    public bool _ticketBalance;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _slotNumber = inMsg.ReadInt32();
        _userUId = inMsg.ReadInt64();
        _ticketBalance = inMsg.ReadBoolean();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write(_slotNumber);
        outMsg.Write(_userUId);
        outMsg.Write(_ticketBalance);
    }
    #endregion
}

#endregion

#region �� ä�� ��û

public class AcNetDataCS_reqRoomTalk : AcNetData_base
{
    public long _roomIndex;
    public string _talkStr;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _talkStr = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write(_talkStr);
    }
    #endregion
}

public class AcNetDataSC_resRoomTalk : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
    }
    #endregion
}

public class AcNetDataSC_notifyRoomTalk : AcNetData_base
{
    public long _roomIndex;
    public AcNetData_TalkInfo _talkInfo = new AcNetData_TalkInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _talkInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        _talkInfo.Packing(outMsg);
    }
    #endregion
}
#endregion

#region �� ���ӷ� ������ ���� ����

public class AcNetDataSC_notifyRoomGameRoomDataChange : AcNetData_base
{
    public long _roomIndex;
    public int _gameRoomDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _gameRoomDataId = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write(_gameRoomDataId);
    }
    #endregion
}

#endregion

#region ��й� ���� �÷��� ���� ����

public class AcNetDataCS_reqRoomPrivatePlayStateChange : AcNetData_base
{
    public long _roomIndex;
    public ePrivateRoomPlayState _privateRoomPlayState;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _privateRoomPlayState = (ePrivateRoomPlayState)inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write((byte)_privateRoomPlayState);
    }
    #endregion
}

public class AcNetDataSC_resRoomPrivatePlayStateChange : AcNetData_base
{
    public long _roomIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);
        _roomIndex = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);
        outMsg.Write(_roomIndex);
    }
    #endregion
}

public class AcNetDataSC_notifyRoomPrivatePlayStateChange : AcNetData_base
{
    public long _roomIndex;
    public ePrivateRoomPlayState _privateRoomPlayState;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _privateRoomPlayState = (ePrivateRoomPlayState)inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write((byte)_privateRoomPlayState);
    }
    #endregion
}

#endregion

#region �� ������ ���� ����

public class AcNetDataSC_notifyRoomMasterChange : AcNetData_base
{
    public long _roomIndex;
    public long _masterUserUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _masterUserUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write(_masterUserUId);
    }
    #endregion
}

#endregion

#region ���� ������ �� ä�� ���� ��û

public class AcNetDataCS_reqEnableEnterChannelInfo : AcNetData_base
{
    public int _gameModeDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _gameModeDataId = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_gameModeDataId);
    }
    #endregion
}

public class AcNetDataSC_resEnableEnterChannelInfo : AcNetData_base
{
    public int _gameModeDataId;
    public List<AcNetData_EnableEnterChannelInfo> _enableEnterChannelInfoList = new List<AcNetData_EnableEnterChannelInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);
        _gameModeDataId = inMsg.ReadInt32();

        if (_result == eGameResult.RESULT_OK)
        {
            ListParse(inMsg, _enableEnterChannelInfoList);
        }

    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);
        outMsg.Write(_gameModeDataId);

        if (_result == eGameResult.RESULT_OK)
        {
            ListPacking(outMsg, _enableEnterChannelInfoList);
        }
    }
    #endregion
}

#endregion

#region ���� ������ �� ���� ä�� ���� ��û

public class AcNetDataCS_reqEnableEnterHighGradeChannel : AcNetData_base
{
    public long _roomIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
    }
    #endregion
}

public class AcNetDataSC_resEnableEnterHighGradeChannel : AcNetData_base
{
    public int _gameModeDataId;
    public int _gameDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _gameModeDataId = inMsg.ReadInt32();
            _gameDataId = inMsg.ReadInt32();
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write(_gameModeDataId);
            outMsg.Write(_gameDataId);
        }
    }
    #endregion
}

#endregion

#region �� ���� ���� Ĩ ���� ����

public class AcNetDataSC_notifyRoomSlotUserBalanceMaxLimitFix : AcNetData_base
{
    public long _roomIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// ���� ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ���� �α��� ��ٰ� ����

public class AcNetDataSS_notifyUserLogin : AcNetData_base
{
    public long _userUId;
    public string _userId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _userId = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        outMsg.Write(_userId);
    }
    #endregion
}

#endregion

#region ���� ���� ������� ����

public class AcNetDataSS_notifyUserDisconnect : AcNetData_base
{
    public long _userUId;
    public eUserLogOutType _logoutType;
    public bool _allUserDisconnect;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _logoutType = (eUserLogOutType)inMsg.ReadByte();
        _allUserDisconnect = inMsg.ReadBoolean();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        outMsg.Write((byte)_logoutType);
        outMsg.Write(_allUserDisconnect);
    }
    #endregion
}

#endregion

#region ���Ӽ��� �翬�� ���� ���� ����Ʈ

public class AcNetDataSS_notifyUserConnectInfo : AcNetData_base
{
    public List<AcNetData_UserConnectInfo> _userConnectInfoList = new List<AcNetData_UserConnectInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        ListParse(inMsg, _userConnectInfoList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        ListPacking(outMsg, _userConnectInfoList);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ���� ���� ��û

public class AcNetDataCS_reqUserResearch : AcNetData_base
{
    public int _researchDataId;
    public int _answerNumber;
    public string _answerString;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _researchDataId = inMsg.ReadInt32();
        _answerNumber = inMsg.ReadInt16();
        _answerString = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_researchDataId);
        outMsg.Write((short)_answerNumber);
        outMsg.Write(_answerString);
    }
    #endregion
}

public class AcNetDataSC_resUserResearch : AcNetData_base
{
    public int _researchDataId;
    public eResearchType _researchType;
    public DateTime _researchDate;

    public List<AcNetData_ItemChangeInfo> _itemChangeInfoList = new List<AcNetData_ItemChangeInfo>();
    public List<AcNetData_ItemAcquireInfo> _itemAcquireInfoList = new List<AcNetData_ItemAcquireInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _researchDataId = inMsg.ReadInt32();
            _researchType = (eResearchType)inMsg.ReadByte();
            _researchDate = DateTime.Parse(inMsg.ReadString());

            ListParse(inMsg, _itemChangeInfoList);
            ListParse(inMsg, _itemAcquireInfoList);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write(_researchDataId);
            outMsg.Write((byte)_researchType);
            outMsg.Write(_researchDate.ToString("yyyy-MM-dd HH:mm:ss.fff"));

            ListPacking(outMsg, _itemChangeInfoList);
            ListPacking(outMsg, _itemAcquireInfoList);
        }
    }
    #endregion
}

#endregion

#region ���� ���� ���糡 ����Ĩ ���� ��û

public class AcNetDataCS_reqUserResearchEndLackChipReward : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSC_resUserResearchEndLackChipReward : AcNetData_base
{
    public long _rewardChip;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        _rewardChip = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        outMsg.Write(_rewardChip);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// BBS
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ���� �Խ��� ���� ��û

public class AcNetDataSS_reqBBSNoticeBoardInfo : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSS_resBBSNoticeBoardInfo : AcNetData_base
{
    public List<AcNetData_BBSNoticeInfo> _BBSNoticeInfoList = new List<AcNetData_BBSNoticeInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        ListParse(inMsg, _BBSNoticeInfoList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        ListPacking(outMsg, _BBSNoticeInfoList);
    }
    #endregion
}

#endregion

#region ���� ���� ��û

public class AcNetDataSS_reqBBSNoticeInfo : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSS_resBBSNoticeInfo : AcNetData_base
{
    public List<AcNetData_BBSNoticeInfo> _BBSNoticeInfoList = new List<AcNetData_BBSNoticeInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        ListParse(inMsg, _BBSNoticeInfoList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        ListPacking(outMsg, _BBSNoticeInfoList);
    }
    #endregion
}

public class AcNetDataSC_notifyBBSNoticeInfo : AcNetData_base
{
    public string _noticeStr;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _noticeStr = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_noticeStr);
    }
    #endregion
}

#endregion

#region ��� ���� ��û

public class AcNetDataSS_reqBBSBannerInfo : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSS_resBBSBannerInfo : AcNetData_base
{
    public List<AcNetData_BBSBannerInfo> _BBSBannerInfoList = new List<AcNetData_BBSBannerInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        ListParse(inMsg, _BBSBannerInfoList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        ListPacking(outMsg, _BBSBannerInfoList);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// ��������
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region �������� ���� ��û

public class AcNetDataSS_reqPostManagementInfo : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSS_resPostManagementInfo : AcNetData_base
{
    public List<AcNetData_PostManagementInfo> _postManagementInfoList = new List<AcNetData_PostManagementInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        ListParse(inMsg, _postManagementInfoList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        ListPacking(outMsg, _postManagementInfoList);
    }
    #endregion
}

#endregion

#region �������� ���� ��û

public class AcNetDataSS_reqPostManagementActiveSend : AcNetData_base
{
    public long _postManagementId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _postManagementId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_postManagementId);
    }
    #endregion
}

public class AcNetDataSS_resPostManagementActiveSend : AcNetData_base
{
    public List<long> _receiveUserUIdList = new List<long>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        ListParse(inMsg, _receiveUserUIdList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        ListPacking(outMsg, _receiveUserUIdList);
    }
    #endregion
}

#endregion

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// �������� ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ���� ������ ���ּ� ����Ʈ ��û

public class AcNetDataSS_reqServerAdminMACAddressList : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSS_resServerAdminMACAddressList : AcNetData_base
{
    public string _adminMACAddressStr;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _adminMACAddressStr = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_adminMACAddressStr);
    }
    #endregion
}

#endregion

#region ���� ���� ���� ��û

public class AcNetDataSS_reqServerCheckString : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSS_resServerCheckString : AcNetData_base
{
    public string _serverCheckString;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _serverCheckString = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_serverCheckString);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// �������� ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ���� ���� ���� ��û

public class AcNetDataSS_reqServerVersionInfo : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSS_resServerVersionInfo : AcNetData_base
{
    public float _serverCurrentVersion;
    public float _serverPatchVersion;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _serverCurrentVersion = inMsg.ReadFloat();
        _serverPatchVersion = inMsg.ReadFloat();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_serverCurrentVersion);
        outMsg.Write(_serverPatchVersion);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// ���Ըӽ�
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ���� ����Ʈ ���� ��û

public class AcNetDataCS_reqSlotMachineJackPotPoint : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSC_resSlotMachineJackPotPoint : AcNetData_base
{
    public long _jackPotPoint;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _jackPotPoint = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_jackPotPoint);
    }
    #endregion
}

#endregion

#region ���Ըӽ� �÷��� ��û

public class AcNetDataCS_reqSlotMachinePlay : AcNetData_base
{
    public int _slotMachineDataId;
    public long _bettingPoint;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _slotMachineDataId = inMsg.ReadInt32();
        _bettingPoint = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_slotMachineDataId);
        outMsg.Write(_bettingPoint);
    }
    #endregion
}

public class AcNetDataSC_resSlotMachinePlay : AcNetData_base
{
    public List<int> _symbolDataIdList = new List<int>();
    public List<int> _rewardDataIdList = new List<int>();
    public long _rewardUId;
    public long _acquireChip;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            ListParse(inMsg, _symbolDataIdList);
            ListParse(inMsg, _rewardDataIdList);
            _rewardUId = inMsg.ReadInt64();
            _acquireChip = inMsg.ReadInt64();
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            ListPacking(outMsg, _symbolDataIdList);
            ListPacking(outMsg, _rewardDataIdList);
            outMsg.Write(_rewardUId);
            outMsg.Write(_acquireChip);
        }
    }
    #endregion
}

public class AcNetDataSC_resSlotMachineAttendancePlay : AcNetData_base
{
    public List<int> _symbolDataIdList = new List<int>();
    public DateTime _lastAttendanceDate;
    public int _attendanceSlotMachineEnableCount;
    public int _attendanceAccumulateCount;
    public long _rewardUId;
    public long _acquireChip;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            ListParse(inMsg, _symbolDataIdList);
            _lastAttendanceDate = DateTime.Parse(inMsg.ReadString());
            _attendanceSlotMachineEnableCount = inMsg.ReadInt32();
            _attendanceAccumulateCount = inMsg.ReadInt32();
            _rewardUId = inMsg.ReadInt64();

            if (_rewardUId != 0)
            {
                _acquireChip = inMsg.ReadInt64();
            }
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            ListPacking(outMsg, _symbolDataIdList);
            outMsg.Write(_lastAttendanceDate.ToString("yyyy-MM-dd HH:mm:ss.fff"));
            outMsg.Write(_attendanceSlotMachineEnableCount);
            outMsg.Write(_attendanceAccumulateCount);
            outMsg.Write(_rewardUId);

            if (_rewardUId != 0)
            {
                outMsg.Write(_acquireChip);
            }
        }
    }
    #endregion
}

public class AcNetDataSC_resSlotMachineRoulettePlay : AcNetData_base
{
    public int _symbolDataId;
    
    public int _rouletteFeverCount;
    public int _rouletteFreeCount;
    public DateTime _rouletteFreeUpdateDateTime;
    public long _rewardUId;
    public long _acquireValue;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _symbolDataId = inMsg.ReadInt32();
            _rouletteFeverCount = inMsg.ReadInt32();
            _rouletteFreeCount = inMsg.ReadInt32();
            _rouletteFreeUpdateDateTime = DateTime.Parse(inMsg.ReadString());
            _rewardUId = inMsg.ReadInt64();
            if (_rewardUId != 0)
            {
                _acquireValue = inMsg.ReadInt64();
            }
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write(_symbolDataId);
            outMsg.Write(_rouletteFeverCount);
            outMsg.Write(_rouletteFreeCount);
            outMsg.Write(_rouletteFreeUpdateDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
            outMsg.Write(_rewardUId);

            if (_rewardUId != 0)
            {
                outMsg.Write(_acquireValue);
            }
        }
    }
    #endregion
}

#endregion

#region ���Ըӽ� �÷��� ���� ��û

public class AcNetDataCS_reqSlotMachinePlayReward : AcNetData_base
{
    public long _rewardUid;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _rewardUid = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_rewardUid);
    }
    #endregion
}

public class AcNetDataSC_resSlotMachinePlayReward : AcNetData_base
{
    public long _acquireValue;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _acquireValue = inMsg.ReadInt64();
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write(_acquireValue);
        }
    }
    #endregion
}

#endregion

#region ���Ըӽ� �귿 �÷��� ���� ��û

public class AcNetDataCS_reqSlotMachineRoulettePlayReward : AcNetData_base
{
    public long _rewardUid;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _rewardUid = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_rewardUid);
    }
    #endregion
}

public class AcNetDataSC_resSlotMachineRoulettePlayReward : AcNetData_base
{
    public long _acquireValue;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);
        if (_result == eGameResult.RESULT_OK)
        {
            _acquireValue = inMsg.ReadInt64();
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write(_acquireValue);
        }
    }
    #endregion
}

#endregion

#region ���Ըӽ� ���� ����Ʈ ��� ��û

public class AcNetDataCS_reqSlotMachineCalcJackPotPoint : AcNetData_base
{
    public long _jackPotPoint;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _jackPotPoint = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_jackPotPoint);
    }
    #endregion
}

#endregion

#region ���Ըӽ� ���� ����Ʈ ����

public class AcNetDataSS_notifySlotMachineJackPotPoint : AcNetData_base
{
    public long _jackPotPoint;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _jackPotPoint = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_jackPotPoint);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// �̼�
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ������ �̼� ������Ʈ ��û

public class AcNetDataSS_reqMissionInfoUpdate : AcNetData_base
{
    public long _userUId;
    public List<AcNetData_MissionInfo> _missionAddList = new List<AcNetData_MissionInfo>();
    public List<AcNetData_MissionInfo> _missionUpdateList = new List<AcNetData_MissionInfo>();
    public List<AcNetData_MissionInfo> _missionCompleteUpdateList = new List<AcNetData_MissionInfo>();

    public bool _needMissionDailyDateUpdate;
    public DateTime _missionDailyUpdateDate;
    
    public bool _needMissionWeeklyDateUpdate;
    public DateTime _missionWeeklyUpdateDate;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();

        ListParse(inMsg, _missionAddList);
        ListParse(inMsg, _missionUpdateList);
        ListParse(inMsg, _missionCompleteUpdateList);

        _needMissionDailyDateUpdate = inMsg.ReadBoolean();
        if (_needMissionDailyDateUpdate == true)
        {
            _missionDailyUpdateDate = DateTime.Parse(inMsg.ReadString());
        }

        _needMissionWeeklyDateUpdate = inMsg.ReadBoolean();
        if (_needMissionWeeklyDateUpdate == true)
        {
            _missionWeeklyUpdateDate = DateTime.Parse(inMsg.ReadString());
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);

        ListPacking(outMsg, _missionAddList);
        ListPacking(outMsg, _missionUpdateList);
        ListPacking(outMsg, _missionCompleteUpdateList);

        outMsg.Write(_needMissionDailyDateUpdate);
        if (_needMissionDailyDateUpdate == true)
        {
            outMsg.Write(_missionDailyUpdateDate.ToString("yyyy-MM-dd HH:mm:ss"));
        }

        outMsg.Write(_needMissionWeeklyDateUpdate);
        if (_needMissionWeeklyDateUpdate == true)
        {
            outMsg.Write(_missionWeeklyUpdateDate.ToString("yyyy-MM-dd HH:mm:ss"));
        }
    }
    #endregion
}

#endregion

#region �̼� ����Ʈ ��û

public class AcNetDataCS_reqMissionList : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSC_resMissionList : AcNetData_base
{
    public List<AcNetData_MissionInfo> _missionInfoList = new List<AcNetData_MissionInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);
        ListParse(inMsg, _missionInfoList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);
        ListPacking(outMsg, _missionInfoList);
    }
    #endregion
}

#endregion

#region �̼� ���� ȹ�� ��û

public class AcNetDataCS_reqMissionRewardAcquire : AcNetData_base
{
    public int _missionDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _missionDataId = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_missionDataId);
    }
    #endregion
}

public class AcNetDataSC_resMissionRewardAcquire : AcNetData_base
{
    public int _missionDataId;
    public List<AcNetData_ItemChangeInfo> _itemChangeInfoList = new List<AcNetData_ItemChangeInfo>();
    public List<AcNetData_ItemAcquireInfo> _itemAcquireInfoList = new List<AcNetData_ItemAcquireInfo>();
    public List<AcNetData_MissionInfo> _missionChangeInfoList = new List<AcNetData_MissionInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);
        _missionDataId = inMsg.ReadInt32();

        if (_result == eGameResult.RESULT_OK)
        {
            ListParse(inMsg, _itemChangeInfoList);
            ListParse(inMsg, _itemAcquireInfoList);
            ListParse(inMsg, _missionChangeInfoList);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);
        outMsg.Write(_missionDataId);

        if (_result == eGameResult.RESULT_OK)
        {
            ListPacking(outMsg, _itemChangeInfoList);
            ListPacking(outMsg, _itemAcquireInfoList);
            ListPacking(outMsg, _missionChangeInfoList);
        }
    }
    #endregion
}

#endregion

#region ������ �̼� ������Ʈ ��û

public class AcNetDataSC_notifyMissionInfoUpdate : AcNetData_base
{
    public List<AcNetData_MissionInfo> _missionUpdateList = new List<AcNetData_MissionInfo>();
    
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        ListParse(inMsg, _missionUpdateList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        ListPacking(outMsg, _missionUpdateList);
    }
    #endregion
}

#endregion

#region ������ �̼� ���� ��û

public class AcNetDataSS_reqMissionResetAll : AcNetData_base
{
    public long _userUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
    }
    #endregion
}

#endregion

#region ���� �̼� ���� ��û(������ ��û)

public class AcNetDataCS_reqMissionRefresh : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

#endregion

#region ���� ���� ���� ��û

public class AcNetDataCS_reqShareRewardInfo : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSC_resShareRewardInfo : AcNetData_base
{
    public AcNetData_ShareRewardInfo _shareRewardInfo = new AcNetData_ShareRewardInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);
        _shareRewardInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);
        _shareRewardInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region ���� ���� ȹ�� ��û

public class AcNetDataCS_reqShareRewardAcquire : AcNetData_base
{
    public int _missionDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _missionDataId = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_missionDataId);
    }
    #endregion
}

public class AcNetDataSC_resShareRewardAcquire : AcNetData_base
{
    public int _missionDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _missionDataId = inMsg.ReadInt32();
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write(_missionDataId);
        }
    }
    #endregion
}

#endregion

#region ���� ���� ���� ������Ʈ ��û

public class AcNetDataSS_reqShareRewardInfoUpdate : AcNetData_base
{
    public AcNetData_ShareRewardInfo _shareRewardInfo = new AcNetData_ShareRewardInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _shareRewardInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        _shareRewardInfo.Packing(outMsg);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// ���׻�
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ���׻� �� ��û

public class AcNetDataCS_reqGaneshaTip : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSC_resGaneshaTip : AcNetData_base
{
    public long _ganeshaPocketChip;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);
        _ganeshaPocketChip = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);
        outMsg.Write(_ganeshaPocketChip);
    }
    #endregion
}

#endregion

#region ���׻� ���� Ĩ  ��ȯ ��û

public class AcNetDataCS_reqGaneshaPocketConvertLP : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSC_resGaneshaPocketConvertLP : AcNetData_base
{
    public long _ganeshaPocketChip;
    public long _convertLP;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _ganeshaPocketChip = inMsg.ReadInt64();
            _convertLP = inMsg.ReadInt64();
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write(_ganeshaPocketChip);
            outMsg.Write(_convertLP);
        }
    }
    #endregion
}

#endregion

#region ���� �κ� �ִٰ� �˸�

public class AcNetDataCS_notifyUserInLobby : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// Ʃ�丮��
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ������ Ʃ�丮�� ������Ʈ ��û

public class AcNetDataSS_reqTutorialInfoUpdate : AcNetData_base
{
    public long _userUId;
    public List<AcNetData_TutorialBaseInfo> _tutorialBaseAddList = new List<AcNetData_TutorialBaseInfo>();
    public List<AcNetData_TutorialGaneshaInfo> _tutorialGaneshaAddList = new List<AcNetData_TutorialGaneshaInfo>();
    public int _tutorialDayCount;
    public DateTime _tutorialUpdateDate;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();

        ListParse(inMsg, _tutorialBaseAddList);
        ListParse(inMsg, _tutorialGaneshaAddList);

        _tutorialDayCount = inMsg.ReadInt32();
        _tutorialUpdateDate = DateTime.Parse(inMsg.ReadString());

    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);

        ListPacking(outMsg, _tutorialBaseAddList);
        ListPacking(outMsg, _tutorialGaneshaAddList);

        outMsg.Write(_tutorialDayCount);
        outMsg.Write(_tutorialUpdateDate.ToString("yyyy-MM-dd HH:mm:ss"));
    }
    #endregion
}

#endregion

#region ���� Ʃ�丮�� ī��Ʈ ������Ʈ ��û

public class AcNetDataSS_reqTutorialCountUpdate : AcNetData_base
{
    public List<AcNetData_TutorialBaseInfo> _tutorialBaseInfoList = new List<AcNetData_TutorialBaseInfo>();
    public List<AcNetData_TutorialGaneshaInfo> _tutorialGaneshaInfoList = new List<AcNetData_TutorialGaneshaInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        ListParse(inMsg, _tutorialBaseInfoList);
        ListParse(inMsg, _tutorialGaneshaInfoList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        ListPacking(outMsg, _tutorialBaseInfoList);
        ListPacking(outMsg, _tutorialGaneshaInfoList);
    }
    #endregion
}

#endregion

#region ���� Ʃ�丮�� �Ϸ� ������Ʈ ��û

public class AcNetDataSS_reqTutorialCompleteUpdate : AcNetData_base
{
    public List<string> _tutorialBaseUIdList = new List<string>();
    public List<string> _tutorialGaneshaUIdList = new List<string>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        ListParse(inMsg, _tutorialBaseUIdList);
        ListParse(inMsg, _tutorialGaneshaUIdList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        ListPacking(outMsg, _tutorialBaseUIdList);
        ListPacking(outMsg, _tutorialGaneshaUIdList);
    }
    #endregion
}

#endregion

#region Ʃ�丮�� ���̽� �Ϸ� ���� ����

public class AcNetDataSC_notifyTutorialBaseEnableComplete : AcNetData_base
{
    public int _tutorialBaseDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _tutorialBaseDataId = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_tutorialBaseDataId);
    }
    #endregion
}

#endregion

#region Ʃ�丮�� ���׻� �Ϸ� ���� ����

public class AcNetDataSC_notifyTutorialGaneshaEnableComplete : AcNetData_base
{
    public int _tutorialGaneshaDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _tutorialGaneshaDataId = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_tutorialGaneshaDataId);
    }
    #endregion
}

#endregion

#region Ʃ�丮�� �Ϸ� ���� ��û

public class AcNetDataCS_reqTutorialCompleteInfo : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSC_resTutorialCompleteInfo : AcNetData_base
{
    public List<int> _tutorialCompleteBaseIdList = new List<int>();
    public List<int> _tutorialCompleteGaneshaIdList = new List<int>();

    public List<int> _tutorialEnableCompleteBaseIdList = new List<int>();
    public List<int> _tutorialEnableCompleteGaneshaIdList = new List<int>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        ListParse(inMsg, _tutorialCompleteBaseIdList);
        ListParse(inMsg, _tutorialCompleteGaneshaIdList);

        ListParse(inMsg, _tutorialEnableCompleteBaseIdList);
        ListParse(inMsg, _tutorialEnableCompleteGaneshaIdList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        ListPacking(outMsg, _tutorialCompleteBaseIdList);
        ListPacking(outMsg, _tutorialCompleteGaneshaIdList);

        ListPacking(outMsg, _tutorialEnableCompleteBaseIdList);
        ListPacking(outMsg, _tutorialEnableCompleteGaneshaIdList);
    }
    #endregion
}

#endregion

#region Ʃ�丮�� ���̽� ���� ��û

public class AcNetDataCS_reqTutorialBaseRewardAcquire : AcNetData_base
{
    public int _tutorialBaseDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _tutorialBaseDataId = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_tutorialBaseDataId);
    }
    #endregion
}

public class AcNetDataSC_resTutorialBaseRewardAcquire : AcNetData_base
{
    public int _tutorialBaseDataId;
    public List<AcNetData_ItemChangeInfo> _itemChangeInfoList = new List<AcNetData_ItemChangeInfo>();
    public List<AcNetData_ItemAcquireInfo> _itemAcquireInfoList = new List<AcNetData_ItemAcquireInfo>();
    public List<AcNetData_MissionInfo> _missionChangeInfoList = new List<AcNetData_MissionInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);
        _tutorialBaseDataId = inMsg.ReadInt32();

        if (_result == eGameResult.RESULT_OK)
        {
            ListParse(inMsg, _itemChangeInfoList);
            ListParse(inMsg, _itemAcquireInfoList);
            ListParse(inMsg, _missionChangeInfoList);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);
        outMsg.Write(_tutorialBaseDataId);

        if (_result == eGameResult.RESULT_OK)
        {
            ListPacking(outMsg, _itemChangeInfoList);
            ListPacking(outMsg, _itemAcquireInfoList);
            ListPacking(outMsg, _missionChangeInfoList);
        }
    }
    #endregion
}

#endregion

#region Ʃ�丮�� ���׻� ���� ��û

public class AcNetDataCS_reqTutorialGaneshaRewardAcquire : AcNetData_base
{
    public int _tutorialGaneshaDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _tutorialGaneshaDataId = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_tutorialGaneshaDataId);
    }
    #endregion
}

public class AcNetDataSC_resTutorialGaneshaRewardAcquire : AcNetData_base
{
    public int _tutorialGaneshaDataId;
    public List<AcNetData_ItemChangeInfo> _itemChangeInfoList = new List<AcNetData_ItemChangeInfo>();
    public List<AcNetData_ItemAcquireInfo> _itemAcquireInfoList = new List<AcNetData_ItemAcquireInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);
        _tutorialGaneshaDataId = inMsg.ReadInt32();

        if (_result == eGameResult.RESULT_OK)
        {
            ListParse(inMsg, _itemChangeInfoList);
            ListParse(inMsg, _itemAcquireInfoList);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);
        outMsg.Write(_tutorialGaneshaDataId);

        if (_result == eGameResult.RESULT_OK)
        {
            ListPacking(outMsg, _itemChangeInfoList);
            ListPacking(outMsg, _itemAcquireInfoList);
        }
    }
    #endregion
}

#endregion

#region ���� Ʃ�丮�� ��Ŭ���� ������Ʈ ��û

public class AcNetDataSS_reqTutorialAllClearUpdate : AcNetData_base
{
    public long _userUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// ���� ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ���� ���� ��û

public class AcNetDataCS_reqADRewardAcquire : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSC_resADRewardAcquire : AcNetData_base
{
    public long _aDRewardValue;
    public int _aDRewardLastRewardLevel;
    
    public bool _updateDateTime;
    public DateTime _aDRewardLastUpdateDateTime;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _aDRewardValue = inMsg.ReadInt64();
            _aDRewardLastRewardLevel = inMsg.ReadInt32();

            _updateDateTime = inMsg.ReadBoolean();
            if (_updateDateTime == true)
            {
                _aDRewardLastUpdateDateTime = DateTime.Parse(inMsg.ReadString());
            }
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write(_aDRewardValue);
            outMsg.Write(_aDRewardLastRewardLevel);

            outMsg.Write(_updateDateTime);
            if (_updateDateTime == true)
            {
                outMsg.Write(_aDRewardLastUpdateDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
            }
        }
    }
    #endregion
}

#endregion

#region ���� ���� ���� ������Ʈ ��û

public class AcNetDataSS_reqADRewardInfoUpdate : AcNetData_base
{
    public long _userUId;
    public int _aDRewardLastRewardLevel;
    public DateTime _aDRewardLastUpdateDateTime;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _aDRewardLastRewardLevel = inMsg.ReadInt32();
        _aDRewardLastUpdateDateTime = DateTime.Parse(inMsg.ReadString());
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        outMsg.Write(_aDRewardLastRewardLevel);
        outMsg.Write(_aDRewardLastUpdateDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// ����Ĩ ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ����Ĩ ���� ȹ�� ��û

public class AcNetDataCS_reqEmptyChipRewardAcquire : AcNetData_base
{
    public bool _adView;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
        _adView = inMsg.ReadBoolean();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
        outMsg.Write(_adView);
    }
    #endregion
}

public class AcNetDataSC_resEmptyChipRewardAcquire : AcNetData_base
{
    public long _emptyChipRewardChip;
    public int _emptyChipRewardRemainCount;

    public bool _updateDateTime;
    public DateTime _emptyChipRewardLastUpdateDateTime;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _emptyChipRewardChip = inMsg.ReadInt64();
            _emptyChipRewardRemainCount = inMsg.ReadInt32();

            _updateDateTime = inMsg.ReadBoolean();
            if (_updateDateTime == true)
            {
                _emptyChipRewardLastUpdateDateTime = DateTime.Parse(inMsg.ReadString());
            }
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write(_emptyChipRewardChip);
            outMsg.Write(_emptyChipRewardRemainCount);

            outMsg.Write(_updateDateTime);
            if (_updateDateTime == true)
            {
                outMsg.Write(_emptyChipRewardLastUpdateDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
            }
        }
    }
    #endregion
}

#endregion

#region ����Ĩ ���� ���� ������Ʈ ��û

public class AcNetDataSS_reqEmptyChipRewardInfoUpdate : AcNetData_base
{
    public long _userUId;
    public int _emptyChipRewardRemainCount;
    public DateTime _emptyChipRewardLastUpdateDateTime;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _emptyChipRewardRemainCount = inMsg.ReadInt32();
        _emptyChipRewardLastUpdateDateTime = DateTime.Parse(inMsg.ReadString());
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        outMsg.Write(_emptyChipRewardRemainCount);
        outMsg.Write(_emptyChipRewardLastUpdateDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// Ȱ��ȭ ���� ���� �׷�
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region Ȱ��ȭ ���� ���� �׷� ���� ��û

public class AcNetDataSS_reqActiveGameServerGroupInfo : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSS_resActiveGameServerGroupInfo : AcNetData_base
{
    public eGameServerGroupType _gameServerGroupType;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _gameServerGroupType = (eGameServerGroupType)inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_gameServerGroupType);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// �� ä��
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region �� ä�� ���� ����

public class AcNetDataSC_notifyChannelRoomOpen : AcNetData_base
{
    public List<int> _channelRoomDataIdList = new List<int>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        ListParse(inMsg, _channelRoomDataIdList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        ListPacking(outMsg, _channelRoomDataIdList);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// �̺�Ʈ
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ���� �̺�Ʈ ���� ������Ʈ ��û

public class AcNetDataSS_reqUserEventInfoUpdate : AcNetData_base
{
    public AcNetData_UserEventInfo _userEventInfo = new AcNetData_UserEventInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userEventInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        _userEventInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region ���� �̺�Ʈ ���� �̺�Ʈ Ŭ���� ����

public class AcNetDataSC_notifyUserAllInEventClear : AcNetData_base
{
    public long _allInCount;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _allInCount = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_allInCount);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ���� ����Ʈ ��û

public class AcNetDataCS_reqBuffInfoList : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}
public class AcNetDataSC_resBuffInfoList : AcNetData_base
{
    public List<AcNetData_BuffInfo> _buffInfoList = new List<AcNetData_BuffInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        ResultParse(inMsg);
        ListParse(inMsg, _buffInfoList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        ResultPacking(outMsg);
        ListPacking(outMsg, _buffInfoList);
    }
    #endregion
}


#endregion

#region ���� ������Ʈ ����

public class AcNetDataSC_notifyBuffUpdate : AcNetData_base
{
    public List<AcNetData_BuffInfo> _updateBuffInfoList = new List<AcNetData_BuffInfo>();
    public List<long> _removeBuffInfoList = new List<long>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        ListParse(inMsg, _updateBuffInfoList);
        ListParse(inMsg, _removeBuffInfoList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        ListPacking(outMsg, _updateBuffInfoList);
        ListPacking(outMsg, _removeBuffInfoList);
    }
    #endregion
}

#endregion
