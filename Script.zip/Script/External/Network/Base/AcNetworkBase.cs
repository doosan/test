using UnityEngine;
using System.Collections.Generic;
using System;


// �⺻ ����
public class AcNetworkBase
{
    //public static string _remoteIP_Login = "172.28.89.195";

    // ���μ���
    //public static string _remoteIP_Login = "172.28.89.219";


    // QA����
    //public static string _remoteIP_Login = "172.28.89.99";




    ////�� �ε�����
    //public static string _remoteIP_Login = "40.81.94.255";
    //// �ε� ����Ʈ ��Ī ����
    //public static string _remoteWebAdress_Patch = "http://104.211.187.101/Patch/";
    //public static string _remoteWebAdress_Log = "http://104.211.183.85:853/Support/SaveLog";
    //public static string _remoteWebAdress_PrivacyPolicy = "http://104.211.187.101/PrivacyPolicyInfo/";





    // �ε�����
    public static string _remoteIP_Login = "104.211.164.44";
    // �ε� ���� ��ġ ����
    public static string _remoteWebAdress_Patch = "http://104.211.164.44/Patch/";
    public static string _remoteWebAdress_Log = "http://104.211.164.44:853/Support/SaveLog";
    public static string _remoteWebAdress_PrivacyPolicy = "http://104.211.164.44/PrivacyPolicyInfo/";




    public static int _listenPort_Login = 847;
    public static int _listenPort_Http_Login = 850;

    public static float _clientVersion = Convert.ToSingle(Application.version);
}

//------------------------------------------------------------------------------------------------------------------------------------------------------
class LTPServerCheckInfo
{
    public int IsServerCheck;
    public int ServerCehckNameId;
    public string ServerVersionString;
    public string ServerCheckString;
}

//------------------------------------------------------------------------------------------------------------------------------------------------------
class LTPServerPrivacyPolicy_DateTimeInfo
{
    public string DateTime;
}

//------------------------------------------------------------------------------------------------------------------------------------------------------
class LTPServerPrivacyPolicy_ContentsInfo
{
    public string Contents;
}