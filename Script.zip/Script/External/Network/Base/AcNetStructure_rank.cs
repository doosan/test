using System.Collections.Generic;
using System;
using Lidgren.Network;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// ��ũ ���� (����)
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ��ũ ���� ���� ����Ʈ ��û

public class AcNetDataCS_reqRankUserList : AcNetData_base
{
    public byte _TOTRankRefreshIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _TOTRankRefreshIndex = inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_TOTRankRefreshIndex);
    }
    #endregion
}

public class AcNetDataSS_reqRankUserList : AcNetData_base
{
    public long _userUId;
    public byte _TOTRankRefreshIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ProxyParse(inMsg);
        _userUId = inMsg.ReadInt64();
        _TOTRankRefreshIndex = inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ProxyPacking(outMsg);
        outMsg.Write(_userUId);
        outMsg.Write(_TOTRankRefreshIndex);
    }
    #endregion
}

public class AcNetDataSC_resRankUserList : AcNetData_base
{
    public byte _TOTRankRefreshIndex;
    public List<AcNetData_RankUserInfo> _rankUserList = new List<AcNetData_RankUserInfo>();
    public AcNetData_SimpleRankUserInfo _myRankUserInfo = new AcNetData_SimpleRankUserInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        _TOTRankRefreshIndex = inMsg.ReadByte();
        ListParse(inMsg, _rankUserList);
        _myRankUserInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        outMsg.Write(_TOTRankRefreshIndex);
        ListPacking(outMsg, _rankUserList);
        _myRankUserInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region ���� �׷� ���� ��û

public class AcNetDataCS_reqLeagueGroupInfo : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
    }
    #endregion
}

public class AcNetDataSS_reqLeagueGroupInfo : AcNetData_base
{
    public long _userUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ProxyParse(inMsg);
        _userUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ProxyPacking(outMsg);
        outMsg.Write(_userUId);
    }
    #endregion
}

public class AcNetDataSC_resLeagueGroupInfo : AcNetData_base
{
    public int _leagueCalcRestSecond;
    public AcNetData_LeagueGroupInfo _leagueGroupInfo = new AcNetData_LeagueGroupInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        _leagueCalcRestSecond = inMsg.ReadInt32();
        _leagueGroupInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        outMsg.Write(_leagueCalcRestSecond);
        _leagueGroupInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region ���� ���� �׷� ���� ��û

public class AcNetDataCS_reqSimpleLeagueGroupInfo : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
    }
    #endregion
}

public class AcNetDataSS_reqSimpleLeagueGroupInfo : AcNetData_base
{
    public long _userUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ProxyParse(inMsg);
        _userUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ProxyPacking(outMsg);
        outMsg.Write(_userUId);
    }
    #endregion
}

public class AcNetDataSC_resSimpleLeagueGroupInfo : AcNetData_base
{
    public AcNetData_SimpleLeagueGroupInfo _leagueGroupInfo = new AcNetData_SimpleLeagueGroupInfo();
    public bool _leagueCalc;
    public DateTime _leagueStartDate;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        _leagueGroupInfo.Parse(inMsg);

        _leagueCalc = inMsg.ReadBoolean();
        if (_leagueCalc == true)
        {
            _leagueStartDate = DateTime.Parse(inMsg.ReadString());
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        _leagueGroupInfo.Packing(outMsg);

        outMsg.Write(_leagueCalc);
        if (_leagueCalc == true)
        {
            outMsg.Write(_leagueStartDate.ToString("yyyy-MM-dd HH:mm:ss.fff"));
        }
    }
    #endregion
}

#endregion

#region Ĩ ��ũ ���� ���� ����Ʈ ��û

public class AcNetDataCS_reqChipRankUserList : AcNetData_base
{
    public byte _chipRankRefreshIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _chipRankRefreshIndex = inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_chipRankRefreshIndex);
    }
    #endregion
}

public class AcNetDataSS_reqChipRankUserList : AcNetData_base
{
    public long _userUId;
    public byte _chipRankRefreshIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ProxyParse(inMsg);
        _userUId = inMsg.ReadInt64();
        _chipRankRefreshIndex = inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ProxyPacking(outMsg);
        outMsg.Write(_userUId);
        outMsg.Write(_chipRankRefreshIndex);
    }
    #endregion
}

public class AcNetDataSC_resChipRankUserList : AcNetData_base
{
    public byte _chipRankRefreshIndex;
    public List<AcNetData_ChipRankUserInfo> _rankUserList = new List<AcNetData_ChipRankUserInfo>();
    public AcNetData_SimpleChipRankUserInfo _myRankUserInfo = new AcNetData_SimpleChipRankUserInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        _chipRankRefreshIndex = inMsg.ReadByte();
        ListParse(inMsg, _rankUserList);
        _myRankUserInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        outMsg.Write(_chipRankRefreshIndex);
        ListPacking(outMsg, _rankUserList);
        _myRankUserInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region ���� ���� ����

public class AcNetDataSC_notifyLeagueStart : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

#endregion

#region ���� �� ����

public class AcNetDataSC_notifyLeagueEnd : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

#endregion

#region Ĩ ��ũ ���� ���� ����Ʈ ��û

public class AcNetDataCS_reqAccumulateLuckyPointInfo : AcNetData_base
{

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSS_reqAccumulateLuckyPointInfo : AcNetData_base
{
    public long _userUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ProxyParse(inMsg);
        _userUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ProxyPacking(outMsg);
        outMsg.Write(_userUId);
    }
    #endregion
}

public class AcNetDataSC_resAccumulateLuckyPointInfo : AcNetData_base
{
    public long _accumulateLuckyPoint;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        _accumulateLuckyPoint = inMsg.ReadInt64();
    }
    #endregion

        #region �޽��� ��ŷ
        //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        outMsg.Write(_accumulateLuckyPoint);
    }
    #endregion
}

#endregion

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// ��ũ ���� (����)
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ���� ����Ʈ �߰� ��û

public class AcNetDataSS_reqLeaguePointAdd : AcNetData_base
{
    public List<AcNetData_LeaguePointInfo> _leaguePointList = new List<AcNetData_LeaguePointInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        ListParse(inMsg, _leaguePointList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        ListPacking(outMsg, _leaguePointList);
    }
    #endregion
}

#endregion

#region TOT è�Ǿ� ����Ʈ �߰� ��û

public class AcNetDataSS_reqTOTChampionShipPointAdd : AcNetData_base
{
    public List<AcNetData_TOTChampionShipPointInfo> _tOTChampionShipPointList = new List<AcNetData_TOTChampionShipPointInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        ListParse(inMsg, _tOTChampionShipPointList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        ListPacking(outMsg, _tOTChampionShipPointList);
    }
    #endregion
}

#endregion

#region ���� ������ �α��� ��û

public class AcNetDataSS_reqUserLogin : AcNetData_base
{
    public AcNetData_UserInfo _userNetData = new AcNetData_UserInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userNetData.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        _userNetData.Packing(outMsg);
    }
    #endregion
}

#endregion

#region ���� ������ �α׾ƿ� ��û

public class AcNetDataSS_reqUserLogout : AcNetData_base
{
    public string _userId;
    public long _userUId;
    public eUserLogOutType _logoutType;
    public string _mACAddress;
    public string _deviceCode;
    public eLanguageType _languageType;
    public byte _optionPushStates;
    public long _lastTotalChip;
    
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userId = inMsg.ReadString();
        _userUId = inMsg.ReadInt64();
        _logoutType = (eUserLogOutType)inMsg.ReadByte();

        _mACAddress = inMsg.ReadString();
        _deviceCode = inMsg.ReadString();

        _languageType = (eLanguageType)inMsg.ReadByte();
        _optionPushStates = inMsg.ReadByte();
        _lastTotalChip = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userId);
        outMsg.Write(_userUId);
        outMsg.Write((byte)_logoutType);

        outMsg.Write(_mACAddress);
        outMsg.Write(_deviceCode);

        outMsg.Write((byte)_languageType);
        outMsg.Write(_optionPushStates);
        outMsg.Write(_lastTotalChip);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// TOT è�Ǿ� ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region TOT è�Ǿ� ���� ���� ���� ��û

public class AcNetDataSS_reqTOTChampionShipStateInfo : AcNetData_base
{
    #region �޽��� �Ľ�

    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }

    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSS_resTOTChampionShipStateInfo : AcNetData_base
{
    public eTOTChampionShipState _tOTChampionShipState;

    public DateTime _tOTChampionShipEndDateTime;
    public int _tOTChampionShipGameModeDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _tOTChampionShipState = (eTOTChampionShipState)inMsg.ReadByte();
        if (_tOTChampionShipState == eTOTChampionShipState.STATE_START)
        {
            _tOTChampionShipEndDateTime = DateTime.Parse(inMsg.ReadString());
            _tOTChampionShipGameModeDataId = inMsg.ReadInt32();
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_tOTChampionShipState);
        if (_tOTChampionShipState == eTOTChampionShipState.STATE_START)
        {
            outMsg.Write(_tOTChampionShipEndDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
            outMsg.Write(_tOTChampionShipGameModeDataId);
        }
    }
    #endregion
}

public class AcNetDataSC_notifyTOTChampionShipStateInfo : AcNetData_base
{
    public eTOTChampionShipState _tOTChampionShipState;

    public DateTime _tOTChampionShipEndDateTime;
    public int _tOTChampionShipGameModeDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _tOTChampionShipState = (eTOTChampionShipState)inMsg.ReadByte();
        if (_tOTChampionShipState == eTOTChampionShipState.STATE_START)
        {
            _tOTChampionShipEndDateTime = DateTime.Parse(inMsg.ReadString());
            _tOTChampionShipGameModeDataId = inMsg.ReadInt32();
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_tOTChampionShipState);
        if (_tOTChampionShipState == eTOTChampionShipState.STATE_START)
        {
            outMsg.Write(_tOTChampionShipEndDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
            outMsg.Write(_tOTChampionShipGameModeDataId);
        }
    }
    #endregion
}

#endregion

#region TOT è�Ǿ� ���� ����Ʈ ���� ��û

public class AcNetDataCS_reqTOTChampionShipUserList : AcNetData_base
{
    public eTOTChampionShipGradeType _tOTChampionShipType;
    public long _tOTChampionShipRankRefreshIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _tOTChampionShipType = (eTOTChampionShipGradeType)inMsg.ReadByte();
        _tOTChampionShipRankRefreshIndex = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_tOTChampionShipType);
        outMsg.Write(_tOTChampionShipRankRefreshIndex);
    }
    #endregion
}

public class AcNetDataSS_reqTOTChampionShipUserList : AcNetData_base
{
    public long _userUId;
    public eTOTChampionShipGradeType _tOTChampionShipType;
    public long _tOTChampionShipRankRefreshIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ProxyParse(inMsg);
        _userUId = inMsg.ReadInt64();
        _tOTChampionShipType = (eTOTChampionShipGradeType)inMsg.ReadByte();
        _tOTChampionShipRankRefreshIndex = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ProxyPacking(outMsg);
        outMsg.Write(_userUId);
        outMsg.Write((byte)_tOTChampionShipType);
        outMsg.Write(_tOTChampionShipRankRefreshIndex);
    }
    #endregion
}

public class AcNetDataSC_resTOTChampionShipUserList : AcNetData_base
{
    public List<AcNetData_TOTChampionShipUserInfo> _userInfoList = new List<AcNetData_TOTChampionShipUserInfo>();
    public AcNetData_TOTChampionShipUserInfo _myUserInfo = new AcNetData_TOTChampionShipUserInfo();
    public long _tOTChampionShipRankRefreshIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        ListParse(inMsg, _userInfoList);
        _myUserInfo.Parse(inMsg);
        _tOTChampionShipRankRefreshIndex = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        ListPacking(outMsg, _userInfoList);
        _myUserInfo.Packing(outMsg);
        outMsg.Write(_tOTChampionShipRankRefreshIndex);
    }
    #endregion
}
#endregion

#region ���� TOT è�Ǿ� ���� ���� ��û

public class AcNetDataCS_reqSimpleTOTChampionShipUserList : AcNetData_base
{
    public long _tOTChampionShipRankRefreshIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _tOTChampionShipRankRefreshIndex = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_tOTChampionShipRankRefreshIndex);
    }
    #endregion
}

public class AcNetDataSS_reqSimpleTOTChampionShipUserList : AcNetData_base
{
    public long _userUId;
    public long _tOTChampionShipRankRefreshIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ProxyParse(inMsg);
        _userUId = inMsg.ReadInt64();
        _tOTChampionShipRankRefreshIndex = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ProxyPacking(outMsg);
        outMsg.Write(_userUId);
        outMsg.Write(_tOTChampionShipRankRefreshIndex);
    }
    #endregion
}

public class AcNetDataSC_resSimpleTOTChampionShipUserList : AcNetData_base
{
    public List<AcNetData_SimpleTOTChampionShipUserInfo> _userInfoList = new List<AcNetData_SimpleTOTChampionShipUserInfo>();
    public AcNetData_SimpleTOTChampionShipUserInfo _myUserInfo = new AcNetData_SimpleTOTChampionShipUserInfo();
    public long _tOTChampionShipRankRefreshIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        ListParse(inMsg, _userInfoList);
        _myUserInfo.Parse(inMsg);
        _tOTChampionShipRankRefreshIndex = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        ListPacking(outMsg, _userInfoList);
        _myUserInfo.Packing(outMsg);
        outMsg.Write(_tOTChampionShipRankRefreshIndex);
    }
    #endregion
}
#endregion

#region TOT è�Ǿ� BuyIn ��û

public class AcNetDataCS_reqTOTChampionShipBuyIn : AcNetData_base
{
    public eTOTChampionShipBuyInType _buyInType;

    #region �޽��� �Ľ�

    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _buyInType = (eTOTChampionShipBuyInType)inMsg.ReadByte();
    }

    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_buyInType);
    }
    #endregion
}

public class AcNetDataSS_reqTOTChampionShipBuyIn : AcNetData_base
{
    public long _userUId;
    public eTOTChampionShipBuyInType _buyInType;

    #region �޽��� �Ľ�

    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ProxyParse(inMsg);

        _userUId = inMsg.ReadInt64();
        _buyInType = (eTOTChampionShipBuyInType)inMsg.ReadByte();
    }

    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ProxyPacking(outMsg);

        outMsg.Write(_userUId);
        outMsg.Write((byte)_buyInType);
    }
    #endregion
}

public class AcNetDataSS_resTOTChampionShipBuyIn : AcNetData_base
{
    public eTOTChampionShipBuyInType _buyInType;
    public eTOTChampionShipGradeType _userGradeType;

    #region �޽��� �Ľ�

    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _buyInType = (eTOTChampionShipBuyInType)inMsg.ReadByte();
            _userGradeType = (eTOTChampionShipGradeType)inMsg.ReadByte();
        }
    }

    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write((byte)_buyInType);
            outMsg.Write((byte)_userGradeType);
        }
    }
    #endregion
}

public class AcNetDataSC_resTOTChampionShipBuyIn : AcNetData_base
{
    public List<AcNetData_ItemChangeInfo> _itemChangeInfoList = new List<AcNetData_ItemChangeInfo>();

    #region �޽��� �Ľ�

    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);

        ListParse(inMsg, _itemChangeInfoList);
    }

    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);

        ListPacking(outMsg, _itemChangeInfoList);
    }
    #endregion
}

#endregion