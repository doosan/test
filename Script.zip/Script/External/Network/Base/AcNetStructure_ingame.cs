using System.Collections.Generic;
using System;
using Lidgren.Network;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// �ΰ���
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ���� ���۵� ����

public class AcNetDataSC_notifyRoomGameStart : AcNetData_base
{
    public long _roomIndex;
    public eGameType _gameType;
    public int _dealerSlotNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        _roomIndex = inMsg.ReadInt64();
        _gameType = (eGameType)inMsg.ReadByte();
        _dealerSlotNumber = inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        outMsg.Write(_roomIndex);
        outMsg.Write((byte)_gameType);
        outMsg.Write((byte)_dealerSlotNumber);
    }
    #endregion
}

#endregion

#region ���� ���� ����

public class AcNetDataSC_notifyRoomGameEnd : AcNetData_base
{
    public long _roomIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
    }
    #endregion
}

#endregion

#region ���� �� ����

public class AcNetDataSC_notifyCurrentTurn : AcNetData_base
{
    public long _roomIndex;
    public int _currentTurnSlotNumber;
    public long _totalPot;
    public long _stakeChip;
    public int _circleCount;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _currentTurnSlotNumber = inMsg.ReadByte();
        _totalPot = inMsg.ReadInt64();
        _stakeChip = inMsg.ReadInt64();
        _circleCount = inMsg.ReadInt16();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write((byte)_currentTurnSlotNumber);
        outMsg.Write(_totalPot);
        outMsg.Write(_stakeChip);
        outMsg.Write((short)_circleCount);
    }
    #endregion
}

#endregion

#region ���� ���� ��û

public class AcNetDataCS_reqBetting : AcNetData_base
{
    public long _roomIndex;
    public eBettingType _bettingType;
    public long _balance;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _bettingType = (eBettingType)inMsg.ReadByte();
        _balance = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write((byte)_bettingType);
        outMsg.Write(_balance);
    }
    #endregion
}

public class AcNetDataSC_resBetting : AcNetData_base
{
    public long _roomIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        _roomIndex = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        outMsg.Write(_roomIndex);
    }
    #endregion
}

#endregion

#region ���� ���� ����

public class AcNetDataSC_notifyBetting : AcNetData_base
{
    public long _roomIndex;
    public int _slotNumber;
    public eBettingType _bettingType;
    public long _totalPot;
    public long _bettingBalance;
    public long _stakeBalance;
    public long _bettingUserBalance;

    // ���̵��
    public int _sideShowSrcSlotNumber;
    public int _sideShowDstSlotNumber;

    // ����
    public List<long> _allInChipSlotList = new List<long>();

    // ������ ȹ���� LP
    public long _changeBuffLP;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _slotNumber = inMsg.ReadByte();
        _bettingType = (eBettingType)inMsg.ReadByte();
        _totalPot = inMsg.ReadInt64();
        _bettingBalance = inMsg.ReadInt64();
        _stakeBalance = inMsg.ReadInt64();
        _bettingUserBalance = inMsg.ReadInt64();

        if (_bettingType == eBettingType.TYPE_SIDESHOW)
        {
            _sideShowSrcSlotNumber = inMsg.ReadByte();
            _sideShowDstSlotNumber = inMsg.ReadByte();
        }
        else if (_bettingType == eBettingType.TYPE_ALLIN)
        {
            ListParse(inMsg, _allInChipSlotList);
        }

        _changeBuffLP = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write((byte)_slotNumber);
        outMsg.Write((byte)_bettingType);
        outMsg.Write(_totalPot);
        outMsg.Write(_bettingBalance);
        outMsg.Write(_stakeBalance);
        outMsg.Write(_bettingUserBalance);

        if (_bettingType == eBettingType.TYPE_SIDESHOW)
        {
            outMsg.Write((byte)_sideShowSrcSlotNumber);
            outMsg.Write((byte)_sideShowDstSlotNumber);
        }
        else if (_bettingType == eBettingType.TYPE_ALLIN)
        {
            ListPacking(outMsg, _allInChipSlotList);
        }

        outMsg.Write(_changeBuffLP);
    }
    #endregion
}

#endregion

#region ���� ī�� ���� ��û

public class AcNetDataCS_reqCardSee : AcNetData_base
{
    public long _roomIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
    }
    #endregion
}

public class AcNetDataSC_resCardSee : AcNetData_base
{
    public long _roomIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        _roomIndex = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        outMsg.Write(_roomIndex);
    }
    #endregion
}

#endregion

#region ���� ī�� ���� ����

public class AcNetDataSC_notifyCardSee : AcNetData_base
{
    public long _roomIndex;
    public int _slotNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _slotNumber = inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write((byte)_slotNumber);
    }
    #endregion
}

#endregion

#region ���� ī�� ���� ���� ����

public class AcNetDataSC_notifyForceCardSee : AcNetData_base
{
    public long _roomIndex;
    public int _slotNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _slotNumber = inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write((byte)_slotNumber);
    }
    #endregion
}

#endregion

#region ���� ���̵� �� �������� ��û

public class AcNetDataCS_reqSideShowAccept : AcNetData_base
{
    public long _roomIndex;
    public bool _accept;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _accept = inMsg.ReadBoolean();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write(_accept);
    }
    #endregion
}

public class AcNetDataSC_resSideShowAccept : AcNetData_base
{
    public long _roomIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        _roomIndex = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        outMsg.Write(_roomIndex);
    }
    #endregion
}

#endregion

#region ���� ���̵�� ���� ���� ����

public class AcNetDataSC_notifySideShowAccept : AcNetData_base
{
    public long _roomIndex;
    public bool _accept;

    public int _sideShowSrcSlotNumber;
    public int _sideShowDstSlotNumber;
    public eGameResultType _gameResultType;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _accept = inMsg.ReadBoolean();

        if (_accept == true)
        {
            _sideShowSrcSlotNumber = inMsg.ReadByte();
            _sideShowDstSlotNumber = inMsg.ReadByte();
            _gameResultType = (eGameResultType)inMsg.ReadByte();
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write(_accept);

        if(_accept == true)
        {
            outMsg.Write((byte)_sideShowSrcSlotNumber);
            outMsg.Write((byte)_sideShowDstSlotNumber);
            outMsg.Write((byte)_gameResultType);
        }
    }
    #endregion
}

#endregion

#region ���� ���� �������� ��û

public class AcNetDataCS_reqAllInAccept : AcNetData_base
{
    public long _roomIndex;
    public bool _accept;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _accept = inMsg.ReadBoolean();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write(_accept);
    }
    #endregion
}

public class AcNetDataSC_resAllInAccept : AcNetData_base
{
    public long _roomIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        _roomIndex = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        outMsg.Write(_roomIndex);
    }
    #endregion
}

#endregion

#region ���� ���� ���� ���� ����

public class AcNetDataSC_notifyAllInAccept : AcNetData_base
{
    public long _roomIndex;
    public bool _accept;

    public int _allInUserSlotNumber;
    public long _totalPot;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _accept = inMsg.ReadBoolean();
        _allInUserSlotNumber = inMsg.ReadByte();

        if (_accept == true)
        {
            _totalPot = inMsg.ReadInt64();
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write(_accept);
        outMsg.Write((byte)_allInUserSlotNumber);

        if (_accept == true)
        {
            outMsg.Write(_totalPot);
        }
    }
    #endregion
}

#endregion

#region ���� ����

public class AcNetDataSC_notifyRoundState : AcNetData_base
{
    public long _roomIndex;
    public eRoundState _roundState;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _roundState = (eRoundState)inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write((byte)_roundState);
    }
    #endregion
}

#endregion

#region ��ٿ� Ÿ�� ����

public class AcNetDataSC_notifyShowDownType : AcNetData_base
{
    public long _roomIndex;
    public eShowDownType _showDownType;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _showDownType = (eShowDownType)inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write((byte)_showDownType);
    }
    #endregion
}

#endregion

#region �� ���� ����

public class AcNetDataSC_notifyDeckReceive : AcNetData_base
{
    public long _roomIndex;
    public int _slotNumber;
    public AcNetData_DeckInfo _deckInfo = new AcNetData_DeckInfo();
    
    // ��Ŀ��
    public AcNetData_DeckInfo _deckInfo_joker = new AcNetData_DeckInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _slotNumber = inMsg.ReadByte();
        _deckInfo.Parse(inMsg);
        _deckInfo_joker.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write((byte)_slotNumber);
        _deckInfo.Packing(outMsg);
        _deckInfo_joker.Packing(outMsg);
    }
    #endregion
}

#endregion

#region ���� ��� ����

public class AcNetDataSC_notifyGameResult : AcNetData_base
{
    public long _roomIndex;
    public long _winnerReceiveBalance;
    public List<int> _winnerSlotNumberList = new List<int>();
    public List<AcNetData_LeaguePointInfo> _leaguePointList = new List<AcNetData_LeaguePointInfo>();
    public List<AcNetData_GameResultPenaltyInfo> _penaltyInfoList = new List<AcNetData_GameResultPenaltyInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _winnerReceiveBalance = inMsg.ReadInt64();
        ListParse(inMsg, _winnerSlotNumberList);
        ListParse(inMsg, _leaguePointList);
        ListParse(inMsg, _penaltyInfoList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write(_winnerReceiveBalance);
        ListPacking(outMsg, _winnerSlotNumberList);
        ListPacking(outMsg, _leaguePointList);
        ListPacking(outMsg, _penaltyInfoList);
    }
    #endregion
}

#endregion

#region ����ǥ�� ��û

public class AcNetDataCS_reqAnimation : AcNetData_base
{
    public long _roomIndex;
    public int _animationId;
    public int _dstSlotNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _animationId = inMsg.ReadInt16();
        _dstSlotNumber = inMsg.ReadByte();

    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write((short)_animationId);
        outMsg.Write((byte)_dstSlotNumber);
    }
    #endregion
}

public class AcNetDataSC_resAnimation : AcNetData_base
{
    public int _dstSlotNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        _dstSlotNumber = inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        outMsg.Write((byte)_dstSlotNumber);
    }
    #endregion
}

public class AcNetDataSC_notifyAnimation : AcNetData_base
{
    public long _roomIndex;
    public int _animationId;
    public int _srcSlotNumber;
    public int _dstSlotNumber;
    public long _userSafeChip;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _animationId = inMsg.ReadInt32();
        _srcSlotNumber = inMsg.ReadByte();
        _dstSlotNumber = inMsg.ReadByte();
        _userSafeChip = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write(_animationId);
        outMsg.Write((byte)_srcSlotNumber);
        outMsg.Write((byte)_dstSlotNumber);
        outMsg.Write(_userSafeChip);
    }
    #endregion
}
#endregion

#region ���� �� ��û

public class AcNetDataCS_reqDealerTip : AcNetData_base
{
    public long _roomIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
    }
    #endregion
}

public class AcNetDataSC_resDealerTip : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
    }
    #endregion
}

public class AcNetDataSC_notifyDealerTip : AcNetData_base
{
    public int _slotNumber;
    public long _userSafeChip;
    public long _roomIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _slotNumber = inMsg.ReadByte();
        _userSafeChip = inMsg.ReadInt64();
        _roomIndex = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_slotNumber);
        outMsg.Write(_userSafeChip);
        outMsg.Write(_roomIndex);
    }
    #endregion
}
#endregion

#region ���� �غ� ��û

public class AcNetDataCS_reqGameReady : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
    }
    #endregion
}

public class AcNetDataSC_resGameReady : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
    }
    #endregion
}
#endregion

#region ���� ���� �� �� ����

public class AcNetDataSC_notifyCurrentTurnDeck : AcNetData_base
{
    public int _slotNumber;
    public int _currentTurnDeckNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _slotNumber = inMsg.ReadByte();
        _currentTurnDeckNumber = inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_slotNumber);
        outMsg.Write((byte)_currentTurnDeckNumber);
    }
    #endregion
}

#endregion

#region �ݰ� Ĩ �̵� ����

public class AcNetDataSC_notifySafeMoveChip : AcNetData_base
{
    public long _roomIndex;
    public int _slotNumber;
    public long _safeChip;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _slotNumber = inMsg.ReadByte();
        _safeChip = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write((byte)_slotNumber);
        outMsg.Write(_safeChip);
    }
    #endregion
}

#endregion

#region ��Ż�� ����

public class AcNetDataSC_notifyTotalPot : AcNetData_base
{
    public long _roomIndex;
    public long _totalPot;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _totalPot = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write(_totalPot);
    }
    #endregion
}

#endregion

#region ���� ���ɿ��� ����

public class AcNetDataSC_notifyBettingEnable : AcNetData_base
{
    public long _roomIndex;
    public bool _bettingEnable;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _bettingEnable = inMsg.ReadBoolean();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write(_bettingEnable);
    }
    #endregion
}

#endregion

#region ���� �� ��û

public class AcNetDataCS_reqRoomMainSelect : AcNetData_base
{
    public long _roomIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
    }
    #endregion
}

public class AcNetDataSC_resRoomMainSelect : AcNetData_base
{
    public long _roomIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        _roomIndex = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        outMsg.Write(_roomIndex);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// [����ü] HighOrLow
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region HighOrLow ���� �÷��� ��û

public class AcNetDataCS_reqHighOrLowGamePlay : AcNetData_base
{
    public bool _firstPlay;
    public int _hightOrLowDataId;
    public long _bettingItemvalue;
    public eHighOrLowSelectType _selectType;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _firstPlay = inMsg.ReadBoolean();
        _hightOrLowDataId = inMsg.ReadInt32();
        _bettingItemvalue = inMsg.ReadInt64();
        _selectType = (eHighOrLowSelectType)inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_firstPlay);
        outMsg.Write(_hightOrLowDataId);
        outMsg.Write(_bettingItemvalue);
        outMsg.Write((byte)_selectType);
    }
    #endregion
}

public class AcNetDataSC_resHighOrLowGamePlay : AcNetData_base
{
    public eGameResultType _gameResultType;
    public AcNetData_CardInfo _resultCardInfo = new AcNetData_CardInfo();
    public long _changeItemValue;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _gameResultType = (eGameResultType)inMsg.ReadByte();
            _resultCardInfo.Parse(inMsg);
            _changeItemValue = inMsg.ReadInt64();
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write((byte)_gameResultType);
            _resultCardInfo.Packing(outMsg);
            outMsg.Write(_changeItemValue);
        }
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// [����ü] �����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ����� ����

public class AcNetDataCS_reqDebugCommand : AcNetData_base
{
    public string _writeString;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        _writeString = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        outMsg.Write(_writeString);
    }
    #endregion
}

public class AcNetDataSC_resDebugCommand : AcNetData_base
{
    public string _writeString;
    public List<AcNetData_ItemChangeInfo> _itemChangeInfoList = new List<AcNetData_ItemChangeInfo>();
    public DateTime _dateTime;
    public int _integerValue;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if(_result == eGameResult.RESULT_OK)
        {
            _writeString = inMsg.ReadString();
            ListParse(inMsg, _itemChangeInfoList);
            _dateTime = DateTime.Parse(inMsg.ReadString());
            _integerValue = inMsg.ReadInt32();
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write(_writeString);
            ListPacking(outMsg, _itemChangeInfoList);
            outMsg.Write(_dateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
            outMsg.Write(_integerValue);
        }
    }
    #endregion
}

#endregion