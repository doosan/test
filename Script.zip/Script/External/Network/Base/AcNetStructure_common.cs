using System.Collections.Generic;
using System;
using Lidgren.Network;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// �⺻ ��Ŷ 
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region [����ü] �⺻ ��Ŷ

public class AcNetData_base
{
#if UNITY_EDITOR || UNITY_ANDROID || UNITY_IOS || UNITY_WEBGL
    [System.NonSerialized] 
#else
    [Newtonsoft.Json.JsonIgnore]
#endif
    public long _proxyGuid = -1;

#if UNITY_EDITOR || UNITY_ANDROID || UNITY_IOS || UNITY_WEBGL
    [System.NonSerialized] 
#else
    [Newtonsoft.Json.JsonIgnore]
#endif
    public eGameResult _result = eGameResult.RESULT_OK;

    public virtual void Parse(NetIncomingMessage inMsg)
    {
        var isReadProxyGuid = inMsg.ReadBoolean();
        if (isReadProxyGuid == true)
        {
            _proxyGuid = inMsg.ReadInt64();
        }
        
        _result = (eGameResult)inMsg.ReadUInt16();
    }

    public virtual void Packing(NetOutgoingMessage outMsg)
    {
        if (_proxyGuid == -1)
        {
            outMsg.Write(false);
        }
        else
        {
            outMsg.Write(true);
            outMsg.Write(_proxyGuid);
        }
        
        outMsg.Write((ushort)_result);
    }

    public virtual void TempParse(NetIncomingMessage inMsg)
    {
        var temp = inMsg.ReadBoolean();
    }

    public virtual void TempPacking(NetOutgoingMessage outMsg)
    {
        outMsg.Write(true);
    }

    public virtual void ProxyParse(NetIncomingMessage inMsg)
    {
        _proxyGuid = inMsg.ReadInt64();
    }

    public virtual void ProxyPacking(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_proxyGuid);
    }

    public virtual void ResultParse(NetIncomingMessage inMsg)
    {
        _result = (eGameResult)inMsg.ReadUInt16();
    }

    public virtual void ResultPacking(NetOutgoingMessage outMsg)
    {
        outMsg.Write((ushort)_result);
    }

    protected void ListParse<T>(NetIncomingMessage inMsg, List<T> parseList) where T : AcNetData_base, new()
    {
        var listCount = inMsg.ReadInt32(); // 6��5õ����
        for (int i = 0; i < listCount; i++)
        {
            var data = new T();
            data.Parse(inMsg);
            parseList.Add(data);
        }
    }

    protected void ListPacking<T>(NetOutgoingMessage outMsg, List<T> packingList) where T : AcNetData_base, new()
    {
        outMsg.Write(packingList.Count);
        for (int i = 0; i < packingList.Count; i++)
        {
            packingList[i].Packing(outMsg);
        }
    }

    protected void ListParse(NetIncomingMessage inMsg, List<long> parseList)
    {
        var listCount = inMsg.ReadInt32();
        for (int i = 0; i < listCount; i++)
        {
            parseList.Add(inMsg.ReadInt64());
        }
    }

    protected void ListPacking(NetOutgoingMessage outMsg, List<long> packingList)
    {
        outMsg.Write(packingList.Count);
        for (int i = 0; i < packingList.Count; i++)
        {
            outMsg.Write(packingList[i]);
        }
    }

    protected void ListParse(NetIncomingMessage inMsg, List<int> parseList)
    {
        var listCount = inMsg.ReadInt32();
        for (int i = 0; i < listCount; i++)
        {
            parseList.Add(inMsg.ReadInt32());
        }
    }

    protected void ListPacking(NetOutgoingMessage outMsg, List<int> packingList)
    {
        outMsg.Write(packingList.Count);
        for (int i = 0; i < packingList.Count; i++)
        {
            outMsg.Write(packingList[i]);
        }
    }

    protected void ListParse(NetIncomingMessage inMsg, List<string> parseList)
    {
        var listCount = inMsg.ReadInt32();
        for (int i = 0; i < listCount; i++)
        {
            parseList.Add(inMsg.ReadString());
        }
    }

    protected void ListPacking(NetOutgoingMessage outMsg, List<string> packingList)
    {
        outMsg.Write(packingList.Count);
        for (int i = 0; i < packingList.Count; i++)
        {
            outMsg.Write(packingList[i]);
        }
    }
}

#endregion

#region [����ü] �޽��� �⺻ ����

public class AcNetDataSC_response : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
    }
    #endregion
}
#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// [����ü] ��Ʈ��ũ Ÿ�� ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ��Ʈ��ũ Ÿ�� ����

public class AcNetData_Certification : AcNetData_base
{
    public eCertificationType _netType;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        _netType = (eCertificationType)inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        outMsg.Write((int)_netType);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// [����ü] ���� ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ���� ����

public class AcNetData_ServerInfo : AcNetData_base
{
    public int _gameServerUId;
    public string _ip;
    public int _port;
    public int _overload;
    public eGameServerGroupType _gameServerGroupType;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        _gameServerUId = inMsg.ReadInt32();
        _ip = inMsg.ReadString();
        _port = inMsg.ReadInt32();
        _overload = inMsg.ReadInt32();
        _gameServerGroupType = (eGameServerGroupType)inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        outMsg.Write(_gameServerUId);
        outMsg.Write(_ip);
        outMsg.Write(_port);
        outMsg.Write(_overload);
        outMsg.Write((byte)_gameServerGroupType);
    }
    #endregion
}

#endregion

#region ���� ä�� ����

public class AcNetData_ServerChannelInfo : AcNetData_base
{
    public string _ip;
    public int _serverUserCount;
    public List<AcNetData_ChannelGameModeInfo> _channelGameModeInfoList = new List<AcNetData_ChannelGameModeInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _ip = inMsg.ReadString();
        _serverUserCount = inMsg.ReadInt32();
        ListParse(inMsg, _channelGameModeInfoList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_ip);
        outMsg.Write(_serverUserCount);
        ListPacking(outMsg, _channelGameModeInfoList);
    }
    #endregion
}

#endregion

#region ���� ä�� ����

public class AcNetData_ServerContentLockInfo : AcNetData_base
{
    public string _ip;
    public List<AcNetData_ChannelGameModeInfo> _channelGameModeInfoList = new List<AcNetData_ChannelGameModeInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _ip = inMsg.ReadString();
        ListParse(inMsg, _channelGameModeInfoList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_ip);
        ListPacking(outMsg, _channelGameModeInfoList);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// [����ü] �����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region �����

public class AcNetData_Debug : AcNetData_base
{
    public string _writeString;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        _writeString = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        outMsg.Write(_writeString);
    }
    #endregion
}
#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// [����ü] ī�� ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region [����ü] ī�� ����

public class AcNetData_CardInfo : AcNetData_base
{
    public eCardShapeType _shapeType;
    public int _number;

    public int CardIndex
    {
        get
        {
            var number = _number;
            if (number == 14)
            {
                number = 1;
            }

            // �ε����� �������� ����
            return (3 - (int)_shapeType) * 13 + number - 1;
        }
    }

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _shapeType = (eCardShapeType)inMsg.ReadByte();
        _number = inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_shapeType);
        outMsg.Write((byte)_number);
    }
    #endregion
}

#endregion

#region [����ü] �� ���� 

public class AcNetData_DeckInfo : AcNetData_base
{
    public int _deckNumber;
    public eGenealogyType _genealogyType;   // ���� �� ����
    public int _genealogyCardNumber;        // ������ ī�� ����(ex: ����7 ������ 7)
    public List<AcNetData_CardInfo> _cardList = new List<AcNetData_CardInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _deckNumber = inMsg.ReadByte();
        _genealogyType = (eGenealogyType)inMsg.ReadByte();
        _genealogyCardNumber = inMsg.ReadByte();
        ListParse<AcNetData_CardInfo>(inMsg, _cardList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_deckNumber);
        outMsg.Write((byte)_genealogyType);
        outMsg.Write((byte)_genealogyCardNumber);
        ListPacking<AcNetData_CardInfo>(outMsg, _cardList);
    }
    #endregion
}

#endregion

#region [����ü] ī�� �����丮 ����

public class AcNetData_RoomCardHistoryInfo : AcNetData_base
{
    public List<AcNetData_CardHistoryInfo> _cardInfoList = new List<AcNetData_CardHistoryInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {

        ListParse(inMsg, _cardInfoList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        ListPacking(outMsg, _cardInfoList);
    }
    #endregion
}

public class AcNetData_CardHistoryInfo : AcNetData_base
{
    public int _slotNumber;
    public AcNetData_CardInfo _cardInfo = new AcNetData_CardInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _slotNumber = inMsg.ReadByte();
        _cardInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_slotNumber);
        _cardInfo.Packing(outMsg);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// [����ü] ���� ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region [����ü] ���� ����
public class AcNetData_UserInfo : AcNetData_base
{
    public long _uId;
    public string _userId;
    public string _password;
    public string _nickName;
    public int _avatarDataId;
    public int _pictureDataId;

    public List<AcNetData_MultiSlotInfo> _multiSlotInfoList = new List<AcNetData_MultiSlotInfo>();
    public List<AcNetData_SafeInfo> _safeInfoList = new List<AcNetData_SafeInfo>();

    //public long _diamond;
    public AcNetData_DiamondInfo _diamondInfo = new AcNetData_DiamondInfo();
    public AcNetData_LuckyPointInfo _luckyPointInfo = new AcNetData_LuckyPointInfo();
    public AcNetData_LuckyPointInfo _luckyPointInfo_BuyIn = new AcNetData_LuckyPointInfo();
    public AcNetData_LuckyPointInfo _luckyPointInfo_BuyIn_PenaltyDeposit = new AcNetData_LuckyPointInfo();

    public int _winCount;
    public int _loseCount;
    public int _accumlatePlayTime;

    public eLeagueGradeType _leagueGradeType;
    public eLeagueGradeType _bestLeagueGradeType;
    public int _bestLeagueRankNumber;
    public AcNetData_LeagueRewardInfo _leagueRewardInfo = new AcNetData_LeagueRewardInfo();
    public AcNetData_TOTRankRewardInfo _tOTRankRewardInfo = new AcNetData_TOTRankRewardInfo();
    public AcNetData_TOTChampionShipRewardInfo _tOTChampionShipRewardInfo = new AcNetData_TOTChampionShipRewardInfo();

    public AcNetData_UserOptionInfo _userOptionInfo = new AcNetData_UserOptionInfo();

    public List<AcNetData_SetAutoInfo> _setAutoInfoList = new List<AcNetData_SetAutoInfo>();

    public List<AcNetData_ResearchInfo> _researchInfoList = new List<AcNetData_ResearchInfo>();

    public bool _ban;
    public eAccountLinkType _accountLinkType;
    public DateTime _regDate;

    public DateTime _dailyRewardDate;
    public bool _tutorialRewardReceive;

    public int _slotMachineOffsetCount;

    public DateTime _lastAttendanceDate;
    public int _attendanceSlotMachineEnableCount;
    public int _attendanceAccumulateCount;

    public DateTime _missionDailyUpdateDate;
    public DateTime _missionWeeklyUpdateDate;

    //
    public int _VIPDataId;
    public DateTime _VIPEndDateTime;

    //
    public bool _tutorialAllClear;
    public int _tutorialDayCount;
    public DateTime _tutorialUpdateDate;

    //
    public int _aDRewardLastRewardLevel;
    public DateTime _aDRewardLastUpdateDateTime;

    //
    public int _emptyChipRewardRemainCount;
    public DateTime _emptyChipRewardLastUpdateDateTime;

    // 
    public long _ganeshaPocketChip;

    // 2.04v
    public string _payTMPhoneNumber;
    public int _payTMLastUseRewardDataId;
    public bool _payTMUseAgreement;

    public DateTime _accpetPolicyDateTime;

    // �귿
    public int _rouletteFeverCount;
    public int _rouletteFreeCount;
    public DateTime _rouletteFreeUpdateDateTime;

    // ������
    public int _rankNumber;
    public long Diamond { get { return _diamondInfo.AllDiamond; } set { _diamondInfo.Reset(); _diamondInfo._diamondEvent = value; } }
    public long LuckyPoint { get { return _luckyPointInfo.AllLuckyPoint; } set { _luckyPointInfo.Reset(); _luckyPointInfo._luckyPointEvent = value; } }
    public long LuckyPointBuyIn { get { return _luckyPointInfo_BuyIn.AllLuckyPoint; } set { _luckyPointInfo_BuyIn.Reset(); _luckyPointInfo_BuyIn._luckyPointEvent = value; } }
    public long LuckyPointBuyInPenaltyDeposit { get { return _luckyPointInfo_BuyIn_PenaltyDeposit.AllLuckyPoint; } set { _luckyPointInfo_BuyIn_PenaltyDeposit.Reset(); _luckyPointInfo_BuyIn_PenaltyDeposit._luckyPointEvent = value; } }
    public DateTime _lastLoginDate;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        _uId = inMsg.ReadInt64();
        _userId = inMsg.ReadString();
        _password = inMsg.ReadString();
        _nickName = inMsg.ReadString();
        _avatarDataId = inMsg.ReadInt32();
        _pictureDataId = inMsg.ReadInt32();
        
        ListParse(inMsg, _multiSlotInfoList);
        ListParse(inMsg, _safeInfoList);

        _diamondInfo.Parse(inMsg);
        _luckyPointInfo.Parse(inMsg);

        _winCount = inMsg.ReadInt32();
        _loseCount = inMsg.ReadInt32();

        _leagueGradeType = (eLeagueGradeType)inMsg.ReadByte();
        _bestLeagueGradeType = (eLeagueGradeType)inMsg.ReadByte();
        _bestLeagueRankNumber = inMsg.ReadInt16();

        _leagueRewardInfo.Parse(inMsg);
        _tOTRankRewardInfo.Parse(inMsg);
        _tOTChampionShipRewardInfo.Parse(inMsg);

        _userOptionInfo.Parse(inMsg);

        ListParse(inMsg, _setAutoInfoList);
        ListParse(inMsg, _researchInfoList);

        _ban = inMsg.ReadBoolean();
        _accountLinkType = (eAccountLinkType)inMsg.ReadByte();
        _regDate = DateTime.Parse(inMsg.ReadString());

        _dailyRewardDate = DateTime.Parse(inMsg.ReadString());
        _tutorialRewardReceive = inMsg.ReadBoolean();

        _slotMachineOffsetCount = inMsg.ReadInt32();

        _lastAttendanceDate = DateTime.Parse(inMsg.ReadString());
        _attendanceSlotMachineEnableCount = inMsg.ReadInt32();
        _attendanceAccumulateCount = inMsg.ReadInt32();

        _missionDailyUpdateDate = DateTime.Parse(inMsg.ReadString());
        _missionWeeklyUpdateDate = DateTime.Parse(inMsg.ReadString());

        _VIPDataId = inMsg.ReadInt32();
        _VIPEndDateTime = DateTime.Parse(inMsg.ReadString());

        _tutorialDayCount = inMsg.ReadInt32();
        _tutorialUpdateDate = DateTime.Parse(inMsg.ReadString());

        _aDRewardLastRewardLevel = inMsg.ReadInt32();
        _aDRewardLastUpdateDateTime = DateTime.Parse(inMsg.ReadString());

        _emptyChipRewardRemainCount = inMsg.ReadInt32();
        _emptyChipRewardLastUpdateDateTime = DateTime.Parse(inMsg.ReadString());

        _ganeshaPocketChip = inMsg.ReadInt64();

        // 2.04v
        _payTMPhoneNumber = inMsg.ReadString();
        _payTMLastUseRewardDataId = inMsg.ReadInt32();
        _payTMUseAgreement = inMsg.ReadBoolean();

        _accpetPolicyDateTime = DateTime.Parse(inMsg.ReadString());

        _rouletteFeverCount = inMsg.ReadInt32();
        _rouletteFreeCount = inMsg.ReadInt32();
        _rouletteFreeUpdateDateTime = DateTime.Parse(inMsg.ReadString());
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        outMsg.Write(_uId);
        outMsg.Write(_userId);
        outMsg.Write(_password);
        outMsg.Write(_nickName);
        outMsg.Write(_avatarDataId);
        outMsg.Write(_pictureDataId);

        ListPacking(outMsg, _multiSlotInfoList);
        ListPacking(outMsg, _safeInfoList);

        _diamondInfo.Packing(outMsg);
        _luckyPointInfo.Packing(outMsg);

        outMsg.Write(_winCount);
        outMsg.Write(_loseCount);

        outMsg.Write((byte)_leagueGradeType);
        outMsg.Write((byte)_bestLeagueGradeType);
        outMsg.Write((short)_bestLeagueRankNumber);

        _leagueRewardInfo.Packing(outMsg);
        _tOTRankRewardInfo.Packing(outMsg);
        _tOTChampionShipRewardInfo.Packing(outMsg);

        _userOptionInfo.Packing(outMsg);

        ListPacking(outMsg, _setAutoInfoList);
        ListPacking(outMsg, _researchInfoList);

        outMsg.Write(_ban);
        outMsg.Write((byte)_accountLinkType);
        outMsg.Write(_regDate.ToString("yyyy-MM-dd HH:mm:ss.fff"));

        outMsg.Write(_dailyRewardDate.ToString("yyyy-MM-dd HH:mm:ss.fff"));
        outMsg.Write(_tutorialRewardReceive);

        outMsg.Write(_slotMachineOffsetCount);

        outMsg.Write(_lastAttendanceDate.ToString("yyyy-MM-dd HH:mm:ss.fff"));
        outMsg.Write(_attendanceSlotMachineEnableCount);
        outMsg.Write(_attendanceAccumulateCount);

        outMsg.Write(_missionDailyUpdateDate.ToString("yyyy-MM-dd HH:mm:ss"));
        outMsg.Write(_missionWeeklyUpdateDate.ToString("yyyy-MM-dd HH:mm:ss"));

        outMsg.Write(_VIPDataId);
        outMsg.Write(_VIPEndDateTime.ToString("yyyy-MM-dd HH:mm:ss"));

        outMsg.Write(_tutorialDayCount);
        outMsg.Write(_tutorialUpdateDate.ToString("yyyy-MM-dd HH:mm:ss.fff"));

        outMsg.Write(_aDRewardLastRewardLevel);
        outMsg.Write(_aDRewardLastUpdateDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));

        outMsg.Write(_emptyChipRewardRemainCount);
        outMsg.Write(_emptyChipRewardLastUpdateDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));

        outMsg.Write(_ganeshaPocketChip);

        // 2.04v
        outMsg.Write(_payTMPhoneNumber);
        outMsg.Write(_payTMLastUseRewardDataId);
        outMsg.Write(_payTMUseAgreement);

        outMsg.Write(_accpetPolicyDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));

        outMsg.Write(_rouletteFeverCount);
        outMsg.Write(_rouletteFreeCount);
        outMsg.Write(_rouletteFreeUpdateDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
    }
    #endregion
}

public class AcNetData_UserLoginInfo : AcNetData_base
{
    public long _uId;
    public eAccountLinkType _accountLinkType;
    public DateTime _regDate;
    public DateTime _lastLoginDate;
    public bool _payTMUseUser;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        _uId = inMsg.ReadInt64();
        _accountLinkType = (eAccountLinkType)inMsg.ReadByte();
        _regDate = DateTime.Parse(inMsg.ReadString());
        _lastLoginDate = DateTime.Parse(inMsg.ReadString());
        _payTMUseUser = inMsg.ReadBoolean();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        outMsg.Write(_uId);
        outMsg.Write((byte)_accountLinkType);
        outMsg.Write(_regDate.ToString("yyyy-MM-dd HH:mm:ss.fff"));
        outMsg.Write(_lastLoginDate.ToString("yyyy-MM-dd HH:mm:ss.fff"));
        outMsg.Write(_payTMUseUser);
    }
    #endregion
}

public class AcNetData_UserSimpleInfo : AcNetData_base
{
    public long _uId;
    public string _userId;
    public string _nickName;
    public int _avatarDataId;
    public int _pictureDataId;
    public eAccountLinkType _accountLinkType;
    public long _balance;
    public long _balanceReservation;
    public bool _ticketBalance;

    public AcNetData_ItemEquipSimpleInfo _ItemEquipSimpleInfo = new AcNetData_ItemEquipSimpleInfo();

    public eLeagueGradeType _leagueGradeType;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadInt64();
        _userId = inMsg.ReadString();
        _nickName = inMsg.ReadString();
        _avatarDataId = inMsg.ReadInt32();
        _pictureDataId = inMsg.ReadInt32();
        _accountLinkType = (eAccountLinkType)inMsg.ReadByte();
        _balance = inMsg.ReadInt64();
        _balanceReservation = inMsg.ReadInt64();
        _ticketBalance = inMsg.ReadBoolean();

        _leagueGradeType = (eLeagueGradeType)inMsg.ReadByte();

        _ItemEquipSimpleInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);
        outMsg.Write(_userId);
        outMsg.Write(_nickName);
        outMsg.Write(_avatarDataId);
        outMsg.Write(_pictureDataId);
        outMsg.Write((byte)_accountLinkType);
        outMsg.Write(_balance);
        outMsg.Write(_balanceReservation);
        outMsg.Write(_ticketBalance);

        outMsg.Write((byte)_leagueGradeType);

        _ItemEquipSimpleInfo.Packing(outMsg);
    }
    #endregion
}

public class AcNetData_UserProfileInfo : AcNetData_base
{
    public long _uId;
    public string _userId;
    public string _nickName;
    public int _avatarDataId;
    public int _pictureDataId;
    public eAccountLinkType _accountLinkType;

    public long _chip;
    public long _luckyPoint;

    public int _winCount;
    public int _loseCount;

    public eLeagueGradeType _leagueGradeType;
    public eLeagueGradeType _bestLeagueGradeType;
    public int _bestLeagueRankNumber;

    public AcNetData_ItemEquipSimpleInfo _ItemEquipSimpleInfo = new AcNetData_ItemEquipSimpleInfo();
    public int _rankNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadInt64();
        _userId = inMsg.ReadString();
        _nickName = inMsg.ReadString();
        _avatarDataId = inMsg.ReadInt32();
        _pictureDataId = inMsg.ReadInt32();
        _accountLinkType = (eAccountLinkType)inMsg.ReadByte();

        _chip = inMsg.ReadInt64();
        _luckyPoint = inMsg.ReadInt64();

        _winCount = inMsg.ReadInt32();
        _loseCount = inMsg.ReadInt32();

        _leagueGradeType = (eLeagueGradeType)inMsg.ReadByte();
        _bestLeagueGradeType = (eLeagueGradeType)inMsg.ReadByte();
        _bestLeagueRankNumber = inMsg.ReadInt16();

        _ItemEquipSimpleInfo.Parse(inMsg);

        _rankNumber = inMsg.ReadInt16();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);
        outMsg.Write(_userId);
        outMsg.Write(_nickName);
        outMsg.Write(_avatarDataId);
        outMsg.Write(_pictureDataId);
        outMsg.Write((byte)_accountLinkType);

        outMsg.Write(_chip);
        outMsg.Write(_luckyPoint);

        outMsg.Write(_winCount);
        outMsg.Write(_loseCount);

        outMsg.Write((byte)_leagueGradeType);
        outMsg.Write((byte)_bestLeagueGradeType);
        outMsg.Write((short)_bestLeagueRankNumber);

        _ItemEquipSimpleInfo.Packing(outMsg);

        outMsg.Write((short)_rankNumber);
    }
    #endregion
}

#endregion

#region [����ü] �κ��丮 ����
public class AcNetData_InventoryInfo : AcNetData_base
{
    // ������
    public AcNetData_ItemEquipInfo _itemEquipInfo = new AcNetData_ItemEquipInfo();
    public List<AcNetData_ItemInfo> _itemList = new List<AcNetData_ItemInfo>();

    // ������ ��
    public List<AcNetData_ItemInfo> _itemRemoveList = new List<AcNetData_ItemInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _itemEquipInfo.Parse(inMsg);

        ListParse(inMsg, _itemList);
        ListParse(inMsg, _itemRemoveList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        _itemEquipInfo.Packing(outMsg);

        ListPacking(outMsg, _itemList);
        ListPacking(outMsg, _itemRemoveList);
    }
    #endregion
}

#endregion

#region [����ü] ���� �ɼ� ����

public class AcNetData_UserOptionInfo : AcNetData_base
{
    public byte _os;
    public eLanguageType _languageType;
    public bool _pushReceive;
    public string _pushToeken;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _os = inMsg.ReadByte();
        _languageType = (eLanguageType)inMsg.ReadByte();
        _pushReceive = inMsg.ReadBoolean();
        _pushToeken = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_os);
        outMsg.Write((byte)_languageType);
        outMsg.Write(_pushReceive);
        outMsg.Write(_pushToeken);
    }
    #endregion
}

#endregion

#region [����ü] ���� ����
public class AcNetData_UserConnectInfo : AcNetData_base
{
    public long _userUId;
    public string _userId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _userId = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        outMsg.Write(_userId);
    }
    #endregion
}

#endregion

#region [����ü] �̼� ����

public class AcNetData_MissionInfo : AcNetData_base
{
    public string _uId;
    public int _missionDataId;
    public long _missionCount;
    public bool _missionComplete;
    public bool _endMission;

    // Ŭ���
    public bool _noticePopUp;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadString();
        _missionDataId = inMsg.ReadInt32();
        _missionCount = inMsg.ReadInt64();
        _missionComplete = inMsg.ReadBoolean();
        _endMission = inMsg.ReadBoolean();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);
        outMsg.Write(_missionDataId);
        outMsg.Write(_missionCount);
        outMsg.Write(_missionComplete);
        outMsg.Write(_endMission);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// [����ü] �ݰ� ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region [����ü] Ĩ ����

public class AcNetData_ChipInfo : AcNetData_base
{
    public long _chipBuy;
    public long _chipCoupon;
    public long _chipBot;
    public long _chipFree;
    public long _chipEvent;

    public long _chipDivisionRemain;

    public long AllChip { get { return _chipFree + _chipCoupon + _chipBuy + _chipBot + _chipEvent; } }

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _chipBuy = inMsg.ReadInt64();
        _chipCoupon = inMsg.ReadInt64();
        _chipBot = inMsg.ReadInt64();
        _chipFree = inMsg.ReadInt64();
        _chipEvent = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_chipBuy);
        outMsg.Write(_chipCoupon);
        outMsg.Write(_chipBot);
        outMsg.Write(_chipFree);
        outMsg.Write(_chipEvent);
    }
    #endregion

    #region ���� �Լ�

    public void Reset()
    {
        _chipBuy = 0;
        _chipCoupon = 0;
        _chipBot = 0;
        _chipFree = 0;
        _chipEvent = 0;
        _chipDivisionRemain = 0;
    }

#if !UNITY_EDITOR && !UNITY_ANDROID && !UNITY_IOS && !UNITY_WEBGL

    public eGameResult Change(AcNetData_ChipInfo changeChipInfo, bool use)
    {
        var result = eGameResult.RESULT_OK;

        var value = changeChipInfo.AllChip;
        if (use == true)
        {
            if (AllChip >= value)
            {
                long oldChip = 0;

                // 1. �̺�Ʈ Ĩ
                oldChip = _chipEvent;
                _chipEvent = Math.Max(_chipEvent - value, 0);
                var remainUseChip = value - oldChip;

                // 2. ���� Ĩ
                if (remainUseChip > 0)
                {
                    oldChip = _chipFree;
                    _chipFree = Math.Max(_chipFree - remainUseChip, 0);
                    remainUseChip -= oldChip;
                }

                // 3. �� Ĩ
                if (remainUseChip > 0)
                {
                    oldChip = _chipBot;
                    _chipBot = Math.Max(_chipBot - remainUseChip, 0);
                    remainUseChip -= oldChip;
                }

                // 4. ���� Ĩ
                if (remainUseChip > 0)
                {
                    oldChip = _chipCoupon;
                    _chipCoupon = Math.Max(_chipCoupon - remainUseChip, 0);
                    remainUseChip -= oldChip;
                }

                // 5. ���� Ĩ
                if (remainUseChip > 0)
                {
                    _chipBuy = Math.Max(_chipBuy - remainUseChip, 0);
                }

                result = eGameResult.RESULT_OK;
            }
            else
            {
                result = eGameResult.RESULT_LACKCHIP;
            }
        }
        else
        {
            _chipEvent += changeChipInfo._chipEvent;
            _chipCoupon += changeChipInfo._chipCoupon;
            _chipFree += changeChipInfo._chipFree;
            _chipBot += changeChipInfo._chipBot;
            _chipBuy += changeChipInfo._chipBuy;

            result = eGameResult.RESULT_OK;
        }

        return result;
    }

    // ����� �ʿ� ����
    public eGameResult Change(long value, bool use, eGoodsType goodsType = eGoodsType.TYPE_FREE)
    {
        var result = eGameResult.RESULT_OK;

        if (use == true)
        {
            if (AllChip >= value)
            {
                long oldChip = 0;

                // 1. �̺�Ʈ Ĩ
                oldChip = _chipEvent;
                _chipEvent = Math.Max(_chipEvent - value, 0);
                var remainUseChip = value - oldChip;

                // 2. ���� Ĩ
                if (remainUseChip > 0)
                {
                    oldChip = _chipFree;
                    _chipFree = Math.Max(_chipFree - remainUseChip, 0);
                    remainUseChip -= oldChip;
                }

                // 3. �� Ĩ
                if (remainUseChip > 0)
                {
                    oldChip = _chipBot;
                    _chipBot = Math.Max(_chipBot - remainUseChip, 0);
                    remainUseChip -= oldChip;
                }

                // 4. ���� Ĩ
                if (remainUseChip > 0)
                {
                    oldChip = _chipCoupon;
                    _chipCoupon = Math.Max(_chipCoupon - remainUseChip, 0);
                    remainUseChip -= oldChip;
                }

                // 5. ���� Ĩ
                if (remainUseChip > 0)
                {
                    _chipBuy = Math.Max(_chipBuy - remainUseChip, 0);
                }

                result = eGameResult.RESULT_OK;
            }
            else
            {
                result = eGameResult.RESULT_LACKCHIP;
            }
        }
        else
        {
            if (goodsType == eGoodsType.TYPE_EVENT)
                _chipEvent += value;
            else if (goodsType == eGoodsType.TYPE_FREE)
                _chipFree += value;
            else if (goodsType == eGoodsType.TYPE_BOT)
                _chipBot += value;
            else if (goodsType == eGoodsType.TYPE_COUPON)
                _chipCoupon += value;
            else if (goodsType == eGoodsType.TYPE_BUY)
                _chipBuy += value;

            result = eGameResult.RESULT_OK;
        }

        return result;
    }

    public void Deposit(AcNetData_ChipInfo chipInfo)
    {
        _chipEvent += chipInfo._chipEvent;
        _chipFree += chipInfo._chipFree;
        _chipBot += chipInfo._chipBot;
        _chipBuy += chipInfo._chipBuy;
    }

    public Tuple<eGameResult, AcNetData_ChipInfo> Withdraw(long value)
    {
        var result = eGameResult.RESULT_LACKCHIP;

        if (AllChip < value)
            return Tuple.Create<eGameResult, AcNetData_ChipInfo>(result, null);

        result = eGameResult.RESULT_OK;

        AcNetData_ChipInfo resultInfo = new AcNetData_ChipInfo();

        // 1. �̺�Ʈ Ĩ
        var remainUseChip = value;

        if (_chipEvent >= remainUseChip)
        {
            _chipEvent = _chipEvent - remainUseChip;
            resultInfo._chipEvent = remainUseChip;

            return Tuple.Create(result, resultInfo);
        }
        else
        {
            remainUseChip = remainUseChip - _chipEvent;
            resultInfo._chipEvent = _chipEvent;
            _chipEvent = 0;
        }

        // 2. ���� Ĩ
        if (_chipFree >= remainUseChip)
        {
            _chipFree = _chipFree - remainUseChip;
            resultInfo._chipFree = remainUseChip;

            return Tuple.Create(result, resultInfo);
        }
        else
        {
            remainUseChip = remainUseChip - _chipFree;
            resultInfo._chipFree = _chipFree;
            _chipFree = 0;
        }

        // 3. �� Ĩ
        if (_chipBot > remainUseChip)
        {
            _chipBot = _chipBot - remainUseChip;
            resultInfo._chipBot = remainUseChip;

            return Tuple.Create(result, resultInfo);
        }
        else
        {
            remainUseChip = remainUseChip - _chipBot;
            resultInfo._chipBot = _chipBot;
            _chipBot = 0;
        }

        // 4. ���� Ĩ
        if (_chipCoupon > remainUseChip)
        {
            _chipCoupon = _chipCoupon - remainUseChip;
            resultInfo._chipCoupon = remainUseChip;

            return Tuple.Create(result, resultInfo);
        }
        else
        {
            remainUseChip = remainUseChip - _chipCoupon;
            resultInfo._chipCoupon = _chipCoupon;
            _chipCoupon = 0;
        }

        // 5. ���� Ĩ
        if (_chipBuy > remainUseChip)
        {
            _chipBuy = _chipBuy - remainUseChip;
            resultInfo._chipBuy = remainUseChip;

            return Tuple.Create(result, resultInfo);
        }
        else
        {
            remainUseChip = remainUseChip - _chipBuy;
            resultInfo._chipBuy = _chipBuy;
            _chipBuy = 0;
        }

        return Tuple.Create(result, resultInfo);
    }

    public eGameResult Withdraw(AcNetData_ChipInfo chipInfo)
    {
        var result = eGameResult.RESULT_LACKCHIP;

        if (AllChip < chipInfo.AllChip)
            return result;

        result = eGameResult.RESULT_OK;

        // 1. �̺�Ʈ Ĩ
        _chipEvent = Math.Max(_chipEvent - chipInfo._chipEvent, 0);

        // 2. ���� Ĩ
        _chipFree = Math.Max(_chipFree - chipInfo._chipFree, 0);

        // 3. �� Ĩ
        _chipBot = Math.Max(_chipBot - chipInfo._chipBot, 0);

        // 4. ���� Ĩ
        _chipCoupon = Math.Max(_chipCoupon - chipInfo._chipCoupon, 0);

        // 5. ���� Ĩ
        _chipBuy = Math.Max(_chipBuy - chipInfo._chipBuy, 0);

        return result;
    }

    public AcNetData_ChipInfo WithdrawAll()
    {
        AcNetData_ChipInfo resultInfo = new AcNetData_ChipInfo();

        // 1. �̺�Ʈ Ĩ
        resultInfo._chipEvent = _chipEvent;
        _chipEvent = 0;

        // 2. ���� Ĩ
        resultInfo._chipFree = _chipFree;
        _chipFree = 0;

        // 3. �� Ĩ
        resultInfo._chipBot = _chipBot;
        _chipBot = 0;

        // 4. ���� Ĩ
        resultInfo._chipCoupon = _chipCoupon;
        _chipCoupon = 0;

        // 4. ���� Ĩ
        resultInfo._chipBuy = _chipBuy;
        _chipBuy = 0;

        return resultInfo;
    }

    //
    public AcNetData_ChipInfo Division(int divisionCount)
    {
        AcNetData_ChipInfo resultInfo = new AcNetData_ChipInfo();

        // 1. �̺�Ʈ Ĩ
        resultInfo._chipEvent = JUtil.SafeDevision(_chipEvent, divisionCount);
        resultInfo._chipDivisionRemain = _chipEvent - resultInfo._chipEvent * divisionCount;

        // 2. ���� Ĩ
        resultInfo._chipFree = JUtil.SafeDevision(_chipFree, divisionCount);
        resultInfo._chipDivisionRemain += _chipFree - resultInfo._chipFree * divisionCount;

        // 3. �� Ĩ
        resultInfo._chipBot = JUtil.SafeDevision(_chipBot, divisionCount);
        resultInfo._chipDivisionRemain += _chipBot - resultInfo._chipBot * divisionCount;

        // 4. ���� Ĩ
        resultInfo._chipCoupon = JUtil.SafeDevision(_chipCoupon, divisionCount);
        resultInfo._chipDivisionRemain += _chipCoupon - resultInfo._chipCoupon * divisionCount;

        // 4. ���� Ĩ
        resultInfo._chipBuy = JUtil.SafeDevision(_chipBuy, divisionCount);
        resultInfo._chipDivisionRemain += _chipBuy - resultInfo._chipBuy * divisionCount;

        return resultInfo;
    }
#endif
    #endregion
}

#endregion

#region [����ü] ���̾Ƹ�� ����

public class AcNetData_DiamondInfo : AcNetData_base
{
    public long _diamondBuy;
    public long _diamondCoupon;
    public long _diamondFree;
    public long _diamondEvent;
    public long AllDiamond { get { return _diamondBuy + _diamondCoupon + _diamondFree + _diamondEvent; } }

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _diamondBuy = inMsg.ReadInt64();
        _diamondCoupon = inMsg.ReadInt64();
        _diamondFree = inMsg.ReadInt64();
        _diamondEvent = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_diamondBuy);
        outMsg.Write(_diamondCoupon);
        outMsg.Write(_diamondFree);
        outMsg.Write(_diamondEvent);
    }
    #endregion

    #region ���� �Լ�

    public void Reset()
    {
        _diamondBuy = 0;
        _diamondCoupon = 0;
        _diamondFree = 0;
        _diamondEvent = 0;
    }

#if !UNITY_EDITOR && !UNITY_ANDROID && !UNITY_IOS && !UNITY_WEBGL

    public eGameResult Change(AcNetData_DiamondInfo changeDiamondInfo, bool use)
    {
        var result = eGameResult.RESULT_OK;

        var value = changeDiamondInfo.AllDiamond;
        if (use == true)
        {
            if (AllDiamond >= value)
            {
                long oldDiamond = 0;

                // 1. �̺�Ʈ ���̾�
                oldDiamond = _diamondEvent;
                _diamondEvent = Math.Max(_diamondEvent - value, 0);
                var remainUseDiamond = value - oldDiamond;

                // 2. ���� ���̾�
                if (remainUseDiamond > 0)
                {
                    oldDiamond = _diamondFree;
                    _diamondFree = Math.Max(_diamondFree - remainUseDiamond, 0);
                    remainUseDiamond -= oldDiamond;
                }

                // 3. ���� ���̾�
                if (remainUseDiamond > 0)
                {
                    oldDiamond = _diamondCoupon;
                    _diamondCoupon = Math.Max(_diamondCoupon - remainUseDiamond, 0);
                    remainUseDiamond -= oldDiamond;
                }

                // 4. ���� ���̾�
                if (remainUseDiamond > 0)
                {
                    _diamondBuy = Math.Max(_diamondBuy - remainUseDiamond, 0);
                }

                result = eGameResult.RESULT_OK;
            }
            else
            {
                result = eGameResult.RESULT_LACKDIAMOND;
            }
        }
        else
        {
            _diamondBuy += changeDiamondInfo._diamondBuy;
            _diamondCoupon += changeDiamondInfo._diamondCoupon;
            _diamondFree += changeDiamondInfo._diamondFree;
            _diamondEvent += changeDiamondInfo._diamondEvent;

            result = eGameResult.RESULT_OK;
        }

        return result;
    }

    // ����� �ʿ� ����
    public eGameResult Change(long value, bool use, eGoodsType goodsType = eGoodsType.TYPE_FREE)
    {
        var result = eGameResult.RESULT_OK;

        if (use == true)
        {
            if (AllDiamond >= value)
            {
                long oldDiamond = 0;

                // 1. �̺�Ʈ ���̾Ƹ��
                oldDiamond = _diamondEvent;
                _diamondEvent = Math.Max(_diamondEvent - value, 0);
                var remainUseChip = value - oldDiamond;

                // 2. ���� ���̾Ƹ��
                if (remainUseChip > 0)
                {
                    oldDiamond = _diamondFree;
                    _diamondFree = Math.Max(_diamondFree - remainUseChip, 0);
                    remainUseChip -= oldDiamond;
                }

                // 3. ���� ���̾Ƹ��
                if (remainUseChip > 0)
                {
                    oldDiamond = _diamondCoupon;
                    _diamondCoupon = Math.Max(_diamondCoupon - remainUseChip, 0);
                    remainUseChip -= oldDiamond;
                }

                // 4. ���� ���̾Ƹ��
                if (remainUseChip > 0)
                {
                    _diamondBuy = Math.Max(_diamondBuy - remainUseChip, 0);
                }

                result = eGameResult.RESULT_OK;
            }
            else
            {
                result = eGameResult.RESULT_LACKDIAMOND;
            }
        }
        else
        {
            if (goodsType == eGoodsType.TYPE_EVENT)
                _diamondEvent += value;
            else if (goodsType == eGoodsType.TYPE_FREE)
                _diamondFree += value;
            else if (goodsType == eGoodsType.TYPE_COUPON)
                _diamondCoupon += value;
            else if (goodsType == eGoodsType.TYPE_BUY)
                _diamondBuy += value;

            result = eGameResult.RESULT_OK;
        }

        return result;
    }

#endif
    #endregion
}

#endregion

#region [����ü] ��Ű����Ʈ ����

public class AcNetData_LuckyPointInfo : AcNetData_base
{
    public long _luckyPointReward;
    public long _luckyPointFree;
    public long _luckyPointEvent;
    public long AllLuckyPoint { get { return _luckyPointReward + _luckyPointFree + _luckyPointEvent; } }

    public bool _ticketLuckyPoint;

    public long _luckyPointDivisionRemain;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _luckyPointReward = inMsg.ReadInt64();
        _luckyPointFree = inMsg.ReadInt64();
        _luckyPointEvent = inMsg.ReadInt64();

        _ticketLuckyPoint = inMsg.ReadBoolean();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_luckyPointReward);
        outMsg.Write(_luckyPointFree);
        outMsg.Write(_luckyPointEvent);

        outMsg.Write(_ticketLuckyPoint);
    }
    #endregion

    #region ���� �Լ�

    public void Reset()
    {
        _luckyPointReward = 0;
        _luckyPointFree = 0;
        _luckyPointEvent = 0;
        _ticketLuckyPoint = false;
    }

    public void Deposit(AcNetData_LuckyPointInfo luckyPointInfo)
    {
        _luckyPointReward += luckyPointInfo._luckyPointReward;
        _luckyPointFree += luckyPointInfo._luckyPointFree;
        _luckyPointEvent += luckyPointInfo._luckyPointEvent;
    }

#if !UNITY_EDITOR && !UNITY_ANDROID && !UNITY_IOS && !UNITY_WEBGL

    public eGameResult Change(AcNetData_LuckyPointInfo changeLuckyPointInfo, bool use)
    {
        var result = eGameResult.RESULT_OK;

        var value = changeLuckyPointInfo.AllLuckyPoint;
        if (use == true)
        {
            if (AllLuckyPoint >= value)
            {
                long oldLuckyPoint = 0;

                // 1. �̺�Ʈ ��Ű����Ʈ
                oldLuckyPoint = _luckyPointEvent;
                _luckyPointEvent = Math.Max(_luckyPointEvent - value, 0);
                var remainUseValue = value - oldLuckyPoint;

                // 2. ���� ��Ű����Ʈ
                if (remainUseValue > 0)
                {
                    oldLuckyPoint = _luckyPointFree;
                    _luckyPointFree = Math.Max(_luckyPointFree - remainUseValue, 0);
                    remainUseValue -= oldLuckyPoint;
                }

                // 3. ���� ��Ű����Ʈ
                if (remainUseValue > 0)
                {
                    _luckyPointReward = Math.Max(_luckyPointReward - remainUseValue, 0);
                }

                result = eGameResult.RESULT_OK;
            }
            else
            {
                result = eGameResult.RESULT_LACKLUCKYPOINT;
            }
        }
        else
        {
            _luckyPointReward += changeLuckyPointInfo._luckyPointReward;
            _luckyPointFree += changeLuckyPointInfo._luckyPointFree;
            _luckyPointEvent += changeLuckyPointInfo._luckyPointEvent;

            result = eGameResult.RESULT_OK;
        }

        return result;
    }

    // ����� �ʿ� ����
    public eGameResult Change(long value, bool use, eGoodsType goodsType = eGoodsType.TYPE_EVENT)
    {
        var result = eGameResult.RESULT_OK;

        if (use == true)
        {
            if (AllLuckyPoint >= value)
            {
                long oldLuckyPoint = 0;

                // 1. �̺�Ʈ ��Ű����Ʈ
                oldLuckyPoint = _luckyPointEvent;
                _luckyPointEvent = Math.Max(_luckyPointEvent - value, 0);
                var remainUseValue = value - oldLuckyPoint;

                // 2. ���� ��Ű����Ʈ
                if (remainUseValue > 0)
                {
                    oldLuckyPoint = _luckyPointFree;
                    _luckyPointFree = Math.Max(_luckyPointFree - remainUseValue, 0);
                    remainUseValue -= oldLuckyPoint;
                }

                // 3. ���� ��Ű����Ʈ
                if (remainUseValue > 0)
                {
                    _luckyPointReward = Math.Max(_luckyPointReward - remainUseValue, 0);
                }

                result = eGameResult.RESULT_OK;
            }
            else
            {
                result = eGameResult.RESULT_LACKLUCKYPOINT;
            }
        }
        else
        {
            if (goodsType == eGoodsType.TYPE_EVENT)
                _luckyPointEvent += value;
            else if (goodsType == eGoodsType.TYPE_FREE)
                _luckyPointFree += value;
            else if (goodsType == eGoodsType.TYPE_REWARD)
                _luckyPointReward += value;
            
            result = eGameResult.RESULT_OK;
        }

        return result;
    }

    public Tuple<eGameResult, AcNetData_LuckyPointInfo> Withdraw(long value, bool ignoreLackChip = false)
    {
        var result = eGameResult.RESULT_LACKCHIP;

        if (AllLuckyPoint < value && ignoreLackChip == false)
            return Tuple.Create<eGameResult, AcNetData_LuckyPointInfo>(result, null);

        result = eGameResult.RESULT_OK;

        AcNetData_LuckyPointInfo resultInfo = new AcNetData_LuckyPointInfo();

        // 1. �̺�Ʈ
        var remainUse = value;

        if (_luckyPointEvent >= remainUse)
        {
            _luckyPointEvent = _luckyPointEvent - remainUse;
            resultInfo._luckyPointEvent = remainUse;

            return Tuple.Create(result, resultInfo);
        }
        else
        {
            remainUse = remainUse - _luckyPointEvent;
            resultInfo._luckyPointEvent = _luckyPointEvent;
            _luckyPointEvent = 0;
        }

        // 2. ����
        if (_luckyPointFree >= remainUse)
        {
            _luckyPointFree = _luckyPointFree - remainUse;
            resultInfo._luckyPointFree = remainUse;

            return Tuple.Create(result, resultInfo);
        }
        else
        {
            remainUse = remainUse - _luckyPointFree;
            resultInfo._luckyPointFree = _luckyPointFree;
            _luckyPointFree = 0;
        }

        // 3. ����
        if (_luckyPointReward >= remainUse)
        {
            _luckyPointReward = _luckyPointReward - remainUse;
            resultInfo._luckyPointReward = remainUse;

            return Tuple.Create(result, resultInfo);
        }
        else
        {
            remainUse = remainUse - _luckyPointReward;
            resultInfo._luckyPointReward = _luckyPointReward;
            _luckyPointReward = 0;
        }

        return Tuple.Create(result, resultInfo);
    }

    public eGameResult Withdraw(AcNetData_LuckyPointInfo lpInfo)
    {
        var result = eGameResult.RESULT_LACKLUCKYPOINT;

        if (AllLuckyPoint < lpInfo.AllLuckyPoint)
            return result;

        result = eGameResult.RESULT_OK;

        // 1. �̺�Ʈ
        _luckyPointEvent = Math.Max(_luckyPointEvent - lpInfo._luckyPointEvent, 0);

        // 2. ����
        _luckyPointFree = Math.Max(_luckyPointFree - lpInfo._luckyPointFree, 0);

        // 3. ����
        _luckyPointReward = Math.Max(_luckyPointReward - lpInfo._luckyPointReward, 0);

        return result;
    }

    //
    public AcNetData_LuckyPointInfo Division(int divisionCount)
    {
        AcNetData_LuckyPointInfo resultInfo = new AcNetData_LuckyPointInfo();

        // 1. �̺�Ʈ Ĩ
        resultInfo._luckyPointEvent = JUtil.SafeDevision(_luckyPointEvent, divisionCount);
        resultInfo._luckyPointDivisionRemain = _luckyPointEvent - resultInfo._luckyPointEvent * divisionCount;

        // 2. ���� Ĩ
        resultInfo._luckyPointFree = JUtil.SafeDevision(_luckyPointFree, divisionCount);
        resultInfo._luckyPointDivisionRemain += _luckyPointFree - resultInfo._luckyPointFree * divisionCount;

        // 3. ���� Ĩ
        resultInfo._luckyPointReward = JUtil.SafeDevision(_luckyPointReward, divisionCount);
        resultInfo._luckyPointDivisionRemain += _luckyPointReward - resultInfo._luckyPointReward * divisionCount;

        return resultInfo;
    }

#endif
    #endregion
}

#endregion

#region [����ü] �ݰ� ����

public class AcNetData_SafeInfo : AcNetData_base
{
    public long _uId;
    public int _number;
    //public long _chip;

    //public long _allChip { get { return _chipFree + _chipPurchase + _chipBot + _chipEvent; } }

    //public long _chipFree;
    //public long _chipPurchase;
    //public long _chipBot;
    //public long _chipEvent;

    public AcNetData_ChipInfo _chipInfo = new AcNetData_ChipInfo();

    public eSafeUseType _safeUseType;

    public long Chip { get { return _chipInfo.AllChip; } set { _chipInfo.Reset(); _chipInfo._chipEvent = value; } }

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadInt64();
        _number = inMsg.ReadByte();

        //_chip = inMsg.ReadInt64();

        //_chipFree = inMsg.ReadInt64();
        //_chipPurchase = inMsg.ReadInt64();
        //_chipBot = inMsg.ReadInt64();
        //_chipEvent = inMsg.ReadInt64();
        _chipInfo.Parse(inMsg);

        _safeUseType = (eSafeUseType)inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);
        outMsg.Write((byte)_number);

        //outMsg.Write(_chip);

        //outMsg.Write(_chipFree);
        //outMsg.Write(_chipPurchase);
        //outMsg.Write(_chipBot);
        //outMsg.Write(_chipEvent);
        _chipInfo.Packing(outMsg);

        outMsg.Write((byte)_safeUseType);
    }
    #endregion

}

#endregion

#region [����ü] ��Ƽ ���� ����

public class AcNetData_MultiSlotInfo : AcNetData_base
{
    public long _uId;
    public int _number;
    public DateTime _multiEndDateTime;
    public DateTime _autoEndDateTime;
    public bool _autoUse;
    public int _autoSettingSelectNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadInt64();
        _number = inMsg.ReadByte();
        _multiEndDateTime = DateTime.Parse(inMsg.ReadString());
        _autoEndDateTime = DateTime.Parse(inMsg.ReadString());

        _autoUse = inMsg.ReadBoolean();
        _autoSettingSelectNumber = inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);
        outMsg.Write((byte)_number);
        outMsg.Write(_multiEndDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
        outMsg.Write(_autoEndDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));

        outMsg.Write(_autoUse);
        outMsg.Write((byte)_autoSettingSelectNumber);
    }
    #endregion

}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// [����ü] ���ӷ�
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region [����ü] �� ����

public class AcNetData_RoomSlotInfo : AcNetData_base
{
    public int _number; // ���� ��ȣ
    public eRoomSlotState _state;
    public bool _fold;
    public bool _cardSee;
    public bool _allInAccept;
    public long _totalBettingBalance;
    public AcNetData_UserSimpleInfo _userInfo = new AcNetData_UserSimpleInfo();
    public List<AcNetData_DeckInfo> _deckList = new List<AcNetData_DeckInfo>();
    public List<AcNetData_DeckInfo> _deckList_joker = new List<AcNetData_DeckInfo>();
    public List<int> _emoticonList = new List<int>();
    public ePrevBettingType _prevBettingType;
    public long _prevBettingBalance;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _number = inMsg.ReadByte();
        _state = (eRoomSlotState)inMsg.ReadByte();
        _fold = inMsg.ReadBoolean();
        _cardSee = inMsg.ReadBoolean();
        _allInAccept = inMsg.ReadBoolean();
        

        if (_state != eRoomSlotState.STATE_WAIT && _state != eRoomSlotState.STATE_CLOSE)
        {
            _userInfo.Parse(inMsg);

            if (_state == eRoomSlotState.STATE_GAMEPLAY)
            {
                ListParse<AcNetData_DeckInfo>(inMsg, _deckList);
                ListParse<AcNetData_DeckInfo>(inMsg, _deckList_joker);
                _totalBettingBalance = inMsg.ReadInt64();
            }
        }

        ListParse(inMsg, _emoticonList);

        _prevBettingType = (ePrevBettingType)inMsg.ReadByte();
        _prevBettingBalance = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_number);
        outMsg.Write((byte)_state);
        outMsg.Write(_fold);
        outMsg.Write(_cardSee);
        outMsg.Write(_allInAccept);

        if (_state != eRoomSlotState.STATE_WAIT && _state != eRoomSlotState.STATE_CLOSE)
        {
            _userInfo.Packing(outMsg);

            if (_state == eRoomSlotState.STATE_GAMEPLAY)
            {
                ListPacking(outMsg, _deckList);
                ListPacking(outMsg, _deckList_joker);
                outMsg.Write(_totalBettingBalance);
            }
        }

        ListPacking(outMsg, _emoticonList);

        outMsg.Write((byte)_prevBettingType);
        outMsg.Write(_prevBettingBalance);
    }
    #endregion
}

public class AcNetData_RoomInfo : AcNetData_base
{
    public long _roomIndex;         // �� �ӽ� �������̵�
    public eRoomState _state;
    public int _roomDataId;
    //public long _bootChip;
    //public long _maxBettingChip;
    public int _turnLimitSecond;
    public bool _autoBootChip;
    public ePotLimitOnOffType _potLimitOnOffType;

    public List<AcNetData_RoomSlotInfo> _slotList = new List<AcNetData_RoomSlotInfo>();

    public eGameType _gameType;
    public eRoomOpenType _roomOpenType;
    public eRoundState _roundState;
    public eShowDownType _showDownType;

    public int _dealerSlotNumber;
    public int _currentTurnSlotNumber;
    public long _totalPot;
    public long _stakeChip;
    public int _circleCount;
    public long _prevBettingBalance;

    public int _blindRoundMaxCount;
    public DateTime _turnEndDateTime;               // RoundState�� Ready�϶� ���ӽ��� �ð��뵵�� ��

    public int _sideShowSrcSlotNumber;
    public int _sideShowDstSlotNumber;

    public int _allInActiveSlotNumber;
    public List<long> _allInChipSlotList;

    public long _masterUserUId;
    public ePrivateRoomPlayState _privateRoomPlayState;

    public List<AcNetData_RoomCardHistoryInfo> _cardHistory = new List<AcNetData_RoomCardHistoryInfo>();

    // ������
    public long _maxPot;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _roomIndex = inMsg.ReadInt64();
        _state = (eRoomState)inMsg.ReadByte();
        _roomDataId = inMsg.ReadInt32();
        //_bootChip = inMsg.ReadInt64();
        _turnLimitSecond = inMsg.ReadInt32();
        _autoBootChip = inMsg.ReadBoolean();
        _potLimitOnOffType = (ePotLimitOnOffType)inMsg.ReadByte();

        _blindRoundMaxCount = inMsg.ReadInt16();

        ListParse(inMsg, _slotList);

        _gameType = (eGameType)inMsg.ReadByte();
        _roomOpenType = (eRoomOpenType)inMsg.ReadByte();

        _roundState = (eRoundState)inMsg.ReadByte();

        if (_state == eRoomState.STATE_GAMEPLAY || _state == eRoomState.STATE_COUNTDOWN)
        {
            _turnEndDateTime = DateTime.Parse(inMsg.ReadString());
        }

        if (_state == eRoomState.STATE_GAMEPLAY)
        {
            _showDownType = (eShowDownType)inMsg.ReadByte();

            _dealerSlotNumber = inMsg.ReadInt32();
            _currentTurnSlotNumber = inMsg.ReadInt32();

            _totalPot = inMsg.ReadInt64();
            _stakeChip = inMsg.ReadInt64();

            _circleCount = inMsg.ReadInt16();
            _prevBettingBalance = inMsg.ReadInt64();

            if (_roundState == eRoundState.STATE_SIDESHOW)
            {
                _sideShowSrcSlotNumber = inMsg.ReadByte();
                _sideShowDstSlotNumber = inMsg.ReadByte();
            }

            if (_roundState == eRoundState.STATE_ALLIN)
            {
                _allInActiveSlotNumber = inMsg.ReadByte();
                ListParse(inMsg, _allInChipSlotList);
            }
        }

        if (_roomOpenType == eRoomOpenType.TYPE_PRIVATE)
        {
            _masterUserUId = inMsg.ReadInt64();
            _privateRoomPlayState = (ePrivateRoomPlayState)inMsg.ReadByte();
        }

        ListParse(inMsg, _cardHistory);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_roomIndex);
        outMsg.Write((byte)_state);
        outMsg.Write(_roomDataId);

        //outMsg.Write(_bootChip);
        outMsg.Write(_turnLimitSecond);
        outMsg.Write(_autoBootChip);
        outMsg.Write((byte)_potLimitOnOffType);

        outMsg.Write((short)_blindRoundMaxCount);

        ListPacking(outMsg, _slotList);

        outMsg.Write((byte)_gameType);
        outMsg.Write((byte)_roomOpenType);

        outMsg.Write((byte)_roundState);

        if (_state == eRoomState.STATE_GAMEPLAY || _state == eRoomState.STATE_COUNTDOWN)
        {
            outMsg.Write(_turnEndDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
        }

        if (_state == eRoomState.STATE_GAMEPLAY)
        {
            outMsg.Write((byte)_showDownType);

            outMsg.Write(_dealerSlotNumber);
            outMsg.Write(_currentTurnSlotNumber);

            outMsg.Write(_totalPot);
            outMsg.Write(_stakeChip);

            outMsg.Write((short)_circleCount);
            outMsg.Write(_prevBettingBalance);
            
            if (_roundState == eRoundState.STATE_SIDESHOW)
            {
                outMsg.Write((byte)_sideShowSrcSlotNumber);
                outMsg.Write((byte)_sideShowDstSlotNumber);
            }

            if (_roundState == eRoundState.STATE_ALLIN)
            {
                outMsg.Write((byte)_allInActiveSlotNumber);
                ListPacking(outMsg, _allInChipSlotList);
            }
        }

        if (_roomOpenType == eRoomOpenType.TYPE_PRIVATE)
        {
            outMsg.Write(_masterUserUId);
            outMsg.Write((byte)_privateRoomPlayState);
        }

        ListPacking(outMsg, _cardHistory);
    }
    #endregion
}

#endregion

#region [����ü] �� ���� ����

public class AcNetData_RoomSimpleInfo : AcNetData_base
{
    public long _roomIndex;
    public eRoomOpenType _roomOpenType;

    public eGameType _gameType;

    public long _bootBalance;
    public long _maxBettingChip;
    public long _maxPot;
    public byte _maxUserCount;
    public byte _curUserCount;
    public byte _turnLimitSecond;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        _roomIndex = inMsg.ReadInt64();
        _roomOpenType = (eRoomOpenType)inMsg.ReadByte();
        _gameType = (eGameType)inMsg.ReadByte();
        _bootBalance = inMsg.ReadInt64();
        _maxBettingChip = inMsg.ReadInt64();
        _maxPot = inMsg.ReadInt64();
        _maxUserCount = inMsg.ReadByte();
        _curUserCount = inMsg.ReadByte();
        _turnLimitSecond = inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        outMsg.Write(_roomIndex);
        outMsg.Write((byte)_roomOpenType);
        outMsg.Write((byte)_gameType);
        outMsg.Write(_bootBalance);
        outMsg.Write(_maxBettingChip);
        outMsg.Write(_maxPot);
        outMsg.Write(_maxUserCount);
        outMsg.Write(_curUserCount);
        outMsg.Write(_turnLimitSecond);
    }
    #endregion
}

#endregion

#region [����ü] �� ���� ���� ����

public class AcNetData_RoomSlotStateInfo : AcNetData_base
{
    public int _number; // ���� ��ȣ
    public eRoomSlotState _state;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _number = inMsg.ReadByte();
        _state = (eRoomSlotState)inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_number);
        outMsg.Write((byte)_state);
    }
    #endregion
}

#endregion

#region [����ü] �� ���� ���� Ĩ ����

public class AcNetData_RoomSlotUserBalanceInfo : AcNetData_base
{
    public int _number; // ���� ��ȣ
    public long _userUId;
    public long _balance;
    public long _balanceReservation;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _number = inMsg.ReadByte();
        _userUId = inMsg.ReadInt64();
        _balance = inMsg.ReadInt64();
        _balanceReservation = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_number);
        outMsg.Write(_userUId);
        outMsg.Write(_balance);
        outMsg.Write(_balanceReservation);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// [����ü] ������
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region [����ü] ���� ������ ���� ����

public class AcNetData_ItemEquipInfo : AcNetData_base
{
    public long _uId = -1;
    public long _userUId;

    public Dictionary<eItemEquipType, List<string>> _itemEquipDic = new Dictionary<eItemEquipType, List<string>>();

    public Dictionary<eItemEquipType, List<int>> _itemEquipSimpleDic = new Dictionary<eItemEquipType, List<int>>(); // ����

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        var isReadUId = inMsg.ReadBoolean();
        if (isReadUId == true)
        {
            _uId = inMsg.ReadInt64();
            _userUId = inMsg.ReadInt64();
        }

        var dicCount = inMsg.ReadUInt16();
        for (int i = 0; i < dicCount; i++)
        {
            var itemEquipType = (eItemEquipType)inMsg.ReadByte();
            var strList = new List<string>();
            ListParse(inMsg, strList);

            _itemEquipDic.Add(itemEquipType, strList);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        if (_uId == -1)
        {
            outMsg.Write(false);
        }
        else
        {
            outMsg.Write(true);
            outMsg.Write(_uId);
            outMsg.Write(_userUId);
        }

        outMsg.Write((ushort)_itemEquipDic.Count);
        foreach (var itemEquipId in _itemEquipDic)
        {
            outMsg.Write((byte)itemEquipId.Key);
            ListPacking(outMsg, itemEquipId.Value);
        }
    }
    #endregion
}

#endregion

#region [����ü] ���� ���� ������ ���� ����(������, ��������)

public class AcNetData_ItemEquipSimpleInfo : AcNetData_base
{
    public Dictionary<eItemEquipType, List<int>> _itemEquipDic = new Dictionary<eItemEquipType, List<int>>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        var dicCount = inMsg.ReadUInt16();
        for (int i = 0; i < dicCount; i++)
        {
            var itemEquipType = (eItemEquipType)inMsg.ReadByte();
            var intList = new List<int>();
            ListParse(inMsg, intList);

            _itemEquipDic.Add(itemEquipType, intList);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((ushort)_itemEquipDic.Count);
        foreach (var itemEquipId in _itemEquipDic)
        {
            outMsg.Write((byte)itemEquipId.Key);
            ListPacking(outMsg, itemEquipId.Value);
        }
    }
    #endregion
}

#endregion

#region [����ü] ������ ����

public class AcNetData_ItemInfo : AcNetData_base
{
    public string _uId;
    public int _itemDataId;
    public long _count;

    public bool _timeLimitOn;
    public DateTime _timeLimitEndDate;

    public DateTime _regDate;

    public bool _newItem;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadString();
        _itemDataId = inMsg.ReadInt32();
        _count = inMsg.ReadInt64();

        _timeLimitOn = inMsg.ReadBoolean();
        if(_timeLimitOn == true)
        {
            _timeLimitEndDate = DateTime.Parse(inMsg.ReadString());
        }

        _newItem = inMsg.ReadBoolean();

        _regDate = DateTime.Parse(inMsg.ReadString());
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);
        outMsg.Write(_itemDataId);
        outMsg.Write(_count);

        outMsg.Write(_timeLimitOn);
        if (_timeLimitOn == true)
        {
            outMsg.Write(_timeLimitEndDate.ToString("yyyy-MM-dd HH:mm:ss.fff"));
        }

        outMsg.Write(_newItem);

        outMsg.Write(_regDate.ToString("yyyy-MM-dd HH:mm:ss.fff"));
    }
    #endregion
}

#endregion

#region [����ü] ������ ���� ����(�κ��丮)

public class AcNetData_ItemChangeInfo : AcNetData_base
{
    public string _itemUId;
    public int _itemDataId;
    public long _count;     // AfterCount

    public bool _timeLimitOn;
    public DateTime _timeLimitEndDate;

    // �α׿�
    public long _beforeCount;
    public long _acquireCount;
    public eItemType _itemType;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _itemUId = inMsg.ReadString();
        _itemDataId = inMsg.ReadInt32();
        _count = inMsg.ReadInt64();

        _timeLimitOn = inMsg.ReadBoolean();
        if (_timeLimitOn == true)
        {
            _timeLimitEndDate = DateTime.Parse(inMsg.ReadString());
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_itemUId);
        outMsg.Write(_itemDataId);
        outMsg.Write(_count);

        outMsg.Write(_timeLimitOn);
        if (_timeLimitOn == true)
        {
            outMsg.Write(_timeLimitEndDate.ToString("yyyy-MM-dd HH:mm:ss.fff"));
        }
    }
    #endregion
}

#endregion

#region [����ü] ������ ȹ�� ����

public class AcNetData_ItemAcquireInfo : AcNetData_base
{
    public int _itemDataId;
    public long _count;

    // ������
    public List<AcNetData_ItemChangeInfo> _changeItemInfoList;
    public eItemType _itemType;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _itemDataId = inMsg.ReadInt32();
        _count = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_itemDataId);
        outMsg.Write(_count);
    }
    #endregion
}

#endregion

#region [����ü] ���� ������ ���� ��û ����

public class AcNetData_ItemEquipRequestInfo : AcNetData_base
{
    public string _itemUId;
    public int _slotNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _itemUId = inMsg.ReadString();
        _slotNumber = inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_itemUId);
        outMsg.Write((byte)_slotNumber);
    }
    #endregion
}

#endregion

#region [����ü] ���� ������ ���� ��û ���� ����

public class AcNetData_ItemEquipResponseInfo : AcNetData_base
{
    public string _itemUId;
    public int _slotNumber;
    public eItemEquipType _itemEquipType;

    public bool _timeLimitOn;
    public DateTime _timeLimitEndDate;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _itemUId = inMsg.ReadString();
            _slotNumber = inMsg.ReadByte();
            _itemEquipType = (eItemEquipType)inMsg.ReadByte();

            _timeLimitOn = inMsg.ReadBoolean();
            if (_timeLimitOn == true)
            {
                _timeLimitEndDate = DateTime.Parse(inMsg.ReadString());
            }
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write(_itemUId);
            outMsg.Write((byte)_slotNumber);
            outMsg.Write((byte)_itemEquipType);

            outMsg.Write(_timeLimitOn);
            if (_timeLimitOn == true)
            {
                outMsg.Write(_timeLimitEndDate.ToString("yyyy-MM-dd HH:mm:ss.fff"));
            }

        }
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// [����ü] ä��
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ä�� ����

public class AcNetData_TalkInfo : AcNetData_base
{
    public long _userUId;
    public string _talkStr;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _talkStr = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        outMsg.Write(_talkStr);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// [����ü] ���� ���� ��� ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region [����ü] ���� ���� ��� ����

public class AcNetData_UserGameResultInfo : AcNetData_base
{
    public int _slotNumber; // ���� ��ȣ
    public eGenealogyType _genealogyType;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _slotNumber = inMsg.ReadByte();
        _genealogyType = (eGenealogyType)inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_slotNumber);
        outMsg.Write((byte)_genealogyType);
    }
    #endregion
}


#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// [����ü] ��ũ ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region [����ü] ��ũ ����

public class AcNetData_RankUserInfo : AcNetData_base
{
    public long _userUId;
    public int _rankNumber;
    public long _point;
    public eLeagueGradeType _leagueGradeType;
    public int _prevRankNumber;

    public string _userId;
    public string _nickName;
    public int _pictureDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        
        _rankNumber = inMsg.ReadInt16();
        _point = inMsg.ReadInt64();
        _leagueGradeType = (eLeagueGradeType)inMsg.ReadByte();
        _prevRankNumber = inMsg.ReadInt16();

        _userId = inMsg.ReadString();
        _nickName = inMsg.ReadString();
        _pictureDataId = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        outMsg.Write((short)_rankNumber);
        outMsg.Write(_point);
        outMsg.Write((byte)_leagueGradeType);
        outMsg.Write((short)_prevRankNumber);

        outMsg.Write(_userId);
        outMsg.Write(_nickName);
        outMsg.Write(_pictureDataId);
    }
    #endregion
}

#endregion

#region [����ü] ��ũ ���� ����

public class AcNetData_SimpleRankUserInfo : AcNetData_base
{
    public int _rankNumber;
    public long _point;
    public int _prevRankNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _rankNumber = inMsg.ReadInt16();
        _point = inMsg.ReadInt64();
        _prevRankNumber = inMsg.ReadInt16();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((short)_rankNumber);
        outMsg.Write(_point);
        outMsg.Write((short)_prevRankNumber);
    }
    #endregion
}

#endregion

#region [����ü] ���� TOT ��ũ ���� ����

public class AcNetData_TOTRankRewardInfo : AcNetData_base
{
    public long _uId;               // ���� ���� �������̵� �ִ°������� UserUId�� DB�߰� �Ҷ������� ����

    public int _rankNumber;

    public int _rewardItemDataId;
    public long _rewardItemCount;

    public bool _receive = true;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadInt64();

        _rankNumber = inMsg.ReadInt32();

        _rewardItemDataId = inMsg.ReadInt32();
        _rewardItemCount = inMsg.ReadInt64();

        _receive = inMsg.ReadBoolean();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);

        outMsg.Write(_rankNumber);

        outMsg.Write(_rewardItemDataId);
        outMsg.Write(_rewardItemCount);

        outMsg.Write(_receive);
    }
    #endregion
}

#endregion

#region [����ü] Ĩ ��ũ ����

public class AcNetData_ChipRankUserInfo : AcNetData_base
{
    public long _userUId;
    public int _rankNumber;
    public long _totalChip;
    public eLeagueGradeType _leagueGradeType;
    public int _prevRankNumber;

    public string _userId;
    public string _nickName;
    public int _pictureDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();

        _rankNumber = inMsg.ReadInt32();
        _totalChip = inMsg.ReadInt64();
        _leagueGradeType = (eLeagueGradeType)inMsg.ReadByte();
        _prevRankNumber = inMsg.ReadInt32();

        _userId = inMsg.ReadString();
        _nickName = inMsg.ReadString();
        _pictureDataId = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        outMsg.Write(_rankNumber);
        outMsg.Write(_totalChip);
        outMsg.Write((byte)_leagueGradeType);
        outMsg.Write(_prevRankNumber);

        outMsg.Write(_userId);
        outMsg.Write(_nickName);
        outMsg.Write(_pictureDataId);
    }
    #endregion
}

public class AcNetDataServer_ChipRankUserInfo : AcNetData_base
{
    public long _userUId;
    public string _userId;
    public string _nickName;
    public int _pictureDataId;
    public long _totalChip;
    public eLeagueGradeType _leagueGradeType;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _totalChip = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        outMsg.Write(_totalChip);
    }
    #endregion
}

#endregion

#region [����ü] ��ũ ���� ����

public class AcNetData_SimpleChipRankUserInfo : AcNetData_base
{
    public int _rankNumber;
    public long _totalChip;
    public int _prevRankNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _rankNumber = inMsg.ReadInt32();
        _totalChip = inMsg.ReadInt64();
        _prevRankNumber = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_rankNumber);
        outMsg.Write(_totalChip);
        outMsg.Write(_prevRankNumber);
    }
    #endregion
}

#endregion

#region [����ü] ���� �׷�

public class AcNetData_LeagueGroupInfo : AcNetData_base
{
    public string _uId; 
    public eLeagueGradeType _leagueGradeType;
    public long _prizePoint;
    //public bool _newLeagueGroup;

    public List<AcNetData_LeagueUserInfo> _leagueUserList = new List<AcNetData_LeagueUserInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadString();
        _leagueGradeType = (eLeagueGradeType)inMsg.ReadByte();
        _prizePoint = inMsg.ReadInt64();

        ListParse(inMsg, _leagueUserList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);
        outMsg.Write((byte)_leagueGradeType);
        outMsg.Write(_prizePoint);

        ListPacking(outMsg, _leagueUserList);
    }
    #endregion
}

public class AcNetData_SimpleLeagueGroupInfo : AcNetData_base
{
    public eLeagueGradeType _leagueGradeType;
    public long _prizePoint;

    public List<AcNetData_SimpleUserLeagueInfo> _leagueUserList = new List<AcNetData_SimpleUserLeagueInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _leagueGradeType = (eLeagueGradeType)inMsg.ReadByte();
        _prizePoint = inMsg.ReadInt64();

        ListParse(inMsg, _leagueUserList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_leagueGradeType);
        outMsg.Write(_prizePoint);

        ListPacking(outMsg, _leagueUserList);
    }
    #endregion
}

#endregion

#region [����ü] ���� ����

public class AcNetData_LeagueUserInfo : AcNetData_base
{
    public string _uId;
    public long _userUId;
    public string _userId;
    public string _userNickName;
    public int _userPictureDataId;
    public string _leagueGroupUId;
    public int _rankNumber;
    public long _point;
    public long _weekPoint;
    public long _savePrizePoint;
    public long _luckyPoint;
    public DateTime _lastAcquirePointDate;

    public eLeagueGradeType _bestLeagueGradeType;
    public int _bestLeagueRankNumber;

    //public bool _newLeagueUser;
    

    // ������
    public AcNetData_LeagueGroupInfo _leagueGroup;
    public bool _pushReceive;
    public string _pushToken;
    public eLanguageType _languageType;
    public bool _pushGradeDownSend;
    public bool _pushTOTRankGradeDownSend;
    public bool _disableAddLeagueGradeUp;   // ���� ��� ������ ���� ����(��Ű -> �ǹ�)
    public DateTime _lastLoginDateTime = DateTime.Now;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadString();
        _userUId = inMsg.ReadInt64();
        _userId = inMsg.ReadString();
        _userNickName = inMsg.ReadString();
        _userPictureDataId = inMsg.ReadInt32();
        _leagueGroupUId = inMsg.ReadString();
        _rankNumber = inMsg.ReadInt16();
        _point = inMsg.ReadInt64();
        _weekPoint = inMsg.ReadInt64();
        _luckyPoint = inMsg.ReadInt64();
        _savePrizePoint = inMsg.ReadInt64();
        _lastAcquirePointDate = DateTime.Parse(inMsg.ReadString());

        _bestLeagueGradeType = (eLeagueGradeType)inMsg.ReadByte();
        _bestLeagueRankNumber = inMsg.ReadInt16();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);
        outMsg.Write(_userUId);
        outMsg.Write(_userId);
        outMsg.Write(_userNickName);
        outMsg.Write(_userPictureDataId);
        outMsg.Write(_leagueGroupUId);
        outMsg.Write((short)_rankNumber);
        outMsg.Write(_point);
        outMsg.Write(_weekPoint);
        outMsg.Write(_luckyPoint);
        outMsg.Write(_savePrizePoint);
        outMsg.Write(_lastAcquirePointDate.ToString("yyyy-MM-dd HH:mm:ss.fff"));

        outMsg.Write((byte)_bestLeagueGradeType);
        outMsg.Write((short)_bestLeagueRankNumber);
    }
    #endregion
}

#endregion

#region [����ü] ���� ����Ʈ ����

public class AcNetData_LeaguePointInfo : AcNetData_base
{
    public long _userUId;
    public long _leaguePoint;
    public long _leaguePrizePoint;
    public long _luckyPoint;
    public long _buffLuckyPoint;

    public long _totalBettingChip;

    public int _multiSlotNumber;

#if !UNITY_EDITOR && !UNITY_ANDROID && !UNITY_IOS && !UNITY_WEBGL
    public eUserType _userType; // ������
#endif

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _leaguePoint = inMsg.ReadInt64();
        _leaguePrizePoint = inMsg.ReadInt64();
        _luckyPoint = inMsg.ReadInt64();
        _buffLuckyPoint = inMsg.ReadInt64();

        _totalBettingChip = inMsg.ReadInt64();
        _multiSlotNumber = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        outMsg.Write(_leaguePoint);
        outMsg.Write(_leaguePrizePoint);
        outMsg.Write(_luckyPoint);
        outMsg.Write(_buffLuckyPoint);

        outMsg.Write(_totalBettingChip);
        outMsg.Write(_multiSlotNumber);
    }
    #endregion
}

#endregion

#region [����ü] TOT è�Ǿ� ����Ʈ ����

public class AcNetData_TOTChampionShipPointInfo : AcNetData_base
{
    public long _userUId;
    public long _point;

#if !UNITY_EDITOR && !UNITY_ANDROID && !UNITY_IOS && !UNITY_WEBGL
    public eUserType _userType; // ������
#endif

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _point = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        outMsg.Write(_point);
    }
    #endregion
}

#endregion

#region [����ü] ���� ���� ����

public class AcNetData_UserLeagueInfo : AcNetData_base
{
    public long _userUId;
    public eLeagueGradeType _gradeType;
    public int _rankNumber;

    public eLeagueGradeType _bestLeagueGradeType;
    public int _bestLeagueRankNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();

        _gradeType = (eLeagueGradeType)inMsg.ReadByte();
        _rankNumber = inMsg.ReadInt16();

        _bestLeagueGradeType = (eLeagueGradeType)inMsg.ReadByte();
        _bestLeagueRankNumber = inMsg.ReadInt16();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        outMsg.Write((byte)_gradeType);
        outMsg.Write((short)_rankNumber);

        outMsg.Write((byte)_bestLeagueGradeType);
        outMsg.Write((short)_bestLeagueRankNumber);
    }
    #endregion
}

public class AcNetData_SimpleUserLeagueInfo : AcNetData_base
{
    public long _userUId;
    public int _rankNumber;
    public string _nickName;
    public long _point;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _rankNumber = inMsg.ReadInt16();
        _nickName = inMsg.ReadString();
        _point = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        outMsg.Write((short)_rankNumber);
        outMsg.Write(_nickName);
        outMsg.Write(_point);
    }
    #endregion
}

#endregion

#region [����ü] ���� ���� ���� ����

public class AcNetData_LeagueRewardInfo : AcNetData_base
{
    public bool _isleagueReward;
    public long _uId;               // ���� ���� �������̵� �ִ°������� UserUId�� DB�߰�&������� �Ҷ������� ����

    public eLeagueGradeType _leagueGradeTypeBefore;
    public eLeagueGradeType _leagueGradeTypeAfter;
    public int _leagueRankNumberBefore;

    public long _prizeChip;
    public long _luckyPoint;
    public int _rewardItemDataId;
    public long _rewardItemCount;
    public bool _receive = true;

    public DateTime _enableReceiveDateTime;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _isleagueReward = inMsg.ReadBoolean();

        if(_isleagueReward == true)
        {
            _uId = inMsg.ReadInt64();

            _leagueGradeTypeBefore = (eLeagueGradeType)inMsg.ReadByte();
            _leagueGradeTypeAfter = (eLeagueGradeType)inMsg.ReadByte();
            _leagueRankNumberBefore = inMsg.ReadInt16();

            _prizeChip = inMsg.ReadInt64();
            _luckyPoint = inMsg.ReadInt64();
            _rewardItemDataId = inMsg.ReadInt32();
            _rewardItemCount = inMsg.ReadInt64();
            _receive = inMsg.ReadBoolean();
            _enableReceiveDateTime = DateTime.Parse(inMsg.ReadString());
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_isleagueReward);

        if(_isleagueReward == true)
        {
            outMsg.Write(_uId);

            outMsg.Write((byte)_leagueGradeTypeBefore);
            outMsg.Write((byte)_leagueGradeTypeAfter);
            outMsg.Write((short)_leagueRankNumberBefore);

            outMsg.Write(_prizeChip);
            outMsg.Write(_luckyPoint);
            outMsg.Write(_rewardItemDataId);
            outMsg.Write(_rewardItemCount);
            outMsg.Write(_receive);
            outMsg.Write(_enableReceiveDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
        }
    }
    #endregion
}

#endregion

#region [����ü] è�Ǿ� ���� ����

public class AcNetData_TOTChampionShipUserInfo : AcNetData_base
{
    public string _uId;
    public long _userUId;
    public int _rankNumber;
    public long _point;
    public eTOTChampionShipGradeType _tOTChampionShipGradeType;
    public int _prevRankNumber;
    public DateTime _lastAcquirePointDate;

    public eLeagueGradeType _leagueGradeType;
    public string _userId;
    public string _nickName;
    public int _pictureDataId;

    // ������
    public bool _pushReceive;
    public string _pushToken;
    public eLanguageType _languageType;
    public bool _pushTOTChampionShipRankDownSend;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadString();
        _userUId = inMsg.ReadInt64();

        _rankNumber = inMsg.ReadInt32();
        _point = inMsg.ReadInt64();
        _tOTChampionShipGradeType = (eTOTChampionShipGradeType)inMsg.ReadByte();

        _lastAcquirePointDate = DateTime.Parse(inMsg.ReadString());

        _prevRankNumber = inMsg.ReadInt32();

        _leagueGradeType = (eLeagueGradeType)inMsg.ReadByte();
        _userId = inMsg.ReadString();
        _nickName = inMsg.ReadString();
        _pictureDataId = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);

        outMsg.Write(_userUId);
        outMsg.Write(_rankNumber);
        outMsg.Write(_point);
        outMsg.Write((byte)_tOTChampionShipGradeType);

        outMsg.Write(_lastAcquirePointDate.ToString("yyyy-MM-dd HH:mm:ss.fff"));

        outMsg.Write(_prevRankNumber);

        outMsg.Write((byte)_leagueGradeType);
        outMsg.Write(_userId);
        outMsg.Write(_nickName);
        outMsg.Write(_pictureDataId);
    }
    #endregion
}

public class AcNetData_SimpleTOTChampionShipUserInfo : AcNetData_base
{
    public long _userUId;
    public int _rankNumber;
    public long _point;
    public eTOTChampionShipGradeType _tOTChampionShipGradeType;
    public int _prevRankNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _rankNumber = inMsg.ReadInt32();
        _point = inMsg.ReadInt64();
        _tOTChampionShipGradeType = (eTOTChampionShipGradeType)inMsg.ReadByte();
        _prevRankNumber = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        outMsg.Write(_rankNumber);
        outMsg.Write(_point);
        outMsg.Write((byte)_tOTChampionShipGradeType);
        outMsg.Write(_prevRankNumber);
    }
    #endregion
}

#endregion

#region [����ü] ���� TOT è�Ǿ� ���� ����

public class AcNetData_TOTChampionShipRewardInfo : AcNetData_base
{
    public long _uId;               // ���� ���� �������̵� �ִ°������� UserUId�� DB�߰� �Ҷ������� ����

    public eTOTChampionShipGradeType _tOTChampionShipGradeType;
    public int _rankNumber;

    public int _rewardItemDataId;
    public long _rewardItemCount;

    public bool _receive = true;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadInt64();

        _tOTChampionShipGradeType = (eTOTChampionShipGradeType)inMsg.ReadByte();
        _rankNumber = inMsg.ReadInt32();

        _rewardItemDataId = inMsg.ReadInt32();
        _rewardItemCount = inMsg.ReadInt64();

        _receive = inMsg.ReadBoolean();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
{
        outMsg.Write(_uId);

        outMsg.Write((byte)_tOTChampionShipGradeType);
        outMsg.Write(_rankNumber);

        outMsg.Write(_rewardItemDataId);
        outMsg.Write(_rewardItemCount);

        outMsg.Write(_receive);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// [����ü] SetAuto
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region [����ü] SetAuto ����

public class AcNetData_SetAutoInfo : AcNetData_base
{
    public long _uId;
    public int _number;
    public eSetAutoSettingType _settingType;

    public Dictionary<eSetAutoType, AcNetData_SetAutoValueInfo> _setAutoValueInfoDic = new Dictionary<eSetAutoType, AcNetData_SetAutoValueInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadInt64();
        _number = inMsg.ReadByte();
        _settingType = (eSetAutoSettingType)inMsg.ReadByte();

        var dicCount = inMsg.ReadUInt16();
        for (int i = 0; i < dicCount; i++)
        {
            var setAutoType = (eSetAutoType)inMsg.ReadByte();
            var autoValueInfo = new AcNetData_SetAutoValueInfo();
            autoValueInfo.Parse(inMsg);

            _setAutoValueInfoDic.Add(setAutoType, autoValueInfo);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);
        outMsg.Write((byte)_number);
        outMsg.Write((byte)_settingType);

        outMsg.Write((ushort)_setAutoValueInfoDic.Count);
        foreach (var setAutoValueInfo in _setAutoValueInfoDic)
        {
            outMsg.Write((byte)setAutoValueInfo.Key);
            setAutoValueInfo.Value.Packing(outMsg);
        }
    }
    #endregion

#if !UNITY_EDITOR && !UNITY_ANDROID && !UNITY_IOS && !UNITY_WEBGL
    public string GetAutoJsonSerialize()
    {
        var tempAutoDic = new Dictionary<byte, AcNetData_SetAutoValueInfo>();
        foreach (var autoPair in _setAutoValueInfoDic)
        {
            tempAutoDic.Add((byte)autoPair.Key, autoPair.Value);
        }

        return Newtonsoft.Json.JsonConvert.SerializeObject(tempAutoDic);
    }
#endif
}

public class AcNetData_SetAutoValueInfo : AcNetData_base
{

#if !UNITY_EDITOR && !UNITY_ANDROID && !UNITY_IOS && !UNITY_WEBGL
    [Newtonsoft.Json.JsonProperty(PropertyName = "o")]  // Json �Ҷ��� DB�� ��Ʈ������ �����Ŷ� ���� �����ϰ�
#endif
    public eOverBelowType _overBelowType;

#if !UNITY_EDITOR && !UNITY_ANDROID && !UNITY_IOS && !UNITY_WEBGL
    [Newtonsoft.Json.JsonProperty(PropertyName = "a")]
#endif
    public int _autoValue;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _overBelowType = (eOverBelowType)inMsg.ReadByte();
        _autoValue = inMsg.ReadInt16();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_overBelowType);
        outMsg.Write((short)_autoValue);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// [����ü] ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region [����ü] ���� �ڽ� ����

public class AcNetData_PostBoxInfo : AcNetData_base
{
    public List<AcNetData_PostInfo> _postList = new List<AcNetData_PostInfo>();

    // ������ ��
    public List<AcNetData_PostInfo> _postRemoveList = new List<AcNetData_PostInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        ListParse(inMsg, _postList);
        ListParse(inMsg, _postRemoveList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        ListPacking(outMsg, _postList);
        ListPacking(outMsg, _postRemoveList);
    }
    #endregion
}

#endregion

#region [����ü] ���� ����

public class AcNetData_PostInfo : AcNetData_base
{
    public string _uId;
    public ePostSendType _sendType;
    public string _senderName;          // SendType�� 99.�ý���, 6.�̺�Ʈ �϶� ������� �̸�
    public int _itemDataId;
    public long _itemCount;
    public string _description;         // SendType�� 99.�ý���, 6.�̺�Ʈ �϶��� ���� ����
    public string _descValueList;       // SendType�� 99.�ý���, 6.�̺�Ʈ �ƴҶ� ���̺��� DescId�� string format�� ����(��ǥ�� �Ľ�)
    public DateTime _regDate;
    public ePostPeriodType _periodType;
    public DateTime _endDate;
    public bool _postRead;

    public bool _newPost;

    // ������
    public long _userUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadString();
        _sendType = (ePostSendType)inMsg.ReadByte();
        _senderName = inMsg.ReadString();
        _itemDataId = inMsg.ReadInt32();
        _itemCount = inMsg.ReadInt64();
        _description = inMsg.ReadString();
        _descValueList = inMsg.ReadString();
        _regDate = DateTime.Parse(inMsg.ReadString());
        _periodType = (ePostPeriodType)inMsg.ReadByte();

        if (_periodType == ePostPeriodType.TYPE_LIMITED)
        {
            _endDate = DateTime.Parse(inMsg.ReadString());
        }

        _postRead = inMsg.ReadBoolean();

        _newPost = inMsg.ReadBoolean();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);
        outMsg.Write((byte)_sendType);
        outMsg.Write(_senderName);
        outMsg.Write(_itemDataId);
        outMsg.Write(_itemCount);
        outMsg.Write(_description);
        outMsg.Write(_descValueList);
        outMsg.Write(_regDate.ToString("yyyy-MM-dd HH:mm:ss.fff"));
        outMsg.Write((byte)_periodType);

        if (_periodType == ePostPeriodType.TYPE_LIMITED)
        {
            outMsg.Write(_endDate.ToString("yyyy-MM-dd HH:mm:ss.fff"));
        }

        outMsg.Write(_postRead);
        outMsg.Write(_newPost);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// [����ü] �翬��
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region [����ü] �翬�� ����

public class AcNetData_ReconnectionInfo : AcNetData_base
{
    public long _mainRoomIndex;
    public List<int> _roomInfoNumberList = new List<int>();
    public List<AcNetData_RoomInfo> _roomInfoList = new List<AcNetData_RoomInfo>();
    

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _mainRoomIndex = inMsg.ReadInt64();
        ListParse(inMsg, _roomInfoNumberList);
        ListParse(inMsg, _roomInfoList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_mainRoomIndex);
        ListPacking(outMsg, _roomInfoNumberList);
        ListPacking(outMsg, _roomInfoList);     
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// [����ü] ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region [����ü] ���� ����

public class AcNetData_ResearchInfo : AcNetData_base
{
    public eResearchType _researchType;
    public DateTime _researchDate;
    public List<int> _researchDataIdList = new List<int>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _researchType = (eResearchType)inMsg.ReadByte();
        _researchDate = DateTime.Parse(inMsg.ReadString());

        ListParse(inMsg, _researchDataIdList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_researchType);
        outMsg.Write(_researchDate.ToString("yyyy-MM-dd HH:mm:ss.fff"));

        ListPacking(outMsg, _researchDataIdList);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// BBS
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region [����ü] ���� ����

public class AcNetData_BBSNoticeInfo : AcNetData_base
{
    public long _uId;
    public int _noticeOrder;
    public bool _isImage;
    public string _noticeStr;
    public DateTime _startDateTime;
    public DateTime _endDateTime;
    public int _delayMinute;
    public eNoticeType _noticeType;

    // ������
    public DateTime _nextSendDate;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadInt64();
        _noticeOrder = inMsg.ReadInt32();
        _isImage = inMsg.ReadBoolean();
        _noticeStr = inMsg.ReadString();
        _startDateTime = DateTime.Parse(inMsg.ReadString());
        _endDateTime = DateTime.Parse(inMsg.ReadString());
        _delayMinute = inMsg.ReadInt32();
        _noticeType = (eNoticeType)inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);
        outMsg.Write(_noticeOrder);
        outMsg.Write(_isImage);
        outMsg.Write(_noticeStr);
        outMsg.Write(_startDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
        outMsg.Write(_endDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
        outMsg.Write(_delayMinute);
        outMsg.Write((byte)_noticeType);
    }
    #endregion
}

#endregion

#region [����ü] ���� ���� ����

public class AcNetData_BBSNoticeSimpleInfo : AcNetData_base
{
    public long _uId;
    public string _noticeStr;

    // ������
    public DateTime _startDateTime;
    public DateTime _endDateTime;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadInt64();
        _noticeStr = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);
        outMsg.Write(_noticeStr);
    }
    #endregion
}

#endregion

#region [����ü] ��� ����

public class AcNetData_BBSBannerInfo : AcNetData_base
{
    public long _uId;
    public bool _isImage;
    public string _noticeStr;
    public DateTime _startDateTime;
    public DateTime _endDateTime;
    public eBannerType _bannerType;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadInt64();
        _isImage = inMsg.ReadBoolean();
        _noticeStr = inMsg.ReadString();
        _startDateTime = DateTime.Parse(inMsg.ReadString());
        _endDateTime = DateTime.Parse(inMsg.ReadString());
        _bannerType = (eBannerType)inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);
        outMsg.Write(_isImage);
        outMsg.Write(_noticeStr);
        outMsg.Write(_startDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
        outMsg.Write(_endDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
        outMsg.Write((byte)_bannerType);
    }
    #endregion
}

#endregion

#region [����ü] ��� ���� ����

public class AcNetData_BBSBannerSimpleInfo : AcNetData_base
{
    public long _uId;
    public eBannerType _bannerType;
    public string _noticeStr;

    // ������
    public DateTime _startDateTime;
    public DateTime _endDateTime;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadInt64();
        _bannerType = (eBannerType)inMsg.ReadByte();
        _noticeStr = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);
        outMsg.Write((byte)_bannerType);
        outMsg.Write(_noticeStr);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region [����ü] ���� ����

public class AcNetData_PaymentInfo : AcNetData_base
{
    public string _uId;
    public long _userUId;
    public ePaymentType _paymentType;
    public DateTime _requestDateTime;
    public int _productId;
    public int _shopDataId;
    public string _orderId; 
    public bool _verify;
    public DateTime _recevieDateTime;
    public bool _recevie;
    public bool _cancel;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadString();
        _userUId = inMsg.ReadInt64();
        _paymentType = (ePaymentType)inMsg.ReadByte();
        _requestDateTime = DateTime.Parse(inMsg.ReadString());
        _productId = inMsg.ReadInt32();
        _shopDataId = inMsg.ReadInt32();
        _orderId = inMsg.ReadString();
        _verify = inMsg.ReadBoolean();
        _recevieDateTime = DateTime.Parse(inMsg.ReadString());
        _recevie = inMsg.ReadBoolean();
        _cancel = inMsg.ReadBoolean();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);
        outMsg.Write(_userUId);
        outMsg.Write((byte)_paymentType);
        outMsg.Write(_requestDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
        outMsg.Write(_productId);
        outMsg.Write(_shopDataId);
        outMsg.Write(_orderId);
        outMsg.Write(_verify);
        outMsg.Write(_recevieDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
        outMsg.Write(_recevie);
        outMsg.Write(_cancel);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// ���� ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region [����ü] ���� ���� ����

public class AcNetData_PostManagementInfo : AcNetData_base
{
    public long _uId;
    public ePostSendTargetType _sendTargetType;
    public string _senderName;
    public string _description;
    public DateTime _sendDateTime;
    public bool _immediate;
    public ePostSendState _sendState;
    public int _itemDataId;
    public long _itemCount;
    public bool _cancel;
    public string _receiveUserUIdList;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadInt64();
        _sendTargetType = (ePostSendTargetType)inMsg.ReadByte();
        _senderName = inMsg.ReadString();
        _description = inMsg.ReadString();
        _sendDateTime = DateTime.Parse(inMsg.ReadString());
        _immediate = inMsg.ReadBoolean();
        _sendState = (ePostSendState)inMsg.ReadByte();
        _itemDataId = inMsg.ReadInt32();
        _itemCount = inMsg.ReadInt64();
        _cancel = inMsg.ReadBoolean();
        _receiveUserUIdList = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);
        outMsg.Write((byte)_sendTargetType);
        outMsg.Write(_senderName);
        outMsg.Write(_description);
        outMsg.Write(_sendDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
        outMsg.Write(_immediate);
        outMsg.Write((byte)_sendState);
        outMsg.Write(_itemDataId);
        outMsg.Write(_itemCount);
        outMsg.Write(_cancel);
        outMsg.Write(_receiveUserUIdList);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// [����ü] ģ��
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region [����ü] ģ�� ����

public class AcNetData_FriendInfo : AcNetData_base
{
    public long _uId;
    public long _friendUserUId;
    public string _friendUserId;
    public string _friendNickName;
    public int _friendPictureDataId;

    public eFriendType _friendType;
    public DateTime _sendGiftDateTime;

    public long _totalChip;
    public eLeagueGradeType _leagueGradeType;
    public long _leaguePoint;

    public eUserState _userState;

    // ������
    public bool _updateInfo;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadInt64();

        _friendUserUId = inMsg.ReadInt64();
        _friendUserId = inMsg.ReadString();
        _friendNickName = inMsg.ReadString();
        _friendPictureDataId = inMsg.ReadInt32();

        _friendType = (eFriendType)inMsg.ReadByte();
        _sendGiftDateTime = DateTime.Parse(inMsg.ReadString());

        _totalChip = inMsg.ReadInt64();
        _leagueGradeType = (eLeagueGradeType)inMsg.ReadByte();
        _leaguePoint = inMsg.ReadInt64();

        _userState = (eUserState)inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);

        outMsg.Write(_friendUserUId);
        outMsg.Write(_friendUserId);
        outMsg.Write(_friendNickName);
        outMsg.Write(_friendPictureDataId);

        outMsg.Write((byte)_friendType);
        outMsg.Write(_sendGiftDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));

        outMsg.Write(_totalChip);
        outMsg.Write((byte)_leagueGradeType);
        outMsg.Write(_leaguePoint);

        outMsg.Write((byte)_userState);
    }
    #endregion
}

#endregion

#region [����ü] ģ�� ��û ����

public class AcNetData_FriendRequestInfo : AcNetData_base
{
    public long _uId;
    public long _requestUserUId;
    public string _requestUserUserId;
    public string _requestUserNickName;
    public int _requestUserPictureDataId;
    public DateTime _requestLimitDateTime;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadInt64();

        _requestUserUId = inMsg.ReadInt64();
        _requestUserUserId = inMsg.ReadString();
        _requestUserNickName = inMsg.ReadString();
        _requestUserPictureDataId = inMsg.ReadInt32();

        _requestLimitDateTime = DateTime.Parse(inMsg.ReadString());
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);

        outMsg.Write(_requestUserUId);
        outMsg.Write(_requestUserUserId);
        outMsg.Write(_requestUserNickName);
        outMsg.Write(_requestUserPictureDataId);

        outMsg.Write(_requestLimitDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
    }
    #endregion
}

#endregion

#region [����ü] ģ�� ���� ����

public class AcNetData_FriendUserStateInfo : AcNetData_base
{
    public long _friendUId;
    public eUserState _userState;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _friendUId = inMsg.ReadInt64();
        _userState = (eUserState)inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_friendUId);
        outMsg.Write((byte)_userState);
    }
    #endregion
}

#endregion

#region [����ü] ģ�� ����

public class AcNetData_FriendSendGiftResultInfo : AcNetData_base
{
    public long _friendUId;
    public long _friendUserUId;
    public DateTime _sendGiftDateTime;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);
        _friendUId = inMsg.ReadInt64();
        _friendUserUId = inMsg.ReadInt64();
        _sendGiftDateTime = DateTime.Parse(inMsg.ReadString());
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);
        outMsg.Write(_friendUId);
        outMsg.Write(_friendUserUId);
        outMsg.Write(_sendGiftDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
    }
    #endregion
}

#endregion

#region [����ü] ������ ģ�� �ʴ뿡 ���� ����

public class AcNetData_UserFriendInviteInfo : AcNetData_base
{
    public int _inviteTotalCount;
    public List<int> _inviteRewardAcquireDataIdList = new List<int>();
    public string _inviteCode;
    public string _registerInviteCode;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _inviteTotalCount = inMsg.ReadInt32();
        ListParse(inMsg, _inviteRewardAcquireDataIdList);
        _inviteCode = inMsg.ReadString();
        _registerInviteCode = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_inviteTotalCount);
        ListPacking(outMsg, _inviteRewardAcquireDataIdList);
        outMsg.Write(_inviteCode);
        outMsg.Write(_registerInviteCode);
    }
    #endregion
}

public class AcNetData_FriendInviteInfo : AcNetData_base
{
    public long _uId;
    public string _InviteUserId;
    public DateTime _inviteDateTime;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadInt64();
        _InviteUserId = inMsg.ReadString();
        _inviteDateTime = DateTime.Parse(inMsg.ReadString());
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);
        outMsg.Write(_InviteUserId);
        outMsg.Write(_inviteDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// [����ü] Ʃ�丮��
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region [����ü] Ʃ�丮�� ���̽� ����

public class AcNetData_TutorialBaseInfo : AcNetData_base
{
    public string _uId;
    public int _tutorialBaseDataId;
    public long _tutorialCount;
    public bool _tutorialComplete;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadString();

        _tutorialBaseDataId = inMsg.ReadInt32();
        _tutorialCount = inMsg.ReadInt64();
        _tutorialComplete = inMsg.ReadBoolean();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);

        outMsg.Write(_tutorialBaseDataId);
        outMsg.Write(_tutorialCount);
        outMsg.Write(_tutorialComplete);
    }
    #endregion
}

#endregion

#region [����ü] Ʃ�丮�� ���׻� ����

public class AcNetData_TutorialGaneshaInfo : AcNetData_base
{
    public string _uId;
    public int _tutorialGaneshaDataId;
    public long _tutorialCount;
    public bool _tutorialComplete;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadString();

        _tutorialGaneshaDataId = inMsg.ReadInt32();
        _tutorialCount = inMsg.ReadInt64();
        _tutorialComplete = inMsg.ReadBoolean();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);

        outMsg.Write(_tutorialGaneshaDataId);
        outMsg.Write(_tutorialCount);
        outMsg.Write(_tutorialComplete);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// [����ü] TOT è�Ǿ�
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region [����ü] TOT è�Ǿ� �����췯 ����

public class AcNetData_TOTChampionShipSchedulerInfo : AcNetData_base
{
    public long _uId;

    public DateTime _startDateTime;
    public DateTime _endDateTime;

    public int _gameModeDataId;
    public bool _repeat;
    public int _repeatIntervalDay;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadInt64();

        _startDateTime = DateTime.Parse(inMsg.ReadString());
        _endDateTime = DateTime.Parse(inMsg.ReadString());

        _gameModeDataId = inMsg.ReadInt32();
        _repeat = inMsg.ReadBoolean();
        _repeatIntervalDay = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);

        outMsg.Write(_startDateTime.ToString("yyyy-MM-dd HH:mm:ss"));
        outMsg.Write(_endDateTime.ToString("yyyy-MM-dd HH:mm:ss"));

        outMsg.Write(_gameModeDataId);
        outMsg.Write(_repeat);
        outMsg.Write(_repeatIntervalDay);
    }
    #endregion
}

#endregion

#region [����ü] TOT è�Ǿ� �����췯 ����

public class AcNetData_TOTChampionShipProgressInfo : AcNetData_base
{
    public string _uId;

    public DateTime _startDateTime;
    public DateTime _endDateTime;

    public long _tOTChampionShipId;
    public int _gameModeDataId;

    public bool _finishSuccess;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadString();

        _startDateTime = DateTime.Parse(inMsg.ReadString());
        _endDateTime = DateTime.Parse(inMsg.ReadString());

        _tOTChampionShipId = inMsg.ReadInt64();
        _gameModeDataId = inMsg.ReadInt32();

        _finishSuccess = inMsg.ReadBoolean();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);

        outMsg.Write(_startDateTime.ToString("yyyy-MM-dd HH:mm:ss"));
        outMsg.Write(_endDateTime.ToString("yyyy-MM-dd HH:mm:ss"));

        outMsg.Write(_tOTChampionShipId);
        outMsg.Write(_gameModeDataId);

        outMsg.Write(_finishSuccess);
    }
    #endregion
}

#endregion

#region [����ü] ���� ���� ����

public class AcNetData_LeagueProgressInfo : AcNetData_base
{
    public string _uId;

    public eLeagueProgressType _progressType;
    public eLeagueProgressState _progressState;

    public DateTime _startDateTime;
    public DateTime _endDateTime;
    public long _progressId;

    public eLeagueProgressFinishState _finishState;

    public int _valueNumber;

    public DateTime _registerDateTime;

    // ������
    public bool _taskOn; // Task ���� ������ ���̻� ȣ�� �ȵǵ��� �ϴ� �뵵

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadString();

        _progressType = (eLeagueProgressType)inMsg.ReadInt32();
        _progressState = (eLeagueProgressState)inMsg.ReadInt32();

        _startDateTime = DateTime.Parse(inMsg.ReadString());
        _endDateTime = DateTime.Parse(inMsg.ReadString());
        _progressId = inMsg.ReadInt64();

        _finishState = (eLeagueProgressFinishState)inMsg.ReadInt32();

        _valueNumber = inMsg.ReadInt32();

        _registerDateTime = DateTime.Parse(inMsg.ReadString());
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);

        outMsg.Write((byte)_progressType);
        outMsg.Write((byte)_progressState);

        outMsg.Write(_startDateTime.ToString("yyyy-MM-dd HH:mm:ss"));
        outMsg.Write(_endDateTime.ToString("yyyy-MM-dd HH:mm:ss"));
        outMsg.Write(_progressId);

        outMsg.Write((byte)_finishState);

        outMsg.Write(_valueNumber);

        outMsg.Write(_registerDateTime.ToString("yyyy-MM-dd HH:mm:ss"));
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// [����ü] ä�� ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region [����ü] ä�� ���� ���

public class AcNetData_ChannelGameModeInfo : AcNetData_base
{
    public long _uId;
    public int _gameModeDataId;

    public Dictionary<int, AcNetData_ChannelGameRoomInfo> _channelGameRoomInfoDic = new Dictionary<int, AcNetData_ChannelGameRoomInfo>();

    // ������
    public bool _needManagementData;
    public bool _autoChannelLockMode;
    public int _autoChannelLockCount;
    public int _autoChannelUnlockCount;
    public int _channelRecommandUserCount;

    // ���ӷ� MinMax �˻���
    public List<AcNetData_ChannelGameRoomInfo> _channelGameRoomInfoList = new List<AcNetData_ChannelGameRoomInfo>();
    public List<AcNetData_ChannelGameRoomInfo> _channelGameRoomInfoList_IncludeLock = new List<AcNetData_ChannelGameRoomInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        //_uId = inMsg.ReadInt64();

        _gameModeDataId = inMsg.ReadInt32();

        _needManagementData = inMsg.ReadBoolean();
        if (_needManagementData == true)
        {
            _autoChannelLockMode = inMsg.ReadBoolean();
            _channelRecommandUserCount = inMsg.ReadInt32();
        }

        var dicCount = inMsg.ReadUInt16();
        for (int i = 0; i < dicCount; i++)
        {
            var gameRoomDataId = inMsg.ReadInt32();
            var channelGameRoomInfo = new AcNetData_ChannelGameRoomInfo();
            channelGameRoomInfo.Parse(inMsg);
            _channelGameRoomInfoDic.Add(gameRoomDataId, channelGameRoomInfo);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        //outMsg.Write(_uId);

        outMsg.Write(_gameModeDataId);

        outMsg.Write(_needManagementData);
        if (_needManagementData == true)
        {
            outMsg.Write(_autoChannelLockMode);
            outMsg.Write(_channelRecommandUserCount);
        }

        outMsg.Write((ushort)_channelGameRoomInfoDic.Count);
        foreach (var KeyValuePair in _channelGameRoomInfoDic)
        {
            outMsg.Write(KeyValuePair.Key);
            KeyValuePair.Value.Packing(outMsg);
        }
    }
    #endregion
}

#endregion

#region [����ü] ä�� ���� ��

public class AcNetData_ChannelGameRoomInfo : AcNetData_base
{
    public long _uId;

    public int _gameModeDataId;
    public int _gameRoomDataId;
    public int _roomCount;
    public int _roomUserCount;
    public int _botCount;
    public int _enablePlayUserCount;

    // ������
    public bool _needManagementData;
    public long _minChipLimit;
    public bool _botEnable;
    public bool _channelLock;
    public bool _autoChannelLock;
    public bool _autoChannelLockEnable;
    public bool _autoChannelBotLock;

    // ���� ä�ζ� ����
    public long _maxChipLimit;
    public long _maxChipLimit_IncludeLock;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        //_uId = inMsg.ReadInt64();

        _gameModeDataId = inMsg.ReadInt32();
        _gameRoomDataId = inMsg.ReadInt32();
        _roomCount = inMsg.ReadInt32();
        _roomUserCount = inMsg.ReadInt32();
        _botCount = inMsg.ReadInt32();
        _enablePlayUserCount = inMsg.ReadInt32();

        _needManagementData = inMsg.ReadBoolean();
        if (_needManagementData == true)
        {
            _minChipLimit = inMsg.ReadInt64();
            _botEnable = inMsg.ReadBoolean();
            _channelLock = inMsg.ReadBoolean();
            _autoChannelLock = inMsg.ReadBoolean();
            _autoChannelLockEnable = inMsg.ReadBoolean();
            _autoChannelBotLock = inMsg.ReadBoolean();
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        //outMsg.Write(_uId);

        outMsg.Write(_gameModeDataId);
        outMsg.Write(_gameRoomDataId);
        outMsg.Write(_roomCount);
        outMsg.Write(_roomUserCount);
        outMsg.Write(_botCount);
        outMsg.Write(_enablePlayUserCount);

        outMsg.Write(_needManagementData);
        if (_needManagementData == true)
        {
            outMsg.Write(_minChipLimit);
            outMsg.Write(_botEnable);
            outMsg.Write(_channelLock);
            outMsg.Write(_autoChannelLock);
            outMsg.Write(_autoChannelLockEnable);
            outMsg.Write(_autoChannelBotLock);
        }
    }
    #endregion
}

#endregion

#region [����ü] ���� �� ä�� ����

public class AcNetData_EnableEnterChannelInfo : AcNetData_base
{
    public int _gameDataId;
    public int _roomUserCount;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _gameDataId = inMsg.ReadInt32();
        _roomUserCount = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_gameDataId);
        outMsg.Write(_roomUserCount);
    }
    #endregion
}

#endregion

#region [����ü] ���� ���� ���� �� ä�� ����

public class AcNetData_EnableEnterHighGradeChannelInfo : AcNetData_base
{
    public int _gameDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _gameDataId = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_gameDataId);
    }
    #endregion
}

#endregion

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// [����ü] ������ ���
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region [����ü] ������ ���� ��� ����

public class AcNetData_ContentMainLockInfo : AcNetData_base
{
    public eContentMainLockType _contentMainLockType;
    public bool _contentLock;
    public Dictionary<int, AcNetData_ContentSubLockInfo> _contentSubLockInfoDic = new Dictionary<int, AcNetData_ContentSubLockInfo>(); // DataId

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _contentMainLockType = (eContentMainLockType)inMsg.ReadByte();
        _contentLock = inMsg.ReadBoolean();

        var dicCount = inMsg.ReadUInt16();
        for (int i = 0; i < dicCount; i++)
        {
            var dataId = inMsg.ReadInt32();
            var dataInfo = new AcNetData_ContentSubLockInfo();
            dataInfo.Parse(inMsg);
            _contentSubLockInfoDic.Add(dataId, dataInfo);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_contentMainLockType);
        outMsg.Write(_contentLock);

        outMsg.Write((ushort)_contentSubLockInfoDic.Count);
        foreach (var KeyValuePair in _contentSubLockInfoDic)
        {
            outMsg.Write(KeyValuePair.Key);
            KeyValuePair.Value.Packing(outMsg);
        }
    }
    #endregion
}

#endregion

#region [����ü] ������ ���� ��� ����

public class AcNetData_ContentSubLockInfo : AcNetData_base
{
    public eContentMainLockType _contentMainLockType;
    public int _dataId;
    public bool _contentLock;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _contentMainLockType = (eContentMainLockType)inMsg.ReadByte();
        _dataId = inMsg.ReadInt32();
        _contentLock = inMsg.ReadBoolean();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_contentMainLockType);
        outMsg.Write(_dataId);
        outMsg.Write(_contentLock);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// [����ü] PayTM 
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region [����ü] PayTM ����

public class AcNetData_PayTMInfo : AcNetData_base
{
    public long _uId;
    public string _password;
    public string _mailAddress;
    public string _phoneNumber;
    public int _lastUseRewardDataId;
    public bool _useAgreement;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadInt64();
        _password = inMsg.ReadString();
        _mailAddress = inMsg.ReadString();
        _phoneNumber = inMsg.ReadString();
        _lastUseRewardDataId = inMsg.ReadInt32();
        _useAgreement = inMsg.ReadBoolean();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);
        outMsg.Write(_password);
        outMsg.Write(_mailAddress);
        outMsg.Write(_phoneNumber);
        outMsg.Write(_lastUseRewardDataId);
        outMsg.Write(_useAgreement);
    }
    #endregion
}

#endregion

#region [����ü] PayTM ��ȯ ����

public class AcNetData_PayTMExchangeInfo : AcNetData_base
{
    public string _uId;
    public DateTime _requestDateTime;
    public string _payTMPhoneNumber;
    public ePayTMExchangeType _payTMExchangeType;
    public int _dataId;
    public long _itemCount;
    public ePayTMExchangeResultType _payTMExchangeResultType;
    public long _exchangeINR;
    public long _exchangeLP;
    public string _statusCode;
    public string _statusMessage;
    public bool _complete;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadString();
        _requestDateTime = DateTime.Parse(inMsg.ReadString());
        _payTMPhoneNumber = inMsg.ReadString();
        _payTMExchangeType = (ePayTMExchangeType)inMsg.ReadByte();
        _dataId = inMsg.ReadInt32();
        _itemCount = inMsg.ReadInt64();
        _payTMExchangeResultType = (ePayTMExchangeResultType)inMsg.ReadByte();
        _exchangeINR = inMsg.ReadInt64();
        _exchangeLP = inMsg.ReadInt64();
        _statusCode = inMsg.ReadString();
        _statusMessage = inMsg.ReadString();
        _complete = inMsg.ReadBoolean();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);
        outMsg.Write(_requestDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
        outMsg.Write(_payTMPhoneNumber);
        outMsg.Write((byte)_payTMExchangeType);
        outMsg.Write(_dataId);
        outMsg.Write(_itemCount);
        outMsg.Write((byte)_payTMExchangeResultType);
        outMsg.Write(_exchangeINR);
        outMsg.Write(_exchangeLP);
        outMsg.Write(_statusCode);
        outMsg.Write(_statusMessage);
        outMsg.Write(_complete);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// [����ü] �̺�Ʈ 
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region [����ü] �̺�Ʈ ����

public class AcNetData_EventInfo : AcNetData_base
{
    public long _uId;
    public eEventType _eventType;
    public eEventState _eventState;
    public DateTime _startDateTime;
    public DateTime _endDateTime;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadInt64();
        _eventType = (eEventType)inMsg.ReadByte();
        _eventState = (eEventState)inMsg.ReadByte();

        _startDateTime = DateTime.Parse(inMsg.ReadString());
        _endDateTime = DateTime.Parse(inMsg.ReadString());
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);

        outMsg.Write((byte)_eventType);
        outMsg.Write((byte)_eventState);

        outMsg.Write(_startDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
        outMsg.Write(_endDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
    }
    #endregion
}

#endregion

#region [����ü] ���� �̺�Ʈ ����

public class AcNetData_ShareRewardInfo : AcNetData_base
{
    public long _uId;
    public List<int> _receiveRewardDataIdList = new List<int>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadInt64();
        ListParse(inMsg, _receiveRewardDataIdList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);
        ListPacking(outMsg, _receiveRewardDataIdList);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// [����ü] Event 
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region [����ü] Event ����

public class AcNetData_UserEventInfo : AcNetData_base
{
    public long _uId;
    public eEventType _eventType;
    public long _eventCount;
    public bool _rewardReceive;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadInt64();
        _eventType = (eEventType)inMsg.ReadByte();
        _eventCount = inMsg.ReadInt64();
        _rewardReceive = inMsg.ReadBoolean();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);
        outMsg.Write((byte)_eventType);
        outMsg.Write(_eventCount);
        outMsg.Write(_rewardReceive);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// [����ü] ���� LP ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region [����ü] ���� ��� �г�Ƽ ����

public class AcNetData_GameResultPenaltyInfo : AcNetData_base
{
    public int _number; // ���� ��ȣ
    public long _penaltyBalance;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _number = inMsg.ReadByte();
        _penaltyBalance = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_number);
        outMsg.Write(_penaltyBalance);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// [����ü] ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region [����ü] ���� ����

public class AcNetData_BuffInfo : AcNetData_base
{
    public long _uId;
    public int _buffDataId;
    public DateTime _registerDateTime;
    public DateTime _startDateTime;
    public DateTime _endDateTime;

    public long _buffPriceValue;   // ���� ����ġ üũ(�� ���� ����)

#if UNITY_EDITOR || UNITY_ANDROID || UNITY_IOS || UNITY_WEBGL
#else
    // ������
    public AcDataInfo_BuffBase _buffBaseDataInfo;
#endif

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _uId = inMsg.ReadInt64();
        _buffDataId = inMsg.ReadInt32();

        _registerDateTime = DateTime.Parse(inMsg.ReadString());
        _startDateTime = DateTime.Parse(inMsg.ReadString());
        _endDateTime = DateTime.Parse(inMsg.ReadString());

        _buffPriceValue = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_uId);
        outMsg.Write(_buffDataId);

        outMsg.Write(_registerDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
        outMsg.Write(_startDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
        outMsg.Write(_endDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));

        outMsg.Write(_buffPriceValue);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// [����ü] ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region [����ü] ���� ���� ��ǰ ����

public class AcNetData_UserLimitProductInfo : AcNetData_base
{
    public int _shopDataId;
    public int _count;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _shopDataId = inMsg.ReadInt32();
        _count = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    // �޽��� ��ŷ
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_shopDataId);
        outMsg.Write(_count);
    }
    #endregion
}

#endregion