using System.Collections.Generic;
using System;
using Lidgren.Network;


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region gamer ���� ����

public class AcNetDataCS_reqResfreshGamerInfo : AcNetData_base
{
    //public int _guid;
    public AcNetData_UserInfo _userInfo;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        //_guid = inMsg.ReadInt32();
        _userInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        //outMsg.Write(_guid);
        _userInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region �������� ���� ��û

public class AcNetDataSS_reqSaveUserInfo : AcNetData_base
{
    public AcNetData_UserInfo _userInfo = new AcNetData_UserInfo();
    public AcNetData_InventoryInfo _inventoryInfo = new AcNetData_InventoryInfo();
    public AcNetData_PostBoxInfo _postBoxInfo = new AcNetData_PostBoxInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userInfo.Parse(inMsg);
        _inventoryInfo.Parse(inMsg);
        _postBoxInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        _userInfo.Packing(outMsg);
        _inventoryInfo.Packing(outMsg);
        _postBoxInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region �������� �ݰ� Ĩ ���� ���� ��û

public class AcNetDataSS_reqSaveUserSafeChipInfo : AcNetData_base
{
    public long _safeUId;
    //public long _safeChip;
    public AcNetData_ChipInfo _safeChipInfo = new AcNetData_ChipInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _safeUId = inMsg.ReadInt64();
        //_safeChip = inMsg.ReadInt64();
        _safeChipInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_safeUId);
        //outMsg.Write(_safeChip);
        _safeChipInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region �������� ���̾Ƹ�� ���� ���� ��û

public class AcNetDataSS_reqSaveUserDiamondInfo : AcNetData_base
{
    public long _userUId;
    //public long _diamond;
    public AcNetData_DiamondInfo _diamondInfo = new AcNetData_DiamondInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        //_diamond = inMsg.ReadInt64();

        _diamondInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        //outMsg.Write(_diamond);
        _diamondInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region �������� ��Ű����Ʈ ���� ���� ��û

public class AcNetDataSS_reqSaveUserLuckyPointInfo : AcNetData_base
{
    public long _userUId;
    public AcNetData_LuckyPointInfo _luckyPointInfo = new AcNetData_LuckyPointInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _luckyPointInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        _luckyPointInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region ���� �κ��丮 ���� ���� ��û

public class AcNetDataSS_reqSaveUserInventoryInfo : AcNetData_base
{
    public long _userUId;
    public AcNetData_InventoryInfo _inventoryInfo = new AcNetData_InventoryInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _inventoryInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        _inventoryInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region ���� ������ ���� ���� ��û

public class AcNetDataSS_reqSaveUserPostBoxInfo : AcNetData_base
{
    public long _userUId;
    public AcNetData_PostBoxInfo _postBoxInfo = new AcNetData_PostBoxInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _postBoxInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        _postBoxInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region ���� ������ ���� ���� ��û

public class AcNetDataSS_reqSaveUserPostRead : AcNetData_base
{
    public long _userUId;
    public string _postUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _postUId = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        outMsg.Write(_postUId);
    }
    #endregion
}

#endregion

#region ���� ����ġ ���� ���� ��û

public class AcNetDataSS_reqSaveUserResearchInfo : AcNetData_base
{
    public long _userUId;
    public AcNetData_ResearchInfo _researchInfo = new AcNetData_ResearchInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _researchInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        _researchInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region ���� TOT ��ũ ���� ���� ���� ��û

public class AcNetDataSS_reqSaveUserTOTRankRewardAcquire : AcNetData_base
{
    public long _userUId;
    public long _rewardUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _rewardUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        outMsg.Write(_rewardUId);
    }
    #endregion
}

#endregion

#region ���� TOT è�Ǿ� ���� ���� ���� ��û

public class AcNetDataSS_reqSaveUserTOTChampionShipRewardAcquire : AcNetData_base
{
    public long _userUId;
    public long _rewardUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _rewardUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        outMsg.Write(_rewardUId);
    }
    #endregion
}

#endregion

#region ���� �Ϸ� ���� ���� ���� ��û

public class AcNetDataSS_reqSaveUserDailyRewardInfo : AcNetData_base
{
    public long _userUId;
    public DateTime _receiveRewardDate;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _receiveRewardDate = DateTime.Parse(inMsg.ReadString());
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        outMsg.Write(_receiveRewardDate.ToString("yyyy-MM-dd HH:mm:ss.fff"));
    }
    #endregion
}

#endregion

#region ���� Ʃ�丮�� ���� ���� ���� ��û

public class AcNetDataSS_reqSaveUserTutorialRewardReceive : AcNetData_base
{
    public long _userUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
    }
    #endregion
}

#endregion

#region ���� �⼮ ���� ���� ��û

public class AcNetDataSS_reqSaveUserAttendanceInfo : AcNetData_base
{
    public long _userUId;
    public DateTime _lastAttendanceDate;
    public int _attendanceSlotMachineEnableCount;
    public int _attendanceAccumulateCount;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();

        _lastAttendanceDate = DateTime.Parse(inMsg.ReadString());
        _attendanceSlotMachineEnableCount = inMsg.ReadInt32();
        _attendanceAccumulateCount = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);

        outMsg.Write(_lastAttendanceDate.ToString("yyyy-MM-dd HH:mm:ss.fff"));
        outMsg.Write(_attendanceSlotMachineEnableCount);
        outMsg.Write(_attendanceAccumulateCount);
    }
    #endregion
}

#endregion

#region ���� �귿 ���� ���� ��û

public class AcNetDataSS_reqSaveUserRouletteInfo : AcNetData_base
{
    public long _userUId;
    public int _rouletteFeverCount;
    public int _rouletteFreeCount;
    public DateTime _rouletteFreeUpdateDateTime;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();

        _rouletteFeverCount = inMsg.ReadInt32();
        _rouletteFreeCount = inMsg.ReadInt32();
        _rouletteFreeUpdateDateTime = DateTime.Parse(inMsg.ReadString());
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        
        outMsg.Write(_rouletteFeverCount);
        outMsg.Write(_rouletteFreeCount);
        outMsg.Write(_rouletteFreeUpdateDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
    }
    #endregion
}

#endregion

#region ���� VIP ���� ���� ��û

public class AcNetDataSS_reqSaveUserVIPInfo : AcNetData_base
{
    public long _userUId;
    public int _VIPDataId;
    public DateTime _VIPEndDateTime;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();

        _VIPDataId = inMsg.ReadInt32();
        _VIPEndDateTime = DateTime.Parse(inMsg.ReadString());
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);

        outMsg.Write(_VIPDataId);
        outMsg.Write(_VIPEndDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
    }
    #endregion
}

#endregion

#region ���� ��Ƽ ���� ���� ��û

public class AcNetDataSS_reqSaveUserMultiSlotInfo : AcNetData_base
{
    public AcNetData_MultiSlotInfo _multiSlotInfo = new AcNetData_MultiSlotInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _multiSlotInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        _multiSlotInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region �������� ���׻� �ָӴ� ���� ���� ��û

public class AcNetDataSS_reqSaveUserGaneshaPocketInfo : AcNetData_base
{
    public long _userUId;
    public long _ganeshaPocketChip;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _ganeshaPocketChip = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        outMsg.Write(_ganeshaPocketChip);
    }
    #endregion
}

#endregion

#region ���� ����(���̽��� ���)

public class AcNetDataCS_reqAccountLink : AcNetData_base
{
    public long _userUId;
    public string _userId;
    public string _linkUserId;
    public string _nickName;
    public eAccountLinkType _accountLinkType;
    public string _deviceCode;
    public string _macAddress;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        _userUId = inMsg.ReadInt64();
        _userId = inMsg.ReadString();
        _linkUserId = inMsg.ReadString();
        _nickName = inMsg.ReadString();
        _accountLinkType = (eAccountLinkType)inMsg.ReadByte();
        _deviceCode = inMsg.ReadString();
        _macAddress = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        outMsg.Write(_userUId);
        outMsg.Write(_userId);
        outMsg.Write(_linkUserId);
        outMsg.Write(_nickName);
        outMsg.Write((byte)_accountLinkType);
        outMsg.Write(_deviceCode);
        outMsg.Write(_macAddress);
    }
    #endregion
}

public class AcNetDataSS_resAccountLink : AcNetData_base
{
    public string _linkUserId;
    public string _nickName;
    public eAccountLinkType _accountLinkType;
    public string _deviceCode;
    public string _macAddress;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        _linkUserId = inMsg.ReadString();
        _nickName = inMsg.ReadString();
        _accountLinkType = (eAccountLinkType)inMsg.ReadByte();
        _deviceCode = inMsg.ReadString();
        _macAddress = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        outMsg.Write(_linkUserId);
        outMsg.Write(_nickName);
        outMsg.Write((byte)_accountLinkType);
        outMsg.Write(_deviceCode);
        outMsg.Write(_macAddress);
    }
    #endregion
}


public class AcNetDataSC_resAccountLink : AcNetData_base
{
    public string _linkUserId;
    public string _nickName;
    public eAccountLinkType _accountLinkType;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        _linkUserId = inMsg.ReadString();
        _nickName = inMsg.ReadString();
        _accountLinkType = (eAccountLinkType)inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        outMsg.Write(_linkUserId);
        outMsg.Write(_nickName);
        outMsg.Write((byte)_accountLinkType);
    }
    #endregion
}

public class AcNetDataSS_reqUserAccountLink : AcNetData_base
{
    public long _userUId;
    public string _userId;
    public string _nickName;
    public int _pictureDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        _userUId = inMsg.ReadInt64();
        _userId = inMsg.ReadString();
        _nickName = inMsg.ReadString();
        _pictureDataId = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        outMsg.Write(_userUId);
        outMsg.Write(_userId);
        outMsg.Write(_nickName);
        outMsg.Write(_pictureDataId);
    }
    #endregion
}

#endregion

#region ���� �г��� ���

public class AcNetDataCS_reqRegisterNickName : AcNetData_base
{
    public string _userId;
    public string _regNickName;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        _userId = inMsg.ReadString();
        _regNickName = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        outMsg.Write(_userId);
        outMsg.Write(_regNickName);
    }
    #endregion
}

public class AcNetDataSC_resRegisterNickName : AcNetData_base
{
    public string _userId;
    public string _regNickName;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        _userId = inMsg.ReadString();
        _regNickName = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        outMsg.Write(_userId);
        outMsg.Write(_regNickName);
    }
    #endregion
}

#endregion

#region ���� ���� ����

public class AcNetDataSC_notifyUserStatChange : AcNetData_base
{
    public long _userUId;
    public eUserUpdateType _updateType;
    public long _updateValue;
    public int _safeNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _updateType = (eUserUpdateType)inMsg.ReadByte();
        _updateValue = inMsg.ReadInt64();
        _safeNumber = inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        outMsg.Write((byte)_updateType);
        outMsg.Write(_updateValue);
        outMsg.Write((byte)_safeNumber);
    }
    #endregion
}

#endregion

#region ���� �κ��丮 ����

public class AcNetDataSC_notifyUserInventoryChange : AcNetData_base
{
    public List<AcNetData_ItemChangeInfo> _itemChangeInfoList = new List<AcNetData_ItemChangeInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        ListParse(inMsg, _itemChangeInfoList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        ListPacking(outMsg, _itemChangeInfoList);
    }
    #endregion
}

#endregion

#region ���� �������� ���� ��û

public class AcNetDataSS_reqUserLeagueInfoRefresh : AcNetData_base
{
    public long _userUId;
    
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
    }
    #endregion
}

public class AcNetDataSS_resUserLeagueInfoRefresh : AcNetData_base
{
    public AcNetData_UserLeagueInfo _userLeagueInfo = new AcNetData_UserLeagueInfo();
    public AcNetData_LeagueRewardInfo _leagueRewardInfo = new AcNetData_LeagueRewardInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _userLeagueInfo.Parse(inMsg);
            _leagueRewardInfo.Parse(inMsg);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _userLeagueInfo.Packing(outMsg);
            _leagueRewardInfo.Packing(outMsg);
        }
    }
    #endregion
}

#endregion

#region ���� ���� ������Ʈ ����

public class AcNetDataSC_notifyUserLeagueUpdateInfo : AcNetData_base
{
    public AcNetData_UserLeagueInfo _userLeagueInfo = new AcNetData_UserLeagueInfo();
    public AcNetData_LeagueRewardInfo _leagueRewardInfo = new AcNetData_LeagueRewardInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userLeagueInfo.Parse(inMsg);
        _leagueRewardInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        _userLeagueInfo.Packing(outMsg);
        _leagueRewardInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region ���� ���׺��� ��û

public class AcNetDataCS_reqUserLeagueRewardAcquire : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
    }
    #endregion
}

public class AcNetDataSS_reqUserLeagueRewardAcquire : AcNetData_base
{
    public long _rewardUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ProxyParse(inMsg);
        _rewardUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ProxyPacking(outMsg);
        outMsg.Write(_rewardUId);
    }
    #endregion
}

public class AcNetDataSS_resUserLeagueRewardAcquire : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
    }
    #endregion
}


public class AcNetDataSC_resUserLeagueRewardAcquire : AcNetData_base
{
    public long _prizeChip;
    public long _luckyPoint;
    public List<AcNetData_ItemChangeInfo> _itemChangeInfoList = new List<AcNetData_ItemChangeInfo>();
    public List<AcNetData_ItemAcquireInfo> _itemAcquireInfoList = new List<AcNetData_ItemAcquireInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _prizeChip = inMsg.ReadInt64();
            _luckyPoint = inMsg.ReadInt64();
            ListParse(inMsg, _itemChangeInfoList);
            ListParse(inMsg, _itemAcquireInfoList);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write(_prizeChip);
            outMsg.Write(_luckyPoint);
            ListPacking(outMsg, _itemChangeInfoList);
            ListPacking(outMsg, _itemAcquireInfoList);
        }
    }
    #endregion
}

#endregion

#region ���� �ɼ����� ����

public class AcNetDataCS_reqUserOptionInfoSave : AcNetData_base
{
    public AcNetData_UserOptionInfo _optionInfo = new AcNetData_UserOptionInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _optionInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        _optionInfo.Packing(outMsg);
    }
    #endregion
}

public class AcNetDataSS_reqUserOptionInfoSave : AcNetData_base
{
    public long _userUId;
    public AcNetData_UserOptionInfo _optionInfo = new AcNetData_UserOptionInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _optionInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        _optionInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region ���� ���� ���ΰ�ħ ����

public class AcNetDataSS_notifyUserPostRefresh : AcNetData_base
{
    public List<long> _receiveUserUIdList = new List<long>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        ListParse(inMsg, _receiveUserUIdList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        ListPacking(outMsg, _receiveUserUIdList);
    }
    #endregion
}

#endregion

#region ���� TOT è�Ǿ� ���� ���� ��û

public class AcNetDataSS_reqUserTOTChampionShipInfoRefresh : AcNetData_base
{
    public long _userUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
    }
    #endregion
}

public class AcNetDataSS_resUserTOTChampionShipInfoRefresh : AcNetData_base
{
    public AcNetData_TOTChampionShipUserInfo _tOTChampionShipUserInfo = new AcNetData_TOTChampionShipUserInfo();
    public AcNetData_TOTChampionShipRewardInfo _tOTChampionShipRewardInfo = new AcNetData_TOTChampionShipRewardInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _tOTChampionShipUserInfo.Parse(inMsg);
            _tOTChampionShipRewardInfo.Parse(inMsg);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _tOTChampionShipUserInfo.Packing(outMsg);
            _tOTChampionShipRewardInfo.Packing(outMsg);
        }
    }
    #endregion
}

#endregion

#region ���� TOT è�Ǿ� ���� ������Ʈ ����

public class AcNetDataSC_notifyUserTOTChampionShipUpdateInfo : AcNetData_base
{
    public AcNetData_TOTChampionShipUserInfo _tOTChampionShipUserInfo = new AcNetData_TOTChampionShipUserInfo();
    public AcNetData_TOTChampionShipRewardInfo _tOTChampionShipRewardInfo = new AcNetData_TOTChampionShipRewardInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _tOTChampionShipUserInfo.Parse(inMsg);
        _tOTChampionShipRewardInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        _tOTChampionShipUserInfo.Packing(outMsg);
        _tOTChampionShipRewardInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region ���� TOT ��ũ ���� ���� ��û

public class AcNetDataSS_reqUserTOTRankInfoRefresh : AcNetData_base
{
    public long _userUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
    }
    #endregion
}

public class AcNetDataSS_resUserTOTRankInfoRefresh : AcNetData_base
{
    public long _userUId;
    public AcNetData_TOTRankRewardInfo _tOTRankRewardInfo = new AcNetData_TOTRankRewardInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _userUId = inMsg.ReadInt64();
            _tOTRankRewardInfo.Parse(inMsg);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write(_userUId);
            _tOTRankRewardInfo.Packing(outMsg);
        }
    }
    #endregion
}

#endregion

#region ���� TOT ��ũ ���� ������Ʈ ����

public class AcNetDataSC_notifyUserTOTRankUpdateInfo : AcNetData_base
{
    public AcNetData_TOTRankRewardInfo _tOTRankRewardInfo = new AcNetData_TOTRankRewardInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _tOTRankRewardInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        _tOTRankRewardInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region ���� TOT ��ũ ���� ��û

public class AcNetDataCS_reqUserTOTRankRewardAcquire : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
    }
    #endregion
}

public class AcNetDataSC_resUserTOTRankRewardAcquire : AcNetData_base
{
    public List<AcNetData_ItemChangeInfo> _itemChangeInfoList = new List<AcNetData_ItemChangeInfo>();
    public List<AcNetData_ItemAcquireInfo> _itemAcquireInfoList = new List<AcNetData_ItemAcquireInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            ListParse(inMsg, _itemChangeInfoList);
            ListParse(inMsg, _itemAcquireInfoList);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            ListPacking(outMsg, _itemChangeInfoList);
            ListPacking(outMsg, _itemAcquireInfoList);
        }
    }
    #endregion
}

#endregion

#region ���� TOT ��ũ ���� ��û

public class AcNetDataCS_reqUserTOTChampionShipRewardAcquire : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
    }
    #endregion
}

public class AcNetDataSC_resUserTOTChampionShipRewardAcquire : AcNetData_base
{
    public List<AcNetData_ItemChangeInfo> _itemChangeInfoList = new List<AcNetData_ItemChangeInfo>();
    public List<AcNetData_ItemAcquireInfo> _itemAcquireInfoList = new List<AcNetData_ItemAcquireInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            ListParse(inMsg, _itemChangeInfoList);
            ListParse(inMsg, _itemAcquireInfoList);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            ListPacking(outMsg, _itemChangeInfoList);
            ListPacking(outMsg, _itemAcquireInfoList);
        }
    }
    #endregion
}

#endregion



//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// Auto
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region �ڵ� ���� ���� ��û

public class AcNetDataCS_reqSetAutoInfoSave : AcNetData_base
{
    public AcNetData_SetAutoInfo _setAutoInfo = new AcNetData_SetAutoInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _setAutoInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        _setAutoInfo.Packing(outMsg);
    }
    #endregion
}

public class AcNetDataSC_resSetAutoInfoSave : AcNetData_base
{
    public AcNetData_SetAutoInfo _setAutoInfo = new AcNetData_SetAutoInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _setAutoInfo.Parse(inMsg);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _setAutoInfo.Packing(outMsg);
        }
    }
    #endregion
}

#endregion

#region �ڵ� ���� ��û

public class AcNetDataCS_reqAutoInfoSave : AcNetData_base
{
    public int _number;
    public bool _auto;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _number = inMsg.ReadByte();
        _auto = inMsg.ReadBoolean();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_number);
        outMsg.Write(_auto);
    }
    #endregion
}

#endregion

#region �ڵ� ���� ���� ��û

public class AcNetDataCS_reqSetAutoSettingSelect : AcNetData_base
{
    public int _number;
    public int _settingNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _number = inMsg.ReadByte();
        _settingNumber = inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_number);
        outMsg.Write((byte)_settingNumber);
    }
    #endregion
}

#endregion

#region �ڵ� ���� ���� ��û

public class AcNetDataCS_reqSetAutoSettingReset : AcNetData_base
{
    public int _settingNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _settingNumber = inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_settingNumber);
    }
    #endregion
}

public class AcNetDataSC_resSetAutoSettingReset : AcNetData_base
{
    public AcNetData_SetAutoInfo _setAutoInfo = new AcNetData_SetAutoInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _setAutoInfo.Parse(inMsg);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _setAutoInfo.Packing(outMsg);
        }
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// �ݰ�
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region �ݰ� ���� ��û

public class AcNetDataCS_reqSafeDeposit : AcNetData_base
{
    public int _safeSlotNumber;
    public long _depositChip;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _safeSlotNumber = inMsg.ReadByte();
        _depositChip = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_safeSlotNumber);
        outMsg.Write(_depositChip);
    }
    #endregion
}

public class AcNetDataSC_resSafeDeposit : AcNetData_base
{
    public AcNetData_SafeInfo _mainSafeInfo = new AcNetData_SafeInfo();
    public AcNetData_SafeInfo _changeSafeInfo = new AcNetData_SafeInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _mainSafeInfo.Parse(inMsg);
            _changeSafeInfo.Parse(inMsg);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _mainSafeInfo.Packing(outMsg);
            _changeSafeInfo.Packing(outMsg);
        }
    }
    #endregion
}

#endregion

#region �ݰ� ��� ��û

public class AcNetDataCS_reqSafeWithdraw : AcNetData_base
{
    public int _safeSlotNumber;
    public long _withdrawChip;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _safeSlotNumber = inMsg.ReadByte();
        _withdrawChip = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_safeSlotNumber);
        outMsg.Write(_withdrawChip);
    }
    #endregion
}

public class AcNetDataSC_resSafeWithdraw : AcNetData_base
{
    public AcNetData_SafeInfo _mainSafeInfo = new AcNetData_SafeInfo();
    public AcNetData_SafeInfo _changeSafeInfo = new AcNetData_SafeInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _mainSafeInfo.Parse(inMsg);
            _changeSafeInfo.Parse(inMsg);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _mainSafeInfo.Packing(outMsg);
            _changeSafeInfo.Packing(outMsg);
        }
    }
    #endregion
}

#endregion

#region �ݰ� Buy In/Out ���� ����

public class AcNetDataSC_notifySafeBuyInOutInfo : AcNetData_base
{
    public AcNetData_SafeInfo _mainSafeInfo = new AcNetData_SafeInfo();
    public AcNetData_SafeInfo _changeSafeInfo = new AcNetData_SafeInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _mainSafeInfo.Parse(inMsg);
        _changeSafeInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        _mainSafeInfo.Packing(outMsg);
        _changeSafeInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region �ݰ� ������ ����Ĩ BuyIn ��û

public class AcNetDataCS_reqSafeBuyInSameChipBefore : AcNetData_base
{
    public int _safeSlotNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _safeSlotNumber = inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_safeSlotNumber);
    }
    #endregion
}

public class AcNetDataSC_resSafeBuyInSameChipBefore : AcNetData_base
{
    public AcNetData_SafeInfo _mainSafeInfo = new AcNetData_SafeInfo();
    public AcNetData_SafeInfo _changeSafeInfo = new AcNetData_SafeInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _mainSafeInfo.Parse(inMsg);
            _changeSafeInfo.Parse(inMsg);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _mainSafeInfo.Packing(outMsg);
            _changeSafeInfo.Packing(outMsg);
        }
    }
    #endregion
}

#endregion


#region ��Ű����Ʈ Buy In/Out ���� ����

public class AcNetDataSC_notifyLuckyPointBuyInOutInfo : AcNetData_base
{
    public AcNetData_LuckyPointInfo _mainInfo = new AcNetData_LuckyPointInfo();
    public AcNetData_LuckyPointInfo _buyInInfo = new AcNetData_LuckyPointInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _mainInfo.Parse(inMsg);
        _buyInInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        _mainInfo.Packing(outMsg);
        _buyInInfo.Packing(outMsg);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ��ü�� ���� ��û

public class AcNetDataCS_reqPostBoxInfo : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSC_resPostBoxInfo : AcNetData_base
{
    public AcNetData_PostBoxInfo _postBoxInfo = new AcNetData_PostBoxInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        _postBoxInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        _postBoxInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region ���� ������ ȹ�� ��û

public class AcNetDataCS_reqPostItemAcquire : AcNetData_base
{
    public string _postUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _postUId = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_postUId);
    }
    #endregion
}

public class AcNetDataSC_resPostItemAcquire : AcNetData_base
{
    public string _acquirePostUId;
    public List<AcNetData_ItemChangeInfo> _itemChangeInfoList = new List<AcNetData_ItemChangeInfo>();
    public List<AcNetData_ItemAcquireInfo> _itemAcquireInfoList = new List<AcNetData_ItemAcquireInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);
        _acquirePostUId = inMsg.ReadString();

        if (_result == eGameResult.RESULT_OK)
        {
            ListParse(inMsg, _itemChangeInfoList);
            ListParse(inMsg, _itemAcquireInfoList);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);
        outMsg.Write(_acquirePostUId);

        if (_result == eGameResult.RESULT_OK)
        {
            ListPacking(outMsg, _itemChangeInfoList);
            ListPacking(outMsg, _itemAcquireInfoList);
        }
    }
    #endregion
}

#endregion

#region ���� ������ ȹ�� ����

public class AcNetDataSC_notifyPostNewAdd : AcNetData_base
{
    public AcNetData_PostInfo _postInfo = new AcNetData_PostInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _postInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        _postInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region ���� ������ ���� ��û

public class AcNetDataCS_reqPostRemove : AcNetData_base
{
    public string _postUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _postUId = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_postUId);
    }
    #endregion
}

public class AcNetDataSC_resPostRemove : AcNetData_base
{
    public string _postUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _postUId = inMsg.ReadString();
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write(_postUId);
        }
    }
    #endregion
}

#endregion

#region ���� ���� ��û

public class AcNetDataSS_reqPostRefresh : AcNetData_base
{
    public long _userUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
    }
    #endregion
}

public class AcNetDataSS_resPostRefresh : AcNetData_base
{
    public long _userUId;
    public List<AcNetData_PostInfo> _postList = new List<AcNetData_PostInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        ListParse(inMsg, _postList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        ListPacking(outMsg, _postList);
    }
    #endregion
}

#endregion

#region ���� ������ ���� ��û

public class AcNetDataCS_reqPostRead : AcNetData_base
{
    public string _postUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _postUId = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_postUId);
    }
    #endregion
}

public class AcNetDataSC_resPostRead : AcNetData_base
{
    public string _postUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _postUId = inMsg.ReadString();
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write(_postUId);
        }
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// ä��
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ä�� ���� ��� ����Ʈ ��û

public class AcNetDataSS_reqChannelGameModeInfoList : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSS_resChannelGameModeInfoList : AcNetData_base
{
    public List<AcNetData_ChannelGameModeInfo> _channelGameModeInfoList = new List<AcNetData_ChannelGameModeInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        ListParse(inMsg, _channelGameModeInfoList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        ListPacking(outMsg, _channelGameModeInfoList);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// ������ ��� 
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ������ ��� ���� ��û

public class AcNetDataSS_reqContentLockInfo : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSS_resContentLockInfo : AcNetData_base
{
    public List<AcNetData_ContentMainLockInfo> _contentMainLockInfoList = new List<AcNetData_ContentMainLockInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        ListParse(inMsg, _contentMainLockInfoList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        ListPacking(outMsg, _contentMainLockInfoList);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// High or Low ���� ��� ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region High or Low ���� ��� ���� ��û

public class AcNetDataSS_reqHighOrLowGameResultInfo : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSS_resHighOrLowGameResultInfo : AcNetData_base
{
    public List<int> _gameResultRateList = new List<int>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        ListParse(inMsg, _gameResultRateList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        ListPacking(outMsg, _gameResultRateList);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// �α�
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region �α� ���� ��û

public class AcNetDataCS_reqLogSave : AcNetData_base
{
    public DateTime _dateTime;
    public byte _mainLogType;
    public byte _subLogType;
    public string _logStr;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _dateTime = DateTime.Parse(inMsg.ReadString());
        _mainLogType = inMsg.ReadByte();
        _subLogType = inMsg.ReadByte();
        _logStr = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_dateTime.ToString("yyyy-MM-dd HH:mm:ss"));
        outMsg.Write(_mainLogType);
        outMsg.Write(_subLogType);
        outMsg.Write(_logStr);
    }
    #endregion
}


#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// �����Ͻ�
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region �����Ͻ� �α���

public class AcNetDataCS_reqLaytancyLogin : AcNetData_base
{
    public string _deviceInfo;
    public string _location;
    public string _networkInfo;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        _deviceInfo = inMsg.ReadString();
        _location = inMsg.ReadString();
        _networkInfo = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        outMsg.Write(_deviceInfo);
        outMsg.Write(_location);
        outMsg.Write(_networkInfo);
    }
    #endregion
}

#endregion

#region �����Ͻ� �α׾ƿ�

public class AcNetDataCS_reqLaytancyLogout : AcNetData_base
{
    public string _deviceInfo;
    public string _location;
    public string _networkInfo;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        _deviceInfo = inMsg.ReadString();
        _location = inMsg.ReadString();
        _networkInfo = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        outMsg.Write(_deviceInfo);
        outMsg.Write(_location);
        outMsg.Write(_networkInfo);
    }
    #endregion
}

#endregion

#region �����Ͻ� ��Ŷ

public class AcNetDataSC_reqLaytancyPacket : AcNetData_base
{
    public long _packetIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _packetIndex = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_packetIndex);
    }
    #endregion
}

public class AcNetDataCS_resLaytancyPacket : AcNetData_base
{
    public long _packetIndex;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _packetIndex = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_packetIndex);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// ģ��
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ģ�� ����Ʈ ��û

public class AcNetDataCS_reqFriendList : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSS_reqFriendList : AcNetData_base
{
    public long _userUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ProxyParse(inMsg);
        _userUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ProxyPacking(outMsg);
        outMsg.Write(_userUId);
    }
    #endregion
}

public class AcNetDataSC_resFriendList : AcNetData_base
{
    public List<AcNetData_FriendInfo> _friendList = new List<AcNetData_FriendInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        ListParse(inMsg, _friendList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        ListPacking(outMsg, _friendList);
    }
    #endregion
}

#endregion

#region ģ�� ��û

public class AcNetDataCS_reqFriendRequest : AcNetData_base
{
    public long _dstUserUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _dstUserUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_dstUserUId);
    }
    #endregion
}

public class AcNetDataSS_reqFriendRequest : AcNetData_base
{
    public long _userUId;
    public long _dstUserUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ProxyParse(inMsg);
        _userUId = inMsg.ReadInt64();
        _dstUserUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ProxyPacking(outMsg);
        outMsg.Write(_userUId);
        outMsg.Write(_dstUserUId);
    }
    #endregion
}

public class AcNetDataSC_resFriendRequest : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
    }
    #endregion
}

#endregion

#region ģ�� ��û ����

public class AcNetDataSC_notifyFriendRequest : AcNetData_base
{
    public long _userUId;
    public AcNetData_FriendRequestInfo _friendRequestInfo = new AcNetData_FriendRequestInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _friendRequestInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        _friendRequestInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region ģ�� ��û ����Ʈ ��û

public class AcNetDataCS_reqFriendRequestList : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSS_reqFriendRequestList : AcNetData_base
{
    public long _userUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ProxyParse(inMsg);
        _userUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ProxyPacking(outMsg);
        outMsg.Write(_userUId);
    }
    #endregion
}

public class AcNetDataSC_resFriendRequestList : AcNetData_base
{
    public List<AcNetData_FriendRequestInfo> _friendRequestList = new List<AcNetData_FriendRequestInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        ListParse(inMsg, _friendRequestList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        ListPacking(outMsg, _friendRequestList);
    }
    #endregion
}

#endregion

#region ģ�� ��û �������� ��û

public class AcNetDataCS_reqFriendRequestAccept : AcNetData_base
{
    public long _requestUId;
    public bool _accept;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _requestUId = inMsg.ReadInt64();
        _accept = inMsg.ReadBoolean();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_requestUId);
        outMsg.Write(_accept);
    }
    #endregion
}

public class AcNetDataSS_reqFriendRequestAccept : AcNetData_base
{
    public long _requestUId;
    public long _userUId;
    public bool _accept;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ProxyParse(inMsg);
        _userUId = inMsg.ReadInt64();
        _requestUId = inMsg.ReadInt64();
        _accept = inMsg.ReadBoolean();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ProxyPacking(outMsg);
        outMsg.Write(_userUId);
        outMsg.Write(_requestUId);
        outMsg.Write(_accept);
    }
    #endregion
}

public class AcNetDataSC_resFriendRequestAccept : AcNetData_base
{
    public long _requestUId;
    public bool _accept;
    public AcNetData_FriendInfo _friendInfo = new AcNetData_FriendInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _requestUId = inMsg.ReadInt64();
            _accept = inMsg.ReadBoolean();
            if (_accept == true)
            {
                _friendInfo.Parse(inMsg);
            }
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write(_requestUId);
            outMsg.Write(_accept);

            if (_accept == true)
            {
                _friendInfo.Packing(outMsg);
            }
        }
    }
    #endregion
}


#endregion

#region ģ�� �߰� ����

public class AcNetDataSC_notifyFriendAdd : AcNetData_base
{
    public long _userUId;
    public AcNetData_FriendInfo _friendInfo = new AcNetData_FriendInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _friendInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        _friendInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region ģ�� ���� ��û

public class AcNetDataCS_reqFriendRemove : AcNetData_base
{
    public long _friendUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _friendUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_friendUId);
    }
    #endregion
}

public class AcNetDataSS_reqFriendRemove : AcNetData_base
{
    public long _userUId;
    public long _friendUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ProxyParse(inMsg);
        _userUId = inMsg.ReadInt64();
        _friendUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ProxyPacking(outMsg);
        outMsg.Write(_userUId);
        outMsg.Write(_friendUId);
    }
    #endregion
}

public class AcNetDataSC_resFriendRemove : AcNetData_base
{
    public long _friendUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        _friendUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        outMsg.Write(_friendUId);
    }
    #endregion
}

#endregion

#region ģ�� ���� ����

public class AcNetDataSC_notifyFriendRemove : AcNetData_base
{
    public long _userUId;
    public long _friendUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _friendUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        outMsg.Write(_friendUId);
    }
    #endregion
}

#endregion

#region ���� ���� ���� �˸�

public class AcNetDataCS_notifyUserStateInfo : AcNetData_base
{
    public eUserState _userState;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userState = (eUserState)inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_userState);
    }
    #endregion
}

public class AcNetDataSS_notifyUserStateInfo : AcNetData_base
{
    public long _userUId;
    public eUserState _userState;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _userState = (eUserState)inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        outMsg.Write((byte)_userState);
    }
    #endregion
}


#endregion

#region ģ�� �������� ����Ʈ ��û

public class AcNetDataCS_reqFriendUserStateInfoList : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSS_reqFriendUserStateInfoList : AcNetData_base
{
    public long _userUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ProxyParse(inMsg);
        _userUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ProxyPacking(outMsg);
        outMsg.Write(_userUId);
    }
    #endregion
}

public class AcNetDataSC_resFriendUserStateInfoList : AcNetData_base
{
    public List<AcNetData_FriendUserStateInfo> _friendUserStateInfoList = new List<AcNetData_FriendUserStateInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        ListParse(inMsg, _friendUserStateInfoList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        ListPacking(outMsg, _friendUserStateInfoList);
    }
    #endregion
}

#endregion

#region ģ�� �α��� ����

public class AcNetDataSC_notifyFriendLogin : AcNetData_base
{
    public long _userUId;
    public long _friendUserUId;
    public eUserState _userState;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _friendUserUId = inMsg.ReadInt64();
        _userState = (eUserState)inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        outMsg.Write(_friendUserUId);
        outMsg.Write((byte)_userState);
    }
    #endregion
}

#endregion

#region ģ�� ��ũ ���߱� ��û

public class AcNetDataCS_reqFriendSync : AcNetData_base
{
    public List<string> _addFriendUserIdList = new List<string>();
    public List<long> _changeFriendUserUIdList = new List<long>();
    public List<long> _removeFriendUserUIdList = new List<long>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        ListParse(inMsg, _addFriendUserIdList);
        ListParse(inMsg, _changeFriendUserUIdList);
        ListParse(inMsg, _removeFriendUserUIdList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        ListPacking(outMsg, _addFriendUserIdList);
        ListPacking(outMsg, _changeFriendUserUIdList);
        ListPacking(outMsg, _removeFriendUserUIdList);
    }
    #endregion
}

public class AcNetDataSS_reqFriendSync : AcNetData_base
{
    public long _userUId;
    public List<string> _addFriendUserIdList = new List<string>();
    public List<long> _changeFriendUserUIdList = new List<long>();
    public List<long> _removeFriendUserUIdList = new List<long>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ProxyParse(inMsg);
        _userUId = inMsg.ReadInt64();
        ListParse(inMsg, _addFriendUserIdList);
        ListParse(inMsg, _changeFriendUserUIdList);
        ListParse(inMsg, _removeFriendUserUIdList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ProxyPacking(outMsg);
        outMsg.Write(_userUId);
        ListPacking(outMsg, _addFriendUserIdList);
        ListPacking(outMsg, _changeFriendUserUIdList);
        ListPacking(outMsg, _removeFriendUserUIdList);
    }
    #endregion
}

public class AcNetDataSC_resFriendSync : AcNetData_base
{
    public List<AcNetData_FriendInfo> _friendList = new List<AcNetData_FriendInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        ListParse(inMsg, _friendList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        ListPacking(outMsg, _friendList);
    }
    #endregion
}

#endregion

#region ģ�� ���� �ֱ� ��û

public class AcNetDataCS_reqFriendSendGift : AcNetData_base
{
    public List<long> _friendUIdList = new List<long>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        ListParse(inMsg, _friendUIdList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        ListPacking(outMsg, _friendUIdList);
    }
    #endregion
}

public class AcNetDataSS_reqFriendSendGift : AcNetData_base
{
    public long _userUId;
    public eLeagueGradeType _userLeagueGradeType;
    public List<long> _friendUIdList = new List<long>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ProxyParse(inMsg);
        _userUId = inMsg.ReadInt64();
        _userLeagueGradeType = (eLeagueGradeType)inMsg.ReadByte();
        ListParse(inMsg, _friendUIdList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ProxyPacking(outMsg);
        outMsg.Write(_userUId);
        outMsg.Write((byte)_userLeagueGradeType);
        ListPacking(outMsg, _friendUIdList);
    }
    #endregion
}

public class AcNetDataSC_resFriendSendGift : AcNetData_base
{
    public List<AcNetData_FriendSendGiftResultInfo> _resultInfoList = new List<AcNetData_FriendSendGiftResultInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        ListParse(inMsg, _resultInfoList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        ListPacking(outMsg, _resultInfoList);
    }
    #endregion
}

#endregion

#region ģ�� �ʴ� ���� ��û

public class AcNetDataCS_reqFriendInviteInfo : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSS_reqFriendInviteInfo : AcNetData_base
{
    public long _userUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ProxyParse(inMsg);
        _userUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ProxyPacking(outMsg);
        outMsg.Write(_userUId);
    }
    #endregion
}

public class AcNetDataSC_resFriendInviteInfo : AcNetData_base
{
    public AcNetData_UserFriendInviteInfo _userfriendInviteInfo = new AcNetData_UserFriendInviteInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _userfriendInviteInfo.Parse(inMsg);
        }

    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _userfriendInviteInfo.Packing(outMsg);
        }
    }
    #endregion
}

#endregion

#region ģ�� ��õ ��û

public class AcNetDataCS_reqFriendRecommend : AcNetData_base
{
    public string _inviteCode;
    public string _deviceCode;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _inviteCode = inMsg.ReadString();
        _deviceCode = inMsg.ReadString();
}
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_inviteCode);
        outMsg.Write(_deviceCode);
    }
    #endregion
}

public class AcNetDataSS_reqFriendRecommend : AcNetData_base
{
    public long _userUId;
    public string _inviteCode;
    public string _deviceCode;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ProxyParse(inMsg);
        _userUId = inMsg.ReadInt64();
        _inviteCode = inMsg.ReadString();
        _deviceCode = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ProxyPacking(outMsg);
        outMsg.Write(_userUId);
        outMsg.Write(_inviteCode);
        outMsg.Write(_deviceCode);
    }
    #endregion
}

public class AcNetDataSC_resFriendRecommend : AcNetData_base
{
    public AcNetData_UserFriendInviteInfo _userfriendInviteInfo = new AcNetData_UserFriendInviteInfo();
    //public long _acquireChip;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _userfriendInviteInfo.Parse(inMsg);
            //_acquireChip = inMsg.ReadInt64();
        }

    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _userfriendInviteInfo.Packing(outMsg);
            //outMsg.Write(_acquireChip);
        }
    }
    #endregion
}

#endregion

#region ģ�� �ʴ� ���� ��û

public class AcNetDataCS_reqFriendInviteRewardAcquire : AcNetData_base
{
    public int _friendRewardDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _friendRewardDataId = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_friendRewardDataId);
    }
    #endregion
}

public class AcNetDataSS_reqFriendInviteRewardAcquire : AcNetData_base
{
    public long _userUId;
    public int _friendRewardDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ProxyParse(inMsg);
        _userUId = inMsg.ReadInt64();
        _friendRewardDataId = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ProxyPacking(outMsg);
        outMsg.Write(_userUId);
        outMsg.Write(_friendRewardDataId);
    }
    #endregion
}

public class AcNetDataSC_resFriendInviteRewardAcquire : AcNetData_base
{
    public int _friendRewardDataId;
    public List<int> _inviteRewardAcquireDataIdList = new List<int>();
    public List<AcNetData_ItemChangeInfo> _itemChangeInfoList = new List<AcNetData_ItemChangeInfo>();
    public List<AcNetData_ItemAcquireInfo> _itemAcquireInfoList = new List<AcNetData_ItemAcquireInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _friendRewardDataId = inMsg.ReadInt32();
            ListParse(inMsg, _inviteRewardAcquireDataIdList);
            ListParse(inMsg, _itemChangeInfoList);
            ListParse(inMsg, _itemAcquireInfoList);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write(_friendRewardDataId);
            ListPacking(outMsg, _inviteRewardAcquireDataIdList);
            ListPacking(outMsg, _itemChangeInfoList);
            ListPacking(outMsg, _itemAcquireInfoList);
        }
    }
    #endregion
}

#endregion

#region ģ�� ä�� ��û

public class AcNetDataCS_reqFriendTalk : AcNetData_base
{
    public long _friendUserUId;
    public string _talkStr;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _friendUserUId = inMsg.ReadInt64();
        _talkStr = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_friendUserUId);
        outMsg.Write(_talkStr);
    }
    #endregion
}

public class AcNetDataSS_reqFriendTalk : AcNetData_base
{
    public long _userUId;
    public long _friendUserUId;
    public string _talkStr;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _friendUserUId = inMsg.ReadInt64();
        _talkStr = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        outMsg.Write(_friendUserUId);
        outMsg.Write(_talkStr);
    }
    #endregion
}

public class AcNetDataSC_resFriendTalk : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
    }
    #endregion
}

public class AcNetDataSC_notifyFriendTalk : AcNetData_base
{
    public long _receiveUserUId;
    public AcNetData_TalkInfo _talkInfo = new AcNetData_TalkInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _receiveUserUId = inMsg.ReadInt64();
        _talkInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_receiveUserUId);
        _talkInfo.Packing(outMsg);
    }
    #endregion
}
#endregion

#region ģ�� ��й� �ʴ� ��û

public class AcNetDataCS_reqFriendPrivateRoomInvite : AcNetData_base
{
    public long _friendUserUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _friendUserUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_friendUserUId);
    }
    #endregion
}

public class AcNetDataSS_reqFriendPrivateRoomInvite : AcNetData_base
{
    public long _userUId;
    public long _friendUserUId;
    public long _roomIndex;
    public int _gameRoomDataId;
    public bool _autoBootChip;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ProxyParse(inMsg);

        _userUId = inMsg.ReadInt64();
        _friendUserUId = inMsg.ReadInt64();
        _roomIndex = inMsg.ReadInt64();
        _gameRoomDataId = inMsg.ReadInt32();
        _autoBootChip = inMsg.ReadBoolean();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ProxyPacking(outMsg);

        outMsg.Write(_userUId);
        outMsg.Write(_friendUserUId);
        outMsg.Write(_roomIndex);
        outMsg.Write(_gameRoomDataId);
        outMsg.Write(_autoBootChip);
    }
    #endregion
}

public class AcNetDataSC_resFriendPrivateRoomInvite : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
    }
    #endregion
}

public class AcNetDataSC_notifyFriendPrivateRoomInvite : AcNetData_base
{
    public long _userUId;
    public long _friendUserUId;
    public long _roomIndex;
    public int _gameRoomDataId;
    public bool _autoBootChip;

    public bool _serverChange;
    public int _gameServerUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _friendUserUId = inMsg.ReadInt64();
        _roomIndex = inMsg.ReadInt64();
        _gameRoomDataId = inMsg.ReadInt32();
        _autoBootChip = inMsg.ReadBoolean();

        _serverChange = inMsg.ReadBoolean();
        if(_serverChange == true)
        {
            _gameServerUId = inMsg.ReadInt32();
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        outMsg.Write(_friendUserUId);
        outMsg.Write(_roomIndex);
        outMsg.Write(_gameRoomDataId);
        outMsg.Write(_autoBootChip);

        outMsg.Write(_serverChange);
        if (_serverChange == true)
        {
            outMsg.Write(_gameServerUId);
        }
    }
    #endregion
}
#endregion

#region ģ�� �ʴ� �� ������Ʈ ����

public class AcNetDataSC_notifyFriendInviteTotalCount : AcNetData_base
{
    public long _userUId;
    public int _InviteTotalCount;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _InviteTotalCount = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        outMsg.Write(_InviteTotalCount);
    }
    #endregion
}
#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// VIP
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region VIP ���� ����

public class AcNetDataSC_notifyVipInfo : AcNetData_base
{
    public int _VIPDataId;
    public DateTime _VIPEndDateTime;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _VIPDataId = inMsg.ReadInt32();
        _VIPEndDateTime = DateTime.Parse(inMsg.ReadString());
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_VIPDataId);
        outMsg.Write(_VIPEndDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"));
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// ��Ƽ���� ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ��Ƽ���� ���� ����

public class AcNetDataSC_notifyMultiSlotInfo : AcNetData_base
{
    public AcNetData_MultiSlotInfo _multiSlotInfo = new AcNetData_MultiSlotInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _multiSlotInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        _multiSlotInfo.Packing(outMsg);
    }
    #endregion
}

#endregion