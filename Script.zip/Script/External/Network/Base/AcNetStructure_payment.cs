using System.Collections.Generic;
using System;
using Lidgren.Network;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ���� ���̵� �߱� ��û

public class AcNetDataCS_reqPaymentId : AcNetData_base
{
    public ePaymentType _paymentType;
    public int _shopDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _paymentType = (ePaymentType)inMsg.ReadByte();
        _shopDataId = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_paymentType);
        outMsg.Write(_shopDataId);
    }
    #endregion
}

public class AcNetDataSC_resPaymentId : AcNetData_base
{
    public string _paymentId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _paymentId = inMsg.ReadString();
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write(_paymentId);
        }
    }
    #endregion
}

#endregion

#region ���� ���� �߰� ��û

public class AcNetDataSS_reqAddPaymentInfo : AcNetData_base
{
    public AcNetData_PaymentInfo _paymentInfo = new AcNetData_PaymentInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _paymentInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        _paymentInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region ���� ���� ���� ��û

public class AcNetDataSS_reqSavePaymentInfo : AcNetData_base
{
    public AcNetData_PaymentInfo _paymentInfo = new AcNetData_PaymentInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _paymentInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        _paymentInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region ���� Ȯ�� ��û

public class AcNetDataCS_reqPaymentVerify : AcNetData_base
{
    public string _receipt;
    public ePaymentType _paymentType;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _receipt = inMsg.ReadString();
        _paymentType = (ePaymentType)inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_receipt);
        outMsg.Write((byte)_paymentType);
    }
    #endregion
}

public class AcNetDataSC_resPaymentVerify : AcNetData_base
{
    public List<AcNetData_ItemChangeInfo> _itemChangeInfoList = new List<AcNetData_ItemChangeInfo>();
    public List<AcNetData_ItemAcquireInfo> _itemAcquireInfoList = new List<AcNetData_ItemAcquireInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            ListParse(inMsg, _itemChangeInfoList);
            ListParse(inMsg, _itemAcquireInfoList);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            ListPacking(outMsg, _itemChangeInfoList);
            ListPacking(outMsg, _itemAcquireInfoList);
        }
    }
    #endregion
}

public class AcNetDataSS_reqVerifyPaymentInfo : AcNetData_base
{
    public long _userUId;
    public string _paymentId;
    public string _orderId;
    public string _productId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _paymentId = inMsg.ReadString();
        _orderId = inMsg.ReadString();
        _productId = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        outMsg.Write(_paymentId);
        outMsg.Write(_orderId);
    }
    #endregion
}

#endregion

#region ���� Ȯ�εǾ����� ������ �� ��ǰ ���� ����

public class AcNetDataSC_notifyPaymentVerifyNonGiveGoods : AcNetData_base
{
    public int _shopDataId;
    public List<AcNetData_ItemChangeInfo> _itemChangeInfoList = new List<AcNetData_ItemChangeInfo>();
    public List<AcNetData_ItemAcquireInfo> _itemAcquireInfoList = new List<AcNetData_ItemAcquireInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _shopDataId = inMsg.ReadInt32();
            ListParse(inMsg, _itemChangeInfoList);
            ListParse(inMsg, _itemAcquireInfoList);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write(_shopDataId);
            ListPacking(outMsg, _itemChangeInfoList);
            ListPacking(outMsg, _itemAcquireInfoList);
        }
    }
    #endregion
}

#endregion

#region ���� ��� ��û

public class AcNetDataCS_reqPaymentCancel : AcNetData_base
{
    public string _paymentId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _paymentId = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_paymentId);
    }
    #endregion
}

public class AcNetDataSS_reqPaymentCancel : AcNetData_base
{
    public string _paymentId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _paymentId = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_paymentId);
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// PayTM
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region PayTM ���� ��� ��û

public class AcNetDataCS_reqPayTMInfoRegister : AcNetData_base
{
    public string _password;
    public string _mailAddress;
    public string _phoneNumber;
    public string _otpStr;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _password = inMsg.ReadString();
        _mailAddress = inMsg.ReadString();
        _phoneNumber = inMsg.ReadString();
        _otpStr = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_password);
        outMsg.Write(_mailAddress);
        outMsg.Write(_phoneNumber);
        outMsg.Write(_otpStr);
    }
    #endregion
}

public class AcNetDataSC_resPayTMInfoRegister : AcNetData_base
{
    public string _errorMessage;
    public string _phoneNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);
        _errorMessage = inMsg.ReadString();
        _phoneNumber = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);
        outMsg.Write(_errorMessage);
        outMsg.Write(_phoneNumber);
    }
    #endregion
}

public class AcNetDataSS_reqPayTMInfoSave : AcNetData_base
{
    public AcNetData_PayTMInfo _payTMInfo = new AcNetData_PayTMInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _payTMInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        _payTMInfo.Packing(outMsg);
    }
    #endregion
}

public class AcNetDataSS_reqPayTMLastUseRewardDataIdSave : AcNetData_base
{
    public long _userUId;
    public int _lastUseRewardDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _lastUseRewardDataId = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        outMsg.Write(_lastUseRewardDataId);
    }
    #endregion
}

#endregion

#region PayTM ȯ�� ���ִ��� Ȯ�� ��û

public class AcNetDataSS_reqPayTMExchangeCheckINR : AcNetData_base
{
    public long _userUId;
    public string _password;
    public int _dataId;
    public long _itemCount;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ProxyParse(inMsg);
        _userUId = inMsg.ReadInt64();
        _password = inMsg.ReadString();
        _dataId = inMsg.ReadInt32();
        _itemCount = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ProxyPacking(outMsg);
        outMsg.Write(_userUId);
        outMsg.Write(_password);
        outMsg.Write(_dataId);
        outMsg.Write(_itemCount);
    }
    #endregion
}

public class AcNetDataSS_resPayTMExchangeCheckINR : AcNetData_base
{
    public long _userUId;
    public string _password;
    public int _dataId;
    public long _itemCount;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        _userUId = inMsg.ReadInt64();
        if (_result == eGameResult.RESULT_OK)
        {
            _password = inMsg.ReadString();
            _dataId = inMsg.ReadInt32();
            _itemCount = inMsg.ReadInt64();
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        outMsg.Write(_userUId);
        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write(_password);
            outMsg.Write(_dataId);
            outMsg.Write(_itemCount);
        }
    }
    #endregion
}

#endregion

#region PayTM ȯ�� INR ���� ��û

public class AcNetDataSS_reqPayTMExchangeINR : AcNetData_base
{
    public long _exchangeINR;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _exchangeINR = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_exchangeINR);
    }
    #endregion
}

#endregion

#region PayTM ȯ�� ��û

public class AcNetDataCS_reqPayTMExchange : AcNetData_base
{
    public string _password;
    public int _dataId;
    public long _itemCount;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _password = inMsg.ReadString();
        _dataId = inMsg.ReadInt32();
        _itemCount = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_password);
        outMsg.Write(_dataId);
        outMsg.Write(_itemCount);
    }
    #endregion
}

public class AcNetDataSC_resPayTMExchange : AcNetData_base
{
    public string _errorCode;
    public int _lastUseRewardDataId;
    public string _shareRewardToken;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _lastUseRewardDataId = inMsg.ReadInt32();
            _shareRewardToken = inMsg.ReadString();
        }
        else
        {
            _errorCode = inMsg.ReadString();
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write(_lastUseRewardDataId);
            outMsg.Write(_shareRewardToken);
        }
        else
        {
            outMsg.Write(_errorCode);
        }
    }
    #endregion
}

#endregion

#region PayTM ȯ�� ��û ���� ���� ��û

public class AcNetDataSS_reqPayTMExchangeRequestInfo : AcNetData_base
{
    public long _userUId;
    public AcNetData_PayTMExchangeInfo _payTMExchangeInfo = new AcNetData_PayTMExchangeInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        _payTMExchangeInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        _payTMExchangeInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region PayTM ȯ�� ��û ��� ���� ���� ��û

public class AcNetDataSS_reqPayTMExchangeResultInfo : AcNetData_base
{
    public AcNetData_PayTMExchangeInfo _payTMExchangeInfo = new AcNetData_PayTMExchangeInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _payTMExchangeInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        _payTMExchangeInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region PayTM OTP ���� ���� ��û

public class AcNetDataCS_reqPayTMOTPMessageSend : AcNetData_base
{
    public string _phoneNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
        _phoneNumber = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
        outMsg.Write(_phoneNumber);
    }
    #endregion
}

public class AcNetDataSC_resPayTMOTPMessageSend : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);
    }
    #endregion
}

#endregion

#region PayTM OTP ���� ������ ��û

public class AcNetDataCS_reqPayTMOTPMessageResend : AcNetData_base
{
    public string _phoneNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
        _phoneNumber = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
        outMsg.Write(_phoneNumber);
    }
    #endregion
}

public class AcNetDataSC_resPayTMOTPMessageResend : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);
    }
    #endregion
}

#endregion

#region PayTM ����ȣ ���� ��û

public class AcNetDataCS_reqPayTMPhoneNumberChange : AcNetData_base
{
    public string _password;
    public string _phoneNumber;
    public string _otpStr;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _password = inMsg.ReadString();
        _phoneNumber = inMsg.ReadString();
        _otpStr = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_password);
        outMsg.Write(_phoneNumber);
        outMsg.Write(_otpStr);
    }
    #endregion
}

public class AcNetDataSC_resPayTMPhoneNumberChange : AcNetData_base
{
    public string _errorMessage;
    public string _phoneNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);
        _errorMessage = inMsg.ReadString();
        _phoneNumber = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);
        outMsg.Write(_errorMessage);
        outMsg.Write(_phoneNumber);
    }
    #endregion
}

#endregion

#region PayTM ��й�ȣ ���� ��û

public class AcNetDataCS_reqPayTMPasswordChange : AcNetData_base
{
    public string _password;
    public string _otpStr;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _password = inMsg.ReadString();
        _otpStr = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_password);
        outMsg.Write(_otpStr);
    }
    #endregion
}

public class AcNetDataSC_resPayTMPasswordChange : AcNetData_base
{
    public string _errorMessage;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);
        _errorMessage = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);
        outMsg.Write(_errorMessage);
    }
    #endregion
}

#endregion

#region PayTM ��� ���� ��û

public class AcNetDataCS_reqPayTMUseAgreement : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSC_resPayTMUseAgreement : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);

    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSS_reqPayTMUseAgreementSave : AcNetData_base
{
    public long _userUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
    }
    #endregion
}

#endregion


#region PayTM INR ���� �߰� ��û

public class AcNetDataSS_reqPayTMINRHaveAdd : AcNetData_base
{
    public long _payTMHaveAddINR;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _payTMHaveAddINR = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_payTMHaveAddINR);
    }
    #endregion
}

#endregion

#region PayTM INR ���� ������Ʈ ��û

public class AcNetDataSS_reqPayTMINRLimitUpdate : AcNetData_base
{
    public long _payTMHaveLimitINR;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _payTMHaveLimitINR = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_payTMHaveLimitINR);
    }
    #endregion
}

#endregion

#region PayTM ȯ�� ���� ���� ��û

public class AcNetDataCS_reqPayTMShareRewardAcquire : AcNetData_base
{
    public string _shareRewardToken;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _shareRewardToken = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_shareRewardToken);
    }
    #endregion
}

public class AcNetDataSC_resPayTMShareRewardAcquire : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);
    }
    #endregion
}

#endregion


#region PayTM ����ȣ ���� ���� Ȯ�� ��û

public class AcNetDataSS_reqPayTMPhoneNumberExists : AcNetData_base
{
    public string _password;
    public string _mailAddress;
    public string _phoneNumber;
    public string _otpStr;
    public ePayTMPhoneNumberExistsType _existsType;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ProxyParse(inMsg);

        _password = inMsg.ReadString();
        _mailAddress = inMsg.ReadString();
        _phoneNumber = inMsg.ReadString();
        _otpStr = inMsg.ReadString();
        _existsType = (ePayTMPhoneNumberExistsType)inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ProxyPacking(outMsg);

        outMsg.Write(_password);
        outMsg.Write(_mailAddress);
        outMsg.Write(_phoneNumber);
        outMsg.Write(_otpStr);
        outMsg.Write((byte)_existsType);
    }
    #endregion
}

public class AcNetDataSS_resPayTMPhoneNumberExists : AcNetData_base
{
    public string _password;
    public string _mailAddress;
    public string _phoneNumber;
    public string _otpStr;
    public ePayTMPhoneNumberExistsType _existsType;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        _password = inMsg.ReadString();
        _mailAddress = inMsg.ReadString();
        _phoneNumber = inMsg.ReadString();
        _otpStr = inMsg.ReadString();
        _existsType = (ePayTMPhoneNumberExistsType)inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        outMsg.Write(_password);
        outMsg.Write(_mailAddress);
        outMsg.Write(_phoneNumber);
        outMsg.Write(_otpStr);
        outMsg.Write((byte)_existsType);
    }
    #endregion
}

#endregion