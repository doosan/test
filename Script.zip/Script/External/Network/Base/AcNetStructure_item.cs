using System.Collections.Generic;
using System;
using Lidgren.Network;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// ������
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region �κ��丮 ���� ��û

public class AcNetDataCS_reqInventoryInfo : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
    }
    #endregion
}

public class AcNetDataSC_resInventoryInfo : AcNetData_base
{
    public AcNetData_InventoryInfo _inventoryInfo = new AcNetData_InventoryInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
        _inventoryInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
        _inventoryInfo.Packing(outMsg);
    }
    #endregion
}

#endregion

#region ������ ���� ��û

public class AcNetDataCS_reqItemEquip : AcNetData_base
{
    public Dictionary<eItemEquipType, List<string>> _itemEquipDic = new Dictionary<eItemEquipType, List<string>>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        var dicCount = inMsg.ReadUInt16();
        for (int i = 0; i < dicCount; i++)
        {
            var itemEquipType = (eItemEquipType)inMsg.ReadByte();
            var strList = new List<string>();
            ListParse(inMsg, strList);

            _itemEquipDic.Add(itemEquipType, strList);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((ushort)_itemEquipDic.Count);
        foreach (var itemEquipId in _itemEquipDic)
        {
            outMsg.Write((byte)itemEquipId.Key);
            ListPacking(outMsg, itemEquipId.Value);
        }
    }
    #endregion
}

public class AcNetDataSC_resItemEquip : AcNetData_base
{
    public AcNetData_ItemEquipInfo _itemEquipInfo = new AcNetData_ItemEquipInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if(_result == eGameResult.RESULT_OK)
        {
            _itemEquipInfo.Parse(inMsg);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _itemEquipInfo.Packing(outMsg);
        }
    }
    #endregion
}

#endregion

#region ������ ���� ���� ��û

public class AcNetDataCS_reqItemUnEquip : AcNetData_base
{
    public int _slotNumber;
    public eItemEquipType _itemEquipType;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _slotNumber = inMsg.ReadByte();
        _itemEquipType = (eItemEquipType)inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write((byte)_slotNumber);
        outMsg.Write((byte)_itemEquipType);
    }
    #endregion
}

public class AcNetDataSC_resItemUnEquip : AcNetData_base
{
    public int _slotNumber;
    public eItemEquipType _itemEquipType;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            _slotNumber = inMsg.ReadByte();
            _itemEquipType = (eItemEquipType)inMsg.ReadByte();
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            outMsg.Write((byte)_slotNumber);
            outMsg.Write((byte)_itemEquipType);
        }
    }
    #endregion
}

#endregion

#region ������ �Ǹ� ��û

public class AcNetDataCS_reqItemSell : AcNetData_base
{
    public string _itemUId;
    public int _itemDataId;
    public long _count;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _itemUId = inMsg.ReadString();
        _itemDataId = inMsg.ReadInt32();

        _count = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_itemUId);
        outMsg.Write(_itemDataId);

        outMsg.Write(_count);
    }
    #endregion
}

public class AcNetDataSC_resItemSell : AcNetData_base
{
    public List<AcNetData_ItemChangeInfo> _itemChangeInfoList = new List<AcNetData_ItemChangeInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            ListParse(inMsg, _itemChangeInfoList);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            ListPacking(outMsg, _itemChangeInfoList);
        }
    }
    #endregion
}

#endregion

#region ������ �ݰ� ��� ��û

public class AcNetDataCS_reqItemSafeUse : AcNetData_base
{
    public int _itemDataId;
    public long _count;
    public int _safeSlotNumber;
    public long _safeChip;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _itemDataId = inMsg.ReadInt32();
        _count = inMsg.ReadInt64();
        _safeSlotNumber = inMsg.ReadByte();
        _safeChip = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_itemDataId);
        outMsg.Write(_count);
        outMsg.Write((byte)_safeSlotNumber);
        outMsg.Write(_safeChip);
    }
    #endregion
}

public class AcNetDataSC_resItemSafeUse : AcNetData_base
{
    public List<AcNetData_ItemChangeInfo> _itemChangeInfoList = new List<AcNetData_ItemChangeInfo>();
    public AcNetData_SafeInfo _mainSafeInfo = new AcNetData_SafeInfo();
    public AcNetData_SafeInfo _changeSafeInfo = new AcNetData_SafeInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            ListParse(inMsg, _itemChangeInfoList);

            _mainSafeInfo.Parse(inMsg);
            _changeSafeInfo.Parse(inMsg);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            ListPacking(outMsg, _itemChangeInfoList);

            _mainSafeInfo.Packing(outMsg);
            _changeSafeInfo.Packing(outMsg);
        }
    }
    #endregion
}

#endregion

#region ������ ��� ��û

public class AcNetDataCS_reqItemUse : AcNetData_base
{
    public string _itemUId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _itemUId = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_itemUId);
    }
    #endregion
}

public class AcNetDataSC_resItemUse : AcNetData_base
{
    public List<AcNetData_ItemChangeInfo> _itemChangeInfoList = new List<AcNetData_ItemChangeInfo>();
    public List<AcNetData_ItemAcquireInfo> _itemAcquireInfoList = new List<AcNetData_ItemAcquireInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            ListParse(inMsg, _itemChangeInfoList);
            ListParse(inMsg, _itemAcquireInfoList);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            ListPacking(outMsg, _itemChangeInfoList);
            ListPacking(outMsg, _itemAcquireInfoList);
        }
    }
    #endregion
}

#endregion

#region ������ ���� ���� ��û

public class AcNetDataCS_reqItemPieceCraft : AcNetData_base
{
    public int _itemDataId;
    public long _craftCount;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _itemDataId = inMsg.ReadInt32();
        _craftCount = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_itemDataId);
        outMsg.Write(_craftCount);
    }
    #endregion
}

public class AcNetDataSC_resItemPieceCraft : AcNetData_base
{
    public List<AcNetData_ItemChangeInfo> _itemChangeInfoList = new List<AcNetData_ItemChangeInfo>();
    public List<AcNetData_ItemAcquireInfo> _itemAcquireInfoList = new List<AcNetData_ItemAcquireInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            ListParse(inMsg, _itemChangeInfoList);
            ListParse(inMsg, _itemAcquireInfoList);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            ListPacking(outMsg, _itemChangeInfoList);
            ListPacking(outMsg, _itemAcquireInfoList);
        }
    }
    #endregion
}

#endregion

#region ������ �ݰ� ��� ��û

public class AcNetDataCS_reqItemMultiAutoUseTicketUse : AcNetData_base
{
    public int _itemDataId;
    public int _multiSlotNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _itemDataId = inMsg.ReadInt32();
        _multiSlotNumber = inMsg.ReadByte();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_itemDataId);
        outMsg.Write((byte)_multiSlotNumber);
    }
    #endregion
}

public class AcNetDataSC_resItemMultiAutoUseTicketUse : AcNetData_base
{
    public List<AcNetData_ItemChangeInfo> _itemChangeInfoList = new List<AcNetData_ItemChangeInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            ListParse(inMsg, _itemChangeInfoList);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            ListPacking(outMsg, _itemChangeInfoList);
        }
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ���� ������ ���� ��û

public class AcNetDataCS_reqShopItemBuy : AcNetData_base
{
    public int _shopDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _shopDataId = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_shopDataId);
    }
    #endregion
}

public class AcNetDataSC_resShopItemBuy : AcNetData_base
{
    public List<AcNetData_ItemChangeInfo> _itemChangeInfoList = new List<AcNetData_ItemChangeInfo>();
    public List<AcNetData_ItemAcquireInfo> _itemAcquireInfoList = new List<AcNetData_ItemAcquireInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            ListParse(inMsg, _itemChangeInfoList);
            ListParse(inMsg, _itemAcquireInfoList);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            ListPacking(outMsg, _itemChangeInfoList);
            ListPacking(outMsg, _itemAcquireInfoList);
        }
    }
    #endregion
}

#endregion

#region ���� ���� ���� ��û

public class AcNetDataCS_reqShopGachaBuy : AcNetData_base
{
    public int _shopGachaDataId;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _shopGachaDataId = inMsg.ReadInt32();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_shopGachaDataId);
    }
    #endregion
}

public class AcNetDataSC_resShopGachaBuy : AcNetData_base
{
    public List<AcNetData_ItemChangeInfo> _itemChangeInfoList = new List<AcNetData_ItemChangeInfo>();
    public List<AcNetData_ItemAcquireInfo> _itemAcquireInfoList = new List<AcNetData_ItemAcquireInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            ListParse(inMsg, _itemChangeInfoList);
            ListParse(inMsg, _itemAcquireInfoList);
        }
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);

        if (_result == eGameResult.RESULT_OK)
        {
            ListPacking(outMsg, _itemChangeInfoList);
            ListPacking(outMsg, _itemAcquireInfoList);
        }
    }
    #endregion
}

#endregion


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// ���� ��ǰ ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ���� ���� ��ǰ ���� ���� ������Ʈ ��û

public class AcNetDataSS_reqUserLimitProductInfoUpdate : AcNetData_base
{
    public long _userUId;
    public List<AcNetData_UserLimitProductInfo> _addUserLimitProductInfo = new List<AcNetData_UserLimitProductInfo>();
    public List<AcNetData_UserLimitProductInfo> _updateUserLimitProductInfo = new List<AcNetData_UserLimitProductInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userUId = inMsg.ReadInt64();
        ListParse(inMsg, _addUserLimitProductInfo);
        ListParse(inMsg, _updateUserLimitProductInfo);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_userUId);
        ListPacking(outMsg, _addUserLimitProductInfo);
        ListPacking(outMsg, _updateUserLimitProductInfo);
    }
    #endregion
}

#endregion

#region ���� ���� ��ǰ ���� ����Ʈ ��û

public class AcNetDataCS_reqUserLimitProductInfoList : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.TempParse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.TempPacking(outMsg);
    }
    #endregion
}

public class AcNetDataSC_resUserLimitProductInfoList : AcNetData_base
{
    public List<AcNetData_UserLimitProductInfo> _userLimitProductInfoList = new List<AcNetData_UserLimitProductInfo>();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.ResultParse(inMsg);
        ListParse(inMsg, _userLimitProductInfoList);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.ResultPacking(outMsg);
        ListPacking(outMsg, _userLimitProductInfoList);
    }
    #endregion
}

#endregion

#region ���� ���� ��ǰ ���� ����

public class AcNetDataSC_notifyUserLimitProductInfo : AcNetData_base
{
    public AcNetData_UserLimitProductInfo _userLimitProductInfo = new AcNetData_UserLimitProductInfo();

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _userLimitProductInfo.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        _userLimitProductInfo.Packing(outMsg);
    }
    #endregion
}

#endregion