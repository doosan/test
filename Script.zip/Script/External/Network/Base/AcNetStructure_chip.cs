using UnityEngine;
using System.Collections.Generic;
using System;
using Lidgren.Network;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// Ĩ ����
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#region ���� ���� ��û

public class AcNetDataCS_reqBankInfo : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
    }
    #endregion
}

public class AcNetDataSC_resBankInfo : AcNetData_base
{
    public string _bankName;
    public string _accountMasterName;
    public string _accountNumber;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _bankName = inMsg.ReadString();
        _accountMasterName = inMsg.ReadString();
        _accountNumber = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_bankName);
        outMsg.Write(_accountMasterName);
        outMsg.Write(_accountNumber);
    }
    #endregion
}
#endregion

#region ���� ��û

public class AcNetDataCS_reqChipCharge : AcNetData_base
{
    public long _chargeChip;
    public string _depositName;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _chargeChip = inMsg.ReadInt64();
        _depositName = inMsg.ReadString();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_chargeChip);
        outMsg.Write(_depositName);
    }
    #endregion
}

public class AcNetDataSC_resChipCharge : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
    }
    #endregion
}

#endregion

#region ȯ�� ��û

public class AcNetDataCS_reqChipExchange : AcNetData_base
{
    public string _bankName;
    public string _accountMasterName;
    public string _accountNumber;
    public string _phoneNumber;
    public long _exchangeChip;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _bankName = inMsg.ReadString();
        _accountMasterName = inMsg.ReadString();
        _accountNumber = inMsg.ReadString();
        _phoneNumber = inMsg.ReadString();
        _exchangeChip = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_bankName);
        outMsg.Write(_accountMasterName);
        outMsg.Write(_accountNumber);
        outMsg.Write(_phoneNumber);
        outMsg.Write(_exchangeChip);
    }
    #endregion
}

public class AcNetDataSC_resChipExchange : AcNetData_base
{
    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        base.Parse(inMsg);
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        base.Packing(outMsg);
    }
    #endregion
}

#endregion

#region ���� �Ϸ� ����

public class AcNetDataSC_NotifyChipChargeComplete : AcNetData_base
{
    public long _chargeChip;
    public long _totalChip;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _chargeChip = inMsg.ReadInt64();
        _totalChip = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_chargeChip);
        outMsg.Write(_totalChip);
    }
    #endregion
}

#endregion

#region ȯ�� �Ϸ� ����

public class AcNetDataSC_NotifyChipExchangeComplete : AcNetData_base
{
    public long _exchangeChip;
    public long _totalChip;

    #region �޽��� �Ľ�
    //----------------------------------------------------------------
    // �޽��� �Ľ�
    public override void Parse(NetIncomingMessage inMsg)
    {
        _exchangeChip = inMsg.ReadInt64();
        _totalChip = inMsg.ReadInt64();
    }
    #endregion

    #region �޽��� ��ŷ
    //----------------------------------------------------------------
    public override void Packing(NetOutgoingMessage outMsg)
    {
        outMsg.Write(_exchangeChip);
        outMsg.Write(_totalChip);
    }
    #endregion
}

#endregion