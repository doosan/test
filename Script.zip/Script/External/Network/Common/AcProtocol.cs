﻿
public static class AcNetMessageHeaders
{
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 입장 0 ~
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public const ushort SCRes_ConnectedMsg = 0;                         // [S->C] [입장] 접속 알림(서버간접속도 같이씀)                                     
    public const ushort CSReq_ServerConnectionInfoCheck = 1;			// [C->S] [입장] 클라이언트 서버 연결 정보 확인 요청
    public const ushort SCRes_ServerConnectionInfoCheck = 2;			// [S->C] [입장] 클라이언트 서버 연결 정보 확인 요청 응답
    public const ushort CSReq_ServerDateTime = 3;				        // [C->S] [입장] 서버 시간 요청
    public const ushort SCRes_ServerDateTime = 4;				        // [S->C] [입장] 서버 시간 응답
    public const ushort CSReq_Account = 5;				                // [C->S] [입장] 회원 가입 요청                                     
    public const ushort SCRes_Account = 6;				                // [S->C] [입장] 회원 가입 응답    
    public const ushort CSReq_Login = 7;				                // [C->S] [입장] 로그인 요청   
    public const ushort SCRes_Login = 8;				                // [C->S] [입장] 로그인 응답
    public const ushort CSReq_Logout = 9;						        // [C->S] [입장] 로그아웃 요청
    public const ushort SCRes_Logout = 10;						        // [S->C] [입장] 로그아웃 응답
    public const ushort CSReq_UserInfo = 11;						    // [C->S] [입장] 유저 정보 요청   
    public const ushort SCRes_UserInfo = 12;						    // [S->C] [입장] 유저 정보 요청   
    public const ushort CSReq_AccountLink = 13;				            // [C->S] [등록] 유저 계정 연결 요청
    public const ushort SCRes_AccountLink = 14;                         // [S->C] [등록] 유저 계정 연결 요청 응답
    public const ushort CSReq_UserProfileRegister = 15;				    // [C->S] [등록] 유저 프로필 등록
    public const ushort SCRes_UserProfileRegister = 16;                 // [S->C] [등록] 유저 프로필 등록 응답   
    public const ushort CSReq_SetAutoInfoSave = 17;				        // [C->S] [입장] 유저 SetAuto 정보 저장
    public const ushort SCRes_SetAutoInfoSave = 18;                     // [S->C] [입장] 유저 SetAuto 정보 저장
    public const ushort CSReq_SetAutoSettingSelect = 19;                // [C->S] [입장] 유저 오토 셋팅 선택
    public const ushort CSReq_SetAutoSettingReset = 20;                 // [C->S] [입장] 유저 오토 셋팅 선택
    public const ushort SCRes_SetAutoSettingReset = 21;                 // [S->C] [입장] 유저 오토 셋팅 선택
    public const ushort CSReq_AutoInfoSave = 22;				        // [C->S] [입장] 유저 Auto 정보 저장(단순 오토인지만)
    public const ushort CSReq_UserOptionInfoSave = 23;				    // [C->S] [입장] 유저 옵션 정보 저장 요청
    public const ushort CSReq_GameServerChange = 24;				    // [C->S] [입장] 게임서버 변경 요청   
    public const ushort CSReq_UserPolicyAccept = 25;				    // [C->S] [입장] 유저 약관 수락 요청
    public const ushort SCRes_UserPolicyAccept = 26;				    // [S->C] [입장] 유저 약관 수락 응답


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 로비
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public const ushort CSReq_RoomPrivateCreate = 100;			        // [C->S] [로비] 비밀 방 생성 요청
    public const ushort SCRes_RoomPrivateCreate = 101;                  // [S->C] [로비] 비밀 방 생성 응답
    public const ushort CSReq_RoomEnter = 102;			                // [C->S] [로비] 방 입장 요청
    public const ushort SCRes_RoomEnter = 103;                          // [S->C] [로비] 방 입장 응답
    public const ushort CSReq_RoomQuickEnter = 104;			            // [C->S] [로비] 방 빠른 입장 요청
    public const ushort SCRes_RoomQuickEnter = 105;                     // [S->C] [로비] 방 빠른 입장 응답
    public const ushort CSReq_RoomSwitchingEnter = 106;			        // [C->S] [로비] 방 스위칭 입장 요청
    public const ushort SCRes_RoomSwitchingEnter = 107;			        // [S->C] [로비] 방 스위칭 입장 응답
    public const ushort SCRes_RoomSwitchingEnterEnable = 108;			// [S->C] [로비] 방 스위칭 입장 가능 여부 응답
    public const ushort CSReq_RoomLeave = 109;			                // [C->S] [로비] 방 퇴장 요청
    public const ushort SCRes_RoomLeave = 110;			                // [S->C] [로비] 방 퇴장 응답
    public const ushort SCNotify_RoomForceLeave = 111;			        // [S->C] [로비] 방 강제 퇴장 공지
    public const ushort CSReq_RoomList = 112;			                // [C->S] [로비] 방 리스트 요청
    public const ushort SCRes_RoomList = 113;			                // [S->C] [로비] 방 리스트 응답
    public const ushort CSReq_RoomSlotAttend = 114;			            // [C->S] [로비] 방 슬롯 착석 요청
    public const ushort SCRes_RoomSlotAttend = 115;			            // [S->C] [로비] 방 슬롯 착석 응답
    public const ushort CSReq_RoomSlotStandUp = 116;			        // [C->S] [로비] 방 슬롯 착석 요청
    public const ushort SCRes_RoomSlotStandUp = 117;			        // [S->C] [로비] 방 슬롯 착석 응답
    public const ushort SCNotify_RoomSlotInfo = 118;			        // [S->C] [로비] 덱 슬롯 체인지 응답
    public const ushort SCNotify_RoomStateChange = 119;			        // [S->C] [로비] 방 상태 변경 공지
    public const ushort SCNotify_RoomSlotStateChange = 120;			    // [S->C] [로비] 방 슬롯 상태 변경 공지
    public const ushort SCNotify_RoomSlotLackBalanceStandUp = 121;		// [S->C] [로비] 방 슬롯 재화 부족 일으킴 공지
    public const ushort SCNotify_RoomSlotLackMultiTimeStandUp = 122;	// [S->C] [로비] 방 슬롯 멀티 시간만료로 일으킴 공지
    public const ushort SCNotify_RoomSlotSafeChipMaxVolumeStandUp = 123; // [S->C] [로비] 방 슬롯 금고 칩 최대치로 일으킴 공지
    public const ushort SCNotify_RoomSlotAutoStandUp = 124;		        // [S->C] [로비] 방 슬롯 자동 일으킴 공지
    public const ushort SCNotify_RoomSlotUserBalanceInfo = 125;			// [S->C] [로비] 방 슬롯 유저 재화 정보 공지
    public const ushort SCNotify_UserStatChange = 126;                  // [S->C] [로비] 유저 상태 변경     // 재화 등등
    public const ushort CSReq_RoomTalk = 127;                           // [C->S] [로비] 방 채팅 요청
    public const ushort SCRes_RoomTalk = 128;                           // [C->S] [로비] 방 채팅 요청 응답
    public const ushort SCNotify_RoomTalk = 129;                        // [S->C] [로비] 방 채팅 공지
    public const ushort CSReq_UserProfileInfo = 130;				    // [C->S] [로비] 유저 프로필 정보 요청
    public const ushort SCRes_UserProfileInfo = 131;                    // [S->C] [로비] 유저 프로필 정보 요청 응답
    public const ushort SCNotify_UserLeagueUpdate = 132;                // [S->C] [로비] 유저 리그 업데이트 공지
    public const ushort CSReq_UserLeagueRewardAcquire = 133;			// [C->S] [로비] 유저 리그 보상 획득 요청
    public const ushort SCRes_UserLeagueRewardAcquire = 134;            // [S->C] [로비] 유저 리그 보상 획득 요청 응답
    public const ushort SSReq_UserLeagueRewardAcquire = 135;            // [GS->DS] [로비] 유저 리그 보상획득 저장 요청
    public const ushort SSRes_UserLeagueRewardAcquire = 136;            // [GS->DS] [로비] 유저 리그 보상획득 저장 요청
    public const ushort CSReq_RoomMainSelect = 137;			            // [C->S] [로비] 방 메인 선택
    public const ushort SCRes_RoomMainSelect = 138;			            // [S->C] [로비] 방 메인 선택
    public const ushort CSReq_UserPictureChange = 139;				    // [C->S] [로비] 유저 초상화 변경 요청
    public const ushort SCRes_UserPictureChange = 140;				    // [C->S] [로비] 유저 초상화 변경 요청 응답
    public const ushort CSReq_UserResearch = 141;				        // [C->S] [로비] 유저 설문 조사 참여 요청
    public const ushort SCRes_UserResearch = 142;				        // [C->S] [로비] 유저 설문 조사 참여 응답
    public const ushort SCRes_UserResearchEndLackChipReward = 143;		// [C->S] [로비] 유저 설문 조사끝 부족칩 보상 요청
    public const ushort CSReq_UserResearchEndLackChipReward = 144;		// [C->S] [로비] 유저 설문 조사끝 부족칩 보상 응답
    public const ushort CSReq_UserDailyReward = 145;		            // [C->S] [로비] 유저 하루 보상 획득 요청 (안씀)
    public const ushort SCRes_UserDailyReward = 146;		            // [C->S] [로비] 유저 하루 보상 획득 요청 응답 (안씀)
    public const ushort SSNotify_UserPostRefesh = 147;                  // [S->S] [우편] 유저 우편 새로고침 공지
    public const ushort SCNotify_RoomGameRoomDataChange = 148;			// [S->C] [로비] 방 게임룸 데이터 변경 알림
    public const ushort CSReq_RoomPrivatePlayStateChange = 149;			// [C->S] [로비] 비밀방 플레이 상태 변경 요청
    public const ushort SCRes_RoomPrivatePlayStateChange = 150;			// [S->C] [로비] 비밀방 플레이 상태 변경 요청 응답
    public const ushort SCNotify_RoomPrivatePlayStateChange = 151;		// [S->C] [로비] 비밀방 플레이 상태 변경 공지
    public const ushort SCNotify_RoomMasterChange = 152;		        // [S->C] [로비] 방 마스터 변경 공지
    public const ushort CSReq_GaneshaTip = 153;                         // [C->S] [로비] 가네샤 팁주기 요청
    public const ushort SCRes_GaneshaTip = 154;                         // [S->S] [로비] 가네샤 팁주기 요청 응답
    public const ushort CSNotify_UserInLobby = 155;                     // [C->S] [로비] 유저 로비에 있다고 알림
    public const ushort SCNotify_ContentLockInfo = 156;                 // [S->S] [입장] 컨텐츠 잠금 정보 공지
    public const ushort CSReq_GaneshaPocketConvertLP = 157;             // [C->S] [로비] 가네샤 LP 변환 요청
    public const ushort SCRes_GaneshaPocketConvertLP = 158;             // [S->S] [로비] 가네샤 LP 변환 요청 응답
    public const ushort CSReq_ContentsLockCheck = 159;                  // [C->S] [로비] 가네샤 LP 변환 요청
    public const ushort SCRes_ContentsLockCheck = 160;                  // [S->S] [로비] 가네샤 LP 변환 요청 응답
    public const ushort SCNotify_UserInventoryChange = 161;			    // [S->C] [로비] 유저 인벤토리 변경 알림
    public const ushort CSReq_RoomRecommendEnter = 162;			        // [C->S] [로비] 방 추천 입장 요청
    public const ushort SCRes_RoomRecommendEnter = 163;			        // [S->C] [로비] 방 추천 입장 응답
    public const ushort SCNotify_ChannelGameRoomOpen = 164;             // [S->C] [로비] 채널 룸 오픈 공지
    public const ushort SCNotify_LPRoomSlotInfo = 165;			        // [S->C] [로비] 덱 슬롯 체인지 응답
    public const ushort CSReq_EnableEnterChannelInfo = 166;			    // [C->S] [로비] 입장 가능 채널 정보 요청
    public const ushort SCRes_EnableEnterChannelInfo = 167;			    // [S->C] [로비] 입장 가능 채널 정보 요청 응답
    public const ushort CSReq_EnableEnterHighGradeChannel = 168;	    // [C->S] [로비] 입장 가능 상위 채널 정보 요청
    public const ushort SCRes_EnableEnterHighGradeChannel = 169;	    // [S->C] [로비] 입장 가능 상위 채널 정보 요청 응답
    public const ushort SCNotify_RoomSlotTicketBalanceInfo = 170;       // [S->C] [로비] 슬롯 티켓 발란스 정보 공지
    public const ushort SCNotify_RoomSlotUserBalanceMaxLimitFix = 171;	// [S->C] [로비] 유저 재화 정보 맥스 재화 제한에 따른 수정 공지


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 인게임
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public const ushort SCNotify_RoomGameStart = 200;			        // [S->C] [인게임] 게임 시작됬음을 공지
    public const ushort SCNotify_RoomGameEnd = 201;			            // [S->C] [인게임] 게임 끝났음을 공지
    public const ushort SCNotify_CurrentTurn = 202;			            // [S->C] [인게임] 현재 턴 공지
    public const ushort CSReq_Betting = 203;			                // [C->s] [인게임] 배팅 요청
    public const ushort SCRes_Betting = 204;			                // [S->C] [인게임] 배팅 응답
    public const ushort SCNotify_Betting = 205;			                // [S->C] [인게임] 배팅 공지
    public const ushort CSReq_CardSee = 206;			                // [C->S] [인게임] 카드 보기 요청
    public const ushort SCRes_CardSee = 207;			                // [S->C] [인게임] 카드 보기 응답
    public const ushort SCNotify_CardSee = 208;			                // [S->C] [인게임] 카드 보기 공지
    public const ushort SCNotify_ForceCardSee = 209;			        // [S->C] [인게임] 강제 카드 보기 공지
    public const ushort CSReq_SideShowAccept = 210;			            // [C->S] [인게임] 카드 보기 요청
    public const ushort SCRes_SideShowAccept = 211;			            // [S->C] [인게임] 카드 보기 응답
    public const ushort SCNotify_SideShowAccept = 212;			        // [S->C] [인게임] 카드 보기 공지
    public const ushort SCNotify_SafeMoveChip = 213;			        // [S->C] [인게임] 금고 칩 이동 공지
    public const ushort CSReq_Animation = 214;			                // [C->S] [인게임] 애니메이션 요청
    public const ushort SCRes_Animation = 215;			                // [S->C] [인게임] 애니메이션 요청 응답
    public const ushort SCNotify_Animation = 216;			            // [S->C] [인게임] 애니메이션 요청 공지
    public const ushort SCNotify_CardReceive = 217;			            // [S->C] [인게임] 카드 받음 공지
    public const ushort SCNotify_RoundState = 218;			            // [S->C] [인게임] 라운드 상태 공지
    public const ushort SCNotify_ShowDownType = 219;			        // [S->C] [인게임] 쇼다운 타입 공지
    public const ushort SCNotify_GameResult = 220;			            // [S->C] [인게임] 게임 결과 공지
    public const ushort SCNotify_TotalPot = 221;			            // [S->C] [인게임] 토탈팟 공지
    public const ushort SCNotify_BettingEnable = 222;                   // [S->C] [인게임] 배팅 가능여부 공지
    public const ushort CSReq_DealerTip = 223;			                // [C->S] [인게임] 딜러 팁 요청
    public const ushort SCRes_DealerTip = 224;			                // [S->C] [인게임] 딜러 팁 요청 응답
    public const ushort SCNotify_DealerTip = 225;                       // [S->C] [인게임] 딜러 팁 요청 공지
    public const ushort CSReq_AllInAccept = 226;			            // [C->S] [인게임] 올인 수락 여부 요청
    public const ushort SCRes_AllInAccept = 227;			            // [S->C] [인게임] 올인 수락 여부 요청 응답
    public const ushort SCNotify_AllInAccept = 228;			            // [S->C] [인게임] 올인 수락 여부 요청 공지
    

    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 랭크
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public const ushort SSReq_LeaguePointAdd = 300;                     // [GS->RS] [서버] 리그 포인트 추가 요청
    public const ushort CSReq_RankUserList = 301;                       // [C->S] [로비] 랭크 유저 리스트 요청
    public const ushort SCRes_RankUserList = 302;                       // [S->C] [로비] 랭크 유저 리스트 공지
    public const ushort CSReq_LeagueGroupInfo = 303;                    // [C->S] [로비] 리그 그룹 정보 요청
    public const ushort SCRes_LeagueGroupInfo = 304;                    // [S->C] [로비] 리그 그룹 정보 공지
    public const ushort CSReq_SimpleLeagueGroupInfo = 305;              // [C->S] [로비] 심플 리그 그룹 정보 요청
    public const ushort SCRes_SimpleLeagueGroupInfo = 306;              // [S->C] [로비] 심플 리그 그룹 정보 공지
    public const ushort CSReq_ChipRankUserList = 307;                   // [C->S] [로비] 칩 랭크 유저 리스트 요청
    public const ushort SCRes_ChipRankUserList = 308;                   // [S->C] [로비] 칩 랭크 유저 리스트 공지
    public const ushort SSNotify_LeagueInfoRefresh = 309;               // [GS->RS] [서버] 리그 정보 갱신하라고 공지
    public const ushort SSReq_UserLeagueInfoRefresh = 310;              // [GS->DS] [서버] 유저 리그 정보 갱신 요청
    public const ushort SSRes_UserLeagueInfoRefresh = 311;              // [DS->GS] [서버] 유저 리그 정보 갱신 요청 응답

    public const ushort SSReq_TOTChampionShipStateInfo = 312;           // [GS->RS] [로비] TOT 챔피언쉽 상태 정보 요청
    public const ushort SSRes_TOTChampionShipStateInfo = 313;           // [RS->GS] [로비] TOT 챔피언쉽 상태 정보 요청 응답
    public const ushort SCNotify_TOTChampionShipStateInfo = 314;        // [S->C] [로비] TOT 챔피언쉽 상태 정보 공지
    public const ushort CSReq_TOTChampionShipUserList = 315;            // [S->C] [로비] TOT 챔피언쉽 랭크 정보 요청
    public const ushort SCRes_TOTChampionShipUserList = 316;            // [S->C] [로비] TOT 챔피언쉽 랭크 정보 요청 응답
    public const ushort CSReq_SimpleTOTChampionShipUserList = 317;      // [S->C] [로비] 유저 TOT 챔피언쉽 정보 요청
    public const ushort SCRes_SimpleTOTChampionShipUserList = 318;      // [S->C] [로비] 유저 TOT 챔피언쉽 정보 요청 응답

    public const ushort SSReq_TOTChampionShipPointAdd = 319;            // [GS->RS] [서버] TOT 챔피언쉽 포인트 추가 요청

    public const ushort SSNotify_TOTChampionShipInfoRefresh = 320;      // [GS->RS] [서버] TOT 챔피언쉽 정보 갱신하라고 공지
    public const ushort SSReq_UserTOTChampionShipInfoRefresh = 321;     // [GS->DS] [서버] 유저 TOT 챔피언쉽 정보 갱신 요청
    public const ushort SSRes_UserTOTChampionShipInfoRefresh = 322;     // [DS->GS] [서버] 유저 TOT 챔피언쉽 정보 갱신 요청 응답
    public const ushort SCNotify_UserTOTChampionShipInfoUpdate = 323;   // [S->C] [로비] 유저 TOT 챔피언쉽 업데이트 공지
    public const ushort CSReq_UserTOTChampionShipRewardAcquire = 324;	// [C->S] [로비] 유저 TOT 랭크 보상 획득 요청
    public const ushort SCRes_UserTOTChampionShipRewardAcquire = 325;   // [S->C] [로비] 유저 TOT 랭크 보상 획득 요청 응답

    public const ushort SSNotify_TOTRankInfoRefresh = 326;              // [GS->RS] [서버] TOT 랭크 정보 갱신하라고 공지
    public const ushort SSReq_UserTOTRankInfoRefresh = 327;             // [GS->DS] [서버] 유저 TOT 랭크 정보 갱신 요청
    public const ushort SSRes_UserTOTRankInfoRefresh = 328;             // [DS->GS] [서버] 유저 TOT 랭크 정보 갱신 요청 응답
    public const ushort SCNotify_UserTOTRankInfoUpdate = 329;           // [S->C] [로비] 유저 TOT 랭크 업데이트 공지
    public const ushort CSReq_UserTOTRankRewardAcquire = 330;			// [C->S] [로비] 유저 TOT 랭크 보상 획득 요청
    public const ushort SCRes_UserTOTRankRewardAcquire = 331;           // [S->C] [로비] 유저 TOT 랭크 보상 획득 요청 응답

    public const ushort CSReq_TOTChampionShipBuyIn = 332;               // [S->C] [로비] 유저 TOT 챔피언쉽 BuyIn 요청
    public const ushort SCRes_TOTChampionShipBuyIn = 333;               // [S->C] [로비] 유저 TOT 챔피언쉽 BuyIn 요청 응답
    public const ushort CSReq_AccumulateLuckyPointInfo = 334;			// [C->S] [로비] 누적 럭키포인트 정보 요청
    public const ushort SCRes_AccumulateLuckyPointInfo = 335;			// [C->S] [로비] 누적 럭키포인트 정보 요청 응답


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 슬롯머신
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public const ushort CSReq_SlotMachineJackPotPoint = 400;           // [C->S] [로비] 슬롯 머신 잭팟 점수 요청
    public const ushort SCRes_SlotMachineJackPotPoint = 401;           // [S->C] [로비] 슬롯 머신 잭팟 점수 요청 응답
    public const ushort CSReq_SlotMachinePlay = 402;                   // [C->S] [로비] 슬롯 머신 플레이 요청
    public const ushort SCRes_SlotMachinePlay = 403;                   // [S->C] [로비] 슬롯 머신 플레이 요청 응답
    public const ushort CSReq_SlotMachinePlayReward = 404;             // [C->S] [로비] 슬롯 머신 플레이 보상 요청
    public const ushort SCRes_SlotMachinePlayReward = 405;             // [S->C] [로비] 슬롯 머신 플레이 보상 요청 응답
    public const ushort SCRes_SlotMachineAttendancePlay = 406;         // [S->C] [로비] 슬롯 머신 출석 플레이 요청 응답
    public const ushort SSReq_SlotMachineCalcJackPotPoint = 407;       // [S->S] [로비] 슬롯 머신 잿팟 포인트 계산 요청
    public const ushort SSNotify_SlotMachineJackPotPoint = 408;        // [S->C] [로비] 슬롯 머신 잿팟 포인트 공지
    public const ushort SSReq_DailySlotMachineUpdate = 409;            // [S->S] [로비] 일일(출석) 슬롯 머신 정보 업데이트 요청
    public const ushort SCRes_SlotMachineRoulettePlay = 411;           // [S->C] [로비] 슬롯 머신 룰렛 플레이 요청 응답
    public const ushort CSReq_SlotMachineRoulettePlayReward = 412;     // [C->S] [로비] 슬롯 머신 룰렛 플레이 보상 요청
    public const ushort SCRes_SlotMachineRoulettePlayReward = 413;     // [S->C] [로비] 슬롯 머신 룰렛 플레이 보상 요청 응답


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 아이템&상점 
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public const ushort CSReq_InventoryInfo = 500;			            // [C->S] [아이템] 인벤토리 정보 요청
    public const ushort SCRes_InventoryInfo = 501;                      // [S->C] [아이템] 인벤토리 정보 요청 응답
    public const ushort CSReq_ItemEquip = 502;			                // [C->S] [아이템] 아이템 장착 요청
    public const ushort SCRes_ItemEquip = 503;			                // [S->C] [아이템] 아이템 장착 요청 응답
    public const ushort CSReq_ItemUnEquip = 504;			            // [C->S] [아이템] 아이템 장착 해제 요청
    public const ushort SCRes_ItemUnEquip = 505;			            // [S->C] [아이템] 아이템 장착 해제 요청 응답
    public const ushort CSReq_ItemSell = 506;			                // [C->S] [아이템] 아이템 판매 요청
    public const ushort SCRes_ItemSell = 507;			                // [S->C] [아이템] 아이템 판매 요청 응답
    public const ushort CSReq_ItemSafeUse = 508;			            // [C->S] [아이템] 아이템 금고 사용 요청
    public const ushort SCRes_ItemSafeUse = 509;                        // [S->C] [아이템] 아이템 금고 사용 요청 응답
    public const ushort CSReq_ItemUse = 510;			                // [C->S] [아이템] 아이템 사용 요청
    public const ushort SCRes_ItemUse = 511;                            // [S->C] [아이템] 아이템 사용 요청 응답
    public const ushort CSReq_ItemPieceCraft = 512;			            // [C->S] [아이템] 아이템 조각 제작 요청
    public const ushort SCRes_ItemPieceCraft = 513;                     // [S->C] [아이템] 아이템 조각 제작 요청 응답

    public const ushort CSReq_ShopItemBuy = 514;			            // [C->S] [상점] 상점 아이템 구매 요청
    public const ushort SCRes_ShopItemBuy = 515;                        // [S->C] [상점] 상점 아이템 구매 요청 응답
    public const ushort CSReq_ShopGachaBuy = 516;			            // [C->S] [상점] 상점 가차 구매 요청
    public const ushort SCRes_ShopGachaBuy = 517;                       // [S->C] [상점] 상점 가차 구매 요청 응답

    public const ushort CSReq_ItemMultiAutoUseTicketUse = 518;			// [C->S] [아이템] 멀리&오토 사용 티켓 사용 요청
    public const ushort SCRes_ItemMultiAutoUseTicketUse = 519;          // [S->C] [아이템] 멀리&오토 사용 티켓 사용 요청 응답

    public const ushort SSReq_UserLimitProductInfoUpdate = 520;         // [GS->DS] 유저 제한 상품 정보 업데이트 요청
    public const ushort CSReq_UserLimitProductInfoList = 521;           // [GS->DS] 유저 제한 상품 정보 리스트 요청
    public const ushort SCRes_UserLimitProductInfoList = 522;           // [GS->DS] 유저 제한 상품 정보 리스트 요청 응답
    public const ushort SCNotify_UserLimitProductInfo = 523;            // [GS->DS] 유저 제한 상품 정보 공지


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 우편
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public const ushort CSReq_PostBoxInfo = 600;			            // [C->S] [우편] 우체통 정보 요청
    public const ushort SCRes_PostBoxInfo = 601;                        // [S->C] [우편] 우체통 정보 요청 응답
    public const ushort CSReq_PostItemAcquire = 602;			        // [C->S] [우편] 우편 아이템 획득 요청
    public const ushort SCRes_PostItemAcquire = 603;                    // [S->C] [우편] 우편 아이템 획득 요청 응답
    public const ushort SCNotify_PostNewAdd = 604;                      // [S->C] [우편] 우편 새로 추가 공지
    public const ushort CSReq_PostRemove = 605;			                // [C->S] [우편] 우편 삭제 요청
    public const ushort SCRes_PostRemove = 606;                         // [S->C] [우편] 우편 삭제 요청 응답
    public const ushort SSReq_PostRefresh = 607;                        // [GS->DS] [서버] 유저 우편 정보 갱신 요청
    public const ushort SSRes_PostRefresh = 608;                        // [DS->GS] [서버] 유저 우편 정보 갱신 요청 응답
    public const ushort CSReq_PostRead = 609; 			                // [C->S] [우편] 우편 삭제 요청
    public const ushort SCRes_PostRead = 610;                           // [S->C] [우편] 우편 삭제 요청 응답
    

    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 금고
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public const ushort CSReq_SafeDeposit = 700;			            // [C->S] [금고] 금고 예금 요청
    public const ushort SCRes_SafeDeposit = 701;			            // [S->C] [금고] 금고 예금 요청 응답
    public const ushort CSReq_SafeWithdraw = 702;			            // [C->S] [금고] 금고 출금 요청
    public const ushort SCRes_SafeWithdraw = 703;                       // [S->C] [금고] 금고 출금 요청 응답
    public const ushort SCNotify_SafeBuyInOutInfo = 704;                // [S->C] [금고] 금고 Buy In/Out 정보 공지
    public const ushort CSReq_SafeBuyInSameChipBefore = 705;		    // [C->S] [금고] 금고 이전과 같은 칩 Buy In 요청
    public const ushort SCRes_SafeBuyInSameChipBefore = 706;            // [S->C] [금고] 금고 이전과 같은 칩 Buy In 요청 응답

    public const ushort SCNotify_LuckyPointBuyInOutInfo = 707;          // [S->C] [금고] 럭키포인트 Buy In/Out 정보 공지

    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 친구
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public const ushort CSReq_FriendList = 800;			                // [C->S] [친구] 친구 리스트 요청
    public const ushort SCRes_FriendList = 801;			                // [S->C] [친구] 친구 리스트 요청 응답
    public const ushort CSReq_FriendRequest = 801;			            // [C->S] [친구] 친구 요청
    public const ushort SCRes_FriendRequest = 802;			            // [S->C] [친구] 친구 요청 응답
    public const ushort SCNotify_FriendRequest = 803;			        // [S->C] [친구] 친구 요청 공지
    public const ushort CSReq_FriendRequestList = 804;			        // [C->S] [친구] 친구 요청 리스트 요청
    public const ushort SCRes_FriendRequestList = 805;			        // [S->C] [친구] 친구 요청 리스트 요청 응답
    public const ushort CSReq_FriendRequestAccept = 806;			    // [C->S] [친구] 친구 요청 수락 여부 요청
    public const ushort SCRes_FriendRequestAccept = 807;			    // [S->C] [친구] 친구 요청 수락 여부 요청 응답
    public const ushort SCNotify_FriendAdd = 808;			            // [S->C] [친구] 친구 추가 공지
    public const ushort CSReq_FriendRemove = 809;			            // [C->S] [친구] 친구 제거 요청
    public const ushort SCRes_FriendRemove = 810;			            // [S->C] [친구] 친구 제거 요청 응답
    public const ushort SCNotify_FriendRemove = 811;			        // [S->C] [친구] 친구 제거 공지
    public const ushort CSNotify_UserStateInfo = 812;			        // [S->C] [친구] 유저 상태정보 알림
    public const ushort CSReq_FriendUserStateInfoList = 813;		    // [C->S] [친구] 친구 유저 상태정보 리스트 요청
    public const ushort SCRes_FriendUserStateInfoList = 814;		    // [S->C] [친구] 친구 유저 상태정보 리스트 요청 응답
    public const ushort SCNotify_FriendLogin = 815;			            // [S->C] [친구] 친구 로그인 공지
    public const ushort CSReq_FriendSync = 816;			                // [C->S] [친구] 친구 싱크 맞추기 요청
    public const ushort SCRes_FriendSync = 817;			                // [S->C] [친구] 친구 싱크 맞추기 요청 응답
    public const ushort CSReq_FriendSendGift = 818;			            // [C->S] [친구] 친구 선물 보내기 요청
    public const ushort SCRes_FriendSendGift = 819;			            // [S->C] [친구] 친구 선물 보내기 요청 응답
    public const ushort CSReq_FriendInviteInfo = 820;			        // [C->S] [친구] 친구 초대 정보 요청
    public const ushort SCRes_FriendInviteInfo = 821;			        // [S->C] [친구] 친구 초대 정보 요청 응답
    public const ushort CSReq_FriendRecommend = 822;			        // [C->S] [친구] 친구 추천 요청
    public const ushort SCRes_FriendRecommend = 823;			        // [S->C] [친구] 친구 추천 요청 응답
    public const ushort CSReq_FriendInviteRewardAcquire = 824;		    // [C->C] [친구] 친구 초대 보상 획득 요청
    public const ushort SCRes_FriendInviteRewardAcquire = 825;		    // [S->C] [친구] 친구 초대 보상 획득 요청 응답
    public const ushort CSReq_FriendTalk = 826;			                // [C->S] [친구] 친구 초대 채팅 요청
    public const ushort SCRes_FriendTalk = 827;			                // [S->C] [친구] 친구 초대 채팅 요청 응답
    public const ushort SCNotify_FriendTalk = 828;			            // [S->C] [친구] 친구 초대 채팅 요청 공지
    public const ushort CSReq_FriendPrivateRoomInvite = 829;		    // [C->S] [친구] 친구 비밀방 초대 요청
    public const ushort SCRes_FriendPrivateRoomInvite = 830;		    // [S->C] [친구] 친구 비밀방 초대 요청 응답
    public const ushort SCNotify_FriendPrivateRoomInvite = 831;		    // [S->C] [친구] 친구 비밀방 초대 요청 공지
    public const ushort SCNotify_FriendInviteTotalCount = 832;			// [S->C] [친구] 친구 총 초대 수 공지


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 유저 정보 저장
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public const ushort SSReq_SaveUserSafeChipInfo = 900;               // [GS->DS] 유저 금고정보 저장 요청
    public const ushort SSReq_SaveUserInventoryInfo = 901;              // [GS->DS] 유저 인벤토리정보 저장 요청
    public const ushort SSReq_SaveUserPostBoxInfo = 902;                // [GS->DS] 유저 우편함 정보 저장 요청
    public const ushort SSReq_SaveUserPostRead = 903;                   // [GS->DS] 유저 우편 읽음 저장 요청
    public const ushort SSReq_SaveUserDiamondInfo = 904;                // [GS->DS] 유저 다이아몬드 저장 요청
    public const ushort SSReq_SaveUserLuckyPoint = 905;                 // [GS->DS] 유저 럭키포인트 저장 요청
    public const ushort SSReq_SaveUserResearchInfo = 906;               // [GS->DS] 유저 리서치정보 저장 요청
    
    public const ushort SSReq_SaveUserTOTRankRewardAcquire = 908;       // [GS->DS] 유저 리그 보상획득 저장 요청
    public const ushort SSReq_SaveUserTOTChampionShipRewardAcquire = 909; // [GS->DS] 유저 리그 보상획득 저장 요청

    public const ushort SSReq_SaveUserDailyRewardInfo = 910;            // [GS->DS] 유저 하루보상 정보 저장 요청
    public const ushort SSReq_SaveUserTutorialRewardReceive = 911;      // [GS->DS] 유저 튜토리얼 보상 받음 저장 요청
    public const ushort SSReq_SaveUserAttendanceInfo = 912;             // [GS->DS] 유저 출석정보 저장 요청
    public const ushort SSReq_SaveUserInfo = 913;                       // [GS->DS] 유저 정보 저장 요청
    public const ushort SSReq_SaveUserVIPInfo = 914;                    // [GS->DS] 유저 VIP정보 저장 요청
    public const ushort SSReq_SaveUserMultiSlotInfo = 915;              // [GS->DS] 유저 멀티 정보 저장 요청
    public const ushort SSReq_SaveUserGaneshaPocketInfo = 916;          // [GS->DS] 유저 가네샤 주머니 정보 저장 요청
    public const ushort SSReq_SaveUserRouletteInfo = 917;               // [GS->DS] 유저 룰렛 정보 저장 요청


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 결제
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public const ushort CSReq_PaymentId = 1000;                         // [C->S] 결제 아이디 발급 요청
    public const ushort SCRes_PaymentId = 1001;                         // [S->C] 결제 아이디 발급 요청 응답
    public const ushort SSReq_AddPaymentInfo = 1002;                    // [GS->DS] 결제 정보 추가 요청
    public const ushort SSReq_SavePaymentInfo = 1003;                   // [GS->DS] 결제 정보 저장 요청
    public const ushort SSReq_VerifyPaymentInfo = 1004;                 // [GS->DS] 결제 확인 요청 (확인하려고 하니 유저가 없을때 DB로 요청)
    public const ushort CSReq_PaymentVerify = 1005;                     // [C->S] 결제 확인 요청
    public const ushort SCRes_PaymentVerify = 1006;                     // [S->C] 결제 확인 요청 응답
    public const ushort SCNotify_PaymentVerifyNonGiveGoods = 1007;      // [S->C] 결제 확인 되었지만 미지급된 상품 지급 공지
    public const ushort CSReq_PaymentCancel = 1008;                     // [C->S] 결제 취소 요청
    public const ushort SSReq_PaymentCancel = 1009;                     // [S->S] 결제 취소 요청


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 미션
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public const ushort CSReq_MissionList = 1100;                       // [C->S] 미션 리스트 요청
    public const ushort SCRes_MissionList = 1101;                       // [S->C] 미션 리스트 요청 응답
    public const ushort CSReq_MissionRewardAcquire = 1102;              // [C->S] 미션 보상 획득 요청
    public const ushort SCRes_MissionRewardAcquire = 1103;              // [C->S] 미션 보상 획득 요청 응답
    public const ushort SSReq_MissionInfoUpdate = 1110;                 // [S->S] 미션 업데이트 요청 
    public const ushort SCNotify_MissionInfoUpdate = 1111;              // [S->C] 미션 업데이트 공지
    public const ushort CSReq_MissionRefresh = 1112;                    // [C->S] 유저 미션 갱신 요청(유저가 요청)
    public const ushort SSReq_MissionResetAll = 1150;                   // [S->S] 미션 모두 리셋 요청(치트)

    public const ushort CSReq_ShareRewardInfo = 1160;                   // [C->S] 공유 보상 정보 요청
    public const ushort SCRes_ShareRewardInfo = 1161;                   // [S->C] 공유 보상 정보 요청 응답
    public const ushort CSReq_ShareRewardAcquire = 1162;                // [C->S] 공유 보상 획득 요청
    public const ushort SCRes_ShareRewardAcquire = 1163;                // [S->C] 공유 보상 획득 요청 응답
    public const ushort SSReq_ShareRewardInfoUpdate = 1164;               // [S->S] 공유 보상 정보 저장 요청


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 멀티 정보
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public const ushort SCNotify_VipInfo = 1200;                        // [S->C] [VIP] 정보 공지
    public const ushort SCNotify_MultiSlotInfo = 1201;                   // [S->C] [멀티] 멀티 정보 공지 


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 튜토리얼
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public const ushort SSReq_TutorialInfoUpdate = 1300;                    // [S->S] 튜토리얼 업데이트 요청 
    public const ushort SSReq_TutorialCountUpdate = 1301;                   // [S->S] 튜토리얼 카운트 업데이트 요청 
    public const ushort SSReq_TutorialCompleteUpdate = 1302;                // [S->S] 튜토리얼 완료 업데이트 요청 
    public const ushort SCNotify_TutorialBaseEnableComplete = 1303;         // [S->C] 튜토리얼 베이스 완료 가능 공지
    public const ushort SCNotify_TutorialGaneshaEnableComplete = 1304;      // [S->C] 튜토리얼 가네샤 완료 가능 공지
    public const ushort CSReq_TutorialCompleteInfo = 1305;                  // [C->S] 튜토리얼 완료 정보 요청
    public const ushort SCRes_TutorialCompleteInfo = 1306;                  // [S->C] 튜토리얼 완료 정보 요청 응답
    public const ushort CSReq_TutorialBaseRewardAcquire = 1307;             // [C->S] 튜토리얼 베이스 보상 요청
    public const ushort SCRes_TutorialBaseRewardAcquire = 1308;             // [S->C] 튜토리얼 베이스 보상 요청 응답
    public const ushort CSReq_TutorialGaneshaRewardAcquire = 1309;          // [C->S] 튜토리얼 가네샤 보상 요청
    public const ushort SCRes_TutorialGaneshaRewardAcquire = 1310;          // [S->C] 튜토리얼 가네샤 보상 요청 응답
    public const ushort SSReq_TutorialAllClearUpdate = 1311;                // [S->S] 튜토리얼 올클리어 업데이트 요청


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 광고
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public const ushort CSReq_ADRewardAcquire = 1400;                       // [C->S] 광고 보상 요청 
    public const ushort SCRes_ADRewardAcquire = 1401;                       // [S->C] 광고 보상 요청 응답
    public const ushort SSReq_ADRewardInfoUpdate = 1402;                    // [GS->DS] 유저 광고 보상 업데이트 요청


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 칩부족
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public const ushort CSReq_EmptyChipRewardAcquire = 1500;		        // [C->S] 유저 부족칩 보상 응답
    public const ushort SCRes_EmptyChipRewardAcquire = 1501;		        // [S->C] 유저 부족칩 보상 요청
    public const ushort SSReq_EmptyChipRewardInfoUpdate = 1502;             // [GS->DS] 유저 광고 보상 업데이트 요청
    public const ushort CSReq_EmptyChipDoubleRewardAcquire = 1503;		    // [C->S] 유저 부족칩 더블 보상 요청


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // PayTM
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public const ushort CSReq_PayTMInfoRegister = 1600;                     // [C->S] PayTM 정보 등록 요청
    public const ushort SCRes_PayTMInfoRegister = 1601;                     // [S->C] PayTM 정보 등록 요청 응답
    public const ushort SSReq_PayTMInfoSave = 1602;                         // [C->S] PayTM 정보 저장 요청
    public const ushort CSReq_PayTMExchange = 1603;                         // [C->S] PayTM 환전 요청
    public const ushort SCRes_PayTMExchange = 1604;                         // [S->C] PayTM 환전 요청 응답
    public const ushort SSReq_SavePayTMExchangeRequestInfo = 1605;          // [GS->DS] PayTM 환전 요청 정보 저장 요청
    public const ushort SSReq_SavePayTMExchangeResultInfo = 1606;           // [GS->DS] PayTM 환전 결과 정보 저장 요청
    public const ushort CSReq_PayTMOTPMessageSend = 1607;                   // [C->S] PayTM OTP 문자 전송 요청
    public const ushort SCReq_PayTMOTPMessageSend = 1608;                   // [S->C] PayTM OTP 문자 전송 요청 응답
    public const ushort CSReq_PayTMOTPMessageResend = 1609;                 // [C->S] PayTM OTP 문자 재전송 요청
    public const ushort SCReq_PayTMOTPMessageResend = 1610;                 // [S->C] PayTM OTP 문자 재전송 요청 응답
    public const ushort CSReq_PayTMPhoneNumberChange = 1611;                // [C->S] PayTM 폰번호 변경 요청
    public const ushort SCRes_PayTMPhoneNumberChange = 1612;                // [S->C] PayTM 폰번호 변경 응답
    public const ushort CSReq_PayTMPasswordChange = 1613;                   // [C->S] PayTM 비밀번호 변경 요청
    public const ushort SCRes_PayTMPasswordChange = 1614;                   // [S->C] PayTM 비밀번호 변경 응답
    public const ushort SSReq_PayTMLastUseRewardDataIdSave = 1615;          // [C->S] PayTM 마지막 교환 RewardDataId 저장 요청
    public const ushort SSReq_PayTMExchangeCheckINR = 1616;                 // [S->S] PayTM 환전 가능한지 확인 요청
    public const ushort SSRes_PayTMExchangeCheckINR = 1617;                 // [S->S] PayTM 환전 가능한지 확인 요청 응답
    public const ushort SSReq_PayTMExchangeINR = 1618;                      // [S->S] PayTM 환전 INR 차감 요청
    public const ushort CSReq_PayTMUseAgreement = 1619;                     // [C->S] PayTM 사용 동의
    public const ushort SCRes_PayTMUseAgreement = 1620;                     // [S->C] PayTM 사용 동의
    public const ushort SSReq_PayTMUseAgreementSave = 1621;                 // [S->S] PayTM 사용 동의 저장 요청

    public const ushort SSReq_PayTMINRHaveAdd = 1622;                       // [S->S] PayTM INR 보유 추가 요청
    public const ushort SSReq_PayTMINRLimitUpdate = 1623;                   // [S->S] PayTM INR 제한 업데이트 요청

    public const ushort CSReq_PayTMShareRewardAcquire = 1624;               // [C->S] PayTM 공유 보상 요청
    public const ushort SCRes_PayTMShareRewardAcquire = 1625;               // [S->C] PayTM 공유 보상 요청 요청
    public const ushort SSReq_PayTMPhoneNumberExists = 1626;                // [S->S] PayTM 폰번호 확인 요청
    public const ushort SSRes_PayTMPhoneNumberExists = 1627;                // [S->S] PayTM 폰번호 확인 요청 응답


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // Event
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public const ushort SSReq_EventInfo = 1700;                             // [S->S] 이벤트 정보 요청
    public const ushort SSRes_EventInfo = 1701;                             // [S->S] 이벤트 정보 요청 응답

    public const ushort SSReq_UserEventInfoUpdate = 1702;                   // [S->S] 유저 이벤트 정보 업데이트 요청
    public const ushort SSNotify_UserAllInEventClear = 1703;                // [S->C] 유저 이벤트 올인 이벤트 클리어 공지


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // HighOrLow
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    //public const ushort CSReq_HighOrLowGamePlay = 1700;                 // [C->S] HighOrLow 게임 플레이 요청
    //public const ushort SCRes_HighOrLowGamePlay = 1701;                 // [S->C] HighOrLow 게임 플레이 요청 응답


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // Buff
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public const ushort CSReq_BuffInfoList = 1801;                          // [C->S] 버프 리스트 요청
    public const ushort SCRes_BuffInfoList = 1802;                          // [C->S] 버프 리스트 요청 응답
    public const ushort SCNotify_BuffUpdate = 1803;                         // [S->S] 버프 업데이트 공지


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 기타 9000 ~
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public const ushort CSReq_DebugWriteLine = 9000;                    // [C->S] [디버깅] 디버깅 용도

    public const ushort CSReq_DebugCommand = 9001;                      // [C->S] [디버깅] 디버깅 명령 요청(치트키 같은)
    public const ushort SCRes_DebugCommand = 9002;                      // [S->C] [디버깅] 디버깅 명령 응답(치트키 같은)

    public const ushort CSReq_LogSave = 9003;                           // [C->S] 로그 저장 요청

    public const ushort CSReq_Ping = 9004;                              // [C->S] 핑 요청
    public const ushort SCRes_Pong = 9005;                              // [S->C] 퐁 응답

    public const ushort CSReq_ReconnectionInfo = 9006;                  // [C->S] 재연결 정보 요청
    public const ushort SCRes_ReconnectionInfo = 9007;                  // [S->C] 재연결 정보 응답

    public const ushort CSSReq_Certification = 9008;                    // [CS->S] [서버] 네트워크 타입 인증 요청(클라인지 서버인지)
    public const ushort SCSRes_Certification = 9009;                    // [S->CS] [서버] 네트워크 타입 인증 응답(클라인지 서버인지)

    public const ushort SSNoti_GameServerInfo = 9010;                   // [GS->LS] [서버] 게임서버 정보 알림
    public const ushort SSNoti_GameServerChannelInfo = 9011;            // [GS->LS] [서버] 게임서버 채널 정보 알림

    public const ushort SSNotify_UserLogin = 9012;                      // [S->S] [서버] 유저 로그인 됨 알림
    public const ushort SSNotify_UserDisconnect = 9013;                 // [S->S] [서버] 유저 연결 끊으라고 알림
    public const ushort SSNotify_UserConnectInfo = 9014;                // [S->S] [서버] 비상시 게임서버와 로그인 서버거 끊어젔다가 재연결됬을떄 게임서버 유저정보를 알림

    public const ushort CSReq_LatancyLogin = 9015;                      // [C->S] 레이턴시 로그인
    public const ushort CSReq_LatancyLogout = 9016;                     // [C->S] 레이턴시 로그아웃
    public const ushort SCReq_LatancyPacket = 9017;                     // [S->C] 레이턴시 패킷 요청
    public const ushort CSRes_LatancyPacket = 9018;                     // [C->S] 레이턴시 패킷 응답

    public const ushort SSReq_BBSNoticeInfoList = 9019;                 // [S->DS] 공지 정보 요청
    public const ushort SSRes_BBSNoticeInfoList = 9020;                 // [DS->S] 공지 정보 요청 응답
    public const ushort SCNotify_BBSNoticeInfo = 9021;                  // [S->C] 공지 정보 공지
    public const ushort SSReq_BBSNoticeBoardInfoList = 9022;            // [S->DS] 공지 게시판 정보 요청
    public const ushort SSRes_BBSNoticeBoardInfoList = 9023;            // [DS->S] 공지 게시판 정보 요청 응답
    public const ushort SSReq_PostManagementInfoList = 9024;            // [S->DS] 우편 관리 정보 요청
    public const ushort SSRes_PostManagementInfoList = 9025;            // [DS->S] 우편 관리 정보 요청 응답
    public const ushort SSReq_PostManagementActiveSend = 9026;          // [S->DS] 우편 관리 우편 발송 요청
    public const ushort SSRes_PostManagementActiveSend = 9027;          // [DS->S] 우편 관리 우편 발송 요청 응답

    public const ushort SSNotify_ChannelGameModeInfoRefresh = 9028;     // [SS->GS] [서버] 채널 업데이트 하라고 공지
    public const ushort SSReq_ChannelGameModeInfoList = 9029;           // [GS->DS] [서버] 채널 게임 모드 정보 요청
    public const ushort SSRes_ChannelGameModeInfoList = 9030;           // [DS->GS] [서버] 채널 게임 모드 정보 요청 응답

    public const ushort SSNotify_ContentLockInfoUpdate = 9031;          // [SS->GS] [서버] 컨텐츠 잠금 정보 업데이트 하라고 공지
    public const ushort SSReq_ContentLockInfo = 9032;                   // [GS->DS] [서버] 컨텐츠 잠금 정보 요청
    public const ushort SSRes_ContentLockInfo = 9033;                   // [DS->GS] [서버] 컨텐츠 잠금 정보 요청 응답

    public const ushort SSReq_ServerAdminMACAddressList = 9034;         // [LS->DS] 서버 관리자 맥주소 리스트 요청
    public const ushort SSRes_ServerAdminMACAddressList = 9035;         // [DS->LS] 서버 관리자 맥주소 리스트 요청 응답
    public const ushort SSReq_ServerCheckString = 9036;                 // [LS->DS] 서버 점검 문자 요청
    public const ushort SSRes_ServerCheckString = 9037;                 // [DS->LS] 서버 점검 문자 요청 응답

    public const ushort SSReq_BBSBannerInfoList = 9038;                 // [S->DS] 배너 정보 요청
    public const ushort SSRes_BBSBannerInfoList = 9039;                 // [DS->S] 배너 정보 요청 응답

    public const ushort SSReq_ActiveGameServerGroupInfo = 9040;         // [GS->LS] 활설화 게임 서버 그룹 정보 요청
    public const ushort SSRes_ActiveGameServerGroupInfo = 9041;         // [LS->GS] 활설화 게임 서버 그룹 정보 요청 응답

    public const ushort SSReq_ServerVersionInfo = 9042;                 // [LS->DS] 서버 버전 정보 요청
    public const ushort SSRes_ServerVersionInfo = 9043;                 // [DS->LS] 서버 버전 정보 요청 응답

    //public const ushort SSReq_HighOrLowGameResultRateInfo = 9044;       // [GS->DS] [서버] High or Low 게임 결과 확률 정보 요청
    //public const ushort SSRes_HighOrLowGameResultRateInfo = 9045;       // [DS->GS] [서버] High or Low 게임 결과 확률 정보 요청 응답
}