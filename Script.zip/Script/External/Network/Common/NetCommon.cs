using UnityEngine;
using System;
using System.Collections;

public class NetCommon 
{
    private static NetCommon _instance = new NetCommon();
    public static NetCommon instance
    {
        get { return _instance; }
    }

	//public NamedAddrPort _entryAddr = new NamedAddrPort();
	//public Guid _entryVersion = new Guid("{C6270932-FA17-4377-BF75-00996B9F7748}");

    NetCommon()
    {
        //_entryAddr.addr = "1.234.45.236";
        //_entryAddr.addr = "110.11.248.66";
        //_entryAddr.port = 55100; //- refactoring server
        //_entryVersion = new Guid("{FCFBA3DD-B9B2-4B60-9DBD-D8577B55FC4F}");             //ver 1.0
        //_entryVersion = new Guid("{E764E2D5-70D0-4ACD-85B2-2C464C5A4EE9}");             //ver 1.1
        //_entryVersion = new Guid("{9D874EB4-50F0-49BF-B3F0-7ABE9F8F2D1B}");           //ver 1.2
        //_entryVersion = new Guid("{59D8870A-54EC-4019-9DBF-08CD391A5D6F}");              //ver 2.0
        //_entryVersion = new Guid("{7CA8CDD2-C287-4569-9D26-A6A5F11F0C10}");              //ver 2.2
        //_entryVersion = new Guid("{F3EBBDA5-2F41-44CC-BE34-1A65D26DE722}");              //ver 2.3
    }
}
