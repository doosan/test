using System;
using System.Collections.Generic;
using Lidgren.Network;
using UnityEngine;



//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// JNetPeer
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++e
public enum ePeerType
{
    LoginPeer,
    GamePeer,
    //RankPeer,
    AllPeer
}

public class ConnectPeerPack
{
    public NetPeer _peer = null;
    public Dictionary<int, Action<NetIncomingMessage>> _messageHandlers = new Dictionary<int, Action<NetIncomingMessage>>();

    public event Action<NetConnection> Connected = null;
    public event Action<NetConnection, string> Disconnected = null;

    public long _messageIndex;

    public void EventConnected(NetConnection c)
    {
        if (Connected != null)
            Connected(c);
    }

    public void EventDisconnected(NetConnection c, string reason)
    {
        if (Disconnected != null)
            Disconnected(c, reason);
    }
}


public class JNetPeer : MonoBehaviour
{
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // ����	
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region ����

    protected Dictionary<ePeerType, ConnectPeerPack> _peerPackList = new Dictionary<ePeerType, ConnectPeerPack>();

    protected Dictionary<string, Action<NetIncomingMessage>> _simpleMessageHandlers = new Dictionary<string, Action<NetIncomingMessage>>();

    #endregion

    #region ������Ƽ

    #endregion

    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // �޽��� �ڵ鷯
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region �޽��� �ڵ鷯
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    protected void ReadMessages()
    {
        foreach (var peer in _peerPackList.Values)
        {
            ReadPeerMessage(peer);
        }
    }

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    protected void ReadPeerMessage(ConnectPeerPack peerPack)
    {
        if (peerPack._peer != null)
        {
            NetIncomingMessage msg;

            while ((msg = peerPack._peer.ReadMessage()) != null)
            {
                switch (msg.MessageType)
                {
                    case NetIncomingMessageType.Data:
                        //var encryption = new NetAESEncryption(peerPack._peer, "temp24qw");
                        //msg.Decrypt(encryption);
                        ushort messageId = msg.ReadUInt16();
                        Action<NetIncomingMessage> handler = null;

                        if (peerPack._messageHandlers.TryGetValue(messageId, out handler))
                        {
                            handler(msg);
                        }
                        else
                        {
                            Debug.LogWarning("No handler for message id " + messageId);
                        }

                        break;

                    case NetIncomingMessageType.StatusChanged:
                        switch (msg.SenderConnection.Status)
                        {
                            case NetConnectionStatus.Connected:
                                peerPack.EventConnected(msg.SenderConnection);
                                break;

                            case NetConnectionStatus.Disconnected:
                                NetConnectionStatus status = (NetConnectionStatus)msg.ReadByte();
                                string reason = msg.ReadString();
                                
                                peerPack.EventDisconnected(msg.SenderConnection, reason);
                                break;
                        }

                        Debug.Log("Status on " + msg.SenderConnection + " changed to " + msg.SenderConnection.Status);
                        break;

                    case NetIncomingMessageType.ErrorMessage:
                    case NetIncomingMessageType.DebugMessage:
                    case NetIncomingMessageType.WarningMessage:
                    case NetIncomingMessageType.VerboseDebugMessage:
                        Debug.Log("Lidgren: " + msg.ReadString());
                        break;

                }

                peerPack._peer.Recycle(msg);
            }
        }
    }

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    protected void ClearPeerMessage(ConnectPeerPack peerPack)
    {
        if (peerPack._peer != null)
        {
            NetIncomingMessage msg;

            while ((msg = peerPack._peer.ReadMessage()) != null)
            {
                peerPack._peer.Recycle(msg);
            }
        }
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // �⺻ ����
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region �⺻ ����

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    protected bool SetPeer(ePeerType peerType, ConnectPeerPack peerPack)
    {
        if (peerPack == null)
            return false;

        _peerPackList[peerType] = peerPack;

        return true;
    }

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public void RegisterMessageHandler(ePeerType peerType, ushort id, Action<NetIncomingMessage> message)
    {
        if (peerType == ePeerType.AllPeer)
        {
            foreach (var peerPack in _peerPackList.Values)
                peerPack._messageHandlers[id] = message;

            return;
        }

        if (!_peerPackList.ContainsKey(peerType))
            return;

        var messageHandlers = _peerPackList[peerType]._messageHandlers;

        if (messageHandlers.ContainsKey(id))
        {
            messageHandlers.Remove(id);
        }

        messageHandlers.Add(id, message);
    }

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public void RegisterMessageHandler<T>(ePeerType peerType, ushort id, Action<T> message)
        where T : AcNetData_base, new()
    {
        RegisterMessageHandler(peerType, id, (inMsg) =>
        {
            if (id == AcNetMessageHeaders.SCRes_Pong)
                return;

            if (inMsg.LengthBytes != 1)
            {
                T data = new T();

                try
                {
                    data.Parse(inMsg);
                }
                catch (System.Exception ex)
                {
                    Debug.LogWarning("Receive Wrong Data: " + ex);
                    return;
                }

                AcNetResultExecute.Instance.NetResultExecute(data._result);
                message(data);
            }
        });
    }

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    void FixedUpdate()
    {
        ReadMessages();
    }

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    void Update()
    {
        ReadMessages();
    }

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    void LateUpdate()
    {
        ReadMessages();
    }
    #endregion
}