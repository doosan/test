﻿using UnityEngine;
using System;
using System.Collections;
using System.Linq;
using System.Collections.Generic;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// AcGameBase
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

public enum eGameSceneState
{
    STATE_LOBBY,
    STATE_WAITINGROOM,
    STATE_ROOMGAMEWAIT,
    STATE_ROOMGAMEPLAY,
    STATE_ROOMGAMERESULT,
}

public class AcGameBase
{
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 변수
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    eGameType _gameType;
    eGameSceneState _gameSceneState;

    float _offsetX; // 멀티 플레이를 위한
    float _posX, _posY;

    List<AcNetData_RoomSimpleInfo> _roomList;
    long _enterRoomIndex;

    public long EnterRoomIndex { get { return _enterRoomIndex; } }
    public AcEnterRoomInfo EnterRoom { get { return AcUserInfo.GetEnterRoom(_enterRoomIndex); } }

    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 메인 함수
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 메인 함수

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public AcGameBase(float offsetX)
    {
        _offsetX = offsetX;
        _gameSceneState = eGameSceneState.STATE_LOBBY;
        _enterRoomIndex = 0;
    }


    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public void OnGUI()
    {
        switch (_gameSceneState)
        {
            case eGameSceneState.STATE_LOBBY:
                LobbyState();
                break;

            case eGameSceneState.STATE_WAITINGROOM:
                WaitingRoomState();
                break;

            case eGameSceneState.STATE_ROOMGAMEWAIT:
                RoomGameWaitState();
                break;

            case eGameSceneState.STATE_ROOMGAMEPLAY:
                RoomGamePlayState();
                break;

            case eGameSceneState.STATE_ROOMGAMERESULT:
                RoomGameResultState();
                break;
        }
    }

    #endregion

    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 상태 함수
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 상태 변경

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 상태 변경
    public virtual void ChangeState(eGameSceneState state)
    {
        _gameSceneState = state;
    }

    #endregion

    #region 로비 상태

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void LobbyState()
    {
        // 게임 선택
        if (GUI.Button(GetRect(10, 10, 150, 25), "클래식 모드"))
        {
            _gameType = eGameType.TYPE_CLASSIC;

            // 방리스트 요청
            AcNetFacade.Instance.SendPacket_req_roomList(_gameType, (res, roomList) =>
            {
                if (res == eGameResult.RESULT_OK)
                {
                    _roomList = roomList;
                    ChangeState(eGameSceneState.STATE_WAITINGROOM);
                }
            });
        }
    }

    #endregion

    #region 대기실 상태

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void WaitingRoomState()
    {
        // 방리스트 갱신
        if (GUI.Button(GetRect(10, 10, 150, 25), "방리스트 갱신"))
        {
            AcNetFacade.Instance.SendPacket_req_roomList(_gameType, (res, roomList) =>
            {
                if(res == eGameResult.RESULT_OK)
                {
                    _roomList = roomList;
                }
            });
        }

        // 방생성
        //if (GUI.Button(GetRect(170, 10, 150, 25), "방생성"))
        //{
        //    if(_gameType == eGameType.TYPE_CLASSIC)
        //    {
        //        AcNetFacade.Instance.SendPacket_req_roomCreate(0, "아무나 오셩~", _gameType, eRoomOpenType.TYPE_PUBLIC, "", eRoomGradeType.TYPE_BRONZE, 100, 6400, 102400, 9, 15, (res, roomIndex) =>
        //        {
        //            if (res == eGameResult.RESULT_OK)
        //            {
        //                _enterRoomIndex = roomIndex;
        //                ChangeState(eGameSceneState.STATE_ROOMGAMEWAIT);
        //            }
        //        });
        //    }
        //}

        // 방 빠른 입장
        if (GUI.Button(GetRect(170, 10, 150, 25), "방 빠른입장"))
        {
            AcNetFacade.Instance.SendPacket_req_roomQuickEnter(0, 10101, 0, 0, "", (res, roomIndex, recGameRoomDataId) =>
            {
                if (res == eGameResult.RESULT_OK)
                {
                    // 원래는 검색해서 해야함(테스트 클라 구조상 불가)
                    _enterRoomIndex = roomIndex;
                    ChangeState(eGameSceneState.STATE_ROOMGAMEWAIT);
                }
                else if (res == eGameResult.RESULT_NOTEXIST)
                {
                    // 방이 없음
                }
            });
        }

        // 방 리스트 정보
        if (_roomList == null || _roomList.Count == 0)
        {
            GUI.Label(GetRect(10, 45, 200, 25), "방 없음");
        }
        else
        {
            for (int i = 0; i < _roomList.Count; i++)
            {
                var roomStr = "";

                if (_gameType == eGameType.TYPE_CLASSIC)
                {
                    roomStr = string.Format("번호: {0}, 부트칩: {1} 최대배팅: {2}, 최대팟: {3} 인원: {4}/{5}", i, _roomList[i]._bootBalance, _roomList[i]._maxBettingChip, _roomList[i]._maxPot, _roomList[i]._curUserCount, _roomList[i]._maxUserCount);
                }

                if (GUI.Button(GetRect(10, 45 + i * 35, 600, 25), roomStr))
                {
                    // 비밀방일 경우 비번 입력해야함.. 테스트클라는 생략~!
                    AcNetFacade.Instance.SendPacket_req_roomEnter(_roomList[i]._roomIndex, 0, 0, (res, roomIndex) =>
                    {
                        if (res == eGameResult.RESULT_OK)
                        {
                            _enterRoomIndex = roomIndex;
                            ChangeState(eGameSceneState.STATE_ROOMGAMEWAIT);
                        }
                        else if (res == eGameResult.RESULT_ROOMENTER_WRONGPASSWORD)
                        {
                            // 비밀방 패스워드 틀림
                        }
                    });
                }
            }
        }
    }

    #endregion

    #region 룸 게임 대기 상태

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void RoomGameWaitState()
    {
        // 방 나가기
        if (GUI.Button(GetRect(10, setUIPosY(10), 150, 25), "방 나가기"))
        {
            Debug.Log("테스트 나가기 버튼 클릭");
            AcNetFacade.Instance.SendPacket_req_leaveRoom(_enterRoomIndex, (res, leaveRoomIndex, changeBalance, changeLP, changeBuffLP) =>
            {
                if (res == eGameResult.RESULT_OK)
                {
                    if (AcUserInfo._enterRoomDic.ContainsKey(leaveRoomIndex) == true)
                    {
                        AcUserInfo._enterRoomDic.Remove(leaveRoomIndex);
                        _enterRoomIndex = 0;
                        ChangeState(eGameSceneState.STATE_LOBBY);
                    }
                }
            });
        }

        // 방 착석에서 일어나기
        if (GUI.Button(GetRect(160, plusUIPosY(0), 150, 25), "일어나기"))
        {
            AcNetFacade.Instance.SendPacket_req_roomSlotStandUp(_enterRoomIndex, res =>
            {
                if (res == eGameResult.RESULT_OK)
                {
                    // 슬롯정보 공지가 날라옴
                }
            });
        }

        if (GUI.Button(GetRect(10, plusUIPosY(25), 70, 25), "감정테스트"))
        {
           // AcNetFacade.Instance.SendPacket_req_emotion(_enterRoomIndex, 0, "test");
        }

        var enterRoom = AcUserInfo.GetEnterRoom(_enterRoomIndex);
        if (enterRoom != null)
        {
            var slotList = enterRoom._netData_room._slotList;
            for (int i = 0; i < slotList.Count; i++)
            {
                // 슬롯정보
                GUI.Label(GetRect(10, plusUIPosY(25), 200, 25), string.Format("슬롯번호: {0}, 슬롯상태: {1}", i, slotList[i]._number, slotList[i]._state));
                if (slotList[i]._state == eRoomSlotState.STATE_WAIT || slotList[i]._state == eRoomSlotState.STATE_CLOSE)
                {
                    GUI.Label(GetRect(10, plusUIPosY(25), 200, 25), "유저 비어있음");
                }
                else
                {
                    GUI.Label(GetRect(10, plusUIPosY(25), 300, 25), string.Format("유저 ID: {0}, NickName: {1}, Chip: {2} ", slotList[i]._userInfo._userId, slotList[i]._userInfo._nickName, slotList[i]._userInfo._balance));
                }

                if (slotList[i]._state == eRoomSlotState.STATE_WAIT)
                {
                    // 착석하기
                    if (GUI.Button(GetRect(10, plusUIPosY(25), 200, 25), string.Format("슬롯{0}번 착석가능", slotList[i]._number)))
                    {
                        int selectSlotNumber = slotList[i]._number;
                        AcNetFacade.Instance.SendPacket_req_RoomSlotAttend(_enterRoomIndex, selectSlotNumber, (res, roomIndex) =>
                        {
                            // 변경된 슬롯정보는 NotifyRoomSlotInfo()이라는 함수에서 업데이트함
                            if (res == eGameResult.RESULT_OK)
                            {

                            }
                        });
                    }
                }
                else
                {
                    GUI.Button(GetRect(10, plusUIPosY(25), 200, 25), string.Format("슬롯{0}번 착석불가", slotList[i]._number));
                }
            }
        }
    }

    #endregion

    #region 룸 게임 플레이 상태

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void RoomGamePlayState()
    {
        
    }

    #endregion

    #region 룸 게임 결과 상태

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public virtual void RoomGameResultState()
    {
        
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 입장한 방 관리 함수
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 입장한 방 얻기

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public AcEnterRoomInfo GetEnterRoom()
    {
        return AcUserInfo.GetEnterRoom(_enterRoomIndex);
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 내부함수
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 내부함수

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 단순 UI좌표 편하게하기 위한 용도
    protected float setUIPosX(float setPosX)
    {
        _posX = setPosX;

        return _posX;
    }

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 단순 UI좌표 편하게하기 위한 용도
    protected float plusUIPosX(float plusPosX)
    {
        _posX += plusPosX;

        return _posX;
    }

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 단순 UI좌표 편하게하기 위한 용도
    protected float setUIPosY(float setPosY)
    {
        _posY = setPosY;

        return _posY;
    }

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 단순 UI좌표 편하게하기 위한 용도
    protected float plusUIPosY(float plusPosY)
    {
        _posY += plusPosY;

        return _posY;
    }

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    protected Rect GetRect(float x, float y, float width, float height)
    {
        return new Rect(x + _offsetX, y, width, height);
    }

    protected string GetCardShape(eCardShapeType shapeType)
    {
        var resultShape = "";

        switch(shapeType)
        {
            case eCardShapeType.TYPE_SPADE:
                resultShape = "♠";
                break;

            case eCardShapeType.TYPE_DIAMOND:
                resultShape = "◆";
                break;

            case eCardShapeType.TYPE_HEART:
                resultShape = "♥";
                break;

            case eCardShapeType.TYPE_CLOVER:
                resultShape = "♣";
                break;



        }


        return resultShape;

    }

    #endregion
}


