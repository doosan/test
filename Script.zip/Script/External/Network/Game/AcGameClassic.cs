﻿using UnityEngine;
using System;
using System.Collections;
using System.Linq;
using System.Collections.Generic;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// AcGameClassic
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

public class AcGameClassic : AcGameBase
{
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 변수
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    bool _userBetting;      // 유저가 칩 배팅 UI 닫기용

    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 메인 함수
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 메인 함수

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public AcGameClassic(float offsetX) : base(offsetX)
    {

    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 인게임 상태 별 함수
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 상태 변경

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // 상태 변경
    public override void ChangeState(eGameSceneState state)
    {
        base.ChangeState(state);

        if (state == eGameSceneState.STATE_ROOMGAMEPLAY)
        {
            var enterRoom = GetEnterRoom();

            // 게임 초기화
            enterRoom._userDeckList.Clear();
            for (int i = 0; i < enterRoom._netData_room._slotList.Count; i++)
            {
                enterRoom._userDeckList.Add(new List<AcNetData_DeckInfo>());
            }

            enterRoom._netData_room._currentTurnSlotNumber = -1;

            foreach(var slot in enterRoom._netData_room._slotList)
            {
                slot._cardSee = false;
                slot._fold = false;
            }

            _userBetting = false;
        }
    }

    #endregion

    #region 룸 게임 플레이 상태

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public override void RoomGamePlayState()
    {
        var enterRoom = GetEnterRoom();

        if (enterRoom == null)
            return;

        GUI.Label(GetRect(10, setUIPosY(10), 500, 25), string.Format("게임 시작됨!! 현재 룸 라운드: {0}", enterRoom._currentRoundState));

        switch(enterRoom._currentRoundState)
        {
            case eRoundState.STATE_DEFAULTCARDRECEIVE:
            case eRoundState.STATE_USERTURN:
            case eRoundState.STATE_SIDESHOW:
                GamePlayState_GamePlay();
                break;

            case eRoundState.STATE_SHOWDOWN:
            case eRoundState.STATE_SHOWDOWNSKIP:
                break;
        }
    }

    #endregion

    #region 룸 게임 결과 상태

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public override void RoomGameResultState()
    {
        var enterRoom = GetEnterRoom();

        GUI.Label(GetRect(10, setUIPosY(10), 400, 25), string.Format("게임 종료됨!!"));

        if (enterRoom != null)
        {
            var slotList = enterRoom._netData_room._slotList;
            for (int i = 0; i < slotList.Count; i++)
            {
                // 슬롯정보
                GUI.Label(GetRect(10, plusUIPosY(25), 200, 25), string.Format("슬롯번호: {0}, 슬롯상태: {1}", i, slotList[i]._number, slotList[i]._state));
                if (slotList[i]._state == eRoomSlotState.STATE_WAIT || slotList[i]._state == eRoomSlotState.STATE_CLOSE)
                {
                    GUI.Label(GetRect(10, plusUIPosY(25), 200, 25), "유저 비어있음");
                }
                else
                {
                    var userType = i != enterRoom._netData_room._dealerSlotNumber ? "일반 유저 " : "딜러 유저 ";
                    GUI.Label(GetRect(10, plusUIPosY(25), 400, 25), string.Format(userType + "ID: {0}, NickName: {1}, Chip: {2} ", slotList[i]._userInfo._userId, slotList[i]._userInfo._nickName, slotList[i]._userInfo._balance));

                    for (int j = 0; j < enterRoom._userDeckList[i].Count; j++)
                    {
                        var gameResultStr = "딜러임";
                        // 유저 승패 여부
                        //for (int k = 0; k < enterRoom._userGameResultInfoList.Count; k++)
                        //{
                        //    if (enterRoom._userGameResultInfoList[k]._slotNumber == i && enterRoom._userGameResultInfoList[k]._deckNumber == j)
                        //    {
                        //        switch (enterRoom._userGameResultInfoList[k]._gameResultType)
                        //        {
                        //            case eGameResultType.TYPE_WIN:
                        //                gameResultStr = "승리!!";
                        //                break;

                        //            case eGameResultType.TYPE_LOSE:
                        //                gameResultStr = "패배!!";
                        //                break;

                        //            case eGameResultType.TYPE_DRAW:
                        //                gameResultStr = "비김!!";
                        //                break;
                        //        }
                        //        break;
                        //    }
                        //}

                        plusUIPosY(25);
                        GUI.Label(GetRect(10, plusUIPosY(0), 350, 25), string.Format("족보: {0} 게임결과: {1}", enterRoom._userDeckList[i][j]._genealogyType, gameResultStr));

                        // 덱 상태
                        var index = 0;
                        foreach (var cardInfo in enterRoom._userDeckList[i][j]._cardList)
                        {
                            GUI.Label(GetRect(360 + index * 100, plusUIPosY(0), 100, 25), string.Format("카드 번호: {0}", cardInfo._number));
                            index++;
                        }
                    }
                }
            }
        }
    }

    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 게임 플레이 상태 세부적 함수
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region 유저들 플레이

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    void GamePlayState_GamePlay()
    {
        var enterRoom = GetEnterRoom();

        GUI.Label(GetRect(10, plusUIPosY(25), 200, 25), string.Format("현재 턴: {0}", enterRoom._netData_room._currentTurnSlotNumber));

        if(enterRoom._currentRoundState == eRoundState.STATE_USERTURN)
        {
            if (enterRoom._netData_room._currentTurnSlotNumber == enterRoom._mySlotNumber)
            {
                if (GUI.Button(GetRect(setUIPosX(10), plusUIPosY(25), 100, 25), "콜"))
                {
                    AcNetFacade.Instance.SendPacket_req_betting(EnterRoomIndex, eBettingType.TYPE_CALL, 0);
                }

                if (GUI.Button(GetRect(plusUIPosX(110), plusUIPosY(0), 100, 25), "레이즈"))
                {
                    AcNetFacade.Instance.SendPacket_req_betting(EnterRoomIndex, eBettingType.TYPE_RAISE, 0);
                }

                if (GUI.Button(GetRect(plusUIPosX(110), plusUIPosY(0), 100, 25), "사이드쇼"))
                {
                    AcNetFacade.Instance.SendPacket_req_betting(EnterRoomIndex, eBettingType.TYPE_SIDESHOW, 0);
                }

                if (GUI.Button(GetRect(plusUIPosX(110), plusUIPosY(0), 100, 25), "쇼"))
                {
                    AcNetFacade.Instance.SendPacket_req_betting(EnterRoomIndex, eBettingType.TYPE_SHOW, 0);
                }

                if (GUI.Button(GetRect(plusUIPosX(110), plusUIPosY(0), 100, 25), "팩"))
                {
                    AcNetFacade.Instance.SendPacket_req_betting(EnterRoomIndex, eBettingType.TYPE_FOLD, 0);
                }
            }
            else
            {
                GUI.Label(GetRect(10, plusUIPosY(25), 100, 25), "선택 할 수 없음");
            }
        }
        else if(enterRoom._currentRoundState == eRoundState.STATE_SIDESHOW)
        {
            if (enterRoom._netData_room._sideShowDstSlotNumber == enterRoom._mySlotNumber)
            {
                if (GUI.Button(GetRect(setUIPosX(10), plusUIPosY(25), 100, 25), "수락"))
                {
                    AcNetFacade.Instance.SendPacket_req_sideShowAccept(EnterRoomIndex, true);
                }

                if (GUI.Button(GetRect(plusUIPosX(110), plusUIPosY(0), 100, 25), "거절"))
                {
                    AcNetFacade.Instance.SendPacket_req_sideShowAccept(EnterRoomIndex, false);
                }
            }
            else
            {
                GUI.Label(GetRect(10, plusUIPosY(25), 100, 25), "사이드쇼 중");
            }
        }
        


        var slotList = enterRoom._netData_room._slotList;
        for (int i = 0; i < slotList.Count; i++)
        {
            // 슬롯정보
            GUI.Label(GetRect(10, plusUIPosY(25), 200, 25), string.Format("슬롯번호: {0}, 슬롯상태: {1}", i, slotList[i]._number, slotList[i]._state));
            if (slotList[i]._state == eRoomSlotState.STATE_WAIT || slotList[i]._state == eRoomSlotState.STATE_CLOSE)
            {
                GUI.Label(GetRect(10, plusUIPosY(25), 200, 25), "유저 비어있음");
            }
            else
            {
                var userType = enterRoom._netData_room._dealerSlotNumber != i ? "일반 유저 " : "딜러 유저 ";
                GUI.Label(GetRect(10, plusUIPosY(25), 400, 25), string.Format(userType + "ID: {0}, NickName: {1} See: {2}, Chip: {3} ", slotList[i]._userInfo._userId, slotList[i]._userInfo._nickName, slotList[i]._cardSee == true ? "Seen" : "Blind", slotList[i]._userInfo._balance));

                for (int j = 0; j < enterRoom._userDeckList[i].Count; j++)
                {
                    plusUIPosY(25);
                    GUI.Label(GetRect(10, plusUIPosY(0), 250, 25), string.Format("덱 번호: {0} 족보: {1} ", enterRoom._userDeckList[i][j]._deckNumber, enterRoom._userDeckList[i][j]._genealogyType));

                    var index = 0;
                    foreach (var cardInfo in enterRoom._userDeckList[i][j]._cardList)
                    {
                        if (enterRoom._netData_room._slotList[i]._cardSee == true)
                        {
                            GUI.Label(GetRect(260 + index * 100, plusUIPosY(0), 100, 25), string.Format("카드 M: {0}, N: {1}", GetCardShape(cardInfo._shapeType), cardInfo._number));
                        }
                        else
                        {
                            GUI.Label(GetRect(260 + index * 100, plusUIPosY(0), 100, 25), string.Format("카드 M: {0}, N: {1}", "S", "S"));
                        }

                        index++;
                    }

                    if ((enterRoom._currentRoundState == eRoundState.STATE_USERTURN || enterRoom._currentRoundState == eRoundState.STATE_SIDESHOW) &&
                        enterRoom._netData_room._slotList[i]._number == enterRoom._mySlotNumber)
                    {
                        if (enterRoom._netData_room._slotList[i]._cardSee == false)
                        {
                            if (GUI.Button(GetRect(260 + index * 100, plusUIPosY(0), 100, 25), "카드보기"))
                            {
                                AcNetFacade.Instance.SendPacket_req_cardSee(EnterRoomIndex);
                            }
                        }
                        else
                        {
                            GUI.Label(GetRect(260 + index * 100, plusUIPosY(0), 100, 25), "카드봄");
                        }
                    }
                }
            }
        }
    }

    #endregion
}


