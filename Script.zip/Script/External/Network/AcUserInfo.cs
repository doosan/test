﻿using UnityEngine;
using System;
using System.Collections;
using System.Linq;
using System.Collections.Generic;
using ForuOnes.T3.LuckyTeenPatti;
using ForuOnes.T3.LuckyTeenPatti.Table;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// AcUserInfo: 유저 정보
//
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

public class AcEnterRoomInfo
{
    public int _multiGameOrder;
    public AcNetData_RoomInfo _netData_room;

    public eRoundState _currentRoundState;

    public int _mySlotNumber;
    public bool _bettingEnable;
    public List<List<AcNetData_DeckInfo>> _userDeckList = new List<List<AcNetData_DeckInfo>>();                      // 슬롯 번호랑 대응
    public List<AcNetData_DeckInfo> _userJokerDeckList = new List<AcNetData_DeckInfo>();                             // 슬롯 번호랑 대응 (조커룰)

    public long _winnerReceiveBalance;
    public List<int> _winnerSlotNumberList = new List<int>();                                                        // 슬롯 번호랑 대응
    public List<AcNetData_LeaguePointInfo> _leaguePointList = new List<AcNetData_LeaguePointInfo>();
    public List<AcNetData_GameResultPenaltyInfo> _penaltyInfoList = new List<AcNetData_GameResultPenaltyInfo>();     // 슬롯 번호랑 대응

    public List<AcNetData_TalkInfo> _roomTalkInfoList = new List<AcNetData_TalkInfo>();

    // 사이드쇼
    public bool _sideShowResult;
    public bool _sideShowAccept;
    public eGameResultType _sideShowGameResultType;

    public AcEnterRoomInfo(int multiGameOrder, AcNetData_RoomInfo netRoomInfo)
    {
        _multiGameOrder = multiGameOrder;
        _netData_room = netRoomInfo;

        for (int i = 0; i < _netData_room._slotList.Count; i++)
        {
            if (_netData_room._slotList[i]._userInfo._uId == AcUserInfo._netData_user._uId)
            {
                // 내슬롯
                _mySlotNumber = _netData_room._slotList[i]._number;
            }
        }

        if (_netData_room._state == eRoomState.STATE_GAMEPLAY)
        {
            _currentRoundState = _netData_room._roundState;
            _userDeckList.Clear();
            _userJokerDeckList.Clear();

            for (int i = 0; i < _netData_room._slotList.Count; i++)
            {
                // 덱 리스트
                if (_netData_room._slotList[i]._deckList.Any() == true)
                {
                    _userDeckList.Add(_netData_room._slotList[i]._deckList);
                }
                else
                {
                    var tempDeckInfo = new AcNetData_DeckInfo();
                    tempDeckInfo._deckNumber = 0;
                    tempDeckInfo._genealogyType = eGenealogyType.TYPE_NONE;
                    tempDeckInfo._genealogyCardNumber = 2;
                    for (int k = 0; k < 3; k++)
                    {
                        tempDeckInfo._cardList.Add(new AcNetData_CardInfo() { _number = 2, _shapeType = eCardShapeType.TYPE_SPADE });
                    }

                    var tempDeckList = new List<AcNetData_DeckInfo>();
                    tempDeckList.Add(tempDeckInfo);
                    _userDeckList.Add(tempDeckList);
                }

                // 조커 덱 리스트
                _userJokerDeckList.Add(new AcNetData_DeckInfo());

                if(_netData_room._slotList[i]._deckList_joker.Any() == true)
                {
                    _userJokerDeckList[i] = _netData_room._slotList[i]._deckList_joker[0]; // 조커는 일단 여러 덱일 일은 없으므로 인덱스 0
                }
            }
        }
    }

    public bool IsPlay()
    {
        var result = false;

        if (_netData_room._state == eRoomState.STATE_GAMEPLAY)
        {
            for (int i = 0; i < _netData_room._slotList.Count; i++)
            {
                if (_netData_room._slotList[i]._userInfo._uId == AcUserInfo._netData_user._uId)
                {
                    if (_netData_room._slotList[i]._state == eRoomSlotState.STATE_GAMEPLAY)
                    {
                        result = true;
                    }
                }
            }
        }

        return result;
    }
}

public static class AcUserInfo
{
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 변수
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    // 로그인 유무
    public static bool _isLogin;
    public static string _loginToken;

    // 서버와 시간 차
    public static double _serverSubtract_Milliseconds;

    // 유저
    public static AcNetData_UserInfo _netData_user;

    // 인벤토리
    public static AcNetData_InventoryInfo _netData_inventory;
    public static List<AcNetData_ItemInfo> _removeItemInfoList = new List<AcNetData_ItemInfo>();

    // 우체통
    public static AcNetData_PostBoxInfo _netData_postbox;

    // 방
    public static long _mainRoomIndex;
    public static Dictionary<long, AcEnterRoomInfo> _enterRoomDic = new Dictionary<long, AcEnterRoomInfo>();

    // 랭크
    public static List<AcNetData_RankUserInfo> _rankUserList = new List<AcNetData_RankUserInfo>();
    public static AcNetData_SimpleRankUserInfo _myRankUserInfo = new AcNetData_SimpleRankUserInfo();

    public static AcNetData_TOTRankRewardInfo _myTOTRankRewardInfo = new AcNetData_TOTRankRewardInfo();

    public static List<AcNetData_ChipRankUserInfo> _chipRankUserList = new List<AcNetData_ChipRankUserInfo>();
    public static AcNetData_SimpleChipRankUserInfo _myChipRankUserInfo = new AcNetData_SimpleChipRankUserInfo();

    public static AcNetData_LeagueGroupInfo _leagueGroupInfo;
    public static int _leagueCalcRestSecond;
    public static AcNetData_SimpleLeagueGroupInfo _simpleLeagueGroupInfo;

    // 랭크 갱신 인덱스
    public static byte _TOTRankRefreshIndex = 0;
    public static byte _chipRankRefreshIndex = 0;

    // TOT 챔피언쉽
    public static eTOTChampionShipState _tOTChampionShipState;
    public static DateTime _tOTChampionShipEndDateTime;
    public static int _tOTChampionShipGameModeDataId;

    public static List<AcNetData_TOTChampionShipUserInfo> _tOTchampionShipUserList = new List<AcNetData_TOTChampionShipUserInfo>();
    public static AcNetData_TOTChampionShipUserInfo _myTOTChampionShipUserInfo = new AcNetData_TOTChampionShipUserInfo();

    public static List<AcNetData_SimpleTOTChampionShipUserInfo> _simpleTOTChampionShipUserList = new List<AcNetData_SimpleTOTChampionShipUserInfo>();
    public static AcNetData_SimpleTOTChampionShipUserInfo _mySimpleTOTChampionShipUserInfo = new AcNetData_SimpleTOTChampionShipUserInfo();

    public static AcNetData_TOTChampionShipRewardInfo _myTOTChampionShipRewardInfo = new AcNetData_TOTChampionShipRewardInfo();

    public static long _tOTChampionShipRankRefreshIndex;
    public static long _tOTChampionShipSimpleRankRefreshIndex;

    // BBS
    public static List<AcNetData_BBSNoticeSimpleInfo> _noticeBoardList = new List<AcNetData_BBSNoticeSimpleInfo>();
    public static List<string> _noticeList = new List<string>();
    public static List<AcNetData_BBSBannerSimpleInfo> _bannerList = new List<AcNetData_BBSBannerSimpleInfo>();

    // 결제 미지급된 상품 지급된 아이템 리스트(인벤토리엔 이미 들어가 있음)
    public static Dictionary<int, List<AcNetData_ItemAcquireInfo>> _nonGiveGoodsShopItemDic = new Dictionary<int, List<AcNetData_ItemAcquireInfo>>();

    // 슬롯머신
    public static List<int> _symbolDataIdList = new List<int>();
    public static List<int> _rewardDataIdList = new List<int>();

    public static List<int> _attendanceSymbolDataIdList = new List<int>();

    public static int _rouletteSymbolDataId;

    // 친구 
    public static List<AcNetData_FriendInfo> _friendList = new List<AcNetData_FriendInfo>();
    public static List<AcNetData_FriendRequestInfo> _friendRequestList = new List<AcNetData_FriendRequestInfo>();
    public static AcNetData_UserFriendInviteInfo _userfriendInviteInfo = null;
    public static Dictionary<long, List<AcNetData_TalkInfo>> _friendTalkDicList = new Dictionary<long, List<AcNetData_TalkInfo>>();

    // 미션
    public static List<AcNetData_MissionInfo> _missionInfoList = null;

    // 공유 보상 정보
    public static AcNetData_ShareRewardInfo _shareRewardInfo = null;

    // 튜토리얼
    public static AcNetDataSC_resTutorialCompleteInfo _tutorialCompleteInfo = new AcNetDataSC_resTutorialCompleteInfo();

    // 컨텐츠 잠금 정보
    public static List<AcNetData_ContentMainLockInfo> _contentMainLockInfoList = new List<AcNetData_ContentMainLockInfo>();

    // PayTM
    public static bool IsPayTMRegister { get { return string.IsNullOrEmpty(_netData_user._payTMPhoneNumber) == false; } }

    // 버프
    public static List<AcNetData_BuffInfo> _buffInfoList = new List<AcNetData_BuffInfo>();
    public static List<AcNetData_BuffInfo> _removeBuffInfoList = new List<AcNetData_BuffInfo>();

    // 구매 제한 상품 정보 리스트
    public static List<AcNetData_UserLimitProductInfo> _userLimitProductInfoList = new List<AcNetData_UserLimitProductInfo>();

    public static long _eventAllInClearCount;

    // 테스트 클라
    public static bool _autoTest = false;

    // 방 정보 얻기
    public static AcEnterRoomInfo GetEnterRoom(long roomIndex)
    {
        AcEnterRoomInfo findRoom = null;

        if (_enterRoomDic.ContainsKey(roomIndex) == true)
        {
            findRoom = _enterRoomDic[roomIndex];
        }

        return findRoom;
    }

    // 유저의 토탈 칩
    public static long UserTotalChip
    {
        get
        {
            return _netData_user._safeInfoList.Sum(data => data.Chip);
        }
    }

    // 서버 시간 얻기
    public static DateTime ServerDateTime
    {
        get
        {
            return DateTime.Now.AddMilliseconds(_serverSubtract_Milliseconds);
        }
    }

    // 출석 슬롯머신 무료 가능 갯수
    public static int AttendanceSlotMachineEnableCount
    {
        get
        {
            var lastAttendanceDate = (long)new TimeSpan(_netData_user._lastAttendanceDate.Ticks).TotalDays;
            var serverdateTime = (long)new TimeSpan(ServerDateTime.Ticks).TotalDays;
            var diffDay = serverdateTime - lastAttendanceDate;
            if (diffDay >= 1)
            {
                // TODO: 임시임 테이블에 Max값 비교해서 플러스 해야함
                _netData_user._attendanceSlotMachineEnableCount = 1;
            }

            return _netData_user._attendanceSlotMachineEnableCount;
        }
    }

    // 출석 누석 횟수
    public static int AttendanceAccumulateCount
    {
        get
        {
            var attendanceAccumulateCount = _netData_user._attendanceAccumulateCount;
            var lastAttendanceDate = (long)new TimeSpan(_netData_user._lastAttendanceDate.Ticks).TotalDays;
            var serverDateTime = (long)new TimeSpan(ServerDateTime.Ticks).TotalDays;
            var diffDay = serverDateTime - lastAttendanceDate;
            if (diffDay >= 1)
            {
                if (diffDay == 1)
                {
                    attendanceAccumulateCount++;
                }
                else
                {
                    attendanceAccumulateCount = 1;
                }
            }

            return attendanceAccumulateCount;
        }
    }

    // 출석 슬롯머신 무료 가능 갯수
    public static int RouletteSlotMachineEnableCount
    {
        get
        {
            var freeUpdateDateTime = (long)new TimeSpan(_netData_user._rouletteFreeUpdateDateTime.Ticks).TotalDays;
            var serverdateTime = (long)new TimeSpan(ServerDateTime.Ticks).TotalDays;
            var diffDay = serverdateTime - freeUpdateDateTime;
            if (diffDay >= 1)
            {
                // TODO: 임시임 테이블에 Max값 비교해서 플러스 해야함
                _netData_user._rouletteFreeCount = 1;
            }

            return _netData_user._rouletteFreeCount;
        }
    }

    // 광고 보상 마지막 획득 레벨
    public static int ADRewardLastRewardLevel
    {
        get
        {
            if (_netData_user._aDRewardLastUpdateDateTime.Date < ServerDateTime.Date)
            {
                return 0;
            }
            else
            {
                return _netData_user._aDRewardLastRewardLevel;
            }
        }
    }

    // 부족칩 보상 가능여부
    public static bool EmptyRewardEnable
    {
        get
        {
            if (_netData_user._emptyChipRewardRemainCount > 0)
                return true; 

            if (_netData_user._emptyChipRewardLastUpdateDateTime.Date < ServerDateTime.Date)
            {
                return true;
            }

            return false;
        }
    }

    #region 버프 리스트

    // 날짜 확인 버프 정보 리스트
    public static List<AcNetData_BuffInfo> BuffInfoList
    {
        get
        {
            for (int i = _buffInfoList.Count - 1; i >= 0; i--)
            {
                if (_buffInfoList[i]._endDateTime < ServerDateTime)
                {
                    var buffDataInfo = BuffBaseTable.Instance.GetData(_buffInfoList[i]._buffDataId);
                    if (buffDataInfo != null && buffDataInfo.DurationType == eBuffDurationType.TYPE_LIMITED)
                    {
                        _removeBuffInfoList.Add(_buffInfoList[i]);
                        _buffInfoList.RemoveAt(i);
                    }
                }
            }

            return _buffInfoList;
        }
    }

    #endregion

    #region 삭제된 버프 리스트

    public static List<AcNetData_BuffInfo> RemoveBuffInfoList { get { return _removeBuffInfoList; } }

    #endregion


    #region 아이템 장착 정보 요청

    public static AcNetData_ItemEquipInfo ItemEquipInfo
    {
        get
        {
            if(_netData_inventory != null)
            {
                for (int i = _netData_inventory._itemList.Count - 1; i >= 0; i--)
                {
                    if (_netData_inventory._itemList[i]._timeLimitOn == true && _netData_inventory._itemList[i]._timeLimitEndDate < ServerDateTime)
                    {
                        foreach (var valueList in _netData_inventory._itemEquipInfo._itemEquipDic.Values)
                        {
                            for (int k = 0; k < valueList.Count; k++)
                            {
                                if (valueList[k] == _netData_inventory._itemList[i]._uId)
                                {
                                    valueList[k] = "";
                                    break;
                                }
                            }
                        }

                        _removeItemInfoList.Add(_netData_inventory._itemList[i]);
                        _netData_inventory._itemList.RemoveAt(i);
                    }
                }

                return _netData_inventory._itemEquipInfo;
            }
            else
            {
                return null;
            }
        }
        
    }

    #endregion

    #region 아이템 리스트 요청

    public static List<AcNetData_ItemInfo> ItemInfoList
    {
        get
        {
            if (_netData_inventory != null)
            {
                for (int i = _netData_inventory._itemList.Count - 1; i >= 0; i--)
                {
                    if (_netData_inventory._itemList[i]._timeLimitOn == true && _netData_inventory._itemList[i]._timeLimitEndDate < ServerDateTime)
                    {
                        foreach (var valueList in _netData_inventory._itemEquipInfo._itemEquipDic.Values)
                        {
                            for (int k = 0; k < valueList.Count; k++)
                            {
                                if (valueList[k] == _netData_inventory._itemList[i]._uId)
                                {
                                    valueList[k] = "";
                                    break;
                                }
                            }
                        }

                        _removeItemInfoList.Add(_netData_inventory._itemList[i]);
                        _netData_inventory._itemList.RemoveAt(i);
                    }
                }

                return _netData_inventory._itemList;
            }
            else
            {
                return null;
            }
        }
    }

    #endregion

    #region 삭제된 아이템 리스트 

    public static List<AcNetData_ItemInfo> RemoveItemInfoList { get { return _removeItemInfoList; } }

    #endregion


    // 푸시 정보
    public static string _pushToken;
}


