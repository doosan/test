﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class GameRoomTableData
    {
        public GameRoomTableData(int id, int gameModeId, long minChipLimit, long bootChip, long maxPotLimit, long chaalChipLimit, float emoticonPriceMultiple, int dealerId, long dealerTip, 
                                 string roomPrefab, float lPBoosterEvent, int playChipEmptyGoods, int lpBoostBuffShopDataId, int playChipEmptyDia)
        {
            Id = id;
            GameModeId = gameModeId;
            MinChipLimit = minChipLimit;
            BootChip = bootChip;
            MaxPotLimit = maxPotLimit;
            ChaalChipLimit = chaalChipLimit;
            EmoticonPriceMultiple = emoticonPriceMultiple;
            DealerId = dealerId;
            DealerTip = dealerTip;
            RoomPrefab = roomPrefab;
            LPBoosterEvent = lPBoosterEvent;
            PlayChipEmptyGoods = playChipEmptyGoods;
            LpBoostBuffShopDataId = lpBoostBuffShopDataId;
            PlayChipEmptyDia = playChipEmptyDia;
        }

        public readonly int Id;
        public readonly int GameModeId;
        public readonly long MinChipLimit;
        public readonly long BootChip;
        public readonly long MaxPotLimit;
        public readonly long ChaalChipLimit;
        public readonly float EmoticonPriceMultiple;
        public readonly int DealerId;
        public readonly long DealerTip;
        public readonly string RoomPrefab;
        public readonly float LPBoosterEvent;
        public readonly int PlayChipEmptyGoods;
        public readonly int LpBoostBuffShopDataId;
        public readonly int PlayChipEmptyDia;

    }

    public class GameRoomTable : Table<GameRoomTable, GameRoomTable.FieldType>
    {
        public enum FieldType
        {
            id,
            gameModeId,
            minChipLimit,
            bootChip,
            maxPotLimit,
            chaalChipLimit,
            emoticonPriceMultiple,
            dealerId,
            dealerTip,
            roomPrefab,
            lPBoosterEvent,
            playChipEmptyGoods,
            lpBoostBuffShopDataId,
            playChipEmptyDia,
        }

        #region Override from Table<GameRoomTable, GameRoomTable.FieldType>
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, GameRoomTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                int gameModeId = enumerator.ParseInt32(FieldType.gameModeId);
                long minChipLimit = enumerator.ParseInt64(FieldType.minChipLimit);
                long bootChip = enumerator.ParseInt64(FieldType.bootChip);
                long maxPotLimit = enumerator.ParseInt64(FieldType.maxPotLimit);
                long chaalChipLimit = enumerator.ParseInt64(FieldType.chaalChipLimit);
                float emoticonPriceMultiple = enumerator.ParseSingle(FieldType.emoticonPriceMultiple);
                int dealerId = enumerator.ParseInt32(FieldType.dealerId);
                long dealerTip = enumerator.ParseInt64(FieldType.dealerTip);
                string roomPrefab = enumerator.ParseString(FieldType.roomPrefab);
                float lPBoosterEvent = enumerator.ParseSingle(FieldType.lPBoosterEvent);
                int playChipEmptyGoods = enumerator.ParseInt32(FieldType.playChipEmptyGoods);
                int lpBoostBuffShopDataId = enumerator.ParseInt32(FieldType.lpBoostBuffShopDataId);
                int playChipEmptyDia = enumerator.ParseInt32(FieldType.playChipEmptyDia);

                var data = new GameRoomTableData(
                        id,
                        gameModeId,
                        minChipLimit,
                        bootChip,
                        maxPotLimit,
                        chaalChipLimit,
                        emoticonPriceMultiple,
                        dealerId,
                        dealerTip,
                        roomPrefab,
                        lPBoosterEvent,
                        playChipEmptyGoods,
                        lpBoostBuffShopDataId,
                        playChipEmptyDia);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public GameRoomTableData GetData(int id)
        {
            GameRoomTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }
       
        public GameRoomTableData GetIndex(int gameModeId, long value)
        {
            List<GameRoomTableData> dataList = _dict.Values.Where(x => x.GameModeId == gameModeId).OrderBy(x => x.BootChip).ToList();

            for (int i = dataList.Count - 1; i >= 0; i--)
            {
                if (dataList[i].MinChipLimit <= value)
                    return dataList[i];
            }
            return null;
        }
       
        public List<GameRoomTableData> GetDataList(int gameModeId)
        {
            return _dict.Values.Where(x => x.GameModeId == gameModeId).OrderBy(x => x.BootChip).ToList();
        }

        //public List<string> RoomPrefabList
        //{
        //    get
        //    {
        //        List<string> _list = new List<string>();

        //        foreach(var p in _dict)
        //        {
        //            if(!_list.Contains(p.Value.RoomPrefab))
        //                _list.Add(p.Value.RoomPrefab);
        //        }

        //        return _list;
        //    }
        //}

        private Dictionary<int, GameRoomTableData> _dict;

    }
}
