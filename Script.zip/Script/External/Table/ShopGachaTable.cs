﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class ShopGachaTableData
    {
        public ShopGachaTableData(int id, string name, int gachaInfoId, bool displayOnOff, int gachaSortOrder, eNeedGoodsType needGoodsType,
                                float saleRate, int needGoodsItemValue, int needgoodsValue, int rewardItemId, string needGoodsIcon)
        {
            Id = id;
            Name = name;
            GachaInfoId = gachaInfoId;
            DisplayOnOff = displayOnOff;
            GachaSortOrder = gachaSortOrder;
            NeedGoodsType = needGoodsType;
            SaleRate = saleRate;
            NeedGoodsItemValue = needGoodsItemValue;
            NeedGoodsValue = needgoodsValue;
            RewardItemId = rewardItemId;
            NeedGoodsIcon = needGoodsIcon;
        }

        public readonly int Id;
        public readonly string Name;
        public readonly int GachaInfoId;
        public readonly bool DisplayOnOff;
        public readonly int GachaSortOrder;
        public readonly eNeedGoodsType NeedGoodsType;
        public readonly float SaleRate;        
        public readonly int NeedGoodsItemValue;
        public readonly int NeedGoodsValue;
        public readonly int RewardItemId;
        public readonly long RewardItemValue;
        public readonly string NeedGoodsIcon;
    }

    #region Override from Table<ShopGachaTable, ShopGachaTable.FieldType>
    public class ShopGachaTable : Table<ShopGachaTable, ShopGachaTable.FieldType>
    {
        public enum FieldType
        {
            id,
            name,
            gachaInfoId,
            displayOnOff,
            gachaSortOrder,
            needGoodsType,
            saleRate,            
            needGoodsItemValue,
            needgoodsValue,
            rewardItemId,
            needGoodsIcon,
        }

        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, ShopGachaTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                string name = enumerator.ParseString(FieldType.name);
                int gachaInfoId = enumerator.ParseInt32(FieldType.gachaInfoId);
                bool displayOnOff = enumerator.ParseBoolean(FieldType.displayOnOff);
                int gachaSortOrder = enumerator.ParseInt32(FieldType.gachaSortOrder);
                eNeedGoodsType needGoodsType = (eNeedGoodsType)enumerator.ParseInt32(FieldType.needGoodsType);
                float saleRate = enumerator.ParseSingle(FieldType.saleRate);
                int needGoodsItemValue = enumerator.ParseInt32(FieldType.needGoodsItemValue);
                int needgoodsValue = enumerator.ParseInt32(FieldType.needgoodsValue);
                int rewardItemId = enumerator.ParseInt32(FieldType.rewardItemId);
                string needGoodsIcon = enumerator.ParseString(FieldType.needGoodsIcon);

                var data = new ShopGachaTableData(
                     id,
                     name,
                     gachaInfoId,
                     displayOnOff,
                     gachaSortOrder,
                     needGoodsType,
                     saleRate,
                     needGoodsItemValue,
                     needgoodsValue,
                     rewardItemId,
                     needGoodsIcon);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public ShopGachaTableData GetData(int id)
        {
            ShopGachaTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public List<ShopGachaTableData> GetData()
        {
            return _dict.Values.ToList();
        }

        private Dictionary<int, ShopGachaTableData> _dict;
    }
}
