﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class GameStrengthTableData
    {
        public GameStrengthTableData(int id, string name, eGenealogyType madeType, int cardNum, int orderNum, float[] madeStrenght)
        {
            Id = id;
            Name = name;
            MadeType = madeType;
            CardNum = cardNum;
            OrderNum = orderNum;
            MadeStrenght = madeStrenght;
        }

        public readonly int Id;
        public readonly string Name;
        public readonly eGenealogyType MadeType;
        public readonly int CardNum;
        public readonly int OrderNum;
        public readonly float[] MadeStrenght;
    }

    public class GameStrengthTable : Table<GameStrengthTable, GameStrengthTable.FieldType>
    {
        public enum FieldType
        {
            id,
            name,
            madeType,
            cardNum,
            orderNum,
            madeStrength,
            muflisStrength,
            jokerStrength,
            ak47Strength,
        }

        #region Override from Table<GameStengthTable, GameStengthTable.FieldType>
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, GameStrengthTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                string name = enumerator.ParseString(FieldType.name);
                eGenealogyType madeType = (eGenealogyType)enumerator.ParseInt32(FieldType.madeType);
                int cardNum = enumerator.ParseInt32(FieldType.cardNum);
                int orderNum = enumerator.ParseInt32(FieldType.orderNum);

                float[] madeStrenghts = { enumerator.ParseSingle(FieldType.madeStrength), enumerator.ParseSingle(FieldType.jokerStrength),
                                          enumerator.ParseSingle(FieldType.muflisStrength), enumerator.ParseSingle(FieldType.ak47Strength) };

                var data = new GameStrengthTableData(
                        id,
                        name,
                        madeType,
                        cardNum,
                        orderNum,
                        madeStrenghts);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public GameStrengthTableData GetData(int id)
        {
            GameStrengthTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public float GetMadeStenght(eGameType gameType, eGenealogyType genealogyType, int cardNum)
        {
            var data = _dict.Where(x => x.Value.MadeType == genealogyType && x.Value.CardNum == cardNum).FirstOrDefault();            

            return data.Value.MadeStrenght[(int)gameType - 1];
        }

        public int GetIndex(eGenealogyType genealogyType, int cardNum)
        {
            var data = _dict.Where(x => x.Value.MadeType == genealogyType && x.Value.CardNum == cardNum).FirstOrDefault();

            return data.Key;
        }

        public int GetIndexInOrder(int order)
        {
            var data = _dict.Where(x => x.Value.OrderNum == order).FirstOrDefault();

            return data.Value.Id;
        }

        public List<string> GetNumberList(eGenealogyType genealogyType)
        {
            List<string> numberList = new List<string>();

            var _list = _dict.Where(x => x.Value.MadeType == genealogyType && x.Value.OrderNum != 0).OrderByDescending(x => x.Value.OrderNum).ToList();
            
            for (int i = 0; i < _list.Count; i++)
            {
                if(_list[i].Value.CardNum == 14)
                    numberList.Add("A");
                else if (_list[i].Value.CardNum == 13)
                    numberList.Add("K");
                else if (_list[i].Value.CardNum == 12)
                    numberList.Add("Q");
                else if (_list[i].Value.CardNum == 11)
                    numberList.Add("J");
                else
                    numberList.Add(_list[i].Value.CardNum.ToString());
            }

            return numberList;
        }

        public int MaxOrder
        {
            get { return _dict.Max(x => x.Value.OrderNum); }
        }

        private Dictionary<int, GameStrengthTableData> _dict;
    }
}
