﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class TutorialGaneshaTableData
    {
        public TutorialGaneshaTableData(int id, int dayNumber, eTutorialGaneshaClearType tutorialGaneshaClearType, int clearCount, int rewardItemId,
                                        long rewardItemValue, eTutorialRewardGiveType rewardGiveType, string ganeshaAction, int ganeshaTextId)
        {
            Id = id;
            DayNumber = dayNumber;
            TutorialGaneshaClearType = tutorialGaneshaClearType;
            ClearCount = clearCount;
            RewardItemId = rewardItemId;
            RewardItemValue = rewardItemValue;
            RewardGiveType = rewardGiveType;
            GaneshaAction = ganeshaAction;
            GaneshaTextId = ganeshaTextId;
        }

        public readonly int Id;
        public readonly int DayNumber;
        public readonly eTutorialGaneshaClearType TutorialGaneshaClearType;
        public readonly int ClearCount;
        public readonly int RewardItemId;
        public readonly long RewardItemValue;
        public readonly eTutorialRewardGiveType RewardGiveType;
        public readonly string GaneshaAction;
        public readonly int GaneshaTextId;
    }

    public class TutorialGaneshaTable : Table<TutorialGaneshaTable, TutorialGaneshaTable.FieldType>
    {
        public enum FieldType
        {
            id,
            dayNumber,
            tutorialGaneshaClearType,
            clearCount,
            rewardItemId,
            rewardItemValue,
            rewardGiveType,
            ganeshaAction,
            ganeshaTextId,
        }


        #region Override from Table<TutorialGaneshaTable, TutorialGaneshaTable.FieldType>
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, TutorialGaneshaTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                int dayNumber = enumerator.ParseInt32(FieldType.dayNumber);
                eTutorialGaneshaClearType tutorialGaneshaClearType = (eTutorialGaneshaClearType)enumerator.ParseInt32(FieldType.tutorialGaneshaClearType);
                int clearCount = enumerator.ParseInt32(FieldType.clearCount);
                int rewardItemId = enumerator.ParseInt32(FieldType.rewardItemId);
                long rewardItemValue = enumerator.ParseInt64(FieldType.rewardItemValue);
                eTutorialRewardGiveType rewardGiveType = (eTutorialRewardGiveType)enumerator.ParseInt32(FieldType.rewardGiveType);
                string ganeshaAction = enumerator.ParseString(FieldType.ganeshaAction);
                int ganeshaTextId = enumerator.ParseInt32(FieldType.ganeshaTextId);                

                var data = new TutorialGaneshaTableData(
                        id,
                        dayNumber,
                        tutorialGaneshaClearType,
                        clearCount,
                        rewardItemId,
                        rewardItemValue,
                        rewardGiveType,
                        ganeshaAction,
                        ganeshaTextId);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public TutorialGaneshaTableData GetData(int id)
        {
            TutorialGaneshaTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        private Dictionary<int, TutorialGaneshaTableData> _dict;
    }
}