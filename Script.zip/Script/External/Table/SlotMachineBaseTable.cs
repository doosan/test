﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class SlotMachineBaseTableData
    {
        public SlotMachineBaseTableData(int id, string name, eSlotMachineType slotMachineType, eSlotMachineFreeEnableType slotMachineFreeEnableType, int freeSpinMaxCount,
                                        eFeverResetType feverResetType, int feverValue,  int couponItemId, long couponItemValue, int useItemId, long useItemValue, int exchangeRatio, int exchangeItemId, int betGroup)     
        {
            Id = id;
            Name = name;
            SlotMachineType = slotMachineType;
            SlotMachineFreeEnableType = slotMachineFreeEnableType;
            FreeSpinMaxCount = freeSpinMaxCount;
            FeverResetType = feverResetType;
            FeverValue = feverValue;
            CouponItemId = couponItemId;
            CouponItemValue = couponItemValue;
            UseItemId = useItemId;
            UseItemValue = useItemValue;
            ExchangeRatio = exchangeRatio;
            ExchangeItemId = exchangeItemId;
            BetGroup = betGroup;
        }

        public readonly int Id;
        public readonly string Name;
        public readonly eSlotMachineType SlotMachineType;
        public readonly eSlotMachineFreeEnableType SlotMachineFreeEnableType;
        public readonly int FreeSpinMaxCount;

        public readonly eFeverResetType FeverResetType;
        public readonly int FeverValue;
        public readonly int CouponItemId;
        public readonly long CouponItemValue;

        public readonly int UseItemId;
        public readonly long UseItemValue;
        public readonly int ExchangeRatio;
        public readonly int ExchangeItemId;
        public readonly int BetGroup;
    }

    #region Override from Table<SlotMachineBaseTable, SlotMachineBaseTable.FieldType>
    public class SlotMachineBaseTable : Table<SlotMachineBaseTable, SlotMachineBaseTable.FieldType>
    {
        public enum FieldType
        {
            id,
            name,
            slotMachineType,
            slotMachineFreeEnableType,
            freeSpinMaxCount,
            feverResetType,
            feverValue,
            couponItemId,
            couponItemValue,
            useItemId,
            useItemValue,
            exchangeRatio,
            exchangeItemId,
            betGroup,
        }

        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, SlotMachineBaseTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                string name = enumerator.ParseString(FieldType.name);                
                eSlotMachineType slotMachineType = (eSlotMachineType)enumerator.ParseInt32(FieldType.slotMachineType);
                eSlotMachineFreeEnableType slotMachineFreeEnableType = (eSlotMachineFreeEnableType)enumerator.ParseInt32(FieldType.slotMachineFreeEnableType);
                int freeSpinMaxCount = enumerator.ParseInt32(FieldType.freeSpinMaxCount);
                eFeverResetType feverResetType = (eFeverResetType)enumerator.ParseInt32(FieldType.feverResetType);
                int feverValue = enumerator.ParseInt32(FieldType.feverValue);
                int couponItemId = enumerator.ParseInt32(FieldType.couponItemId);
                long couponItemValue = enumerator.ParseInt64(FieldType.couponItemValue);
                int useItemId = enumerator.ParseInt32(FieldType.useItemId);
                long useItemValue = enumerator.ParseInt64(FieldType.useItemValue);
                int exchangeRatio = enumerator.ParseInt32(FieldType.exchangeRatio);
                int exchangeItemId = enumerator.ParseInt32(FieldType.exchangeItemId);
                int betGroup = enumerator.ParseInt32(FieldType.betGroup);

                var data = new SlotMachineBaseTableData(
                                id,
                                name,
                                slotMachineType,
                                slotMachineFreeEnableType,
                                freeSpinMaxCount,
                                feverResetType,
                                feverValue,
                                couponItemId,
                                couponItemValue,
                                useItemId,
                                useItemValue,
                                exchangeRatio,
                                exchangeItemId,
                                betGroup);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public SlotMachineBaseTableData GetData(int id)
        {
            SlotMachineBaseTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        private Dictionary<int, SlotMachineBaseTableData> _dict;
    }
}
