﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class SlotMachineBetTableData
    {
        public SlotMachineBetTableData(int id, string name, int betGroup, long useItemValue, long neddItemValue)
        {
            Id = id;
            Name = name;
            BetGroup = betGroup;
            UseItemValue = useItemValue;
            NeddItemValue = neddItemValue;
        }

        public readonly int Id;
        public readonly string Name;
        public readonly int BetGroup;
        public readonly long UseItemValue;
        public readonly long NeddItemValue;
    }

    #region Override from Table<SlotMachineBetTable, SlotMachineBetTable.FieldType>
    public class SlotMachineBetTable : Table<SlotMachineBetTable, SlotMachineBetTable.FieldType>
    {
        public enum FieldType
        {
            id,
            name,
            betGroup,
            useItemValue,
            needItemValue,
        }

        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, SlotMachineBetTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                string name = enumerator.ParseString(FieldType.name);
                int betGroup = enumerator.ParseInt32(FieldType.betGroup);
                long useItemValue = enumerator.ParseInt64(FieldType.useItemValue);
                long needItemValue = enumerator.ParseInt64(FieldType.needItemValue);



                var data = new SlotMachineBetTableData(
                                id,
                                name,                               
                                betGroup,
                                useItemValue,
                                needItemValue);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public SlotMachineBetTableData GetData(int id)
        {
            SlotMachineBetTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public SlotMachineBetTableData GetData(int group, long value)
        {
            List<KeyValuePair<int, SlotMachineBetTableData>> dataList = _dict.Where(x => x.Value.BetGroup == group).ToList();

            for (int i = dataList.Count - 1; i >= 0; i--)
            {
                if (dataList[i].Value.NeddItemValue <= value)
                    return dataList[i].Value;
            }
            return null;
        }

        public List<SlotMachineBetTableData> GetDatas(int group)
        {
            List<KeyValuePair<int, SlotMachineBetTableData>> dataList = _dict.Where(x => x.Value.BetGroup == group).ToList();

            List<SlotMachineBetTableData> _list = new List<SlotMachineBetTableData>();

            for (int i = 0; i < dataList.Count; i++)
            {
                _list.Add(dataList[i].Value);
            }
            return _list;
        }

        private Dictionary<int, SlotMachineBetTableData> _dict;
    }
}
