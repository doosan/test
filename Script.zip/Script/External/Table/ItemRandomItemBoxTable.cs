﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class ItemRandomItemBoxTableData
    {
        public ItemRandomItemBoxTableData(int id, string name, int itemBaseId, int rewardItemBaseId, long randomMinValue)
        {
            Id = id;
            Name = name;
            ItemBaseId = itemBaseId;
            RewardItemBaseId = rewardItemBaseId;
            RandomMinValue = randomMinValue;
        }

        public readonly int Id;
        public readonly string Name;
        public readonly int ItemBaseId;
        public readonly int RewardItemBaseId;
        public readonly long RandomMinValue;
    }

    #region Override from Table<ItemRandomItemBoxTable, ItemRandomItemBoxTable.FieldType>
    public class ItemRandomItemBoxTable : Table<ItemRandomItemBoxTable, ItemRandomItemBoxTable.FieldType>
    {
        public enum FieldType
        {
            id,
            name,
            itemBaseId,
            rewardItemBaseId,
            randomMinValue,
        }
        
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, ItemRandomItemBoxTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                string name = enumerator.ParseString(FieldType.name);
                int itemBaseId = enumerator.ParseInt32(FieldType.itemBaseId);
                int rewardItemBaseId = enumerator.ParseInt32(FieldType.rewardItemBaseId);
                long randomMinValue = enumerator.ParseInt64(FieldType.randomMinValue);

                var data = new ItemRandomItemBoxTableData(
                        id,
                        name,
                        itemBaseId,
                        rewardItemBaseId,
                        randomMinValue);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public ItemRandomItemBoxTableData GetData(int id)
        {
            ItemRandomItemBoxTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public List<ItemRandomItemBoxTableData> GetDataList(int itemId)
        {
            return _dict.Values.Where(x => x.ItemBaseId == itemId).ToList();
        }

        private Dictionary<int, ItemRandomItemBoxTableData> _dict;
    }
}
