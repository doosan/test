﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class GameVoiceTableData
    {
        public GameVoiceTableData(int id, string name, int voiceGroup, eVoiceType voiceType, int voiceSubType, string soundResource, int voiceRandomCount)
        {
            Id = id;
            Name = name;
            VoiceGroup = voiceGroup;
            VoiceType = voiceType;
            VoiceSubType = voiceSubType;
            SoundResource = soundResource;
            VoiceRandomCount = voiceRandomCount;
        }

        public readonly int Id;
        public readonly string Name;
        public readonly int VoiceGroup;
        public readonly eVoiceType VoiceType;
        public readonly int VoiceSubType;
        public readonly string SoundResource;
        public readonly int VoiceRandomCount;
    }

    public class GameVoiceTable : Table<GameVoiceTable, GameVoiceTable.FieldType>
    {
        public enum FieldType
        {
            id,
            name,
            voiceGroup,
            voiceType,
            voiceSubType,
            soundResouce,
            voiceRandomCount
        }

        #region Override from Table<GameSoundTable, GameSoundTable.FieldType>
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, GameVoiceTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                string name = enumerator.ParseString(FieldType.name);
                int voiceGroup = enumerator.ParseInt32(FieldType.voiceGroup);
                eVoiceType voiceType = (eVoiceType)enumerator.ParseInt32(FieldType.voiceType);
                int voiceSubType = enumerator.ParseInt32(FieldType.voiceSubType);
                string soundResource = enumerator.ParseString(FieldType.soundResouce);
                int voiceRandomCount = enumerator.ParseInt32(FieldType.voiceRandomCount);
                
                var data = new GameVoiceTableData(
                    id,
                    name,
                    voiceGroup,
                    voiceType,
                    voiceSubType,
                    soundResource,
                    voiceRandomCount);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {

            get { return _dict.Count; }
        }

        public GameVoiceTableData GetData(int id)
        {
            GameVoiceTableData soundData;
            return _dict.TryGetValue(id, out soundData) ? soundData : null;
        }

        public List<GameVoiceTableData> GetGroupList(int groupid)
        {
            return _dict.Values.Where(x => x.VoiceGroup == groupid).ToList();
        }

        private Dictionary<int, GameVoiceTableData> _dict;
    }
}
