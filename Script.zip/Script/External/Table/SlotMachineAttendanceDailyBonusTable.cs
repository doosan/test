﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class SlotMachineAttendanceDailyBonusTableData
    {
        public SlotMachineAttendanceDailyBonusTableData(int id, string name, int dayCount, float dayBonusValue)
        {
            Id = id;
            Name = name;
            DayCount = dayCount;
            DayBonusValue = dayBonusValue;
        }

        public readonly int Id;
        public readonly string Name;
        public readonly int DayCount;
        public readonly float DayBonusValue;
    }

    #region Override from Table<SlotMachineAttendanceDailyBonusTable, SlotMachineAttendanceDailyBonusTable.FieldType>
    public class SlotMachineAttendanceDailyBonusTable : Table<SlotMachineAttendanceDailyBonusTable, SlotMachineAttendanceDailyBonusTable.FieldType>
    {
        public enum FieldType
        {
            id,
            name,
            dayCount,
            dayBonusValue,
        }

        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, SlotMachineAttendanceDailyBonusTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                string name = enumerator.ParseString(FieldType.name);
                int dayCount = enumerator.ParseInt32(FieldType.dayCount);
                float dayBonusValue = enumerator.ParseSingle(FieldType.dayBonusValue);


                var data = new SlotMachineAttendanceDailyBonusTableData(
                                id,
                                name,
                                dayCount,
                                dayBonusValue);
                                

                dict.Add(id, data);
            }
            
            _dict = dict.OrderBy(x => x.Value.DayCount).ToDictionary(x => x.Key, x => x.Value);
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public int MaxDayCount
        {
            get { return _dict.Max(x => x.Value.DayCount); }
        }

        public SlotMachineAttendanceDailyBonusTableData GetData(int id)
        {
            SlotMachineAttendanceDailyBonusTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public float GetBounsValue(int dayCount)
        {
            return _dict.Where(x => x.Value.DayCount == dayCount).FirstOrDefault().Value.DayBonusValue;
        }

        public List<SlotMachineAttendanceDailyBonusTableData> dictList
        {
            get
            {
                return _dict.Values.ToList();
            }
        }

        private Dictionary<int, SlotMachineAttendanceDailyBonusTableData> _dict;
    }
}
