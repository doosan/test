﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class ShopPayTMRewardTableData
    {
        public ShopPayTMRewardTableData(int id, string name, long needLP, long exchangePayTM, int effectLevel, int payTMExchangeShareRewardId, int orderNumber, bool useOnOffType)
        {
            Id = id;
            Name = name;
            NeedLP = needLP;
            ExchangePayTM = exchangePayTM;
            EffectLevel = effectLevel - 1;
            PayTMExchangeShareRewardId = payTMExchangeShareRewardId;
            OrderNumber = orderNumber;
            UseOnOffType = useOnOffType;
        }

        public readonly int Id;
        public readonly string Name;
        public readonly long NeedLP;
        public readonly long ExchangePayTM;
        public readonly int EffectLevel;
        public readonly int PayTMExchangeShareRewardId;
        public readonly int OrderNumber;
        public readonly bool UseOnOffType;
    }

    #region Override from Table<ShopPayTMRewardTable, ShopPayTMRewardTable.FieldType>
    public class ShopPayTMRewardTable : Table<ShopPayTMRewardTable, ShopPayTMRewardTable.FieldType>
    {
        public enum FieldType
        {
            id,
            name,
            needLP,
            exchangePayTM,
            effectLevel,
            payTMExchangeShareRewardId,
            orderNumber,
            useOnOffType
        }

        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, ShopPayTMRewardTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                string name = enumerator.ParseString(FieldType.name);
                long needLP = enumerator.ParseInt64(FieldType.needLP);
                long exchangePayTM = enumerator.ParseInt64(FieldType.exchangePayTM);
                int effectLevel = enumerator.ParseInt32(FieldType.effectLevel);
                int payTMExchangeShareRewardId = enumerator.ParseInt32(FieldType.payTMExchangeShareRewardId);
                int orderNumber = enumerator.ParseInt32(FieldType.orderNumber);
                bool useOnOffType = enumerator.ParseBoolean(FieldType.useOnOffType);


                var data = new ShopPayTMRewardTableData(
                    id,
                    name,
                    needLP,
                    exchangePayTM,
                    effectLevel,
                    payTMExchangeShareRewardId,
                    orderNumber,
                    useOnOffType);

                dict.Add(id, data);
            }

            _dict = dict;

            int lastOrder = GetDataOnList().Max(x => x.OrderNumber);

            LastIndex = _dict.Values.Where(x => x.OrderNumber == lastOrder).FirstOrDefault().Id;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public int LastIndex { get; private set; } = 0;

        public ShopPayTMRewardTableData GetData(int id)
        {
            ShopPayTMRewardTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public List<ShopPayTMRewardTableData> GetDataList()
        {
            return _dict.Values.OrderBy(x => x.OrderNumber).ToList();
        }

        public List<ShopPayTMRewardTableData> GetDataOnList()
        {
            return _dict.Values.Where(x => x.UseOnOffType).OrderBy(x => x.OrderNumber).ToList();
        }

        public int GetNextValidIndex(int id)
        {
            int lastOrder = GetDataOnList().Max(x => x.OrderNumber);
            int startOrder = id == 0 ? 1 :  _dict[id].OrderNumber + 1;

            List<ShopPayTMRewardTableData> onList = GetDataOnList();

            for (int i = startOrder; i <= lastOrder; i++)
            {
                ShopPayTMRewardTableData stData = onList.Where(x => x.OrderNumber == i).FirstOrDefault();

                if (stData != null)
                    return stData.Id;
            }

            return id;
        }

        public int GetValidIndex(int id)
        {
            if (id == 0)
                return 0;

            List<ShopPayTMRewardTableData> onList = GetDataOnList();
            
            int startOrder = _dict[id].OrderNumber;

            //if (lastOrder <= startOrder)
            //    return onList.Where(x => x.OrderNumber == lastOrder).FirstOrDefault().Id;

            for (int i = startOrder; i >= 0; i--)
            {
                ShopPayTMRewardTableData stData = onList.Where(x => x.OrderNumber == i).FirstOrDefault();

                if (stData != null)
                    return stData.Id;
            }

            return 0;
        }

        private Dictionary<int, ShopPayTMRewardTableData> _dict;
    }
}
