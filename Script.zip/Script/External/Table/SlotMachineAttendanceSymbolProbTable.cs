﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class SlotMachineAttendanceSymbolProbTableData
    {
        public SlotMachineAttendanceSymbolProbTableData(int id, string name, int realNumber, eAttendanceSymbolType attendanceSymbolType,
            eAttendanceCalcSignType attendanceCalcSignType, int attendanceGroupNumber, int exchangeItemId, long symbolValue, float symbolProb, string contentsIcon)
        {
            Id = id;
            Name = name;
            RealNumber = realNumber;
            AttendanceSymbolType = attendanceSymbolType;
            AttendanceCalcSignType = attendanceCalcSignType;
            AttendanceGroupNumber = attendanceGroupNumber;
            ExchangeItemId = exchangeItemId;
            SymbolValue = symbolValue;
            SymbolProb = symbolProb;
            ContentsIcon = contentsIcon;
        }

        public readonly int Id;
        public readonly string Name;
        public readonly int RealNumber;
        public readonly eAttendanceSymbolType AttendanceSymbolType;
        public readonly eAttendanceCalcSignType AttendanceCalcSignType;
        public readonly int AttendanceGroupNumber;
        public readonly int ExchangeItemId;
        public readonly long SymbolValue;
        public readonly float SymbolProb;
        public readonly string ContentsIcon;
    }

    #region Override from Table<SlotMachineAttendanceSymbolProbTable, SlotMachineAttendanceSymbolProbTable.FieldType>
    public class SlotMachineAttendanceSymbolProbTable : Table<SlotMachineAttendanceSymbolProbTable, SlotMachineAttendanceSymbolProbTable.FieldType>
    {
        public enum FieldType
        {
            id,
            name,
            realNumber,
            attendanceSymbolType,
            attendanceCalcSignType,
            attendanceGroupNumber,
            exchangeItemId,
            symbolValue,
            symbolProb,
            contentsIcon,
        }

        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, SlotMachineAttendanceSymbolProbTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                string name = enumerator.ParseString(FieldType.name);
                
                int realNumber = enumerator.ParseInt32(FieldType.realNumber);
                eAttendanceSymbolType attendanceSymbolType = (eAttendanceSymbolType)enumerator.ParseInt32(FieldType.attendanceSymbolType);
                eAttendanceCalcSignType attendanceCalcSignType = (eAttendanceCalcSignType)enumerator.ParseInt32(FieldType.attendanceCalcSignType);
                int attendanceGroupNumber = enumerator.ParseInt32(FieldType.attendanceGroupNumber);
                int exchangeItemId = enumerator.ParseInt32(FieldType.exchangeItemId);
                long symbolValue = enumerator.ParseInt64(FieldType.symbolValue);
                float symbolProb = enumerator.ParseSingle(FieldType.symbolProb);
                string contentsIcon = enumerator.ParseString(FieldType.contentsIcon);

                var data = new SlotMachineAttendanceSymbolProbTableData(
                                id,
                                name,
                                realNumber,
                                attendanceSymbolType,
                                attendanceCalcSignType,
                                attendanceGroupNumber,
                                exchangeItemId,
                                symbolValue,
                                symbolProb,
                                contentsIcon);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public SlotMachineAttendanceSymbolProbTableData GetData(int id)
        {
            SlotMachineAttendanceSymbolProbTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        //public SlotMachineAttendanceSymbolProbTableData GetData(eAttendanceSymbolType type)
        //{
        //    return _dict.Where(x => x.Value.AttendanceSymbolType == type).FirstOrDefault().Value;
        //}

        public List<SlotMachineAttendanceSymbolProbTableData> GetDataList(eAttendanceSymbolType type)
        {
            return _dict.Values.Where(x => x.AttendanceSymbolType == type).ToList();
        }

        private Dictionary<int, SlotMachineAttendanceSymbolProbTableData> _dict;
    }
}
