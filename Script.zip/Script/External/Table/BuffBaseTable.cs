﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class BuffBaseTableData
    {
        public BuffBaseTableData(int id, string name, int buffDescId, eBuffType buffType, eBuffDataDuplicateType dataDuplicateType, float buffValue, eBuffDurationType durationType, 
                                 int durationMinute, int groupNumberList, string buffIconImage, List<int> applyGameModeDataIdList, bool applyPrivateMode)
        {
            Id = id;
            Name = name;
            BuffDescId = buffDescId;
            BuffType = buffType;
            DataDuplicateType = dataDuplicateType;
            BuffValue = buffValue;
            DurationType = durationType;
            DurationMinute = durationMinute;
            GroupNumberList = groupNumberList;
            BuffIconImage = buffIconImage;
            ApplyGameModeDataIdList = applyGameModeDataIdList;
            ApplyPrivateMode = applyPrivateMode;
            //LimitBootChannal = limitBootChannal;
        }

        public readonly int Id;
        public readonly string Name;
        public readonly int BuffDescId;
        public readonly eBuffType BuffType;
        public readonly eBuffDataDuplicateType DataDuplicateType;
        public readonly float BuffValue;
        public readonly eBuffDurationType DurationType;
        public readonly int DurationMinute;
        public readonly int GroupNumberList;
        public readonly string BuffIconImage;
        public readonly List<int> ApplyGameModeDataIdList;
        public readonly bool ApplyPrivateMode;
        //public readonly long LimitBootChannal;
    }

    #region Override from Table<BuffBaseTable, BuffBaseTable.FieldType>
    public class BuffBaseTable : Table<BuffBaseTable, BuffBaseTable.FieldType>
    {
        public enum FieldType
        {
            id,
            name,
            buffDescId,
            buffType,
            dataDuplicateType,
            buffValue,
            durationType,
            durationMinute,
            groupNumberList,
            buffIconImage,
            applyGameModeDataIdList,
            applyPrivateMode,
           // limitBootChannal,
        }
        
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, BuffBaseTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                string name= enumerator.ParseString(FieldType.name);
                int buffDescId = enumerator.ParseInt32(FieldType.buffDescId);
                eBuffType buffType = (eBuffType)enumerator.ParseInt32(FieldType.buffType);
                eBuffDataDuplicateType dataDuplicateType = (eBuffDataDuplicateType)enumerator.ParseInt32(FieldType.dataDuplicateType);
                float buffValue = enumerator.ParseSingle(FieldType.buffValue);
                eBuffDurationType durationType = (eBuffDurationType)enumerator.ParseInt32(FieldType.durationType);
                int durationMinute = enumerator.ParseInt32(FieldType.durationMinute);
                int groupNumberList = enumerator.ParseInt32(FieldType.groupNumberList);
                string buffIconImage = enumerator.ParseString(FieldType.buffIconImage);
                List<int> applyGameModeDataIdList = enumerator.ParseInt32Array(FieldType.applyGameModeDataIdList);
                bool applyPrivateMode = enumerator.ParseBoolean(FieldType.applyPrivateMode);
              //  long limitBootChannal = enumerator.ParseInt64(FieldType.limitBootChannal);

                var data = new BuffBaseTableData(
                        id,
                        name,
                        buffDescId,
                        buffType,
                        dataDuplicateType,
                        buffValue,
                        durationType,
                        durationMinute,
                        groupNumberList,
                        buffIconImage,
                        applyGameModeDataIdList,
                        applyPrivateMode);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public BuffBaseTableData GetData(int id)
        {
            BuffBaseTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        private Dictionary<int, BuffBaseTableData> _dict;
    }
}
