﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class GameShortCutTableData
    {
        public GameShortCutTableData(int id, int nameId)
        {
            Id = id;
            NameId = nameId;
        }

        public readonly int Id;
        public readonly int NameId;
    }

    public class GameShortCutTable : Table<GameShortCutTable, GameShortCutTable.FieldType>
    {
        public enum FieldType
        {
            id,
            nameId,
        }

        #region Override from Table<GameShortCutTable, GameShortCutTable.FieldType>
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, GameShortCutTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                int nameId = enumerator.ParseInt32(FieldType.nameId);

                var data = new GameShortCutTableData(
                        id,
                        nameId);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {

            get { return _dict.Count; }
        }

        public GameShortCutTableData GetData(int id)
        {
            GameShortCutTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public List<GameShortCutTableData> GetDataList()
        {
            return _dict.Values.ToList();
        }

        private Dictionary<int, GameShortCutTableData> _dict;
    }
}
