﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class GameAdRewardTableData
    {
        public GameAdRewardTableData(int id, int adLevel, int rewardItemId, long rewardValue, int rewardLevel, int rewardDescId, string rewardIcon)
        {
            Id = id;            
            AdLevel = adLevel;
            RewardItemId = rewardItemId;
            RewardValue = rewardValue;
            RewardLevel = rewardLevel;
            RewardDescId = rewardDescId;
            RewardIcon = rewardIcon;
        }

        public readonly int Id;
        public readonly int AdLevel;
        public readonly int RewardItemId;
        public readonly long RewardValue;
        public readonly long RewardLevel;
        public readonly int RewardDescId;
        public readonly string RewardIcon;
    }

    public class GameAdRewardTable : Table<GameAdRewardTable, GameAdRewardTable.FieldType>
    {
        public enum FieldType
        {
            id,
            adLevel,
            rewardItemId,
            rewardValue,
            rewardLevel,
            rewardDescId,
            rewardIcon,
        }

        #region Override from Table<GameAdRewardTable, GameAdRewardTable.FieldType>
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, GameAdRewardTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                int adLevel = enumerator.ParseInt32(FieldType.adLevel);
                int rewardItemId = enumerator.ParseInt32(FieldType.rewardItemId);
                int rewardValue = enumerator.ParseInt32(FieldType.rewardValue);
                int rewardLevel = enumerator.ParseInt32(FieldType.rewardLevel);
                int rewardDescId = enumerator.ParseInt32(FieldType.rewardDescId);
                string rewardIcon = enumerator.ParseString(FieldType.rewardIcon);

                var data = new GameAdRewardTableData(
                        id,
                        adLevel,
                        rewardItemId,
                        rewardValue,
                        rewardLevel,
                        rewardDescId,
                        rewardIcon);

                dict.Add(id, data);
            }

            _dict = dict;
            maxLevel = _dict.Values.Max(x => x.AdLevel);
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public GameAdRewardTableData GetData(int id)
        {
            GameAdRewardTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public List<GameAdRewardTableData> GetDataList()
        {
            return _dict.Values.ToList().OrderBy(x => x.AdLevel).ToList();
        }

        public int maxLevel = 0;
        private Dictionary<int, GameAdRewardTableData> _dict;
    }
}

