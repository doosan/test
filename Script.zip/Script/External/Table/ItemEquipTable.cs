﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class ItemEquipTableData
    {
        public ItemEquipTableData(int id, string name, int itemBaseId, string[] femalePrefab, string[] malePrefab)
        {
            Id = id;
            Name = name;
            ItemBaseId = itemBaseId;
            FemalePrefab = femalePrefab;
            MalePrefab = malePrefab;
        }

        public readonly int Id;
        public readonly string Name;
        public readonly int ItemBaseId;

        public readonly string[] FemalePrefab;
        public readonly string[] MalePrefab;
    }

    #region Override from Table<ItemEquipTable, ItemEquipTable.FieldType>
    public class ItemEquipTable : Table<ItemEquipTable, ItemEquipTable.FieldType>
    {
        public enum FieldType
        {
            id,
            name,
            itemBaseId,
            femaleNormal,
            femaleThin,
            femaleFat,
            femaleHealthy,
            maleNormal,
            maleThin,
            maleFat,
            maleHealthy,
        }
        
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, ItemEquipTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                string name = enumerator.ParseString(FieldType.name);
                int itemBaseId = enumerator.ParseInt32(FieldType.itemBaseId);
                string[] femalePrefab = { enumerator.ParseString(FieldType.femaleNormal), enumerator.ParseString(FieldType.femaleThin), enumerator.ParseString(FieldType.femaleFat), enumerator.ParseString(FieldType.femaleHealthy) };
                string[] malePrefab = { enumerator.ParseString(FieldType.maleNormal), enumerator.ParseString(FieldType.maleThin), enumerator.ParseString(FieldType.maleFat), enumerator.ParseString(FieldType.maleHealthy) };

                var data = new ItemEquipTableData(
                        id,
                        name,
                        itemBaseId,
                        femalePrefab,
                        malePrefab);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public ItemEquipTableData GetData(int id)
        {
            ItemEquipTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public string GetPrefab(int itemId, eCharacterType characterType, eCharacterBodyType characterBodyType)
        {
            var data = _dict.Where(x => x.Value.ItemBaseId == itemId).FirstOrDefault();

            if(characterType == eCharacterType.TYPE_MAN)
                return data.Value.MalePrefab[(int)characterBodyType - 1];
            if (characterType == eCharacterType.TYPE_WOMAN)
                return data.Value.FemalePrefab[(int)characterBodyType - 1];

            return string.Empty;
        }

        private Dictionary<int, ItemEquipTableData> _dict;
    }
}
