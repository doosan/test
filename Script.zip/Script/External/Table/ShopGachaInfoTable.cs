﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class ShopGachaInfoTableData
    {
        public ShopGachaInfoTableData(int id, string name, int gachaNameId, eGachaInfoType gachaInfoType, bool displayOnOff, int gachaInfoSortOrder, string gachaMenuIcon)
        {
            Id = id;
            Name = name;
            GachaNameId = gachaNameId;
            GachaInfoType = gachaInfoType;
            DisplayOnOff = displayOnOff;
            GachaInfoSortOrder = gachaInfoSortOrder;
            GachaMenuIcon = gachaMenuIcon;
        }

        public readonly int Id;
        public readonly string Name;
        public readonly int GachaNameId;
        public readonly eGachaInfoType GachaInfoType;
        public readonly bool DisplayOnOff;
        public readonly int GachaInfoSortOrder;
        public readonly string GachaMenuIcon;
    }

    #region Override from Table<ShopGachaInfoTable, ShopGachaInfoTable.FieldType>
    public class ShopGachaInfoTable : Table<ShopGachaInfoTable, ShopGachaInfoTable.FieldType>
    {
        public enum FieldType
        {
            id,
            name,
            gachaNameId,
            gachaInfoType,
            displayOnOff,
            gachaInfoSortOrder,
            gachaMenuIcon,
        }

        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, ShopGachaInfoTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                string name = enumerator.ParseString(FieldType.name);
                int gachaNameId = enumerator.ParseInt32(FieldType.gachaNameId);
                eGachaInfoType gachaInfoType = (eGachaInfoType)enumerator.ParseInt32(FieldType.gachaInfoType);
                bool displayOnOff = enumerator.ParseBoolean(FieldType.displayOnOff);
                int gachaInfoSortOrder = enumerator.ParseInt32(FieldType.gachaInfoSortOrder);               
                string gachaMenuIcon = enumerator.ParseString(FieldType.gachaMenuIcon);

                var data = new ShopGachaInfoTableData(
                    id,
                    name,
                    gachaNameId,
                    gachaInfoType,
                    displayOnOff,
                    gachaInfoSortOrder,
                    gachaMenuIcon);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public ShopGachaInfoTableData GetData(int id)
        {
            ShopGachaInfoTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        private Dictionary<int, ShopGachaInfoTableData> _dict;
    }
}
