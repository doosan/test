﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class GameHighOrLowTableData
    {
        public GameHighOrLowTableData(int id,  eItemType playItemType, long minItemValue, long betMin, long betMax, long betButton1, long betButton2, long betButton3, long betButton4,
            int setRewardValue, float highCommision, float lowCommision, eHighOrLowSevenType sevenType, int sevenSetRewardValue)
        {
            Id = id;
            PlayItemType = playItemType;
            MinItemValue = minItemValue;
            BetMin = betMin;
            BetMax = betMax; 
            BetButtons[0] = betButton1;
            BetButtons[1] = betButton2;
            BetButtons[2] = betButton3;
            BetButtons[3] = betButton4;
            SetRewardValue = setRewardValue;
            HighCommision = highCommision;
            LowCommision = lowCommision;
            SevenType = sevenType;
            SevenSetRewardValue = sevenSetRewardValue;
        }

        public readonly int Id;
        public readonly eItemType PlayItemType;
        public readonly long MinItemValue;
        public readonly long BetMin;
        public readonly long BetMax;
        public readonly long[] BetButtons = new long[4];
        public readonly int SetRewardValue;
        public readonly float HighCommision;
        public readonly float LowCommision;
        public readonly eHighOrLowSevenType SevenType;
        public readonly int SevenSetRewardValue;
    }

    public class GameHighOrLowTable : Table<GameHighOrLowTable, GameHighOrLowTable.FieldType>
    {
        public enum FieldType
        {
            id,
            playItemType,
            minItemValue,
            betMin,
            betMax,
            betButton1,
            betButton2,
            betButton3,
            betButton4,
            setRewardValue,
            highCommision,
            lowCommision,
            sevenType,
            sevenSetRewardValue,
        }

        #region Override from Table<GameHighOrLowTable, GameHighOrLowTable.FieldType>
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, GameHighOrLowTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                eItemType playItemType = (eItemType)enumerator.ParseInt32(FieldType.playItemType);
                long minItemValue = enumerator.ParseInt64(FieldType.minItemValue);
                long betMin = enumerator.ParseInt64(FieldType.betMin);
                long betMax = enumerator.ParseInt64(FieldType.betMax);
                long betButton1 = enumerator.ParseInt64(FieldType.betButton1);
                long betButton2 = enumerator.ParseInt64(FieldType.betButton2);
                long betButton3 = enumerator.ParseInt64(FieldType.betButton3);
                long betButton4 = enumerator.ParseInt64(FieldType.betButton4);
                int setRewardValue = enumerator.ParseInt32(FieldType.setRewardValue);
                float highCommision = enumerator.ParseSingle(FieldType.highCommision);
                float lowCommision = enumerator.ParseSingle(FieldType.lowCommision);
                eHighOrLowSevenType sevenType = (eHighOrLowSevenType)enumerator.ParseInt32(FieldType.sevenType);
                int sevenSetRewardValue = enumerator.ParseInt32(FieldType.sevenSetRewardValue);

                var data = new GameHighOrLowTableData(
                            id,
                            playItemType,
                            minItemValue,
                            betMin,
                            betMax,
                            betButton1,
                            betButton2,
                            betButton3,
                            betButton4,
                            setRewardValue,
                            highCommision,
                            lowCommision,
                            sevenType,
                            sevenSetRewardValue);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public GameHighOrLowTableData GetData(int id)
        {
            GameHighOrLowTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        private Dictionary<int, GameHighOrLowTableData> _dict;
    }
}

