﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class GameIndianPokerTableData
    {
        public GameIndianPokerTableData(int id, int gameModeId, ePlayLPType playLPType, long minChipLimit, long bootLP, long maxChipLimit, float emoticonPriceMultiple, 
            int dealerId, long dealerTip, string roomPrefab, List<int> entryItemIdList, long penaltyValue, long penaltyDeposit)
        {
            Id = id;
            GameModeId = gameModeId;
            PlayLPType = playLPType;
            MinChipLimit = minChipLimit;
            BootLP = bootLP;
            MaxChipLimit = maxChipLimit;
            EmoticonPriceMultiple = emoticonPriceMultiple;
            DealerId = dealerId;
            DealerTip = dealerTip;
            RoomPrefab = roomPrefab;
            EntryItemIdList = entryItemIdList;
            PenaltyValue = penaltyValue;
            PenaltyDeposit = penaltyDeposit;
        }

        public readonly int Id;
        public readonly int GameModeId;
        public readonly ePlayLPType PlayLPType;
        public readonly long MinChipLimit;
        public readonly long BootLP;
        public readonly long MaxChipLimit;        
        public readonly float EmoticonPriceMultiple;
        public readonly int DealerId;
        public readonly long DealerTip;
        public readonly string RoomPrefab;
        public readonly float LPBoosterEvent;
        public readonly List<int> EntryItemIdList;
        public readonly long PenaltyValue;
        public readonly long PenaltyDeposit;

    }

    public class GameIndianPokerTable : Table<GameIndianPokerTable, GameIndianPokerTable.FieldType>
    {
        public enum FieldType
        {
            id,
            gameModeId,
            playLPType,
            minChipLimit,
            bootLP,
            maxChipLimit,
            emoticonPriceMultiple,
            dealerId,
            dealerTip,
            roomPrefab,
            entryItemIdList,
            penaltyValue,
            penaltyDeposit,
        }

        #region Override from Table<GameRoomTable, GameRoomTable.FieldType>
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, GameIndianPokerTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                int gameModeId = enumerator.ParseInt32(FieldType.gameModeId);
                ePlayLPType playLPType = (ePlayLPType)enumerator.ParseInt32(FieldType.playLPType);
                long minChipLimit = enumerator.ParseInt64(FieldType.minChipLimit);
                long bootLP = enumerator.ParseInt64(FieldType.bootLP);
                long maxChipLimit = enumerator.ParseInt64(FieldType.maxChipLimit);
                float emoticonPriceMultiple = enumerator.ParseSingle(FieldType.emoticonPriceMultiple);
                int dealerId = enumerator.ParseInt32(FieldType.dealerId);                
                long dealerTip = enumerator.ParseInt64(FieldType.dealerTip);
                string roomPrefab = enumerator.ParseString(FieldType.roomPrefab);
                List<int> entryItemIdList = enumerator.ParseInt32Array(FieldType.entryItemIdList);
                long penaltyValue = enumerator.ParseInt64(FieldType.penaltyValue);
                long penaltyDeposit = enumerator.ParseInt64(FieldType.penaltyDeposit);


                var data = new GameIndianPokerTableData(
                        id,
                        gameModeId,
                        playLPType,
                        minChipLimit,
                        bootLP,
                        maxChipLimit,
                        emoticonPriceMultiple,
                        dealerId,
                        dealerTip,
                        roomPrefab,
                        entryItemIdList,
                        penaltyValue,
                        penaltyDeposit);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public GameIndianPokerTableData GetData(int id)
        {
            GameIndianPokerTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }
       
        //public GameIndianPokerTableData GetIndex(int gameModeId, long value)
        //{
        //    List<GameIndianPokerTableData> dataList = _dict.Values.Where(x => x.GameModeId == gameModeId).OrderBy(x => x.BootChip).ToList();

        //    for (int i = dataList.Count - 1; i >= 0; i--)
        //    {
        //        if (dataList[i].MinChipLimit <= value)
        //            return dataList[i];
        //    }
        //    return null;
        //}
       
        //public List<GameIndianPokerTableData> GetDataList(int gameModeId)
        //{
        //    return _dict.Values.Where(x => x.GameModeId == gameModeId).OrderBy(x => x.BootChip).ToList();
        //}

        //public List<string> RoomPrefabList
        //{
        //    get
        //    {
        //        List<string> _list = new List<string>();

        //        foreach(var p in _dict)
        //        {
        //            if(!_list.Contains(p.Value.RoomPrefab))
        //                _list.Add(p.Value.RoomPrefab);
        //        }

        //        return _list;
        //    }
        //}

        private Dictionary<int, GameIndianPokerTableData> _dict;

    }
}
