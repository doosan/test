﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class GameResearchTableData
    {
        public GameResearchTableData(int id, eResearchType researchType, int questionId, int answerId1, int answerId2, int answerId3, long rewardChipValue, int rewardItemId, int rewardItemValue)
        {
            Id = id;
            ResearchType = researchType;
            QuestionId = questionId;
            AnswerId1 = answerId1;
            AnswerId2 = answerId2;
            AnswerId3 = answerId3;
            RewardChipValue = rewardChipValue;
            RewardItemId = rewardItemId;
            RewardItemValue = rewardItemValue;
        }

        public readonly int Id;
        public readonly eResearchType ResearchType;
        public readonly int QuestionId;
        public readonly int AnswerId1;
        public readonly int AnswerId2;
        public readonly int AnswerId3;
        public readonly long RewardChipValue;
        public readonly int RewardItemId;
        public readonly int RewardItemValue;
    }

    public class GameResearchTable : Table<GameResearchTable, GameResearchTable.FieldType>
    {
        public enum FieldType
        {
            id,
            researchType,
            questionId,
            answerId1,
            answerId2,
            answerId3,
            rewardChipValue,
            rewardItemId,
            rewardItemValue,
        }

        #region Override from Table<GameResearchTable, GameResearchTable.FieldType>
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, GameResearchTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                eResearchType researchType = (eResearchType)enumerator.ParseInt32(FieldType.researchType);
                int questionId = enumerator.ParseInt32(FieldType.questionId);
                int answerId1 = enumerator.ParseInt32(FieldType.answerId1);
                int answerId2 = enumerator.ParseInt32(FieldType.answerId2);
                int answerId3 = enumerator.ParseInt32(FieldType.answerId3);
                long rewardChipValue = enumerator.ParseInt64(FieldType.rewardChipValue);
                int rewardItemId = enumerator.ParseInt32(FieldType.rewardItemId);
                int rewardItemValue = enumerator.ParseInt32(FieldType.rewardItemValue);

                var data = new GameResearchTableData(
                        id,
                        researchType,
                        questionId,
                        answerId1,
                        answerId2,
                        answerId3,
                        rewardChipValue,
                        rewardItemId,
                        rewardItemValue);


                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public GameResearchTableData GetData(int id)
        {
            GameResearchTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public GameResearchTableData GetData(eResearchType type, List<int> idList)
        {
            var _list = _dict.Where(x => x.Value.ResearchType == type).ToList();

            if (idList==null)
                return _list[0].Value;

            for (int i = 0; i < _list.Count; i++)
            {
                if (!idList.Contains(_list[i].Value.Id))
                    return _list[i].Value;
            }

            return null;
        }

        private Dictionary<int, GameResearchTableData> _dict;
    }
}
