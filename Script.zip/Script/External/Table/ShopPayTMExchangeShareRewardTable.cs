﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class ShopPayTMExchangeShareRewardTableData
    {
        public ShopPayTMExchangeShareRewardTableData(int id, string name, int rewardItemId, long rewardItemValue, string shareURL)
        {
            Id = id;
            Name = name;
            RewardItemId = rewardItemId;
            RewardItemValue = rewardItemValue;
            ShareURL = shareURL;
        }

        public readonly int Id;
        public readonly string Name;
        public readonly int RewardItemId;
        public readonly long RewardItemValue;
        public readonly string ShareURL;
    }

    #region Override from Table<ShopPayTMExchangeShareRewardTable, ShopPayTMExchangeShareRewardTable.FieldType>
    public class ShopPayTMExchangeShareRewardTable : Table<ShopPayTMExchangeShareRewardTable, ShopPayTMExchangeShareRewardTable.FieldType>
    {
        public enum FieldType
        {
            id,
            name,
            rewardItemId,
            rewardItemValue,
            shareURL
        }

        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, ShopPayTMExchangeShareRewardTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                string name = enumerator.ParseString(FieldType.name);
                int rewardItemId = enumerator.ParseInt32(FieldType.rewardItemId);
                long rewardItemValue = enumerator.ParseInt64(FieldType.rewardItemValue);
                string shareURL = enumerator.ParseString(FieldType.shareURL);

                var data = new ShopPayTMExchangeShareRewardTableData(
                    id,
                    name,
                    rewardItemId,
                    rewardItemValue,
                    shareURL);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public ShopPayTMExchangeShareRewardTableData GetData(int id)
        {
            ShopPayTMExchangeShareRewardTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public List<ShopPayTMExchangeShareRewardTableData> GetDataList()
        {
            return _dict.Values.ToList();
        }

        private Dictionary<int, ShopPayTMExchangeShareRewardTableData> _dict;
    }
}