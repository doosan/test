﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class SlotMachineSymbolProbTableData
    {
        public SlotMachineSymbolProbTableData(int id, string name, eSlotMachineSymbolType symbolType, string contentsIcon)
        {
            Id = id;
            Name = name;
            SymbolType = symbolType;
            ContentsIcon = contentsIcon;
        }

        public readonly int Id;
        public readonly string Name;
        public readonly eSlotMachineSymbolType SymbolType;
        public readonly string ContentsIcon;
    }

    #region Override from Table<SlotMachineSymbolProbTable, SlotMachineSymbolProbTable.FieldType>
    public class SlotMachineSymbolProbTable : Table<SlotMachineSymbolProbTable, SlotMachineSymbolProbTable.FieldType>
    {
        public enum FieldType
        {
            id,
            name,
            symbolType,
            contentsIcon,
        }

        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, SlotMachineSymbolProbTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                string name = enumerator.ParseString(FieldType.name);
                eSlotMachineSymbolType symbolType = (eSlotMachineSymbolType)enumerator.ParseInt32(FieldType.symbolType);
                string contentsIcon = enumerator.ParseString(FieldType.contentsIcon);


                var data = new SlotMachineSymbolProbTableData(
                                id,
                                name,
                                symbolType,
                                contentsIcon);
                                

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public SlotMachineSymbolProbTableData GetData(int id)
        {
            SlotMachineSymbolProbTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public SlotMachineSymbolProbTableData GetRandomData()
        {
            return _dict.OrderBy(n => Random.value).FirstOrDefault().Value;
        }

        private Dictionary<int, SlotMachineSymbolProbTableData> _dict;
    }
}
