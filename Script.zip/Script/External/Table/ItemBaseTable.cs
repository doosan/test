﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class ItemBaseTableData
    {
        public ItemBaseTableData(int id, string name, int itemNameId, int itemDescId, eItemType itemType, int itemSubType, int itemTypeNameId, int safeVolumeId,
                                eItemGradeType itemGradeType, eItemLimitType timeLimitType, int timeLimitMinute, eItemStackType stackType,
                                int stackMaxCount, bool sellType, long sellChip, string itemModeling, string itemIcon, long needLP, long exchangePayTM,
                                eUseItemIconEffectType useItemIconEffect, int payTMExchangeShareRewardId, int buffBaseId, int postAllGetType, bool usePeriodLimitType, long luckyPointTicketValue)
        {
            Id = id;
            Name = name;
            ItemNameId = itemNameId;
            ItemDescId = itemDescId;
            ItemType = itemType;
            ItemSubType = itemSubType;
            ItemTypeNameId = itemTypeNameId;
            SafeVolumeId = safeVolumeId;
            ItemGradeType = itemGradeType;
            TimeLimitType = timeLimitType;
            TimeLimitMinute = timeLimitMinute;
            StackType = stackType;
            StackMaxCount = stackMaxCount;
            SellType = sellType;
            SellChip = sellChip;
            ItemModeling = itemModeling;
            ItemIconName = itemIcon;
            NeedLP = needLP;
            ExchangePayTM = exchangePayTM;
            UseItemIconEffect = useItemIconEffect;
            PayTMExchangeShareRewardId = payTMExchangeShareRewardId;
            BuffBaseId = buffBaseId;
            PostAllGetType = postAllGetType;
            UsePeriodLimitType = usePeriodLimitType;
            LuckyPointTicketValue = luckyPointTicketValue;
        }

        public readonly int Id;
        public readonly string Name;
        public readonly int ItemNameId;
        public readonly int ItemDescId;
        public readonly eItemType ItemType;
        public readonly int ItemSubType;
        public readonly int ItemTypeNameId;
        public readonly int SafeVolumeId;
        public readonly eItemGradeType ItemGradeType;
        public readonly eItemLimitType TimeLimitType;
        public readonly int TimeLimitMinute;
        public readonly eItemStackType StackType;
        public readonly int StackMaxCount;
        public readonly bool SellType;
        public readonly long SellChip;
        public readonly long NeedLP;
        public readonly long ExchangePayTM;
        public readonly string ItemModeling;
        public readonly string ItemIconName;
        public readonly eUseItemIconEffectType UseItemIconEffect;
        public readonly int PayTMExchangeShareRewardId;
        public readonly int BuffBaseId;
        public readonly int PostAllGetType;
        public readonly bool UsePeriodLimitType;
        public readonly long LuckyPointTicketValue;

        public string ItemIcon
        {
            get
            {
                string str = ItemIconName;

                int avartaDataId = AcUserInfo._netData_user._avatarDataId == -1 ? (int)GameConfigTable.Instance.GetConfigValue(eConfigType.TYPE_DEFAULTCHARACTERID) : AcUserInfo._netData_user._avatarDataId;
                
                if (ItemType == eItemType.TYPE_COSTUME && ItemSubType == (int)eItemEquipType.TYPE_TOP)
                {
                    str = str + (GameCharacterTable.Instance.GetData(avartaDataId).CharacterType == eCharacterType.TYPE_WOMAN ? "_Female" : "_Male");
                }
                return str;
            }
        }
    }

    #region Override from Table<ItemBaseTable, ItemBaseTable.FieldType>
    public class ItemBaseTable : Table<ItemBaseTable, ItemBaseTable.FieldType>
    {
        public enum FieldType
        {
            id,
            name,
            itemNameId,
            itemDescId,
            itemType,
            itemSubType,
            itemTypeNameId,
            safeVolumeId,
            itemGradeType,
            timeLimitType,
            timeLimitMinute,
            stackType,
            stackMaxCount,
            sellType,
            sellChip,
            itemModeling,
            itemIcon,
            needLP,
            exchangePayTM,
            useItemIconEffect,
            payTMExchangeShareRewardId,
            buffBaseId,
            postAllGetType,
            usePeriodLimitType,
            luckyPointTicketValue,
        }
        
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, ItemBaseTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                string name= enumerator.ParseString(FieldType.name);
                int itemNameId = enumerator.ParseInt32(FieldType.itemNameId);
                int itemDescId = enumerator.ParseInt32(FieldType.itemDescId);
                eItemType itemType = (eItemType)enumerator.ParseInt32(FieldType.itemType);
                int itemSubType = enumerator.ParseInt32(FieldType.itemSubType);
                int itemTypeNameId = enumerator.ParseInt32(FieldType.itemTypeNameId);
                int safeVolumeId = enumerator.ParseInt32(FieldType.safeVolumeId);
                eItemGradeType itemGradeType = (eItemGradeType)enumerator.ParseInt32(FieldType.itemGradeType);
                eItemLimitType timeLimitType = (eItemLimitType)enumerator.ParseInt32(FieldType.timeLimitType);
                int timeLimitMinute= enumerator.ParseInt32(FieldType.timeLimitMinute);
                eItemStackType stackType= (eItemStackType)enumerator.ParseInt32(FieldType.stackType);
                int stackMaxCount= enumerator.ParseInt32(FieldType.stackMaxCount);
                bool sellType= enumerator.ParseBoolean(FieldType.sellType);
                long sellChip= enumerator.ParseInt64(FieldType.sellChip);
                string itemModeling= enumerator.ParseString(FieldType.itemModeling);
                string itemIcon= enumerator.ParseString(FieldType.itemIcon);
                long needLP = enumerator.ParseInt64(FieldType.needLP);
                long exchangePayTM = enumerator.ParseInt64(FieldType.exchangePayTM);
                eUseItemIconEffectType useItemIconEffect = (eUseItemIconEffectType)enumerator.ParseInt32(FieldType.useItemIconEffect);
                int payTMExchangeShareRewardId = enumerator.ParseInt32(FieldType.payTMExchangeShareRewardId);
                int buffBaseId = enumerator.ParseInt32(FieldType.buffBaseId);
                int postAllGetType = enumerator.ParseInt32(FieldType.postAllGetType);
                bool usePeriodLimitType = enumerator.ParseBoolean(FieldType.usePeriodLimitType);
                long luckyPointTicketValue = enumerator.ParseInt64(FieldType.luckyPointTicketValue);

                var data = new ItemBaseTableData(
                        id,
                        name,
                        itemNameId,
                        itemDescId,
                        itemType,
                        itemSubType,
                        itemTypeNameId,
                        safeVolumeId,
                        itemGradeType,
                        timeLimitType,
                        timeLimitMinute,
                        stackType,
                        stackMaxCount,
                        sellType,
                        sellChip,
                        itemModeling,
                        itemIcon,
                        needLP,
                        exchangePayTM,
                        useItemIconEffect,
                        payTMExchangeShareRewardId,
                        buffBaseId,
                        postAllGetType,
                        usePeriodLimitType,
                        luckyPointTicketValue);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public ItemBaseTableData GetData(int id)
        {
            ItemBaseTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public ItemBaseTableData GetDatabyBuffIndex(int id)
        {
            return _dict.Values.Where(x => x.BuffBaseId == id).FirstOrDefault();
        }

        private Dictionary<int, ItemBaseTableData> _dict;
    }
}
