﻿using System;
using System.Collections.Generic;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{

	public enum Language {

		English,		
        Hindustani,		
	}

	public class StringTable : Table<StringTable, StringTable.FieldType> {

		public static readonly Dictionary<Language, string> Languages = new Dictionary<Language, string>
        {
			{ Language.English, "English" },
			{ Language.Hindustani, "Hindustani" },		
		};

		public enum FieldType {

			UniqueID,            
			English,
            Hindustani,
        }

		#region Overrides
		protected override void OnLoad(RecordEnumerator enumerator) {

			if (!_language.HasValue)
				throw new InvalidOperationException("Load(string, Language) 메서드를 사용하여 로드해야합니다.");

			FieldType languageFieldType;
			switch (_language)
            {
			case Language.English: languageFieldType = FieldType.English; break;		

			default:
				languageFieldType = FieldType.English;
				break;
			}

			var dict = new Dictionary<string, string>();

			while (enumerator.MoveNext()) {

				string uniqueId = enumerator.ParseString(FieldType.UniqueID);
				string text = enumerator.ParseString(languageFieldType).Replace("\\n", "\n");

				if (string.IsNullOrEmpty(uniqueId))
					throw new InvalidFieldException(FieldType.UniqueID, "빈 필드일 수 없습니다.");

				if (dict.ContainsKey(uniqueId))
					throw new InvalidFieldException(FieldType.UniqueID, uniqueId, "키 값은 중복될 수 없습니다.");

				if (string.IsNullOrEmpty(text))
					text = string.Format("STRING_EMPTY({0})", uniqueId);

				dict.Add(uniqueId, text);
			}

			_dict = dict;
		}

		protected override void OnUnload() {

			_dict = null;
		}
		#endregion

		public bool Load(string rootSuffix, Language language) {

			if (IsLoaded)
				return false;

			_language = language;

			if (Load(rootSuffix))
				return true;

			_language = null;
			return false;
		}

		public string GetText(string uniqueId) {

			if (uniqueId == null)
				throw new ArgumentNullException("uniqueId");

			string result;
			return _dict != null && _dict.TryGetValue(uniqueId, out result)
					? result
					: string.Format("STRING_NOT_FOUND({0})", uniqueId);
		}

		private Language? _language;
		private Dictionary<string, string> _dict;
	}
}
