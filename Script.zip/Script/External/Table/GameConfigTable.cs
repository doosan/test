﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class GameConfigTableData
    {
        public GameConfigTableData(int id, eConfigType configType, float configValue)
        {
            Id = id;
            ConfigType = configType;
            ConfigValue = configValue;
        }

        public readonly int Id;
        public readonly eConfigType ConfigType;
        public readonly float ConfigValue;
    }

    public class GameConfigTable : Table<GameConfigTable, GameConfigTable.FieldType>
    {
        public enum FieldType
        {
            id,
            configType,
            configValue,
        }

        #region Override from Table<GameConfigTable, GameConfigTable.FieldType>
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, GameConfigTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                eConfigType configType = (eConfigType)enumerator.ParseInt32(FieldType.configType);
                float configValue = enumerator.ParseSingle(FieldType.configValue);

                var data = new GameConfigTableData(
                        id,
                        configType,
                        configValue);

                dict.Add(id, data);

                if (configType == eConfigType.TYPE_LUCKYPOINTDECIMALPOINT)
                    ConvertNumber.unitCount = (int)configValue;
                if (configType == eConfigType.TYPE_LUCKYPOINTVIEWDECIMALPOINT)
                    ConvertNumber.SetViewCount((int)configValue);
                if (configType == eConfigType.TYPE_SILVERLUCKYPOINTEXCHANGE)
                    ConvertNumber.slpCount = (int)configValue;
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {

            get { return _dict.Count; }
        }

        public GameConfigTableData GetData(int id)
        {
            GameConfigTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public float GetConfigValue(eConfigType type)
        {
            return _dict.Where(x => x.Value.ConfigType == type).FirstOrDefault().Value.ConfigValue;
        }

        private Dictionary<int, GameConfigTableData> _dict;
    }
}
