﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class MissionBaseTableData
    {
        public MissionBaseTableData(int id, int missionDescId, int missionNameId, eMissionType missionType, eMissionAccrueType missionAccrueType, int sortOrderNumber, int precedeMissionId, int followUpMissionId,
            eMissionGameSlotCheckType gameSlotCheckType, eMissionGameType gameType, eMissionMainCompleteType missionMainCompleteType, int missionSubCompleteType1, int missionSubCompleteType2, long missionCompleteValue,
            int missionRewardItemId, long missionRewardItemValue, string missionIcon, bool shareRewardOnOff, int shareRewardItemId, long shareRewardItemValue, int shareDescId)
        {
            Id = id;
            MissionNameId = missionNameId;
            MissionDescId = missionDescId;
            MissionType = missionType;
            MissionAccrueType = missionAccrueType;
            SortOrderNumber = sortOrderNumber;
            PrecedeMissionId = precedeMissionId;
            FollowUpMissionId = followUpMissionId;
            GameSlotCheckType = gameSlotCheckType;
            GameType = gameType;
            MissionMainCompleteType = missionMainCompleteType;
            MissionSubCompleteType1 = missionSubCompleteType1;
            MissionSubCompleteType2 = missionSubCompleteType2;
            MissionCompleteValue = missionCompleteValue;
            MissionRewardItemId = missionRewardItemId;
            MissionRewardItemValue = missionRewardItemValue;
            MissionIcon = missionIcon;
            ShareRewardOnOff = shareRewardOnOff;
            ShareRewardItemId = shareRewardItemId;
            ShareRewardItemValue = shareRewardItemValue;
            ShareDescId = shareDescId;
        }

        public readonly int Id;
        public readonly int MissionNameId;
        public readonly int MissionDescId;
        public readonly eMissionType MissionType;
        public readonly eMissionAccrueType MissionAccrueType;
        public readonly int SortOrderNumber;
        public readonly int PrecedeMissionId;
        public readonly int FollowUpMissionId;
        public readonly eMissionGameSlotCheckType GameSlotCheckType;
        public readonly eMissionGameType GameType;
        public readonly eMissionMainCompleteType MissionMainCompleteType;
        public readonly int MissionSubCompleteType1;
        public readonly int MissionSubCompleteType2;
        public readonly long MissionCompleteValue;
        public readonly int MissionRewardItemId;
        public readonly long MissionRewardItemValue;
        public readonly string MissionIcon;
        public readonly bool ShareRewardOnOff;
        public readonly int ShareRewardItemId;
        public readonly long ShareRewardItemValue;
        public readonly int ShareDescId;
    }

    public class MissionBaseTable : Table<MissionBaseTable, MissionBaseTable.FieldType>
    {
        public enum FieldType
        {
            id,
            missionNameId,
            missionDescId,
            missionType,
            missionAccrueType,
            sortOrderNumber,
            precedeMissionId,
            followUpMissionId,
            gameSlotCheckType,
            gameType,
            missionMainCompleteType,
            missionSubCompleteType1,
            missionSubCompleteType2,
            missionCompleteValue,
            missionRewardItemId,
            missionRewardItemValue,
            missionIcon,
            shareRewardOnOff,
            shareRewardItemId,
            shareRewardItemValue,
            shareDescId,
        }

        #region Override from Table<MissionBaseTable, MissionBaseTable.FieldType>
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, MissionBaseTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                int missionNameId = enumerator.ParseInt32(FieldType.missionNameId);
                int missionDescId = enumerator.ParseInt32(FieldType.missionDescId);
                eMissionType missionType = (eMissionType)enumerator.ParseInt32(FieldType.missionType);
                eMissionAccrueType missionAccrueType = (eMissionAccrueType)enumerator.ParseInt32(FieldType.missionAccrueType);
                int sortOrderNumber = enumerator.ParseInt32(FieldType.sortOrderNumber);
                int precedeMissionId = enumerator.ParseInt32(FieldType.precedeMissionId);
                int followUpMissionId = enumerator.ParseInt32(FieldType.followUpMissionId);
                eMissionGameSlotCheckType gameSlotCheckType = (eMissionGameSlotCheckType)enumerator.ParseInt32(FieldType.gameType);
                eMissionGameType gameType = (eMissionGameType)enumerator.ParseInt32(FieldType.id);
                eMissionMainCompleteType missionMainCompleteType = (eMissionMainCompleteType)enumerator.ParseInt32(FieldType.missionMainCompleteType);
                int missionSubCompleteType1 = enumerator.ParseInt32(FieldType.missionSubCompleteType1);
                int missionSubCompleteType2 = enumerator.ParseInt32(FieldType.missionSubCompleteType2);
                long missionCompleteValue = enumerator.ParseInt64(FieldType.missionCompleteValue);
                int missionRewardItemId = enumerator.ParseInt32(FieldType.missionRewardItemId);
                long missionRewardItemValue = enumerator.ParseInt64(FieldType.missionRewardItemValue);
                string missionIcon = enumerator.ParseString(FieldType.missionIcon);
                bool shareRewardOnOff = enumerator.ParseBoolean(FieldType.shareRewardOnOff);
                int shareRewardItemId = enumerator.ParseInt32(FieldType.shareRewardItemId);
                long shareRewardItemValue = enumerator.ParseInt64(FieldType.shareRewardItemValue);
                int shareDescId = enumerator.ParseInt32(FieldType.shareDescId);

                var data = new MissionBaseTableData(
                        id,
                        missionNameId,
                        missionDescId,
                        missionType,
                        missionAccrueType,
                        sortOrderNumber,
                        precedeMissionId,
                        followUpMissionId,
                        gameSlotCheckType,
                        gameType,
                        missionMainCompleteType,
                        missionSubCompleteType1,
                        missionSubCompleteType2,
                        missionCompleteValue,
                        missionRewardItemId,
                        missionRewardItemValue,
                        missionIcon,
                        shareRewardOnOff,
                        shareRewardItemId,
                        shareRewardItemValue,
                        shareDescId);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public MissionBaseTableData GetData(int id)
        {
            MissionBaseTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public List<MissionBaseTableData> GetDataList()
        {
            return _dict.Values.OrderBy(x => x.SortOrderNumber).ToList();
        }


        private Dictionary<int, MissionBaseTableData> _dict;
    }
}
