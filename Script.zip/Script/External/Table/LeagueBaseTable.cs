﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class LeagueBaseTableData
    {
        public LeagueBaseTableData(int id, int leagueNameId, eLeagueGradeType leagueGradeType,
                                   long leagueBasePrizeChip, int leagueLimitNumber, int gradeUpValue,
                                   int gradeDownValue, string leagueIcon, bool leagueUse)
        {
            Id = id;            
            LeagueNameId = leagueNameId;
            LeagueGradeType = leagueGradeType;
            LeagueBasePrizeChip = leagueBasePrizeChip;
            LeagueLimitNumber = leagueLimitNumber;
            GradeUpValue = gradeUpValue;
            GradeDownValue = gradeDownValue;
            LeagueIcon = leagueIcon;
            LeagueUse = leagueUse;
        }

        public readonly int Id;
        public readonly int LeagueNameId;
        public readonly eLeagueGradeType LeagueGradeType;
        public readonly long LeagueBasePrizeChip;
        public readonly int LeagueLimitNumber;
        public readonly int GradeUpValue;
        public readonly int GradeDownValue;
        public readonly string LeagueIcon;
        public readonly bool LeagueUse;
    }

    #region Override from Table<LeagueBaseTable, LeagueBaseTable.FieldType>
    public class LeagueBaseTable : Table<LeagueBaseTable, LeagueBaseTable.FieldType>
    {
        public enum FieldType
        {
            id,
            leagueNameId,
            leagueGradeType,
            leagueBasePrizeChip,
            leagueLimitNumber,
            gradeUpValue,
            gradeDownValue,
            leagueIcon,
            leagueUse
        }

        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, LeagueBaseTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                int leagueNameId = enumerator.ParseInt32(FieldType.leagueNameId);
                eLeagueGradeType leagueGradeType = (eLeagueGradeType)enumerator.ParseInt32(FieldType.leagueGradeType);                
                long leagueBasePrizeChip = enumerator.ParseInt64(FieldType.leagueBasePrizeChip);
                int leagueLimitNumber = enumerator.ParseInt32(FieldType.leagueLimitNumber);
                int gradeUpValue = enumerator.ParseInt32(FieldType.gradeUpValue);
                int gradeDownValue = enumerator.ParseInt32(FieldType.gradeDownValue);
                string leagueIcon = enumerator.ParseString(FieldType.leagueIcon);
                bool leagueUse = enumerator.ParseBoolean(FieldType.leagueUse);
                var data = new LeagueBaseTableData(
                       id,
                       leagueNameId,
                       leagueGradeType,                       
                       leagueBasePrizeChip,
                       leagueLimitNumber,
                       gradeUpValue,
                       gradeDownValue,
                       leagueIcon,
                       leagueUse);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public LeagueBaseTableData GetData(int id)
        {
            LeagueBaseTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public LeagueBaseTableData GetData(eLeagueGradeType type)
        {
            return _dict.Where(x => x.Value.LeagueGradeType == type).FirstOrDefault().Value;
        }

        private Dictionary<int, LeagueBaseTableData> _dict;
    }
}

