﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class TutorialTextTableData
    {
        public TutorialTextTableData(int id, int stringGroup, int stringId, int nextStringId)
        {
            Id = id;
            StringGroup = stringGroup;
            StringId = stringId;
            NextStringId = nextStringId;
        }

        public readonly int Id;
        public readonly int StringGroup;
        public readonly int StringId;
        public readonly int NextStringId;

    }

    public class TutorialTextTable : Table<TutorialTextTable, TutorialTextTable.FieldType>
    {
        public enum FieldType
        {
            id,
            stringGroup,
            stringId,
            nextStringId,
        }

        #region Override from Table<TutorialTextTable, TutorialTextTable.FieldType>
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, TutorialTextTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                int stringGroup = enumerator.ParseInt32(FieldType.stringGroup);
                int stringId = enumerator.ParseInt32(FieldType.stringId);
                int nextStringId = enumerator.ParseInt32(FieldType.nextStringId);

                var data = new TutorialTextTableData(
                            id,
                            stringGroup,
                            stringId,
                            nextStringId);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public TutorialTextTableData GetData(int id)
        {
            TutorialTextTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }
        
        private Dictionary<int, TutorialTextTableData> _dict;
    }
}
