﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class ItemPieceCraftTableData
    {
        public ItemPieceCraftTableData(int id, string name, int itemBaseId, int needMaterialItemCount, int carftResultItemBaseId, int craftResultItemCount)
        { 
            Id = id;
            Name = name;
            ItemBaseId = itemBaseId;
            NeedMaterialItemCount = needMaterialItemCount;
            CarftResultItemBaseId = carftResultItemBaseId;
            CraftResultItemCount = craftResultItemCount;
        }

        public readonly int Id;
        public readonly string Name;
        public readonly int ItemBaseId;
        public readonly int NeedMaterialItemCount;
        public readonly int CarftResultItemBaseId;
        public readonly int CraftResultItemCount;
    }

    #region Override from Table<ItemPieceCraftTable, ItemPieceCraftTable.FieldType>
    public class ItemPieceCraftTable : Table<ItemPieceCraftTable, ItemPieceCraftTable.FieldType>
    {
        public enum FieldType
        {
            id,
            name,
            itemBaseId,
            needMaterialItemCount,
            craftResultItemBaseId,            

            craftResultItemCount
        }
        
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, ItemPieceCraftTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                string name = enumerator.ParseString(FieldType.name);
                int itemBaseId = enumerator.ParseInt32(FieldType.itemBaseId);
                int needMaterialItemCount = enumerator.ParseInt32(FieldType.needMaterialItemCount);
                int craftResultItemBaseId = enumerator.ParseInt32(FieldType.craftResultItemBaseId);
                int craftResultItemCount = enumerator.ParseInt32(FieldType.craftResultItemCount);


                var data = new ItemPieceCraftTableData(
                        id,
                        name,
                        itemBaseId,
                        needMaterialItemCount,
                        craftResultItemBaseId,
                        craftResultItemCount);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public ItemPieceCraftTableData GetData(int id)
        {
            ItemPieceCraftTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public ItemPieceCraftTableData GetDatainItemId(int id)
        {

            return _dict.Where(x => x.Value.ItemBaseId == id).FirstOrDefault().Value;
        }

        private Dictionary<int, ItemPieceCraftTableData> _dict;
    }
}
