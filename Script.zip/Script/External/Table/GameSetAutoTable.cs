﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class GameSetAutoTableData
    {
        public GameSetAutoTableData(int id, eSetAutoSettingType setAutoSettingType, int setAutoSettingTypeId, int setAutoSettingTypedescriptId,
                                    eSetAutoType setAutoType, int nameId, int descriptId)
        {
            Id = id;
            SetAutoSettingType = setAutoSettingType;
            SetAutoSettingTypeId = setAutoSettingTypeId;
            SetAutoSettingTypedescriptId = setAutoSettingTypedescriptId;
            SetAutoType = setAutoType;
            NameId = nameId;
            DescriptId = descriptId;
        }

        public readonly int Id;
        public readonly eSetAutoSettingType SetAutoSettingType;
        public readonly int SetAutoSettingTypeId;
        public readonly int SetAutoSettingTypedescriptId;
        public readonly eSetAutoType SetAutoType;
        public readonly int NameId;
        public readonly int DescriptId;
    }
    public class GameSetAutoTable : Table<GameSetAutoTable, GameSetAutoTable.FieldType>
    {
        public enum FieldType
        {
            id,
            setAutoSettingType,
            setAutoSettingTypeId,
            setAutoSettingTypedescriptId,
            setAutoType,
            nameId,
            descriptId,
        }

        #region Override from Table<GameModeTable, GameModeTable.FieldType>
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, GameSetAutoTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                eSetAutoSettingType setAutoSettingType = (eSetAutoSettingType)enumerator.ParseInt32(FieldType.setAutoSettingType);
                int setAutoSettingTypeId = enumerator.ParseInt32(FieldType.setAutoSettingTypeId);
                int setAutoSettingTypedescriptId = enumerator.ParseInt32(FieldType.setAutoSettingTypedescriptId);
                eSetAutoType setAutoType = (eSetAutoType)enumerator.ParseInt32(FieldType.setAutoType);
                int nameId = enumerator.ParseInt32(FieldType.nameId);
                int descriptId = enumerator.ParseInt32(FieldType.descriptId);

                var data = new GameSetAutoTableData(
                        id,
                        setAutoSettingType,
                        setAutoSettingTypeId,
                        setAutoSettingTypedescriptId,
                        setAutoType,
                        nameId,
                        descriptId);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public GameSetAutoTableData GetData(int id)
        {
            GameSetAutoTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public GameSetAutoTableData GetData(eSetAutoType setAutoType)
        {
            return _dict.Where(x => x.Value.SetAutoType == setAutoType).FirstOrDefault().Value;
        }

        public GameSetAutoTableData GetData(eSetAutoSettingType setAutoSettingType)
        {
            return _dict.Where(x => x.Value.SetAutoSettingType == setAutoSettingType).FirstOrDefault().Value;
        }

        private Dictionary<int, GameSetAutoTableData> _dict;
    }
}
