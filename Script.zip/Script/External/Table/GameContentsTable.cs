﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class GameContentsTableData
    {
        public GameContentsTableData(int id, int gameContentsNameId, string contentsIcon, eContentMainLockType contensEnum, eContensButtonType contensButtonType, int sortNumber, bool useOnOffType)
        {
            Id = id;
            GameContentsNameId = gameContentsNameId;
            ContentsIcon = contentsIcon;
            ContensEnum = contensEnum;
            ContensButtonType = contensButtonType;
            SortNumber = sortNumber;
            UseOnOffType = useOnOffType;
        }

        public readonly int Id;
        public readonly int GameContentsNameId;
        public readonly string ContentsIcon;
        public readonly eContentMainLockType ContensEnum;
        public readonly eContensButtonType ContensButtonType;
        public readonly int SortNumber;
        public readonly bool UseOnOffType;
    }

    public class GameContentsTable : Table<GameContentsTable, GameContentsTable.FieldType>
    {
        public enum FieldType
        {
            id,
            gameContentsNameId,
            contentsIcon,
            contensEnum,
            contensButtonType,
            sortNumber,
            useOnOffType,
        }

        #region Override from Table<GameContentsable, GameContentsable.FieldType>
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, GameContentsTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                int gameContentsNameId = enumerator.ParseInt32(FieldType.gameContentsNameId);
                string contentsIcon = enumerator.ParseString(FieldType.gameContentsNameId);
                eContentMainLockType contensEnum = (eContentMainLockType)enumerator.ParseInt32(FieldType.contensEnum);
                eContensButtonType contensButtonType = (eContensButtonType)enumerator.ParseInt32(FieldType.contensButtonType);
                int sortNumber = enumerator.ParseInt32(FieldType.sortNumber);
                bool useOnOffType = enumerator.ParseBoolean(FieldType.useOnOffType);

                var data = new GameContentsTableData(
                        id,
                         gameContentsNameId,
                         contentsIcon,
                         contensEnum,
                         contensButtonType,
                         sortNumber,
                         useOnOffType);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public GameContentsTableData GetData(int id)
        {
            GameContentsTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public List<GameContentsTableData> GetDataList()
        {
            return _dict.Values.OrderBy(x => x.SortNumber).ToList();
        }

        private Dictionary<int, GameContentsTableData> _dict;
    }
}
