﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class GameOptionTableData
    {
        public GameOptionTableData(int id, string name, int optionNameId, eOptionType optionType, int optionValue, string optionString)
        {
            Id = id;
            Name = name;
            OptionNameId = optionNameId;
            OptionType = optionType;
            OptionValue = optionValue;
            OptionString = optionString;
        }

        public readonly int Id;
        public readonly string Name;
        public readonly int OptionNameId;
        public readonly eOptionType OptionType;
        public readonly int OptionValue;
        public readonly string OptionString;
    }

    public class GameOptionTable : Table<GameOptionTable, GameOptionTable.FieldType>
    {
        public enum FieldType
        {
            id,
            name,
            optionNameId,
            optionType,
            optionValue,
            optionString,
        }

        #region Override from Table<GameOptionTable, GameOptionTable.FieldType>
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, GameOptionTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                string name = enumerator.ParseString(FieldType.name);
                int optionNameId = enumerator.ParseInt32(FieldType.optionNameId);
                eOptionType optionType = (eOptionType)enumerator.ParseInt32(FieldType.optionType);
                int optionValue = enumerator.ParseInt32(FieldType.optionValue);
                string optionString = enumerator.ParseString(FieldType.optionString);


                var data = new GameOptionTableData(
                                id,
                                name,
                                optionNameId,
                                optionType,
                                optionValue,
                                optionString);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public GameOptionTableData GetData(int id)
        {
            GameOptionTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public GameOptionTableData GetData(eOptionType type)
        {
            return _dict.Where(x => x.Value.OptionType == type).FirstOrDefault().Value;
        }

        private Dictionary<int, GameOptionTableData> _dict;
    }
}
