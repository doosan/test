﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using System.Text;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class LocalizationProhibitedWordTableData
    {
        public LocalizationProhibitedWordTableData(int id, string word)
        {
            Id = id;
            Word = word;
        }

        public readonly int Id;
        public readonly string Word;
    }

    public class LocalizationProhibitedWordTable: Table<LocalizationProhibitedWordTable, LocalizationProhibitedWordTable.FieldType>
    {
        public enum FieldType
        {
            id,
            word,
        }

        #region Override from Table<LocalizationSentenceTable, LocalizationSentenceTable.FieldType>
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, string>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                string word = enumerator.ParseString(FieldType.word).Replace("\\n", "\n");
                //var data = new LocalizationProhibitedWordTableData(
                //       id,
                //       word);
                dict.Add(id, word);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public bool ContainString(string str)
        {
            return _dict.Any(x => str.ToLower().Contains(x.Value));
        }

        public string GetString(string str)
        {
            string strstr = str.ToLower();

            var _data = _dict.Where(x => strstr.Contains(x.Value)).ToList();

            if (_data.Count == 0)
                return str;
            else
            {
                List<int> indexList = new List<int>();
                for (int j = 0; j < _data.Count; j++)
                {
                    int k = strstr.IndexOf(_data[j].Value);

                    for (int m = 0; m < _data[j].Value.Length; m++)
                    {
                        if(!indexList.Contains(k + m))
                            indexList.Add(k + m);
                    }

                    //string temp = "";
                    //for (int i = 0; i < _data[j].Value.Length; i++)
                    //    temp = temp + "*";

                    //str = str.Replace(_data[j].Value, temp);
                }

                var tttt = str.ToCharArray();

                

                for (int i = 0; i < indexList.Count; i++)
                {
                    tttt[indexList[i]] = '*';
                }
                

                return GetString(new string(tttt));
            }
        }

        //private Hashtable _dict = new Hashtable();

        private Dictionary<int, string> _dict;
    }
}
