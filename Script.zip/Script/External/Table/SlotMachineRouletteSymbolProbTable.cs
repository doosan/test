﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class SlotMachineRouletteSymbolProbTableData
    {
        public SlotMachineRouletteSymbolProbTableData(int id, string name, int rouletteGroupId, int sortOrder, int rewardItemId, long rewardItemValue, bool feverItem, Color slotColor, string viewData)
        {
            Id = id;
            Name = name;
            RouletteGroupId = rouletteGroupId;
            RouletteGroupId = rouletteGroupId;
            SortOrder = sortOrder;
            RewardItemId = rewardItemId;
            RewardItemValue = rewardItemValue;
            FeverItem = feverItem;
            SlotColor = slotColor;
            ViewData = viewData;
        }

        public readonly int Id;
        public readonly string Name;
        public readonly int RouletteGroupId;
        public readonly int SortOrder;
        public readonly int RewardItemId;
        public readonly long RewardItemValue;
        public readonly bool FeverItem;
        public readonly Color SlotColor;
        public readonly string ViewData;
    }

    #region Override from Table<SlotMachineRouletteSymbolProbTable, SlotMachineRouletteSymbolProbTable.FieldType>
    public class SlotMachineRouletteSymbolProbTable : Table<SlotMachineRouletteSymbolProbTable, SlotMachineRouletteSymbolProbTable.FieldType>
    {
        public enum FieldType
        {
            id,
            name,
            rouletteGroupId,
            sortOrder,
            rewardItemId,
            rewardItemValue,
            feverItem,
            slotColor,
            viewData,
        }

        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, SlotMachineRouletteSymbolProbTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                string name = enumerator.ParseString(FieldType.name);
                int rouletteGroupId = enumerator.ParseInt32(FieldType.rouletteGroupId);
                int sortOrder = enumerator.ParseInt32(FieldType.sortOrder);
                int rewardItemId = enumerator.ParseInt32(FieldType.rewardItemId);
                long rewardItemValue = enumerator.ParseInt64(FieldType.rewardItemValue);
                bool feverItem = enumerator.ParseBoolean(FieldType.feverItem);
                Color slotColor = Color.white;
                ColorUtility.TryParseHtmlString(enumerator.ParseString(FieldType.slotColor), out slotColor);
                string viewData = enumerator.ParseString(FieldType.viewData);

                var data = new SlotMachineRouletteSymbolProbTableData(
                                id,
                                name,
                                rouletteGroupId,
                                sortOrder,
                                rewardItemId,
                                rewardItemValue,
                                feverItem,
                                slotColor,
                                viewData);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public SlotMachineRouletteSymbolProbTableData GetData(int id)
        {
            SlotMachineRouletteSymbolProbTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public List<SlotMachineRouletteSymbolProbTableData> GetDataList()
        {
            return _dict.Values.ToList();
        }

        public List<SlotMachineRouletteSymbolProbTableData> GetDataList(int groupId)
        {
            return _dict.Values.Where(x=>x.RouletteGroupId == groupId).ToList();
        }

        //public SlotMachineRouletteSymbolProbTableData GetRandomData()
        //{
        //    return _dict.OrderBy(n => Random.value).FirstOrDefault().Value;
        //}

        private Dictionary<int, SlotMachineRouletteSymbolProbTableData> _dict;
    }
}
