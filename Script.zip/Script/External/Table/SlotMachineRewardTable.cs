﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class SlotMachineRewardTableData
    {
        public SlotMachineRewardTableData(int id, string name, eSlotMachineSymbolIndexType[] symbolIndexType, int[] symbolIndex, int rewardActionType)
        {
            Id = id;
            Name = name;
            SymbolIndexType = symbolIndexType;
            SymbolIndex = symbolIndex;
            RewardActionType = rewardActionType;
        }

        public readonly int Id;
        public readonly string Name;
        public readonly eSlotMachineSymbolIndexType[] SymbolIndexType;

        public readonly int[] SymbolIndex;
        public readonly int RewardActionType;
        
    }

    #region Override from Table<SlotMachineRewardTable, SlotMachineRewardTable.FieldType>
    public class SlotMachineRewardTable : Table<SlotMachineRewardTable, SlotMachineRewardTable.FieldType>
    {
        public enum FieldType
        {
            id,
            name,
            symbolIndexType1,
            symbolIndex1,
            symbolIndexType2,
            symbolIndex2,
            symbolIndexType3,
            symbolIndex3,
            rewardActionType,
        }

        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, SlotMachineRewardTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                string name = enumerator.ParseString(FieldType.name);
                eSlotMachineSymbolIndexType[] symbolIndexType = new eSlotMachineSymbolIndexType[3];
                int[] symbolIndex = new int[3];

                symbolIndexType[0] = (eSlotMachineSymbolIndexType)enumerator.ParseInt32(FieldType.symbolIndexType1);
                symbolIndexType[1] = (eSlotMachineSymbolIndexType)enumerator.ParseInt32(FieldType.symbolIndexType2);
                symbolIndexType[2] = (eSlotMachineSymbolIndexType)enumerator.ParseInt32(FieldType.symbolIndexType3);

                symbolIndex[0] = enumerator.ParseInt32(FieldType.symbolIndexType1);
                symbolIndex[1] = enumerator.ParseInt32(FieldType.symbolIndexType2);
                symbolIndex[2] = enumerator.ParseInt32(FieldType.symbolIndexType3);

                int rewardActionType = enumerator.ParseInt32(FieldType.rewardActionType);

                var data = new SlotMachineRewardTableData(
                                id,
                                name,
                                symbolIndexType,
                                symbolIndex,
                                rewardActionType);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public SlotMachineRewardTableData GetData(int id)
        {
            SlotMachineRewardTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        private Dictionary<int, SlotMachineRewardTableData> _dict;
    }
}
