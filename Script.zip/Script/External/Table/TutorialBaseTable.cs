﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class TutorialBaseTableData
    {
        public TutorialBaseTableData(int id, int dayNumber, eTutorialBaseClearType tutorialBaseClearType, int clearCount, int rewardItemId,
                                        long rewardItemValue, string ganeshaAction, int ganeshaTextId)
        {
            Id = id;
            DayNumber = dayNumber;
            TutorialBaseClearType = tutorialBaseClearType;
            ClearCount = clearCount;
            RewardItemId = rewardItemId;
            RewardItemValue = rewardItemValue;
            GaneshaAction = ganeshaAction;
            GaneshaTextId = ganeshaTextId;
        }

        public readonly int Id;
        public readonly int DayNumber;
        public readonly eTutorialBaseClearType TutorialBaseClearType;
        public readonly int ClearCount;
        public readonly int RewardItemId;
        public readonly long RewardItemValue;
        public readonly string GaneshaAction;
        public readonly int GaneshaTextId;
    }

    public class TutorialBaseTable : Table<TutorialBaseTable, TutorialBaseTable.FieldType>
    {
        public enum FieldType
        {
            id,
            dayNumber,
            tutorialBaseClearType,
            clearCount,
            rewardItemId,
            rewardItemValue,
            ganeshaAction,
            ganeshaTextId,
        }


        #region Override from Table<TutorialGaneshaTable, TutorialGaneshaTable.FieldType>
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, TutorialBaseTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                int dayNumber = enumerator.ParseInt32(FieldType.dayNumber);
                eTutorialBaseClearType tutorialBaseClearType = (eTutorialBaseClearType)enumerator.ParseInt32(FieldType.tutorialBaseClearType);
                int clearCount = enumerator.ParseInt32(FieldType.clearCount);
                int rewardItemId = enumerator.ParseInt32(FieldType.rewardItemId);
                long rewardItemValue = enumerator.ParseInt64(FieldType.rewardItemValue);
                string ganeshaAction = enumerator.ParseString(FieldType.ganeshaAction);
                int ganeshaTextId = enumerator.ParseInt32(FieldType.ganeshaTextId);                

                var data = new TutorialBaseTableData(
                        id,
                        dayNumber,
                        tutorialBaseClearType,
                        clearCount,
                        rewardItemId,
                        rewardItemValue,
                        ganeshaAction,
                        ganeshaTextId);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public TutorialBaseTableData GetData(int id)
        {
            TutorialBaseTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        private Dictionary<int, TutorialBaseTableData> _dict;
    }
}