﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class LeagueRewardTableData
    {
        public LeagueRewardTableData(int id, int leagueBaseId, int leagueRank, double prizePerValue, long basicRankPrize, eItemType rewardItemType, int rewardItemId, long rewardItemValue)
        {
            Id = id;
            LeagueBaseId = leagueBaseId;
            LeagueRank = leagueRank;
            PrizePerValue = prizePerValue;
            BasicRankPrize = basicRankPrize;
            RewardItemType = rewardItemType;
            RewardItemId = rewardItemId;
            RewardItemValue = rewardItemValue;
        }

        public readonly int Id;
        public readonly int LeagueBaseId;
        public readonly int LeagueRank;
        public readonly double PrizePerValue;
        public readonly long BasicRankPrize;
        public readonly eItemType RewardItemType;
        public readonly int RewardItemId;
        public readonly long RewardItemValue;
    }

    #region Override from Table<LeagueRewardTable, LeagueRewardTable.FieldType>
    public class LeagueRewardTable : Table<LeagueRewardTable, LeagueRewardTable.FieldType>
    {
        public enum FieldType
        {
            id,
            leagueBaseId,
            leagueRank,
            prizePerValue,
            basicRankPrize,
            rewardItemType,
            rewardItemId,
            rewardItemValue
        }

        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, LeagueRewardTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                int leagueBaseId = enumerator.ParseInt32(FieldType.leagueBaseId);
                int leagueRank = enumerator.ParseInt32(FieldType.leagueRank);
                double prizePerValue = enumerator.ParseDouble(FieldType.prizePerValue);
                long basicRankPrize = enumerator.ParseInt64(FieldType.basicRankPrize);
                eItemType rewardItemType = (eItemType)enumerator.ParseInt32(FieldType.rewardItemType);
                int rewardItemId = enumerator.ParseInt32(FieldType.rewardItemId);
                long rewardItemValue = enumerator.ParseInt64(FieldType.rewardItemValue);


                var data = new LeagueRewardTableData(
                       id,
                       leagueBaseId,
                       leagueRank,
                       prizePerValue,
                       basicRankPrize,
                       rewardItemType,
                       rewardItemId,
                       rewardItemValue);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public LeagueRewardTableData GetData(int id)
        {
            LeagueRewardTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public long GetTotalPrize(int leagueId, int rank, long prize)
        {
            LeagueRewardTableData data = _dict.Where(x => x.Value.LeagueBaseId == leagueId && x.Value.LeagueRank == rank).FirstOrDefault().Value;
            long value = data.BasicRankPrize;
            value = value + (long)(prize * data.PrizePerValue);
            return value;
        }

        public long GetBasicPrize(int leagueId, int rank)
        {
            LeagueRewardTableData data = _dict.Where(x => x.Value.LeagueBaseId == leagueId && x.Value.LeagueRank == rank).FirstOrDefault().Value;


            return data.BasicRankPrize;
        }

        public List<LeagueRewardTableData> GetDataList(int leagueId)
        {
            return _dict.Values.Where(x => x.LeagueBaseId == leagueId).ToList();
        }

        private Dictionary<int, LeagueRewardTableData> _dict;
    }
}

