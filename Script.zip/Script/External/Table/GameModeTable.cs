﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class GameModeTableData
    {
        public GameModeTableData(int id, int gameContentsId, int sortNumber, int gameModeNameId, eGameType gameType, eGameCategory gameCategory, eRoomSelectType roomSelectType,
                        bool potLimitOnOffType, bool allInOnOffType, int indianPokerSuffleValue, int blindValue, int blindNoSeenValue, int bettingTimeLimitSeconds, string gameRuleIcon, bool useOnOffType,
                        bool useMultiOnOffType, bool privateOnOffType, Color labelColor, Color nameColor, bool topMenuExit, bool topMenuStandUp, bool topMenuSwitch, bool topMenuShop,
                        bool topMenuSetting, int timeUpAlram, int timeUpAlramSound)
        {
            Id = id;
            GameContentsId = gameContentsId;
            SortNumber = sortNumber;
            GameModeNameId = gameModeNameId;
            GameType = gameType;
            GameCategory = gameCategory;
            RoomSelectType = roomSelectType;
            PotLimitOnOffType = potLimitOnOffType;
            AllInOnOffType = allInOnOffType;
            IndianPokerSuffleValue = indianPokerSuffleValue;
            BlindValue = blindValue;
            BlindNoSeenValue = blindNoSeenValue;
            BettingTimeLimitSeconds = bettingTimeLimitSeconds;
            GameRuleIcon = gameRuleIcon;
            UseOnOffType = useOnOffType;
            UseMultiOnOffType = useMultiOnOffType;
            PrivateOnOffType = privateOnOffType;
            LabelColor = labelColor;
            NameColor = nameColor;

            TopMenuExit = topMenuExit;
            TopMenuStandUp = topMenuStandUp;
            TopMenuSwitch = topMenuSwitch;
            TopMenuShop = topMenuShop;
            TopMenuSetting = topMenuSetting;

            TimeUpAlram = timeUpAlram;
            TimeUpAlramSound = timeUpAlramSound;
        }

        public readonly int Id;
        public readonly int GameContentsId;
        public readonly int SortNumber;
        public readonly int GameModeNameId;
        public readonly eGameType GameType;
        public readonly eGameCategory GameCategory;
        public readonly eRoomSelectType RoomSelectType;
        public readonly bool PotLimitOnOffType;
        public readonly int IndianPokerSuffleValue;
        public readonly int BlindValue;
        public readonly int BlindNoSeenValue;
        public readonly bool AllInOnOffType;
        public readonly int BettingTimeLimitSeconds;
        public readonly string GameRuleIcon;
        public readonly bool UseOnOffType;
        public readonly bool UseMultiOnOffType;
        public readonly bool PrivateOnOffType;
        public readonly Color LabelColor;
        public readonly Color NameColor;

        public readonly bool TopMenuExit;
        public readonly bool TopMenuStandUp;
        public readonly bool TopMenuSwitch;
        public readonly bool TopMenuShop;
        public readonly bool TopMenuSetting;

        public readonly int TimeUpAlram;
        public readonly int TimeUpAlramSound;
    }

    public class GameModeTable : Table<GameModeTable, GameModeTable.FieldType>
    {
        public enum FieldType
        {
            id,
            gameContentsId,
            sortNumber,
            gameModeNameId,
            gameType,
            gameCategory,
            roomSelectType,
            potLimitOnOffType,
            allInOnOffType,
            blindValue,
            blindNoSeenValue,
            indianPokerSuffleValue,
            bettingTimeLimitSeconds,
            gameRuleIcon,
            useOnOffType,
            useMultiOnOffType,
            privateOnOffType,
            labelColor,
            nameColor,
            topMenuExit,
            topMenuStandUp,
            topMenuSwitch,
            topMenuShop,
            topMenuSetting,
            timeUpAlram,
            timeUpAlramSound,
        }


        #region Override from Table<GameModeTable, GameModeTable.FieldType>
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, GameModeTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                int gameContentsId = enumerator.ParseInt32(FieldType.gameContentsId);
                int sortNumber = enumerator.ParseInt32(FieldType.sortNumber);
                int gameModeNameId = enumerator.ParseInt32(FieldType.gameModeNameId);
                eGameType gameType = (eGameType)enumerator.ParseInt32(FieldType.gameType);
                eGameCategory gameCategory = (eGameCategory)enumerator.ParseInt32(FieldType.gameCategory);
                eRoomSelectType roomSelectType = (eRoomSelectType)enumerator.ParseInt32(FieldType.roomSelectType);
                bool potLimitOnOffType = enumerator.ParseBoolean(FieldType.potLimitOnOffType);
                bool allInOnOffType = enumerator.ParseBoolean(FieldType.allInOnOffType);
                int indianPokerSuffleValue = enumerator.ParseInt32(FieldType.indianPokerSuffleValue);                
                int blindValue = enumerator.ParseInt32(FieldType.blindValue);
                int blindNoSeenValue = enumerator.ParseInt32(FieldType.blindNoSeenValue);                
                int bettingTimeLimitSeconds = enumerator.ParseInt32(FieldType.bettingTimeLimitSeconds);
                string gameRuleIcon = enumerator.ParseString(FieldType.gameRuleIcon);
                bool useOnOffType = enumerator.ParseBoolean(FieldType.useOnOffType);
                bool useMultiOnOffType = enumerator.ParseBoolean(FieldType.useMultiOnOffType);
                bool privateOnOffType = enumerator.ParseBoolean(FieldType.privateOnOffType);
                
                bool topMenuExit = enumerator.ParseBoolean(FieldType.topMenuExit);
                bool topMenuStandUp = enumerator.ParseBoolean(FieldType.topMenuStandUp);
                bool topMenuSwitch = enumerator.ParseBoolean(FieldType.topMenuSwitch);
                bool topMenuShop = enumerator.ParseBoolean(FieldType.topMenuShop);
                bool topMenuSetting = enumerator.ParseBoolean(FieldType.topMenuSetting);
                int timeUpAlram = enumerator.ParseInt32(FieldType.timeUpAlram);
                int timeUpAlramSound = enumerator.ParseInt32(FieldType.timeUpAlramSound);


                Color labelColor = Color.white;
                ColorUtility.TryParseHtmlString(enumerator.ParseString(FieldType.labelColor), out labelColor);

                Color nameColor = Color.white;
                ColorUtility.TryParseHtmlString(enumerator.ParseString(FieldType.nameColor), out nameColor);

                var data = new GameModeTableData(
                        id,
                        gameContentsId,
                        sortNumber,
                        gameModeNameId,
                        gameType,
                        gameCategory,
                        roomSelectType,
                        potLimitOnOffType,
                        allInOnOffType,
                        indianPokerSuffleValue,
                        blindValue,
                        blindNoSeenValue,
                        bettingTimeLimitSeconds,
                        gameRuleIcon,
                        useOnOffType,
                        useMultiOnOffType,
                        privateOnOffType,
                        labelColor,
                        nameColor,
                        topMenuExit,
                        topMenuStandUp,
                        topMenuSwitch,
                        topMenuShop,
                        topMenuSetting,
                        timeUpAlram,
                        timeUpAlramSound);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public GameModeTableData GetData(int id)
        {
            GameModeTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public List<GameModeTableData> GetDataList()
        {
            return _dict.Values.ToList();
        }

        public List<GameModeTableData> GetUseDataList()
        {
            return _dict.Values.Where(x=>x.UseOnOffType).ToList();
        }

        public List<GameModeTableData> GetPrivateUseDataList()
        {
            return _dict.Values.Where(x => x.UseOnOffType && x.PrivateOnOffType).ToList();
        }

        public List<GameModeTableData> GetDataList(int gameContentsId, bool main = true)
        {
            if(main)
                return _dict.Values.Where(x => x.GameContentsId == gameContentsId && x.UseOnOffType).OrderBy(x => x.SortNumber).ToList();
            else
                return _dict.Values.Where(x => x.GameContentsId == gameContentsId && x.UseOnOffType && x.UseMultiOnOffType).OrderBy(x => x.SortNumber).ToList();
        }

        public int GetIndex(eGameType type)
        {
            return _dict.Where(x => x.Value.GameType == type).FirstOrDefault().Value.Id;
        }

        public GameModeTableData GetData(eGameType type)
        {
            return _dict.Where(x => x.Value.GameType == type).FirstOrDefault().Value;
        }

        private Dictionary<int, GameModeTableData> _dict;
    }
}

