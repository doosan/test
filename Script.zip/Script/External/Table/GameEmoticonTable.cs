﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class GameEmoticonTableData
    {
        public GameEmoticonTableData(int id, eEmoticonUseTargetType useTarget, eEmoticonType emoticonType, int sortOrder, string emoticonPrefab, string myAni,
            string targetAni, string targetEffect, long emoticonPrice, string emoticonIcon, bool ufoBeamUseType, int voiceChangeGroup)
        {
            Id = id;
            UseTarget = useTarget;
            EmoticonType = emoticonType;
            SortOrder = sortOrder;
            EmoticonPrefab = emoticonPrefab;
            MyAni = myAni;
            TargetAni = targetAni;
            TargetEffect = targetEffect;
            EmoticonPrice = emoticonPrice;
            EmoticonIcon = emoticonIcon;
            UfoBeamUseType = ufoBeamUseType;
            VoiceChangeGroup = voiceChangeGroup;
        }

        public readonly int Id;
        public readonly eEmoticonUseTargetType UseTarget;
        public readonly eEmoticonType EmoticonType;
        public readonly int SortOrder;
        public readonly string EmoticonPrefab;
        public readonly string MyAni;
        public readonly string TargetAni;
        public readonly string TargetEffect;
        public readonly long EmoticonPrice;
        public readonly string EmoticonIcon;
        public readonly bool UfoBeamUseType;
        public readonly int VoiceChangeGroup;
    }

    public class GameEmoticonTable : Table<GameEmoticonTable, GameEmoticonTable.FieldType>
    {
        public enum FieldType
        {
            id,
            useTarget,
            emoticonType,
            sortOrder,
            emoticonPrefab,
            myAni,
            targetAni,
            targetEffect,
            emoticonPrice,
            emoticonIcon,
            ufoBeamUseType,
            voiceChangeGroup
        }

        #region Override from Table<GameEmoticonTable, GameEmoticonTable.FieldType>
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, GameEmoticonTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                eEmoticonUseTargetType useTarget = (eEmoticonUseTargetType)enumerator.ParseInt32(FieldType.useTarget);
                eEmoticonType emoticonType = (eEmoticonType)enumerator.ParseInt32(FieldType.emoticonType);
                int sortOrder = enumerator.ParseInt32(FieldType.sortOrder);
                string emoticonPrefab = enumerator.ParseString(FieldType.emoticonPrefab);
                string myAni = enumerator.ParseString(FieldType.myAni);
                string targetAni = enumerator.ParseString(FieldType.targetAni);
                string targetEffect = enumerator.ParseString(FieldType.targetEffect);
                long emoticonPrice = enumerator.ParseInt64(FieldType.emoticonPrice);
                string emoticonIcon = enumerator.ParseString(FieldType.emoticonIcon);
                bool ufoBeamUseType = enumerator.ParseBoolean(FieldType.ufoBeamUseType);
                int voiceChangeGroup = enumerator.ParseInt32(FieldType.voiceChangeGroup);

                var data = new GameEmoticonTableData(
                                id,
                                useTarget,
                                emoticonType,
                                sortOrder,
                                emoticonPrefab,
                                myAni,
                                targetAni,
                                targetEffect,
                                emoticonPrice,
                                emoticonIcon,
                                ufoBeamUseType,
                                voiceChangeGroup);

                dict.Add(id, data);
            }

            _dict = dict.OrderBy(x=>x.Value.SortOrder).ToDictionary(x=>x.Key, x=>x.Value);
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public GameEmoticonTableData GetData(int id)
        {
            GameEmoticonTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public List<GameEmoticonTableData> GetDataList()
        {
            return _dict.Values.ToList();
        }

        public List<GameEmoticonTableData> GetDatas(eEmoticonUseTargetType type)
        {
            return _dict.Values.Where(x => x.UseTarget == type || x.UseTarget == eEmoticonUseTargetType.TYPE_ALL).ToList();
        }

        public List<GameEmoticonTableData> datas
        {
            get { return _dict.Values.ToList(); }
        }

        private Dictionary<int, GameEmoticonTableData> _dict;
    }
}
