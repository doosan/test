﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class GameCharacterTableData
    {
        public GameCharacterTableData(int id, eCharacterType characterType, bool displayOnOff, eCharacterBodyType characterBodyType, string characterPrefab, int pictureDataId, int characterVoiceGroup)
        {
            Id = id;
            CharacterType = characterType;
            DisplayOnOff = displayOnOff;
            CharacterBodyType = characterBodyType;
            CharacterPrefab = characterPrefab;
            PictureDataId = pictureDataId;
            CharacterVoiceGroup = characterVoiceGroup;
        }

        public readonly int Id;
        public readonly eCharacterType CharacterType;
        public readonly bool DisplayOnOff;
        public readonly eCharacterBodyType CharacterBodyType;
        public readonly string CharacterPrefab;
        public readonly int PictureDataId;
        public readonly int CharacterVoiceGroup;
    }

    public class GameCharacterTable : Table<GameCharacterTable, GameCharacterTable.FieldType>
    {
        public enum FieldType
        {
            id,
            characterType,
            displayOnOff,
            characterBodyType,
            chracterPrefab,            
            pictureDataId,
            characterVoiceGroup,
        }

        #region Override from Table<GameCharacterTable, GameCharacterTable.FieldType>
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, GameCharacterTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                
                eCharacterType characterType = (eCharacterType)enumerator.ParseInt32(FieldType.characterType);
                bool displayOnOff = enumerator.ParseBoolean(FieldType.displayOnOff);
                eCharacterBodyType characterBodyType = (eCharacterBodyType)enumerator.ParseInt32(FieldType.characterBodyType);
                string characterPrefab = enumerator.ParseString(FieldType.chracterPrefab);
                int pictureDataId = enumerator.ParseInt32(FieldType.pictureDataId);
                int characterVoiceGroup = enumerator.ParseInt32(FieldType.characterVoiceGroup);

                var data = new GameCharacterTableData(
                            id,
                            characterType,
                            displayOnOff,
                            characterBodyType,
                            characterPrefab,
                            pictureDataId,
                            characterVoiceGroup);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public GameCharacterTableData GetData(int id)
        {
            GameCharacterTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public GameCharacterTableData GetData(eCharacterType characterType, eCharacterBodyType bodyType)
        {
            return _dict.Where(x => x.Value.CharacterBodyType == bodyType && x.Value.CharacterType == characterType).FirstOrDefault().Value;
        }

        public List<eCharacterBodyType> OnBodyTypeList
        {
            get
            {
                return _dict.Values.Where(x => x.DisplayOnOff).Select(x => x.CharacterBodyType).Distinct().ToList();
            }
        }

        public List<string> OnCharacterPrefabList
        {
            get
            {
                return _dict.Values.Where(x => x.DisplayOnOff && x.CharacterType != eCharacterType.TYPE_DEALER).Select(x => x.CharacterPrefab).Distinct().ToList();
            }
        }

        public List<string> OnDealerPrefabList
        {
            get
            {
                return _dict.Values.Where(x => x.DisplayOnOff && x.CharacterType == eCharacterType.TYPE_DEALER).Select(x => x.CharacterPrefab).Distinct().ToList();
            }
        }

        //public List<GameCharacterTableData> _dictList
        //{
        //    get
        //    {
        //        List<GameCharacterTableData> data = new List<GameCharacterTableData>();

        //        for (int i = 0; i < _dict.Count; i++)
        //        {
        //            data.Add(_dict.ElementAt(i).Value);
        //        }

        //        data = data.OrderBy(x => x.SortNumber).ToList();

        //        return data;
        //    }
        //}



        private Dictionary<int, GameCharacterTableData> _dict;
    }
}
