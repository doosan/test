﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class GameSoundTableData
    {
        public GameSoundTableData(int id, string name, int soundType, string soundResource)
        {
            Id = id;
            Name = name;
            SoundType = (eSoundType)soundType;
            SoundResource = soundResource;
        }

        public readonly int Id;
        public readonly string Name;
        public readonly eSoundType SoundType;
        public readonly string SoundResource;
    }

    public class GameSoundTable : Table<GameSoundTable, GameSoundTable.FieldType>
    {
        public enum FieldType
        {
            id,
            name,
            soundType,
            soundResource
        }

        #region Override from Table<GameSoundTable, GameSoundTable.FieldType>
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, GameSoundTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                string name = enumerator.ParseString(FieldType.name);
                int soundType = enumerator.ParseInt32(FieldType.soundType);
                string soundResource = enumerator.ParseString(FieldType.soundResource);
                

                var data = new GameSoundTableData(
                        id,
                        name,
                        soundType,
                        soundResource);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {

            get { return _dict.Count; }
        }

        public GameSoundTableData GetData(int id)
        {
            GameSoundTableData soundData;

            if (_dict == null)
                return null;

            return _dict.TryGetValue(id, out soundData) ? soundData : null;
        }

        public string GetSoundPath(int id)
        {
            return GetData(id).SoundResource;
        }

        private Dictionary<int, GameSoundTableData> _dict;
    }
}
