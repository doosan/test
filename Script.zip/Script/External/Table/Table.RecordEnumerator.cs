﻿using System;
using System.Collections.Generic;
using UnityEngine;
using Pie;
using Pie.Collections;
using Pie.Csv;
using ForuOnes.T3.LuckyTeenPatti.Table;

namespace ForuOnes.T3.LuckyTeenPatti
{
    public abstract partial class Table<T, TFieldType>
    {
        protected struct RecordEnumerator
        {
            public RecordEnumerator(CsvReader reader, Pie.Collections.IReadOnlyList<int> fieldIndices)
            {
                if (reader == null)
                    throw new ArgumentNullException("reader");

                if (fieldIndices == null)
                    throw new ArgumentNullException("fieldIndices");

                _reader = reader;
                _fieldIndices = fieldIndices;
            }

            public bool MoveNext()
            {
                return _reader.Read();
            }

            public string ParseString(TFieldType fieldType, string defaultValue = "")
            {
                string value = GetValue(fieldType);
                return value ?? defaultValue;
            }

            public bool ParseBoolean(TFieldType fieldType, bool defaultValue = false)
            {
                string value = GetValue(fieldType);

                if (string.IsNullOrEmpty(value))
                    return defaultValue;

                try
                {
                    return Convert.ToBoolean(Convert.ToInt32(value));
                }
                catch
                {
                    throw new InvalidFieldException(fieldType.ToString(), value, "유효한 bool 형식이 아닙니다.");
                }
            }

            public int ParseInt32(TFieldType fieldType, int defaultValue = 0)
            {
                string value = GetValue(fieldType);

                if (string.IsNullOrEmpty(value))
                    return defaultValue;

                try
                {
                    return Convert.ToInt32(value);
                }
                catch
                {
                    throw new InvalidFieldException(fieldType.ToString(), value, "유효한 int 형식이 아닙니다.");
                }
            }

            public long ParseInt64(TFieldType fieldType, int defaultValue = 0)
            {
                string value = GetValue(fieldType);

                if (string.IsNullOrEmpty(value))
                    return defaultValue;

                try
                {
                    return Convert.ToInt64(value);
                }
                catch
                {
                    throw new InvalidFieldException(fieldType.ToString(), value, "유효한 int 형식이 아닙니다.");
                }
            }

            public float ParseSingle(TFieldType fieldType, float defaultValue = 0.0f)
            {
                string value = GetValue(fieldType);

                if (string.IsNullOrEmpty(value))
                    return defaultValue;

                try
                {
                    return Convert.ToSingle(value);
                }
                catch
                {
                    throw new InvalidFieldException(fieldType.ToString(), value, "유효한 float 형식이 아닙니다.");
                }
            }

            public double ParseDouble(TFieldType fieldType, double defaultValue = 0.0)
            {
                string value = GetValue(fieldType);

                if (string.IsNullOrEmpty(value))
                    return defaultValue;

                try
                {
                    return Convert.ToDouble(value);
                }
                catch
                {
                    throw new InvalidFieldException(fieldType.ToString(), value, "유효한 double 형식이 아닙니다.");
                }
            }

            public TEnum ParseEnum<TEnum>(TFieldType fieldType, TEnum defaultValue = default(TEnum))
            {
                string value = GetValue(fieldType);
                if (string.IsNullOrEmpty(value))
                    return defaultValue;

                try
                {
                    return (TEnum)Enum.Parse(typeof(TEnum), value);
                }
                catch
                {
                    throw new InvalidFieldException(
                            fieldType.ToString(),
                            value,
                            string.Format("유효한 {0} 형식이 아닙니다.", typeof(TEnum).Name));
                }
            }

            public Vector2 ParseVector2(TFieldType fieldType, Vector2 defaultValue = default(Vector2))
            {
                string value = GetValue(fieldType);

                if (string.IsNullOrEmpty(value))
                    return defaultValue;

                string[] splitted = value.Split(',');
                if (splitted.Length == 0)
                    return defaultValue;

                if (splitted.Length != 2)
                    throw new InvalidFieldException(fieldType.ToString(), value, "유효한 Vector2 형식이 아닙니다.");

                try
                {
                    Vector2 result = new Vector2(
                            Convert.ToSingle(splitted[0].Trim()),
                            Convert.ToSingle(splitted[1].Trim()));

                    return result;
                }
                catch
                {
                    throw new InvalidFieldException(fieldType.ToString(), value, "유효한 Vector2 형식이 아닙니다.");
                }
            }

            public Vector3 ParseVector3(TFieldType fieldType, Vector3 defaultValue = default(Vector3))
            {
                string value = GetValue(fieldType);

                if (string.IsNullOrEmpty(value))
                    return defaultValue;

                string[] splitted = value.Split(',');
                if (splitted.Length == 0)
                    return defaultValue;

                if (splitted.Length != 3)
                    throw new InvalidFieldException(fieldType.ToString(), value, "유효한 Vector3 형식이 아닙니다.");

                try
                {
                    Vector3 result = new Vector3(
                            Convert.ToSingle(splitted[0].Trim()),
                            Convert.ToSingle(splitted[1].Trim()),
                            Convert.ToSingle(splitted[2].Trim()));

                    return result;
                }
                catch
                {
                    throw new InvalidFieldException(fieldType.ToString(), value, "유효한 Vector3 형식이 아닙니다.");
                }
            }

            public List<string> ParseStringArray(TFieldType fieldType)
            {

                string value = GetValue(fieldType);

                var result = new List<string>();
                if (string.IsNullOrEmpty(value))
                    return result;

                string[] splitted = value.Split(',');
                if (splitted.Length == 0)
                    return result;

                for (int i = 0; i < splitted.Length; ++i)
                    result.Add(splitted[i].Trim());

                return result;
            }

            public List<int> ParseInt32Array(TFieldType fieldType)
            {
                string value = GetValue(fieldType);

                value = value.Replace("\"", "");

                var result = new List<int>();
                if (string.IsNullOrEmpty(value))
                    return result;

                string[] splitted = value.Split(',');
                if (splitted.Length == 0)
                    return result;

                try
                {
                    for (int i = 0; i < splitted.Length; ++i)
                        result.Add(Convert.ToInt32(splitted[i]));

                    return result;
                }
                catch
                {
                    throw new InvalidFieldException(fieldType.ToString(), value, "유효한 int 배열 형식이 아닙니다.");
                }
            }

            public string ParsePath(TFieldType fieldType)
            {
                string value = GetValue(fieldType);

                try
                {
                    return Utils.CombinePath(string.Empty, value);
                }
                catch
                {
                    throw new InvalidFieldException(fieldType.ToString(), value, "유효한 경로 형식이 아닙니다.");
                }
            }

            private string GetValue(TFieldType fieldType)
            {
                return _reader[_fieldIndices[fieldType.ToInt32(null)]];
            }

            private CsvReader _reader;
            private Pie.Collections.IReadOnlyList<int> _fieldIndices;
        }
    }
}

