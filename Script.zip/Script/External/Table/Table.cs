﻿using System;
using UnityEngine;
using Pie;
using Pie.Collections;
using Pie.Csv;
using Pie.ExtensionMethods.System;
using Pie.ExtensionMethods.System.Collections.Generic;
using Pie.Logging;
using ForuOnes.T3.LuckyTeenPatti.Table;
using G.Util;
//using G.Util;

namespace ForuOnes.T3.LuckyTeenPatti
{
	using _ = Functional;

	public interface ITable {

		bool Load(string rootSuffix);
		void Unload();

		string Name { get; }
		bool IsLoaded { get; }
	}

	public abstract partial class Table<T, TFieldType> : Singleton<T>, ITable
			where T : Table<T, TFieldType>, new()
			where TFieldType : struct, IConvertible {

		#region Implementation of ITable
		public bool Load(string rootSuffix) {

			if (IsLoaded)
            {
                Unload();
            }
				//throw new InvalidOperationException("이미 로드된 테이블을 다시 로드할 수 없습니다.");

			var logger = LogManager.Instance.GetLogger(GetType());
			var failed = Utils.Failed(logger.Error);

			// 리소스 로드.
			string path;
#if FILE_ENCRYPT
			path = Utils.CombinePath(Constants.EncryptTableRoot, rootSuffix, Name);
#else
			path = Utils.CombinePath(Constants.TableRoot, rootSuffix, Name);
#endif
#if PATCH
            var asset = TableManager.Instance.GetTable(Name);
#else
            var asset = Resources.Load<TextAsset>(path);

            if (failed(asset != null, "파일을 찾을 수 없습니다.(경로: {0})".FormatWith(path)))
                return false;
#endif



            string text;
#if FILE_ENCRYPT
			//복호화.
			text = EncrypManager.Instance.AES256.DecryptString(asset.bytes, 0, asset.bytes.Length);
#else
			text = asset.text;
#endif

			CsvReader reader = CsvReader.Create(text, new CsvReaderSettings(','));

			if (failed(reader != null, "유효한 CSV 형식이 아닙니다.(경로: {0})".FormatWith(path)))
				return false;

			Resources.UnloadAsset(asset);

			// 헤더.
			var requiredFieldNames = Enum.GetNames(typeof(TFieldType));
			var fieldIndices = _.Chain(requiredFieldNames).Map(fieldName => reader.FieldNames.IndexOf(fieldName));
			var missedFieldNames = fieldIndices
					.Map((index, i) => _.Pair(index, requiredFieldNames[i]))
					.Filter(pair => pair.Key == -1)
					.Map(pair => pair.Value)
					.Join(", ");

			if (failed(_.None(missedFieldNames), "{0} 필드가 없습니다.(경로: {1})".FormatWith(missedFieldNames, path)))
				return false;

			try {

				OnLoad(new RecordEnumerator(reader, new ReadOnlyList<int>(fieldIndices.ToArray())));

				IsLoaded = true;
				return true;
			}
			catch (Exception e) {

				object msg = "{0} 번 레코드를 파싱하는 중에 에러가 발생했습니다.(경로: {1})\n{2}".FormatWith(
					reader.CurrentRecordIndex,
					path,
					e);

				logger.Error(msg);
				return false;
			}
		}

		public void Unload() {

			if (!IsLoaded)
				return;

			IsLoaded = false;

			OnUnload();
		}

		public virtual string Name {

			get {

				string className = GetType().Name;
				int suffixIndex = className.LastIndexOf("Table");
                
				return suffixIndex == -1 ? className : className.Substring(0, suffixIndex);
			}
		}

		public bool IsLoaded {

			get;
			private set;
		}
#endregion

		protected abstract void OnLoad(RecordEnumerator enumerator);

		protected abstract void OnUnload();
	}
}
