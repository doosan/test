﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class GameFriendInviteRewardTableData
    {
        public GameFriendInviteRewardTableData(int id, string name, int inviteCount, int rewardItemId, long rewardItemValue)
        {
            Id = id;
            Name = name;
            InviteCount = inviteCount;
            RewardItemId = rewardItemId;
            RewardItemValue = rewardItemValue;
        }

        public readonly int Id;
        public readonly string Name;
        public readonly int InviteCount;
        public readonly int RewardItemId;
        public readonly long RewardItemValue;
    }

    public class GameFriendInviteRewardTable : Table<GameFriendInviteRewardTable, GameFriendInviteRewardTable.FieldType>
    {
        public enum FieldType
        {
            id,
            name,
            inviteCount,
            rewardItemId,
            rewardItemValue,
        }

        #region Override from Table<GameFriendInviteRewardTable, GameFriendInviteRewardTable.FieldType>
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, GameFriendInviteRewardTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                string name = enumerator.ParseString(FieldType.name);
                int InviteCount = enumerator.ParseInt32(FieldType.inviteCount);
                int rewardItemId = enumerator.ParseInt32(FieldType.rewardItemId);

                long rewardItemValue = enumerator.ParseInt64(FieldType.rewardItemValue);

                var data = new GameFriendInviteRewardTableData(
                        id,
                        name,
                        InviteCount,
                        rewardItemId,
                        rewardItemValue);
               

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public GameFriendInviteRewardTableData GetData(int id)
        {
            GameFriendInviteRewardTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public List<GameFriendInviteRewardTableData> dictList
        {
            get { return _dict.Values.ToList(); }
        }

        private Dictionary<int, GameFriendInviteRewardTableData> _dict;
    }
}
