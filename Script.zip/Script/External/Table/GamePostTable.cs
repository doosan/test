﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class GamePostTableData
    {
        public GamePostTableData(int id, string name, ePostSendType postSendType, int senderNameId, int descId, ePostPeriodType periodType, int periodTime, Color labelColor, string labelImage)
        {
            Id = id;
            Name = name;
            PostSendType = postSendType;
            SenderNameId = senderNameId;
            DescId = descId;
            PeriodType = periodType;
            PeriodTime = periodTime;
            LabelColor = labelColor;
            LabelImage = labelImage;
        }

        public readonly int Id;
        public readonly string Name;
        public readonly ePostSendType PostSendType;
        public readonly int SenderNameId;
        public readonly int DescId;
        public readonly ePostPeriodType PeriodType;
        public readonly int PeriodTime;
        public readonly Color LabelColor;
        public readonly string LabelImage;
    }

    public class GamePostTable : Table<GamePostTable, GamePostTable.FieldType>
    {
        public enum FieldType
        {
            id,
            name,
            postSendType,
            senderNameId,
            descId,
            periodType,
            periodTime,
            labelColor,
            labelImage,
        }

        #region Override from Table<GamePostTable, GamePostTable.FieldType>
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, GamePostTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                string name = enumerator.ParseString(FieldType.name);
                ePostSendType postSendType = (ePostSendType)enumerator.ParseInt32(FieldType.postSendType);
                int senderNameId = enumerator.ParseInt32(FieldType.senderNameId);
                int descId = enumerator.ParseInt32(FieldType.descId);
                ePostPeriodType periodType = (ePostPeriodType)enumerator.ParseInt32(FieldType.periodType);
                int periodTime = enumerator.ParseInt32(FieldType.periodTime);

                Color labelColor = Color.white;
                ColorUtility.TryParseHtmlString(enumerator.ParseString(FieldType.labelColor), out labelColor);

                string labelImage = enumerator.ParseString(FieldType.labelImage);

                var data = new GamePostTableData(
                    id,
                    name,
                    postSendType,
                    senderNameId,
                    descId,
                    periodType,
                    periodTime,
                    labelColor,
                    labelImage);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public GamePostTableData GetData(int id)
        {
            GamePostTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public GamePostTableData GetData(ePostSendType type)
        {
            return _dict.Where(x => x.Value.PostSendType == type).FirstOrDefault().Value;
        }

        private Dictionary<int, GamePostTableData> _dict;
    }
}
