﻿using System;
using System.Text;

namespace ForuOnes.T3.LuckyTeenPatti
{
    public abstract partial class Table<T, TFieldType>
    {
        protected class InvalidFieldException : Exception
        {

            private static string GetMessage(string fieldName, object actualValue, string message)
            {

                var builder = new StringBuilder(message);

                if (!string.IsNullOrEmpty(fieldName))
                    builder.AppendLine().AppendFormat("필드 이름: {0}", fieldName);

                if (actualValue != null)
                    builder.AppendLine().AppendFormat("실제 값은 {0}입니다.", actualValue);

                return builder.ToString();
            }

            public string FieldName
            {

                get;
                private set;
            }

            public object ActualValue
            {

                get;
                private set;
            }

            public InvalidFieldException()
            {
            }

            public InvalidFieldException(string message)
                : base(message)
            {
            }

            public InvalidFieldException(string message, Exception inner)
                : base(message, inner)
            {
            }

            public InvalidFieldException(string fieldName, string message)
                : this(fieldName, null, message)
            {
            }

            public InvalidFieldException(object fieldName, string message)
                : this(fieldName.ToString(), null, message)
            {
            }

            public InvalidFieldException(string fieldName, object actualValue, string message)
                : base(GetMessage(fieldName, actualValue, message))
            {

                FieldName = fieldName;
                ActualValue = actualValue;
            }

            public InvalidFieldException(object fieldName, object actualValue, string message)
                : base(GetMessage(fieldName.ToString(), actualValue, message))
            {

                FieldName = fieldName.ToString();
                ActualValue = actualValue;
            }
        }

        protected class InvalidRecordException : Exception
        {

            public InvalidRecordException()
            {
            }

            public InvalidRecordException(string message)
                : base(message)
            {
            }

            public InvalidRecordException(string message, Exception inner)
                : base(message, inner)
            {
            }
        }
    }
}

