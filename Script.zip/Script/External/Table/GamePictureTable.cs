﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class GamePictureTableData
    {
        public GamePictureTableData(int id, int sortOrder, string image)
        {
            Id = id;
            SortOrder = sortOrder;
            Image = image;
        }

        public readonly int Id;
        public readonly int SortOrder;
        public readonly string Image;
    }

    public class GamePictureTable : Table<GamePictureTable, GamePictureTable.FieldType>
    {
        public enum FieldType
        {
            id,
            sortOrder,
            image
        }

        #region Override from Table<GamePictureTable, GamePictureTable.FieldType>
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, GamePictureTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                int sortOrder = enumerator.ParseInt32(FieldType.sortOrder);
                string image = enumerator.ParseString(FieldType.image);

                var data = new GamePictureTableData(
                        id,
                        sortOrder,
                        image);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public GamePictureTableData GetData(int id)
        {
            GamePictureTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public List<GamePictureTableData> GetData()
        {
            return _dict.Values.ToList();           
        }

        private Dictionary<int, GamePictureTableData> _dict;
    }
}
