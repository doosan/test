﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class ShopPaymentInfoTableData
    {
        public ShopPaymentInfoTableData(int id, string name, ePaymentType paymentType, string goodsCode, int shopBaseId)
        {
            Id = id;
            Name = name;
            PaymentType = paymentType;
            GoodsCode = goodsCode;
            ShopBaseId = shopBaseId;
        }

        public readonly int Id;
        public readonly string Name;
        public readonly ePaymentType PaymentType;
        public readonly string GoodsCode;
        public readonly int ShopBaseId;

    }

    #region Override from Table<ShopPaymentInfoTable, ShopPaymentInfoTable.FieldType>
    public class ShopPaymentInfoTable : Table<ShopPaymentInfoTable, ShopPaymentInfoTable.FieldType>
    {
        public enum FieldType
        {
            id,
            name,
            paymentType,
            goodsCode,
            shopBaseId
        }

        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, ShopPaymentInfoTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                string name = enumerator.ParseString(FieldType.name);
                ePaymentType paymentType = (ePaymentType)enumerator.ParseInt32(FieldType.paymentType);
                string goodsCode = enumerator.ParseString(FieldType.goodsCode);
                int shopBaseId = enumerator.ParseInt32(FieldType.shopBaseId);


                var data = new ShopPaymentInfoTableData(
                    id,
                    name,
                    paymentType,
                    goodsCode,
                    shopBaseId);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public ShopPaymentInfoTableData GetData(int id)
        {
            ShopPaymentInfoTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public string GetGoodsCode(int id, ePaymentType type)
        {
            return _dict.Where(x => x.Value.ShopBaseId == id && x.Value.PaymentType == type).FirstOrDefault().Value.GoodsCode;
        }

        public List<ShopPaymentInfoTableData> GetGoodsCodeList(ePaymentType type)
        {
            return _dict.Values.Where(x => x.PaymentType == type).ToList();
        }

        private Dictionary<int, ShopPaymentInfoTableData> _dict;
    }
}
