﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class ItemSafeVolumeTableData
    {
        public ItemSafeVolumeTableData(int id, string name, int safeNameId, long maxChargeChip, long maxSafeVolume, long moveChipLimit, bool taxUseType, double taxValueRate, int maxTimeLimitMinute, string safeIcon)
        { 
            Id = id;
            Name = name;
            SafeNameId = safeNameId;
            MaxChargeChip = maxChargeChip;
            MaxSafeVolume = maxSafeVolume;
            MoveChipLimit = moveChipLimit;
            TaxUseType = taxUseType;
            TaxValueRate = taxValueRate;
            MaxTimeLimitMinute = maxTimeLimitMinute;
            SafeIcon = safeIcon;
        }

        public readonly int Id;
        public readonly string Name;
        public readonly int SafeNameId;
        public readonly long MaxChargeChip;
        public readonly long MaxSafeVolume;
        public readonly long MoveChipLimit;
        public readonly bool TaxUseType;
        public readonly double TaxValueRate;
        public readonly int MaxTimeLimitMinute;
        public readonly string SafeIcon;
    }

    #region Override from Table<ItemBaseTable, ItemBaseTable.FieldType>
    public class ItemSafeVolumeTable : Table<ItemSafeVolumeTable, ItemSafeVolumeTable.FieldType>
    {
        public enum FieldType
        {
            id,
            name,
            safeNameId,
            maxChargeChip,
            maxSafeVolume,
            moveChipLimit,
            taxUseType,
            taxValueRate,
            maxTimeLimitMinute,
            safeIcon
        }
        
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, ItemSafeVolumeTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                string name = enumerator.ParseString(FieldType.name);
                int safeNameId = enumerator.ParseInt32(FieldType.safeNameId);
                long maxChargeChip = enumerator.ParseInt64(FieldType.maxChargeChip);
                
                long maxSafeVolume = enumerator.ParseInt64(FieldType.maxSafeVolume);
                long moveChipLimit = enumerator.ParseInt64(FieldType.moveChipLimit);
                bool taxUseType = enumerator.ParseBoolean(FieldType.taxUseType);
                double taxValueRate = enumerator.ParseDouble(FieldType.taxValueRate);
                int maxTimeLimitMinute = enumerator.ParseInt32(FieldType.maxTimeLimitMinute);
                string safeIcon = enumerator.ParseString(FieldType.safeIcon);
                var data = new ItemSafeVolumeTableData(
                        id,
                        name,
                        safeNameId,
                        maxChargeChip,
                        maxSafeVolume,
                        moveChipLimit,
                        taxUseType,
                        taxValueRate,
                        maxTimeLimitMinute,
                        safeIcon);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public ItemSafeVolumeTableData GetData(int id)
        {
            ItemSafeVolumeTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        private Dictionary<int, ItemSafeVolumeTableData> _dict;
    }
}
