﻿using ForuOnes.T3.LuckyTeenPatti;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class LocalizationSentenceTableData
    {
        public LocalizationSentenceTableData(int id, string kr, string en, string india, string enindia)
        {
            Id = id;
            Kr = kr;
            En = en;
            India = india;
            Enindia = enindia;
        }

        public readonly int Id;
        public readonly string Kr;
        public readonly string En;
        public readonly string India;
        public readonly string Enindia;
    }

    public class LocalizationSentenceTable: Table<LocalizationSentenceTable, LocalizationSentenceTable.FieldType>
    {
        public enum FieldType
        {
            id,
            en,
            kr,
            india,
            enindia,
        }

        #region Override from Table<LocalizationSentenceTable, LocalizationSentenceTable.FieldType>
        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, LocalizationSentenceTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                string en = enumerator.ParseString(FieldType.en).Replace("\\n", "\n");
                string kr = enumerator.ParseString(FieldType.kr).Replace("\\n", "\n");
                string india = enumerator.ParseString(FieldType.india).Replace("\\n", "\n");
                string enindia = enumerator.ParseString(FieldType.enindia).Replace("\\n", "\n");



                var data = new LocalizationSentenceTableData(
                        id,
                        kr,
                        en,
                        india,
                        enindia);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public string GetString(int id)
        {
            if (_dict.ContainsKey(id))
            {
                if (PlayerPrefsManager.Instance.languageType == eLanguageType.TYPE_ENG)
                    return _dict[id].En;
                if (PlayerPrefsManager.Instance.languageType == eLanguageType.TYPE_INDIA)
                    return _dict[id].India;
                if (PlayerPrefsManager.Instance.languageType == eLanguageType.TYPE_KOR)
                    return _dict[id].Kr;
                if (PlayerPrefsManager.Instance.languageType == eLanguageType.TYPE_INDIAINENGLISH)
                    return _dict[id].Enindia;
            }

            return string.Empty;
        }

        private Dictionary<int, LocalizationSentenceTableData> _dict;
    }
}
