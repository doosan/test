﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti.Table
{
    public class ShopBaseTableData
    {
        public ShopBaseTableData(int id, string name, eShopType shopType, bool displayOnOff, int shopSortOrder, eNeedGoodsType needGoodsType,
                                float saleRate, int usDollerSent, int indiaRupee, int needGoodsItemValue, int needGoodsValue, int needGoodsItemStringId,
                                int rewardItemId, long rewardItemValue, float bonusRate, string needGoodsIcon, string productIcon, eProvideType provideType,
                                eLimitProductType limitProductType, int limitProductValue, eLimitProductSortOutDisplayType limitProductSortOutDisplayType)
        {
            Id = id;
            Name = name;
            ShopType = shopType;
            DisplayOnOff = displayOnOff;
            ShopSortOrder = shopSortOrder;
            NeedGoodsType = needGoodsType;
            SaleRate = saleRate;
            UsDollerSent = usDollerSent;
            IndiaRupee = indiaRupee;
            NeedGoodsItemValue = needGoodsItemValue;
            NeedGoodsValue = needGoodsValue;
            NeedGoodsItemStringId = needGoodsItemStringId;
            RewardItemId = rewardItemId;
            RewardItemValue = rewardItemValue;
            BonusRate = bonusRate;
            NeedGoodsIcon = needGoodsIcon;
            ProductIcon = productIcon;
            ProvideType = provideType;
            LimitProductType = limitProductType;
            LimitProductValue = limitProductValue;
            LimitProductSortOutDisplayType = limitProductSortOutDisplayType;
        }

        public readonly int Id;
        public readonly string Name;
        public readonly eShopType ShopType;
        public readonly bool DisplayOnOff;
        public readonly int ShopSortOrder;
        public readonly eNeedGoodsType NeedGoodsType;
        public readonly float SaleRate;
        public readonly int UsDollerSent;
        public readonly int IndiaRupee;
        public readonly int NeedGoodsItemValue;
        public readonly int NeedGoodsValue;
        public readonly int NeedGoodsItemStringId;
        public readonly int RewardItemId;
        public readonly long RewardItemValue;
        public readonly float BonusRate;
        public readonly string NeedGoodsIcon;
        public readonly string ProductIcon;
        public readonly eProvideType ProvideType;
        public readonly eLimitProductType LimitProductType;
        public readonly int LimitProductValue;
        public readonly eLimitProductSortOutDisplayType LimitProductSortOutDisplayType;
    }

    #region Override from Table<ShopBaseTable, ShopBaseTable.FieldType>
    public class ShopBaseTable : Table<ShopBaseTable, ShopBaseTable.FieldType>
    {
        public enum FieldType
        {
            id,
            name,
            shopType,
            displayOnOff,
            shopSortOrder,
            needGoodsType,
            saleRate,
            usDollerSent,
            indiaRupee,
            needGoodsItemValue,
            needGoodsValue,
            needGoodsItemStringId,
            rewardItemId,
            rewardItemValue,
            bonusRate,
            needGoodsIcon,
            productIcon,
            provideType,
            limitProductType,
            limitProductValue,
            limitProductSortOutDisplayType,
        }

        protected override void OnLoad(RecordEnumerator enumerator)
        {
            var dict = new Dictionary<int, ShopBaseTableData>();

            while (enumerator.MoveNext())
            {
                int id = enumerator.ParseInt32(FieldType.id);
                string name = enumerator.ParseString(FieldType.name);
                eShopType shopType = (eShopType)enumerator.ParseInt32(FieldType.shopType);
                bool displayOnOff = enumerator.ParseBoolean(FieldType.displayOnOff);
                int shopSortOrder = enumerator.ParseInt32(FieldType.shopSortOrder);
                eNeedGoodsType needGoodsType = (eNeedGoodsType)enumerator.ParseInt32(FieldType.needGoodsType);
                float saleRate = enumerator.ParseSingle(FieldType.saleRate);
                int usDollerSent = enumerator.ParseInt32(FieldType.usDollerSent);
                int indiaRupee = enumerator.ParseInt32(FieldType.indiaRupee);
                int needGoodsItemValue = enumerator.ParseInt32(FieldType.needGoodsItemValue);
                int needGoodsValue = enumerator.ParseInt32(FieldType.needGoodsValue);
                int needGoodsItemStringId = enumerator.ParseInt32(FieldType.needGoodsItemStringId);
                int rewardItemId = enumerator.ParseInt32(FieldType.rewardItemId);
                long rewardItemValue = enumerator.ParseInt64(FieldType.rewardItemValue);
                float bonusRate = enumerator.ParseSingle(FieldType.bonusRate);
                string needGoodsIcon = enumerator.ParseString(FieldType.needGoodsIcon);
                string productIcon = enumerator.ParseString(FieldType.productIcon);
                eProvideType provideType = (eProvideType)enumerator.ParseInt32(FieldType.provideType);
                eLimitProductType limitProductType = (eLimitProductType)enumerator.ParseInt32(FieldType.limitProductType);
                int limitProductValue = enumerator.ParseInt32(FieldType.limitProductValue);
                eLimitProductSortOutDisplayType limitProductSortOutDisplayType = (eLimitProductSortOutDisplayType)enumerator.ParseInt32(FieldType.limitProductSortOutDisplayType);
                
                var data = new ShopBaseTableData(
                    id,
                    name,
                    shopType,
                    displayOnOff,
                    shopSortOrder,
                    needGoodsType,
                    saleRate,
                    usDollerSent,
                    indiaRupee,
                    needGoodsItemValue,
                    needGoodsValue,
                    needGoodsItemStringId,
                    rewardItemId,
                    rewardItemValue,
                    bonusRate,
                    needGoodsIcon,
                    productIcon,
                    provideType,
                    limitProductType,
                    limitProductValue,
                    limitProductSortOutDisplayType);

                dict.Add(id, data);
            }

            _dict = dict;
        }

        protected override void OnUnload()
        {
            _dict = null;
        }
        #endregion

        public int Count
        {
            get { return _dict.Count; }
        }

        public ShopBaseTableData GetData(int id)
        {
            ShopBaseTableData data;
            return _dict.TryGetValue(id, out data) ? data : null;
        }

        public List<ShopBaseTableData> GetData()
        {
            return _dict.Values.ToList();
        }

        public List<ShopBaseTableData> GetData(eShopType type)
        {
            return _dict.Values.Where(x => x.ShopType == type).ToList();
        }

        public int MaxCount
        {
            get
            {
                int count = 0;

                for (int i = (int)eShopType.TYPE_CHIP; i < (int)eShopType.TYPE_MULTI2 + 1;i++)
                {
                    int totalCount = _dict.Where(x => x.Value.ShopType == (eShopType)i).Count();

                    if (totalCount > count)
                        count = totalCount;
                }
                return count;
            }
        }

        private Dictionary<int, ShopBaseTableData> _dict;
    }
}
