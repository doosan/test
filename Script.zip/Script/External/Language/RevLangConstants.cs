﻿// Decompiled with JetBrains decompiler
// Type: Unity8bitConverter.common.RevLangConstants
// Assembly: Unity8bitConverter, Version=1.0.6800.23181, Culture=neutral, PublicKeyToken=null
// MVID: BE41920D-61DD-4C6C-A760-AF80A8128465
// Assembly location: D:\Test\New Unity Project (2)\Assets\Resources\Unity8bitConverter.dll

namespace Unity8bitConverter.common
{
  public class RevLangConstants
  {
    public static readonly int Lang_Hindi = 0;
    public static readonly int Lang_Gujarati = 1;
    public static readonly int Lang_Punjabi = 2;
    public static readonly int Lang_Malayalam = 5;
    public static readonly int Lang_Tamil = 4;
    public static readonly int Lang_Telugu = 6;
    public static readonly int Lang_Kannada = 7;
    public static readonly int Lang_Bengali = 3;
    public static readonly int Lang_English = 8;
    public static readonly int LANG_DEFAULT = 100;
  }
}
