﻿// Decompiled with JetBrains decompiler
// Type: Unity8bitConverter.font.GlyphMap
// Assembly: Unity8bitConverter, Version=1.0.6800.23181, Culture=neutral, PublicKeyToken=null
// MVID: BE41920D-61DD-4C6C-A760-AF80A8128465
// Assembly location: D:\Test\New Unity Project (2)\Assets\Resources\Unity8bitConverter.dll

namespace Unity8bitConverter.font
{
  public class GlyphMap
  {
    public byte lhslen;
    public byte rhslen;
    public char[] LHS;
    public char[] RHS;
  }
}
