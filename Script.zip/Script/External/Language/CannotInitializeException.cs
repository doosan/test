﻿// Decompiled with JetBrains decompiler
// Type: Unity8bitConverter.font.CannotInitializeException
// Assembly: Unity8bitConverter, Version=1.0.6800.23181, Culture=neutral, PublicKeyToken=null
// MVID: BE41920D-61DD-4C6C-A760-AF80A8128465
// Assembly location: D:\Test\New Unity Project (2)\Assets\Resources\Unity8bitConverter.dll

using System;

namespace Unity8bitConverter.font
{
  public class CannotInitializeException : Exception
  {
    public CannotInitializeException()
    {
    }

    public CannotInitializeException(string message)
      : base(message)
    {
    }

    public CannotInitializeException(string message, Exception inner)
      : base(message, inner)
    {
    }
  }
}
