﻿// Decompiled with JetBrains decompiler
// Type: Unity8bitConverter.UnicodeConverter
// Assembly: Unity8bitConverter, Version=1.0.6800.23181, Culture=neutral, PublicKeyToken=null
// MVID: BE41920D-61DD-4C6C-A760-AF80A8128465
// Assembly location: D:\Test\New Unity Project (2)\Assets\Resources\Unity8bitConverter.dll

using System;
using Unity8bitConverter.common;
using Unity8bitConverter.font;

namespace Unity8bitConverter
{
  public class UnicodeConverter : IConverter
  {
    private Syllable syl;

    public void Initialize()
    {
      //this.curEpoch = (int) (DateTime.UtcNow - new DateTime(1970, 1, 1)).TotalSeconds;
      //if (this.curEpoch > 1534881647 || this.curEpoch < 1534231247)
      //  throw new CannotInitializeException("Your trail period is expired.. Cannot initialize the component");
      FontLoader.loadfont();
      this.syl = new Syllable();
    }

    public string GetFontName(int Lang)
    {
      //if (Lang != RevLangConstants.Lang_Hindi)
      //  throw new InvalidOperationException("Only Hindi Language is supported");
      return FontLoader.fontMapping[Lang];
    }

    public char getLangMask(int lang)
    {
      switch (lang)
      {
        case 0:
          return 'ऀ';
        case 1:
          return '\x0A80';
        case 2:
          return '\x0A00';
        case 3:
          return 'ঀ';
        case 4:
          return '\x0B80';
        case 5:
          return '\x0D00';
        case 6:
          return 'ఀ';
        case 7:
          return '\x0C80';
        default:
          return char.MinValue;
      }
    }

    public string Convert(string given, int Lang)
    {
      int index1 = 0;
      int length = 0;
      int langMask = (int) this.getLangMask(Lang);
      byte[] lhs = new byte[given.Length + 1];
      char[] str = new char[given.Length + 1];
      char[] chArray = new char[given.Length * 5];
      char[] base1 = new char[40];
      for (int index2 = 0; index2 < given.Length; ++index2)
      {
        if (given[index2] != '\x200D')
        {
          str[index1] = given[index2];
          lhs[index1++] = (byte) ((uint) given[index2] & (uint) sbyte.MaxValue);
        }
      }
      int index3 = 0;
      while (index3 < index1)
      {
        int MaxSize = 1;
        if (((int) str[index3] & 65408) == langMask)
        {
          while (((int) str[index3 + MaxSize] & 65408) == langMask && index3 + MaxSize != index1)
            ++MaxSize;
        }
        else
        {
          while (((int) str[index3 + MaxSize] & 65408) != langMask && index3 + MaxSize != index1)
            ++MaxSize;
        }
        if (((int) str[index3] & 65408) == langMask)
        {
          while (MaxSize > 0)
          {
            int syllableDv = this.syl.parseSyllable_DV(str, MaxSize, index3);
            int num = this.syl.Convert(lhs, syllableDv, index3, Lang, base1);
            index3 += num;
            MaxSize -= num;
            for (int index2 = 0; index2 < Syllable.NO_OF_GLYPH; ++index2)
              chArray[length++] = base1[index2];
          }
        }
        else
        {
          for (; MaxSize > 0; --MaxSize)
          {
            if (str[index3] != '\x200C')
              chArray[length++] = str[index3];
            ++index3;
          }
        }
      }
      return new string(chArray, 0, length);
    }
  }
}
