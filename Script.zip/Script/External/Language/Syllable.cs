﻿// Decompiled with JetBrains decompiler
// Type: Unity8bitConverter.font.Syllable
// Assembly: Unity8bitConverter, Version=1.0.6800.23181, Culture=neutral, PublicKeyToken=null
// MVID: BE41920D-61DD-4C6C-A760-AF80A8128465
// Assembly location: D:\Test\New Unity Project (2)\Assets\Resources\Unity8bitConverter.dll

using System.Collections.Generic;
using Unity8bitConverter.common;

namespace Unity8bitConverter.font
{
  public class Syllable
  {
    private static readonly int A = 1;
    private static readonly int B = 2;
    private static readonly int C = 3;
    private static readonly int C1 = 4;
    private static readonly int C2 = 5;
    private static readonly int D = 6;
    private static readonly int F = 7;
    private static readonly int E = 8;
    private static readonly int D1 = 9;
    private static readonly int B1 = 10;
    private static readonly int D2 = 11;
    private static readonly int RIGHTBASEINCOMPLETE = 12;
    private static readonly int BOTTOMBASEINCOMPLETE = 13;
    private static readonly int BASESTEMINCOMPLETE = 14;
    private static readonly int REPH = 7;
    private static readonly int LEFT = 1;
    private static readonly int NOOFDVGROUPS = 24;
    public static readonly int no_of_languages = 1;
    private static readonly int HALANT = 77;
    private static readonly int COMPLETEMASK = 15;
    private readonly byte[] GMetaDV = new byte[24]
    {
      (byte) 0,
      (byte) 0,
      (byte) 1,
      (byte) 3,
      (byte) 5,
      (byte) 20,
      (byte) 21,
      (byte) 57,
      (byte) 88,
      (byte) 95,
      (byte) 112,
      (byte) 113,
      (byte) 62,
      (byte) 76,
      (byte) 77,
      (byte) 77,
      (byte) 60,
      (byte) 60,
      (byte) 86,
      (byte) 87,
      (byte) 114,
      (byte) 119,
      (byte) 79,
      (byte) 79
    };
    private readonly byte[] CharPropertiesDV_0 = new byte[1];
    private readonly byte[] CharPropertiesDV_1 = new byte[10]
    {
      (byte) Syllable.B,
      (byte) Syllable.B1,
      (byte) Syllable.C,
      (byte) Syllable.C1,
      (byte) Syllable.C2,
      (byte) Syllable.D,
      (byte) Syllable.D1,
      (byte) Syllable.D2,
      (byte) Syllable.E,
      (byte) 0
    };
    private readonly byte[] CharPropertiesDV_2 = new byte[1];
    private readonly byte[] CharPropertiesDV_3 = new byte[2]
    {
      (byte) Syllable.F,
      (byte) 0
    };
    private readonly byte[] CharPropertiesDV_4 = new byte[2]
    {
      (byte) Syllable.F,
      (byte) 0
    };
    private readonly byte[] CharPropertiesDV_5 = new byte[2]
    {
      (byte) Syllable.F,
      (byte) 0
    };
    private readonly byte[] CharPropertiesDV_6 = new byte[5]
    {
      (byte) Syllable.C,
      (byte) Syllable.C1,
      (byte) Syllable.C2,
      (byte) Syllable.E,
      (byte) 0
    };
    private readonly byte[] CharPropertiesDV_7 = new byte[5]
    {
      (byte) Syllable.C,
      (byte) Syllable.C1,
      (byte) Syllable.C2,
      (byte) Syllable.E,
      (byte) 0
    };
    private readonly byte[] CharPropertiesDV_8 = new byte[3]
    {
      (byte) Syllable.C,
      (byte) Syllable.C2,
      (byte) 0
    };
    private readonly byte[] CharPropertiesDV_9 = new byte[5]
    {
      (byte) Syllable.C,
      (byte) Syllable.C1,
      (byte) Syllable.C2,
      (byte) Syllable.E,
      (byte) 0
    };
    private readonly byte[] CharPropertiesDV_10 = new byte[1];
    private readonly byte[] CharPropertiesDV_11 = new byte[5]
    {
      (byte) Syllable.C,
      (byte) Syllable.C1,
      (byte) Syllable.C2,
      (byte) Syllable.E,
      (byte) 0
    };
    private Dictionary<int, byte[]> CharPropertiesDV_map = new Dictionary<int, byte[]>();
    private char[] diacritics = new char[9];
    public LoadFont loadFont;
    public static int NO_OF_GLYPH;

    public Syllable()
    {
      this.loadFont = FontLoader.loadFont;
      this.add_CharPropertiesDV_to_dict();
    }

    private void add_CharPropertiesDV_to_dict()
    {
      this.CharPropertiesDV_map.Add(0, this.CharPropertiesDV_0);
      this.CharPropertiesDV_map.Add(1, this.CharPropertiesDV_1);
      this.CharPropertiesDV_map.Add(2, this.CharPropertiesDV_2);
      this.CharPropertiesDV_map.Add(3, this.CharPropertiesDV_3);
      this.CharPropertiesDV_map.Add(4, this.CharPropertiesDV_4);
      this.CharPropertiesDV_map.Add(5, this.CharPropertiesDV_5);
      this.CharPropertiesDV_map.Add(6, this.CharPropertiesDV_6);
      this.CharPropertiesDV_map.Add(7, this.CharPropertiesDV_7);
      this.CharPropertiesDV_map.Add(8, this.CharPropertiesDV_8);
      this.CharPropertiesDV_map.Add(9, this.CharPropertiesDV_9);
      this.CharPropertiesDV_map.Add(10, this.CharPropertiesDV_10);
      this.CharPropertiesDV_map.Add(11, this.CharPropertiesDV_11);
    }

    internal int Convert(byte[] lhs, int len, int index1, int language, char[] base1)
    {
      int index2 = 0;
      int num1 = 0;
      int baseType1 = 0;
      int baseType2 = 0;
      for (int index3 = 0; index3 < this.diacritics.Length; ++index3)
        this.diacritics[index3] = char.MinValue;
      int length = len * 4;
      if (len < 0)
        length = -1 * length;
      char[] chArray1 = new char[length];
      if (language == RevLangConstants.Lang_English)
      {
        char[] chArray2 = base1;
        int index3 = index2;
        int num2 = index3 + 1;
        int lh = (int) lhs[index1];
        chArray2[index3] = (char) lh;
        Syllable.NO_OF_GLYPH = num2;
        return 1;
      }
      if (language == RevLangConstants.Lang_Hindi && len == 1 && lhs[index1] == (byte) 100)
      {
        base1[0] = 'Ī';
        Syllable.NO_OF_GLYPH = 1;
        return 1;
      }
      if (len < 0)
      {
        chArray1[index2++] = language != RevLangConstants.Lang_Telugu ? (language != RevLangConstants.Lang_Bengali ? '#' : '◌') : '2';
        baseType2 = Syllable.B1;
        len = 1;
      }
      if (lhs[index1] == (byte) 80 && (language == RevLangConstants.Lang_Hindi || language == RevLangConstants.Lang_Gujarati))
      {
        char[] chArray2 = base1;
        int index3 = index2;
        int num2 = index3 + 1;
        int num3 = 292;
        chArray2[index3] = (char) num3;
        Syllable.NO_OF_GLYPH = 1;
        return 1;
      }
      while (num1 < len)
      {
        int index3;
        for (index3 = 0; index3 < this.loadFont.font[language].NoOfGlyphMap; ++index3)
        {
          int lhslen = (int) this.loadFont.font[language].glyphMap[index3].lhslen;
          if (lhslen + num1 <= len && this.StrnCmp(lhs, this.loadFont.font[language].glyphMap[index3].LHS, lhslen, num1 + index1, len + index1) > 0)
          {
            int index4;
            for (index4 = 0; index4 < (int) this.loadFont.font[language].glyphMap[index3].rhslen; ++index4)
            {
              int glyphType = this.GetGlyphType(this.loadFont.font[language].glyphMap[index3].RHS[index4], language);
              if (((glyphType & Syllable.COMPLETEMASK) != Syllable.REPH || num1 == 0) && ((glyphType & Syllable.COMPLETEMASK) != 11 || language != RevLangConstants.Lang_Kannada || this.loadFont.font[language].glyphMap[index3].RHS[0] != '&' && this.loadFont.font[language].glyphMap[index3].RHS[0] != '%' || len != 2))
              {
                if ((glyphType & Syllable.COMPLETEMASK) == 1)
                  chArray1[index2++] = this.loadFont.font[language].glyphMap[index3].RHS[index4];
                else if ((glyphType & Syllable.COMPLETEMASK) <= Syllable.D1)
                {
                  if ((baseType2 & Syllable.COMPLETEMASK) == Syllable.D2)
                  {
                    chArray1[index2++] = this.loadFont.font[language].COMPLETIONGLYPH;
                    baseType2 = Syllable.B1;
                  }
                  if ((num1 + lhslen != len || index4 != (int) this.loadFont.font[language].glyphMap[index3].rhslen - 1 || ((baseType2 & Syllable.COMPLETEMASK) == Syllable.B1 || (baseType2 & Syllable.COMPLETEMASK) == Syllable.BASESTEMINCOMPLETE) || (baseType2 & Syllable.COMPLETEMASK) == Syllable.RIGHTBASEINCOMPLETE) && this.diacritics[(glyphType & Syllable.COMPLETEMASK) - 1] == char.MinValue)
                    this.diacritics[(glyphType & Syllable.COMPLETEMASK) - 1] = this.loadFont.font[language].glyphMap[index3].RHS[index4];
                  else
                    break;
                }
                else if (((baseType2 & Syllable.COMPLETEMASK) != Syllable.B1 || (glyphType & Syllable.COMPLETEMASK) == Syllable.RIGHTBASEINCOMPLETE || (glyphType & Syllable.COMPLETEMASK) == Syllable.BOTTOMBASEINCOMPLETE) && ((baseType2 & Syllable.COMPLETEMASK) != Syllable.RIGHTBASEINCOMPLETE && (baseType2 & Syllable.COMPLETEMASK) != Syllable.BOTTOMBASEINCOMPLETE || (baseType2 == 28 || (glyphType & Syllable.COMPLETEMASK) != Syllable.B1)))
                {
                  if ((glyphType & Syllable.COMPLETEMASK) == Syllable.D2 && num1 + lhslen == len)
                  {
                    if ((int) lhs[index1 + num1 + lhslen - 1] != Syllable.HALANT)
                    {
                      chArray1[index2] = this.loadFont.font[language].glyphMap[index3].RHS[index4];
                      ++index2;
                      if (index4 == (int) this.loadFont.font[language].glyphMap[index3].rhslen - 1)
                      {
                        chArray1[index2] = this.loadFont.font[language].COMPLETIONGLYPH;
                        baseType2 = Syllable.B1;
                        ++index2;
                      }
                      else
                        baseType2 = Syllable.D2;
                    }
                    else
                      break;
                  }
                  else if ((glyphType & Syllable.COMPLETEMASK) == Syllable.RIGHTBASEINCOMPLETE)
                  {
                    chArray1[index2++] = this.loadFont.font[language].glyphMap[index3].RHS[index4];
                    if (language != RevLangConstants.Lang_Bengali || chArray1[index2 - 1] != '℅')
                      baseType2 = Syllable.B1;
                  }
                  else
                  {
                    chArray1[index2] = this.loadFont.font[language].glyphMap[index3].RHS[index4];
                    ++index2;
                    baseType2 = glyphType;
                    if (baseType2 == 29 && language == RevLangConstants.Lang_Telugu)
                      baseType2 = 10;
                  }
                  for (int index5 = 0; index5 < this.loadFont.font[language].NoOfCombinationGlyphs; ++index5)
                  {
                    if ((int) chArray1[index2 - 1] == (int) this.loadFont.font[language].combinationGlyphs[index5].glyph)
                    {
                      for (int index6 = 0; index6 < (int) this.loadFont.font[language].combinationGlyphs[index5].diacritic_count; ++index6)
                        this.diacritics[(int) this.loadFont.font[language].combinationGlyphs[index5].diacritic[index6] - 1] = '\x0001';
                    }
                  }
                }
                else
                  break;
              }
              else
                break;
            }
            if (index4 == (int) this.loadFont.font[language].glyphMap[index3].rhslen)
            {
              num1 += lhslen;
              break;
            }
          }
        }
        if (index3 == this.loadFont.font[language].NoOfGlyphMap)
        {
          if (num1 == 0)
          {
            char[] chArray2 = base1;
            int index4 = index2;
            int num2 = index4 + 1;
            int num3 = 63;
            chArray2[index4] = (char) num3;
            Syllable.NO_OF_GLYPH = num2;
            return 1;
          }
          break;
        }
      }
      if ((this.GetGlyphType(chArray1[0], language) & Syllable.COMPLETEMASK) == Syllable.D2)
        baseType1 = index2 != 2 || this.GetGlyphType(chArray1[1], language) > Syllable.D1 ? this.GetGlyphType(chArray1[0], language) : this.GetGlyphType(chArray1[0], language) - 1;
      for (int index3 = 0; index3 < index2; ++index3)
      {
        char glyph = chArray1[index3];
        if (this.Property(glyph, language) == Syllable.LEFT)
        {
          for (int index4 = index3; index4 > 0; --index4)
            chArray1[index4] = chArray1[index4 - 1];
          chArray1[0] = glyph;
          break;
        }
      }
      if (language == 1 && this.diacritics[7] == 'Ä' && this.diacritics[6] != char.MinValue)
        this.diacritics[7] = 'Æ';
      for (int index3 = 0; index3 < Syllable.D1; ++index3)
      {
        if ((language == RevLangConstants.Lang_Kannada || language == RevLangConstants.Lang_Telugu) && index3 == 7)
          ++index3;
        if (index3 == 7 && this.diacritics[index3] != char.MinValue || this.diacritics[index3] != char.MinValue && this.diacritics[index3] != '\x0001')
        {
          int index4;
          for (index4 = 0; index4 < this.loadFont.font[language].NoOfDiacriticMap; ++index4)
          {
            int num2 = this.StrCmp(this.diacritics, this.loadFont.font[language].diacriticMap[index4].LHS, Syllable.D1 - index3, this.loadFont.font[language].diacriticMap[index4].lhslen);
            if (num2 > 0)
            {
              index3 += num2;
              break;
            }
          }
          char glyph = index4 != this.loadFont.font[language].NoOfDiacriticMap ? this.loadFont.font[language].diacriticMap[index4].RHS : this.diacritics[index3];
          if (this.Property(glyph, language) == Syllable.LEFT)
          {
            for (int index5 = index2; index5 > 0; --index5)
              chArray1[index5] = chArray1[index5 - 1];
            chArray1[0] = (char) this.Substitute(glyph, baseType1, language);
          }
          else
            chArray1[index2] = (char) this.Substitute(glyph, baseType2, language);
          ++index2;
        }
      }
      int num4 = index2;
      int num5 = 0;
      for (int index3 = 0; index3 < num4; ++index3)
      {
        if (this.IsKern(chArray1[index3], language) && (language != RevLangConstants.Lang_Telugu || index3 >= num4 - 1 || !this.isNoKernMatra(chArray1[index3 + 1])))
        {
          char[] chArray2 = base1;
          int index4 = num5;
          int num2 = index4 + 1;
          int num3 = (int) chArray1[index3];
          chArray2[index4] = (char) num3;
          char kernChar = this.GetKernChar(chArray1[index3], language);
          if (index3 < num4 - 1)
          {
            while ((this.GetGlyphType(chArray1[index3 + 1], language) < Syllable.D1 && this.GetGlyphType(chArray1[index3 + 1], language) != 4 && (this.GetGlyphType(chArray1[index3 + 1], language) != 5 && this.GetGlyphType(chArray1[index3 + 1], language) != 9) || this.GetGlyphType(chArray1[index3 + 1], language) == 29) && (this.GetGlyphType(chArray1[index3 + 1], language) != 8 || language != RevLangConstants.Lang_Telugu))
            {
              base1[num2++] = chArray1[index3 + 1];
              ++index3;
              if (index3 == num4 - 1 || this.GetGlyphType(chArray1[index3], language) == 29 && this.GetGlyphType(chArray1[index3 + 1], language) == 29)
                break;
            }
          }
          char[] chArray3 = base1;
          int index5 = num2;
          num5 = index5 + 1;
          int num6 = (int) kernChar;
          chArray3[index5] = (char) num6;
        }
        else
          base1[num5++] = chArray1[index3];
      }
      if (language == RevLangConstants.Lang_Hindi || language == RevLangConstants.Lang_Malayalam || (language == RevLangConstants.Lang_Gujarati || language == RevLangConstants.Lang_Punjabi) || (language == RevLangConstants.Lang_Tamil || language == RevLangConstants.Lang_Bengali))
      {
        for (int index3 = 0; index3 < num5; ++index3)
        {
          if (base1[index3] >= ' ' && base1[index3] <= '\x007F' || base1[index3] >= ' ' && base1[index3] <= 'þ')
            base1[index3] = (char) ((uint) base1[index3] + 256U);
        }
      }
      Syllable.NO_OF_GLYPH = num5;
      return num1;
    }

    internal bool isNoKernMatra(char g)
    {
      char[] chArray = new char[13]
      {
        '\x00B3',
        '´',
        'µ',
        'Ð',
        'Ñ',
        'Ò',
        'Ó',
        'Ô',
        'Õ',
        'Ö',
        '×',
        'Ø',
        char.MinValue
      };
      for (int index = 0; chArray[index] != char.MinValue; ++index)
      {
        if ((int) chArray[index] == (int) g)
          return true;
      }
      return false;
    }

    internal int GetGroup(char g)
    {
      char[] chArray1 = new char[12]
      {
        'X',
        'r',
        '¤',
        '§',
        'ª',
        'µ',
        '\x00BD',
        'Ç',
        'Ð',
        'Ó',
        'Ö',
        char.MinValue
      };
      char[] chArray2 = new char[7]
      {
        ']',
        'g',
        'u',
        'x',
        '|',
        '\x00BC',
        char.MinValue
      };
      for (int index = 0; chArray1[index] != char.MinValue; ++index)
      {
        if ((int) chArray1[index] == (int) g)
          return 1;
      }
      for (int index = 0; chArray2[index] != char.MinValue; ++index)
      {
        if ((int) chArray2[index] == (int) g)
          return 2;
      }
      return 0;
    }

    internal bool IsKern(char g, int lang)
    {
      for (int index = 0; index < this.loadFont.font[lang].NoofKernglyphs; ++index)
      {
        if ((int) this.loadFont.font[lang].kerningGlyphs[index].glyph == (int) g)
          return true;
      }
      return false;
    }

    internal char GetKernChar(char g, int lang)
    {
      for (int index = 0; index < this.loadFont.font[lang].NoofKernglyphs; ++index)
      {
        if ((int) this.loadFont.font[lang].kerningGlyphs[index].glyph == (int) g)
          return this.loadFont.font[lang].kerningGlyphs[index].kernglyph;
      }
      return char.MinValue;
    }

    internal int GetGlyphCount()
    {
      return Syllable.NO_OF_GLYPH;
    }

    internal int Property(char glyph, int language)
    {
      for (int index = 0; index < this.loadFont.font[language].NoOfPropertyGlyphs; ++index)
      {
        if ((int) this.loadFont.font[language].propertyGlyphs[index].glyph == (int) glyph)
          return (int) this.loadFont.font[language].propertyGlyphs[index].property;
      }
      return 0;
    }

    internal int Substitute(char glyph, int baseType, int language)
    {
      for (int index1 = 0; index1 < this.loadFont.font[language].NoOfSubstitutionGlyphs; ++index1)
      {
        if ((int) this.loadFont.font[language].substitutionGlyphs[index1].glyph == (int) glyph)
        {
          for (int index2 = 0; index2 < (int) this.loadFont.font[language].substitutionGlyphs[index1].length; ++index2)
          {
            if ((int) this.loadFont.font[language].substitutionGlyphs[index1].baseType[index2] == (baseType & (int) this.loadFont.font[language].substitutionGlyphs[index1].mask))
              return (int) this.loadFont.font[language].substitutionGlyphs[index1].substituteGlyph[index2];
          }
          break;
        }
      }
      return (int) glyph;
    }

    internal int StrCmp(char[] str1, char[] str2, int len1, byte len2)
    {
      int index1 = Syllable.D1 - len1;
      int index2 = 0;
      int num = 0;
      while (len2 != (byte) 0)
      {
        while (index1 < str1.Length && str1[index1] == char.MinValue && len1 > 0)
        {
          ++index1;
          --len1;
          ++num;
        }
        if (index1 >= str1.Length || index2 >= str2.Length || (int) str2[index2] != (int) str1[index1])
          return 0;
        ++index2;
        ++index1;
        --len2;
        ++num;
      }
      return num;
    }

    internal int StrnCmp(byte[] str1, char[] str2, int len, int index, int tot_len)
    {
      int index1 = 0;
      for (; len > 0; --len)
      {
        if (index == tot_len || (int) (byte) ((uint) str1[index] + 256U) != (int) str2[index1])
          return 0;
        ++index;
        ++index1;
      }
      return 1;
    }

    internal int GetGlyphType(char glyph, int language)
    {
      int noOfGlyphs = this.loadFont.font[language].NoOfGlyphs;
      int num1 = noOfGlyphs;
      int index1 = 0;
      int num2 = (index1 + num1) / 2;
      while (index1 < num1)
      {
        int index2 = (index1 + num1) / 2;
        if ((int) this.loadFont.font[language].Id[index2] < (int) glyph)
          index1 = index2 + 1;
        else
          num1 = index2;
      }
      if (index1 < noOfGlyphs && (int) this.loadFont.font[language].Id[index1] == (int) glyph)
        return (int) this.loadFont.font[language].type[index1];
      return -1;
    }

    internal int GetGlyphIndex(char glyph, int language)
    {
      return -1;
    }

    internal char GetSubBase(char c, int language)
    {
      for (int index = 0; index < this.loadFont.font[language].NoOfSubstitutionGlyphs; ++index)
      {
        if ((int) this.loadFont.font[language].substitutionGlyphs[index].glyph == (int) c)
          c = this.loadFont.font[language].substitutionGlyphs[index].substituteGlyph[0];
      }
      return c;
    }

    internal int parseSyllable_DV(char[] str, int MaxSize, int index)
    {
      int num1 = 1;
      if (str[index] == char.MaxValue)
        return 0;
      if (MaxSize >= 2 && ((int) str[index] & (int) sbyte.MaxValue) == 5 && ((int) str[index + 1] & (int) sbyte.MaxValue) == 69 || MaxSize >= 2 && ((int) str[index] & (int) sbyte.MaxValue) == 6 && ((int) str[index + 1] & (int) sbyte.MaxValue) == 69 || MaxSize >= 2 && ((int) str[index] & (int) sbyte.MaxValue) == 5 && ((int) str[index + 1] & (int) sbyte.MaxValue) == 73)
        return 2;
      int index1 = 2;
      while (index1 < Syllable.NOOFDVGROUPS && (((int) str[index + num1 - 1] & (int) sbyte.MaxValue) < (int) this.GMetaDV[index1] || ((int) str[index + num1 - 1] & (int) sbyte.MaxValue) > (int) this.GMetaDV[index1 + 1]))
        index1 += 2;
      if (index1 == Syllable.NOOFDVGROUPS)
        return 1;
      int num2 = index1 >> 1;
      if (num2 == Syllable.A || num2 == Syllable.D || (num2 == Syllable.D1 || num2 == Syllable.D2) || (num2 == Syllable.F || num2 == Syllable.E))
        return -1;
      if (num1 == MaxSize)
        return num1;
      while (((int) str[index + num1] & (int) sbyte.MaxValue) != 0 && str[index + num1] > 'ÿ')
      {
        if (str[index + num1] != '\x200D')
        {
          int index2 = 2;
          while (index2 < Syllable.NOOFDVGROUPS && (((int) str[index + num1] & (int) sbyte.MaxValue) < (int) this.GMetaDV[index2] || ((int) str[index + num1] & (int) sbyte.MaxValue) > (int) this.GMetaDV[index2 + 1]))
            index2 += 2;
          if (index2 != Syllable.NOOFDVGROUPS && this.strChr(this.CharPropertiesDV_map[index2 >> 1], (byte) num2) != 0)
            num2 = index2 >> 1;
          else
            break;
        }
        ++num1;
        if (num1 == MaxSize || str[index + num1] == '\x200C')
          break;
      }
      return num1;
    }

    internal int strChr(byte[] js, byte c2)
    {
      for (int index = 0; index < js.Length; ++index)
      {
        if ((int) c2 == (int) js[index])
          return index + 1;
      }
      return 0;
    }

    internal int StrChr(string js, byte c2)
    {
      for (int index = 0; index < js.Length; ++index)
      {
        if ((int) c2 == (int) (byte) js.ToCharArray()[index])
          return index + 1;
      }
      return 0;
    }

    internal int getLanguage(char value)
    {
      if (value < 'ऀ' || value > 'ൿ')
        return RevLangConstants.Lang_English;
      if (value >= 'ऀ' && value <= 'ॿ')
        return RevLangConstants.Lang_Hindi;
      if (value >= 'ঀ' && value <= '\x09FF')
        return RevLangConstants.Lang_Bengali;
      if (value >= '\x0A00' && value <= '\x0A7F')
        return RevLangConstants.Lang_Punjabi;
      if (value >= '\x0A80' && value <= '\x0AFF')
        return RevLangConstants.Lang_Gujarati;
      if (value >= '\x0B80' && value <= '\x0BFF')
        return RevLangConstants.Lang_Tamil;
      if (value >= 'ఀ' && value <= '౿')
        return RevLangConstants.Lang_Telugu;
      if (value >= '\x0C80' && value <= '\x0CFF')
        return RevLangConstants.Lang_Kannada;
      if (value >= '\x0D00' && value <= 'ൿ')
        return RevLangConstants.Lang_Malayalam;
      return (int) ushort.MaxValue;
    }
  }
}
