﻿// Decompiled with JetBrains decompiler
// Type: Unity8bitConverter.font.FontLoader
// Assembly: Unity8bitConverter, Version=1.0.6800.23181, Culture=neutral, PublicKeyToken=null
// MVID: BE41920D-61DD-4C6C-A760-AF80A8128465
// Assembly location: D:\Test\New Unity Project (2)\Assets\Resources\Unity8bitConverter.dll

using System.Collections.Generic;
using Unity8bitConverter.common;

namespace Unity8bitConverter.font
{
  public class FontLoader
  {
    internal static Dictionary<int, string> fontMapping = new Dictionary<int, string>();
    public static LoadFont loadFont;

        public static void loadfont()
        {
            FontLoader.loadFont = new LoadFont();
            FontLoader.loadFont.LoadFile();
            if (FontLoader.fontMapping.Count != 0)
                return;
            FontLoader.fontMapping.Add(RevLangConstants.Lang_Hindi, "DV-Mohanty-Regular1-Offset2");
        }
  }
}
