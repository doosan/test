﻿// Decompiled with JetBrains decompiler
// Type: Unity8bitConverter.font.MyFont
// Assembly: Unity8bitConverter, Version=1.0.6800.23181, Culture=neutral, PublicKeyToken=null
// MVID: BE41920D-61DD-4C6C-A760-AF80A8128465
// Assembly location: D:\Test\New Unity Project (2)\Assets\Resources\Unity8bitConverter.dll

namespace Unity8bitConverter.font
{
  public class MyFont
  {
    public int NoOfGlyphs;
    public char[] Id;
    public char[] type;
    public int NoOfGlyphMap;
    public GlyphMap[] glyphMap;
    public int NoOfDiacriticMap;
    public DiacriticMap[] diacriticMap;
    public int NoOfPropertyGlyphs;
    public PropertyGlyphs[] propertyGlyphs;
    public int NoOfSubstitutionGlyphs;
    public SubstitutionGlyphs[] substitutionGlyphs;
    public int NoOfCombinationGlyphs;
    public CombinationGlyphs[] combinationGlyphs;
    public int NoofKernglyphs;
    public kerning[] kerningGlyphs;
    public char COMPLETIONGLYPH;
  }
}
