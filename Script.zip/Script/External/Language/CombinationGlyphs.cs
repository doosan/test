﻿// Decompiled with JetBrains decompiler
// Type: Unity8bitConverter.font.CombinationGlyphs
// Assembly: Unity8bitConverter, Version=1.0.6800.23181, Culture=neutral, PublicKeyToken=null
// MVID: BE41920D-61DD-4C6C-A760-AF80A8128465
// Assembly location: D:\Test\New Unity Project (2)\Assets\Resources\Unity8bitConverter.dll

namespace Unity8bitConverter.font
{
  public class CombinationGlyphs
  {
    public char glyph;
    public byte diacritic_count;
    public byte[] diacritic;
  }
}
