﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pie.ExtensionMethods.System.Collections.Generic;

namespace Pie
{
    using Unit = UniRx.Unit;
    using _ = Functional;

    public enum PromiseState
    {
        Pending,
        Fulfilled,
        Rejected
    }

    public static class Promise
    {
        public static Promise<T> Create<T>(MonoBehaviour owner, Action<Action<T>, Action<Exception>> fn)
        {
            return new Promise<T>(owner, fn);
        }

        public static Promise<Unit> CreateFromCoroutine(MonoBehaviour owner, IEnumerator coroutine)
        {
            return new Promise<Unit>(
                    owner,
                    (resolve, reject) => {

                        owner.StartCoroutine(WrapEnumerator(coroutine, () => resolve(Unit.Default), reject));
                    });
        }

        public static Promise<T> CreateFromAsyncOperation<T>(MonoBehaviour owner, T asyncOperation)
                where T : AsyncOperation
        {
            IEnumerator coroutine = WaitAsyncOperation(asyncOperation);

            return new Promise<T>(
                    owner,
                    (resolve, reject) => {

                        owner.StartCoroutine(WrapEnumerator(coroutine, () => resolve(asyncOperation), reject));
                    });
        }

        public static Promise<T> Resolve<T>(MonoBehaviour owner, T arg)
        {
            Action<Action<T>, Action<Exception>> fn = (resolve, reject) => resolve(arg);

            return new Promise<T>(owner, fn);
        }

        public static Promise<T> Reject<T>(MonoBehaviour owner, Exception error)
        {
            Action<Action<T>, Action<Exception>> fn = (resolve, reject) => reject(error);

            return new Promise<T>(owner, fn);
        }

        public static Promise<T[]> All<T>(MonoBehaviour owner, params Promise<T>[] promises)
        {
            return new Promise<T[]>(
                    owner,
                    (resolve, reject) => {

                        owner.StartCoroutine(AllPromiseCoroutine(promises, resolve, reject));
                    });
        }

        private static IEnumerator WrapEnumerator(IEnumerator coroutine, Action resolve, Action<Exception> reject)
        {
            bool raisedError = false;
            while (true)
            {
                try
                {
                    if (!coroutine.MoveNext())
                    {
                        break;
                    }
                }
                catch (Exception e)
                {
                    raisedError = true;
                    reject(e);

                    break;
                }

                yield return coroutine.Current;
            }

            try
            {
                if (!raisedError)
                {
                     resolve();
                }
            }
            finally
            {
                var d = coroutine as IDisposable;
                if (d != null)
                {
                    d.Dispose();
                }
            }
        }

        private static IEnumerator WaitAsyncOperation<T>(T asyncOperation)
                where T : AsyncOperation
        {
            if (asyncOperation == null) throw new ArgumentNullException("asyncOperation");

            yield return asyncOperation;
        }

        private static IEnumerator AllPromiseCoroutine<T>(Promise<T>[] promises, Action<T[]> onFulfilled, Action<Exception> onRejected)
        {
            if (promises == null || _.Any(promises, p => p == null)) throw new ArgumentNullException("promises");
            if (onFulfilled == null) throw new ArgumentNullException("onFulfilled");
            if (onRejected == null) throw new ArgumentNullException("onRejected");

            var pendings = _.ToList(_.Map(promises, (p, i) => _.Pair(i, p)));
            var results = new T[promises.Length];

            while (true)
            {
                for (int i = 0; i < pendings.Count; ++i)
                {
                    Promise<T> promise = pendings[i].Value;
                    if (promise.HasError)
                    {
                        onRejected(promise.Error);
                        yield break;
                    }
                    else if (promise.HasValue)
                    {
                        int index = pendings[i].Key;
                        results[index] = promise.Result;

                        pendings.RemoveAtSwap(i);
                        i -= 1;
                    }
                }

                if (_.None(pendings))
                {
                    onFulfilled(results);
                    yield break;
                }

                yield return null;
            }
        }
    }

    public sealed class Promise<T> : CustomYieldInstruction
    {
        public Promise(MonoBehaviour owner, Action<Action<T>, Action<Exception>> fn)
            : this(owner)
        {
            if (fn == null) throw new ArgumentNullException("fn");

            Action<T> resolve = arg =>
            {
                if (_state != PromiseState.Pending) throw new InvalidOperationException("상태가 확정된 프로미스에 resolve를 호출할 수 없습니다.");

                _value = arg;
                _state = PromiseState.Fulfilled;
            };
            Action<Exception> reject = error =>
            {
                if (_state != PromiseState.Pending) throw new InvalidOperationException("상태가 확정된 프로미스에 reject를 호출할 수 없습니다.");

                _error = error;
                _state = PromiseState.Rejected;
            };

            try
            {
                fn(resolve, reject);
            }
            catch (Exception e)
            {
                reject(e);
            }
        }

        public Promise(MonoBehaviour owner)
        {
            if (owner == null) throw new ArgumentNullException("owner");

            _owner = owner;
            _state = PromiseState.Pending;
        }

        public Promise<Unit> Then(Action<T> onFulfilled, Action<Exception> onRejected = null)
        {
            var next = new Promise<Unit>(_owner);

            Action onFulfilledWrapper = null;
            if (onFulfilled != null)
            {
                onFulfilledWrapper = () => onFulfilled(_value);
            }

            _owner.StartCoroutine(next.WaitPromiseCoroutine(this, onFulfilledWrapper, onRejected));

            return next;
        }

        public Promise<TResult> Then<TResult>(Func<T, TResult> onFulfilled, Action<Exception> onRejected = null)
        {
            var next = new Promise<TResult>(_owner);

            Action onFulfilledWrapper = null;
            if (onFulfilled != null)
            {
                onFulfilledWrapper = () => next._value = onFulfilled(_value);
            }

            _owner.StartCoroutine(next.WaitPromiseCoroutine(this, onFulfilledWrapper, onRejected));

            return next;
        }

        public Promise<TResult> Then<TResult>(Func<T, TResult> onFulfilled, Func<Exception, TResult> onRejected)
        {
            var next = new Promise<TResult>(_owner);

            Action onFulfilledWrapper = null;
            if (onFulfilled != null)
            {
                onFulfilledWrapper = () => next._value = onFulfilled(_value);
            }

            Action<Exception> onRejectedWrapper = null;
            if (onRejected != null)
            {
                onRejectedWrapper = error => next._value = onRejected(error);
            }

            _owner.StartCoroutine(next.WaitPromiseCoroutine(this, onFulfilledWrapper, onRejectedWrapper));

            return next;
        }

        public Promise<TResult> ThenPromise<TResult>(Func<T, Promise<TResult>> onFulfilled, Action<Exception> onRejected = null)
        {
            var next = new Promise<TResult>(_owner);

            Func<Promise<TResult>> onFulfilledWrapper = null;
            if (onFulfilled != null)
            {
                onFulfilledWrapper = () => onFulfilled(_value);
            }

            _owner.StartCoroutine(next.WaitNestedPromiseCoroutine(this, onFulfilledWrapper, onRejected));

            return next;
        }

        public Promise<TResult> ThenPromise<TResult>(Func<T, Promise<TResult>> onFulfilled, Func<Exception, TResult> onRejected)
        {
            var next = new Promise<TResult>(_owner);

            Func<Promise<TResult>> onFulfilledWrapper = null;
            if (onFulfilled != null)
            {
                onFulfilledWrapper = () => onFulfilled(_value);
            }

            Action<Exception> onRejectedWrapper = null;
            if (onRejected != null)
            {
                onRejectedWrapper = error => next._value = onRejected(error);
            }

            _owner.StartCoroutine(next.WaitNestedPromiseCoroutine(this, onFulfilledWrapper, onRejectedWrapper));

            return next;
        }

        public Promise<T> Catch(Action<Exception> onRejected)
        {
            return Then(_ => _value, onRejected);
        }

        public Promise<T> Catch(Func<Exception, T> onRejected)
        {
            return Then(_ => _value, onRejected);
        }

        public void Done(Action<T> onFulfilled, Action<Exception> onRejected = null)
        {
            Then(onFulfilled, onRejected).Catch(error => _owner.StartCoroutine(Throw(error)));
        }

        public MonoBehaviour Owner
        {
            get { return _owner; }
        }

        public PromiseState State
        {
            get { return _state; }
        }

        public bool HasValue
        {
            get { return _state == PromiseState.Fulfilled; }
        }

        public bool HasError
        {
            get { return _state == PromiseState.Rejected; }
        }

        public T Result
        {
            get { return _value; }
        }

        public Exception Error
        {
            get { return _error; }
        }

        #region Override from CustomYieldInstruction
        public override bool keepWaiting
        {
            get { return _state == PromiseState.Pending; }
        }
        #endregion

        private static IEnumerator Throw(Exception e)
        {
            yield return null;

            throw e;
        }

        private IEnumerator WaitPromiseCoroutine<U>(Promise<U> prev, Action onFulfilled, Action<Exception> onRejected)
        {
            if (prev == null) throw new ArgumentNullException("prev");

            // 항상 비동기로 처리.
            yield return null;

            while (prev._state == PromiseState.Pending)
            {
                yield return null;
            }

            try
            {
                if (prev._state == PromiseState.Fulfilled)
                {
                    if (onFulfilled != null)
                    {
                        onFulfilled();
                    }
                }
                else if (prev._state == PromiseState.Rejected)
                {
                    if (onRejected == null)
                    {
                        throw prev._error;
                    }
                    // onRejected가 예외를 처리하고 추가적인 예외를 발생시키지 않는다면 Fulfilled 상태가 된다.
                    onRejected(prev._error);
                }

                _state = PromiseState.Fulfilled;
            }
            catch (Exception e)
            {
                _error = e;
                _state = PromiseState.Rejected;
            }
        }

        private IEnumerator WaitNestedPromiseCoroutine<U>(Promise<U> prev, Func<Promise<T>> onFulfilled, Action<Exception> onRejected)
        {
            if (prev == null) throw new ArgumentNullException("prev");
            if (onFulfilled == null) throw new ArgumentNullException("onFulfilled");

            // 항상 비동기로 처리.
            yield return null;

            while (prev._state == PromiseState.Pending)
            {
                yield return null;
            }

            if (prev._state == PromiseState.Fulfilled)
            {
                Promise<T> nestedPromise;
                try
                {
                    nestedPromise = onFulfilled();

                    if (nestedPromise == null) throw new InvalidOperationException("프로미스를 반환하는 onFulfilled 함수에서 null을 반환해서는 안 됩니다.");
                }
                catch (Exception e)
                {
                    _error = e;
                    _state = PromiseState.Rejected;

                    yield break;
                }

                while (nestedPromise._state == PromiseState.Pending)
                {
                    yield return null;
                }

                if (nestedPromise._state == PromiseState.Fulfilled)
                {
                    _value = nestedPromise._value;
                    _state = PromiseState.Fulfilled;
                }
                else if (onRejected != null)
                {
                    try
                    {
                        onRejected(nestedPromise._error);
                        _state = PromiseState.Fulfilled;
                    }
                    catch (Exception e)
                    {
                        _error = e;
                        _state = PromiseState.Rejected;
                    }
                }
                else
                {
                    _error = nestedPromise._error;
                    _state = PromiseState.Rejected;
                }
            }
            else if (onRejected != null)
            {
                try
                {
                    onRejected(prev._error);
                    _state = PromiseState.Fulfilled;
                }
                catch (Exception e)
                {
                    _error = e;
                    _state = PromiseState.Rejected;
                }
            }
            else
            {
                _error = prev._error;
                _state = PromiseState.Rejected;
            }
        }

        private MonoBehaviour _owner;
        private PromiseState _state;
        private T _value;
        private Exception _error;
    }
}
