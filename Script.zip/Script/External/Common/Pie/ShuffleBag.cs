﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Pie
{
    /// <summary>
    /// 무작위로 섞인 목록을 순회하는 동안 중복된 요소를 출력하지 않는 시퀀스 생성기.
    /// </summary>
    /// <typeparam name="T">목록에 포함되는 요소의 타입.</typeparam>
    public class ShuffleBag<T> : IEnumerable<T>
    {
        /// <summary>
        /// 기본 크기와 유니티 랜덤 난수 생성기를 사용하여 목록을 생성하는 생성자.
        /// </summary>
        public ShuffleBag()
            : this(UnityRandom.Instance)
        {
        }

        /// <summary>
        /// 사용할 난수 생성기를 직접 지정하고 기본 크기를 가지는 목록을 생성하는 생성자.
        /// </summary>
        /// <param name="random">목록에서 무작위 요소를 선택할 때 사용할 난수 생성기.</param>
        public ShuffleBag(IRandom random)
        {
            _bag = new List<T>();
            _random = random;
        }

        /// <summary>
        /// 유니티 난수 생성기를 사용하고 목록의 기본 크기를 지정하여 목록을 생성하는 생성자.
        /// </summary>
        /// <param name="capacity">목록의 기본 크기.</param>
        public ShuffleBag(int capacity)
            : this(capacity, UnityRandom.Instance)
        {
        }

        /// <summary>
        /// 목록의 기본 크기와 난수 생성기를 직접 지정하여 목록을 생성하는 생성자.
        /// </summary>
        /// <param name="capacity">목록의 기본 크기.</param>
        /// <param name="random">목록에서 무작위 요소를 선택할 때 사용할 난수 생성기.</param>
        public ShuffleBag(int capacity, IRandom random)
        {
            _bag = new List<T>(capacity);
            _random = random;
        }

        #region Implementation of IEnumerable<T>
        public IEnumerator<T> GetEnumerator()
        {
            int cnt = _bag.Count;
            for (int i = 0; i < cnt; ++i)
            {
                yield return Next();
            }
        }
        #endregion
        
        #region Implementation of IEnumerable
        IEnumerator IEnumerable.GetEnumerator()
        {
            int cnt = _bag.Count;
            for (int i = 0; i < cnt; ++i)
            {
                yield return Next();
            }
        }
        #endregion

        /// <summary>
        /// 목록에 요소를 추가한다.
        /// </summary>
        /// <param name="item">추가할 요소.</param>
        public void Add(T item)
        {
            _bag.Add(item);

            _cursor = _bag.Count - 1;
        }

        /// <summary>
        /// 지정한 수만큼의 요소를 목록에 추가한다.
        /// </summary>
        /// <param name="item">추가할 요소.</param>
        /// <param name="quantity">추가할 요소의 수. 1 이상이어야 한다.</param>
        public void Add(T item, int quantity)
        {
            if (quantity < 1)
            {
                throw new ArgumentException("추가하려는 요소의 수가 1보다 작습니다", "quantity");
            }

            if (_bag.Capacity < _bag.Count + quantity)
            {
                _bag.Capacity = _bag.Count + quantity;
            }

            for (int i = 0; i < quantity; ++i)
            {
                _bag.Add(item);
            }

            _cursor = _bag.Count - 1;
        }

        /// <summary>
        /// 목록에서 무작위로 선택된 요소를 반환한다.
        /// </summary>
        /// <remarks>목록에 새로운 요소를 추가하지 않는다면 목록에 있는 모든 요소를 반환할 때까지 중복된 요소를 반환하지 않는다.</remarks>
        /// <returns>무작위로 선택된 요소.</returns>
        public T Next()
        {
            if (Count < 1)
            {
                throw new InvalidOperationException("요소가 한 개도 없는 상태에서 호출할 수 없습니다.");
            }

            // 커서의 위치가 1보다 작다면 커서 위치를 리셋하고 첫번째 요소를 반환한다.
            if (_cursor < 1)
            {
                _cursor = Count - 1;
                return _bag[0];
            }

            // 현재 커서 위치를 포함한 범위에서 무작위로 요소를 선택하고 해당 요소를 현재 커서 위치와 교환한다.
            // 커서의 위치를 감소하고, 선택된 요소를 반환한다.
            int grab = _random.Next(_cursor + 1);
            T retval = _bag[grab];

            // 두 인덱스의 값을 교환한다.
            T temp = _bag[_cursor];
            _bag[_cursor] = _bag[grab];
            _bag[grab] = temp;

            _cursor -= 1;
            return retval;
        }

        /// <summary>
        /// 메모리를 재할당하지 않고 요소를 추가할 수 있는 목록의 크기.
        /// </summary>
        public int Capacity
        {
            get { return _bag.Capacity; }
        }

        /// <summary>
        /// 현재 목록에 포함된 요소의 수.
        /// </summary>
        public int Count
        {
            get { return _bag.Count; }
        }

        private readonly List<T> _bag;

        private IRandom _random;
        private int _cursor = -1;
    }
}
