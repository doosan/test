﻿using UnityEngine;
using UnityEditor;

namespace Pie
{
    [CustomPropertyDrawer(typeof(Range))]
    public class RangePropertyDrawer : PropertyDrawer
    {
        #region Overrides
        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            label = EditorGUI.BeginProperty(position, label, property);

            Rect nonLabelRect = EditorGUI.PrefixLabel(position, label);
            float width = nonLabelRect.width / 2.0f;
            Rect beginRect = new Rect(nonLabelRect.x, nonLabelRect.y, width, nonLabelRect.height);
            Rect endRect = beginRect;
            endRect.x += width;

            var style = new GUIStyle();
            style.alignment = TextAnchor.MiddleRight;
            style.padding = new RectOffset(0, 3, 0, 0);
            style.normal.textColor = Color.gray;

            EditorGUI.indentLevel = 0;

            SerializedProperty beginProperty = property.FindPropertyRelative("_begin");
            EditorGUI.PropertyField(beginRect, beginProperty, GUIContent.none);
            EditorGUI.LabelField(beginRect, "begin", style);

            SerializedProperty endProperty = property.FindPropertyRelative("_end");
            EditorGUI.PropertyField(endRect, endProperty, GUIContent.none);
            EditorGUI.LabelField(endRect, "end", style);

            if (beginProperty.floatValue > endProperty.floatValue)
            {
                endProperty.floatValue = beginProperty.floatValue;
            }

            EditorGUI.EndProperty();
        }
        #endregion
    }
}
