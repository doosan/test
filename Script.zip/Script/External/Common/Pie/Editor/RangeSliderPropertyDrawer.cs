﻿using UnityEngine;
using UnityEditor;

namespace Pie
{
    [CustomPropertyDrawer(typeof(RangeSliderAttribute))]
    public class RangerSliderPropertyDrawer : PropertyDrawer
    {
        #region Overrides
        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            return property.type != "Range"
                    ? EditorGUI.GetPropertyHeight(property, label)
                    : base.GetPropertyHeight(property, label);
        }

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            if (property.type != "Range")
            {
                EditorGUI.PropertyField(position, property, label, true);
                return;
            }

            float propertyHeight = base.GetPropertyHeight(property, label);
            position.height = propertyHeight;

            EditorGUI.BeginProperty(position, label, property);

            // 라벨.
            Rect nonLabelRect = EditorGUI.PrefixLabel(position, GUIUtility.GetControlID(FocusType.Passive), label);

            var indent = EditorGUI.indentLevel;
            EditorGUI.indentLevel = 0;

            SerializedProperty beginProperty = property.FindPropertyRelative("_begin");
            SerializedProperty endProperty = property.FindPropertyRelative("_end");

            const float valueWidth = 50.0f;
            const float horizontalSpace = 5.0f;

            var beginValueRect = new Rect(
                    nonLabelRect.x,
                    nonLabelRect.y,
                    valueWidth,
                    nonLabelRect.height);
            var sliderRect = new Rect(
                    beginValueRect.xMax + horizontalSpace,
                    nonLabelRect.y,
                    nonLabelRect.width - ((valueWidth + horizontalSpace) * 2.0f),
                    nonLabelRect.height);
            var endValueRect = new Rect(
                    sliderRect.xMax + horizontalSpace,
                    nonLabelRect.y,
                    valueWidth,
                    nonLabelRect.height);

            var sliderAttribute = (RangeSliderAttribute)attribute;

            float beginValue = beginProperty.floatValue;
            float endValue = endProperty.floatValue;

            if (sliderAttribute.WholeNumbers)
            {
                beginValue = EditorGUI.IntField(beginValueRect, Mathf.RoundToInt(beginValue));
                endValue = EditorGUI.IntField(endValueRect, Mathf.RoundToInt(endValue));
            }
            else
            {
                beginValue = EditorGUI.FloatField(beginValueRect, beginValue);
                endValue = EditorGUI.FloatField(endValueRect, endValue);
            }

            beginValue = Mathf.Max(beginValue, sliderAttribute.Min);
            endValue = Mathf.Min(endValue, sliderAttribute.Max);

            if (beginValue > endValue)
            {
                endValue = beginValue;
            }

            EditorGUI.MinMaxSlider(sliderRect, ref beginValue, ref endValue, sliderAttribute.Min, sliderAttribute.Max);

            if (sliderAttribute.WholeNumbers)
            {
                beginValue = Mathf.Round(beginValue);
                endValue = Mathf.Round(endValue);
            }

            if (!Mathf.Approximately(beginProperty.floatValue, beginValue))
            {
                beginProperty.floatValue = beginValue;
            }

            if (!Mathf.Approximately(endProperty.floatValue, endValue))
            {
                endProperty.floatValue = endValue;
            }

            EditorGUI.indentLevel = indent;
            EditorGUI.EndProperty();
        }
        #endregion
    }
}
