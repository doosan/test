using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEditor;

namespace Pie
{
    public class BitmapFontImporterWindow : EditorWindow
    {
        [MenuItem("Window/Bitmap Font Importer")]
        public static void ShowWindow()
        {
            var window = EditorWindow.GetWindow<BitmapFontImporterWindow>("Bitmap Font Importer");
            window.minSize = new Vector2(200.0f, 200.0f);

            window.Show();
        }

        bool _forceMonospace;
        int _monospacePadding;
        //int _monospaceTabCount = 8;

        #region EditorWindow Messages
        void OnGUI()
        {
            GUILayout.Label("Font Data", EditorStyles.boldLabel);
            _fntAsset = (TextAsset)EditorGUILayout.ObjectField(_fntAsset, typeof (TextAsset), false);

            EditorGUILayout.Space();
            GUILayout.Label("Options", EditorStyles.boldLabel);

            _forceMonospace = EditorGUILayout.Toggle("Force Monospace", _forceMonospace);
            if (_forceMonospace)
            {

                EditorGUI.indentLevel += 1;

                _monospacePadding = Mathf.Max(EditorGUILayout.IntField("Padding", _monospacePadding), 0);
                //_monospaceTabCount = Mathf.Max(EditorGUILayout.IntField("Tab Count", _monospaceTabCount), 0);

                EditorGUI.indentLevel -= 1;
            }

            EditorGUILayout.Space();

            EditorGUI.BeginDisabledGroup(_fntAsset == null);
            if (GUILayout.Button("Generate Font"))
            {
                _error = string.Empty;

                GeneratorFontAsset();
            }
            EditorGUI.EndDisabledGroup();

            if (_error.Length != 0)
            {
                EditorGUILayout.HelpBox(_error, MessageType.Error);
            }
        }
        #endregion

        private void GeneratorFontAsset()
        {
            // fnt 파일 파싱.
            // TODO songkyoo 2015-06-03: 지원되지 않는 항목에 대한 경고 출력.
            string[] lines = _fntAsset.text.Split(new [] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            if (lines.Length < 4)
            {
                _error = "올바른 fnt 파일 형식이 아닙니다.";
                return;
            }

            Func<int, string, Dictionary<string, string>> parse = (row, tag) => {

                string line = lines[row];
                int index = line.IndexOf(' ');

                if (line.Substring(0, index) != tag)
                {
                    _error = string.Format("{0} 행은 {1} 태그를 가지고 있지 않습니다.", row + 1, tag);
                    return null;
                }

                var splitted = new List<string>();

                index += 1;

                while (index < line.Length)
                {
                    int keyStartIndex = index;
                    int seperatorIndex = line.IndexOf('=', keyStartIndex);

                    // NOTE songkyoo 2015-11-09: 문자열 안에 이스케이프 문자가 없다고 가정한다.
                    if (line[seperatorIndex + 1] == '"')
                    {
                        index = line.IndexOf("\" ", seperatorIndex + 2);
                        if (index != -1)
                        {
                            index += 1;
                        }
                        else if (line[line.Length - 1] == '"')
                        {
                            index = line.Length;
                        }
                        else
                        {
                            _error = string.Format("올바른 형식의 문자열이 아닙니다.(행: {0}, 열: {1})", row + 1, seperatorIndex + 1);
                            return null;
                        }
                    }
                    else
                    {
                        index = line.IndexOf(' ', keyStartIndex);
                        if (index == -1)
                        {
                            index = line.Length;
                        }
                    }

                    splitted.Add(line.Substring(keyStartIndex, index - keyStartIndex));

                    while (index < line.Length && line[index] == ' ')
                    {
                        index += 1;
                    }
                }

                var dict = new Dictionary<string, string>();
                for (int i = 0; i < splitted.Count; ++i)
                {
                    int splitterIndex = splitted[i].IndexOf('=');
                    if (splitterIndex == -1)
                    {
                        _error = "키=값 형식이 올바르지 않습니다.";
                        return null;
                    }

                    string key = splitted[i].Substring(0, splitterIndex);
                    string value = splitted[i].Substring(splitterIndex + 1);
                    if (value.Length > 1 && value[0] == '"')
                    {
                        value = value.Substring(1, value.Length - 2);
                    }

                    dict.Add(key, value);
                }

                return dict;
            };

            string rootPath = Path.GetDirectoryName(AssetDatabase.GetAssetPath(_fntAsset));
            string exportPath = rootPath + "/" + Path.GetFileNameWithoutExtension(_fntAsset.name);
            string fontPath = exportPath + ".fontsettings";
            string materialPath = exportPath + ".mat";

            bool isReplaceMode = false;
            var font = AssetDatabase.LoadAssetAtPath<Font>(fontPath);
            if (font != null)
            {
                isReplaceMode = true;
            }
            else
            {
                // face를 읽도록 수정.
                font = new Font(_fntAsset.name);
            }

            var info = parse(0, "info");
            if (info == null)
            {
                return;
            }

            double size;
            if (!double.TryParse(info["size"], out size))
            {
                _error = "size 값이 올바르지 않습니다.";
                return;
            }

            var common = parse(1, "common");
            if (common == null)
            {
                return;
            }

            float lineHeight;
            if (!float.TryParse(common["lineHeight"], out lineHeight))
            {
                _error = "lineHeight 값이 올바르지 않습니다.";
                return;
            }

            float @base;
            if (!float.TryParse(common["base"], out @base))
            {
                _error = "base 값이 올바르지 않습니다.";
                return;
            }

            int scaleW;
            int scaleH;
            if (!int.TryParse(common["scaleW"], out scaleW))
            {
                _error = "scaleW 값이 올바르지 않습니다.";
                return;
            }

            if (!int.TryParse(common["scaleH"], out scaleH))
            {
                _error = "scaleH 값이 올바르지 않습니다.";
                return;
            }

            // TODO songkyoo 2015-06-04: 여러 페이지를 쓸 경우 에러 출력.
            var page = parse(2, "page");
            if (page == null)
            {
                return;
            }

            bool needCreateMaterial = false;
            if (font.material == null)
            {
                string texPath = rootPath + "/" + Path.GetFileName(page["file"]);
                var tex = AssetDatabase.LoadAssetAtPath<Texture2D>(texPath);
                if (tex == null)
                {
                    _error = string.Format("텍스처를 로드할 수 없습니다.({0})", texPath);
                    return;
                }

                var mat = new Material(Shader.Find("UI/Default Font"));
                mat.mainTexture = tex;
                font.material = mat;

                needCreateMaterial = true;
            }

            var chars = parse(3, "chars");
            if (chars == null)
            {
                return;
            }

            int charCount;
            if (!int.TryParse(chars["count"], out charCount))
            {
                _error = "count 값이 올바르지 않습니다.";
                return;
            }

            float texWidth = scaleW;
            float texHeight = scaleH;

            int maxWidth = 0;

            var charInfos = new CharacterInfo[charCount];
            int charBaseLine = 4;
            for (int i = 0; i < charCount; ++i)
            {
                var charNode = parse(charBaseLine + i, "char");
                if (charNode == null)
                {
                    return;
                }

                int id;
                int x;
                int y;
                int width;
                int height;
                int xoffset;
                int yoffset;
                int xadvance;

                if (!int.TryParse(charNode["id"], out id) ||
                    !int.TryParse(charNode["x"], out x) ||
                    !int.TryParse(charNode["y"], out y) ||
                    !int.TryParse(charNode["width"], out width) ||
                    !int.TryParse(charNode["height"], out height) ||
                    !int.TryParse(charNode["xoffset"], out xoffset) ||
                    !int.TryParse(charNode["yoffset"], out yoffset) ||
                    !int.TryParse(charNode["xadvance"], out xadvance))
                {
                    _error = "char 값이 올바르지 않습니다.";
                    return;
                }

                if (width > maxWidth)
                {
                    maxWidth = width;
                }

                var uv = new Rect();
                uv.x = x / texWidth;
                uv.y = y / texHeight;
                uv.width = width / texWidth;
                uv.height = height / texHeight;
                uv.y = 1.0f - (uv.y + uv.height);

                charInfos[i] = new CharacterInfo {
                    index = id,
                    advance = xadvance,
                    uvBottomLeft = new Vector2(uv.xMin, uv.yMin),
                    uvBottomRight = new Vector2(uv.xMax, uv.yMin),
                    uvTopLeft = new Vector2(uv.xMin, uv.yMax),
                    uvTopRight = new Vector2(uv.xMax, uv.yMax),
                    minX = xoffset,
                    maxX = xoffset + width,
                    minY = -(yoffset + height),
                    maxY = -yoffset
                };
            }

            if (_forceMonospace)
            {
                for (int i = 0; i < charCount; ++i)
                {
                    charInfos[i].advance = maxWidth + (_monospacePadding * 2);

                    int width = charInfos[i].maxX - charInfos[i].minX;
                    int xoffset = ((maxWidth - width) / 2) + _monospacePadding;

                    charInfos[i].minX = xoffset;
                    charInfos[i].maxX = xoffset + width;
                }

                // TODO songkyoo 2015-12-17: 탭(id = 9)은 별도로 수정.
            }

            font.characterInfo = charInfos;

            var serilizedFont = new SerializedObject(font);
            serilizedFont.FindProperty("m_FontSize").floatValue = @base;
            serilizedFont.FindProperty("m_LineSpacing").floatValue = lineHeight;

            // TODO songkyoo 2015-11-13: 커닝 페어 추가.

            serilizedFont.ApplyModifiedPropertiesWithoutUndo();

            if (needCreateMaterial)
            {
                AssetDatabase.CreateAsset(font.material, materialPath);
            }

            if (isReplaceMode)
            {
                EditorUtility.SetDirty(font);
                AssetDatabase.SaveAssets();
            }
            else
            {
                AssetDatabase.CreateAsset(font, fontPath);
            }
        }

        private TextAsset _fntAsset;
        private string _error = string.Empty;
    }
}
