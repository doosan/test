﻿using System;
using UnityEngine;

namespace Pie
{
    /// <summary>
    /// 편의성 함수를 가지는 클래스.
    /// </summary>
    public static partial class Utils
    {
        public static float NormalizeAngle(float degree)
        {
            float result = degree - (Mathf.Floor(degree / 360.0f) * 360.0f);
            return result > 180.0f ? result - 360.0f : result;
        }

        public static void Swap<T>(ref T x, ref T y)
        {
            T temp = x;
            x = y;
            y = temp;
        }

        public static byte HexToByte(char c)
        {
            switch (c)
            {
            case '0': return 0;
            case '1': return 1;
            case '2': return 2;
            case '3': return 3;
            case '4': return 4;
            case '5': return 5;
            case '6': return 6;
            case '7': return 7;
            case '8': return 8;
            case '9': return 9;
            case 'A': return 10;
            case 'B': return 11;
            case 'C': return 12;
            case 'D': return 13;
            case 'E': return 14;
            case 'F': return 15;
            case 'a': return 10;
            case 'b': return 11;
            case 'c': return 12;
            case 'd': return 13;
            case 'e': return 14;
            case 'f': return 15;
            }

            throw new ArgumentException("유효한 16진수 문자가 아닙니다.", "c");
        }

        /// <summary>
        /// 바이트 배열을 16진수 형식 문자열로 변환한다.
        /// <seealso cref="Utils.TryParseBytes"/>
        /// </summary>
        /// <param name="bytes">문자열로 변환할 바이트 배열.</param>
        /// <returns>바이트 배열. 원소 1개당 2개의 문자로 변환된다. null이거나 빈 배열일 경우 빈 문자열을 반환한다.</returns>
        public static string StringifyBytes(byte[] bytes)
        {
            if (bytes == null || bytes.Length == 0)
            {
                return string.Empty;
            }

            const string hexChars = "0123456789ABCDEF";

            var chars = new char[bytes.Length * 2];
            for (int i = 0; i < bytes.Length; i += 1)
            {
                byte b = bytes[i];
                int index = i * 2;
                chars[index + 0] = hexChars[b >> 4];
                chars[index + 1] = hexChars[b & 0x0F];
            }

            return new string(chars);
        }

        /// <summary>
        /// <see cref="System.Char.IsDigit"/>와 다르게 문자가 순수하게 0에서 9사이를 나타내는지 확인한다.
        /// </summary>
        /// <param name="c">확인할 문자.</param>
        /// <returns>0에서 9사이에 포함되는 문자라면 <c>true</c>, 그렇지 않다면 <c>false</c>.</returns>
        public static bool IsDigit(char c)
        {
            return (c >= '0' && c <= '9');
        }

        /// <summary>
        /// 문자가 16진수를 나타내는지 확인한다.
        /// </summary>
        /// <param name="c">확인할 문자.</param>
        /// <returns>문자가 16진수라면 <c>true</c>, 그렇지 않다면 <c>false</c>.</returns>
        public static bool IsHexDigit(char c)
        {
            return (c >= '0' && c <= '9') ||
                   (c >= 'A' && c <= 'F') ||
                   (c >= 'a' && c <= 'f');
        }

        public static int FloorClosestPowerOfTwo(int value)
        {
            int last = 1;
            for (int i = 1; i < 16; ++i)
            {
                int current = 2 << i;
                if (value < current)
                {
                    return last;
                }

                last = current;
            }

            return 0;
        }

        public static int CeilClosestPowerOfTwo(int value)
        {
            int last = 2 << 15;
            for (int i = 14; i >= 0; --i)
            {
                int current = 2 << i;
                if (value > current)
                {
                    return last;
                }

                last = current;
            }

            return 0;
        }
    }
}
