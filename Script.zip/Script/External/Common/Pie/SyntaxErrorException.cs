﻿using System;

namespace Pie
{
    /// <summary>
    /// 구조적인 문자열을 파싱 중에 문법적인 오류가 있는 경우 발생한다.
    /// </summary>
    public sealed class SyntaxErrorException : Exception
    {
        // TODO songkyoo 2016-09-01: string message, string text, int position, int rowNumber, int columnNumber, Exception innerException

        public SyntaxErrorException(string message, string text, int rowNumber, int columnNumber)
            : base(string.Format("{0}{3}행: {1}{3}열: {2}", message, rowNumber, columnNumber, Environment.NewLine))
        {
            Text = text;
            RowNumber = rowNumber;
            ColumnNumber = columnNumber;
        }

        /// <summary>
        /// 예외가 발생한 문자열.
        /// </summary>
        public string Text
        {
            get;
            private set;
        }

        public int RowNumber
        {
            get;
            private set;
        }

        public int ColumnNumber
        {
            get;
            private set;
        }
    }
}
