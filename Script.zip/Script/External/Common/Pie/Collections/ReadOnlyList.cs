﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Pie.Collections
{
    public interface IReadOnlyList<T> : IReadOnlyCollection<T>, IEnumerable
    {
        T this[int index]
        {
            get;
        }
    }

    public class ReadOnlyList<T> : IReadOnlyList<T>
    {
        public ReadOnlyList(IList<T> source)
        {
            if (source == null)
            {
                throw new ArgumentNullException("source");
            }

            Items = source;
        }

        #region Implementation of IEnumerable<T>
        public IEnumerator<T> GetEnumerator()
        {
            return Items.GetEnumerator();
        }
        #endregion

        #region Implementation of IEnumerable
        IEnumerator IEnumerable.GetEnumerator()
        {
            return Items.GetEnumerator();
        }
        #endregion

        #region Implementation of IReadOnlyCollection<T>
        public int Count
        {
            get { return Items.Count; }
        }
        #endregion

        #region Implementation of IReadOnlyList<T>
        public T this[int index]
        {
            get { return Items[index]; }
        }
        #endregion

        public IList<T> Items
        {
            get;
            private set;
        }
    }
}
