﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Pie.Collections
{
    public interface IReadOnlyCollection<T> : IEnumerable<T>, IEnumerable
    {
        int Count
        {
            get;
        }
    }

    public class ReadOnlyCollection<T> : IReadOnlyCollection<T>
    {
        public ReadOnlyCollection(ICollection<T> source)
        {
            if (source == null)
            {
                throw new ArgumentNullException("source");
            }

            Items = source;
        }

        #region Implementation of IEnumerable<T>
        public IEnumerator<T> GetEnumerator()
        {
            return Items.GetEnumerator();
        }
        #endregion

        #region Implementation of IEnumerable
        IEnumerator IEnumerable.GetEnumerator()
        {
            return Items.GetEnumerator();
        }
        #endregion

        #region Implementation of IReadOnlyCollection<T>
        public int Count
        {
            get { return Items.Count; }
        }
        #endregion

        public ICollection<T> Items
        {
            get;
            private set;
        }
    }
}
