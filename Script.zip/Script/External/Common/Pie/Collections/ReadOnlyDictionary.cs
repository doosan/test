﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Pie.Collections
{
    public interface IReadOnlyDictionary<TKey, TValue> : IReadOnlyCollection<KeyValuePair<TKey, TValue>>, IEnumerable
    {
        bool ContainsKey(TKey key);

        bool TryGetValue(TKey key, out TValue value);

        TValue this[TKey key]
        {
            get;
        }

        IEnumerable<TKey> Keys
        {
            get;
        }

        IEnumerable<TValue> Values
        {
            get;
        }
    }

    public class ReadOnlyDictionary<TKey, TValue> : IReadOnlyDictionary<TKey, TValue>
    {
        public ReadOnlyDictionary(IDictionary<TKey, TValue> source)
        {
            if (source == null)
            {
                throw new ArgumentNullException("source");
            }

            Items = source;
        }

        #region Implementation of IEnumerable<T>
        public IEnumerator<KeyValuePair<TKey, TValue>> GetEnumerator()
        {
            return Items.GetEnumerator();
        }
        #endregion

        #region Implementation of IEnumerable
        IEnumerator IEnumerable.GetEnumerator()
        {
            return Items.GetEnumerator();
        }
        #endregion

        #region Implementation of IReadOnlyCollection<T>
        public int Count
        {
            get { return Items.Count; }
        }
        #endregion

        #region Implementation of IReadOnlyDictionary<TKey,TValue>
        public bool ContainsKey(TKey key)
        {
            return Items.ContainsKey(key);
        }

        public bool TryGetValue(TKey key, out TValue value)
        {
            return Items.TryGetValue(key, out value);
        }

        public TValue this[TKey key]
        {
            get { return Items[key]; }
        }

        public IEnumerable<TKey> Keys
        {
            get { return Items.Keys; }
        }

        public IEnumerable<TValue> Values
        {
            get { return Items.Values; }
        }
        #endregion

        public IDictionary<TKey, TValue> Items
        {
            get;
            private set;
        }
    }
}
