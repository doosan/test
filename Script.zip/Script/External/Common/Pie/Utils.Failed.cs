﻿using System;

namespace Pie
{
    using Object = UnityEngine.Object;

    public static partial class Utils
    {
        public static Func<bool, object, bool> Failed(Action<object> log)
        {
            return (condition, msg) =>
            {
                if (!condition)
                {
                    log(msg);
                }
                return !condition;
            };
        }

        public static Func<bool, object, bool> Failed(Action<object, Object> log, Object context)
        {
            return (condition, msg) =>
            {
                if (!condition)
                {
                    log(msg, context);
                }
                return !condition;
            };
        }

        //public static Func<bool, object, bool> Failed(Action<Object, object> log, Object context)
        //{
        //    return (condition, msg) =>
        //    {
        //        if (!condition)
        //        {
        //            log(context, msg);
        //        }
        //        return !condition;
        //    };
        //}
    }
}
