﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pie
{
    public interface ICollector<T, TAccumulator, TResult>
    {
        void Accumulate(TAccumulator accumulator, T value);
        TResult Finish(TAccumulator accumulator);
        TAccumulator Supply();
    }

    public static partial class Functional
    {
        //public static IEnumerable<TResult> Map<T, TResult>(IList<T> source, Func<T, int, TResult> mapper)
        //{
        //    if (source == null) throw new ArgumentNullException("source");
        //    if (mapper == null) throw new ArgumentNullException("mapper");

        //    int cnt = source.Count;
        //    for (int i = 0; i < cnt; i += 1)
        //    {
        //        yield return mapper(source[i], i);
        //    }
        //}

        //public static IEnumerable<TResult> Map<T, TResult>(IList<T> source, Func<T, TResult> mapper)
        //{
        //    if (source == null) throw new ArgumentNullException("source");
        //    if (mapper == null) throw new ArgumentNullException("mapper");

        //    int cnt = source.Count;
        //    for (int i = 0; i < cnt; i += 1)
        //    {
        //        yield return mapper(source[i]);
        //    }
        //}

        public static IEnumerable<TResult> Map<T, TResult>(IEnumerable<T> source, Func<T, int, TResult> mapper)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (mapper == null) throw new ArgumentNullException("mapper");

            int i = 0;
            foreach (T value in source)
            {
                yield return mapper(value, i);
                i += 1;
            }
        }

        public static IEnumerable<TResult> Map<T, TResult>(IEnumerable<T> source, Func<T, TResult> mapper)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (mapper == null) throw new ArgumentNullException("mapper");

            foreach (T value in source)
            {
                yield return mapper(value);
            }
        }

        public static IEnumerable<TResult> FlatMap<T, TResult>(IEnumerable<T> source, Func<T, int, IEnumerable<TResult>> mapper)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (mapper == null) throw new ArgumentNullException("mapper");

            int i = 0;
            foreach (T value in source)
            {
                foreach (TResult result in mapper(value, i))
                {
                    yield return result;
                }
                i += 1;
            }
        }

        public static IEnumerable<TResult> FlatMap<T, TResult>(IEnumerable<T> source, Func<T, IEnumerable<TResult>> mapper)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (mapper == null) throw new ArgumentNullException("mapper");

            foreach (T value in source)
            {
                foreach (TResult result in mapper(value))
                {
                    yield return result;
                }
            }
        }

        // public IEnumerable<TResult> FlatMap<TCollection, TResult>(IEnumerable<T> source, Func<T, int, IEnumerable<TCollection>> collectionMapper, IEnumerable<T, TCollection> resultMapper)

        // public IEnumerable<TResult> FlatMap<TCollection, TResult>(IEnumerable<T> source, Func<T, IEnumerable<TCollection>> collectionMapper, IEnumerable<T, TCollection> resultMapper)

        public static IEnumerable<T> Filter<T>(IList<T> source, Func<T, int, bool> predicate) {
            if (source == null) throw new ArgumentNullException("source");
            if (predicate == null) throw new ArgumentNullException("predicate");

            int cnt = source.Count;
            for (int i = 0; i < cnt; i += 1)
            {
                if (predicate(source[i], i))
                {
                    yield return source[i];
                }
            }
        }

        public static IEnumerable<T> Filter<T>(IList<T> source, Func<T, bool> predicate) {
            if (source == null) throw new ArgumentNullException("source");
            if (predicate == null) throw new ArgumentNullException("predicate");

            int cnt = source.Count;
            for (int i = 0; i < cnt; i += 1)
            {
                if (predicate(source[i]))
                {
                    yield return source[i];
                }
            }
        }

        public static IEnumerable<T> Filter<T>(IEnumerable<T> source, Func<T, int, bool> predicate)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (predicate == null) throw new ArgumentNullException("predicate");

            int i = 0;
            foreach (T value in source)
            {
                if (predicate(value, i))
                {
                    yield return value;
                }
                i += 1;
            }
        }

        public static IEnumerable<T> Filter<T>(IEnumerable<T> source, Func<T, bool> predicate)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (predicate == null) throw new ArgumentNullException("predicate");

            foreach (T value in source)
            {
                if (predicate(value))
                {
                    yield return value;
                }
            }
        }

        public static IEnumerable<T> Reject<T>(IList<T> source, Func<T, int, bool> predicate)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (predicate == null) throw new ArgumentNullException("predicate");

            int cnt = source.Count;
            for (int i = 0; i < cnt; i += 1)
            {
                if (!predicate(source[i], i))
                {
                    yield return source[i];
                }
            }
        }

        public static IEnumerable<T> Reject<T>(IList<T> source, Func<T, bool> predicate)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (predicate == null) throw new ArgumentNullException("predicate");

            int cnt = source.Count;
            for (int i = 0; i < cnt; i += 1)
            {
                if (!predicate(source[i]))
                {
                    yield return source[i];
                }
            }
        }

        public static IEnumerable<T> Reject<T>(IEnumerable<T> source, Func<T, int, bool> predicate)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (predicate == null) throw new ArgumentNullException("predicate");

            int i = 0;
            foreach (T value in source)
            {
                if (!predicate(value, i))
                {
                    yield return value;
                }
                i += 1;
            }
        }

        public static IEnumerable<T> Reject<T>(IEnumerable<T> source, Func<T, bool> predicate)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (predicate == null) throw new ArgumentNullException("predicate");

            foreach (T value in source)
            {
                if (!predicate(value))
                {
                    yield return value;
                }
            }
        }

        public static IEnumerable<T> Take<T>(IEnumerable<T> source, int n)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (n < 0) throw new ArgumentException("n이 0보다 작습니다.", "n");

            var enumerator = source.GetEnumerator();
            for (var i = 0; i < n; i += 1)
            {
                if (!enumerator.MoveNext())
                {
                    yield break;
                }
                yield return enumerator.Current;
            }
        }

        public static T First<T>(IEnumerable<T> source, Func<T, bool> predicate)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (predicate == null) throw new ArgumentNullException("predicate");

            foreach (T value in source)
            {
                if (predicate(value))
                {
                    return value;
                }
            }
            throw new InvalidOperationException("시퀀스에 일치하는 요소가 없습니다.");
        }

        public static T First<T>(IEnumerable<T> source)
        {
            if (source == null) throw new ArgumentNullException("source");

            var enumerator = source.GetEnumerator();
            if (enumerator.MoveNext())
            {
                return enumerator.Current;
            }
            throw new InvalidOperationException("시퀀스에 요소가 없습니다.");
        }

        public static T FirstOrDefault<T>(IList<T> source, T defaultValue = default(T))
        {
            if (source == null)
            {
                throw new ArgumentNullException("source");
            }

            return source.Count > 0 ? source[0] : defaultValue;
        }

        public static T FirstOrDefault<T>(IEnumerable<T> source, Func<T, bool> predicate, T defaultValue = default(T))
        {
            if (source == null) throw new ArgumentNullException("source");
            if (predicate == null) throw new ArgumentNullException("predicate");

            foreach (T value in source)
            {
                if (predicate(value))
                {
                    return value;
                }
            }
            return defaultValue;
        }

        public static T FirstOrDefault<T>(IEnumerable<T> source, T defaultValue = default(T))
        {
            if (source == null) throw new ArgumentNullException("source");

            var enumerator = source.GetEnumerator();
            return enumerator.MoveNext() ? enumerator.Current : defaultValue;
        }

        // public IEnumerable<T> Initial(IEnumerable<T> source)

        public static IEnumerable<T> Skip<T>(IEnumerable<T> source, int n)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (n < 0) throw new ArgumentException("n이 0보다 작습니다.", "n");

            var enumerator = source.GetEnumerator();
            for (var i = 0; i < n; i += 1)
            {
                if (!enumerator.MoveNext())
                {
                    yield break;
                }
            }

            while (enumerator.MoveNext())
            {
                yield return enumerator.Current;
            }
        }

        // public T Last(IEnumerable<T> source, Func<T, bool> predicate)

        // public T Last(IEnumerable<T> source)

        // public T LastOrDefault(IEnumerable<T> source, Func<T, bool> predicate)

        // public T LastOrDefault(IEnumerable<T> source)

        public static IEnumerable<T> Rest<T>(IEnumerable<T> source)
        {
            if (source == null) throw new ArgumentNullException("source");

            return Skip(source, 1);
        }

        public static IEnumerable<T> Concat<T>(IEnumerable<T> first, IEnumerable<T> second)
        {
            if (first == null) throw new ArgumentNullException("first");
            if (second == null) throw new ArgumentNullException("second");

            foreach (T value in first)
            {
                yield return value;
            }

            foreach (T value in second)
            {
                yield return value;
            }
        }

        public static IEnumerable<T> Push<T>(IEnumerable<T> source, params T[] values)
        {
            if (source == null) throw new ArgumentNullException("source");

            foreach (T value in source)
            {
                yield return value;
            }

            foreach (T value in values)
            {
                yield return value;
            }
        }

        public static IEnumerable<T> Push<T>(IEnumerable<T> source, T value)
        {
            if (source == null) throw new ArgumentNullException("source");

            foreach (T t in source)
            {
                yield return t;
            }
            yield return value;
        }

        // public TResult Collect<TResult>(IEnumerable<T> source, ICollector<TResult> collector)

        public static TResult Reduce<T, TResult>(IEnumerable<T> source, TResult seed, Func<TResult, T, TResult> accumulator)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (accumulator == null) throw new ArgumentNullException("accumulator");

            TResult result = seed;
            foreach (T value in source)
            {
                result = accumulator(result, value);
            }
            return result;
        }

        public static T Reduce<T>(IEnumerable<T> source, Func<T, T, T> accumulator)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (accumulator == null) throw new ArgumentNullException("accumulator");

            var enumerator = source.GetEnumerator();
            if (!enumerator.MoveNext())
            {
                throw new InvalidOperationException("시퀀스에 요소가 없습니다.");
            }

            T result = enumerator.Current;
            while (enumerator.MoveNext())
            {
                result = accumulator(result, enumerator.Current);
            }
            return result;
        }

        public static bool All<T>(IEnumerable<T> source, Func<T, bool> predicate)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (predicate == null) throw new ArgumentNullException("predicate");

            var list = source as IList<T>;
            if (list != null)
            {
                for (int i = 0; i < list.Count; ++i)
                {
                    if (!predicate(list[i]))
                    {
                        return false;
                    }
                }
            }
            else
            {
                foreach (T value in source)
                {
                    if (!predicate(value))
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        public static bool Any<T>(IEnumerable<T> source, Func<T, bool> predicate)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (predicate == null) throw new ArgumentNullException("predicate");

            var list = source as IList<T>;
            if (list != null)
            {
                for (int i = 0; i < list.Count; ++i)
                {
                    if (predicate(list[i]))
                    {
                        return true;
                    }
                }
            }
            else
            {
                foreach (T value in source)
                {
                    if (predicate(value))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public static bool Any<T>(IEnumerable<T> source)
        {
            if (source == null) throw new ArgumentNullException("source");

            var list = source as IList<T>;
            if (list != null)
            {
                return list.Count > 0;
            }

            return source.GetEnumerator().MoveNext();
        }

        public static bool None<T>(IEnumerable<T> source, Func<T, bool> predicate)
        {
            return !Any(source, predicate);
        }

        public static bool None<T>(IEnumerable<T> source)
        {
            return !Any(source);
        }

        public static int Count<T>(IEnumerable<T> source)
        {
            if (source == null) throw new ArgumentNullException("source");

            var list = source as IList<T>;
            if (list != null)
            {
                return list.Count;
            }

            var cnt = 0;
            var enumerator = source.GetEnumerator();
            while (enumerator.MoveNext())
            {
                cnt += 1;
            }
            return cnt;
        }

        public static int Count<T>(IEnumerable<T> source, Func<T, bool> predicate)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (predicate == null) throw new ArgumentNullException("predicate");

            var cnt = 0;

            var list = source as IList<T>;
            if (list != null)
            {
                for (int i = 0; i < list.Count; ++i)
                {
                    if (predicate(list[i]))
                    {
                        cnt += 1;
                    }
                }
            }
            else
            {
                foreach (T value in source)
                {
                    if (predicate(value))
                    {
                        cnt += 1;
                    }
                }
            }
            return cnt;
        }

        public static void Each<T>(IEnumerable<T> source, Action<T, int> action)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (action == null) throw new ArgumentNullException("action");

            var list = source as IList<T>;
            if (list != null)
            {
                for (int i = 0; i < list.Count; ++i)
                {
                    action(list[i], i);
                }
            }
            else
            {
                int i = 0;
                foreach (T value in source)
                {
                    action(value, i);
                    i += 1;
                }
            }
        }

        public static void Each<T>(IEnumerable<T> source, Action<T> action)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (action == null) throw new ArgumentNullException("action");

            var list = source as IList<T>;
            if (list != null)
            {
                for (int i = 0; i < list.Count; ++i)
                {
                    action(list[i]);
                }
            }
            else
            {
                foreach (T value in source)
                {
                    action(value);
                }
            }
        }

        public static T[] ToArray<T>(IEnumerable<T> source)
        {
            if (source == null) throw new ArgumentNullException("source");

            var list = new List<T>(source);
            return list.ToArray();
        }

        public static TResult[] ToArray<T, TResult>(IEnumerable<T> source, Func<T, TResult> mapper)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (mapper == null) throw new ArgumentNullException("mapper");

            var list = new List<TResult>(Map(source, mapper));
            return list.ToArray();
        }

        public static List<T> ToList<T>(IEnumerable<T> source)
        {
            if (source == null) throw new ArgumentNullException("source");

            return new List<T>(source);
        }

        public static List<TResult> ToList<T, TResult>(IEnumerable<T> source, Func<T, TResult> mapper)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (mapper == null) throw new ArgumentNullException("mapper");

            return new List<TResult>(Map(source, mapper));
        }

        public static HashSet<T> ToSet<T>(IEnumerable<T> source)
        {
            if (source == null)
            {
                throw new ArgumentNullException("source");
            }

            return new HashSet<T>(source);
        }

        public static HashSet<TResult> ToSet<T, TResult>(IEnumerable<T> source, Func<T, TResult> mapper)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (mapper == null) throw new ArgumentNullException("mapper");

            return new HashSet<TResult>(Map(source, mapper));
        }

        public static Dictionary<TKey, T> ToDictionary<T, TKey>(
                IEnumerable<T> source,
                Func<T, TKey> keyMapper,
                IEqualityComparer<TKey> comparer = null)
        {
            return ToDictionary<T, TKey, T>(source, keyMapper, Identity, comparer);
        }

        public static Dictionary<TKey, TValue> ToDictionary<T, TKey, TValue>(
                IEnumerable<T> source,
                Func<T, TKey> keyMapper,
                Func<T, TValue> valueMapper,
                IEqualityComparer<TKey> comparer = null)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (keyMapper == null) throw new ArgumentNullException("keyMapper");
            if (valueMapper == null) throw new ArgumentNullException("valueMapper");

            var dict = new Dictionary<TKey, TValue>(comparer);
            foreach (T value in source)
            {
                dict.Add(keyMapper(value), valueMapper(value));
            }
            return dict;
        }

        public static KeyValuePair<TKey, TValue> Pair<TKey, TValue>(TKey key, TValue value)
        {
            return new KeyValuePair<TKey, TValue>(key, value);
        }

        public static string Join<T>(IEnumerable<T> source, string delimiter = null)
        {
            return Join(source, delimiter, string.Empty, string.Empty);
        }

        public static string Join<T>(IEnumerable<T> source, string delimiter, string prefix, string suffix)
        {
            if (source == null) throw new ArgumentNullException("source");

            var builder = new StringBuilder(prefix);

            var enumerator = source.GetEnumerator();
            if (enumerator.MoveNext())
            {
                builder.Append(enumerator.Current);

                while (enumerator.MoveNext())
                {
                    builder.Append(delimiter);
                    builder.Append(enumerator.Current);
                }
            }

            return builder.Append(suffix).ToString();
        }

        public static void Times(int count, Action<int> action)
        {
            if (action == null) throw new ArgumentNullException("action");

            for (int i = 0; i < count; ++i)
            {
                action(i);
            }
        }

        public static void Times(int count, Action action)
        {
            if (action == null) throw new ArgumentNullException("action");

            for (int i = 0; i < count; ++i)
            {
                action();
            }
        }

        /// <summary>
        /// 조건을 검사할 인스턴스와 인덱스를 인자로 받아 bool 타입을 반환하는 함수의 결과를 뒤집는 랩핑 함수를
        /// 반환한다.
        /// </summary>
        /// <typeparam name="T">함수의 인자로 전달되는 인스턴스의 타입.</typeparam>
        /// <param name="predicate">조건을 검사할 인스턴스와 인덱스를 인자로 받고 bool 타입을 반환하는 함수.</param>
        /// <returns>뒤집힌 결과를 반환하는 함수.</returns>
        public static Func<T, int, bool> Not<T>(Func<T, int, bool> predicate)
        {
            return (value, i) => !predicate(value, i);
        }

        /// <summary>
        /// 조건을 검사할 인스턴스를 인자로 받아 bool 타입을 반환하는 함수의 결과를 뒤집는 랩핑 함수를 반환한다.
        /// </summary>
        /// <typeparam name="T">함수의 인자로 전달되는 인스턴스의 타입.</typeparam>
        /// <param name="predicate">조건을 검사할 인스턴스를 인자로 받고 bool 타입을 반환하는 함수.</param>
        /// <returns>뒤집힌 결과를 반환하는 함수.</returns>
        public static Func<T, bool> Not<T>(Func<T, bool> predicate)
        {
            return value => !predicate(value);
        }

        public static Predicate<T> Not<T>(Predicate<T> predicate)
        {
            return value => !predicate(value);
        }

        public static T Identity<T>(T value)
        {
            return value;
        }

        public static Func<T> Always<T>(T value)
        {
            return () => value;
        }

        public static Comparison<T> ToComparison<T>(Func<T, T, bool> predicate)
        {
            if (predicate == null) throw new ArgumentNullException("predicate");

            return (x, y) =>
            {
                if (predicate(x, y))
                {
                    return -1;
                }
                else if (predicate(y, x))
                {
                    return 1;
                }
                return 0;
            };
        }

        public static IComparer<T> ToComparer<T>(Comparison<T> comparison)
        {
            if (comparison == null) throw new ArgumentNullException("comparison");

            return new ComparisonToComparer<T>(comparison);
        }

        //public static IComparer<T> ToComparer<T>(Func<T, T, bool> predicate)
        //{
        //    if (predicate == null) throw new ArgumentNullException("predicate");

        //    return new ComparisonToComparer<T>((x, y) =>
        //        {
        //            if (predicate(x, y))
        //            {
        //                return -1;
        //            }
        //            else if (predicate(y, x))
        //            {
        //                return 1;
        //            }
        //            return 0;
        //        });
        //}

        private sealed class ComparisonToComparer<T> : IComparer<T>
        {
            public ComparisonToComparer(Comparison<T> comparison)
            {
                _comparison = comparison;
            }

            #region Implementation of IComparer<T>
            public int Compare(T x, T y)
            {
                return _comparison(x, y);
            }
            #endregion

            private readonly Comparison<T> _comparison;
        }
    }
}
