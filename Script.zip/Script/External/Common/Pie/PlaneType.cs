﻿namespace Pie
{
    public enum PlaneType
    {
        XY,
        XZ,
        YZ
    }
}
