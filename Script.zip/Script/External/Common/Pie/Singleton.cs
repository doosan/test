﻿namespace Pie
{
    public abstract class Singleton<T> where T : Singleton<T>, new()
    {
        public static T Instance
        {
            get
            {
                if (_instance != null)
                {
                    return _instance;
                }

                _instance = new T();
                return _instance;
            }
        }

        public static bool HasInstance
        {
            get { return _instance != null; }
        }

        protected Singleton()
        {
        }

        private static T _instance;
    }
}
