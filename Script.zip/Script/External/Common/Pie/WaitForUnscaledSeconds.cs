﻿using UnityEngine;

namespace Pie
{
    public class WaitForUnscaledSeconds : CustomYieldInstruction
    {
        public WaitForUnscaledSeconds(float time)
        {
            _time = Time.unscaledTime + Mathf.Max(time, 0.0f);
        }

        #region Override from CustomYieldInstruction
        public override bool keepWaiting
        {
            get { return Time.unscaledTime < _time; }
        }
        #endregion

        private float _time;
    }
}
