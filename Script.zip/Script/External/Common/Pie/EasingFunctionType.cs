﻿using System;
using UnityEngine;

namespace Pie
{
    /// <summary>
    /// Easing 함수의 종류.
    /// </summary>
    public enum EasingFunctionType
    {
        Linear,
        SineIn,
        SineOut,
        SineInOut,
        QuadIn,
        QuadOut,
        QuadInOut,
        CubicIn,
        CubicOut,
        CubicInOut,
        QuartIn,
        QuartOut,
        QuartInOut,
        QuintIn,
        QuintOut,
        QuintInOut,
        ExpoIn,
        ExpoOut,
        ExpoInOut,
        CircIn,
        CircOut,
        CircInOut,
        BackIn,
        BackOut,
        BackInOut,
        ElasticIn,
        ElasticOut,
        ElasticInOut,
        BounceIn,
        BounceOut,
        BounceInOut
    }

    /// <summary>
    /// EasingFunctionType 확장 함수 클래스.
    /// </summary>
    public static class EasingFunctionsExtentions
    {
        /// <summary>
        /// Easing 함수의 종류로부터 대리자를 반환한다.
        /// </summary>
        /// <returns>Easing 함수 대리자.</returns>
        /// <param name="type">Easing 함수의 종류.</param>
        /// <exception cref="System.ArgumentException">
        /// <c>type</c>이 유효한 <c>EasingFunctionType</c>값이 아닐 경우.
        /// </exception>
        public static EasingFunctionDelegate GetFunction(this EasingFunctionType type)
        {
            switch (type)
            {
                case EasingFunctionType.Linear:       return EasingFunctions.Linear;
                case EasingFunctionType.SineIn:       return EasingFunctions.SineIn;
                case EasingFunctionType.SineOut:      return EasingFunctions.SineOut;
                case EasingFunctionType.SineInOut:    return EasingFunctions.SineInOut;
                case EasingFunctionType.QuadIn:       return EasingFunctions.QuadIn;
                case EasingFunctionType.QuadOut:      return EasingFunctions.QuadOut;
                case EasingFunctionType.QuadInOut:    return EasingFunctions.QuadInOut;
                case EasingFunctionType.CubicIn:      return EasingFunctions.CubicIn;
                case EasingFunctionType.CubicOut:     return EasingFunctions.CubicOut;
                case EasingFunctionType.CubicInOut:   return EasingFunctions.CubicInOut;
                case EasingFunctionType.QuartIn:      return EasingFunctions.QuartIn;
                case EasingFunctionType.QuartOut:     return EasingFunctions.QuartOut;
                case EasingFunctionType.QuartInOut:   return EasingFunctions.QuartInOut;
                case EasingFunctionType.QuintIn:      return EasingFunctions.QuintIn;
                case EasingFunctionType.QuintOut:     return EasingFunctions.QuintOut;
                case EasingFunctionType.QuintInOut:   return EasingFunctions.QuintInOut;
                case EasingFunctionType.ExpoIn:       return EasingFunctions.ExpoIn;
                case EasingFunctionType.ExpoOut:      return EasingFunctions.ExpoOut;
                case EasingFunctionType.ExpoInOut:    return EasingFunctions.ExpoInOut;
                case EasingFunctionType.CircIn:       return EasingFunctions.CircIn;
                case EasingFunctionType.CircOut:      return EasingFunctions.CircOut;
                case EasingFunctionType.CircInOut:    return EasingFunctions.CircInOut;
                case EasingFunctionType.BackIn:       return EasingFunctions.BackIn;
                case EasingFunctionType.BackOut:      return EasingFunctions.BackOut;
                case EasingFunctionType.BackInOut:    return EasingFunctions.BackInOut;
                case EasingFunctionType.ElasticIn:    return EasingFunctions.ElasticIn;
                case EasingFunctionType.ElasticOut:   return EasingFunctions.ElasticOut;
                case EasingFunctionType.ElasticInOut: return EasingFunctions.ElasticInOut;
                case EasingFunctionType.BounceIn:     return EasingFunctions.BounceIn;
                case EasingFunctionType.BounceOut:    return EasingFunctions.BounceOut;
                case EasingFunctionType.BounceInOut:  return EasingFunctions.BounceInOut;

                default:
                    throw new ArgumentException("잘못된 EasingFunctionType값입니다.", "type");
            }
        }
    }
}
