﻿using UnityEngine;

namespace Pie
{
    /// <summary>
    /// 유니티의 전역 랜덤 인스턴스를 IRandom 인터페이스로 랩핑한 클래스.
    /// </summary>
    /// <remarks>정적 멤버 Instance를 통해서만 접근할 수 있다.</remarks>
    public class UnityRandom : RandomBase
    {
        #region Overrides
        public override int Next(int minInclusive, int maxExclusive)
        {
            return Random.Range(minInclusive, maxExclusive);
        }

        public override float NextSingle(float minInclusive, float maxInclusive)
        {
            return Random.Range(minInclusive, maxInclusive);
        }

        public override double NextDouble()
        {
            return (double)Random.value * DoubleUIntMax;
        }

        public override double NextDouble(double minInclusive, double maxInclusive)
        {
            return minInclusive + ((maxInclusive - minInclusive) * (double)Random.value);
        }
        #endregion

        public static readonly UnityRandom Instance = new UnityRandom();

        private const double DoubleUIntMax = (double)uint.MaxValue / ((double)uint.MaxValue + 1.0);

        private UnityRandom()
        {
            // 외부 생성을 금지하기 위해서 private 생성자를 사용한다.
        }
    }
}
