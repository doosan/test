﻿using System;
using System.Collections.Generic;
using UnityEngine;
using Pie.Collections;

namespace Pie
{
    public interface IRandom
    {
        /// <summary>
        /// 0보다 크거나 같고 int.MaxValue보다 작은 int 형식의 값을 반환한다.
        /// </summary>
        /// <returns>0보다 크거나 같고 int.MaxValue보다 작은 int 형식의 값.</returns>
        int Next();

        /// <summary>
        /// 0보다 크거나 같고 maxExclusive보다 작은 int 형식의 값을 반환한다.
        /// </summary>
        /// <returns>0보다 크거나 같고 maxExclusive보다 작은 int 형식의 값.</returns>
        int Next(int maxExclusive);

        /// <summary>
        /// minInclusive보다 크거나 같고 maxExclusive보다 작은 int 형식의 값을 반환한다.
        /// </summary>
        /// <returns>minInclusive보다 크거나 같고 maxExclusive보다 작은 int 형식의 값.</returns>
        int Next(int minInclusive, int maxExclusive);

        /// <summary>
        /// 0보다 크거나 같고 1보다 작은 float 형식의 값을 반환한다.
        /// </summary>
        /// <returns>0보다 크거나 같고 1보다 작은 float 형식의 값.</returns>
        float NextSingle();

        float NextSingle(float maxInclusive);

        /// <summary>
        /// minInclusive보다 크거나 같고 maxInclusive보다 작거나 같은 float 형식의 값을 반환한다.
        /// </summary>
        /// <returns>minInclusive보다 크거나 같고 maxInclusive보다 작거나 같은 float 형식의 값.</returns>
        float NextSingle(float minInclusive, float maxInclusive);

        /// <summary>
        /// 0보다 크거나 같고 1보다 작은 double 형식의 값을 반환한다.
        /// </summary>
        /// <returns>0보다 크거나 같고 1보다 작은 double 형식의 값.</returns>
        double NextDouble();

        double NextDouble(double maxInclusive);

        /// <summary>
        /// minInclusive보다 크거나 같고 maxInclusive보다 작거나 같은 double 형식의 값을 반환한다.
        /// </summary>
        /// <returns>minInclusive보다 크거나 같고 maxInclusive보다 작거나 같은 double 형식의 값.</returns>
        double NextDouble(double minInclusive, double maxInclusive);

        void NextBytes(byte[] bytes);
    }

    public abstract class RandomBase : IRandom
    {
        #region Implementation of IRandom
        public virtual int Next()
        {
            return Next(int.MaxValue);
        }

        public virtual int Next(int maxExclusive)
        {
            return Next(0, maxExclusive);
        }

        public virtual int Next(int minInclusive, int maxExclusive)
        {
            return minInclusive + (int)(NextDouble() * (double)(maxExclusive - minInclusive));
        }

        public virtual float NextSingle()
        {
            return (float)NextDouble();
        }

        public virtual float NextSingle(float maxInclusive)
        {
            return NextSingle(0.0f, maxInclusive);
        }

        public virtual float NextSingle(float minInclusive, float maxInclusive)
        {
            return (float)NextDouble(minInclusive, maxInclusive);
        }

        public abstract double NextDouble();

        public virtual double NextDouble(double maxInclusive)
        {
            return NextDouble(0.0f, maxInclusive);
        }

        public abstract double NextDouble(double minInclusive, double maxInclusive);

        public void NextBytes(byte[] bytes)
        {
            if (bytes == null)
            {
                throw new ArgumentNullException("bytes");
            }

            for (int i = 0; i < bytes.Length; i += 4)
            {
                int value = Next(int.MinValue, int.MaxValue);
                bytes[i + 0] = (byte)(value & 0x000000ff);
                bytes[i + 1] = (byte)(value & 0x0000ff00);
                bytes[i + 2] = (byte)(value & 0x00ff0000);
                bytes[i + 3] = (byte)(value & 0xff000000);
            }

            int remainStart = (bytes.Length / 4) * 4;
            if (remainStart >= bytes.Length)
            {
                return;
            }

            int remainCount = bytes.Length - remainStart;
            int remainValue = Next();
            for (int i = 0; i < remainCount; ++i)
            {
                bytes[remainStart + i] = (byte)(remainValue & 0xff << i * 8);
            }
        }
        #endregion
    }

    public static class IRandomExtensionMethods
    {
        /// <summary>
        /// 입력한 리스트로부터 랜덤한 값을 반환한다.
        /// </summary>
        /// <remarks>리스트는 한 개 이상의 값을 가지고 있어야 한다.</remarks>
        /// <typeparam name="T">리스트 요소의 타입.</typeparam>
        /// <param name="list">리스트 인스턴스.</param>
        /// <returns>리스트 내에서 임의로 선택된 값.</returns>
        public static T Choice<T>(this IRandom random, IList<T> list)
        {
            if (list == null)
            {
                throw new ArgumentNullException("list");
            }

            if (list.Count == 0)
            {
                throw new InvalidOperationException("시퀀스가 비어있습니다.");
            }

            return list[random.Next(list.Count)];
        }

        public static T Choice<T>(this IRandom random, Pie.Collections.IReadOnlyList<T> list)
        {
            if (list == null)
            {
                throw new ArgumentNullException("list");
            }

            if (list.Count == 0)
            {
                throw new InvalidOperationException("시퀀스가 비어있습니다.");
            }

            return list[random.Next(list.Count)];
        }

        public static void Shuffle<T>(this IRandom random, IList<T> list)
        {
            for (int i = list.Count - 1; i > 0; --i)
            {
                int grab = random.Next(i + 1);

                T temp = list[i];
                list[i] = list[grab];
                list[grab] = temp;
            }
        }
    }
}
