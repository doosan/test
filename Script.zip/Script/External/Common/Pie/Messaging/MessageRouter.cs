﻿using System;
using System.Collections.Generic;

namespace Pie.Messaging
{
    public interface IMessage
    {
    }

    public interface IMessageRouter
    {
        void RegisterListener(object listener);

        void UnregisterListener(object listener);

        void Subscribe<T>(object listener, Action<T> handler) where T : IMessage;

        void Unsubscribe<T>(object listener, Action<T> handler) where T : IMessage;

        void Unsubscribe<T>(object listener) where T : IMessage;

        void Route<T>(T message) where T : IMessage;

        void Clear();
    }

    public partial class MessageRouter : IMessageRouter
    {
        public void RegisterListener(object listener)
        {
            if (listener == null)
            {
                throw new ArgumentNullException("listener");
            }

            if (_subscriptions.ContainsKey(listener))
            {
                throw new InvalidOperationException("같은 리스너를 다시 등록할 수 없습니다.");
            }

            _subscriptions.Add(listener, new Subscription(this));
        }

        public void UnregisterListener(object listener)
        {
            Subscription subscription;
            if (!_subscriptions.TryGetValue(listener, out subscription))
            {
                return;
            }

            subscription.Unsubscribe();
            _subscriptions.Remove(listener);
        }

        public void Subscribe<T>(object listener, Action<T> handler) where T : IMessage
        {
            Subscription subscription;
            if (!_subscriptions.TryGetValue(listener, out subscription))
            {
                throw new KeyNotFoundException("등록된 리스너만 메세지를 구독할 수 있습니다.");
            }

            subscription.Subscribe<T>(handler);
        }

        public void Unsubscribe<T>(object listener, Action<T> handler) where T : IMessage
        {
            Subscription subscription;
            if (!_subscriptions.TryGetValue(listener, out subscription))
            {
                return;
            }

            subscription.Unsubscribe<T>(handler);
        }

        public void Unsubscribe<T>(object listener) where T : IMessage
        {
            Subscription subscription;
            if (!_subscriptions.TryGetValue(listener, out subscription))
            {
                return;
            }

            subscription.Unsubscribe<T>();
        }

        public void Route<T>(T message) where T : IMessage
        {
            Type messageType = typeof (T);

            LinkedList<Delegate> handlers;
            if (!_handlers.TryGetValue(messageType, out handlers))
            {
                return;
            }

            LinkedListNode<Delegate> node = handlers.First;
            while (node != null)
            {
                var handler = (Action<T>)node.Value;
                handler(message);

                node = node.Next;
            }
        }

        public void Clear()
        {
            _subscriptions.Clear();
            _handlers.Clear();
        }

        private readonly Dictionary<object, Subscription> _subscriptions = new Dictionary<object, Subscription>();
        private readonly Dictionary<Type, LinkedList<Delegate>> _handlers = new Dictionary<Type, LinkedList<Delegate>>();
    }
}
