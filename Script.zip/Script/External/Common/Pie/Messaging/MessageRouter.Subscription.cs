﻿using System;
using System.Collections.Generic;

namespace Pie.Messaging
{
    public partial class MessageRouter
    {
        public sealed class Subscription
        {
            internal Subscription(MessageRouter router)
            {
                if (router == null)
                {
                    throw new ArgumentNullException("router");
                }

                _router = router;
                _handlers = new Dictionary<Type, Dictionary<Delegate, LinkedListNode<Delegate>>>();
            }

            public void Subscribe<T>(Action<T> handler) where T : IMessage
            {
                if (handler == null)
                {
                    throw new ArgumentNullException("handler");
                }

                Type messageType = typeof (T);

                LinkedList<Delegate> routerHandlers;
                if (!_router._handlers.TryGetValue(messageType, out routerHandlers))
                {
                    routerHandlers = new LinkedList<Delegate>();
                    _router._handlers.Add(messageType, routerHandlers);
                }

                Dictionary<Delegate, LinkedListNode<Delegate>> handlers;
                if (!_handlers.TryGetValue(messageType, out handlers))
                {
                    handlers = new Dictionary<Delegate, LinkedListNode<Delegate>>();
                    _handlers.Add(messageType, handlers);
                }

                if (handlers.ContainsKey(handler))
                {
                    throw new InvalidOperationException("같은 메세지에 대해 동일한 핸들러를 추가할 수 없습니다.");
                }

                handlers.Add(handler, routerHandlers.AddLast(handler));
            }

            public void Unsubscribe<T>(Action<T> handler) where T : IMessage
            {
                Type messageType = typeof (T);

                Dictionary<Delegate, LinkedListNode<Delegate>> handlers;
                if (!_handlers.TryGetValue(messageType, out handlers))
                {
                    return;
                }

                LinkedListNode<Delegate> node;
                if (!handlers.TryGetValue(handler, out node))
                {
                    return;
                }

                _router._handlers[messageType].Remove(node);
                handlers.Remove(handler);
            }

            public void Unsubscribe<T>() where T : IMessage
            {
                Type messageType = typeof (T);

                Dictionary<Delegate, LinkedListNode<Delegate>> handlers;
                if (!_handlers.TryGetValue(messageType, out handlers))
                {
                    return;
                }

                LinkedList<Delegate> routerHandlers = _router._handlers[messageType];

                var enumerator = handlers.GetEnumerator();
                while (enumerator.MoveNext())
                {
                    routerHandlers.Remove(enumerator.Current.Value);
                }

                handlers.Clear();
            }

            public void Unsubscribe()
            {
                var enumerator1 = _handlers.GetEnumerator();
                while (enumerator1.MoveNext())
                {
                    Type messageType = enumerator1.Current.Key;
                    Dictionary<Delegate, LinkedListNode<Delegate>> handlers = enumerator1.Current.Value;
                    LinkedList<Delegate> routerHandlers = _router._handlers[messageType];

                    var enumerator2 = handlers.GetEnumerator();
                    while (enumerator2.MoveNext())
                    {
                        routerHandlers.Remove(enumerator2.Current.Value);
                    }
                }

                _handlers.Clear();
            }

            private readonly MessageRouter _router;
            private readonly Dictionary<Type, Dictionary<Delegate, LinkedListNode<Delegate>>> _handlers;
        }
    }
}
