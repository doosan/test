﻿using System;
using UnityEngine;

namespace Pie
{
    /// <summary>
    /// 싱글톤 클래스. 이 클래스를 상속하여 특정 타입의 싱글톤 클래스를 만든다.
    /// </summary>
    public abstract class MonoBehaviourSingleton<T> : MonoBehaviour
            where T : MonoBehaviourSingleton<T>
    {
        #region MonoBehaviour Messages
        protected virtual void Awake()
        {
            string typeName = typeof (T).Name;
            string storageName = IsGlobal ? "글로벌" : "로컬";

            if (_instance != null)
            {
#if !NO_UNITYDEBUG
                Debug.LogWarningFormat(this, "{0} 타입의 {1} 싱글톤 인스턴스가 이미 존재합니다.", typeName, storageName);
#endif
				return;
            }

            _instance = (T)this;

            if (IsGlobal)
            {
                DontDestroyOnLoad(gameObject);
            }

#if !NO_UNITYDEBUG
            Debug.LogFormat(this, "{0} 타입의 {1} 싱글톤 인스턴스가 생성되었습니다.", typeName, storageName);
#endif
        }

        private void OnApplicationQuit()
        {
            if (_instance == this)
            {
                _isQuitting = true;
            }
        }

        protected virtual void OnDestroy()
        {
            if (_instance == null || _instance != this)
            {
                return;
            }

            _instance = null;

            string typeName = typeof(T).Name;
            string storageName = IsGlobal ? "글로벌" : "로컬";

#if !NO_UNITYDEBUG
            Debug.LogFormat("{0} 타입의 {1} 싱글톤 인스턴스가 파괴되었습니다.", typeName, storageName);
#endif
        }
#endregion

        /// <summary>
        /// 싱글톤 인스턴스가 있다면 반환하고, 그렇지 않다면 새로운 싱글톤 인스턴스를 생성한다.
        /// </summary>
        /// <value>싱글톤 인스턴스.</value>
        public static T Instance
        {
            get
            {
                if (_instance != null)
                {
                    return _instance;
                }

                if (_isQuitting)
                {
                    return null;
                }

                //new GameObject(typeof(T).Name, typeof(T));
                return _instance;
            }
        }

        public static bool HasInstance
        {
            get { return _instance != null; }
        }

        public abstract bool IsGlobal
        {
            get;
        }

        private static T _instance;
        private static bool _isQuitting;
    }
}
