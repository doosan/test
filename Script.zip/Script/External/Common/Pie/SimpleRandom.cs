﻿using System;

namespace Pie
{
    /// <summary>
    /// Xorshift 알고리즘을 사용한 의사 난수 생성기.
    /// </summary>
    [Serializable]
    public class SimpleRandom : RandomBase
    {
        /// <summary>
        /// 시간에 따른 임의의 시드 값을 사용하여 새 인스턴스를 생성한다.
        /// </summary>
        public SimpleRandom()
            : this(Environment.TickCount)
        {
        }

        /// <summary>
        /// 지정한 시드 값을 사용하여 새 인스턴스를 생성한다.
        /// </summary>
        /// <param name="seed">난수 시작 값을 정하기 위한 숫자.</param>
        public SimpleRandom(int seed)
        {
            InitWithSeed(seed);
        }

        #region Overrides
        public override double NextDouble()
        {
            return (double)Sample() * UIntMaxExclusiveReversed;
        }

        public override double NextDouble(double minInclusive, double maxInclusive)
        {
            double value = (double)Sample() * UIntMaxInclusiveReversed;
            return minInclusive + ((maxInclusive - minInclusive) * value);
        }
        #endregion

        public int Seed
        {
            get { return (int)x; }
            set { InitWithSeed(value); }
        }

        private const double UIntMaxInclusiveReversed = 1.0 / (double)uint.MaxValue;
        private const double UIntMaxExclusiveReversed = 1.0 / ((double)uint.MaxValue + 1.0);

        private const uint Y = 362436069;
        private const uint Z = 521288629;
        private const uint W = 88675123;

        private void InitWithSeed(int seed)
        {
            x = (uint)((seed * 1431655781) +
                       (seed * 1183186591) +
                       (seed * 622729787) +
                       (seed * 338294347));
            y = Y;
            z = Z;
            w = W;
        }

        private uint Sample()
        {
            uint t = x ^ (x << 11);
            x = y;
            y = z;
            z = w;
            w = (w ^ (w >> 19)) ^ (t ^ (t >> 8));
            return w;
        }

        private uint x;
        private uint y;
        private uint z;
        private uint w;
    }
}
