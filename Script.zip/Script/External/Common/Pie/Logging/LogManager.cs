﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using UnityEngine;

namespace Pie.Logging
{
    using _ = Functional;

    public class LogManager : MonoBehaviourSingleton<LogManager>
    {
        public void Init(ILogger rootLogger = null, IEnumerable<KeyValuePair<string, ILogger>> loggers = null)
        {
            if (rootLogger != null)
            {
                _rootLogger = rootLogger;
            }

            if (loggers != null)
            {
                _loggers = _.ToDictionary(loggers, pair => pair.Key, pair => pair.Value);
            }
        }

        #region Override from MonoBehaviourSingleton<LogManager>
        protected override void OnDestroy()
        {
            var enumerator = _loggers.Values.GetEnumerator();
            while (enumerator.MoveNext())
            {
                enumerator.Current.Dispose();
            }

            _loggers.Clear();

            base.OnDestroy();
        }

        public override bool IsGlobal
        {
            get { return true; }
        }
        #endregion

        public ILogger GetLogger(string name)
        {
            if (name == null)
            {
                throw new ArgumentNullException("name");
            }

            ILogger logger;
            if (!_loggers.TryGetValue(name, out logger))
            {
                int delimiterIndex = name.LastIndexOf('.');
                while (delimiterIndex > -1)
                {
                    if (_loggers.TryGetValue(name.Substring(0, delimiterIndex), out logger))
                    {
                        return logger;
                    }

                    delimiterIndex = name.LastIndexOf('.', delimiterIndex - 1);
                }

                return _rootLogger;
            }

            return logger;
        }

        public ILogger GetLogger(Type type)
        {
            return GetLogger(type.FullName);
        }

        private ILogger _rootLogger = new Logger(LogLevel.Debug, new UnityConsoleAppender(new SimpleLayout(endOfLine: string.Empty)));
        private Dictionary<string, ILogger> _loggers = new Dictionary<string, ILogger>();
    }
}
