﻿using System;
using UnityEngine;

namespace Pie.Logging
{
    public class UnityConsoleAppender : IAppender
    {
        public UnityConsoleAppender(ILayout layout)
        {
            if (layout == null)
            {
                throw new ArgumentNullException("layout");
            }

            _layout = layout;
        }

        #region Implementation of IDisposable
        public void Dispose()
        {
        }
        #endregion

        #region Implementation of IAppender
        public void Append(LogEvent evt)
        {
            string msg = _layout.Format(evt);
            switch (evt.Level)
            {
            case LogLevel.Debug: Debug.Log(msg, evt.Context);        break;
            case LogLevel.Info:  Debug.Log(msg, evt.Context);        break;
            case LogLevel.Warn:  Debug.LogWarning(msg, evt.Context); break;
            case LogLevel.Error: Debug.LogError(msg, evt.Context);   break;
            case LogLevel.Fatal: Debug.LogError(msg, evt.Context);   break;
            }
        }
        #endregion

        private readonly ILayout _layout;
    }
}
