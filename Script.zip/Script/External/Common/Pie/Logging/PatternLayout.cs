﻿using System;
using System.Text;

namespace Pie.Logging
{
    public class PatternLayout : LayoutBase
    {
        public PatternLayout(string pattern, string header = "", string footer = "", string endOfLine = "\r\n")
                : base(header, footer, endOfLine)
        {
            if (pattern == null)
            {
                throw new ArgumentNullException("pattern");
            }

            if (pattern.Length == 0)
            {
                throw new ArgumentException("빈 문자열일 수 없습니다.", "pattern");
            }

            _format = ParsePattern(pattern);
        }

        #region Override from LayoutBase
        public override string Format(LogEvent evt)
        {
            return string.Format(
                    _format,
                    evt.Level,
                    evt.Tag,
                    evt.Message,
                    evt.TimeStamp,
                    evt.FrameCount,
                    evt.Time,
                    _endOfLine,
                    evt.Context != null ? evt.Context.name : string.Empty,
                    "%");
        }
        #endregion

        // %l   로그 레벨
        // %T   태그
        // %m   메세지
        // %d{} 날짜/시간{DateTime 포맷}
        // %f   게임 프레임
        // %t   게임 시간(ms)
        // %n   개행문자
        // %x   컨텍스트 이름
        // %%   % 문자
        //
        // % 다음에 숫자를 지정하여 필드의 폭과 정렬 방식을 지정할 수 있다.
        private static string ParsePattern(string pattern)
        {
            int errorPos = 0;
            string errorMsg = string.Empty;

            var formatBuilder = new StringBuilder();
            var numberBuilder = new StringBuilder();
            var dateFormatBuilder = new StringBuilder();

            Func<int, bool> addFormatItem = (idx) =>
            {
                var fmt = new StringBuilder();
                fmt.Append("{");
                fmt.Append(idx);

                if (numberBuilder.Length != 0)
                {
                    fmt.Append(",");
                    fmt.Append(numberBuilder);

                    numberBuilder.Length = 0;
                }

                if (dateFormatBuilder.Length != 0)
                {
                    string dateFormat = dateFormatBuilder.ToString();

                    try
                    {
                        DateTime.Now.ToString(dateFormat);
                    }
                    catch (FormatException)
                    {
                        errorMsg = "유효한 DateTime 형식 포맷이 아닙니다.";
                        return false;
                    }

                    fmt.Append(":");
                    fmt.Append(dateFormat);

                    dateFormatBuilder.Length = 0;
                }

                fmt.Append("}");

                formatBuilder.Append(fmt);
                return true;
            };

            const int modeNormal = 0;
            const int modeNextEscape = 1;
            const int modeNextNegative = 2;
            const int modeNumOrSymbol = 3;
            const int modeDateFormat = 4;

            int symbol = -1;
            int mode = modeNormal;

            for (int i = 0; i < pattern.Length; ++i)
            {
                int symbolIdx = -1;
                char c = pattern[i];

                Func<bool> hasDateFormat = () => c == 'd' && i < pattern.Length - 1 && pattern[i + 1] == '{';
                Action setDateFormatMode = () =>
                {
                    symbol = symbolIdx;
                    mode = modeDateFormat;
                    i += 1;
                    errorPos = i;
                };

                switch (mode)
                {
                case modeNormal:
                    if (c == '%')
                    {
                        mode = modeNextEscape;
                    }
                    else
                    {
                        formatBuilder.Append(c);
                    }
                    break;

                case modeNextEscape:
                    symbolIdx = Symbols.IndexOf(c);
                    if (symbolIdx != -1)
                    {
                        if (hasDateFormat())
                        {
                            setDateFormatMode();
                        }
                        else
                        {
                            addFormatItem(symbolIdx);
                            mode = modeNormal;
                        }
                    }
                    else if (char.IsDigit(c))
                    {
                        numberBuilder.Append(c);
                        mode = modeNumOrSymbol;
                    }
                    else if (c == '-')
                    {
                        numberBuilder.Append(c);
                        mode = modeNextNegative;
                    }
                    else
                    {
                        errorPos = i;
                        errorMsg = "% 기호 뒤에는 숫자 혹은 정해진 심볼 문자만 쓸 수 있습니다.";
                        goto Error;
                    }
                    break;

                case modeNextNegative:
                    if (char.IsDigit(c))
                    {
                        numberBuilder.Append(c);
                        mode = modeNumOrSymbol;
                    }
                    else
                    {
                        errorPos = i;
                        errorMsg = "- 기호 뒤에는 반드시 숫자가 필요합니다.";
                        goto Error;
                    }
                    break;

                case modeNumOrSymbol:
                    symbolIdx = Symbols.IndexOf(c);
                    if (symbolIdx != -1)
                    {
                        if (hasDateFormat())
                        {
                            setDateFormatMode();
                        }
                        else
                        {
                            addFormatItem(symbolIdx);
                            mode = modeNormal;
                        }
                    }
                    else if (char.IsDigit(c))
                    {
                        numberBuilder.Append(c);
                    }
                    else
                    {
                        errorPos = i;
                        errorMsg = "% 기호 뒤에는 숫자 혹은 정해진 심볼 문자만 쓸 수 있습니다.";
                        goto Error;
                    }
                    break;

                case modeDateFormat:
                    if (c != '}')
                    {
                        dateFormatBuilder.Append(c);
                    }
                    else
                    {
                        if (!addFormatItem(symbol))
                        {
                            goto Error;
                        }

                        symbol = -1;
                        mode = modeNormal;
                    }
                    break;
                }
            }

            if (mode != modeNormal)
            {
                errorMsg = "유효한 패턴 문자열이 아닙니다.";
                goto Error;
            }

            return formatBuilder.ToString();

        Error:
            throw new FormatException(string.Format("{0}(위치: {1})", errorMsg, errorPos));
        }

        private const string Symbols = "lTmdftnx%";

        private readonly string _format;
    }
}
