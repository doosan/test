﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Pie.Logging
{
    using Object = UnityEngine.Object;

    public class Logger : ILogger
    {
        public Logger(LogLevel level, IEnumerable<IAppender> appenders)
        {
            if (!Enum.IsDefined(typeof(LogLevel), level))
            {
                throw new ArgumentException("유효한 LogLevel 값이 아닙니다.", "level");
            }

            if (appenders == null)
            {
                throw new ArgumentNullException("appenders");
            }

            if (appenders.Any(appender => appender == null))
            {
                throw new ArgumentException("null 값을 가질 수 없습니다.", "appenders");
            }

            _level = level;
            _appenders = new List<IAppender>(appenders);
        }

        public Logger(LogLevel level, IAppender appender)
        {
            if (!Enum.IsDefined(typeof(LogLevel), level))
            {
                throw new ArgumentException("유효한 LogLevel 값이 아닙니다.", "level");
            }

            if (appender == null)
            {
                throw new ArgumentNullException("appender");
            }

            _level = level;
            _appenders = new List<IAppender> { appender };
        }

        #region Implementation of IDisposable
        public void Dispose()
        {
            for (int i = 0; i < _appenders.Count; ++i)
            {
                _appenders[i].Dispose();
            }

            _appenders.Clear();
        }
        #endregion

        #region Implementation of ILogger
        public void Debug(object message)
        {
            if (IsDebugEnabled)
            {
#if !NO_UNITYDEBUG
				Append(LogLevel.Debug, string.Empty, message, null);
#endif
            }
        }

        public void Info(object message)
        {
            if (IsInfoEnabled)
            {
#if !NO_UNITYDEBUG
                Append(LogLevel.Info, string.Empty, message, null);
#endif
            }
        }

        public void Warn(object message)
        {
            if (IsWarnEnabled)
            {
#if !NO_UNITYDEBUG
                Append(LogLevel.Warn, string.Empty, message, null);
#endif
            }
        }

        public void Error(object message)
        {
            if (IsErrorEnabled)
            {
#if !NO_UNITYDEBUG
                Append(LogLevel.Error, string.Empty, message, null);
#endif
            }
        }

        public void Fatal(object message)
        {
            if (IsFatalEnabled)
            {
#if !NO_UNITYDEBUG
                Append(LogLevel.Fatal, string.Empty, message, null);
#endif
            }
        }

        public void Debug(object message, string tag)
        {
            if (IsDebugEnabled)
            {
#if !NO_UNITYDEBUG
                Append(LogLevel.Debug, string.Empty, message, null);
#endif
            }
        }

        public void Info(object message, string tag)
        {
            if (IsInfoEnabled)
            {
#if !NO_UNITYDEBUG
                Append(LogLevel.Info, tag, message, null);
#endif
            }
        }

        public void Warn(object message, string tag)
        {
            if (IsWarnEnabled)
            {
#if !NO_UNITYDEBUG
                Append(LogLevel.Warn, tag, message, null);
#endif
            }
        }

        public void Error(object message, string tag)
        {
            if (IsErrorEnabled)
            {
#if !NO_UNITYDEBUG
                Append(LogLevel.Error, tag, message, null);
#endif
            }
        }

        public void Fatal(object message, string tag)
        {
            if (IsFatalEnabled)
            {
#if !NO_UNITYDEBUG
                Append(LogLevel.Fatal, tag, message, null);
#endif
            }
        }

        public void Debug(object message, Object context)
        {
            if (IsDebugEnabled)
            {
#if !NO_UNITYDEBUG
                Append(LogLevel.Debug, string.Empty, message, context);
#endif
            }
        }

        public void Info(object message, Object context)
        {
            if (IsInfoEnabled)
            {
#if !NO_UNITYDEBUG
                Append(LogLevel.Info, string.Empty, message, context);
#endif
            }
        }

        public void Warn(object message, Object context)
        {
            if (IsWarnEnabled)
            {
#if !NO_UNITYDEBUG
                Append(LogLevel.Warn, string.Empty, message, context);
#endif
            }
        }

        public void Error(object message, Object context)
        {
            if (IsErrorEnabled)
            {
#if !NO_UNITYDEBUG
                Append(LogLevel.Error, string.Empty, message, context);
#endif
            }
        }

        public void Fatal(object message, Object context)
        {
            if (IsFatalEnabled)
            {
#if !NO_UNITYDEBUG
				Append(LogLevel.Fatal, string.Empty, message, context);
#endif
            }
        }

        public void Debug(object message, string tag, Object context)
        {
            if (IsDebugEnabled)
            {
#if !NO_UNITYDEBUG
                Append(LogLevel.Debug, tag, message, context);
#endif
            }
        }

        public void Info(object message, string tag, Object context)
        {
            if (IsInfoEnabled)
            {
#if !NO_UNITYDEBUG
                Append(LogLevel.Info, tag, message, context);
#endif
            }
        }

        public void Warn(object message, string tag, Object context)
        {
            if (IsWarnEnabled)
            {
#if !NO_UNITYDEBUG
                Append(LogLevel.Warn, tag, message, context);
#endif
            }
        }

        public void Error(object message, string tag, Object context)
        {
            if (IsErrorEnabled)
            {
#if !NO_UNITYDEBUG
                Append(LogLevel.Error, tag, message, context);
#endif
            }
        }

        public void Fatal(object message, string tag, Object context)
        {
            if (IsFatalEnabled)
            {
#if !NO_UNITYDEBUG
                Append(LogLevel.Fatal, tag, message, context);
#endif
            }
        }
#endregion

        private bool IsDebugEnabled
        {
            get { return _level <= LogLevel.Debug; }
        }

        private bool IsInfoEnabled
        {
            get { return _level <= LogLevel.Info; }
        }

        private bool IsWarnEnabled
        {
            get { return _level <= LogLevel.Warn; }
        }

        private bool IsErrorEnabled
        {
            get { return _level <= LogLevel.Error; }
        }

        private bool IsFatalEnabled
        {
            get { return _level <= LogLevel.Fatal; }
        }

        private void Append(LogLevel level, string tag, object message, Object context)
        {
            if (message == null)
            {
                throw new ArgumentNullException("message");
            }

            DateTime timeStamp = DateTime.Now;
            ulong time = Convert.ToUInt64(Time.time * 1000.0f);

            LogEvent evt = new LogEvent(
                    level,
                    tag ?? string.Empty,
                    message,
                    timeStamp,
                    Time.frameCount,
                    time,
                    context);

            for (int i = 0; i < _appenders.Count; ++i)
            {
                try
                {
                   _appenders[i].Append(evt);
                }
                catch (Exception e)
                {
					UnityEngine.Debug.LogException(e, evt.Context);
                }
            }
        }

        private readonly LogLevel _level;
        private readonly List<IAppender> _appenders;
    }
}
