﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace Pie.Logging
{
    public class CsvLayout : ILayout
    {
        public enum QuoteMode
        {
            All,
            Auto,
            NonNumeric,
            None
        }

        public class InvalidTypeException : Exception
        {
            public InvalidTypeException()
            {
            }

            public InvalidTypeException(string message)
                    : base(message)
            {
            }

            public InvalidTypeException(string message, Exception inner)
                    : base(message, inner)
            {
            }
        }

        public CsvLayout(
                string messageTypeName,
                IEnumerable<string> fields,
                char delimiter = ',',
                char quote = '"',
                char escape = '"',
                QuoteMode quoteMode = QuoteMode.All,
                string header = "",
                string footer = "",
                string recordSeparator = "\r\n")
        {
            if (fields == null)
            {
                throw new ArgumentNullException("fields");
            }

            if (delimiter == '\u000A' || delimiter == '\u000D')
            {
                throw new ArgumentException("LF(U+000A)와 CR(U+000D)은 분리자로 사용할 수 없습니다.", "delimiter");
            }

            if (quote == '\u000A' || quote == '\u000D')
            {
                throw new ArgumentException("LF(U+000A)와 CR(U+000D)은 인용 부호로 사용할 수 없습니다.", "quote");
            }

            if (escape == '\u000A' || escape == '\u000D')
            {
                throw new ArgumentException("LF(U+000A)와 CR(U+000D)은 이스케이프 문자로 사용할 수 없습니다.", "escape");
            }

            if (!Enum.IsDefined(typeof (QuoteMode), quoteMode))
            {
                throw new ArgumentException("유효한 QuoteMode 값이 아닙니다.", "quoteMode");
            }

            Type messageType = Type.GetType(messageTypeName);
            if (messageType == null)
            {
                throw new ArgumentException("지정한 메세지 타입과 일치하는 타입을 찾을 수 없습니다.", messageTypeName);
            }

            if (!messageType.IsValueType)
            {
                throw new ArgumentException("값 타입만 메세지 타입으로 사용할 수 있습니다.", messageTypeName);
            }

            var logEvents = new List<string>
            {
                "Level",
                "Tag",
                "TimeStamp",
                "FrameCount",
                "Time",
                "FullClassName",
                "ClassName",
                "MethodName",
                "Context"
            };

            var numericTypes = new List<Type>
            {
                typeof (sbyte),
                typeof (short),
                typeof (int),
                typeof (long),
                typeof (byte),
                typeof (ushort),
                typeof (uint),
                typeof (ulong),
                typeof (float),
                typeof (double),
                typeof (decimal),
            };

            var fieldInfos = new List<InternalFieldInfo>();
            foreach (var field in fields)
            {
                if (string.IsNullOrEmpty(field))
                {
                    throw new ArgumentException("빈 필드는 허용되지 않습니다.", "fields");
                }

                FieldType fieldType = FieldType.Field;
                string fieldName = string.Empty;
                string format = string.Empty;
                FieldInfo fieldInfo = null;

                int formatStartIndex = field.IndexOf('{');
                if (formatStartIndex >= 0)
                {
                    int formatEndIndex = field.IndexOf('}');
                    if (formatEndIndex <= formatStartIndex)
                    {
                        throw new FormatException(field + "은 유효한 필드 형식이 아닙니다.");
                    }

                    format = string.Format(
                            "{{0:{0}}}",
                            field.Substring(formatStartIndex + 1, formatEndIndex - formatStartIndex - 1));
                }

                int startIndex = 0;
                if (field[0] == '%')
                {
                    if (field.Length < 1)
                    {
                        throw new ArgumentException(field + "은 유효한 필드 형식이 아닙니다.", "fields");
                    }

                    fieldType = FieldType.LogEvent;
                    startIndex = 1;
                }

                fieldName = formatStartIndex >= 0
                        ? field.Substring(startIndex, formatStartIndex - startIndex)
                        : field.Substring(startIndex);

                if (fieldName.Length == 0)
                {
                    throw new ArgumentException(field + "은 유효한 필드 형식이 아닙니다.", "fields");
                }

                Type type = null;

                if (fieldType == FieldType.LogEvent)
                {
                    if (!logEvents.Contains(fieldName))
                    {
                        throw new ArgumentException(fieldName + "은 지원되는 로그 이벤트 이름이 아닙니다.", "fields");
                    }

                    if (format.Length > 0)
                    {
                        if (fieldName == "TimeStamp")
                        {
                            type = typeof (DateTime);
                        }
                        else
                        {
                            throw new ArgumentException(fieldName + "은 포맷이 지원되는 로그 이벤트가 아닙니다.", "fields");
                        }
                    }
                }
                else
                {
                    BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
                    fieldInfo = messageType.GetField(fieldName, flags);
                    if (fieldInfo == null)
                    {
                        throw new ArgumentException(string.Format("{0}는 {1}에 대한 유효한 필드 이름이 아닙니다.", fieldName, messageTypeName), "fields");
                    }

                    if (format.Length > 0)
                    {
                        if (numericTypes.Contains(fieldInfo.FieldType))
                        {
                            type = fieldInfo.FieldType;
                        }
                        else
                        {
                            throw new ArgumentException(fieldName + "은 포맷이 지원되는 형식이 아닙니다.", "fields");
                        }
                    }
                }

                if (type != null)
                {
                    try
                    {
                        string.Format(format, Activator.CreateInstance(type));
                    }
                    catch (FormatException)
                    {
                        throw new FormatException(string.Format("{0}은 유효한 {1} 형식 포맷이 아닙니다.", format, type.Name));
                    }
                }

                fieldInfos.Add(new InternalFieldInfo(fieldType, fieldName, format, fieldInfo));
            }

            if (fieldInfos.Count == 0)
            {
                throw new ArgumentOutOfRangeException( "fields", "필드 값이 하나 이상 있어야 합니다.");
            }

            _messageType = messageType;
            _fields = fieldInfos.ToArray();

            _delimiter = delimiter.ToString();
            _quote = quote.ToString();
            _escapedQuote = escape.ToString() + quote;
            _quoteMode = quoteMode;

            _recordSeparator = recordSeparator ?? Environment.NewLine;

            Header = string.IsNullOrEmpty(header) ? string.Empty : header + recordSeparator;
            Footer = string.IsNullOrEmpty(footer) ? string.Empty : footer + recordSeparator;
        }

        #region Implementation of ILayout
        public string Format(LogEvent evt)
        {
            if (evt.Message.GetType() != _messageType)
            {
                throw new InvalidTypeException(string.Format("evt.Message의 타입이 지정한 타입({0})과 일치하지 않습니다.", _messageType.FullName));
            }

            var builder = new StringBuilder();

            for (int i = 0; i < _fields.Length; ++i)
            {
                int startIndex = builder.Length;

                FieldType fieldType = _fields[i].Type;
                string fieldName = _fields[i].Name;

                switch (fieldType)
                {
                case FieldType.Field:
                    builder.Append(_fields[i].Info.GetValue(evt.Message));
                    break;

                case FieldType.LogEvent:
                    switch (fieldName)
                    {
                    case "Level": builder.Append(evt.Level); break;
                    case "Tag": builder.Append(evt.Tag); break;
                    case "TimeStamp": builder.AppendFormat(_fields[i].Format, evt.TimeStamp); break;
                    case "FrameCount": builder.Append(evt.FrameCount); break;
                    case "Time": builder.Append(evt.Time); break;
                    case "Context": builder.Append(evt.Context.name); break;
                    }
                    break;
                }

                int length = builder.Length - startIndex;

                if (_quoteMode == QuoteMode.All ||
                    _quoteMode == QuoteMode.Auto && NeedQuote(builder, startIndex, length) ||
                    _quoteMode == QuoteMode.NonNumeric && !IsNumeric(builder, startIndex, length))
                {
                    builder.Replace(_quote, _escapedQuote, startIndex, length);
                    builder.Insert(startIndex, _quote);
                    builder.Append(_quote);
                }

                if (i != _fields.Length - 1)
                {
                    builder.Append(_delimiter);
                }
            }

            return builder.Append(_recordSeparator).ToString();
        }

        public string Header
        {
            get;
            private set;
        }

        public string Footer
        {
            get;
            private set;
        }
        #endregion

        private enum FieldType
        {
            LogEvent,
            Field
        }

        private struct InternalFieldInfo
        {
            public InternalFieldInfo(
                    FieldType type,
                    string name,
                    string format,
                    FieldInfo info)
            {
                Type = type;
                Name = name;
                Info = info;
                Format = format;
            }

            public readonly FieldType Type;
            public readonly string Name;
            public readonly FieldInfo Info;
            public readonly string Format;
        }

        private static bool IsNumeric(StringBuilder builder, int startIndex, int length)
        {
            if (builder == null)
            {
                throw new ArgumentNullException("builder");
            }

            if (length == 0)
            {
                return false;
            }

            int at = startIndex;
            int end = startIndex + length;

            if (builder[at] == '-')
            {
                at += 1;
            }

            // DecimalNumber
            if (at == end || !Utils.IsDigit(builder[at]))
            {
                return false;
            }

            if (builder[at] == '0')
            {
                at += 1;
            }
            else
            {
                while (at != end && Utils.IsDigit(builder[at]))
                {
                    at += 1;
                }
            }

            if (at == end)
            {
                return true;
            }

            // .Digits
            if (builder[at] == '.')
            {
                at += 1;
                if (at == end || !Utils.IsDigit(builder[at]))
                {
                    return false;
                }

                while (at != end && Utils.IsDigit(builder[at]))
                {
                    at += 1;
                }

                if (at == end)
                {
                    return true;
                }

                if (builder[at] != 'e' && builder[at] != 'E')
                {
                    return false;
                }
            }

            // ExponentPart
            if (builder[at] == 'e' || builder[at] == 'E')
            {
                at += 1;
                if (at == end)
                {
                    return false;
                }

                if (builder[at] == '+' || builder[at] == '-')
                {
                    at += 1;
                    if (at == end || !Utils.IsDigit(builder[at]))
                    {
                        return false;
                    }
                }

                while (at != end && Utils.IsDigit(builder[at]))
                {
                    at += 1;
                }
            }

            return at == end;
        }

        private bool NeedQuote(StringBuilder builder, int startPosition, int length)
        {
            int end = startPosition + length;
            for (int i = startPosition; i < end; ++i)
            {
                char c = builder[i];
                if (c == _delimiter[0] || c == _quote[0])
                {
                    return true;
                }
            }

            return false;
        }

        private readonly Type _messageType;
        private readonly InternalFieldInfo[] _fields;

        private readonly string _delimiter;
        private readonly string _quote;
        private readonly string _escapedQuote;
        private readonly QuoteMode _quoteMode;

        private readonly string _recordSeparator;
    }
}
