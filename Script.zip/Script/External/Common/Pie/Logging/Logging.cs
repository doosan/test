﻿using System;
using System.Diagnostics;
using System.Reflection;

namespace Pie.Logging
{
    using Object = UnityEngine.Object;

    public enum LogLevel
    {
        Debug,
        Info,
        Warn,
        Error,
        Fatal
    }

    public struct LogEvent
    {
        public LogEvent(
                LogLevel level,
                string tag,
                object message,
                DateTime timeStamp,
                int frameCount,
                ulong time,
                Object context)
        {
            Level = level;
            Tag = tag;
            Message = message;
            TimeStamp = timeStamp;
            FrameCount = frameCount;
            Time = time;
            Context = context;
        }

        public readonly LogLevel Level;
        public readonly string Tag;
        public readonly object Message;
        public readonly DateTime TimeStamp;
        public readonly int FrameCount;
        public readonly ulong Time;
        public readonly Object Context;
    }

    public interface ILayout
    {
        string Format(LogEvent evt);

        string Header { get; }

        string Footer { get; }
    }

    public interface IAppender : IDisposable
    {
        void Append(LogEvent evt);
    }

    public interface ILogger : IDisposable
    {
        void Debug(object message);

        void Info(object message);

        void Warn(object message);

        void Error(object message);

        void Fatal(object message);

        void Debug(object message, string tag);

        void Info(object message, string tag);

        void Warn(object message, string tag);

        void Error(object message, string tag);

        void Fatal(object message, string tag);

        void Debug(object message, Object context);

        void Info(object message, Object context);

        void Warn(object message, Object context);

        void Error(object message, Object context);

        void Fatal(object message, Object context);

        void Debug(object message, string tag, Object context);

        void Info(object message, string tag, Object context);

        void Warn(object message, string tag, Object context);

        void Error(object message, string tag, Object context);

        void Fatal(object message, string tag, Object context);
    }
}
