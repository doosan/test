﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.IO;

namespace Pie.Logging
{
    public class FileAppender : IAppender
    {
        public FileAppender(ILayout layout, string path, bool append)
        {
            if (layout == null)
            {
                throw new ArgumentNullException("layout");
            }

            if (path == null)
            {
                throw new ArgumentNullException("path");
            }

            string directory = Path.GetDirectoryName(path) ?? Directory.GetDirectoryRoot(path);

            if (!append)
            {
                if (File.Exists(path))
                {
                    File.Delete(path);
                }

                if (!Directory.Exists(directory))
                {
                    Directory.CreateDirectory(directory);
                }

                File.Create(path).Close();
            }

            _layout = layout;
            _directory = directory;
            _path = path;

            _writeThread = new Thread(WriteLoop);
            _waitLoop = new AutoResetEvent(false);
            _waitWrite = new AutoResetEvent(true);

            _writeThread.Start();

            string header = _layout.Header;
            if (!string.IsNullOrEmpty(header))
            {
                RequestWrite(header);
            }
        }

        ~FileAppender()
        {
            Dispose();
        }

        #region Implementation of IDisposable
        public void Dispose()
        {
            if (_disposed)
            {
                return;
            }

            string footer = _layout.Footer;
            if (!string.IsNullOrEmpty(footer))
            {
                RequestWrite(footer);
            }

            _waitWrite.WaitOne();

            _stopLoop = true;
            _waitLoop.Set();
            _writeThread.Join();

            _disposed = true;

            GC.SuppressFinalize(this);
        }
        #endregion

        #region Implementation of IAppender
        public void Append(LogEvent evt)
        {
            RequestWrite(_layout.Format(evt));
        }
        #endregion

        private void WriteLoop()
        {
            while (!_stopLoop)
            {
                _waitLoop.WaitOne();

                try
                {
                    if (!Directory.Exists(_directory))
                    {
                        Directory.CreateDirectory(_directory);
                    }

                    using (var writer = new StreamWriter(_path, true))
                    {
                        while (_messages.Count > 0)
                        {
                            writer.Write(_messages.Peek());
                            _messages.Dequeue();
                        }
                    }
                }
                catch (Exception e)
                {
					UnityEngine.Debug.LogException(e);
                }

                _waitWrite.Set();
            }
        }

        private void RequestWrite(string message)
        {
            _waitWrite.WaitOne();
            _messages.Enqueue(message);
            _waitLoop.Set();
        }

        private readonly ILayout _layout;
        private readonly string _directory;
        private readonly string _path;

        private readonly Queue<string> _messages = new Queue<string>();
        private readonly Thread _writeThread;
        private readonly AutoResetEvent _waitLoop;
        private readonly AutoResetEvent _waitWrite;

        private bool _stopLoop;
        private bool _disposed;
    }
}
