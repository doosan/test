﻿using System;

namespace Pie.Logging
{
    public abstract class LayoutBase : ILayout
    {
        protected LayoutBase(string header, string footer, string endOfLine)
        {
            _endOfLine = endOfLine ?? Environment.NewLine;

            Header = string.IsNullOrEmpty(header) ? string.Empty : header + endOfLine;
            Footer = string.IsNullOrEmpty(footer) ? string.Empty : footer + endOfLine;
        }

        public abstract string Format(LogEvent evt);

        public string Header
        {
            get;
            private set;
        }

        public string Footer
        {
            get;
            private set;
        }

        protected readonly string _endOfLine;
    }

    public class SimpleLayout : LayoutBase
    {
        public SimpleLayout(string header = "", string footer = "", string endOfLine = "\r\n")
                : base(header, footer, endOfLine)
        {
        }

        #region Override from LayoutBase
        public override string Format(LogEvent evt)
        {
            string msg = evt.Message + _endOfLine;
            return string.IsNullOrEmpty(evt.Tag) ? msg : evt.Tag + ": " + msg;
        }
        #endregion
    }
}
