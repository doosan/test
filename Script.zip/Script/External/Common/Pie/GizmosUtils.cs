using System.Collections.Generic;
using UnityEngine;
using Pie.ExtensionMethods.UnityEngine;

namespace Pie
{
    public static class GizmosUtils
    {
        public static void DrawLine(Vector3 from, Vector3 to, Color color)
        {
            Color c = Gizmos.color;
            Gizmos.color = color;
            Gizmos.DrawLine(from, to);
            Gizmos.color = c;
        }

        /// <summary>
        /// 지정한 위치에 지정한 노멀 방향으로 원을 그린다.
        /// </summary>
        /// <param name="position">원의 중심 위치.</param>
        /// <param name="normal">원의 노멀 방향.</param>
        /// <param name="radius">원의 반지름.</param>
        public static void DrawCircle(Vector3 position, Vector3 normal, float radius)
        {
            Matrix4x4 mat = Matrix4x4.TRS(position, Quaternion.LookRotation(normal), new Vector3(radius, radius, radius));

            if (_circlePoints == null)
            {
                BuildCirclePoints();
            }

            Vector3 first = mat.MultiplyPoint3x4(_circlePoints[0]);
            Vector3 from = first;
            Vector3 to = Vector3.zero;

            for (int i = 0; i < CirclePointCount - 1; ++i)
            {
                to = mat.MultiplyPoint3x4(_circlePoints[i + 1]);
                Gizmos.DrawLine(from, to);
                from = to;
            }
            Gizmos.DrawLine(to, first);
        }

        public static void DrawCircle(Vector3 position, Vector3 normal, float radius, Color color)
        {
            Color c = Gizmos.color;
            Gizmos.color = color;
            DrawCircle(position, normal, radius);
            Gizmos.color = c;
        }

        public static void DrawCircle2D(Vector3 position, float radius)
        {
            DrawCircle(position, Vector3.back, radius);
        }

        public static void DrawCircle2D(Vector3 position, float radius, Color color)
        {
            DrawCircle(position, Vector3.back, radius, color);
        }

        // TODO public static void DrawArc(Vector3 position, Vector3 normal, Vector3 from, float degree, float radius);

        public static void DrawArc2D(Vector3 position, Vector2 from, float angle, float radius)
        {
            const int anglePerPoint = 6;

            int pointCount = Mathf.CeilToInt(angle / anglePerPoint);
            float pointAngle = angle / pointCount;

            Vector2 direction = from.normalized * radius;
            Vector3 lastPoint = position + (Vector3)direction;

            for (int i = 0; i < pointCount; ++i)
            {
                float r = pointAngle * (i + 1) * Mathf.Deg2Rad;
                float c = Mathf.Cos(r);
                float s = Mathf.Sin(r);

                var r1 = new Vector2(c, -s);
                var r2 = new Vector2(s, c);

                float x = Vector2.Dot(r1, direction);
                float y = Vector2.Dot(r2, direction);

                Vector3 newLastPoint = position + new Vector3(x, y);
                Gizmos.DrawLine(lastPoint, newLastPoint);
                lastPoint = newLastPoint;
            }
        }

        public static void DrawArc2D(Vector3 position, Vector2 from, float angle, float radius, Color color)
        {
            Color c = Gizmos.color;
            Gizmos.color = color;
            DrawArc2D(position, from, angle, radius);
            Gizmos.color = c;
        }

        public static void DrawRect(Vector3 p1, Vector3 p2, Vector3 p3, Vector3 p4)
        {
            Gizmos.DrawLine(p1, p2);
            Gizmos.DrawLine(p2, p3);
            Gizmos.DrawLine(p3, p4);
            Gizmos.DrawLine(p4, p1);
        }

        public static void DrawRect(Vector3 p1, Vector3 p2, Vector3 p3, Vector3 p4, Color color)
        {
            Color c = Gizmos.color;
            Gizmos.color = color;
            DrawRect(p1, p2, p3, p4);
            Gizmos.color = c;
        }

        public static void DrawArrow(float size, Vector3 position, Quaternion rotation)
        {
            float halfSize = size * 0.5f * 0.16f;
            float halfHeight = size * 1.5f * 0.08f;

            var mesh = new Mesh();

            mesh.vertices = new[] {

                new Vector3(-halfSize, halfSize, -halfHeight),
                new Vector3(halfSize, halfSize, -halfHeight),
                new Vector3(-halfSize, -halfSize, -halfHeight),
                new Vector3(halfSize, -halfSize, -halfHeight),

                new Vector3(0.0f, 0.0f, halfHeight),
                new Vector3(-halfSize, halfSize, -halfHeight),
                new Vector3(halfSize, halfSize, -halfHeight),

                new Vector3(0.0f, 0.0f, halfHeight),
                new Vector3(halfSize, halfSize, -halfHeight),
                new Vector3(halfSize, -halfSize, -halfHeight),

                new Vector3(0.0f, 0.0f, halfHeight),
                new Vector3(halfSize, -halfSize, -halfHeight),
                new Vector3(-halfSize, -halfSize, -halfHeight),

                new Vector3(0.0f, 0.0f, halfHeight),
                new Vector3(-halfSize, -halfSize, -halfHeight),
                new Vector3(-halfSize, halfSize, -halfHeight)
            };

            mesh.triangles = new[] {

                0, 1, 2,
                2, 1, 3,
                4, 6, 5,
                7, 9, 8,
                10, 12, 11,
                13, 15, 14
            };

            mesh.RecalculateBounds();
            mesh.RecalculateNormals();

            Gizmos.DrawMesh(mesh, position, rotation);
        }

        public static void DrawArrow(float size, Vector3 position, Quaternion rotation, Color color)
        {
            Color c = Gizmos.color;
            Gizmos.color = color;
            DrawArrow(size, position, rotation);
            Gizmos.color = c;
        }

        public static void DrawLines(IEnumerable<Vector3> points)
        {
            IEnumerator<Vector3> enumerator = points.GetEnumerator();

            Vector3 prev;

            if (!enumerator.MoveNext())
            {
                return;
            }

            prev = enumerator.Current;

            while (enumerator.MoveNext())
            {
                Vector3 curr = enumerator.Current;
                Gizmos.DrawLine(prev, curr);
                prev = curr;
            }
        }

        public static void DrawLines(IEnumerable<Vector3> points, Color color)
        {
            Color c = Gizmos.color;
            Gizmos.color = color;
            DrawLines(points);
            Gizmos.color = c;
        }

        public static float GetHandleSize(Vector3 position)
        {
            Camera current = Camera.current;
            position = Gizmos.matrix.MultiplyPoint(position);
            if (current != null)
            {
                Transform transform = current.transform;
                Vector3 position2 = transform.position;
                float z = Vector3.Dot(position - position2, transform.TransformDirection(new Vector3(0.0f, 0.0f, 1.0f)));
                Vector3 a = current.WorldToScreenPoint(position2 + transform.TransformDirection(new Vector3(0.0f, 0.0f, z)));
                Vector3 b = current.WorldToScreenPoint(position2 + transform.TransformDirection(new Vector3(1.0f, 0.0f, z)));
                float magnitude = (a - b).magnitude;
                return 80.0f / Mathf.Max(magnitude, 0.0001f);
            }
            return 20.0f;
        }

        // 원을 그리는데 사용할 정적 포인트 배열을 생성한다.
        private static void BuildCirclePoints()
        {
            float radPerSeg = 360.0f / (float)CirclePointCount * Mathf.Deg2Rad;

            _circlePoints = new Vector3[CirclePointCount];
            for (int i = 0; i < CirclePointCount; ++i)
            {
                _circlePoints[i] = new Vector3(
                    Mathf.Sin((float)i * radPerSeg),
                    Mathf.Cos((float)i * radPerSeg));
            }
        }

        /// <summary>
        /// DrawCircle 메서드에서 원을 그리는데 사용할 포인트 수.
        /// </summary>
        private const int CirclePointCount = 60;

        private static Vector3[] _circlePoints;
    }
}
