﻿using System.IO;
using System.Text.RegularExpressions;

namespace Pie
{
    public static partial class Utils
    {
        public static string CombinePath(string path1, string path2)
        {
            return Path.Combine(path1, path2).Replace('\\', '/');
        }

        public static string CombinePath(string path1, string path2, string path3)
        {
            return Path.Combine(Path.Combine(path1, path2), path3).Replace('\\', '/');
        }

        public static string CombinePath(string path1, string path2, string path3, string path4)
        {
            return Path.Combine(Path.Combine(Path.Combine(path1, path2), path3), path4).Replace('\\', '/');
        }

        public static string CombinePath(params string[] paths)
        {
            if (paths.Length == 0)
            {
                return string.Empty;
            }

            string path = paths[0];
            for (int i = 0; i < paths.Length; ++i)
            {
                string nextPath = paths[i];
                path = Path.Combine(path, nextPath);
            }

            return path.Replace('\\', '/');
        }

        public static bool IsValidPath(string path)
        {
            if (InvalidPathChars.IsMatch(path))
            {
                return false;
            }
            return true;
        }

        private static readonly Regex InvalidPathChars = new Regex("[" + Regex.Escape(new string(Path.GetInvalidPathChars())) + "]");
    }
}
