using System;

namespace Pie.Processing
{
    /// <summary>
    /// 프로세스 매니저에서 실행할 수 있는 프로세스의 기본 구현 클래스.
    /// </summary>
    /// <remarks>프로세스 매니저에서 실행할 프로세스는 이 클래스를 상속받아 OnUpdate를 구현한다.</remarks>
    public abstract class Process : IProcess
    {
        #region Implementation of IProcess
        void IProcess.Start()
        {
            if (IsRunning)
            {
                throw new InvalidOperationException("실행 중에 호출할 수 없습니다.");
            }

            IsRunning = true;
            IsFinished = false;

            _isStarted = false;

            OnStart();
        }

        void IProcess.Update(float deltaTime)
        {
            if (!IsRunning)
            {
                throw new InvalidOperationException("실행 중이 아닐 때 호출할 수 없습니다.");
            }

            if (!_isStarted)
            {
                _isStarted = true;
                deltaTime = 0.0f;

                if (OnUpdateStart())
                {
                    if (!IsRunning)
                    {
                        return;
                    }

                    IsFinished = true;

                    OnFinished();
                    return;
                }
            }

            if (OnUpdate(deltaTime))
            {
                if (!IsRunning)
                {
                    return;
                }

                IsFinished = true;

                OnFinished();
            }
        }

        public void Stop()
        {
            if (!IsRunning)
            {
                return;
            }

            IsRunning = false;
            IsFinished = false;

            OnStopped();
        }

        public bool IsRunning
        {
            get;
            private set;
        }

        public bool IsFinished
        {
            get;
            private set;
        }
        #endregion

        /// <summary>
        /// Start 메서드 호출 시 상속받은 클래스에 호출된다.
        /// </summary>
        /// <remarks>
        /// 프로세스는 기본적으로 재실행 가능해야하며, OnStart에서는 각종 초기화 작업을 수행해야 한다.
        /// </remarks>
        protected virtual void OnStart()
        {
        }

        /// <summary>
        /// 첫번째 OnUpdate 호출 시 OnUpdate가 호출되기 전에 호출된다. 여기서 Stop이 호출되면 OnUpdate가 호출되지 않고
        /// 종료된다.
        /// </summary>
        /// <returns>프로세스가 종료되었다면 <c>true</c>, 계속 실행되어야 한다면 <c>false</c>.</returns>
        protected virtual bool OnUpdateStart()
        {
            return false;
        }

        /// <summary>
        /// 프로세스의 Update 메서드 호출 시 상속받은 클래스에 호출된다.
        /// </summary>
        /// <param name="deltaTime">지난 프레임으로부터 경과한 시간.</param>
        /// <returns>프로세스가 종료되었다면 <c>true</c>, 계속 실행되어야 한다면 <c>false</c>.</returns>
        protected virtual bool OnUpdate(float deltaTime)
        {
            return true;
        }

        /// <summary>
        /// 중간에 Stop 메서드가 호출되지 않고 끝까지 실행되었을 때 마지막 OnUpdate 메서드를 호출하고 종료되기 전에
        /// 상속한 클래스에 호출된다. 여기서 Stop을 호출해도 정상적으로 종료된 것으로 처리한다.
        /// </summary>
        protected virtual void OnFinished()
        {
        }

        /// <summary>
        /// Stop 메서드 호출 시 상속받은 클래스에 호출된다.
        /// </summary>
        /// <remarks>
        /// 이 메서드는 프로세스가 정상적으로 종료되었는지 여부와 관계 없이 Stop 메서드를 호출하면 호출되기 때문에
        /// 이 메서드가 호출되는 것을 항상 프로세스의 정상적인 종료라고 간주해서는 안 된다.
        /// </remarks>
        protected virtual void OnStopped()
        {
        }

        private bool _isStarted;
    }
}
