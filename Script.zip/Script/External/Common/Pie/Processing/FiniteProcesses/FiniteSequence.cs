using System;
using System.Collections.Generic;

namespace Pie.Processing
{
    public class FiniteSequence : IFiniteProcess
    {
        public FiniteSequence(params IFiniteProcess[] processes)
                : this(processes as IEnumerable<IFiniteProcess>)
        {
        }

        public FiniteSequence(IEnumerable<IFiniteProcess> processes)
        {
            if (processes == null)
            {
                throw new ArgumentNullException("processes");
            }

            _processes = new List<IFiniteProcess>(processes);

            float duration = 0.0f;
            for (int i = 0; i < _processes.Count; ++i)
            {
                if (_processes[i] == null)
                {
                    throw new ArgumentException("null 값을 가질 수 없습니다.", "processes");
                }

                if (_processes[i].IsRunning)
                {
                    throw new ArgumentException("실행 중인 프로세스를 추가할 수 없습니다.", "processes");
                }

                duration += _processes[i].Duration;
            }

            if (duration < 0.0f)
            {
                throw new ArgumentException("Duration의 합이 0보다 작습니다.", "processes");
            }

            Duration = duration;
        }

        #region Implementation of IProcess
        void IProcess.Start()
        {
            (this as IFiniteProcess).Start(false);
        }

        void IProcess.Update(float deltaTime)
        {
            if (!IsRunning)
            {
                throw new InvalidOperationException("실행 중이 아닐 때 호출할 수 없습니다.");
            }

            IFiniteProcess currentProcess = _processes[_currentProcessIndex];
            while (true)
            {
                float nextElapsed = currentProcess.Elapsed + deltaTime;

                currentProcess.Update(deltaTime);

                if (!IsRunning)
                {
                    return;
                }

                if (!currentProcess.IsRunning)
                {
                    IsRunning = false;
                    return;
                }

                if (!currentProcess.IsFinished)
                {
                    Elapsed = _finishedProcessesElapsed + currentProcess.Elapsed;
                    Normalized = Elapsed / Duration;

                    break;
                }

                _currentProcessIndex += 1;
                _finishedProcessesElapsed += currentProcess.Duration;

                Elapsed = _finishedProcessesElapsed;
                Normalized = (float)_currentProcessIndex / _processes.Count;

                if (_currentProcessIndex >= _processes.Count)
                {
                    // NOTE songkyoo 2015-12-20: Stop 호출 시 마지막 프로세스의 Stop을 호출하도록 하기 위해서
                    //                           _currentProcessIndex를 설정한다.
                    _currentProcessIndex = _processes.Count - 1;
                    IsFinished = true;

                    return;
                }

                currentProcess.Stop();
                currentProcess = _processes[_currentProcessIndex];
                currentProcess.Start(true);

                deltaTime = nextElapsed - currentProcess.Duration;
            }
        }

        public void Stop()
        {
            if (!IsRunning)
            {
                return;
            }

            IsRunning = false;
            IsFinished = false;

            if (_currentProcessIndex < _processes.Count && _processes[_currentProcessIndex].IsRunning)
            {
                _processes[_currentProcessIndex].Stop();
            }
        }

        public bool IsRunning
        {
            get;
            private set;
        }

        public bool IsFinished
        {
            get;
            private set;
        }
        #endregion

        #region Implementation of IFiniteProcess
        void IFiniteProcess.Start(bool repeatStart)
        {
            if (IsRunning)
            {
                throw new InvalidOperationException("실행 중에 호출할 수 없습니다.");
            }

            IsRunning = true;
            IsFinished = false;
            Elapsed = 0.0f;
            Normalized = 0.0f;

            _currentProcessIndex = 0;
            _finishedProcessesElapsed = 0.0f;

            if (_processes.Count <= 0)
            {
                IsFinished = true;
                return;
            }

            _processes[0].Start(repeatStart);
        }

        public float Duration
        {
            get;
            private set;
        }

        public float Elapsed
        {
            get;
            private set;
        }

        public float Normalized
        {
            get;
            private set;
        }
        #endregion

        private List<IFiniteProcess> _processes;
        private int _currentProcessIndex;
        private float _finishedProcessesElapsed;
    }
}
