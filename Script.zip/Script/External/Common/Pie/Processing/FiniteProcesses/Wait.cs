using System;

namespace Pie.Processing
{
    /// <summary>
    /// 일정 시간동안 대기하는 프로세스.
    /// </summary>
    public class Wait : FiniteProcess
    {
        public Wait(float waitTime, Action onFinished = null, Action onStopped = null)
                : base(waitTime)
        {
            _onFinished = onFinished;
            _onStopped = onStopped;
        }

        protected override void OnFinished()
        {
            if (_onFinished != null)
            {
                _onFinished();
            }
        }

        protected override void OnStopped()
        {
            if (_onStopped != null)
            {
                _onStopped();
            }
        }

        private Action _onFinished;
        private Action _onStopped;
    }
}
