using System;

namespace Pie.Processing
{
    public class CallFunction : InstantProcess
    {
        public CallFunction(Action fn)
        {
            if (fn == null)
            {
                throw new ArgumentNullException("fn");
            }

            _fn = fn;
        }

        protected override void OnUpdate()
        {
            _fn();
        }

        private Action _fn;
    }
}
