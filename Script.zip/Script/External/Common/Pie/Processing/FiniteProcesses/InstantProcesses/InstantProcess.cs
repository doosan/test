﻿namespace Pie.Processing
{
    public class InstantProcess : FiniteProcess
    {
        protected InstantProcess()
                : base(0.0f)
        {
        }

        protected override sealed void OnUpdate(float deltaTime)
        {
            OnUpdate();
        }

        protected virtual void OnUpdate()
        {
        }
    }
}
