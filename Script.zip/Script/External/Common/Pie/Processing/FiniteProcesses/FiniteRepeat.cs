using System;

namespace Pie.Processing
{
    public class FiniteRepeat : IFiniteProcess
    {
        public FiniteRepeat(int repeatCount, IFiniteProcess process)
        {
            if (repeatCount < 1)
            {
                throw new ArgumentOutOfRangeException("repeatCount", "1보다 작을 수 없습니다.");
            }

            if (process == null)
            {
                throw new ArgumentNullException("process");
            }

            _process = process;

            Duration = repeatCount * process.Duration;
            RepeatCount = repeatCount;
        }

        #region Implementation of IProcess
        void IProcess.Start()
        {
            (this as IFiniteProcess).Start(false);
        }

        void IProcess.Update(float deltaTime)
        {
            if (!IsRunning)
            {
                throw new InvalidOperationException("실행 중이 아닐 때 호출할 수 없습니다.");
            }

            while (true)
            {
                float nextElapsed = _process.Elapsed + deltaTime;

                _process.Update(deltaTime);

                if (!IsRunning)
                {
                    return;
                }

                if (!_process.IsRunning)
                {
                    IsRunning = false;
                    return;
                }

                if (!_process.IsFinished)
                {
                    Elapsed = (_currentRepeatCount * _process.Duration) + _process.Elapsed;
                    Normalized = Elapsed / Duration;

                    break;
                }

                _currentRepeatCount += 1;

                Elapsed = _currentRepeatCount * _process.Duration;
                Normalized = (float)_currentRepeatCount / RepeatCount;

                if (_currentRepeatCount >= RepeatCount)
                {
                    IsFinished = true;
                    return;
                }

                _process.Stop();
                _process.Start(true);

                deltaTime = nextElapsed - _process.Duration;
            }
        }

        public void Stop()
        {
            if (!IsRunning)
            {
                return;
            }

            IsRunning = false;
            IsFinished = false;

            if (_process.IsRunning)
            {
               _process.Stop();
            }
        }

        public bool IsRunning
        {
            get;
            private set;
        }

        public bool IsFinished
        {
            get;
            private set;
        }
        #endregion

        #region Implementation of IFiniteProcess
        void IFiniteProcess.Start(bool repeatStart)
        {
            if (IsRunning)
            {
                throw new InvalidOperationException("실행 중에 호출할 수 없습니다.");
            }

            IsRunning = true;
            IsFinished = false;

            _currentRepeatCount = 0;

            _process.Start(repeatStart);
        }

        public float Elapsed
        {
            get;
            private set;
        }

        public float Duration
        {
            get;
            private set;
        }

        public float Normalized
        {
            get;
            private set;
        }
        #endregion

        public int RepeatCount
        {
            get;
            private set;
        }

        private IFiniteProcess _process;
        private int _currentRepeatCount;
    }
}
