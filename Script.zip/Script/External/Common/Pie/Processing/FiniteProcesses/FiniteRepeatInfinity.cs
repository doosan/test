using System;

namespace Pie.Processing
{
    public class FiniteRepeatInfinity : IFiniteProcess
    {
        public FiniteRepeatInfinity(IFiniteProcess process)
        {
            if (process == null)
            {
                throw new ArgumentNullException("process");
            }

            _process = process;
        }

        #region Implementation of IProcess
        void IProcess.Start()
        {
            (this as IFiniteProcess).Start(false);
        }

        void IProcess.Update(float deltaTime)
        {
            if (!IsRunning)
            {
                throw new InvalidOperationException("실행 중이 아닐 때 호출할 수 없습니다.");
            }

            while (true)
            {
                float nextElapsed = _process.Elapsed + deltaTime;

                _process.Update(deltaTime);

                if (!IsRunning)
                {
                    return;
                }

                if (!_process.IsRunning)
                {
                    IsRunning = false;
                    return;
                }

                if (!_process.IsFinished)
                {
                    Elapsed = (_currentRepeatCount * _process.Duration) + _process.Elapsed;
                    break;
                }

                _currentRepeatCount += 1;

                Elapsed = _currentRepeatCount * _process.Duration;

                _process.Stop();
                _process.Start(true);

                deltaTime = nextElapsed - _process.Duration;
            }
        }

        public void Stop()
        {
            if (!IsRunning)
            {
                return;
            }

            IsRunning = false;

            if (_process.IsRunning)
            {
               _process.Stop();
            }
        }

        public bool IsRunning
        {
            get;
            private set;
        }

        public bool IsFinished
        {
            get { return false; }
        }
        #endregion

        #region Implementation of IFiniteProcess
        void IFiniteProcess.Start(bool repeatStart)
        {
            if (IsRunning)
            {
                throw new InvalidOperationException("실행 중에 호출할 수 없습니다.");
            }

            IsRunning = true;

            _currentRepeatCount = 0;

            _process.Start(repeatStart);
        }

        public float Elapsed
        {
            get;
            private set;
        }

        public float Duration
        {
            get { return float.PositiveInfinity; }
        }

        public float Normalized
        {
            get { return 0.0f; }
        }
        #endregion

        private IFiniteProcess _process;
        private int _currentRepeatCount;
    }
}
