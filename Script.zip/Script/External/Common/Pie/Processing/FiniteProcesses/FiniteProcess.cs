using System;
using UnityEngine;

namespace Pie.Processing
{
    /// <summary>
    /// 정해진 시간동안 실행되는 프로세스가 사용하는 기본 구현 클래스.
    /// </summary>
    /// <remarks>
    /// 기본적으로 Process와 비슷하지만 OnUpdate에 반환 값이 없고, OnUpdate의 마지막 호출에는
    /// 프로세스 전체 Duration의 초과값을 제외한 deltaTime이 전달된다.
    /// </remarks>
    public abstract class FiniteProcess : IFiniteProcess
    {
        /// <summary>
        /// 프로세스의 실행되는 시간을 인자로 받는 생성자.
        /// </summary>
        /// <param name="duration">
        /// 프로세스가 실행되는 시간. 0보다 크거나 같아야 한다.
        /// </param>
        public FiniteProcess(float duration)
        {
            if (duration < 0.0f)
            {
                throw new ArgumentOutOfRangeException("duration", "0보다 작을 수 없습니다.");
            }

            Duration = duration;
        }

        #region Implementation of IProcess
        void IProcess.Start()
        {
            (this as IFiniteProcess).Start(false);
        }

        void IProcess.Update(float deltaTime)
        {
            if (!IsRunning)
            {
                throw new InvalidOperationException("실행 중이 아닐 때 호출할 수 없습니다.");
            }

            if (!_isStarted)
            {
                _isStarted = true;

                if (!_isRepeatStart)
                {
                    deltaTime = 0.0f;
                }

                if (OnUpdateStart())
                {
                    if (!IsRunning)
                    {
                        return;
                    }

                    IsFinished = true;

                    OnFinished();
                    return;
                }
            }

            // deltaTime을 더해서 전체 프로세스 시간을 넘긴다면 종료 과정을 처리.
            float nextElapsed = Elapsed + deltaTime;
            if (nextElapsed >= Duration)
            {
                deltaTime = Duration - Elapsed;

                Elapsed = Duration;
                Normalized = 1.0f;

                OnUpdate(deltaTime);

                if (!IsRunning)
                {
                    return;
                }

                // 마지막 업데이트에 Stop이 호출되지 않았을 경우만 IsFinished를 true로 설정한다.
                IsFinished = true;

                OnFinished();
                return;
            }

            // Duration이 0이라면 여기에 도달하지 않기 때문에 Duration으로 나눠도 문제없다.
            Elapsed = nextElapsed;
            Normalized = Elapsed / Duration;

            OnUpdate(deltaTime);
        }

        public void Stop()
        {
            if (!IsRunning)
            {
                return;
            }

            IsRunning = false;
            IsFinished = false;

            OnStopped();
        }

        public bool IsRunning
        {
            get;
            private set;
        }

        public bool IsFinished
        {
            get;
            private set;
        }
        #endregion

        #region Implementation of IFiniteProcess
        void IFiniteProcess.Start(bool repeatStart)
        {
            if (IsRunning)
            {
                throw new InvalidOperationException("실행 중에 호출할 수 없습니다.");
            }

            IsRunning = true;
            IsFinished = false;
            Elapsed = 0.0f;
            Normalized = 0.0f;

            _isStarted = false;
            _isRepeatStart = repeatStart;

            OnStart();
        }

        public float Elapsed
        {
            get;
            private set;
        }

        public float Duration
        {
            get;
            private set;
        }

        public float Normalized
        {
            get;
            private set;
        }
        #endregion

        /// <summary>
        /// Start 메서드 호출 시 상속받은 클래스에 호출된다.
        /// </summary>
        /// <remarks>
        /// 프로세스는 기본적으로 재실행 가능해야하며, OnStart에서는 각종 초기화 작업을 수행해야 한다.
        /// </remarks>
        protected virtual void OnStart()
        {
        }

        /// <summary>
        /// 첫번째 OnUpdate 호출 시 OnUpdate가 호출되기 전에 호출된다. 여기서 Stop이 호출되면 OnUpdate가 호출되지 않고
        /// 종료된다.
        /// </summary>
        /// <returns>프로세스가 종료되었다면 <c>true</c>, 계속 실행되어야 한다면 <c>false</c>.</returns>
        protected virtual bool OnUpdateStart()
        {
            return false;
        }

        /// <summary>
        /// 프로세스의 Update 메서드 호출 시 상속받은 클래스에 호출된다. 이 메서드가 호출되는 시점에서 프로세스의 시간
        /// 값은 갱신된 상태다.
        /// </summary>
        /// <param name="deltaTime">지난 프레임으로부터 경과한 시간.</param>
        protected virtual void OnUpdate(float deltaTime)
        {
        }

        /// <summary>
        /// 중간에 Stop 메서드가 호출되지 않고 끝까지 실행되었을 때 마지막 OnUpdate 메서드를 호출하고 종료되기 전에
        /// 상속한 클래스에 호출된다. 여기서 Stop을 호출해도 정상적으로 종료된 것으로 처리한다.
        /// </summary>
        protected virtual void OnFinished()
        {
        }

        /// <summary>
        /// Stop 메서드 호출 시 상속받은 클래스에 호출된다.
        /// </summary>
        /// <remarks>
        /// 이 메서드는 프로세스가 정상적으로 종료되었는지 여부와 관계 없이 Stop 메서드를 호출하면 호출되기 때문에
        /// 이 메서드가 호출되는 것을 항상 프로세스의 정상적인 종료라고 간주해서는 안 된다.
        /// </remarks>
        protected virtual void OnStopped()
        {
        }

        private bool _isStarted;
        private bool _isRepeatStart;
    }
}
