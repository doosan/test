namespace Pie.Processing
{
    public interface IFiniteProcess : IProcess
    {
        void Start(bool repeatStart);

        /// <summary>
        /// 프로세스가 실행되는 시간.
        /// </summary>
        /// <value>프로세스가 실행되는 시간.</value>
        float Duration
        {
            get;
        }

        /// <summary>
        /// 프로세스가 실행된 시간.
        /// </summary>
        /// <value>프로세스가 실행된 시간. Duration을 초과하지 않는다.</value>
        float Elapsed
        {
            get;
        }

        /// <summary>
        /// 프로세스가 종료되는 시간을 1로 봤을 때 현재 프로세스가 실행된 시간.
        /// </summary>
        /// <value>프로세스 시작 시 0, 완료 시 1이 되며, 1을 초과하지 않는다.</value>
        float Normalized
        {
            get;
        }
    }
}
