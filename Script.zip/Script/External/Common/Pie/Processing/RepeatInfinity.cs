﻿using System;

namespace Pie.Processing
{
    public class RepeatInfinity : IProcess
    {
        public RepeatInfinity(IProcess process)
        {
            if (process == null)
            {
                throw new ArgumentNullException("process");
            }

            _process = process;
        }

        #region Implementation of IProcess
        void IProcess.Start()
        {
            if (IsRunning)
            {
                throw new InvalidOperationException("실행 중에 호출할 수 없습니다.");
            }

            IsRunning = true;

            _process.Start();
        }

        void IProcess.Update(float deltaTime)
        {
            if (!IsRunning)
            {
                throw new InvalidOperationException("실행 중이 아닐 때 호출할 수 없습니다.");
            }

            while (true)
            {
                _process.Update(deltaTime);

                if (!IsRunning)
                {
                    return;
                }

                if (!_process.IsRunning)
                {
                    IsRunning = false;
                    return;
                }

                if (!_process.IsFinished)
                {
                    break;
                }

                _process.Stop();
                _process.Start();
            }
        }

        public void Stop()
        {
            if (!IsRunning)
            {
                return;
            }

            IsRunning = false;

            if (_process.IsRunning)
            {
               _process.Stop();
            }
        }

        public bool IsRunning
        {
            get;
            private set;
        }

        public bool IsFinished
        {
            get { return false; }
        }
        #endregion

        private IProcess _process;
    }
}
