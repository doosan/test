using System;

namespace Pie.Processing
{
    public abstract class IntervalProcess : IIntervalProcess
    {
        #region Implementation of IProcess
        void IProcess.Start()
        {
            if (IsRunning)
            {
                throw new InvalidOperationException("실행 중에 호출할 수 없습니다.");
            }

            IsRunning = true;
            IsFinished = false;

            OnStart();
        }

        void IProcess.Update(float deltaTime)
        {
            if (!IsRunning)
            {
                throw new InvalidOperationException("실행 중이 아닐 때 호출할 수 없습니다.");
            }

            // NOTE songkyoo 2015-12-20: 기본적으로 Interval 계열 프로세스는 Update에서는 아무 것도 하지 않는다. 따라서
            //                           정상 종료는 Finish의 호출로 이루어지며, Finish 호출 시의 상태는 전적으로
            //                           프로세스나 프로세스를 관리하는 다른 개체의 책임이다.
        }

        public void Stop()
        {
            if (!IsRunning)
            {
                return;
            }

            IsRunning = false;
            IsFinished = false;

            OnStopped();
        }

        public bool IsRunning
        {
            get;
            private set;
        }

        public bool IsFinished
        {
            get;
            private set;
        }
        #endregion

        #region Implementation of IIntervalProcess
        public void Finish()
        {
            IsFinished = true;
        }

        public float Normalized
        {
            get { return _normalized; }
            set
            {
                _normalized = value;
                OnUpdate(value);
            }
        }
        #endregion

        /// <summary>
        /// Start 메서드 호출 시 상속받은 클래스에 호출된다.
        /// </summary>
        /// <remarks>
        /// 프로세스는 기본적으로 재실행 가능해야하며, OnStart에서는 각종 초기화 작업을 수행해야 한다.
        /// </remarks>
        protected virtual void OnStart()
        {
        }

        /// <summary>
        /// 프로세스의 Normalized에 값을 설정할 때 상속받은 클래스에 호출된다.
        /// </summary>
        /// <param name="normalized">프로세스의 현재 상태 값. 이 값에 맞춰 프로세스를 갱신한다.</param>
        protected virtual void OnUpdate(float normalized)
        {
        }

        protected virtual void OnFinished()
        {
        }

        /// <summary>
        /// Stop 메서드 호출 시 상속받은 클래스에 호출된다.
        /// </summary>
        /// <remarks>
        /// 이 메서드는 프로세스가 정상적으로 종료되었는지 여부와 관계 없이 Stop 메서드를 호출하면 호출되기 때문에
        /// 이 메서드가 호출되는 것을 항상 프로세스의 정상적인 종료라고 간주해서는 안 된다.
        /// </remarks>
        protected virtual void OnStopped()
        {
        }

        private float _normalized;
    }
}
