namespace Pie.Processing
{
    /// <summary>
    /// 인터벌 프로세스 인터페이스.
    /// </summary>
    /// <remarks>
    /// 인터벌 프로세스는 자체적으로는 업데이트 하지 않으며, Normalized 값을 설정하는 것을 통해 프로세스의 상태를
    /// 결정한다. 따라서 기본적으로 인터벌 프로세스 자체만으로는 프로세스 매니저에 등록해서 사용하는 경우는 거의 없으며,
    /// Normalized 값을 관리해주는 Easing 같은 프로세스에 포함되어 실행된다. 외부나 인터벌 프로세스를 관리하는
    /// 프로세스에 의해 Finish 메서드를 호출하는 것으로 인터벌 프로세스를 정상 종료한다.
    /// </remarks>
    public interface IIntervalProcess : IProcess
    {
        /// <summary>
        /// 프로세스를 정상 종료한다.
        /// </summary>
        void Finish();

        /// <summary>
        /// 프로세스의 현재 상태를 나타낸다.
        /// </summary>
        /// <remarks>
        /// 0이면 초기상태, 1이면 종료상태이며 0과 1사이의 값으로 제한하는 것은 프로세스의 필요에 따라서 처리해야 한다.
        /// </remarks>
        /// <value>프로세스의 현재 상태.</value>
        float Normalized
        {
            get;
            set;
        }
    }
}
