using System;

namespace Pie.Processing
{
    /// <summary>
    /// 프로세스의 속도를 변경하는 프로세스.
    /// </summary>
    public class TimeScale : IProcess
    {
        /// <summary>
        /// 속도를 변경할 프로세스를 인자로 받는 생성자.
        /// </summary>
        /// <param name="process">
        /// 속도를 변경할 프로세스. 이 프로세스의 업데이트는 <see cref="TimeScale"/> 클래스가 수행한다. <c>null</c> 값일 수
        /// 없다.
        /// </param>
        public TimeScale(IProcess process)
        {
            if (process == null)
            {
                throw new ArgumentNullException("process");
            }

            _process = process;

            Scale = 1.0f;
        }

        #region Implementation of IProcess
        void IProcess.Start()
        {
            _process.Start();
        }

        void IProcess.Update(float deltaTime)
        {
            _process.Update(deltaTime * _scale);
        }

        public void Stop()
        {
            _process.Stop();
        }

        public bool IsRunning
        {
            get { return _process.IsRunning; }
        }

        public bool IsFinished
        {
            get { return _process.IsFinished; }
        }
        #endregion

        /// <summary>
        /// 업데이트 시 전달할 deltaTime에 대한 스케일 값.
        /// </summary>
        /// <value>스케일 값. 0보다 크거나 같아야한다.</value>
        public float Scale
        {
            get { return _scale; }
            set
            {
                if (value < 0.0f)
                {
                    throw new ArgumentOutOfRangeException("Scale", "0보다 작을 수 없습니다.");
                }

                _scale = value;
            }
        }

        private IProcess _process;
        private float _scale;
    }
}
