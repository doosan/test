﻿using System;

namespace Pie.Processing
{
    public class Repeat : IProcess
    {
        public Repeat(int repeatCount, IProcess process)
        {
            if (repeatCount < 1)
            {
                throw new ArgumentOutOfRangeException("repeatCount", "1보다 작을 수 없습니다.");
            }

            if (process == null)
            {
                throw new ArgumentNullException("process");
            }

            _process = process;

            RepeatCount = repeatCount;
        }

        #region Implementation of IProcess
        void IProcess.Start()
        {
            if (IsRunning)
            {
                throw new InvalidOperationException("실행 중에 호출할 수 없습니다.");
            }

            IsRunning = true;
            IsFinished = false;

            _currentRepeatCount = 0;

            _process.Start();
        }

        void IProcess.Update(float deltaTime)
        {
            if (!IsRunning)
            {
                throw new InvalidOperationException("실행 중이 아닐 때 호출할 수 없습니다.");
            }

            while (true)
            {
                _process.Update(deltaTime);

                if (!IsRunning)
                {
                    return;
                }

                if (!_process.IsRunning)
                {
                    IsRunning = false;
                    return;
                }

                if (!_process.IsFinished)
                {
                    break;
                }

                _currentRepeatCount += 1;

                if (_currentRepeatCount >= RepeatCount)
                {
                    IsFinished = true;
                    return;
                }

                _process.Stop();
                _process.Start();
            }
        }

        public void Stop()
        {
            if (!IsRunning)
            {
                return;
            }

            IsRunning = false;
            IsFinished = false;

            if (_process.IsRunning)
            {
               _process.Stop();
            }
        }

        public bool IsRunning
        {
            get;
            private set;
        }

        public bool IsFinished
        {
            get;
            private set;
        }
        #endregion

        public int RepeatCount
        {
            get;
            private set;
        }

        private IProcess _process;
        private int _currentRepeatCount;
    }
}
