﻿using UnityEngine;

namespace Pie.ExtensionMethods.UnityEngine
{
    public static class AnimationCurveExtensionMethods
    {
        public static float GetTime(this AnimationCurve curve)
        {
            return (curve.length == 0) ? 0.0f : curve[curve.length - 1].time;
        }
    }
}
