﻿using UnityEngine;

namespace Pie.ExtensionMethods.UnityEngine
{
    public static class CanvasGroupExtensionMethods
    {
        public static void SetAlpha(this CanvasGroup group, float value)
        {
            group.alpha = value;
        }
    }
}
