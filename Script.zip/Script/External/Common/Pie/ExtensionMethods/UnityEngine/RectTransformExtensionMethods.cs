﻿using UnityEngine;

namespace Pie.ExtensionMethods.UnityEngine
{
    public static class RectTransformExtensionMethods
    {
        public static void SetSizeDelta(this RectTransform rectTransform, RectTransform other)
        {
            rectTransform.sizeDelta = other.sizeDelta;
        }

        public static void SetSizeDelta(this RectTransform rectTransform, Vector2 sizeDelta)
        {
            rectTransform.sizeDelta = sizeDelta;
        }

        public static void SetSizeDelta(this RectTransform rectTransform, float sizeDelta)
        {
            rectTransform.sizeDelta = new Vector2(sizeDelta, sizeDelta);
        }

        public static void SetSizeDelta(this RectTransform rectTransform, float x, float y)
        {
            rectTransform.sizeDelta = new Vector2(x, y);
        }

        public static void SetSizeDeltaX(this RectTransform rectTransform, float x)
        {
            Vector2 sizeDelta = rectTransform.sizeDelta;
            sizeDelta.x = x;
            rectTransform.sizeDelta = sizeDelta;
        }

        public static void AddSizeDeltaX(this RectTransform rectTransform, float x)
        {
            Vector2 sizeDelta = rectTransform.sizeDelta;
            sizeDelta.x += x;
            rectTransform.sizeDelta = sizeDelta;
        }

        public static void SetSizeDeltaY(this RectTransform rectTransform, float y)
        {
            Vector2 sizeDelta = rectTransform.sizeDelta;
            sizeDelta.y = y;
            rectTransform.sizeDelta = sizeDelta;
        }

        public static void AddSizeDeltaY(this RectTransform rectTransform, float y)
        {
            Vector2 sizeDelta = rectTransform.sizeDelta;
            sizeDelta.y += y;
            rectTransform.sizeDelta = sizeDelta;
        }

        public static void SetAnchoredPosition(this RectTransform rectTransform, RectTransform other)
        {
            rectTransform.anchoredPosition = other.anchoredPosition;
        }

        public static void SetAnchoredPosition(this RectTransform rectTransform, Vector2 anchoredPosition)
        {
            rectTransform.anchoredPosition = anchoredPosition;
        }

        public static void SetAnchoredPosition(this RectTransform rectTransform, float x, float y)
        {
            rectTransform.anchoredPosition = new Vector2(x, y);
        }

        public static void SetAnchoredPositionX(this RectTransform rectTransform, float x)
        {
            Vector2 anchoredPosition = rectTransform.anchoredPosition;
            anchoredPosition.x = x;
            rectTransform.anchoredPosition = anchoredPosition;
        }

        public static void AddAnchoredPositionX(this RectTransform rectTransform, float x)
        {
            Vector2 anchoredPosition = rectTransform.anchoredPosition;
            anchoredPosition.x += x;
            rectTransform.anchoredPosition = anchoredPosition;
        }

        public static void SetAnchoredPositionY(this RectTransform rectTransform, float y)
        {
            Vector2 anchoredPosition = rectTransform.anchoredPosition;
            anchoredPosition.y = y;
            rectTransform.anchoredPosition = anchoredPosition;
        }

        public static void AddAnchoredPositionY(this RectTransform rectTransform, float y)
        {
            Vector2 anchoredPosition = rectTransform.anchoredPosition;
            anchoredPosition.y += y;
            rectTransform.anchoredPosition = anchoredPosition;
        }

        public static void SetOffsetMinX(this RectTransform rectTransform, float x)
        {
            Vector2 offsetMin = rectTransform.offsetMin;
            offsetMin.x = x;
            rectTransform.offsetMin = offsetMin;
        }

        public static void AddOffsetMinX(this RectTransform rectTransform, float x)
        {
            Vector2 offsetMin = rectTransform.offsetMin;
            offsetMin.x += x;
            rectTransform.offsetMin = offsetMin;
        }

        public static void SetOffsetMinY(this RectTransform rectTransform, float y)
        {
            Vector2 offsetMin = rectTransform.offsetMin;
            offsetMin.y = y;
            rectTransform.offsetMin = offsetMin;
        }

        public static void AddOffsetMinY(this RectTransform rectTransform, float y)
        {
            Vector2 offsetMin = rectTransform.offsetMin;
            offsetMin.y += y;
            rectTransform.offsetMin = offsetMin;
        }

        public static void SetOffsetMaxX(this RectTransform rectTransform, float x)
        {
            Vector2 offsetMax = rectTransform.offsetMax;
            offsetMax.x = x;
            rectTransform.offsetMax = offsetMax;
        }

        public static void AddOffsetMaxX(this RectTransform rectTransform, float x)
        {
            Vector2 offsetMax = rectTransform.offsetMax;
            offsetMax.x += x;
            rectTransform.offsetMax = offsetMax;
        }

        public static void SetOffsetMaxY(this RectTransform rectTransform, float y)
        {
            Vector2 offsetMax = rectTransform.offsetMax;
            offsetMax.y = y;
            rectTransform.offsetMax = offsetMax;
        }

        public static void AddOffsetMaxY(this RectTransform rectTransform, float y)
        {
            Vector2 offsetMax = rectTransform.offsetMax;
            offsetMax.y += y;
            rectTransform.offsetMax = offsetMax;
        }
    }
}
