﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace Pie.ExtensionMethods.UnityEngine
{
    public static class TransformExtensionMethods
    {
        #region Position
        public static void SetPosition(this Transform transform, Transform other)
        {
            transform.position = other.position;
        }

        public static void SetPosition(this Transform transform, Vector3 position)
        {
            transform.position = position;
        }

        public static void SetPosition(this Transform transform, float x, float y, float z)
        {
            transform.position = new Vector3(x, y, z);
        }

        public static void SetPositionXY(this Transform transform, Vector2 xy)
        {
            Vector3 pos = transform.position;
            pos.x = xy.x;
            pos.y = xy.y;
            transform.position = pos;
        }

        public static void SetPositionXY(this Transform transform, float x, float y)
        {
            Vector3 pos = transform.position;
            pos.x = x;
            pos.y = y;
            transform.position = pos;
        }

        public static void SetPositionXZ(this Transform transform, Vector2 xz)
        {
            Vector3 pos = transform.position;
            pos.x = xz.x;
            pos.z = xz.y;
            transform.position = pos;
        }

        public static void SetPositionXZ(this Transform transform, float x, float z)
        {
            Vector3 pos = transform.position;
            pos.x = x;
            pos.z = z;
            transform.position = pos;
        }

        public static void SetPositionYZ(this Transform transform, Vector2 yz)
        {
            Vector3 pos = transform.position;
            pos.y = yz.x;
            pos.z = yz.y;
            transform.position = pos;
        }

        public static void SetPositionYZ(this Transform transform, float y, float z)
        {
            Vector3 pos = transform.position;
            pos.y = y;
            pos.z = z;
            transform.position = pos;
        }

        public static void SetPositionX(this Transform transform, float x)
        {
            Vector3 pos = transform.position;
            pos.x = x;
            transform.position = pos;
        }

        public static void SetPositionY(this Transform transform, float y)
        {
            Vector3 pos = transform.position;
            pos.y = y;
            transform.position = pos;
        }

        public static void SetPositionZ(this Transform transform, float z)
        {
            Vector3 pos = transform.position;
            pos.z = z;
            transform.position = pos;
        }
        #endregion

        #region LocalPosition
        public static void SetLocalPosition(this Transform transform, Transform other)
        {
            transform.localPosition = other.localPosition;
        }

        public static void SetLocalPosition(this Transform transform, Vector3 position)
        {
            transform.localPosition = position;
        }

        public static void SetLocalPosition(this Transform transform, float x, float y, float z)
        {
            transform.localPosition = new Vector3(x, y, z);
        }

        public static void SetLocalPositionXY(this Transform transform, Vector2 xy)
        {
            Vector3 pos = transform.localPosition;
            pos.x = xy.x;
            pos.y = xy.y;
            transform.localPosition = pos;
        }

        public static void SetLocalPositionXY(this Transform transform, float x, float y)
        {
            Vector3 pos = transform.localPosition;
            pos.x = x;
            pos.y = y;
            transform.localPosition = pos;
        }

        public static void SetLocalPositionXZ(this Transform transform, Vector2 xz)
        {
            Vector3 pos = transform.localPosition;
            pos.x = xz.x;
            pos.z = xz.y;
            transform.localPosition = pos;
        }

        public static void SetLocalPositionXZ(this Transform transform, float x, float z)
        {
            Vector3 pos = transform.localPosition;
            pos.x = x;
            pos.z = z;
            transform.localPosition = pos;
        }

        public static void SetLocalPositionYZ(this Transform transform, Vector2 yz)
        {
            Vector3 pos = transform.localPosition;
            pos.y = yz.x;
            pos.z = yz.y;
            transform.localPosition = pos;
        }

        public static void SetLocalPositionYZ(this Transform transform, float y, float z)
        {
            Vector3 pos = transform.localPosition;
            pos.y = y;
            pos.z = z;
            transform.localPosition = pos;
        }

        public static void SetLocalPositionX(this Transform transform, float x)
        {
            Vector3 pos = transform.localPosition;
            pos.x = x;
            transform.localPosition = pos;
        }

        public static void SetLocalPositionY(this Transform transform, float y)
        {
            Vector3 pos = transform.localPosition;
            pos.y = y;
            transform.localPosition = pos;
        }

        public static void SetLocalPositionZ(this Transform transform, float z)
        {
            Vector3 pos = transform.localPosition;
            pos.z = z;
            transform.localPosition = pos;
        }
        #endregion

        #region EulerAngles
        public static void SetEulerAngles(this Transform transform, Transform other)
        {
            transform.eulerAngles = other.eulerAngles;
        }

        public static void SetEulerAngles(this Transform transform, Vector3 eulerAngles)
        {
            transform.eulerAngles = eulerAngles;
        }

        public static void SetEulerAngles(this Transform transform, float x, float y, float z)
        {
            transform.eulerAngles = new Vector3(x, y, z);
        }

        public static void SetEulerAnglesXY(this Transform transform, Vector2 xy)
        {
            Vector3 rot = transform.eulerAngles;
            rot.x = xy.x;
            rot.y = xy.y;
            transform.eulerAngles = rot;
        }

        public static void SetEulerAnglesXY(this Transform transform, float x, float y)
        {
            Vector3 rot = transform.eulerAngles;
            rot.x = x;
            rot.y = y;
            transform.eulerAngles = rot;
        }

        public static void SetEulerAnglesYZ(this Transform transform, Vector2 yz)
        {
            Vector3 rot = transform.eulerAngles;
            rot.y = yz.x;
            rot.z = yz.y;
            transform.eulerAngles = rot;
        }

        public static void SetEulerAnglesYZ(this Transform transform, float y, float z)
        {
            Vector3 rot = transform.eulerAngles;
            rot.y = y;
            rot.z = z;
            transform.eulerAngles = rot;
        }

        public static void SetEulerAnglesXZ(this Transform transform, Vector2 xz)
        {
            Vector3 rot = transform.eulerAngles;
            rot.x = xz.x;
            rot.z = xz.y;
            transform.eulerAngles = rot;
        }

        public static void SetEulerAnglesXZ(this Transform transform, float x, float z)
        {
            Vector3 rot = transform.eulerAngles;
            rot.x = x;
            rot.z = z;
            transform.eulerAngles = rot;
        }

        public static void SetEulerAnglesX(this Transform transform, float x)
        {
            Vector3 rot = transform.eulerAngles;
            rot.x = x;
            transform.eulerAngles = rot;
        }

        public static void SetEulerAnglesY(this Transform transform, float y)
        {
            Vector3 rot = transform.eulerAngles;
            rot.y = y;
            transform.eulerAngles = rot;
        }

        public static void SetEulerAnglesZ(this Transform transform, float z)
        {
            Vector3 rot = transform.eulerAngles;
            rot.z = z;
            transform.eulerAngles = rot;
        }
        #endregion

        #region LocalEulerAngles
        public static void SetLocalEulerAngles(this Transform transform, Transform other)
        {
            transform.localEulerAngles = other.localEulerAngles;
        }

        public static void SetLocalEulerAngles(this Transform transform, Vector3 eulerAngles)
        {
            transform.localEulerAngles = eulerAngles;
        }

        public static void SetLocalEulerAngles(this Transform transform, float x, float y, float z)
        {
            transform.localEulerAngles = new Vector3(x, y, z);
        }

        public static void SetLocalEulerAnglesXY(this Transform transform, Vector2 xy)
        {
            Vector3 rot = transform.localEulerAngles;
            rot.x = xy.x;
            rot.y = xy.y;
            transform.localEulerAngles = rot;
        }

        public static void SetLocalEulerAnglesXY(this Transform transform, float x, float y)
        {
            Vector3 rot = transform.localEulerAngles;
            rot.x = x;
            rot.y = y;
            transform.localEulerAngles = rot;
        }

        public static void SetLocalEulerAnglesYZ(this Transform transform, Vector2 yz)
        {
            Vector3 rot = transform.localEulerAngles;
            rot.y = yz.x;
            rot.z = yz.y;
            transform.localEulerAngles = rot;
        }

        public static void SetLocalEulerAnglesYZ(this Transform transform, float y, float z)
        {
            Vector3 rot = transform.localEulerAngles;
            rot.y = y;
            rot.z = z;
            transform.localEulerAngles = rot;
        }

        public static void SetLocalEulerAnglesXZ(this Transform transform, Vector2 xz)
        {
            Vector3 rpt = transform.localEulerAngles;
            rpt.x = xz.x;
            rpt.z = xz.y;
            transform.localEulerAngles = rpt;
        }

        public static void SetLocalEulerAnglesXZ(this Transform transform, float x, float z)
        {
            Vector3 rot = transform.localEulerAngles;
            rot.x = x;
            rot.z = z;
            transform.localEulerAngles = rot;
        }

        public static void SetLocalEulerAnglesX(this Transform transform, float x)
        {
            Vector3 rot = transform.localEulerAngles;
            rot.x = x;
            transform.localEulerAngles = rot;
        }

        public static void SetLocalEulerAnglesY(this Transform transform, float y)
        {
            Vector3 rot = transform.localEulerAngles;
            rot.y = y;
            transform.localEulerAngles = rot;
        }

        public static void SetLocalEulerAnglesZ(this Transform transform, float z)
        {
            Vector3 rot = transform.localEulerAngles;
            rot.z = z;
            transform.localEulerAngles = rot;
        }
        #endregion

        #region Rotation
        public static void SetRotation(this Transform transform, Transform other)
        {
            transform.rotation = other.rotation;
        }

        public static void SetRotation(this Transform transform, Quaternion rotation)
        {
            transform.rotation = rotation;
        }

        public static void SetRotation(this Transform transform, float x, float y, float z, float w)
        {
            transform.rotation = new Quaternion(x, y, z, w);
        }
        #endregion

        #region LocalRotation
        public static void SetLocalRotation(this Transform transform, Transform other)
        {
            transform.localRotation = other.localRotation;
        }

        public static void SetLocalRotation(this Transform transform, Quaternion rotation)
        {
            transform.localRotation = rotation;
        }

        public static void SetLocalRotation(this Transform transform, float x, float y, float z, float w)
        {
            transform.localRotation = new Quaternion(x, y, z, w);
        }
        #endregion

        #region LocalScale
        public static void SetLocalScale(this Transform transform, Transform other)
        {
            transform.localScale = other.localScale;
        }

        public static void SetLocalScale(this Transform transform, Vector3 scale)
        {
            transform.localScale = scale;
        }

        public static void SetLocalScale(this Transform transform, float x, float y, float z)
        {
            transform.localScale = new Vector3(x, y, z);
        }

        public static void SetLocalScale(this Transform transform, float scale)
        {
            transform.localScale = new Vector3(scale, scale, scale);
        }

        public static void SetLocalScaleXY(this Transform transform, Vector2 xy)
        {
            Vector3 scl = transform.localScale;
            scl.x = xy.x;
            scl.y = xy.y;
            transform.localScale = scl;
        }

        public static void SetLocalScaleXY(this Transform transform, float scale)
        {
            Vector3 scl = transform.localScale;
            scl.x = scale;
            scl.y = scale;
            transform.localScale = scl;
        }

        public static void SetLocalScaleXY(this Transform transform, float x, float y)
        {
            Vector3 scl = transform.localScale;
            scl.x = x;
            scl.y = y;
            transform.localScale = scl;
        }

        public static void SetLocalScaleXZ(this Transform transform, Vector2 xz)
        {
            Vector3 scl = transform.localScale;
            scl.x = xz.x;
            scl.z = xz.y;
            transform.localScale = scl;
        }

        public static void SetLocalScaleXZ(this Transform transform, float scale)
        {
            Vector3 scl = transform.localScale;
            scl.x = scale;
            scl.z = scale;
            transform.localScale = scl;
        }

        public static void SetLocalScaleXZ(this Transform transform, float x, float z)
        {
            Vector3 scl = transform.localScale;
            scl.x = x;
            scl.z = z;
            transform.localScale = scl;
        }

        public static void SetLocalScaleYZ(this Transform transform, Vector2 yz)
        {
            Vector3 scl = transform.localScale;
            scl.y = yz.x;
            scl.z = yz.y;
            transform.localScale = scl;
        }

        public static void SetLocalScaleYZ(this Transform transform, float scale)
        {
            Vector3 scl = transform.localScale;
            scl.y = scale;
            scl.z = scale;
            transform.localScale = scl;
        }

        public static void SetLocalScaleYZ(this Transform transform, float y, float z)
        {
            Vector3 scl = transform.localScale;
            scl.y = y;
            scl.z = z;
            transform.localScale = scl;
        }

        public static void SetLocalScaleX(this Transform transform, float x)
        {
            Vector3 scl = transform.localScale;
            scl.x = x;
            transform.localScale = scl;
        }

        public static void SetLocalScaleY(this Transform transform, float y)
        {
            Vector3 scl = transform.localScale;
            scl.y = y;
            transform.localScale = scl;
        }

        public static void SetLocalScaleZ(this Transform transform, float z)
        {
            Vector3 scl = transform.localScale;
            scl.z = z;
            transform.localScale = scl;
        }
        #endregion

        // TODO songkyoo 2015-11-25: 재귀적으로 내려가도록 수정.

        public static Transform FindChild(this Transform parent, Func<Transform, bool> predicate)
        {
            int childCount = parent.childCount;
            for (int i = 0; i < childCount; i += 1)
            {
                Transform child = parent.GetChild(i);
                if (predicate(child))
                {
                    return child;
                }
            }
            return null;
        }

        public static Transform[] FindChilds(this Transform parent, Func<Transform, bool> predicate)
        {
            var childs = new List<Transform>();

            int childCount = parent.childCount;
            for (int i = 0; i < childCount; i += 1)
            {
                Transform child = parent.GetChild(i);
                if (predicate(child))
                {
                    childs.Add(child);
                }
            }
            return childs.ToArray();
        }

        public static T FindChildComponent<T>(this Transform parent, string path) where T : Component
        {
            Transform child = parent.Find(path);
            if (child == null)
            {
                return null;
            }
            return child.GetComponent<T>();
        }

        public static T FindChildComponent<T>(this Transform parent, Func<Transform, bool> predicate) where T : Component
        {
            Transform child = parent.FindChild(predicate);
            if (child == null)
            {
                return null;
            }
            return child.GetComponent<T>();
        }
    }
}
