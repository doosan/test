﻿using UnityEngine;
using UnityEngine.UI;

namespace Pie.ExtensionMethods.UnityEngine.UI
{
    public static class GraphicExtensionMethods
    {
        public static void SetColor(this Graphic graphic, Color color)
        {
            graphic.color = color;
        }

        public static void SetColor(this Graphic graphic, float r, float g, float b, float a)
        {
            graphic.color = new Color(r, g, b, a);
        }

        public static void SetColorA(this Graphic graphic, float a)
        {
            Color c = graphic.color;
            c.a = a;
            graphic.color = c;
        }

        public static void SetColorR(this Graphic graphic, float r)
        {
            Color c = graphic.color;
            c.r = r;
            graphic.color = c;
        }

        public static void SetColorG(this Graphic graphic, float g)
        {
            Color c = graphic.color;
            c.g = g;
            graphic.color = c;
        }

        public static void SetColorB(this Graphic graphic, float b)
        {
            Color c = graphic.color;
            c.b = b;
            graphic.color = c;
        }

        public static void SetColorRGB(this Graphic graphic, Color color)
        {
            Color c = graphic.color;
            c.r = color.r;
            c.g = color.g;
            c.b = color.b;
            graphic.color = c;
        }

        public static void SetColorRGB(this Graphic graphic, float r, float g, float b)
        {
            Color c = graphic.color;
            c.r = r;
            c.g = g;
            c.b = b;
            graphic.color = c;
        }

        public static void SetColorRGB(this Graphic graphic, float value)
        {
            Color c = graphic.color;
            c.r = value;
            c.g = value;
            c.b = value;
            graphic.color = c;
        }
    }
}
