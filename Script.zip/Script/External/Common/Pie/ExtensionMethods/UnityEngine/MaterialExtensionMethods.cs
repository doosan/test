﻿using UnityEngine;

namespace Pie.ExtensionMethods.UnityEngine
{
    public static class MaterialExtensionMethods
    {
        public static void SetColor(this Material mat, Color c)
        {
            mat.color = c;
        }

        public static void SetColor(this Material mat, float r, float g, float b, float a)
        {
            mat.color = new Color(r, g, b, a);
        }

        public static void SetColorA(this Material mat, float a)
        {
            Color c = mat.color;
            c.a = a;
            mat.color = c;
        }

        public static void SetColorR(this Material mat, float r)
        {
            Color c = mat.color;
            c.r = r;
            mat.color = c;
        }

        public static void SetColorG(this Material mat, float g)
        {
            Color c = mat.color;
            c.g = g;
            mat.color = c;
        }

        public static void SetColorB(this Material mat, float b)
        {
            Color c = mat.color;
            c.b = b;
            mat.color = c;
        }

        public static void SetColorRGB(this Material mat, Color color)
        {
            Color c = mat.color;
            c.r = color.r;
            c.g = color.g;
            c.b = color.b;
            mat.color = c;
        }

        public static void SetColorRGB(this Material mat, float r, float g, float b)
        {
            Color c = mat.color;
            c.r = r;
            c.g = g;
            c.b = b;
            mat.color = c;
        }

        public static void SetColorRGB(this Material mat, float value)
        {
            Color c = mat.color;
            c.r = value;
            c.g = value;
            c.b = value;
            mat.color = c;
        }

        public static void SetColor(this Material mat, string propertyName, Color c)
        {
            mat.SetColor(propertyName, c);
        }

        public static void SetColor(this Material mat, string propertyName, float r, float g, float b, float a)
        {
            mat.SetColor(propertyName, new Color(r, g, b, a));
        }

        public static void SetColorA(this Material mat, string propertyName, float a)
        {
            Color c = mat.GetColor(propertyName);
            c.a = a;
            mat.SetColor(propertyName, c);
        }

        public static void SetColorR(this Material mat, string propertyName, float r)
        {
            Color c = mat.GetColor(propertyName);
            c.r = r;
            mat.SetColor(propertyName, c);
        }

        public static void SetColorG(this Material mat, string propertyName, float g)
        {
            Color c = mat.GetColor(propertyName);
            c.g = g;
            mat.SetColor(propertyName, c);
        }

        public static void SetColorB(this Material mat, string propertyName, float b)
        {
            Color c = mat.GetColor(propertyName);
            c.b = b;
            mat.SetColor(propertyName, c);
        }

        public static void SetColorRGB(this Material mat, string propertyName, Color color)
        {
            Color c = mat.GetColor(propertyName);
            c.r = color.r;
            c.g = color.g;
            c.b = color.b;
            mat.SetColor(propertyName, c);
        }

        public static void SetColorRGB(this Material mat, string propertyName, float r, float g, float b)
        {
            Color c = mat.GetColor(propertyName);
            c.r = r;
            c.g = g;
            c.b = b;
            mat.SetColor(propertyName, c);
        }

        public static void SetColorRGB(this Material mat,  string propertyName, float value)
        {
            Color c = mat.GetColor(propertyName);
            c.r = value;
            c.g = value;
            c.b = value;
            mat.SetColor(propertyName, c);
        }

        public static void SetColor(this Material mat, int nameID, Color c)
        {
            mat.SetColor(nameID, c);
        }

        public static void SetColor(this Material mat, int nameID, float r, float g, float b, float a)
        {
            mat.SetColor(nameID, new Color(r, g, b, a));
        }

        public static void SetColorA(this Material mat, int nameID, float a)
        {
            Color c = mat.GetColor(nameID);
            c.a = a;
            mat.SetColor(nameID, c);
        }

        public static void SetColorR(this Material mat, int nameID, float r)
        {
            Color c = mat.GetColor(nameID);
            c.r = r;
            mat.SetColor(nameID, c);
        }

        public static void SetColorG(this Material mat, int nameID, float g)
        {
            Color c = mat.GetColor(nameID);
            c.g = g;
            mat.SetColor(nameID, c);
        }

        public static void SetColorB(this Material mat, int nameID, float b)
        {
            Color c = mat.GetColor(nameID);
            c.b = b;
            mat.SetColor(nameID, c);
        }

        public static void SetColorRGB(this Material mat, int nameID, Color color)
        {
            Color c = mat.GetColor(nameID);
            c.r = color.r;
            c.g = color.g;
            c.b = color.b;
            mat.SetColor(nameID, c);
        }

        public static void SetColorRGB(this Material mat, int nameID, float r, float g, float b)
        {
            Color c = mat.GetColor(nameID);
            c.r = r;
            c.g = g;
            c.b = b;
            mat.SetColor(nameID, c);
        }

        public static void SetColorRGB(this Material mat, int nameID, float value)
        {
            Color c = mat.GetColor(nameID);
            c.r = value;
            c.g = value;
            c.b = value;
            mat.SetColor(nameID, c);
        }
    }
}
