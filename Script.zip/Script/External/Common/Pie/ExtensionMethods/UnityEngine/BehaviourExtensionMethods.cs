﻿using UnityEngine;

namespace Pie.ExtensionMethods.UnityEngine
{
    public static class BehaviourExtensionMethods
    {
        public static void SetEnabled(this Behaviour behaviour, bool enabled)
        {
            behaviour.enabled = enabled;
        }

        public static bool GetEnabled(this Behaviour behaviour)
        {
            return behaviour.enabled;
        }
    }
}
