﻿using UnityEngine;

namespace Pie.ExtensionMethods.UnityEngine
{
    public static class Vector3ExtensionMethods
    {
        public static Vector3 Get__X(this Vector3 vec3, float x = 0.0f, float y = 0.0f)
        {
            return new Vector3(x, y, vec3.x);
        }

        public static Vector3 Get__Y(this Vector3 vec3, float x = 0.0f, float y = 0.0f)
        {
            return new Vector3(x, y, vec3.y);
        }

        public static Vector3 Get__Z(this Vector3 vec3, float x = 0.0f, float y = 0.0f)
        {
            return new Vector3(x, y, vec3.z);
        }

        public static Vector3 Get_X_(this Vector3 vec3, float x = 0.0f, float z = 0.0f)
        {
            return new Vector3(x, vec3.x, z);
        }

        public static Vector3 Get_XX(this Vector3 vec3, float x = 0.0f)
        {
            return new Vector3(x, vec3.x, vec3.x);
        }

        public static Vector3 Get_XY(this Vector3 vec3, float x = 0.0f)
        {
            return new Vector3(x, vec3.x, vec3.y);
        }

        public static Vector3 Get_XZ(this Vector3 vec3, float x = 0.0f)
        {
            return new Vector3(x, vec3.x, vec3.z);
        }

        public static Vector3 Get_Y_(this Vector3 vec3, float x = 0.0f, float z = 0.0f)
        {
            return new Vector3(x, vec3.y, z);
        }

        public static Vector3 Get_YX(this Vector3 vec3, float x = 0.0f)
        {
            return new Vector3(x, vec3.y, vec3.x);
        }

        public static Vector3 Get_YY(this Vector3 vec3, float x = 0.0f)
        {
            return new Vector3(x, vec3.y, vec3.y);
        }

        public static Vector3 Get_YZ(this Vector3 vec3, float x = 0.0f)
        {
            return new Vector3(x, vec3.y, vec3.z);
        }

        public static Vector3 Get_Z_(this Vector3 vec3, float x = 0.0f, float z = 0.0f)
        {
            return new Vector3(x, vec3.z, vec3.z);
        }

        public static Vector3 Get_ZX(this Vector3 vec3, float x = 0.0f)
        {
            return new Vector3(x, vec3.z, vec3.x);
        }

        public static Vector3 Get_ZY(this Vector3 vec3, float x = 0.0f)
        {
            return new Vector3(x, vec3.z, vec3.y);
        }

        public static Vector3 Get_ZZ(this Vector3 vec3, float x = 0.0f)
        {
            return new Vector3(x, vec3.z, vec3.z);
        }

        public static Vector3 GetX__(this Vector3 vec3, float y = 0.0f, float z = 0.0f)
        {
            return new Vector3(vec3.x, y, z);
        }

        public static Vector3 GetX_X(this Vector3 vec3, float y = 0.0f)
        {
            return new Vector3(vec3.x, y, vec3.x);
        }

        public static Vector3 GetX_Y(this Vector3 vec3, float y = 0.0f)
        {
            return new Vector3(vec3.x, y, vec3.y);
        }

        public static Vector3 GetX_Z(this Vector3 vec3, float y = 0.0f)
        {
            return new Vector3(vec3.x, y, vec3.z);
        }

        public static Vector3 GetXX_(this Vector3 vec3, float z = 0.0f)
        {
            return new Vector3(vec3.x, vec3.x, z);
        }

        public static Vector3 GetXXX(this Vector3 vec3)
        {
            return new Vector3(vec3.x, vec3.x, vec3.x);
        }

        public static Vector3 GetXXY(this Vector3 vec3)
        {
            return new Vector3(vec3.x, vec3.x, vec3.y);
        }

        public static Vector3 GetXXZ(this Vector3 vec3)
        {
            return new Vector3(vec3.x, vec3.x, vec3.z);
        }

        public static Vector3 GetXY_(this Vector3 vec3, float z = 0.0f)
        {
            return new Vector3(vec3.x, vec3.y, z);
        }

        public static Vector3 GetXYX(this Vector3 vec3)
        {
            return new Vector3(vec3.x, vec3.y, vec3.x);
        }

        public static Vector3 GetXYY(this Vector3 vec3)
        {
            return new Vector3(vec3.x, vec3.y, vec3.y);
        }

        public static Vector3 GetXYZ(this Vector3 vec3)
        {
            return new Vector3(vec3.x, vec3.y, vec3.z);
        }

        public static Vector3 GetXZ_(this Vector3 vec3, float z = 0.0f)
        {
            return new Vector3(vec3.x, vec3.z, z);
        }

        public static Vector3 GetXZX(this Vector3 vec3)
        {
            return new Vector3(vec3.x, vec3.z, vec3.x);
        }

        public static Vector3 GetXZY(this Vector3 vec3)
        {
            return new Vector3(vec3.x, vec3.z, vec3.y);
        }

        public static Vector3 GetXZZ(this Vector3 vec3)
        {
            return new Vector3(vec3.x, vec3.z, vec3.z);
        }

        public static Vector3 GetY__(this Vector3 vec3, float y = 0.0f, float z = 0.0f)
        {
            return new Vector3(vec3.y, y, z);
        }

        public static Vector3 GetY_X(this Vector3 vec3, float y = 0.0f)
        {
            return new Vector3(vec3.y, y, vec3.x);
        }

        public static Vector3 GetY_Y(this Vector3 vec3, float y = 0.0f)
        {
            return new Vector3(vec3.y, y, vec3.y);
        }

        public static Vector3 GetY_Z(this Vector3 vec3, float y = 0.0f)
        {
            return new Vector3(vec3.y, y, vec3.z);
        }

        public static Vector3 GetYX_(this Vector3 vec3, float z = 0.0f)
        {
            return new Vector3(vec3.y, vec3.x, z);
        }

        public static Vector3 GetYXX(this Vector3 vec3)
        {
            return new Vector3(vec3.y, vec3.x, vec3.x);
        }

        public static Vector3 GetYXY(this Vector3 vec3)
        {
            return new Vector3(vec3.y, vec3.x, vec3.y);
        }

        public static Vector3 GetYXZ(this Vector3 vec3)
        {
            return new Vector3(vec3.y, vec3.x, vec3.z);
        }

        public static Vector3 GetYY_(this Vector3 vec3, float z = 0.0f)
        {
            return new Vector3(vec3.y, vec3.y, z);
        }

        public static Vector3 GetYYX(this Vector3 vec3)
        {
            return new Vector3(vec3.y, vec3.y, vec3.x);
        }

        public static Vector3 GetYYY(this Vector3 vec3)
        {
            return new Vector3(vec3.y, vec3.y, vec3.y);
        }

        public static Vector3 GetYYZ(this Vector3 vec3)
        {
            return new Vector3(vec3.y, vec3.y, vec3.z);
        }

        public static Vector3 GetYZ_(this Vector3 vec3, float z = 0.0f)
        {
            return new Vector3(vec3.y, vec3.z, z);
        }

        public static Vector3 GetYZX(this Vector3 vec3)
        {
            return new Vector3(vec3.y, vec3.z, vec3.x);
        }

        public static Vector3 GetYZY(this Vector3 vec3)
        {
            return new Vector3(vec3.y, vec3.z, vec3.y);
        }

        public static Vector3 GetYZZ(this Vector3 vec3)
        {
            return new Vector3(vec3.y, vec3.z, vec3.z);
        }

        public static Vector3 GetZ__(this Vector3 vec3, float y = 0.0f, float z = 0.0f)
        {
            return new Vector3(vec3.z, y, z);
        }

        public static Vector3 GetZ_X(this Vector3 vec3, float y = 0.0f)
        {
            return new Vector3(vec3.z, y, vec3.x);
        }

        public static Vector3 GetZ_Y(this Vector3 vec3, float y = 0.0f)
        {
            return new Vector3(vec3.z, y, vec3.y);
        }

        public static Vector3 GetZ_Z(this Vector3 vec3, float y = 0.0f)
        {
            return new Vector3(vec3.z, y, vec3.z);
        }

        public static Vector3 GetZX_(this Vector3 vec3, float z = 0.0f)
        {
            return new Vector3(vec3.z, vec3.x, z);
        }

        public static Vector3 GetZXX(this Vector3 vec3)
        {
            return new Vector3(vec3.z, vec3.x, vec3.x);
        }

        public static Vector3 GetZXY(this Vector3 vec3)
        {
            return new Vector3(vec3.z, vec3.x, vec3.y);
        }

        public static Vector3 GetZXZ(this Vector3 vec3)
        {
            return new Vector3(vec3.z, vec3.x, vec3.z);
        }

        public static Vector3 GetZY_(this Vector3 vec3, float z = 0.0f)
        {
            return new Vector3(vec3.z, vec3.y, z);
        }

        public static Vector3 GetZYX(this Vector3 vec3)
        {
            return new Vector3(vec3.z, vec3.y, vec3.x);
        }

        public static Vector3 GetZYY(this Vector3 vec3)
        {
            return new Vector3(vec3.z, vec3.y, vec3.y);
        }

        public static Vector3 GetZYZ(this Vector3 vec3)
        {
            return new Vector3(vec3.z, vec3.y, vec3.z);
        }

        public static Vector3 GetZZ_(this Vector3 vec3, float z = 0.0f)
        {
            return new Vector3(vec3.z, vec3.z, z);
        }

        public static Vector3 GetZZX(this Vector3 vec3)
        {
            return new Vector3(vec3.z, vec3.z, vec3.x);
        }

        public static Vector3 GetZZY(this Vector3 vec3)
        {
            return new Vector3(vec3.z, vec3.z, vec3.y);
        }

        public static Vector3 GetZZZ(this Vector3 vec3)
        {
            return new Vector3(vec3.z, vec3.z, vec3.z);
        }

        public static Vector2 To_X(this Vector3 vec3, float x = 0.0f)
        {
            return new Vector2(x, vec3.x);
        }

        public static Vector2 To_Y(this Vector3 vec3, float x = 0.0f)
        {
            return new Vector2(x, vec3.y);
        }

        public static Vector2 To_Z(this Vector3 vec3, float x = 0.0f)
        {
            return new Vector2(x, vec3.z);
        }

        public static Vector2 ToX_(this Vector3 vec3, float y = 0.0f)
        {
            return new Vector2(vec3.x, y);
        }

        public static Vector2 ToXX(this Vector3 vec3)
        {
            return new Vector2(vec3.x, vec3.x);
        }

        public static Vector2 ToXY(this Vector3 vec3)
        {
            return new Vector2(vec3.x, vec3.y);
        }

        public static Vector2 ToXZ(this Vector3 vec3)
        {
            return new Vector2(vec3.x, vec3.z);
        }

        public static Vector2 ToY_(this Vector3 vec3, float y = 0.0f)
        {
            return new Vector2(vec3.y, y);
        }

        public static Vector2 ToYX(this Vector3 vec3)
        {
            return new Vector2(vec3.y, vec3.x);
        }

        public static Vector2 ToYY(this Vector3 vec3)
        {
            return new Vector2(vec3.y, vec3.y);
        }

        public static Vector2 ToYZ(this Vector3 vec3)
        {
            return new Vector2(vec3.y, vec3.z);
        }

        public static Vector2 ToZ_(this Vector3 vec3, float y = 0.0f)
        {
            return new Vector2(vec3.z, y);
        }

        public static Vector2 ToZX(this Vector3 vec3)
        {
            return new Vector2(vec3.z, vec3.x);
        }

        public static Vector2 ToZY(this Vector3 vec3)
        {
            return new Vector2(vec3.z, vec3.y);
        }

        public static Vector2 ToZZ(this Vector3 vec3)
        {
            return new Vector2(vec3.z, vec3.z);
        }
    }
}
