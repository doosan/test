﻿using UnityEngine;

namespace Pie.ExtensionMethods.UnityEngine
{
    public static class GameObjectExtensionMethods
    {
        public static GameObject Instantiate(this GameObject go)
        {
            return GameObject.Instantiate(go);
        }

        public static GameObject Instantiate(this GameObject go, Vector3 position, Quaternion rotation)
        {
            return GameObject.Instantiate(go, position, rotation) as GameObject;
        }

        public static GameObject Duplicate(this GameObject go, bool worldPositionStays = false)
        {
            var duplicated = GameObject.Instantiate(go);
            duplicated.transform.SetParent(go.transform.parent, false);
            return duplicated;
        }

        public static T GetOrAddComponent<T>(this GameObject gameObject) where T : Component
        {
            T component = gameObject.GetComponent<T>();
            if (component == null)
            {
                component = gameObject.AddComponent<T>();
            }

            return component;
        }

        public static void SetLayerRecursively(this GameObject go, string layerName)
        {
            SetChildLayerRecursively(go.transform, LayerMask.NameToLayer(layerName));
        }

        public static void SetLayerRecursively(this GameObject go, int layer)
        {
            SetChildLayerRecursively(go.transform, layer);
        }

        private static void SetChildLayerRecursively(Transform t, int layer)
        {
            t.gameObject.layer = layer;

            for (int i = 0; i < t.childCount; i += 1)
            {
                SetChildLayerRecursively(t.GetChild(i), layer);
            }
        }
    }
}
