﻿using UnityEngine;

namespace Pie.ExtensionMethods.UnityEngine {

    public static class SpriteRendererExtensionMethods
    {
        public static void SetColor(this SpriteRenderer sr, Color color)
        {
            sr.color = color;
        }

        public static void SetColor(this SpriteRenderer sr, float r, float g, float b, float a)
        {
            sr.color = new Color(r, g, b, a);
        }

        public static void SetColorA(this SpriteRenderer sr, float a)
        {
            Color c = sr.color;
            c.a = a;
            sr.color = c;
        }

        public static void SetColorR(this SpriteRenderer sr, float r)
        {
            Color c = sr.color;
            c.r = r;
            sr.color = c;
        }

        public static void SetColorG(this SpriteRenderer sr, float g)
        {
            Color c = sr.color;
            c.g = g;
            sr.color = c;
        }

        public static void SetColorB(this SpriteRenderer sr, float b)
        {
            Color c = sr.color;
            c.b = b;
            sr.color = c;
        }

        public static void SetColorRGB(this SpriteRenderer sr, Color color)
        {
            Color c = sr.color;
            c.r = color.r;
            c.g = color.g;
            c.b = color.b;
            sr.color = c;
        }

        public static void SetColorRGB(this SpriteRenderer sr, float r, float g, float b)
        {
            Color c = sr.color;
            c.r = r;
            c.g = g;
            c.b = b;
            sr.color = c;
        }

        public static void SetColorRGB(this SpriteRenderer sr, float value)
        {
            Color c = sr.color;
            c.r = value;
            c.g = value;
            c.b = value;
            sr.color = c;
        }

        public static Vector2 GetBorderSize(this Sprite sprite)
        {
            Vector4 border = sprite.border;
            return new Vector2(border.x + border.z, border.y + border.w);
        }
    }
}
