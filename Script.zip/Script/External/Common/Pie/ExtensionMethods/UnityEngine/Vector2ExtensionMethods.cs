﻿using UnityEngine;

namespace Pie.ExtensionMethods.UnityEngine
{
    public static class Vector2ExtensionMethods
    {
        public static Vector2 Get_X(this Vector2 vec2, float x = 0.0f)
        {
            return new Vector2(x, vec2.x);
        }

        public static Vector2 Get_Y(this Vector2 vec2, float x = 0.0f)
        {
            return new Vector2(x, vec2.y);
        }

        public static Vector2 GetX_(this Vector2 vec2, float y = 0.0f)
        {
            return new Vector2(vec2.x, y);
        }

        public static Vector2 GetXX(this Vector2 vec2)
        {
            return new Vector2(vec2.x, vec2.x);
        }

        public static Vector2 GetXY(this Vector2 vec2)
        {
            return vec2;
        }

        public static Vector2 GetY_(this Vector2 vec2, float y = 0.0f)
        {
            return new Vector2(vec2.y, y);
        }

        public static Vector2 GetYX(this Vector2 vec2)
        {
            return new Vector2(vec2.y, vec2.x);
        }

        public static Vector2 GetYY(this Vector2 vec2)
        {
            return new Vector2(vec2.y, vec2.y);
        }

        public static Vector3 To_X_(this Vector2 vec2, float x = 0.0f, float z = 0.0f)
        {
            return new Vector3(x, vec2.x, z);
        }

        public static Vector3 To_XX(this Vector2 vec2, float x = 0.0f)
        {
            return new Vector3(x, vec2.x, vec2.x);
        }

        public static Vector3 To_XY(this Vector2 vec2, float x = 0.0f)
        {
            return new Vector3(x, vec2.x, vec2.y);
        }

        public static Vector3 To_Y_(this Vector2 vec2, float x = 0.0f, float z = 0.0f)
        {
            return new Vector3(x, vec2.y, z);
        }

        public static Vector3 To_YX(this Vector2 vec2, float x = 0.0f)
        {
            return new Vector3(x, vec2.y, vec2.x);
        }

        public static Vector3 To_YY(this Vector2 vec2, float x = 0.0f)
        {
            return new Vector3(x, vec2.y, vec2.y);
        }

        public static Vector3 ToXX_(this Vector2 vec2, float z = 0.0f)
        {
            return new Vector3(vec2.x, vec2.x, z);
        }

        public static Vector3 ToXXX(this Vector2 vec2)
        {
            return new Vector3(vec2.x, vec2.x, vec2.x);
        }

        public static Vector3 ToXXY(this Vector2 vec2)
        {
            return new Vector3(vec2.x, vec2.x, vec2.y);
        }

        public static Vector3 ToXY_(this Vector2 vec2, float z = 0.0f)
        {
            return new Vector3(vec2.x, vec2.y, z);
        }

        public static Vector3 ToXYX(this Vector2 vec2)
        {
            return new Vector3(vec2.x, vec2.y, vec2.x);
        }

        public static Vector3 ToXYY(this Vector2 vec2)
        {
            return new Vector3(vec2.x, vec2.y, vec2.y);
        }

        public static Vector3 ToY__(this Vector2 vec2, float y = 0.0f, float z = 0.0f)
        {
            return new Vector3(vec2.y, y, z);
        }

        public static Vector3 ToY_X(this Vector2 vec2, float y = 0.0f)
        {
            return new Vector3(vec2.y, y, vec2.x);
        }

        public static Vector3 ToY_Y(this Vector2 vec2, float y = 0.0f)
        {
            return new Vector3(vec2.y, y, vec2.y);
        }

        public static Vector3 ToYX_(this Vector2 vec2, float z = 0.0f)
        {
            return new Vector3(vec2.y, vec2.x, z);
        }

        public static Vector3 ToYXX(this Vector2 vec2)
        {
            return new Vector3(vec2.y, vec2.x, vec2.x);
        }

        public static Vector3 ToYXY(this Vector2 vec2)
        {
            return new Vector3(vec2.y, vec2.x, vec2.y);
        }

        public static Vector3 ToYY_(this Vector2 vec2, float z = 0.0f)
        {
            return new Vector3(vec2.y, vec2.y, z);
        }

        public static Vector3 ToYYX(this Vector2 vec2)
        {
            return new Vector3(vec2.y, vec2.y, vec2.x);
        }

        public static Vector3 ToYYY(this Vector2 vec2)
        {
            return new Vector3(vec2.y, vec2.y, vec2.y);
        }
    }
}
