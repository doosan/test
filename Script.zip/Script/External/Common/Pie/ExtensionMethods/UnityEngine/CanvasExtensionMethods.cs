using UnityEngine;

namespace Pie.ExtensionMethods.UnityEngine
{
    public static class CanvasExtensionMethods
    {
        public static Rect? CustomSafeArea;

        /// <summary>
        /// 캔버스의 Safe Area를 계산해서 반환한다. Overlay 모드인 경우만 의미가 있으며, <see cref="Canvas.scaleFactor"/> 값을
        /// 사용하기 때문에 해당 값이 확정된 이후 호출해야 올바른 결과를 얻을 수 있다.
        /// </summary>
        /// <returns>캔버스 크기를 기준으로한 Safe Area.</returns>
        public static Rect GetSafeArea(this Canvas canvas)
        {
            Rect safeArea = Screen.safeArea;

            if (CustomSafeArea.HasValue)
            {
                safeArea = CustomSafeArea.Value;
            }

            float scaleFactor = canvas.scaleFactor;
            Vector2 position = safeArea.position / scaleFactor;
            Vector2 size = safeArea.size / scaleFactor;

            return Rect.MinMaxRect(
                Mathf.Ceil(position.x),
                Mathf.Ceil(position.y),
                Mathf.Floor(size.x),
                Mathf.Floor(size.y));
        }
    }
}
