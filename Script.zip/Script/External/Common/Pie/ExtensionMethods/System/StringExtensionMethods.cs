﻿using System;
using System.Text;

namespace Pie.ExtensionMethods.System
{
    public static class StringExtensionMethods
    {
        #region String
        public static object FormatWith<T1>(this string s, T1 arg1)
        {
            return new StringFormatter1<T1>(s, arg1);
        }

        public static object FormatWith<T1>(this string s, IFormatProvider provider, T1 arg1)
        {
            return new StringFormatter1<T1>(provider, s, arg1);
        }

        public static object FormatWith<T1, T2>(this string s, T1 arg1, T2 arg2)
        {
            return new StringFormatter2<T1, T2>(s, arg1, arg2);
        }

        public static object FormatWith<T1, T2>(this string s, IFormatProvider provider, T1 arg1, T2 arg2)
        {
            return new StringFormatter2<T1, T2>(provider, s, arg1, arg2);
        }

        public static object FormatWith<T1, T2, T3>(this string s, T1 arg1, T2 arg2, T3 arg3)
        {
            return new StringFormatter3<T1, T2, T3>(s, arg1, arg2, arg3);
        }

        public static object FormatWith<T1, T2, T3>(this string s, IFormatProvider provider, T1 arg1, T2 arg2, T3 arg3)
        {
            return new StringFormatter3<T1, T2, T3>(provider, s, arg1, arg2, arg3);
        }

        public static object FormatWith(this string s, params object[] args)
        {
            return new StringFormatter(s, args);
        }

        public static object FormatWith(this string s, IFormatProvider provider, params object[] args)
        {
            return new StringFormatter(provider, s, args);
        }
        #endregion

        #region StringBuilder
        public static void Clear(this StringBuilder builder)
        {
            builder.Length = 0;
        }
        #endregion

        private class StringFormatter1<T1>
        {
            public StringFormatter1(string format, T1 arg1)
                    : this(null, format, arg1)
            {
            }

            public StringFormatter1(IFormatProvider provider, string format, T1 arg1)
            {
                _provider = provider;
                _format = format;
                _arg1 = arg1;
            }

            #region Override from object
            public override string ToString()
            {
                return string.Format(_provider, _format, _arg1);
            }
            #endregion

            private readonly IFormatProvider _provider;
            private readonly string _format;
            private readonly T1 _arg1;
        }

        private class StringFormatter2<T1, T2>
        {
            public StringFormatter2(string format, T1 arg1, T2 arg2)
                    : this(null, format, arg1, arg2)
            {
            }

            public StringFormatter2(IFormatProvider provider, string format, T1 arg1, T2 arg2)
            {
                _provider = provider;
                _format = format;
                _arg1 = arg1;
                _arg2 = arg2;
            }

            #region Override from object
            public override string ToString()
            {
                return string.Format(_provider, _format, _arg1, _arg2);
            }
            #endregion

            private readonly IFormatProvider _provider;
            private readonly string _format;
            private readonly T1 _arg1;
            private readonly T2 _arg2;
        }

        private class StringFormatter3<T1, T2, T3>
        {
            public StringFormatter3(string format, T1 arg1, T2 arg2, T3 arg3)
                    : this(null, format, arg1, arg2, arg3)
            {
            }

            public StringFormatter3(IFormatProvider provider, string format, T1 arg1, T2 arg2, T3 arg3)
            {
                _provider = provider;
                _format = format;
                _arg1 = arg1;
                _arg2 = arg2;
                _arg3 = arg3;
            }

            #region Override from object
            public override string ToString()
            {
                return string.Format(_provider, _format, _arg1, _arg2, _arg3);
            }
            #endregion

            private readonly IFormatProvider _provider;
            private readonly string _format;
            private readonly T1 _arg1;
            private readonly T2 _arg2;
            private readonly T3 _arg3;
        }

        private class StringFormatter
        {
            public StringFormatter(string format, params object[] args)
                    : this(null, format, args)
            {
            }

            public StringFormatter(IFormatProvider provider, string format, params object[] args)
            {
                _provider = provider;
                _format = format;
                _args = args;
            }

            #region Override from object
            public override string ToString()
            {
                return string.Format(_provider, _format, _args);
            }
            #endregion

            private readonly IFormatProvider _provider;
            private readonly string _format;
            private readonly object[] _args;
        }
    }
}
