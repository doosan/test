﻿using System;
using System.Collections.Generic;
using Pie.Collections;

namespace Pie.ExtensionMethods.System.Collections.Generic
{
    public static class ListExtensionMethods
    {
        public static void Swap<T>(this IList<T> list, int x, int y)
        {
            if (x == y)
            {
                return;
            }

            T temp = list[x];
            list[x] = list[y];
            list[y] = temp;
        }

        public static void RemoveAtSwap<T>(this IList<T> list, int index)
        {
            if (index < 0 || index >= list.Count)
            {
                throw new ArgumentOutOfRangeException("index", index, "유효한 범위가 아닙니다.");
            }

            int lastIndex = list.Count - 1;
            if (index != lastIndex)
            {
                list.Swap(index, lastIndex);
            }
            list.RemoveAt(lastIndex);
        }

        public static bool RemoveSwap<T>(this IList<T> list, T item)
        {
            int index = list.IndexOf(item);
            if (index == -1)
            {
                return false;
            }

            list.RemoveAtSwap(index);
            return true;
        }

        public static int IndexOf<T>(this Pie.Collections.IReadOnlyList<T> list, T item)
        {
            for (int i = 0; i < list.Count; ++i)
            {
                if (EqualityComparer<T>.Default.Equals(list[i], item))
                {
                    return i;
                }
            }
            return -1;
        }
    }
}
