﻿using System;
using System.Collections.Generic;
using Pie.Collections;

namespace Pie.ExtensionMethods.System.Collections.Generic
{
    public static class DictionaryExtensionMethods
    {
        public static void Swap<TKey, TValue>(this IDictionary<TKey, TValue> dict, TKey x, TKey y)
        {
            TValue temp = dict[x];
            dict[x] = dict[y];
            dict[y] = temp;
        }

        public static void Add<TKey, TValue>(this IDictionary<TKey, TValue> dict, KeyValuePair<TKey, TValue> pair)
        {
            dict.Add(pair.Key, pair.Value);
        }

        public static TValue GetOrDefault<TKey, TValue>(this Pie.Collections.IReadOnlyDictionary<TKey, TValue> dict, TKey key, Func<TValue> defaultValue)
        {
            TValue result;
            return dict.TryGetValue(key, out result) ? result : defaultValue();
        }

        public static TValue GetOrDefault<TKey, TValue>(this Pie.Collections.IReadOnlyDictionary<TKey, TValue> dict, TKey key, TValue defaultValue)
        {
            TValue result;
            return dict.TryGetValue(key, out result) ? result : defaultValue;
        }

        public static TValue GetOrDefault<TKey, TValue>(this Pie.Collections.IReadOnlyDictionary<TKey, TValue> dict, TKey key)
        {
            TValue result;
            return dict.TryGetValue(key, out result) ? result : default(TValue);
        }

        public static TValue GetOrDefault<TKey, TValue>(this IDictionary<TKey, TValue> dict, TKey key, Func<TValue> defaultValue)
        {
            TValue result;
            return dict.TryGetValue(key, out result) ? result : defaultValue();
        }

        public static TValue GetOrDefault<TKey, TValue>(this IDictionary<TKey, TValue> dict, TKey key, TValue defaultValue)
        {
            TValue result;
            return dict.TryGetValue(key, out result) ? result : defaultValue;
        }

        public static TValue GetOrDefault<TKey, TValue>(this IDictionary<TKey, TValue> dict, TKey key)
        {
            TValue result;
            return dict.TryGetValue(key, out result) ? result : default(TValue);
        }

        public static TValue GetOrAdd<TKey, TValue>(this IDictionary<TKey, TValue> dict, TKey key, Func<TValue> value)
        {
            TValue result;
            if (!dict.TryGetValue(key, out result))
            {
                result = value();
                dict.Add(key, result);
            }
            return result;
        }

        public static TValue GetOrAdd<TKey, TValue>(this IDictionary<TKey, TValue> dict, TKey key, TValue value)
        {
            TValue result;
            if (!dict.TryGetValue(key, out result))
            {
                result = value;
                dict.Add(key, result);
            }
            return result;
        }
    }
}
