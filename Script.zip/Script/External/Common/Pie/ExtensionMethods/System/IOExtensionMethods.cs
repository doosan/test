﻿using System.IO;

namespace Pie.ExtensionMethods.System.IO
{
    public static class IOExtensionMethods
    {
        public static byte[] ReadAllBytes(this BinaryReader reader)
        {
            const int bufferSize = 4096;
            byte[] buffer = new byte[bufferSize];

            using (var stream = new MemoryStream())
            {
                while (true)
                {
                    int count = reader.Read(buffer, 0, buffer.Length);
                    if (count == 0)
                    {
                        break;
                    }

                    stream.Write(buffer, 0, count);
                }

                return stream.ToArray();
            }
        }
    }
}
