﻿using System;
using System.Collections.Generic;
using UnityEngine;
using Pie.Collections;

// TODO: 에러를 예외로 변경.
// TODO: Line, Column 번호 표시.

namespace Pie.Csv
{
    /// <summary>
    /// CSV를 레코드 단위로 파싱한다.
    /// </summary>
    public partial class CsvReader
    {
        /// <summary>
        /// CSV 문자열로부터 레코드를 읽고 인스턴스가 해당 레코드의 필드 값을 읽을 수 있는 상태로 만든다.
        /// </summary>
        /// <remarks>
        /// CsvReader가 생성된 시점에는 아무 레코드도 가리키고 있는 상태가 아니기 때문에 <c>Read</c>를 호출하여 첫번째
        /// 레코드를 가리키도록 해야한다. 헤더는 첫번째 레코드에 포함되지 않는다.
        /// </remarks>
        /// <returns>레코드를 읽었다면 <c>true</c>, 오류가 발생했거나 더 읽을 레코드가 없다면 <c>false</c>.</returns>
        public bool Read()
        {
            // 문자열 끝에 도달했다면 종료.
            if (EOF)
            {
                _currentRecord.Clear();
                return false;
            }

            CurrentRecordIndex += 1;
            // 레코드를 읽고 현재 위치를 갱신한다.
            if (TryParseRecord(_csv, Settings, ref _currentRecord, ref _position) == false)
            {
                // ReadState = 
                return false;
            }

            // 레코드의 필드 수를 확인한다.
            if (_currentRecord.Count != FieldCount)
            {
                throw new InvalidRecordException("레코드의 필드 수가 기존 레코드와 일치하지 않습니다.", CurrentRecordIndex);
            }

            return true;
        }

        public void Reset()
        {
            CurrentRecordIndex = 0;

            _position = 0;
            _currentRecord.Clear();

            if (HasHeader)
            {
                Read();
            }
        }

        public bool ContainsHeader(string name)
        {
            return (_fieldNames != null) && _fieldNames.Contains(name);
        }

        /// <summary>
        /// 인스턴스를 생성하는 데 사용한 <see cref="CsvReaderSettings"/> 인스턴스. 이 값을 바꾸더라도 파싱 관련 옵션은 변경되지
        /// 않는다.
        /// </summary>
        /// <value>
        /// 인스턴스를 생성하는 데 사용한 <see cref="CsvReaderSettings"/> 인스턴스. Create에서 설정하지 않았다면 기본값을 사용한다.
        /// </value>
        public CsvReaderSettings Settings
        {
            get;
            private set;
        }

        /// <summary>
        /// 헤더를 가지고있는지를 타나낸다.
        /// </summary>
        /// <value>
        /// <see cref="CsvReaderSettings.HasHeader"/>를 <c>true</c>로 설정하여 첫번째 레코드를 헤더로 파싱했다면 <c>true</c>,
        /// 그렇지 않다면 <c>false</c>.
        /// </value>
        public bool HasHeader
        {
            get { return FieldNames != null; }
        }

        /// <summary>
        /// 헤더가 있을 경우 필드에 헤더 이름으로 접근하려 할 때 사용하는 StringComparer.
        /// </summary>
        /// <value>
        /// 헤더 이름을 비교할 때 사용하는 <see cref="StringComparer"/>. 기본값으로 생성했다면
        /// StringComparer.OrdinalIgnoreCase를 사용한다.
        /// </value>
        public StringComparer HeaderComparer
        {
            get { return _nameToIndex.Comparer as StringComparer; }
        }

        /// <summary>
        /// <see cref="CsvReaderSettings.HasHeader"/>를 <c>true</c>로 설정하여 첫번째 레코드를 헤더로 파싱했다면 이 프로퍼티를
        /// 사용하여 헤더 목록을 읽을 수 있다.
        /// </summary>
        /// <value>
        /// 헤더를 생성했다면 열거 가능한 헤더 목록을 가지고 그렇지 않다면 null 값을 가진다.
        /// </value>
        public Pie.Collections.IReadOnlyList<string> FieldNames
        {
            get;
            private set;
        }

        /// <summary>
        /// 필드 수.
        /// </summary>
        /// <value>첫번째 레코드를 파싱한 결과로 확정된 필드 수.</value>
        public int FieldCount
        {
            get;
            private set;
        }

        public Pie.Collections.IReadOnlyList<string> CurrentRecord
        {
            get;
            private set;
        }

        /// <summary>
        /// 현재 파싱 중인 레코드의 번호를 나타낸다. 텍스트 파일의 라인 번호가 아닌 레코드의 번호라는 것을 주의.
        /// </summary>
        /// <value>현재 파싱 중인 레코드 번호.</value>
        public int CurrentRecordIndex
        {
            get;
            private set;
        }

        /// <summary>
        /// Read 메서드의 호출 결과로 리더가 CSV 문자열의 끝에 도달했는지를 나타낸다.
        /// </summary>
        /// <value>리더가 CSV 문자열의 끝에 도달했다면 <c>true</c>, 그렇지 않다면 <c>false</c>.</value>
        public bool EOF
        {
            get { return string.IsNullOrEmpty(_csv) || _position >= _csv.Length; }
        }

        /// <summary>
        /// 현재 리더가 가리키고 있는 레코드의 필드에 필드 인덱스로 접근한다.
        /// </summary>
        /// <param name="index">필드 인덱스.</param>
        /// <value>지정된 필드의 값.</value>
        public string this[int index]
        {
            get { return _currentRecord[index]; }
        }

        /// <summary>
        /// 현재 리더가 가리키고 있는 레코드의 필드에 필드 이름으로 접근한다. 필드 이름으로 접근하기 위해서는 헤더가
        /// 반드시 있어야 한다.
        /// </summary>
        /// <param name="name">필드 이름.</param>
        /// <value>지정된 필드의 값.</value>
        public string this[string name]
        {
            get { return _currentRecord[_nameToIndex[name]]; }
        }

        private CsvReader(string csv, CsvReaderSettings settings, int startPosition, List<string> header, int fieldCount)
        {
            _csv = csv;
            _position = startPosition;

            Settings = settings;

            if (header != null)
            {
                if (header.Count != fieldCount)
                {
                    throw new ArgumentException("header.Count와 fieldCount가 같은 값이 아닙니다.", "header");
                }

                _fieldNames = new HashSet<string>(header, settings.HeaderComparer);

                if (header.Count != fieldCount)
                {
                    throw new ArgumentException("header에 중복된 이름이 있습니다.", "header");
                }

                _nameToIndex = new Dictionary<string, int>(settings.HeaderComparer);

                for (int i = 0; i < header.Count; i += 1)
                {
                    _nameToIndex.Add(header[i], i);
                }

                FieldNames = new ReadOnlyList<string>(header);
            }

            FieldCount = fieldCount;
            CurrentRecord = new ReadOnlyList<string>(_currentRecord);
            CurrentRecordIndex = settings.HeaderRecordIndex;
        }

        private HashSet<string> _fieldNames;
        private Dictionary<string, int> _nameToIndex;

        private string _csv;
        private int _position;
        private List<string> _currentRecord = new List<String>();
    }
}
