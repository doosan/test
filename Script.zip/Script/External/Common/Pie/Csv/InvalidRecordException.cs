﻿using System;

namespace Pie.Csv
{
    public sealed class InvalidRecordException : Exception
    {
        private static string GetMessage(string message, int recordNumber)
        {
            return string.Format("{0}{3}행: {1}{3}열: {2}", message, recordNumber, Environment.NewLine);
        }

        public InvalidRecordException(string message, int recordNumber)
                : base(GetMessage(message, recordNumber))
        {
            RecordNumber = recordNumber;
        }

        public InvalidRecordException(string message, int recordNumber, Exception innerException)
                : base(GetMessage(message, recordNumber), innerException)
        {
            RecordNumber = recordNumber;
        }

        public int RecordNumber
        {
            get;
            private set;
        }
    }
}
