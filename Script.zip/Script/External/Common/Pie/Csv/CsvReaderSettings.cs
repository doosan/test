﻿using System;

namespace Pie.Csv
{
    /// <summary>
    /// <see cref="CsvReader"/>를 생성하고 파싱할 때 사용되는 각종 옵션을 지정한다.
    /// </summary>
    public struct CsvReaderSettings
    {
        public static readonly CsvReaderSettings Default = new CsvReaderSettings();

        public CsvReaderSettings(char delimiter = ',') : this()
        {
            Delimiter = delimiter;

            Escape = '"';
            Quote = '"';

            HeaderRecordIndex = 1;
            HeaderComparer = StringComparer.OrdinalIgnoreCase;
        }

        /// <summary>
        /// 필드를 구분하기 위한 분리자. 기본값은 ','. LF(U+000A)와 CR(U+000D)은 분리자로 사용할 수 없다.
        /// </summary>
        /// <value>CSV 문자열에서 분리자로 판단할 문자.</value>
        public char Delimiter
        {
            get { return _delimiter; }
            set
            {
                if (value == '\u000A' || value == '\u000D')
                {
                    throw new ArgumentException("LF(U+000A)와 CR(U+000D)은 분리자로 사용할 수 없습니다.", "Delimiter");
                }

                _delimiter = value;
            }
        }

        /// <summary>
        /// 인용 부호 내에서 인용 부호를 이스케이프하기 위한 문자. 기본값은 '"'. LF(U+000A)와 CR(U+000D)은 이스케이프
        /// 문자로 사용할 수 없다.
        /// </summary>
        /// <value>CSV 문자열에서 인용 부호 내부의 인용 부호를 이스케이프하는 문자.</value>
        public char Escape
        {
            get { return _escape; }
            set
            {
                if (value == '\u000A' || value == '\u000D')
                {
                    throw new ArgumentException("LF(U+000A)와 CR(U+000D)은 이스케이프 문자로 사용할 수 없습니다.", "Escape");
                }

                _escape = value;
            }
        }

        /// <summary>
        /// 인용 부호를 나타내는 문자. 기본값은 '"'. LF(U+000A)와 CR(U+000D)은 인용 부호로 사용할 수 없다.
        /// </summary>
        /// <value>CSV 문자열에서 인용 부호로 판단할 문자.</value>
        public char Quote
        {
            get { return _quote; }
            set
            {
                if (value == '\u000A' || value == '\u000D')
                {
                    throw new ArgumentException("LF(U+000A)와 CR(U+000D)은 인용 부호로 사용할 수 없습니다.", "Quote");
                }

                _quote = value;
            }
        }

        /// <summary>
        /// 헤더를 가지고 있는지 나타낸다. 헤더가 있다면 필드에 헤더 이름으로 접근할 수 있다.
        /// </summary>
        /// <value>
        /// <see cref="HeaderRecordIndex"/>에 지정한 레코드가 0이 아니라면 <c>true</c>, 그렇지 않다면 <c>false</c>.
        /// </value>
        public bool HasHeader
        {
            get { return HeaderRecordIndex > 0; }
        }

        /// <summary>
        /// 몇번째 레코드(인덱스)를 헤드로 사용할 지 나타낸다. 레코드 인덱스는 1부터 시작한다. 0일 경우 헤더를 사용하지
        /// 않는다. 1보다 클 경우 헤더보다 이전의 레코드는 무시된다.
        /// </summary>
        /// <value>몇번째 레코드(인덱스)를 헤드로 사용할 지 나타낸다. 기본 값은 1.</value>
        public int HeaderRecordIndex
        {
            get;
            set;
        }

        /// <summary>
        /// 필드 헤더가 있을 경우 필드를 헤더 이름으로 접근하려 할 때 사용할 StringComparer. 기본값은
        /// <see cref="StringComparer.OrdinalIgnoreCase"/>.
        /// </summary>
        /// <value>헤더 이름을 찾는데 사용할 문자열의 동등성을 비교하는 StringComparer.</value>
        public StringComparer HeaderComparer
        {
            get;
            set;
        }

        /// <summary>
        /// 인용 부호가 없는 필드 문자열의 선행 공백과 후행 공백을 제거할지를 나타낸다. 인용 부호가 있는 필드는
        /// 인용 부호의 바깥은 공백은 무시하고 안의 공백은 유지한다. 기본값은 <c>false</c>.
        /// </summary>
        /// <value>
        /// 인용 부호로 둘러쌓이지 않은 필드의 선행 공백과 후행 공백을 제거하려면 <c>true</c>, 공백을 보존하려면
        /// <c>false</c>.
        /// </value>
        public bool TrimNotQuotedField
        {
            get;
            set;
        }

        private char _delimiter;
        private char _escape;
        private char _quote;
    }
}
