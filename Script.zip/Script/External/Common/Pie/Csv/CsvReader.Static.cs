﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using UnityEngine;

namespace Pie.Csv
{
    public partial class CsvReader
    {
        /// <summary>
        /// CSV 문자열과 ICSVReaderSettings 인스턴스를 사용하여 CSVReader를 생성한다.
        /// </summary>
        /// <remarks>
        /// 생성 시, 헤더를 기록하거나 필드 수를 확인하기 위해 첫번째 레코드를 파싱한다. 이 과정이 실패하면 null을
        /// 반환한다.
        /// </remarks>
        /// <param name="csv">CSV 문자열.</param>
        /// <param name="settings">CSV 문자열을 파싱하는데 사용할 <see cref="CsvReaderSettings"/> 인스턴스.</param>
        /// <returns>CSVReader 인스턴스. CSV 문자열이 없거나 첫번째 레코드를 읽을 수 없다면 null을 반환한다.</returns>
        /// <exception cref="ArgumentNullException"><c>csv</c>가 <c>null</c>일 경우.</exception>
        public static CsvReader Create(string csv, CsvReaderSettings settings)
        {
            if (csv == null)
            {
                throw new ArgumentNullException("csv");
            }

            if (csv.Length == 0)
            {
                throw new ArgumentException("파싱할 문자열이 없습니다.", "csv");
            }

            // 첫번째 레코드를 읽고 필드 수를 기록한다.
            var currentRecord = new List<string>();
            var currentPosition = 0;

            int fieldCount;

            if (settings.HasHeader)
            {
                for (var i = 0; i < settings.HeaderRecordIndex; ++i)
                {
                    if (!TryParseRecord(csv, settings, ref currentRecord, ref currentPosition))
                    {
                        throw new ArgumentException("헤더로 사용할 레코드 인덱스보다 데이터가 적습니다.", "csv");
                    }
                }

                // 헤더에 빈 필드가 있어서는 안 된다.
                if (currentRecord.FindIndex(s => string.IsNullOrEmpty(s)) != -1)
                {
                    throw new ArgumentException("헤더는 빈 필드를 가질 수 없습니다.", "csv");
                }

                // 헤더 중복 검사.
                var fieldHeaders = new HashSet<string>(currentRecord, settings.HeaderComparer);
                if (fieldHeaders.Count != currentRecord.Count)
                {
                    throw new ArgumentException("헤더에 중복된 이름이 있습니다.", "csv");
                }

                fieldCount = currentRecord.Count;
            }
            else
            {
                if (!TryParseRecord(csv, settings, ref currentRecord, ref currentPosition))
                {
                    return null;
                }

                fieldCount = currentRecord.Count;

                currentRecord   = null;
                currentPosition = 0;
            }

            return new CsvReader(csv, settings, currentPosition, currentRecord, fieldCount);
        }

        // 하나의 레코드를 파싱한다. 필드 목록과 갱신된 위치를 얻을 수 있으며, 파싱 중 문제가 생겼을 경우 false를
        // 반환한다. 갱신된 위치는 다음 레코드의 처음 위치를 가리킨다.
        private static bool TryParseRecord(string csv, CsvReaderSettings settings, ref List<string> fields, ref int position)
        {
            fields.Clear();

            // 필드 파싱.
            for (; ; )
            {
                string field;
                bool hasNext;
                if (!TryParseField(csv, settings, ref position, out field, out hasNext))
                {
                    return false;
                }

                fields.Add(field);

                if (hasNext == false)
                {
                    break;
                }
            }
            return true;
        }

        // 하나의 필드를 파싱한다. 갱신된 위치, 필드의 값, 레코드의 마지막 필드 여부를 얻을 수 있으며, 파싱 중 문제가
        // 생겼을 경우 false를 반환한다. 갱신된 위치는 다음 필드의 처음 위치를 가리킨다.
        private static bool TryParseField(string csv, CsvReaderSettings settings, ref int position, out string field, out bool hasNext)
        {
            char delimiter   = settings.Delimiter;
            char quoteEscape = settings.Escape;
            char quote       = settings.Quote;

            int startPosition = position;

            // 기본값을 설정해둔다.
            field   = string.Empty;
            hasNext = false;

            for (; ; )
            {
                int lastPosition = position;
                if (ParseIfLineEnd(csv, ref position))
                {
                    if (settings.TrimNotQuotedField)
                    {
                        Trim(csv, ref startPosition, ref lastPosition);
                    }

                    if (lastPosition - startPosition == 0)
                    {
                        // 현재는 이 경우 field를 null로 설정한다.
                        return true;
                    }

                    field = csv.Substring(startPosition, lastPosition - startPosition);
                    return true;
                }

                char c = csv[position];
                // 분리자일 경우.
                if (c == delimiter)
                {
                    if (settings.TrimNotQuotedField)
                    {
                        Trim(csv, ref startPosition, ref lastPosition);
                    }

                    if (lastPosition - startPosition == 0)
                    {
                        // 현재는 이 경우 field를 null로 설정한다.
                        hasNext = true;
                        position += 1;
                        return true;
                    }

                    field = csv.Substring(startPosition, lastPosition - startPosition);
                    hasNext = true;
                    position += 1;

                    return true;
                }
                // 인용 부호일 경우.
                else if (position == startPosition && c == quote)
                {
                    string quotedField;
                    if (!TryParseQuotedField(csv, quote, quoteEscape, ref position , out quotedField))
                    {
                        return false;
                    }

                    field = quotedField;

                    // 공백 문자가 아닐 때까지 position을 전진.
                    for (; ; )
                    {
                        // 인용 부호가 닫힌 후에는 행의 끝이나 분리자까지 공백 문자 이외에 다른 문자가 올 수 없다.
                        // 행의 끝.
                        if (ParseIfLineEnd(csv, ref position))
                        {
                            break;
                        }
                        // 분리자.
                        else if (csv[position] == delimiter)
                        {
                            hasNext = true;
                            position += 1;
                            break;
                        }
                        // 공백 문자 이외의 문자일 경우 오류.
                        else if (CharUnicodeInfo.GetUnicodeCategory(csv, position) != UnicodeCategory.SpaceSeparator)
                        {
#if !NO_UNITYDEBUG
							Debug.LogError("닫는 인용 부호 뒤에 다음 분리자나 행이 끝에 도달하기 전까지 공백 문자 이외의 문자가 올 수 없습니다."); // TODO: SyntaxError로 변경.
#endif
                            return false;
                        }

                        position += 1;
                    }

                    return true;
                }

                // 다음 문자로 이동.
                position += 1;
            }
        }

        // 인용부호로 시작하는 위치로부터 인용부호가 끝나는 위치까지 문자열을 파싱하여 인용부호를 제외한 결과를 얻을 수
        // 있다. 성공적으로 종료되었을 때 position은 마지막 인용부호 다음 위치. 문제가 있다면 false를 반환한다.
        private static bool TryParseQuotedField(string csv, char quote, char quoteEscape, ref int position, out string quotedField)
        {
            quotedField = null;

            int eof = csv.Length - 1;
            int openQoutePos  = position;
            int closeQuotePos = position;
            for (; ; )
            {
                if (position == eof)
                {
#if !NO_UNITYDEBUG
					Debug.LogError("닫히지 않은 필드입니다."); // TODO: SyntaxError로 변경.
#endif
                    return false;
                }

                closeQuotePos = csv.IndexOf(quote, closeQuotePos + 1);

                // 문자열의 끝에 도달했다면 인용 부호의 쌍이 맞지 않는 경우.
                if (closeQuotePos == -1)
                {
#if !NO_UNITYDEBUG
                    Debug.LogError("닫히지 않은 필드입니다."); // TODO: SyntaxError로 변경.
#endif
                    return false;
                }

                // 인용 부호 내부의 인용 부호일 경우.
                // 인용 부호와 이스케이프 문자가 동일한 경우 다음 문자를 확인하고 그렇지 않다면 이전 문자를 확인한다.
                if (quote == quoteEscape)
                {
                    // 문자열의 끝이거나 다음 문자가 인용 부호가 아니라면 루프 종료.
                    if (closeQuotePos == eof)
                    {
                        break;
                    }
                    // 다음 문자가 인용 부호라면 위치를 갱신하고 루프.
                    else if (csv[closeQuotePos + 1] == quote)
                    {
                        closeQuotePos += 1;
                        continue;
                    }
                }
                // 이스케이프 문자가 인용 부호와 같지 않은데 닫는 위치가 여는 위치 바로 다음이면 빈 문자열.
                else if (closeQuotePos == openQoutePos + 1)
                {
                    quotedField = string.Empty;
                    position    = closeQuotePos + 1;
                    return true;
                }
                else if (csv[closeQuotePos - 1] == quoteEscape)
                {
                    continue;
                }

                break;
            }

            // 인용 부호로 둘러쌓인 필드는 인용 부호 내부가 필드 값이 되고 인용 부호 바깥의 공백은 무시된다.
            int currentPos = openQoutePos + 1;

            // 인용 부호 내부의 인용 부호를 치환한다.
            StringBuilder quotedText = new StringBuilder(closeQuotePos - currentPos);
            while (currentPos < closeQuotePos)
            {
                // 인용 부호의 내부 영역만을 사용하기 때문에 인용 부호와 이스케이프 문자가 동일한 경우를
                // 처리하지 않아도 된다.
                if (csv[currentPos] == quoteEscape)
                {
                    quotedText.Append(quote);
                    currentPos += 2;
                }
                else
                {
                    quotedText.Append(csv[currentPos]);
                    currentPos += 1;
                }
            }

            quotedField = quotedText.ToString();
            position    = closeQuotePos + 1;
            return true;
        }

        // 행이 종료되는 위치라면 그에 맞는 처리를 하고 position의 위치를 갱신한다. 그렇지 않다면 아무것도 하지 않는다.
        // 행이 종료되는 경우는 position이 문자열 길이를 넘었을 경우, position의 위치가 LF, CR, CRLF 인 경우 네가지이다.
        // 개행 문자로 행이 종료될 경우는 position은 개행 문자 바로 다음 위치로 이동한다. 문자열 내부의 개행 문자 종류가
        // 일관성이 없거나 지원하는 개행 문자가 아닐 경우인 상황은 무시된다.
        private static bool ParseIfLineEnd(string csv, ref int position)
        {
            // position이 문자열 길이를 넘음.
            if (position >= csv.Length)
            {
                return true;
            }

            char c = csv[position];

            // LF.
            if (c == '\u000A')
            {
                position += 1;
                return true;
            }
            // CR.
            else if (c == '\u000D')
            {
                position += 1;
                // CR-LF.
                if ((position < csv.Length) && (csv[position] == '\u000A'))
                {
                    position += 1;
                }
                return true;
            }
            return false;
        }

        // str의 [startPos, endPos)의 선행 공백과 후행 공백을 제외한 값으로 startPos, endPos를 수정한다.
        private static void Trim(string str, ref int startPos, ref int endPos)
        {
            while ((startPos < endPos) && char.IsWhiteSpace(str, startPos))
            {
                startPos += 1;
            }

            while ((startPos < endPos) && char.IsWhiteSpace(str, endPos - 1))
            {
                endPos -= 1;
            }
        }
    }
}
