﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Pie
{
    public static partial class Functional
    {
        public static Chaining<T> Chain<T>(IEnumerable<T> source)
        {
            return new Chaining<T>(source);
        }

        public static Chaining<T> Empty<T>()
        {
            return new Chaining<T>(EmptyOf<T>.Instance);
        }

        public static Chaining<T> Construct<T>(params T[] values)
        {
            return Empty<T>().Push(values);
        }

        public static Chaining<T> Construct<T>(T value)
        {
            return Empty<T>().Push(value);
        }

        /// <summary>
        /// 0부터 end - 1까지의 범위를 가지는 정수 시퀀스를 생성한다.
        /// </summary>
        /// <param name="end">시퀀스의 종료 값. 이 값은 시퀀스에 포함되지 않는다.</param>
        public static Chaining<int> Range(int end)
        {
            return new Chaining<int>(EnumerableRange(0, end, 1));
        }

        /// <summary>
        /// begin부터 end - 1까지의 범위를 가지는 정수 시퀀스를 생성한다.
        /// </summary>
        /// <param name="begin">시퀀스의 시작 값.</param>
        /// <param name="end">시퀀스의 종료 값. 이 값은 시퀀스에 포함되지 않는다.</param>
        public static Chaining<int> Range(int begin, int end)
        {
            return new Chaining<int>(EnumerableRange(begin, end, 1));
        }

        /// <summary>
        /// begin부터 시작하여 step만큼 변화하는 정수 시퀀스를 생성한다. step이 양수라면 end보다 작은 begin + (i * step)이
        /// 마지막 원소가 되고 step이 음수라면 end보다 큰 begin + (i * step)이 마지막 수가 된다.
        /// </summary>
        /// <param name="begin">시퀀스의 시작 값.</param>
        /// <param name="end">시퀀스의 종료 값. 이 값은 시퀀스에 포함되지 않는다.</param>
        /// <param name="step">시퀀스의 변화 값.</param>
        public static Chaining<int> Range(int begin, int end, int step)
        {
            return new Chaining<int>(EnumerableRange(begin, end, step));
        }

        public static Chaining<T> Repeat<T>(int count, T value)
        {
            return new Chaining<T>(EnumerableRepeat<T>(count, value));
        }

        private static class EmptyOf<T>
        {
            static EmptyOf()
            {
                Instance = new T[0];
            }

            public static T[] Instance
            {
                get;
                private set;
            }
        }

        private static IEnumerable<int> EnumerableRange(int begin, int end, int step)
        {
            int count = Math.Abs((end - begin) / step);
            for (var i = 0; i < count; i += 1)
            {
                yield return begin + (step * i);
            }
        }

        private static IEnumerable<T> EnumerableRepeat<T>(int count, T value)
        {
            for (var i = 0; i < count; i += 1)
            {
                yield return value;
            }
        }
    }
}
