﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Pie
{
    public struct Chaining<T> : IEnumerable<T>
    {
        public Chaining(IEnumerable<T> source)
        {
            if (source == null) throw new ArgumentNullException("source");

            _source = source;
        }

        #region Implementation of IEnumerator<T>
        public IEnumerator<T> GetEnumerator()
        {
            return _source.GetEnumerator();
        }
        #endregion

        #region Implementation of IEnumerator
        IEnumerator IEnumerable.GetEnumerator()
        {
            return _source.GetEnumerator();
        }
        #endregion

        public Chaining<TResult> Map<TResult>(Func<T, int, TResult> mapper)
        {
            return new Chaining<TResult>(Functional.Map(_source, mapper));
        }

        public Chaining<TResult> Map<TResult>(Func<T, TResult> mapper)
        {
            return new Chaining<TResult>(Functional.Map(_source, mapper));
        }

        public Chaining<TResult> FlatMap<TResult>(Func<T, int, IEnumerable<TResult>> mapper)
        {
            return new Chaining<TResult>(Functional.FlatMap(_source, mapper));
        }

        public Chaining<TResult> FlatMap<TResult>(Func<T, IEnumerable<TResult>> mapper)
        {
            return new Chaining<TResult>(Functional.FlatMap(_source, mapper));
        }

        // public Chaining<TResult> FlatMap<TCollection, TResult>(Func<T, int, IEnumerable<TCollection>> collectionMapper, IEnumerable<T, TCollection> resultMapper)

        // public Chaining<TResult> FlatMap<TCollection, TResult>(Func<T, IEnumerable<TCollection>> collectionMapper, IEnumerable<T, TCollection> resultMapper)

        public Chaining<T> Filter(Func<T, int, bool> predicate)
        {
            return new Chaining<T>(Functional.Filter(_source, predicate));
        }

        public Chaining<T> Filter(Func<T, bool> predicate)
        {
            return new Chaining<T>(Functional.Filter(_source, predicate));
        }

        public Chaining<T> Reject(Func<T, int, bool> predicate)
        {
            return new Chaining<T>(Functional.Reject(_source, predicate));
        }

        public Chaining<T> Reject(Func<T, bool> predicate)
        {
            return new Chaining<T>(Functional.Reject(_source, predicate));
        }

        public Chaining<T> Take(int n)
        {
            return new Chaining<T>(Functional.Take(_source, n));
        }

        public T First(Func<T, bool> predicate)
        {
            return Functional.First(_source, predicate);
        }

        public T First()
        {
            return Functional.First(_source);
        }

        public T FirstOrDefault(Func<T, bool> predicate, T defaultValue = default(T))
        {
            return Functional.FirstOrDefault(_source, predicate, defaultValue);
        }

        public T FirstOrDefault(T defaultValue = default(T))
        {
            return Functional.FirstOrDefault(_source, defaultValue);
        }

        // public Chaining<T> Initial()

        public Chaining<T> Skip(int n)
        {
            return new Chaining<T>(Functional.Skip(_source, n));
        }

        // public T Last(Func<T, bool> predicate)

        // public T Last()

        // public T LastOrDefault(Func<T, bool> predicate)

        // public T LastOrDefault()

        public Chaining<T> Rest()
        {
            return new Chaining<T>(Functional.Rest(_source));
        }

        public Chaining<T> Concat(IEnumerable<T> other)
        {
            return new Chaining<T>(Functional.Concat(_source, other));
        }

        public Chaining<T> Push(params T[] values)
        {
            return new Chaining<T>(Functional.Push(_source, values));
        }

        public Chaining<T> Push(T value)
        {
            return new Chaining<T>(Functional.Push(_source, value));
        }

        // public TResult Collect<TResult>(ICollector<TResult> collector)

        public TResult Reduce<TResult>(TResult seed, Func<TResult, T, TResult> accumulator)
        {
            return Functional.Reduce(_source, seed, accumulator);
        }

        public T Reduce(Func<T, T, T> accumulator)
        {
            return Functional.Reduce(_source, accumulator);
        }

        public bool All(Func<T, bool> predicate)
        {
            return Functional.All(_source, predicate);
        }

        public bool Any(Func<T, bool> predicate)
        {
            return Functional.Any(_source, predicate);
        }

        public bool Any()
        {
            return Functional.Any(_source);
        }

        public bool None(Func<T, bool> predicate)
        {
            return Functional.None(_source, predicate);
        }

        public bool None()
        {
            return Functional.None(_source);
        }

        public int Count()
        {
            return Functional.Count(_source);
        }

        public int Count(Func<T, bool> predicate)
        {
            return Functional.Count(_source, predicate);
        }

        public void Each(Action<T, int> action)
        {
            Functional.Each(_source, action);
        }

        public void Each(Action<T> action)
        {
            Functional.Each(_source, action);
        }

        public T[] ToArray()
        {
            return Functional.ToArray(_source);
        }

        public TResult[] ToArray<TResult>(Func<T, TResult> mapper)
        {
            return Functional.ToArray(_source, mapper);
        }

        public List<T> ToList()
        {
            return Functional.ToList(_source);
        }

        public List<TResult> ToList<TResult>(Func<T, TResult> mapper)
        {
            return Functional.ToList(_source, mapper);
        }

        public HashSet<T> ToSet()
        {
            return Functional.ToSet(_source);
        }

        public HashSet<TResult> ToSet<TResult>(IEnumerable<T> source, Func<T, TResult> mapper)
        {
            return Functional.ToSet(_source, mapper);
        }

        public Dictionary<TKey, T> ToDictionary<TKey>(
                Func<T, TKey> keyMapper,
                IEqualityComparer<TKey> comparer = null)
        {
            return Functional.ToDictionary(_source, keyMapper, comparer);
        }

        public Dictionary<TKey, TValue> ToDictionary<TKey, TValue>(
                Func<T, TKey> keyMapper,
                Func<T, TValue> valueMapper,
                IEqualityComparer<TKey> comparer = null)
        {
            return Functional.ToDictionary(_source, keyMapper, valueMapper, comparer);
        }

        public string Join(string delimiter = null)
        {
            return Functional.Join(_source, delimiter);
        }

        public string Join(string delimiter, string prefix, string suffix)
        {
            return Functional.Join(_source, delimiter, prefix, suffix);
        }

        private readonly IEnumerable<T> _source;
    }
}
