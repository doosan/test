﻿using System;
using System.Collections.Generic;

namespace Pie.Json
{
    public abstract partial class JsonValue
    {
        public static JsonValue DeepCopy(JsonValue value, Func<string, JsonValue, JsonValue> receiver = null)
        {
            var stack = new List<JsonValue>();
            var clonedStack = new List<JsonValue>();
            var depth = 0;

            Func<JsonValue, Func<JsonValue>, JsonValue> pushIfNotCircular = (currentValue, newValue) =>
            {
                if (stack.Contains(currentValue))
                {
                    return null;
                }
                stack.Add(currentValue);
                clonedStack.Add(newValue());
                depth += 1;
                return clonedStack[depth - 1];
            };
            Action pop = () =>
            {
                depth -= 1;
                clonedStack.RemoveAt(depth);
                stack.RemoveAt(depth);
            };
            Func<JsonValue, JsonValue> getCopied = currentValue => clonedStack[stack.IndexOf(currentValue)];

            Func<JsonValue, JsonValue> deepCopy = null;
            deepCopy = (currentValue) =>
            {
                switch (GetTypeOf(currentValue))
                {
                case JsonValueType.Object:
                    JsonValue newObj = pushIfNotCircular(currentValue, () => new JsonObject(currentValue.Length));
                    if (newObj == null)
                    {
                        return getCopied(currentValue);
                    }

                    foreach (var pair in currentValue as IEnumerable<KeyValuePair<string, JsonValue>>)
                    {
                        JsonValue copiedValue = deepCopy(pair.Value);
                        copiedValue = receiver != null ? receiver(pair.Key, copiedValue) : copiedValue;

                        JsonValueType copiedType = GetTypeOf(copiedValue);
                        if (copiedType == JsonValueType.Undefined ||
                            copiedType == JsonValueType.Null)
                        {
                            continue;
                        }

                        newObj.Add(pair.Key, copiedValue);
                    }

                    pop();
                    return newObj;

                case JsonValueType.Array:
                    JsonValue newArray = pushIfNotCircular(currentValue, () => new JsonArray(currentValue.Length));
                    if (newArray == null)
                    {
                        return getCopied(currentValue);
                    }

                    for (int i = 0; i < currentValue.Length; ++i)
                    {
                        JsonValue copiedValue = deepCopy(currentValue[i]);
                        newArray.Add(receiver != null ? receiver(i.ToString(), copiedValue) : copiedValue);
                    }

                    pop();
                    return newArray;

                case JsonValueType.Undefined:
                case JsonValueType.String:
                case JsonValueType.Number:
                case JsonValueType.Boolean:
                case JsonValueType.Null:
                default:
                    return currentValue;
                }
            };

            JsonValue result = deepCopy(value);
            return receiver != null ? receiver(string.Empty, result) : result;
        }

        public static JsonValueType GetTypeOf(JsonValue value)
        {
            return (value == null) ? JsonValueType.Null : value.ValueType;
        }

        public static bool IsTypeOf(JsonValue value, JsonValueType valueType)
        {
            return GetTypeOf(value) == valueType;
        }

        public static bool IsUndefined(JsonValue value)
        {
            return IsTypeOf(value, JsonValueType.Undefined);
        }

        public static bool IsObject(JsonValue value)
        {
            return IsTypeOf(value, JsonValueType.Object);
        }

        public static bool IsArray(JsonValue value)
        {
            return IsTypeOf(value, JsonValueType.Array);
        }

        public static bool IsString(JsonValue value)
        {
            return IsTypeOf(value, JsonValueType.String);
        }

        public static bool IsNumber(JsonValue value)
        {
            return IsTypeOf(value, JsonValueType.Number);
        }

        public static bool IsBoolean(JsonValue value)
        {
            return IsTypeOf(value, JsonValueType.Boolean);
        }

        public static bool IsNull(JsonValue value)
        {
            return IsTypeOf(value, JsonValueType.Null);
        }

        public static bool Equals(JsonValue a, JsonValue b)
        {
            if (GetTypeOf(a) != GetTypeOf(b))
            {
                return false;
            }

            switch (a.ValueType)
            {
            case JsonValueType.Array:
                if (a.Length != b.Length)
                {
                    return false;
                }

                for (int i = 0; i < a.Length; ++i)
                {
                    if (!Equals(a[i], b[i]))
                    {
                        return false;
                    }
                }
                return true;

            case JsonValueType.Object:
                if (a.Length != b.Length)
                {
                    return false;
                }

                var keys = (a as JsonObject).Keys.GetEnumerator();
                while (keys.MoveNext())
                {
                    var key = keys.Current;
                    if (!b.HasProperty(key) || !Equals(a[key], b[key]))
                    {
                        return false;
                    }
                }
                return true;

            default:
                return a.Equals(b);
            }
        }

        #region Constants
        private static readonly JsonValue Undefined = new JsonUndefined();
        private static readonly JsonValue True = new JsonTrue();
        private static readonly JsonValue False = new JsonFalse();
        #endregion
    }
}
