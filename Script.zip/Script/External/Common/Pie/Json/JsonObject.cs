﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Pie.Json
{
    public sealed class JsonObject : JsonValue, IEnumerable<KeyValuePair<string, JsonValue>>
    {
        #region Constructors
        public JsonObject()
        {
            _dict = new Dictionary<string, JsonValue>();
        }

        public JsonObject(int capacity)
        {
            _dict = new Dictionary<string, JsonValue>(capacity);
        }

        public JsonObject(IEnumerable<KeyValuePair<string, JsonValue>> source)
        {
            if (source == null)
            {
                throw new ArgumentNullException("source");
            }

            var coll = source as ICollection;
            if (coll != null)
            {
                _dict = new Dictionary<string, JsonValue>(coll.Count);
            }
            else
            {
                _dict = new Dictionary<string, JsonValue>();
            }

            foreach (var pair in source)
            {
                Add(pair.Key, pair.Value);
            }
        }
        #endregion

        #region Implementation of IEnumerable<KeyValuePair<string, JsonValue>>
        public Dictionary<string, JsonValue>.Enumerator GetEnumerator()
        {
            return _dict.GetEnumerator();
        }

        IEnumerator<KeyValuePair<string, JsonValue>> IEnumerable<KeyValuePair<string, JsonValue>>.GetEnumerator()
        {
            return _dict.GetEnumerator();
        }
        #endregion

        #region Implementation of IEnumerable
        IEnumerator IEnumerable.GetEnumerator()
        {
            return _dict.GetEnumerator();
        }
        #endregion

        #region Override from JsonValue
        public override bool HasProperty(string propertyName)
        {
            if (propertyName == null)
            {
                return false;
            }
            return _dict.ContainsKey(propertyName);
        }

        public override void Add(string propertyName, JsonValue value)
        {
            _dict[propertyName] = value;
        }

        public override void Remove(string propertyName)
        {
            _dict.Remove(propertyName);
        }

        public override JsonValue this[string propertyName]
        {
            get
            {
                JsonValue result;
                if (_dict.TryGetValue(propertyName, out result))
                {
                    return result;
                }
                return base[propertyName];
            }
            set { Add(propertyName, value); }
        }

        public override JsonValueType ValueType
        {
            get { return JsonValueType.Object; }
        }

        public override JsonObject AsObject
        {
            get { return this; }
        }

        public override string AsString
        {
            get { return "[JsonObject]"; }
        }

        public override bool AsBoolean
        {
            get { return true; }
        }

        public override int Length
        {
            get { return _dict.Count; }
        }
        #endregion

        #region Properties
        public Dictionary<string, JsonValue>.KeyCollection Keys
        {
            get { return _dict.Keys; }
        }

        public Dictionary<string, JsonValue>.ValueCollection Values
        {
            get { return _dict.Values; }
        }
        #endregion

        private readonly Dictionary<string, JsonValue> _dict;
    }
}
