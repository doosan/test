﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Pie.Json
{
    public sealed class JsonArray : JsonValue, IEnumerable<JsonValue>
    {
        #region Constructors
        public JsonArray()
        {
            _list = new List<JsonValue>();
        }

        public JsonArray(int capacity)
        {
            _list = new List<JsonValue>(capacity);
        }

        public JsonArray(IEnumerable<JsonValue> source)
        {
            if (source == null)
            {
                throw new ArgumentNullException("source");
            }
            _list = new List<JsonValue>(source);
        }
        #endregion

        #region Implementation of IEnumerable<JsonValue>
        public List<JsonValue>.Enumerator GetEnumerator()
        {
            return _list.GetEnumerator();
        }

        IEnumerator<JsonValue> IEnumerable<JsonValue>.GetEnumerator()
        {
            return _list.GetEnumerator();
        }
        #endregion

        #region Implementation of IEnumerable
        IEnumerator IEnumerable.GetEnumerator()
        {
            return _list.GetEnumerator();
        }
        #endregion

        #region Override from JsonValue
        public override void Add(JsonValue value)
        {
            _list.Add(value);
        }

        public override void Remove(int index)
        {
            if (index < 0 || index >= _list.Count)
            {
                return;
            }
            _list.RemoveAt(index);
        }

        public override JsonValue this[int index]
        {
            get
            {
                if (index < 0 || index >= _list.Count)
                {
                    return base[index];
                }
                return _list[index];
            }
            set
            {
                if (index < 0)
                {
                    return;
                }

                if (index >= _list.Count)
                {
                    _list.Capacity = index + 1;
                    for (int i = _list.Count; i < index + 1; ++i)
                    {
                        _list.Add(null);
                    }
                }
                _list[index] = value;
            }
        }

        public override JsonValueType ValueType
        {
            get { return JsonValueType.Array; }
        }

        public override JsonArray AsArray
        {
            get { return this; }
        }

        public override string AsString
        {
            get { return "[JsonArray]"; }
        }

        public override bool AsBoolean
        {
            get { return true; }
        }

        public override int Length
        {
            get { return _list.Count; }
        }
        #endregion

        private readonly List<JsonValue> _list;
    }
}
