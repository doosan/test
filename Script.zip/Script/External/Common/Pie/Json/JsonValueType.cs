﻿namespace Pie.Json
{
    public enum JsonValueType
    {
        Undefined,
        Object,
        Array,
        String,
        Number,
        Boolean,
        Null
    }
}
