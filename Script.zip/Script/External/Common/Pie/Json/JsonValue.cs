﻿using System;

namespace Pie.Json
{
    public abstract partial class JsonValue
    {
        #region Override from object
        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override string ToString()
        {
            return AsString;
        }
        #endregion

        #region Operator Overloading
        public static bool operator ==(JsonValue a, JsonValue b)
        {
            if (ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || (object)b == null)
            {
                return false;
            }

            return a.Equals(b);
        }

        public static bool operator !=(JsonValue a, JsonValue b)
        {
            return !(a == b);
        }

        public static bool operator ==(JsonValue a, string b)
        {
            if (ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || (object)b == null)
            {
                return false;
            }

            return a.Equals(b);
        }

        public static bool operator !=(JsonValue a, string b)
        {
            return !(a == b);
        }

        public static bool operator ==(string a, JsonValue b)
        {
            return b == a;
        }

        public static bool operator !=(string a, JsonValue b)
        {
            return b != a;
        }

        public static bool operator ==(JsonValue a, double b)
        {
            if ((object)a == null)
            {
                return false;
            }

            return a.Equals(b);
        }

        public static bool operator !=(JsonValue a, double b)
        {
            return !(a == b);
        }

        public static bool operator ==(double a, JsonValue b)
        {
            return b == a;
        }

        public static bool operator !=(double a, JsonValue b)
        {
            return b != a;
        }
        #endregion

        #region Object Interface
        public virtual bool HasProperty(string propertyName)
        {
            return false;
        }

        public bool HasProperty(string propertyName, JsonValueType type)
        {
            return HasProperty(propertyName) && this[propertyName].ValueType == type;
        }

        public virtual void Add(string propertyName, JsonValue value)
        {
            throw new NotSupportedException();
        }

        public virtual void Remove(string propertyName)
        {
            throw new NotSupportedException();
        }

        public virtual JsonValue this[string propertyName]
        {
            get { return Undefined; }
            set { throw new NullReferenceException(); }
        }
        #endregion

        #region Array Interface
        public virtual void Add(JsonValue value)
        {
            throw new NotSupportedException();
        }

        public virtual void Remove(int index)
        {
            throw new NotSupportedException();
        }

        public virtual JsonValue this[int index]
        {
            get { return Undefined; }
            set { throw new NullReferenceException(); }
        }
        #endregion

        #region Type Casting
        public static implicit operator JsonValue(string value)
        {
            return new JsonString(value);
        }

        public static implicit operator JsonValue(double value)
        {
            return new JsonNumber(value);
        }

        public static implicit operator JsonValue(bool value)
        {
            return value ? True : False;
        }

        public virtual JsonObject AsObject
        {
            get { return null; }
        }

        public virtual JsonArray AsArray
        {
            get { return null; }
        }

        public abstract string AsString
        {
            get;
        }

        public virtual double AsNumber
        {
            get { return double.NaN; }
        }

        public virtual bool AsBoolean
        {
            get { return false; }
        }
        #endregion

        public bool Equals(string value)
        {
            if (ValueType != JsonValueType.String)
            {
                return false;
            }

            return AsString == value;
        }

        public bool Equals(double value)
        {
            if (ValueType != JsonValueType.Number)
            {
                return false;
            }

            return AsNumber == value;
        }

        public abstract JsonValueType ValueType
        {
            get;
        }

        public virtual int Length
        {
            get { return 0; }
        }
    }
}
