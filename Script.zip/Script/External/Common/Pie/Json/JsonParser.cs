﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pie.Json
{
    public struct JsonParserSettings
    {
        public bool AllowComment;
        public bool AllowTrailingComma;
    }

    public sealed class JsonParser
    {
        public JsonParser()
        {
        }

        public JsonParser(JsonParserSettings settings)
        {
            _settings = settings;
        }

        /// <summary>
        /// JSON 문자열로부터 JsonValue 인스턴스를 생성한다.
        /// </summary>
        /// <seealso cref="JsonBuilder.Stringify"/>
        /// <param name="text">JSON 문자열.</param>
        /// <returns>빈 문자열이거나 공백 문자만 포함하고 있다면 <c>null</c>, 그렇지 않다면 JsonValue 인스턴스를 반환한다.</returns>
        /// <exception cref="ArgumentNullException"><c>text</c>가 <c>null</c>값일 경우.</exception>
        /// <exception cref="SyntaxErrorException">주어진 문자열에 문법적인 오류가 있을 경우.</exception>
        public JsonValue Parse(string text, Func<string, JsonValue, JsonValue> receiver = null)
        {
            if (text == null)
            {
                throw new ArgumentNullException("text");
            }

            try
            {
                _text = text;
                _at = 0;
                _lineNumber = 1;
                _columnNumber = 1;

                RemoveWhitespace();
                if (EOF)
                {
                    return null;
                }

                JsonValue result = Build(receiver);
                if (!EOF)
                {
                    RemoveWhitespace();
                }

                if (!EOF) throw new SyntaxErrorException("유효한 JSON 형식이 아닙니다.", _text, _lineNumber, _columnNumber);

                return result;
            }
            finally
            {
                _text = null;
            }
        }

        private void MoveNext()
        {
            _at += 1;
            _columnNumber += 1;
        }

        private void MoveNextLine()
        {
            char c = _text[_at];

            // LF
            if (c == '\u000A')
            {
                MoveNext();

                _lineNumber += 1;
                _columnNumber = 1;
            }
            // CR
            else if (c == '\u000D')
            {
                MoveNext();

                // CRLF
                if (_at < _text.Length && _text[_at] == '\u000A')
                {
                    MoveNext();
                }

                _lineNumber += 1;
                _columnNumber = 1;
            }
            else
            {
                throw new InvalidOperationException("_at이 가리키는 _text의 값이 CR 혹은 LF인 위치에서 호출해야 합니다.");
            }
        }

        private void RemoveComment()
        {
            if (EOF || !_settings.AllowComment)
            {
                return;
            }

            if (_text[_at] != '/') throw new InvalidOperationException("_at이 가리키는 _text의 값이 '/'인 위치에서 호출해야 합니다.");

            int commentStartCol = _columnNumber;
            int commentStartLine = _lineNumber;

            SyntaxErrorIfFailMoveNext();

            char c = _text[_at];
            if (c == '/')
            {
                int lineEndPos = _text.IndexOfAny(new[] { '\u000A', '\u000D' }, _at);
                if (lineEndPos == -1)
                {
                    _at = _text.Length;
                    _columnNumber += commentStartCol - _at;
                }
                else
                {
                    _at = lineEndPos;

                    MoveNextLine();
                }

                return;
            }
            else if (c == '*')
            {
                SyntaxErrorIfFailMoveNext();

                for (; ; )
                {
                    int startPos = _at;
                    int pos = _text.IndexOfAny(new[] { '\u000A', '\u000D', '*' }, _at);
                    SyntaxErrorIf(pos == -1, "유효한 주석 형식이 아닙니다.", commentStartCol, commentStartLine);

                    _at = pos;

                    switch (_text[_at])
                    {
                    case '\u000A':
                    case '\u000D':
                        MoveNextLine();
                        break;

                    case '*':
                        _columnNumber += pos - startPos;

                        SyntaxErrorIfFailMoveNext();

                        if (_text[_at] == '/')
                        {
                            MoveNext();
                            return;
                        }
                        break;
                    }
                }
            }
            else
            {
                SyntaxErrorIf(EOF, "유효한 주석 형식이 아닙니다.", commentStartCol, commentStartLine);
            }
        }

        private void RemoveWhitespace()
        {
            while (!EOF)
            {
                while (_text[_at] == '/')
                {
                    RemoveComment();
                    if (EOF)
                    {
                        return;
                    }
                }

                char c = _text[_at];
                if (c == '\u0009' || c == '\u0020')
                {
                    MoveNext();
                }
                else if (c == '\u000A' || c == '\u000D')
                {
                    MoveNextLine();
                }
                else
                {
                    return;
                }
            }
        }

        private JsonObject BuildObject(Func<string, JsonValue, JsonValue> receiver)
        {
            var hasNext = false;

            MoveNext();
            SyntaxErrorIfFailRemoveWhitespace();

            var members = new List<KeyValuePair<string, JsonValue>>();
            var lastSeparatorCol = 0;
            var lastSeparatorLine = 0;

            for (; ; )
            {
                if (_text[_at] == '}')
                {
                    if (!_settings.AllowTrailingComma)
                    {
                        SyntaxErrorIf(hasNext, "마지막 멤버 뒤에 구분자를 기술해서는 안 됩니다.", lastSeparatorCol, lastSeparatorLine);
                    }
                    MoveNext();

                    return new JsonObject(members);
                }
                else
                {
                    SyntaxErrorIf(_text[_at] != '\"', "유효한 객체 형식이 아닙니다.");

                    string key = BuildString();

                    SyntaxErrorIfFailRemoveWhitespace();
                    SyntaxErrorIfNot(":");
                    SyntaxErrorIfFailRemoveWhitespace();

                    JsonValue value = Build(receiver);
                    value = receiver != null ? receiver(key, value) : value;

                    JsonValueType copiedType = JsonValue.GetTypeOf(value);
                    if (copiedType != JsonValueType.Undefined &&
                        copiedType != JsonValueType.Null)
                    {
                        members.Add(Functional.Pair(key, value));
                    }

                    SyntaxErrorIfFailRemoveWhitespace();

                    hasNext = _text[_at] == ',';
                    if (hasNext)
                    {
                        lastSeparatorCol = _columnNumber;
                        lastSeparatorLine = _lineNumber;

                        MoveNext();
                        SyntaxErrorIfFailRemoveWhitespace();
                    }
                    else
                    {
                        SyntaxErrorIf(_text[_at] != '}', "유효한 JSON 형식이 아닙니다.");
                    }
                }
            }
        }

        private JsonArray BuildArray(Func<string, JsonValue, JsonValue> receiver)
        {
            var hasNext = false;

            MoveNext();
            SyntaxErrorIfFailRemoveWhitespace();

            int index = 0;
            var elements = new List<JsonValue>();
            var lastSeparatorPos = 0;

            for (; ; )
            {
                if (_text[_at] == ']')
                {
                    if (!_settings.AllowTrailingComma)
                    {
                        SyntaxErrorIf(hasNext, "마지막 요소 뒤에 구분자를 기술해서는 안 됩니다.", lastSeparatorPos);
                    }
                    MoveNext();

                    return new JsonArray(elements);
                }
                else
                {
                    JsonValue value = Build(receiver);

                    elements.Add(receiver != null ? receiver(index.ToString(), value) : value);
                    SyntaxErrorIfFailRemoveWhitespace();

                    hasNext = _text[_at] == ',';
                    if (hasNext)
                    {
                        index += 1;
                        lastSeparatorPos = _columnNumber;

                        MoveNext();
                        SyntaxErrorIfFailRemoveWhitespace();
                    }
                    else
                    {
                        SyntaxErrorIf(_text[_at] != ']', "유효한 JSON 형식이 아닙니다.");
                    }
                }
            }
        }

        private string BuildString()
        {
            _strBuilder.Length = 0;

            if (_text[_at] != '"') throw new InvalidOperationException("현재 문자가 '\"'인 상태에서 호출되어야 합니다.");

            var escaped = false;
            for (; ; )
            {
                SyntaxErrorIfFailMoveNext();
                SyntaxErrorIfFail(_text[_at] > '\u001F', "유효한 문자가 아닙니다.");

                if (escaped)
                {
                    switch (_text[_at])
                    {
                        case '"': _strBuilder.Append('"'); break;
                        case '\\': _strBuilder.Append('\\'); break;
                        case '/': _strBuilder.Append('/'); break;
                        case 'b': _strBuilder.Append('\b'); break;
                        case 'f': _strBuilder.Append('\f'); break;
                        case 'n': _strBuilder.Append('\n'); break;
                        case 'r': _strBuilder.Append('\r'); break;
                        case 't': _strBuilder.Append('\t'); break;

                        case 'u':
                            int unicodeStartPos = _columnNumber - 1;
                            var c = '\0';
                            for (var i = 0; i < 4; ++i)
                            {
                                SyntaxErrorIfFailMoveNext();
                                SyntaxErrorIfFail(Utils.IsHexDigit(_text[_at]), "유니코드 문자 표시에는 16진수 형식만 쓸 수 있습니다.");
                                c = (char)((Utils.HexToByte(_text[_at]) << (3 - i) * 4) | c);
                            }

                            SyntaxErrorIfFail(c > '\u001F', "유효한 유니코드 문자가 아닙니다.", unicodeStartPos);
                            _strBuilder.Append(c);
                            break;

                        default:
                            throw new SyntaxErrorException("유효한 이스케이프 문자가 아닙니다.", _text, _lineNumber, _columnNumber);
                    }
                    escaped = false;
                }
                else if (_text[_at] == '\\')
                {
                    escaped = true;
                }
                else if (_text[_at] == '\"')
                {
                    MoveNext();
                    return _strBuilder.ToString();
                }
                else
                {
                    _strBuilder.Append(_text[_at]);
                }
            }
        }

        private double BuildNumber()
        {
            int numStartPos = _at;
            double num;

            _strBuilder.Length = 0;

            if (_text[_at] == '-')
            {
                _strBuilder.Append(_text[_at]);
                SyntaxErrorIfFailMoveNext();
            }

            // DecimalNumber
            SyntaxErrorIfFail(Utils.IsDigit(_text[_at]), "유효한 숫자 형식이 아닙니다.");

            if (_text[_at] == '0')
            {
                _strBuilder.Append(_text[_at]);
                MoveNext();
                if (EOF || IsWhitespace || _text[_at] == '}' || _text[_at] == ']')
                {
                    return 0.0;
                }

                if (_text[_at] != ',')
                {
                    SyntaxErrorIfFail(_text[_at] == '.', "유효한 숫자 형식이 아닙니다.");
                }
            }
            else if (AppendDigits())
            {
                SyntaxErrorIfFail(double.TryParse(_strBuilder.ToString(), out num), "유효한 숫자 범위가 아닙니다.", numStartPos);
                return num;
            }

            // .Digits
            if (_text[_at] == '.')
            {
                _strBuilder.Append(_text[_at]);
                SyntaxErrorIfFailMoveNext();
                SyntaxErrorIfFail(Utils.IsDigit(_text[_at]), "유효한 숫자 형식이 아닙니다.");

                if (AppendDigits())
                {
                    SyntaxErrorIfFail(double.TryParse(_strBuilder.ToString(), out num), "유효한 숫자 범위가 아닙니다.", numStartPos);
                    return num;
                }
            }

            // ExponentPart
            if (_text[_at] == 'e' || _text[_at] == 'E')
            {
                _strBuilder.Append(_text[_at]);
                SyntaxErrorIfFailMoveNext();

                if (_text[_at] == '+' || _text[_at] == '-')
                {
                    _strBuilder.Append(_text[_at]);
                    SyntaxErrorIfFailMoveNext();
                }
                SyntaxErrorIfFail(Utils.IsDigit(_text[_at]), "유효한 숫자 형식이 아닙니다.");

                if (AppendDigits())
                {
                    SyntaxErrorIfFail(double.TryParse(_strBuilder.ToString(), out num), "유효한 숫자 범위가 아닙니다.", numStartPos);
                    return num;
                }
            }

            SyntaxErrorIfFail(double.TryParse(_strBuilder.ToString(), out num), "유효한 숫자 범위가 아닙니다.", numStartPos);
            return num;
        }

        private bool AppendDigits()
        {
            while (!(EOF || IsWhitespace) && Utils.IsDigit(_text[_at]))
            {
                _strBuilder.Append(_text[_at]);
                MoveNext();
            }
            return !(EOF || IsWhitespace || _text[_at] == '.');
        }

        private JsonValue Build(Func<string, JsonValue, JsonValue> receiver)
        {
            // text[_at]의 값이 유효한 문자여야 한다.
            switch (_text[_at])
            {
            case '{':
                return BuildObject(receiver);

            case '[':
                return BuildArray(receiver);

            case '\"':
                return BuildString();

            case 't':
                SyntaxErrorIfNot("true");
                return true;

            case 'f':
                SyntaxErrorIfNot("false");
                return false;

            case 'n':
                SyntaxErrorIfNot("null");
                return null;

            default:
                SyntaxErrorIfFail(_text[_at] == '-' || Utils.IsDigit(_text[_at]), "유효한 JSON 형식이 아닙니다.");

                return BuildNumber();
            }
        }

        private void SyntaxErrorIf(bool cond, string msg, int colNum = 0, int lineNum = 0)
        {
            if (cond)
            {
                throw new SyntaxErrorException(
                    msg,
                    _text,
                    lineNum == 0 ? _lineNumber : lineNum,
                    colNum == 0 ? _columnNumber : colNum);
            }
        }

        private void SyntaxErrorIfFail(bool cond, string msg, int colNum = 0)
        {
            SyntaxErrorIf(
                !cond,
                msg,
                colNum == 0 ? _columnNumber : colNum);
        }

        private void SyntaxErrorIfFailMoveNext()
        {
            MoveNext();
            SyntaxErrorIfFail(_at < _text.Length, "파싱이 종료되지 않았는데 문자열의 끝에 도달했습니다.");
        }

        private void SyntaxErrorIfFailRemoveWhitespace()
        {
            RemoveWhitespace();
            SyntaxErrorIf(EOF, "파싱이 종료되지 않았는데 문자열의 끝에 도달했습니다.");
        }

        private void SyntaxErrorIfNot(string expected)
        {
            for (var i = 0; i < expected.Length; ++i)
            {
                SyntaxErrorIfFail(_text[_at] == expected[i], "예상한 토큰과 일치하지 않습니다.");
                SyntaxErrorIfFailMoveNext();
            }
        }

        private bool EOF
        {
            get { return _at >= _text.Length; }
        }

        private bool IsWhitespace
        {
            get
            {
                switch (_text[_at])
                {
                case '\u0009': return true;
                case '\u000A': return true;
                case '\u000D': return true;
                case '\u0020': return true;
                }
                return false;
            }
        }

        private readonly StringBuilder _strBuilder = new StringBuilder();

        private readonly JsonParserSettings _settings;

        private string _text;
        private int _at;
        private int _lineNumber;
        private int _columnNumber;
    }
}
