﻿using System;

namespace Pie.Json
{
    /// <summary>
    /// JsonValue 인스턴스를 문자열로 변환할 때, JsonValue 인스턴스가 순환 구조를 가지고 있을 경우 발생한다.
    /// </summary>
    public sealed class CircularReferenceException : Exception
    {
        public CircularReferenceException()
        {
        }
    }
}
