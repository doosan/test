﻿using System.Collections.Generic;
using System.Text;

namespace Pie.Json
{
    // TODO: JsonBuilderSettings 작성 및 적용.
    //  ignoreCircularReference = false
    //  indent = 0
    //  indentType = {space|tab}

    public sealed class JsonBuilder
    {
        public JsonBuilder()
        {
        }

        /// <summary>
        /// JsonValue 인스턴스를 JSON 문자열로 변환한다.
        /// </summary>
        /// <seealso cref="JsonParser.Parse"/>
        /// <remarks>변환하려는 JsonValue 인스턴스는 순환 구조를 가지면 안 된다.</remarks>
        /// <param name="value">문자열로 변환할 JsonValue 인스턴스. <c>null</c>이라면 "null" 문자열을 반환한다.</param>
        /// <returns>JSON 문자열.</returns>
        /// <exception cref="CircularReferenceException">value가 순환 구조를 가지고 있을 경우 발생.</exception>
        public string Stringify(JsonValue value)
        {
            try
            {
                Build(value);

                return _builder.ToString();
            }
            catch
            {
                throw;
            }
            finally
            {
                _stack.Clear();
                _builder.Length = 0;
            }
        }

        private void Push(char openChar, JsonValue currentValue)
        {
            if (_stack.Contains(currentValue))
            {
                throw new CircularReferenceException();
            }

            _builder.Append(openChar);
            _stack.Push(currentValue);
        }

        private void Pop(char closeChar)
        {
            _stack.Pop();
            _builder.Append(closeChar);
        }

        private void Build(JsonValue currentValue)
        {
            switch (JsonValue.GetTypeOf(currentValue))
            {
                case JsonValueType.Undefined:
                    break;

                case JsonValueType.Object:
                    Push('{', currentValue);

                    Dictionary<string, JsonValue>.Enumerator enumerator = (currentValue as JsonObject).GetEnumerator();
                    if (enumerator.MoveNext())
                    {
                        for (; ; )
                        {
                            KeyValuePair<string, JsonValue> pair = enumerator.Current;
                            if (JsonValue.IsUndefined(pair.Value))
                            {
                                if (enumerator.MoveNext())
                                {
                                    continue;
                                }
                                else
                                {
                                    break;
                                }
                            }

                            _builder.Append("\"");
                            _builder.Append(pair.Key);
                            _builder.Append("\":");
                            Build(pair.Value);

                            if (!enumerator.MoveNext())
                            {
                                break;
                            }

                            _builder.Append(",");
                        }
                    }

                    Pop('}');
                    break;

                case JsonValueType.Array:
                    Push('[', currentValue);

                    if (currentValue.Length > 0)
                    {
                        int lastIndex = currentValue.Length - 1;
                        for (int i = 0; i < lastIndex; i += 1)
                        {
                            if (JsonValue.IsUndefined(currentValue[i]))
                            {
                                _builder.Append("null");
                            }
                            else
                            {
                                Build(currentValue[i]);
                            }
                            _builder.Append(",");
                        }
                        Build(currentValue[lastIndex]);
                    }

                    Pop(']');
                    break;

                case JsonValueType.Number:
                    double num = currentValue.AsNumber;
                    bool isInvalidNum = double.IsNaN(num) || double.IsInfinity(num);
                    _builder.Append(isInvalidNum ? "null" : currentValue.AsString);
                    break;

                case JsonValueType.Boolean:
                    _builder.Append(currentValue.AsString);
                    break;

                case JsonValueType.String:
                    string str = currentValue.AsString;

                    _builder.Append("\"");
                    for (var i = 0; i < str.Length; i += 1)
                    {
                        char c = str[i];
                        switch (c)
                        {
                        case '\"': _builder.Append("\\\""); break;
                        case '\\': _builder.Append("\\\\"); break;
                        case '/':  _builder.Append("\\/" ); break;
                        case '\b': _builder.Append("\\b" ); break;
                        case '\f': _builder.Append("\\f" ); break;
                        case '\n': _builder.Append("\\n" ); break;
                        case '\r': _builder.Append("\\r" ); break;
                        case '\t': _builder.Append("\\t" ); break;

                        default:
                            if (c <= '\u001F')
                            {
                                _builder.AppendFormat("\\u00{0:X2}", (int)c);
                            }
                            else
                            {
                                _builder.Append(c);
                            }
                            break;
                        }
                    }
                    _builder.Append("\"");
                    break;

                case JsonValueType.Null:
                    _builder.Append("null");
                    break;
            }
        }

        private readonly Stack<JsonValue> _stack = new Stack<JsonValue>();
        private readonly StringBuilder _builder = new StringBuilder();
    }
}
