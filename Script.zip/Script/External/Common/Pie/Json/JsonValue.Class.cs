﻿using System;

namespace Pie.Json
{
    public abstract partial class JsonValue
    {
        private sealed class JsonUndefined : JsonValue
        {
            #region Override from object
            public override bool Equals(object obj)
            {
                return obj is JsonUndefined;
            }

            public override int GetHashCode()
            {
                return 0;
            }
            #endregion

            #region Override from JsonValue
            public override JsonValue this[string propertyName]
            {
                get { throw new NullReferenceException(); }
            }

            public override JsonValue this[int index]
            {
                get { throw new NullReferenceException(); }
            }

            public override JsonValueType ValueType
            {
                get { return JsonValueType.Undefined; }
            }

            public override string AsString
            {
                get { return "undefined"; }
            }
            #endregion
        }

        private sealed class JsonString : JsonValue
        {
            public JsonString(string value)
            {
                if (value == null)
                {
                    throw new ArgumentNullException("value");
                }
                _value = value;
            }

            #region Override from object
            public override bool Equals(object obj)
            {
                var other = obj as JsonString;
                return other != null && other._value == _value;
            }

            public override int GetHashCode()
            {
                return _value.GetHashCode();
            }
            #endregion

            #region Operator Overloading
            public static bool operator ==(JsonString a, string b)
            {
                if (ReferenceEquals(a, b))
                {
                    return true;
                }

                if ((object)a == null || (object)b == null)
                {
                    return false;
                }

                return a._value == b;
            }

            public static bool operator !=(JsonString a, string b)
            {
                return !(a == b);
            }

            public static bool operator ==(string a, JsonString b)
            {
                return b == a;
            }

            public static bool operator !=(string a, JsonString b)
            {
                return b != a;
            }
            #endregion

            #region Override from JsonValue
            public override JsonValueType ValueType
            {
                get { return JsonValueType.String; }
            }

            public override string AsString
            {
                get { return _value; }
            }

            public override bool AsBoolean
            {
                get { return !string.IsNullOrEmpty(_value); }
            }

            public override int Length
            {
                get { return _value.Length; }
            }
            #endregion

            private readonly string _value;
        }

        private sealed class JsonNumber : JsonValue
        {
            public JsonNumber(double value)
            {
                _value = value;
            }

            #region Override from object
            public override bool Equals(object obj)
            {
                var other = obj as JsonNumber;
                return other != null && other._value == _value;
            }

            public override int GetHashCode()
            {
                return _value.GetHashCode();
            }
            #endregion

            #region Operator Overloading
            public static bool operator ==(JsonNumber a, double b)
            {
                if ((object)a == null)
                {
                    return false;
                }

                return a._value == b;
            }

            public static bool operator !=(JsonNumber a, double b)
            {
                return !(a == b);
            }

            public static bool operator ==(double a, JsonNumber b)
            {
                return b == a;
            }

            public static bool operator !=(double a, JsonNumber b)
            {
                return b != a;
            }
            #endregion

            #region Override from JsonValue
            public override JsonValueType ValueType
            {
                get { return JsonValueType.Number; }
            }

            public override string AsString
            {
                get { return _value.ToString(); }
            }

            public override double AsNumber
            {
                get { return _value; }
            }

            public override bool AsBoolean
            {
                get { return !double.IsNaN(_value) && _value != 0.0; }
            }
            #endregion

            private readonly double _value;
        }

        private sealed class JsonTrue : JsonValue
        {
            #region Override from object
            public override bool Equals(object obj)
            {
                return obj is JsonTrue || obj is bool && (bool)obj;
            }

            public override int GetHashCode()
            {
                return 1;
            }
            #endregion

            #region Override from JsonValue
            public override JsonValueType ValueType
            {
                get { return JsonValueType.Boolean; }
            }

            public override string AsString
            {
                get { return "true"; }
            }

            public override double AsNumber
            {
                get { return 1.0; }
            }

            public override bool AsBoolean
            {
                get { return true; }
            }
            #endregion
        }

        private sealed class JsonFalse : JsonValue
        {
            #region Override from object
            public override bool Equals(object obj)
            {
                return obj is JsonFalse || obj is bool && !(bool)obj;
            }

            public override int GetHashCode()
            {
                return 0;
            }
            #endregion

            #region Override from JsonValue
            public override JsonValueType ValueType
            {
                get { return JsonValueType.Boolean; }
            }

            public override string AsString
            {
                get { return "false"; }
            }

            public override double AsNumber
            {
                get { return 0.0; }
            }
            #endregion
        }
    }
}
