﻿using System;
using UnityEngine;

namespace Pie
{
    public interface IRange
    {
        float Begin
        {
            get;
        }

        float End
        {
            get;
        }

        float Length
        {
            get;
        }
    }

    public static class IRangeExtensionMethods
    {
        public static bool Contains(this IRange range, float value)
        {
            if (range == null) throw new ArgumentNullException("range");

            return value >= range.Begin && value <= range.End;
        }

        public static float Lerp(this IRange range, float t)
        {
            return Mathf.Lerp(range.Begin, range.End, t);
        }

        public static float LerpUnclamped(this IRange range, float t)
        {
            return Mathf.LerpUnclamped(range.Begin, range.End, t);
        }

        public static float LerpAngle(this IRange range, float t)
        {
            return Mathf.LerpAngle(range.Begin, range.End, t);
        }

        public static float GetRandomValue(this Pie.IRange range, IRandom random = null)
        {
            if (range == null) throw new ArgumentNullException("range");

            if (Mathf.Approximately(range.Length, 0.0f))
            {
                return range.Begin;
            }

            var r = random ?? UnityRandom.Instance;
            return r.NextSingle(range.Begin, range.End);
        }
    }

    [Serializable]
    public class Range : IRange
    {
        #region Inspector Fields
        [SerializeField] private float _begin = 0.0f;
        [SerializeField] private float _end = 0.0f;
        #endregion

        public Range()
        {
        }

        #region Implementation of IRange
        public float Begin
        {
            get { return _begin; }
        }

        public float End
        {
            get { return _end; }
        }

        public float Length
        {
            get { return _end - _begin; }
        }
        #endregion

        public Range(float begin, float end)
        {
            Set(begin, end);
        }

        public void Set(float begin, float end)
        {
            if (begin > end) throw new ArgumentOutOfRangeException("begin", begin, "begin은 end보다 작거나 같아야 합니다.");

            _begin = begin;
            _end = end;
        }
    }

    public class RangeSliderAttribute : PropertyAttribute
    {
        public RangeSliderAttribute(float min, float max, bool wholeNumbers = false)
        {
            if (float.IsNaN(min) || float.IsInfinity(min)) throw new ArgumentException("유효한 값이 아닙니다.", "min");
            if (float.IsNaN(max) || float.IsInfinity(max)) throw new ArgumentException("유효한 값이 아닙니다.", "max");
            if (min > max) throw new ArgumentOutOfRangeException("min", min, "min은 end보다 작거나 같아야 합니다.");

            Min = min;
            Max = max;
            WholeNumbers = wholeNumbers;
        }

        public readonly float Min;
        public readonly float Max;
        public readonly bool WholeNumbers;
    }
}
