﻿using System;
using System.Collections.Generic;
using UnityEngine;
using Pie.Collections;

namespace Pie
{
    public interface IFsmState<TState, TTransitionEvent>
            where TState : struct
            where TTransitionEvent : struct
    {
        void Enter(IFsmState<TState, TTransitionEvent> prev);

        void Update();

        void Exit(IFsmState<TState, TTransitionEvent> next);

        FsmEventResult<TState> OnEvent(TTransitionEvent evt, FsmEventResult<TState> result);

        bool IsFinished
        {
            get;
        }

        IFsm<TState, TTransitionEvent> Fsm
        {
            get;
            set;
        }

        TState State
        {
            get;
        }

        Pie.Collections.IReadOnlyDictionary<TTransitionEvent, TState> Transitions
        {
            get;
        }

        TState? FinishedState
        {
            get;
        }
    }

    public class FsmState<TState, TTransitionEvent> : IFsmState<TState, TTransitionEvent>
            where TState : struct
            where TTransitionEvent : struct
    {
        public FsmState(
                TState state,
                Action<IFsmState<TState, TTransitionEvent>, FsmState<TState, TTransitionEvent>> onEnter = null,
                Action<FsmState<TState, TTransitionEvent>> onUpdate = null,
                Action<FsmState<TState, TTransitionEvent>, IFsmState<TState, TTransitionEvent>> onExit = null,
                Func<FsmState<TState, TTransitionEvent>, TTransitionEvent, FsmEventResult<TState>, FsmEventResult<TState>> onEvent = null,
                IEnumerable<KeyValuePair<TTransitionEvent, TState>> transitions = null,
                TState? finishedState = null)
        {
            _onEnter = onEnter;
            _onUpdate = onUpdate;
            _onExit = onExit;
            _onEvent = onEvent;

            State = state;

            var dict = new Dictionary<TTransitionEvent, TState>();
            if (transitions != null)
            {
                foreach (var transition in transitions)
                {
                    dict.Add(transition.Key, transition.Value);
                }
            }

            Transitions = new ReadOnlyDictionary<TTransitionEvent, TState>(dict);
            FinishedState = finishedState;
        }

        #region Implementaion of IFsmState<TState, TTransitionEvent>
        public void Enter(IFsmState<TState, TTransitionEvent> prev)
        {
            IsFinished = false;

            if (_onEnter != null)
            {
                _onEnter(prev, this);
            }
        }

        public void Update()
        {
            if (_onUpdate == null)
            {
                return;
            }

            _onUpdate(this);

            //if (_onUpdate != null)
            //{
            //    _onUpdate(this);
            //}
            //else
            //{
            //    IsFinished = true;
            //}
        }

        public void Exit(IFsmState<TState, TTransitionEvent> next)
        {
            if (_onExit != null)
            {
                _onExit(this, next);
            }
        }

        public FsmEventResult<TState> OnEvent(TTransitionEvent evt, FsmEventResult<TState> result)
        {
            return _onEvent != null ? _onEvent(this, evt, result) : result;
        }

        public bool IsFinished
        {
            get;
            private set;
        }

        public IFsm<TState, TTransitionEvent> Fsm
        {
            get;
            set;
        }

        public TState State
        {
            get;
            private set;
        }

        public Pie.Collections.IReadOnlyDictionary<TTransitionEvent, TState> Transitions
        {
            get;
            private set;
        }

        public TState? FinishedState
        {
            get;
            private set;
        }
        #endregion

        public void Finish()
        {
            IsFinished = true;
        }

        private readonly Action<IFsmState<TState, TTransitionEvent>, FsmState<TState, TTransitionEvent>> _onEnter;
        private readonly Action<FsmState<TState, TTransitionEvent>> _onUpdate;
        private readonly Action<FsmState<TState, TTransitionEvent>, IFsmState<TState, TTransitionEvent>> _onExit;
		private readonly Func<FsmState<TState, TTransitionEvent>, TTransitionEvent, FsmEventResult<TState>, FsmEventResult<TState>> _onEvent;
    }
}
