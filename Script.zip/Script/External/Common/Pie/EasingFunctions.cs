﻿using System;
using UnityEngine;

namespace Pie
{
    /// <summary>
    /// Easing 함수 대리자.
    /// </summary>
    /// <param name="t">d에 대한 현재 시간.</param>
    /// <param name="b">시작 값.</param>
    /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
    /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
    public delegate float EasingFunctionDelegate(float t, float b, float c, float d);

    /// <summary>
    /// Easing 함수 클래스. 모든 Easing 함수의 t 값은 [0, d]로 클램프된다.
    /// </summary>
    public static class EasingFunctions
    {
        #region Linear
        /// <summary>
        /// 선형 변환.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float Linear(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }
            return c * t / d + b;
        }
        #endregion

        #region Sine
        /// <summary>
        /// sin(t)에 의한 가속 변환.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float SineIn(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }
            return -c * Mathf.Cos(t / d * HalfPI) + c + b;
        }

        /// <summary>
        /// sin(t)에 의한 감속 변환.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float SineOut(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }
            return c * Mathf.Sin(t / d * HalfPI) + b;
        }

        /// <summary>
        /// sin(t)에 의한 변환. d에 대한 t의 비가 0.5가 될 때까지는 가속, 0.5부터 1까지는 감속한다.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float SineInOut(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }
            return -c * 0.5f * (Mathf.Cos(Mathf.PI * t / d) - 1.0f) + b;
        }
        #endregion

        #region Quadratic
        /// <summary>
        /// t^2에 의한 가속 변환.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float QuadIn(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }

            t /= d;
            return c * t * t + b;
        }

        /// <summary>
        /// t^2에 의한 감속 변환.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float QuadOut(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }

            t /= d;
            return -c * t * (t - 2.0f) + b;
        }

        /// <summary>
        /// t^2에 의한 변환. d에 대한 t의 비가 0.5가 될 때까지는 가속, 0.5부터 1까지는 감속한다.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float QuadInOut(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }

            t /= d * 0.5f;
            if (t < 1.0f)
            {
                return c * 0.5f * t * t + b;
            }

            t -= 1.0f;
            return -c * 0.5f * (t * (t - 2.0f) - 1.0f) + b;
        }
        #endregion

        #region Cubic
        /// <summary>
        /// t^3에 의한 가속 변환.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float CubicIn(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }

            t /= d;
            return c * t * t * t + b;
        }

        /// <summary>
        /// t^3에 의한 감속 변환.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float CubicOut(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }

            t /= d;
            t -= 1.0f;
            return c * (t * t * t + 1.0f) + b;
        }

        /// <summary>
        /// t^3에 의한 변환. d에 대한 t의 비가 0.5가 될 때까지는 가속, 0.5부터 1까지는 감속한다.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float CubicInOut(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }

            t /= d * 0.5f;
            if (t < 1.0f)
            {
                return c * 0.5f * t * t * t + b;
            }

            t -= 2.0f;
            return c * 0.5f * (t * t * t + 2.0f) + b;
        }
        #endregion

        #region Quartic
        /// <summary>
        /// t^4에 의한 가속 변환.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float QuartIn(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }

            t /= d;
            return c * t * t * t * t + b;
        }

        /// <summary>
        /// t^4에 의한 감속 변환.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float QuartOut(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }

            t /= d;
            t -= 1.0f;
            return -c * (t * t * t * t - 1.0f) + b;
        }

        /// <summary>
        /// t^4에 의한 변환. d에 대한 t의 비가 0.5가 될 때까지는 가속, 0.5부터 1까지는 감속한다.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float QuartInOut(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }

            t /= d * 0.5f;
            if (t < 1.0f)
            {
                return c * 0.5f * t * t * t * t + b;
            }

            t -= 2.0f;
            return -c * 0.5f * (t * t * t * t - 2.0f) + b;
        }
        #endregion

        #region Quintic
        /// <summary>
        /// t^5에 의한 가속 변환.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float QuintIn(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }

            t /= d;
            return c * t * t * t * t * t + b;
        }

        /// <summary>
        /// t^5에 의한 감속 변환.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float QuintOut(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }

            t /= d;
            t -= 1.0f;
            return c * (t * t * t * t * t + 1.0f) + b;
        }

        /// <summary>
        /// t^5에 의한 변환. d에 대한 t의 비가 0.5가 될 때까지는 가속, 0.5부터 1까지는 감속한다.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float QuintInOut(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }

            t /= d * 0.5f;
            if (t < 1.0f)
            {
                return c * 0.5f * t * t * t * t * t + b;
            }

            t -= 2.0f;
            return c * 0.5f * (t * t * t * t * t + 2.0f) + b;
        }
        #endregion

        #region Exponential
        /// <summary>
        /// 2^t에 의한 가속 변환.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float ExpoIn(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }
            return c * Mathf.Pow(2.0f, 10.0f * (t / d - 1.0f)) + b;
        }

        /// <summary>
        /// 2^t에 의한 감속 변환.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float ExpoOut(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }
            return c * (-Mathf.Pow(2.0f, -10.0f * t / d) + 1.0f) + b;
        }

        /// <summary>
        /// 2^t에 의한 변환. d에 대한 t의 비가 0.5가 될 때까지는 가속, 0.5부터 1까지는 감속한다.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float ExpoInOut(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }

            t /= d * 0.5f;
            if (t < 1.0f)
            {
                return c * 0.5f * Mathf.Pow(2.0f, 10.0f * (t - 1.0f)) + b;
            }

            t -= 1.0f;
            return c * 0.5f * (-Mathf.Pow(2.0f, -10.0f * t) + 2.0f) + b;
        }
        #endregion

        #region Circular
        /// <summary>
        /// sqrt(1 - t^2)에 의한 가속 변환.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float CircIn(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }

            t /= d;
            return -c * (Mathf.Sqrt(1.0f - t * t) - 1.0f) + b;
        }

        /// <summary>
        /// sqrt(1 - t^2)에 의한 감속 변환.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float CircOut(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }

            t /= d;
            t -= 1.0f;
            return c * Mathf.Sqrt(1.0f - t * t) + b;
        }

        /// <summary>
        /// sqrt(1 - t^2)에 의한 변환. d에 대한 t의 비가 0.5가 될 때까지는 가속, 0.5부터 1까지는 감속한다.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float CircInOut(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }

            t /= d * 0.5f;
            if (t < 1.0f)
            {
                return -c * 0.5f * (Mathf.Sqrt(1.0f - t * t) - 1.0f) + b;
            }

            t -= 2.0f;
            return c * 0.5f * (Mathf.Sqrt(1.0f - t * t) + 1.0f) + b;
        }
        #endregion

        #region Back
        /// <summary>
        /// (s + 1) * t^3 - s * t^2에 의한 가속 변환.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float BackIn(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }

            const float s = 1.70158f;
            float postFix = t /= d;
            return c * postFix * t * ((s + 1.0f) * t - s) + b;
        }

        /// <summary>
        /// (s + 1) * t^3 - s * t^2에 의한 감속 변환.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float BackOut(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }

            const float s = 1.70158f;
            t = t / d - 1.0f;
            return c * (t * t * ((s + 1) * t + s) + 1.0f) + b;
        }

        /// <summary>
        /// (s + 1) * t^3 - s * t^2에 의한 변환. d에 대한 t의 비가 0.5가 될 때까지는 가속, 0.5부터 1까지는 감속한다.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float BackInOut(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }

            float s = 1.70158f;
            t /= d * 0.5f;
            s *= 1.525f;

            if (t < 1.0f)
            {
                return c * 0.5f * (t * t * ((s + 1.0f) * t - s)) + b;
            }

            t -= 2.0f;
            float postFix = t;
            return c * 0.5f * (postFix * t * ((s + 1.0f) * t + s) + 2.0f) + b;
        }
        #endregion

        #region Elastic
        /// <summary>
        /// 지수적으로 감쇠하는 사인파 모양의 가속 변환.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float ElasticIn(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }

            t /= d;

            float p = d * 0.3f;
            t -= 1.0f;
            return c * Mathf.Pow(2.0f, 10.0f * t) * -Mathf.Sin((t * d - p / 4.0f) * TwoPI / p) + b;
        }

        /// <summary>
        /// 지수적으로 감쇠하는 사인파 모양의 감속 변환.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float ElasticOut(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }

            t /= d;

            float p = d * 0.3f;
            return c * Mathf.Pow(2.0f, -10.0f * t) * Mathf.Sin((t * d - p / 4.0f) * TwoPI / p) + b + c;
        }

        /// <summary>
        /// 지수적으로 감쇠하는 사인파 모양의 변환. d에 대한 t의 비가 0.5가 될 때까지는 가속, 0.5부터 1까지는 감속한다.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float ElasticInOut(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }

            t /= d * 0.5f;

            float p = d * (0.3f * 1.5f);
            float a = c;
            float s = p / 4.0f;
            float postFix;

            if (t < 1.0f)
            {
                t -= 1.0f;
                postFix = a * Mathf.Pow(2.0f, 10.0f * t);
                return postFix * -0.5f * Mathf.Sin((t * d - s) * TwoPI / p) + b;
            }

            t -= 1.0f;
            postFix = a * Mathf.Pow(2.0f, -10.0f * t);
            return postFix * Mathf.Sin((t * d - s) * TwoPI / p) * 0.5f + b + c;
        }
        #endregion

        #region Bounce
        /// <summary>
        /// 지수적으로 감쇠하는 포물선 모양 반동을 보여주는 가속 변환.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float BounceIn(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }
            return c - BounceOut(d - t, default(float), c, d) + b;
        }

        /// <summary>
        /// 지수적으로 감쇠하는 포물선 모양 반동을 보여주는 감속 변환.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float BounceOut(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }

            t /= d;
            if (t < (1.0f / 2.75f))
            {
                return c * (7.5625f * t * t) + b;
            }
            else if (t < (2.0f / 2.75f))
            {
                t -= 1.5f / 2.75f;
                return c * (7.5625f * t * t + 0.75f) + b;
            }
            else if (t < (2.5f / 2.75f))
            {
                t -= 2.25f / 2.75f;
                return c * (7.5625f * t * t + 0.9375f) + b;
            }
            else
            {
                t -= 2.625f / 2.75f;
                return c * (7.5625f * t * t + 0.984375f) + b;
            }
        }

        /// <summary>
        /// 지수적으로 감쇠하는 포물선 모양 반동을 보여주는 변환.
        /// d에 대한 t의 비가 0.5가 될 때까지는 가속, 0.5부터 1까지는 감속한다.
        /// </summary>
        /// <param name="t">d에 대한 현재 시간.</param>
        /// <param name="b">시작 값.</param>
        /// <param name="c">시작 값으로부터 변화할 값. 최종 값은 b + c가 된다.</param>
        /// <param name="d">b로부터 b + c까지 변화하는 시간.</param>
        public static float BounceInOut(float t, float b, float c, float d)
        {
            float retval;
            if (CheckOutOfRange(t, b, c, d, out retval))
            {
                return retval;
            }

            if (t < d * 0.5f)
            {
                return BounceIn(t * 2.0f, default(float), c, d) * 0.5f + b;
            }
            else
            {
                return (BounceOut(t * 2.0f - d, default(float), c, d) + c) * 0.5f + b;
            }
        }
        #endregion

        private static bool CheckOutOfRange(float t, float b, float c, float d, out float retval)
        {
            retval = 0.0f;
            if (t <= 0.0f)
            {
                retval = b;
                return true;
            }
            else if (t >= d)
            {
                retval = b + c;
                return true;
            }
            return false;
        }

        private const float HalfPI = (float)(Math.PI * 0.5);
        private const float TwoPI = (float)(Math.PI * 2.0);
    }
}
