﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Pie
{
    public struct FsmEventResult<TState>
            where TState : struct
    {
        public static readonly FsmEventResult<TState> None = new FsmEventResult<TState>(false, default(TState));

        public FsmEventResult(TState nextState)
            : this(true, nextState)
        {
        }

        public readonly bool HasNextState;
        public readonly TState NextState;

        private FsmEventResult(bool hasNextState, TState nextState)
        {
            HasNextState = hasNextState;
            NextState = nextState;
        }
    }

    public interface IFsm<TState, TTransitionEvent> : IEnumerable<IFsmState<TState, TTransitionEvent>>
            where TState : struct
            where TTransitionEvent : struct
    {
        void Add(IFsmState<TState, TTransitionEvent> fsmState);

        void Remove(TState state);

        bool Contains(TState state);

        void Start();

        void Update();

        void Stop();

        void Event(TTransitionEvent evt);

        TState StartState
        {
            get;
            set;
        }

        IFsmState<TState, TTransitionEvent> this[TState state]
        {
            get;
            set;
        }

        bool IsPlaying
        {
            get;
        }

        IFsmState<TState, TTransitionEvent> PreviousFsmState
        {
            get;
        }

        IFsmState<TState, TTransitionEvent> CurrentFsmState
        {
            get;
        }

        Dictionary<TTransitionEvent, TState> GlobalTransitions
        {
            get;
        }
    }

    public class Fsm<TState, TTransitionEvent> : IFsm<TState, TTransitionEvent>
            where TState : struct
            where TTransitionEvent : struct
    {
        public Fsm(TState startState)
        {
            _fsmStates = new Dictionary<TState, IFsmState<TState, TTransitionEvent>>();
            _startState = startState;
            _globalTransitions = new Dictionary<TTransitionEvent, TState>();
        }

        #region Implementaion of IEnumerable<IFsmState<TState, TTransitionEvent>>
        public IEnumerator<IFsmState<TState, TTransitionEvent>> GetEnumerator()
        {
            return _fsmStates.Values.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return _fsmStates.Values.GetEnumerator();
        }
        #endregion

        #region Implementaion of IFsm<TState, TTransitionEvent>
        public void Add(IFsmState<TState, TTransitionEvent> fsmState)
        {
            if (fsmState == null)
            {
                throw new ArgumentNullException("fsmState");
            }

            _fsmStates.Add(fsmState.State, fsmState);
            fsmState.Fsm = this;
        }

        public void Remove(TState state)
        {
            _fsmStates.Remove(state);
        }

        public bool Contains(TState state)
        {
            return _fsmStates.ContainsKey(state);
        }

        public void Start()
        {
            if (_currentFsmState != null)
            {
                throw new InvalidOperationException("실행 중인 Fsm의 Start 메서드를 호출할 수 없습니다.");
            }

            if (!_fsmStates.ContainsKey(StartState))
            {
                throw new InvalidOperationException(StartState + " 상태와 일치하는 FsmState가 없습니다.");
            }

            _currentFsmState = _fsmStates[StartState];

            UpdateCurrentFsmState(FsmStageState.Enter, null);
            UpdateQueuedFsmState();
        }

        public void Update()
        {
            if (_currentFsmState == null)
            {
                return;
            }

            UpdateCurrentFsmState(FsmStageState.Update, null);
            UpdateQueuedFsmState();
        }

        public void Stop()
        {
            if (_currentFsmState == null)
            {
                return;
            }

            if (_fsmStateStage == FsmStageState.Exit)
            {
                throw new InvalidOperationException("Exit 호출 중에 Stop을 호출할 수 없습니다.");
                //Debug.LogWarning("Exit 호출 중에 Stop을 호출할 수 없습니다.");
                //return;
            }

            if (_fsmStateStage == FsmStageState.Enter || _fsmStateStage == FsmStageState.Update)
            {
                _stopRequested = true;
            }
            else
            {
                StopInternal();
            }
        }

        public void Event(TTransitionEvent evt)
        {
            if (_currentFsmState == null)
            {
                throw new InvalidOperationException("정지된 Fsm에 전환을 시도할 수 없습니다.");
            }

            if (_onEvent)
            {
                throw new InvalidOperationException("Event 호출 중에 Fsm에 전환을 시도할 수 없습니다.");
            }

            if (_fsmStateStage == FsmStageState.Exit)
            {
                throw new InvalidOperationException("Exit 호출 중에 Fsm에 전환을 시도할 수 없습니다.");
            }

            _onEvent = true;

            FsmEventResult<TState> result;
            TState nextState;
            if (!_currentFsmState.Transitions.TryGetValue(evt, out nextState) &&
                !_globalTransitions.TryGetValue(evt, out nextState))
            {
                //Debug.LogWarningFormat(
                //        "{0} 상태에는 {1} 이벤트에 해당하는 전환이 없습니다.",
                //        CurrentFsmState.State,
                //        evt);

                result = FsmEventResult<TState>.None;
            }
            else
            {
                result = new FsmEventResult<TState>(nextState);
            }

            try
            {
                result = _currentFsmState.OnEvent(evt, result);
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                _onEvent = false;
            }

            if (!result.HasNextState)
            {
                return;
            }
            else
            {
                nextState = result.NextState;
            }

            IFsmState<TState, TTransitionEvent> nextFsmState;
            if (!_fsmStates.TryGetValue(nextState, out nextFsmState))
            {
                throw new InvalidOperationException(nextState + " 상태가 존재하지 않습니다.");
            }

            if (_fsmStateStage == FsmStageState.Enter || _fsmStateStage == FsmStageState.Update)
            {
                _queuedFsmState = _fsmStates[nextState];
            }
            else
            {
                ChangeFsmState(_fsmStates[nextState]);
                UpdateQueuedFsmState();
            }
        }

        public TState StartState
        {
            get { return _startState; }
            set { _startState = value; }
        }

        public IFsmState<TState, TTransitionEvent> this[TState state]
        {
            get { return _fsmStates[state]; }
            set
            {
                value.Fsm = this;
                _fsmStates[state] = value;
            }
        }

        public bool IsPlaying
        {
            get { return _currentFsmState != null; }
        }

        public IFsmState<TState, TTransitionEvent> PreviousFsmState
        {
            get { return _previousFsmState; }
        }

        public IFsmState<TState, TTransitionEvent> CurrentFsmState
        {
            get { return _currentFsmState; }
        }

        public Dictionary<TTransitionEvent, TState> GlobalTransitions
        {
            get { return _globalTransitions; }
        }
        #endregion

        private enum FsmStageState
        {
            NONE,

            Enter,
            Update,
            Exit
        }

        private void StopInternal()
        {
            UpdateCurrentFsmState(FsmStageState.Exit, null);

            _previousFsmState = null;
            _currentFsmState = null;

            _onEvent = false;
            _stopRequested = false;
            _queuedFsmState = null;
        }

        private void ChangeFsmState(IFsmState<TState, TTransitionEvent> fsmState)
        {
            UpdateCurrentFsmState(FsmStageState.Exit, fsmState);

            _previousFsmState = CurrentFsmState;
            _currentFsmState = fsmState;

            UpdateCurrentFsmState(FsmStageState.Enter, PreviousFsmState);
        }

        private void UpdateCurrentFsmState(FsmStageState fsmStateStage, IFsmState<TState, TTransitionEvent> relativeFsm)
        {
            if (fsmStateStage == FsmStageState.NONE)
            {
                throw new ArgumentException("fsmStateStage");
            }

            if (_fsmStateStage != FsmStageState.NONE)
            {
                throw new InvalidOperationException("UpdateCurrentFsmState 호출 중에 다시 호출할 수 없습니다.");
            }

            if (_currentFsmState.Fsm != this)
            {
                throw new InvalidOperationException("CurrentFsmState.Fsm 값이 실행 중인 Fsm 인스턴스가 아닙니다.");
            }

            _fsmStateStage = fsmStateStage;

            try
            {
                switch (_fsmStateStage)
                {
                case FsmStageState.Enter: _currentFsmState.Enter(relativeFsm); break;
                case FsmStageState.Update: _currentFsmState.Update(); break;
                case FsmStageState.Exit: _currentFsmState.Exit(relativeFsm); break;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                _fsmStateStage = FsmStageState.NONE;
            }
        }

        private void UpdateQueuedFsmState()
        {
            for (; ; )
            {
                if (_stopRequested)
                {
                    StopInternal();
                    return;
                }
                else if (_queuedFsmState != null)
                {
                    IFsmState<TState, TTransitionEvent> nextFsmState = _queuedFsmState;
                    _queuedFsmState = null;

                    ChangeFsmState(nextFsmState);
                }
                else if (_currentFsmState.IsFinished)
                {
                    if (_currentFsmState.FinishedState.HasValue)
                    {
                        ChangeFsmState(_fsmStates[_currentFsmState.FinishedState.Value]);
                    }
                    else
                    {
                        StopInternal();
                        return;
                    }
                }
                else
                {
                    return;
                }
            }
        }

        private readonly Dictionary<TState, IFsmState<TState, TTransitionEvent>> _fsmStates;
        private TState _startState;
        private IFsmState<TState, TTransitionEvent> _previousFsmState;
        private IFsmState<TState, TTransitionEvent> _currentFsmState;
        private Dictionary<TTransitionEvent, TState> _globalTransitions;

        private FsmStageState _fsmStateStage;
        private bool _onEvent;
        private bool _stopRequested;
        private IFsmState<TState, TTransitionEvent> _queuedFsmState;
    }
}
