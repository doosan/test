﻿using UnityEngine;

namespace ForuOnes.T3.LuckyTeenPatti {

	public static class Constants {

		//public const string DeviceType =
		//	#if UNITY_EDITOR
		//	"unityeditor";
		//	#elif UNITY_ANDROID
		//	"android";
		//	#elif UNITY_IOS
		//	"ios";
		//	#endif

		public const string TableRoot = "Tables/";
		public const string EncryptTableRoot = "EncryptTables/";

		public const string MusicRoot = "Musics/";
		public const string SoundRoot = "Sounds/";
		public const string EffectRoot = "Effects/";		

		public static readonly Vector2 CanvasReferenceResolution = new Vector2(1920.0f, 1080.0f);

		public static float CanvasReferenceAspect {

			get { return CanvasReferenceResolution.x / CanvasReferenceResolution.y; }
		}
	}
}
