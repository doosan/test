﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pie;


namespace G.Util
{
    public class EncrypManager : MonoBehaviourSingleton<EncrypManager>
    {
        private static string keyAndIV = "QNUr/GF5r2vGUeJYo9B+eyNgPi43lrj1cDRs67W7ocOIjLRECTwHbUTQeT4XpL/O"; // 키값은 고정..
        private Aes256 aes_1;

        public Aes256 AES256 { get { return aes_1; } }


        protected override void Awake()
        {
            base.Awake();

            aes_1 = new Aes256(keyAndIV);
        }


#region Override from MonoBehaviourSingleton<Game>
        public override bool IsGlobal
        {

            get { return true; }
        }
#endregion

    }
}
