using System;

namespace G.Util
{
	internal static class EncryptedValue
	{
		internal static uint seed = 0XB397B5D3;
		internal static ulong seedl = 0X3C078FB4B397B5D3;
		internal static Aes256 aes;

		static EncryptedValue()
		{
			aes = new Aes256();
		}
	}
	
	public class EncryptedInt32
	{
		private byte[] b = new byte[4];
		private uint v0;
		private uint v1;
		private uint v2;

		private uint v_Show;

		public EncryptedInt32()
		{
			Value = 0;
		}

		public EncryptedInt32(int v)
		{
			Value = v;
		}

		public int Value
		{
			get
			{
				if (v0 != (v2 ^ v1)) throw new Exception("Memory Hacked");
				return (int)(v0 ^ EncryptedValue.seed);
			}

			set
			{
				Randomizer.NextBytes(b);
				v0 = (uint)value ^ EncryptedValue.seed;
				v1 = BitConverter.ToUInt32(b, 0);
				v2 = (uint)v0 ^ v1;

				v_Show = (uint)value;
			}
		}

		public int Value_Show
		{
			get
			{
				return (int)v_Show;
			}
		}
	}

	//
	public class EncryptedUInt32
	{
		private byte[] b = new byte[4];
		private uint v0;
		private uint v1;
		private uint v2;

		private uint v_Show;

		public EncryptedUInt32()
		{
			Value = 0;
		}

		public EncryptedUInt32(uint v)
		{
			Value = v;
		}

		public uint Value
		{
			get
			{
				if (v0 != (v2 ^ v1)) throw new Exception("Memory Hacked");
				return (v0 ^ EncryptedValue.seed);
			}

			set
			{
				Randomizer.NextBytes(b);
				v0 = value ^ EncryptedValue.seed;
				v1 = BitConverter.ToUInt32(b, 0);
				v2 = v0 ^ v1;

				v_Show = value;
			}
		}

		public uint Value_Show
		{
			get
			{
				return v_Show;
			}
		}
	}

	public class EncryptedInt64
	{
		private byte[] b = new byte[8];
		private ulong v0;
		private ulong v1;
		private ulong v2;

		public EncryptedInt64()
		{
			Value = 0;
		}

		public EncryptedInt64(long v)
		{
			Value = v;
		}

		public long Value
		{
			get
			{
				if (v0 != (v2 ^ v1)) throw new Exception("Memory Hacked");
				return (long)(v0 ^ EncryptedValue.seedl);
			}

			set
			{
				Randomizer.NextBytes(b);
				v0 = (ulong)value ^ EncryptedValue.seedl;
				v1 = BitConverter.ToUInt64(b, 0);
				v2 = (ulong)v0 ^ v1;
			}
		}
	}

	public class EncryptedUInt64
	{
		private byte[] b = new byte[8];
		private ulong v0;
		private ulong v1;
		private ulong v2;

		public EncryptedUInt64()
		{
			Value = 0;
		}

		public EncryptedUInt64(ulong v)
		{
			Value = v;
		}

		public ulong Value
		{
			get
			{
				if (v0 != (v2 ^ v1)) throw new Exception("Memory Hacked");
				return (v0 ^ EncryptedValue.seedl);
			}

			set
			{
				Randomizer.NextBytes(b);
				v0 = value ^ EncryptedValue.seedl;
				v1 = BitConverter.ToUInt64(b, 0);
				v2 = v0 ^ v1;
			}
		}
	}

	public class EncryptedString
	{
		private byte[] b;
		private int h;

		public EncryptedString()
		{
			Value = null;
		}

		public EncryptedString(string v)
		{
			Value = v;
		}

		public string Value
		{
			get
			{
				if (b == null) return null;

				string s = EncryptedValue.aes.DecryptString(b, 0, b.Length);
				if (s.GetHashCode() != h) throw new Exception("Memory Hacked");
				return s;
			}

			set
			{
				if (value == null)
				{
					b = null;
				}
				else
				{
					h = value.GetHashCode();
					b = EncryptedValue.aes.EncryptString(value);
				}
			}
		}
	}
}
