﻿using UnityEngine;
using System.Collections;
using System.Security.Cryptography;
using G.Util;

public class csFile_Encrypted : MonoBehaviour
{
	private static string keyAndIV = "QNUr/GF5r2vGUeJYo9B+eyNgPi43lrj1cDRs67W7ocOIjLRECTwHbUTQeT4XpL/O"; // 키값은 고정.. ^^ 2014.03.26..

	private Aes256			aes_1;

	//
	void Start()
	{
		aes_1 = new Aes256(keyAndIV);
	}

	//
	public void File_Encrypted_All()
	{
		System.IO.DirectoryInfo di = new System.IO.DirectoryInfo( Application.dataPath + "/Resources/Tables" );
		
		foreach(System.IO.FileInfo f in di.GetFiles()) 
		{
			#if Logs
			Debug.Log( f.Name );
#endif
			if( !f.Name.Contains("meta") )
			{
				File_Encrypted( f.Name.Substring( 0, f.Name.Length - 4 ), "Tables/", Application.dataPath + "/TablesEncrypted/" );
			}
			//listBox1.Items.Add(f.Name + "  " + f.Extension)
		}
	}

	//
	public void File_Decrypted_All()
	{
		System.IO.DirectoryInfo di = new System.IO.DirectoryInfo( Application.dataPath + "/TablesEncrypted" );
		
		foreach(System.IO.FileInfo f in di.GetFiles())
		{
			#if Logs
			Debug.Log( f.Name );
#endif
			if( !f.Name.Contains("meta") && f.Name.Contains("bytes") )
			{
				File_Decrypted( f.FullName );
			}
			//listBox1.Items.Add(f.Name + "  " + f.Extension)
		}
	}


	//
	public bool File_Encrypted( string strFileName, string strPath_1, string strPath_2 )
	{
		string fileName = strPath_1 + strFileName;

		TextAsset table = Resources.Load( fileName ) as TextAsset;
	
		if(table == null)
		{
			Debug.LogWarning( "File_Encrypted : " +   fileName + " Not Find" );
			return false;
		}


		fileName = strPath_2 + strFileName + ".bytes";

		Debug.LogWarning(  "Create File_Encrypted : " +   fileName );

		//string fileName = strFileName + ".dat";

		//aes_1.EncryptStringToFile( fileName,  table.text );
		aes_1.EncryptToFile( fileName, table.bytes, 0, table.bytes.Length );

		return true;
	}

	//
	public string File_Decrypted( string strPathName )
	{
		#if Logs
		Debug.Log( strPathName );
#endif
		string str = aes_1.DecryptStringFromFile( strPathName );

		#if Logs
		Debug.Log( str );
#endif
		return str;
	}
	
	//
	void OnGUI()
	{
		if ( GUI.Button(new Rect(10, 10, 100, 100), "Encrypted") == true )
		{
			File_Encrypted_All();
		}

		if ( GUI.Button(new Rect(10, 110, 100, 100), "Decrypted") == true )
		{
			File_Decrypted_All();
		}
	}


}
