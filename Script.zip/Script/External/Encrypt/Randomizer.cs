﻿using System;
using System.Collections.Generic;
using System.Text;

namespace G.Util
{
    public class Randomizer
    {
		private static Random random = new Random();

		public static int Next() { return random.Next(); }
		public static int Next(int max) { return random.Next(max); }
		public static int Next(int min, int max) { return random.Next(min, max); }

		public static void NextBytes(byte[] buffer) { random.NextBytes(buffer); }

		public static double NextDouble() { return random.NextDouble(); }

		public static void Shuffle<T>(T[] array)
		{
			Random rnd = new Random();

			for (int i = array.Length - 1; i >= 0; i--)
			{
				int index = rnd.Next(i + 1);
				T tmp = array[i];
				array[i] = array[index];
				array[index] = tmp;
			}
		}

		public static void Shuffle<T>(List<T> list)
		{
			Random rnd = new Random();

			for (int i = list.Count - 1; i >= 0; i--)
			{
				int index = rnd.Next(i + 1);
				T tmp = list[i];
				list[i] = list[index];
				list[index] = tmp;
			}
		}
	}
}
