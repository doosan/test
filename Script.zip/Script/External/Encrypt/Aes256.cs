using System;
using System.IO;
using System.Text;
using System.Security.Cryptography;

namespace G.Util
{
	public class Aes256
	{
		Aes aes = null;

		public Aes256()
		{
			aes = Aes.Create();
			aes.GenerateKey();
			aes.GenerateIV();
		}

		public Aes256(byte[] key, byte[] iv)
		{
			aes = Aes.Create();
			aes.Key = key;
			aes.IV = iv;
		}

		public Aes256(string keyAndIV)
		{
			aes = Aes.Create();
			SetKeyAndIV(aes, keyAndIV);
		}

		public byte[] Encrypt(byte[] buffer, int offset, int count)
		{
			return Encrypt(aes, buffer, offset, count);
		}

		public byte[] EncryptString(string text)
		{
			return EncryptString(aes, text);
		}

		public Stream EncryptToStream(byte[] buffer, int offset, int count)
		{
			return EncryptToStream(aes, buffer, offset, count);
		}

		public void EncryptToFile(string path, byte[] buffer, int offset, int count)
		{
			EncryptToFile(path, aes, buffer, offset, count);
		}

		public void EncryptStringToFile(string path, string text)
		{
			EncryptStringToFile(path, aes, text);
		}

		public byte[] Decrypt(byte[] buffer, int offset, int count)
		{
			return Decrypt(aes, buffer, offset, count);
		}

		public string DecryptString(byte[] buffer, int offset, int count)
		{
			return DecryptString(aes, buffer, offset, count);
		}

		public Stream DecryptToStream(byte[] buffer, int offset, int count)
		{
			return DecryptToStream(aes, buffer, offset, count);
		}

		public Stream DecryptToStream(Stream stream)
		{
			return DecryptToStream(aes, stream);
		}

		public byte[] DecryptFromFile(string path)
		{
			return DecryptFromFile(path, aes);
		}

		public string DecryptStringFromFile(string path)
		{
			return DecryptStringFromFile(path, aes);
		}

		public static void SetKeyAndIV(Aes aes, string keyAndIV)
		{
			byte[] kiBytes = Convert.FromBase64String(keyAndIV);
			if (kiBytes.Length != 48) throw new Exception("Wrong Key And IV");

			byte[] key = new byte[32];
			byte[] iv = new byte[16];
			Buffer.BlockCopy(kiBytes, 0, key, 0, 32);
			Buffer.BlockCopy(kiBytes, 32, iv, 0, 16);

			aes.Key = key;
			aes.IV = iv;
		}

		public static byte[] Encrypt(Aes aes, byte[] buffer, int offset, int count)
		{
			using (ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV))
			{
				return encryptor.TransformFinalBlock(buffer, offset, count);
			}
		}

		public static byte[] EncryptString(Aes aes, string text)
		{
			byte[] data = Encoding.UTF8.GetBytes(text);
			return Encrypt(aes, data, 0, data.Length);
		}

		public static Stream EncryptToStream(Aes aes, byte[] buffer, int offset, int count)
		{
			using (ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV))
			using (MemoryStream ms = new MemoryStream())
			using (CryptoStream cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
			{
				cs.Write(buffer, offset, count);
				cs.FlushFinalBlock();
				return ms;
			}
		}

		public static void EncryptToFile(string path, Aes aes, byte[] buffer, int offset, int count)
		{
            using (ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV))
			using (FileStream fs = new FileStream(path, FileMode.Create))
			using (CryptoStream cs = new CryptoStream(fs, encryptor, CryptoStreamMode.Write))
			{
				cs.Write(buffer, offset, count);
				cs.FlushFinalBlock();
				fs.Flush();
				fs.Close();
			}
		}

		public static void EncryptStringToFile(string path, Aes aes, string text)
		{
			byte[] data = Encoding.UTF8.GetBytes(text);
			EncryptToFile(path, aes, data, 0, data.Length);
		}

		public static byte[] Decrypt(Aes aes, byte[] buffer, int offset, int count)
		{
			using (ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV))
			{
				return decryptor.TransformFinalBlock(buffer, offset, count);
			}
		}

		public static string DecryptString(Aes aes, byte[] buffer, int offset, int count)
		{
			byte[] data = Decrypt(aes, buffer, offset, count);
			return Encoding.UTF8.GetString(data);
		}

		public static Stream DecryptToStream(Aes aes, byte[] buffer, int offset, int count)
		{
			ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);
			MemoryStream encryptedStream = new MemoryStream(buffer, offset, count);
			return new CryptoStream(encryptedStream, decryptor, CryptoStreamMode.Read);
		}

		public static Stream DecryptToStream(Aes aes, Stream stream)
		{
			ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);
			return new CryptoStream(stream, decryptor, CryptoStreamMode.Read);
		}

		public static byte[] DecryptFromFile(string path, Aes aes)
		{
			byte[] encrypted = File.ReadAllBytes(path);
			return Decrypt(aes, encrypted, 0, encrypted.Length);
		}

		public static string DecryptStringFromFile(string path, Aes aes)
		{
			byte[] encrypted = File.ReadAllBytes(path);
			return DecryptString(aes, encrypted, 0, encrypted.Length);
		}
	}
}
