﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameDefine
{
    public static readonly string clientVersion = "V2.2.02";

    public static readonly long[] chipValue = 
    { 1,             5,             10,             50,             100,             500,             1000,             5000,
      10000,         50000,         100000,         500000,         1000000,         5000000,         10000000,         50000000,
      100000000,     500000000,     1000000000,     5000000000,     10000000000,     50000000000,     100000000000,     500000000000,
      1000000000000, 5000000000000, 10000000000000, 50000000000000, 100000000000000, 500000000000000, 1000000000000000, 5000000000000000 };

    public static readonly int lpUintCount = 5;
    public static readonly int maxPlayer = 5;
    public static readonly int notMainRoom = -1;
    public static readonly int receiveMaxCardCount = 3;

    public static readonly int historyListMaxCount = 10;
    public static readonly int historySlotMaxCount = 100;

    public static readonly int classicContentsDataId = 101;
    public static readonly int variationContentsDataId = 102;
    public static readonly int privateContentsDataId = 104;

#if UNITY_IOS
    public static readonly string gameId = "3093926";
#elif UNITY_ANDROID
    public static readonly string gameId = "3093927";
#else
    public static readonly string gameId = "3093927";
#endif

    public static readonly string placementId = "rewardedVideo";
}