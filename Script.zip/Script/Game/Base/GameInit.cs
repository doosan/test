﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ForuOnes.T3.LuckyTeenPatti;
using DG.Tweening;
using UniRx;
using Pie;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti
{
    public class GameInit : MonoBehaviourSingleton<GameInit>
    {
        private enum State
        {
            NotInitialized,
            Initializing,
            Initialized
        }
        #region Overrides
        protected override void Awake()
        {

            base.Awake();

        }

        public override bool IsGlobal
        {

            get { return true; }
        }
        #endregion

        #region Static
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        private static void OnApplicationInitialize()
        {

            // Game 오브젝트 생성.
            new GameObject("Game", typeof(GameInit));
            //Init();

#if SRDEBUG
            SRDebug.Init();
            SROptions.General.Attach();
#endif

            DOTween.Init();
            MainThreadDispatcher.Initialize();
            // UISoundManager.Init();
        }

        public static void Init()
        {
            //try
            //{
            //    string failedTableName = Instance._tables
            //        .Select(table => Tuple.Create(table.Load(string.Empty), table.Name))
            //        .Where(tuple => !tuple.Item1)
            //        .Select(tuple => tuple.Item2)
            //        .FirstOrDefault();
            //}
            //catch
            //{

            //    throw;
            //}
        }

        #endregion

        
    }
}