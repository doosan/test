﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class InputFieldSelecter : MonoBehaviour, ISelectHandler
{
    #region Inspector Fields
    [SerializeField] private InputField _inputField = null;
    #endregion

    public void OnSelect(BaseEventData data)
    {
        _inputField.text = str;
    }

    public void SetString(string _str)
    {
        str = _str;
    }

    private string str = string.Empty;
}
