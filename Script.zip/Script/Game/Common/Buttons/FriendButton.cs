﻿using System.Collections;
using System.Collections.Generic;
using UniRx;
using UnityEngine;
using UnityEngine.UI;
using System;
using ForuOnes.T3.LuckyTeenPatti.Table;

namespace ForuOnes.T3.LuckyTeenPatti
{
    public class FriendButton : NotiButton
    {
        #region Inspector Fields
        [SerializeField] private GameObject _newIcon = null;

        [SerializeField] private GameObject _count = null;
        [SerializeField] private Text _countValue = null;

        [SerializeField] private Transform _arlamTranform = null;
        [SerializeField] private bool _IsGame = false;
        #endregion

        // Start is called before the first frame update
        void Start()
        {
            Func<int, string> getString = LocalizationSentenceTable.Instance.GetString;

            _button.onClick.AddListener(() =>
            {
                if (AcUserInfo._netData_user._accountLinkType == eAccountLinkType.TYPE_FACEBOOK)
                {
                    UIManager.Instance.StartLoading();
                    AcNetFacade.Instance.SendPacket_req_contentsLockCheck(eContentMainLockType.TYPE_FRIEND, 0, res =>
                    {
                        UIManager.Instance.FinishLoading();

                        if (res == eGameResult.RESULT_OK)
                        {
                            UIManager.Instance.StartLoading();

                            AcNetFacade.Instance.SendPacket_req_friendList(res2 =>
                            {
                                UIManager.Instance.FinishLoading();
                                if (res2 == eGameResult.RESULT_OK)
                                {
                                    UIManager.Instance.OpenUI(eGameUI.Friend_UI);                                    
                                }
                            });
                        }
                        else if (res == eGameResult.RESULT_CONTENTLOCK)
                        {
                            MessageBoxManager.Instance.OnMessageBoxUI(getString(110077), getString(30011), getString(30010), null, null, true, false);                            
                        }
                    });
                }
                else
                {
                    UIManager.Instance.StartLoading();
                    AcNetFacade.Instance.SendPacket_req_contentsLockCheck(eContentMainLockType.TYPE_FRIEND, 0, res =>
                    {
                        UIManager.Instance.FinishLoading();

                        if (res == eGameResult.RESULT_OK)
                        {
                            UIManager.Instance.OpenUI(eGameUI.Friend_UI);
                        }
                        else if (res == eGameResult.RESULT_CONTENTLOCK)
                        {
                            MessageBoxManager.Instance.OnMessageBoxUI(getString(110077), getString(30011), getString(30010), null, null, true, false);                            
                        }
                    });
                }
            });

            if (_IsGame)
            {
                _button.gameObject.SetActive(AcUserInfo._netData_user._accountLinkType == eAccountLinkType.TYPE_FACEBOOK);                
            }
        }

        private void OnEnable()
        {
            LoginAlertManager.Instance.SetTransform(_arlamTranform);

            PlayerDataManager.Instance.ObserveEveryValueChanged(x => x.connectionFriendsCount)
             .DistinctUntilChanged()
             .Subscribe(count =>
             {
                 if (count == 0)
                 {
                     _count.SetActive(false);
                 }
                 else
                 {
                     _count.SetActive(true);
                     _countValue.text = count <= 99 ? count.ToString() : "99";
                 }
             }).AddTo(disposalbles);

            this.ObserveEveryValueChanged(x => x.IsRequest)
             .DistinctUntilChanged()
             .Subscribe(value =>
             {
                 _newIcon.SetActive(value);
             }).AddTo(disposalbles);

        }

        private bool IsRequest { get { return AcUserInfo._friendRequestList.Count > 0; } }
    }
}
