﻿using System.Collections;
using System.Collections.Generic;
using UniRx;
using UnityEngine;
using UnityEngine.UI;
using System;
using ForuOnes.T3.LuckyTeenPatti.Table;

namespace ForuOnes.T3.LuckyTeenPatti
{
    public class PostButton : NotiButton
    {
        #region Inspector Fields
        [SerializeField] private GameObject _count = null;
        [SerializeField] private Text _countValue = null;
        #endregion

        // Start is called before the first frame update
        void Start()
        {
            Func<int, string> getString = LocalizationSentenceTable.Instance.GetString;

            _button.onClick.AddListener(() =>
            {
                UIManager.Instance.StartLoading();
                AcNetFacade.Instance.SendPacket_req_contentsLockCheck(eContentMainLockType.TYPE_POST, 0, res =>
                {
                    UIManager.Instance.FinishLoading();

                    if (res == eGameResult.RESULT_OK)
                    {
                        UIManager.Instance.OpenUI(eGameUI.Post_UI);                        
                    }
                    else if (res == eGameResult.RESULT_CONTENTLOCK)
                    {
                        MessageBoxManager.Instance.OnMessageBoxUI(getString(110077), getString(30011), getString(30010), null, null, true, false);                        
                    }
                });
            });
        }

        private void OnEnable()
        {
            AcUserInfo._netData_postbox._postList.ObserveEveryValueChanged(x => x.Count)
                    .DistinctUntilChanged()
                    .Subscribe(count =>
                    {
                        if (count == 0)
                        {
                            _count.SetActive(false);
                        }
                        else
                        {
                            _count.SetActive(true);
                            _countValue.text = count <= 99 ? count.ToString() : "99";
                        }
                    }).AddTo(disposalbles);
        }
    }
}
