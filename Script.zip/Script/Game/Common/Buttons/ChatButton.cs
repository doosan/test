﻿using System.Collections;
using System.Collections.Generic;
using UniRx;
using UnityEngine;
using UnityEngine.UI;

namespace ForuOnes.T3.LuckyTeenPatti
{
    public class ChatButton : NotiButton
    {
        #region Inspector Fields
        [SerializeField] private GameObject _count = null;
        [SerializeField] private Text _countValue = null;

        [SerializeField] private GameObject _effect = null;
        #endregion

        // Start is called before the first frame update
        void Start()
        {
            _button.onClick.AddListener(() =>
            {
                UIManager.Instance.GetUIWindowWithOpen<ChatUI>(eGameUI.Chat_UI).SetCurrentChat(multiOder);
                UIManager.Instance.OpenUI(eGameUI.Chat_UI);
            });
        }

        private void OnEnable()
        {
            PlayerDataManager.Instance.ObserveEveryValueChanged(x => x.newChatCount)
                .DistinctUntilChanged()
                .Subscribe(count =>
                {
                    if (count == 0)
                    {
                        _effect.SetActive(false);
                        _count.SetActive(false);
                    }
                    else
                    {
                        _effect.SetActive(true);
                        _count.SetActive(true);
                        _countValue.text = count <= 99 ? count.ToString() : "99";
                    }
                }).AddTo(disposalbles);
        }

        public void SetMultiOder(int _multiOder)
        {
            multiOder = _multiOder;
        }

        private int multiOder = 0;
    }
}
