﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using ForuOnes.T3.LuckyTeenPatti.Table;
using DG.Tweening;
using System;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti
{
    public class BoostPurchaseButton : MonoBehaviour
    {
        #region Inspector Fields
        [SerializeField] private Button _button = null;
        [SerializeField] private Image _icon = null;
        [SerializeField] private Text _value = null;

        [SerializeField] private LocalizationText _itemName = null;
        [SerializeField] private Image _rewardIcon = null;
        [SerializeField] private Text _price = null;
        [SerializeField] private Transform _panel = null;
        #endregion

        private void Start()
        {
            Func<int, string> getString = LocalizationSentenceTable.Instance.GetString;

            _button.onClick.AddListener(() =>
            {
                BuffBaseTableData buffData = BuffBaseTable.Instance.GetData(ItemBaseTable.Instance.GetData(data.RewardItemId).BuffBaseId);

                if (buffData != null)
                {
                    if (AcUserInfo.BuffInfoList.Any(x => x._buffDataId == buffData.Id))
                    {
                        if (buffData.DataDuplicateType == eBuffDataDuplicateType.TYPE_NONE)
                        {
                            MessageBoxManager.Instance.OnMessageBoxUI(getString(460005), getString(30011), getString(30010), null, null, true, false);
                        }
                        else if (buffData.DataDuplicateType == eBuffDataDuplicateType.TYPE_EXTENDTIME)
                        {
                            MessageBoxManager.Instance.OnMessageBoxUI(getString(460006), getString(30011), getString(30010), () =>
                            {
                                UIManager.Instance.CloseUI();
                                UIManager.Instance.GetUIWindowWithOpen<BoostPurchaseUI>(eGameUI.BoostPurchase_UI).Init(data);
                            }, null, true, true);
                        }
                        else if (buffData.DataDuplicateType == eBuffDataDuplicateType.TYPE_OVERWRITETIME)
                        {
                            MessageBoxManager.Instance.OnMessageBoxUI(getString(460007).Replace("{0}", getString(ItemBaseTable.Instance.GetDatabyBuffIndex(buffData.Id).ItemNameId)), getString(30011), getString(30010), () =>
                            {
                                UIManager.Instance.CloseUI();
                                UIManager.Instance.GetUIWindowWithOpen<BoostPurchaseUI>(eGameUI.BoostPurchase_UI).Init(data);
                            }, null, true, true);
                        }
                    }
                    else
                    {                        
                        UIManager.Instance.GetUIWindowWithOpen<BoostPurchaseUI>(eGameUI.BoostPurchase_UI).Init(data);
                    }
                }
            });
        }

        public void SetButton(int shopBaseId, bool isPrivate)
        {
            if(sequence == null)
            {
                sequence = DOTween.Sequence();

                sequence.Append(_panel.DOScale(Vector3.one, 1.0f).SetEase(Ease.OutBounce))
                        .AppendInterval(3.0f)
                        .Append(_panel.DOScale(Vector3.zero, 0.5f).SetEase(Ease.InOutBack))
                        .OnComplete(() =>
                        {
                            sequence.Restart();
                            sequence.Pause();
                        });

                sequence.Pause();
            }

            data = ShopBaseTable.Instance.GetData(shopBaseId);

            if (data == null)
            {
                gameObject.SetActive(false);
                return;
            }

            ItemBaseTableData itemData = ItemBaseTable.Instance.GetData(data.RewardItemId);

            if (itemData != null)
            {
                BuffBaseTableData buffData = BuffBaseTable.Instance.GetData(ItemBaseTable.Instance.GetData(data.RewardItemId).BuffBaseId);

                if (buffData != null)
                {
                    if (buffData.ApplyPrivateMode == false && isPrivate)
                    {
                        gameObject.SetActive(false);
                    }
                    else
                    {
                        _icon.sprite = ResourcesManager.Instance.GetSprite(buffData.BuffIconImage);
                        _value.text = "+" + buffData.BuffValue.ToString("0%");

                        _itemName.SetIndex(itemData.ItemNameId);

                        if (data.NeedGoodsType == eNeedGoodsType.TYPE_ITEMTYPE)
                        {
                            _rewardIcon.sprite = ResourcesManager.Instance.GetSprite(data.NeedGoodsIcon);

                            if ((eItemType)data.NeedGoodsItemValue == eItemType.TYPE_LUCKYPOINT)
                            {
                                _price.text = ConvertNumber.GetLPNumber(data.NeedGoodsValue, _price.fontSize);
                            }
                            else
                            {
                                _price.text = ConvertNumber.GetChipNumber(data.NeedGoodsValue);
                            }
                        }
                        _icon.sprite = ResourcesManager.Instance.GetSprite(buffData.BuffIconImage);

                        gameObject.SetActive(true);
                    }
                }
                else
                {
                    gameObject.SetActive(false);
                }
            }
            else
            {
                gameObject.SetActive(false);
            }
        }

        public void OnConversation()
        {
            BuffBaseTableData buffData = BuffBaseTable.Instance.GetData(ItemBaseTable.Instance.GetData(data.RewardItemId).BuffBaseId);
            if (!AcUserInfo.BuffInfoList.Any(x => x._buffDataId == buffData.Id))
                sequence.Restart();
        }

        private void OnDisable()
        {
            sequence.Restart();
            sequence.Pause();
        }

        private Sequence sequence = null;
        private ShopBaseTableData data = null;
    }
}
