﻿using System.Collections;
using System.Collections.Generic;
using UniRx;
using UnityEngine;
using ForuOnes.T3.LuckyTeenPatti.Table;
using System;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti
{
    public class RouletteButton : NotiButton
    {
        #region Inspector Fields
        [SerializeField] private int slotIndex = 3;
        [SerializeField] private GameObject _newIcon = null;
        #endregion

        private void Awake()
        {
            slotData = SlotMachineBaseTable.Instance.GetData(slotIndex);
        }

        // Start is called before the first frame update
        void Start()
        {
            Func<int, string> getString = LocalizationSentenceTable.Instance.GetString;

            _button.onClick.AddListener(() =>
            {
                AppEventManager.Instance.SendEvent("Lobby_Menu_Touch_Roulette");

                UIManager.Instance.StartLoading();
                AcNetFacade.Instance.SendPacket_req_contentsLockCheck(eContentMainLockType.TYPE_ROULETTE, 0, res =>
                {
                    UIManager.Instance.FinishLoading();

                    if (res == eGameResult.RESULT_OK)
                    {
                        UIManager.Instance.OpenUI(eGameUI.Roulette_UI);
                    }
                    else if (res == eGameResult.RESULT_CONTENTLOCK)
                    {
                        MessageBoxManager.Instance.OnMessageBoxUI(getString(110077), getString(30011), getString(30010), null, null, true, false);                        
                    }
                });
            });
        }

        private void OnEnable()
        {
            this.ObserveEveryValueChanged(x => x.IsEnable)
                .DistinctUntilChanged()
                .Subscribe(value =>
                {
                    _newIcon.SetActive(value);
                }).AddTo(disposalbles);
        }

        private bool IsEnable
        {
            get
            {
                if(slotData.CouponItemId != 1)
                {
                    return (AcUserInfo.RouletteSlotMachineEnableCount > 0 && slotData.SlotMachineFreeEnableType == eSlotMachineFreeEnableType.TYPE_ON) || AcUserInfo.ItemInfoList.Any(x => x._itemDataId == slotData.CouponItemId);
                }

                return (AcUserInfo.RouletteSlotMachineEnableCount > 0 && slotData.SlotMachineFreeEnableType == eSlotMachineFreeEnableType.TYPE_ON);
            }
        }

        private SlotMachineBaseTableData slotData = null;
    }
}

