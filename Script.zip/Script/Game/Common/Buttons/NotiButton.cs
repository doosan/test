﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UniRx;

public class NotiButton : MonoBehaviour
{
    #region Inspector Fields
    [SerializeField] protected Button _button = null;
    #endregion

    private void OnDisable()
    {
        disposalbles.Clear();
    }

    private void OnDestroy()
    {
        disposalbles.Clear();
        disposalbles = null;
    }

    protected CompositeDisposable disposalbles = new CompositeDisposable();
}
