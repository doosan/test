﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UniRx;
using UnityEngine.UI;
using System;
using ForuOnes.T3.LuckyTeenPatti.Table;

namespace ForuOnes.T3.LuckyTeenPatti
{
    public class AdvertiseInfoButton : NotiButton
    {
        #region Inspector Fields
        [SerializeField] private GameObject _advertiseLevelObj = null;

        [SerializeField] private Text _value = null;
        [SerializeField] private Text _level = null;
        #endregion

        // Start is called before the first frame update
        void Start()
        {
            _button.onClick.AddListener(() =>
            {
                AppEventManager.Instance.SendEvent("Lobby_Menu_Touch_Adreward");
                UIManager.Instance.OpenUI(eGameUI.ADAchieve_UI);
            });
        }

        private void OnEnable()
        {
            this.ObserveEveryValueChanged(x => x.ADRewardLastRewardLevel)
                .DistinctUntilChanged()
                .Subscribe(value =>
                {
                    if (value == GameAdRewardTable.Instance.maxLevel)
                        _advertiseLevelObj.SetActive(false);
                    else
                    {
                        GameAdRewardTableData data = GameAdRewardTable.Instance.GetData(value + 1);

                        if (data != null)
                        {
                            ItemBaseTableData itemData = ItemBaseTable.Instance.GetData(data.RewardItemId);

                            if (itemData.ItemType == eItemType.TYPE_LUCKYPOINT)
                            {
                                _value.text = ConvertNumber.GetLPNumber(data.RewardValue, _value.fontSize);
                            }
                            else
                                _value.text = ConvertNumber.GetChipNumber(data.RewardValue);

                            _level.text = "Level " + data.AdLevel.ToString();
                            _advertiseLevelObj.SetActive(true);
                        }
                        else
                        {
                            _advertiseLevelObj.SetActive(false);
                        }
                    }


                }).AddTo(disposalbles);
        }

        private int ADRewardLastRewardLevel { get { return AcUserInfo.ADRewardLastRewardLevel; } }
    }
}
