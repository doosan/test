﻿using System.Collections;
using System.Collections.Generic;
using UniRx;
using UnityEngine;
using UnityEngine.UI;
using System;
using ForuOnes.T3.LuckyTeenPatti.Table;

namespace ForuOnes.T3.LuckyTeenPatti
{
    public class AttendButton : NotiButton
    {
        #region Inspector Fields
        [SerializeField] private GameObject _newIcon = null;
        #endregion

        // Start is called before the first frame update
        void Start()
        {
            Func<int, string> getString = LocalizationSentenceTable.Instance.GetString;

            _button.onClick.AddListener(() =>
            {
                UIManager.Instance.StartLoading();
                AcNetFacade.Instance.SendPacket_req_contentsLockCheck(eContentMainLockType.TYPE_ATTENDANCE, 0, res =>
                {
                    UIManager.Instance.FinishLoading();
                    if (res == eGameResult.RESULT_OK)
                    {
                        UIManager.Instance.OpenUI(eGameUI.AttendSlot_UI);
                        
                    }
                    else if (res == eGameResult.RESULT_CONTENTLOCK)
                    {
                        MessageBoxManager.Instance.OnMessageBoxUI(getString(110077), getString(30011), getString(30010), null, null, true, false);                        
                    }
                });
            });
        }

        private void OnEnable()
        {
            this.ObserveEveryValueChanged(x => x.IsAttendance)
                .DistinctUntilChanged()
                .Subscribe(value =>
                {
                    _newIcon.SetActive(value);
                }).AddTo(disposalbles);
        }

        private bool IsAttendance { get { return AcUserInfo.AttendanceSlotMachineEnableCount > 0; } }
    }
}
