﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ButtonLog : MonoBehaviour
{
    [SerializeField] private Button _button = null;
    [SerializeField] private eButtonType type;

    // Use this for initialization
    void Start ()
    {
        _button.onClick.AddListener(() =>
        {
            AcNetFacade.Instance.SendPacket_req_logButtonClick(type);
        });
    }
}
