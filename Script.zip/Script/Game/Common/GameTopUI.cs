﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UniRx;

namespace ForuOnes.T3.LuckyTeenPatti
{
    public class GameTopUI : MonoBehaviour
    {
        #region Inspector Fields
        [SerializeField] private Numbering _totalChip = null;
        [SerializeField] private Numbering _lPoint = null;

        [SerializeField] private Button _menuButton = null;
        [SerializeField] private Button _lpEventButton = null;
        #endregion

        // Start is called before the first frame update
        void Start()
        {
            UIManager.Instance.AddBackButton();
            _menuButton.onClick.AddListener(() => UIManager.Instance.CloseUI());
            _lpEventButton.gameObject.SetActive(LoginManager.Instance.IsMission);
        }        

        private void OnEnable()
        {
            UIManager.Instance.SetBaseUI(UIManager.Instance.GetUIWindow(eGameUI.InGameMenu_UI));
            OutGameManager.Instance._topUI.gameObject.SetActive(false);

            _totalChip.FixValue(AcUserInfo.UserTotalChip);
            _lPoint.FixLPValue(AcUserInfo._netData_user.LuckyPoint);

            this.ObserveEveryValueChanged(x => x.UserTotalChip)
              .DistinctUntilChanged()
              .Subscribe(UserTotalChip =>
              {
                  _totalChip.SetValue(UserTotalChip);
              }).AddTo(disposalbles);

            AcUserInfo._netData_user.ObserveEveryValueChanged(x => x.LuckyPoint)
               .DistinctUntilChanged()
               .Subscribe(_luckyPoint => _lPoint.SetLPValue(_luckyPoint)).AddTo(this);
        }

        private void OnDisable()
        {
            disposalbles.Clear();
        }

        private void OnDestroy()
        {
            disposalbles.Clear();
            disposalbles = null;
        }

        private CompositeDisposable disposalbles = new CompositeDisposable();
        private long UserTotalChip { get { return AcUserInfo.UserTotalChip; } }
    }
}
