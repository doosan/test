﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

[RequireComponent(typeof(Text))]
public class Numbering : MonoBehaviour
{
    #region Inspector Fields
    [SerializeField] private Text _text = null;
    [SerializeField] private bool _isChip = true;
    #endregion
    
    private long currentValue = 0;

    public void FixValue(long value)
    {
        currentValue = value;
        
        if (zero)
        {
            if (value == 0)
            {
                _text.text = "";
                return;
            }
        }

        if (_isChip)
            _text.text = ConvertNumber.GetChipNumber(currentValue);
        else
            _text.text = ConvertNumber.GetBetNumber(currentValue);

        //if (sequence != null)
        //{
        //    sequenceStop = false;
        //    transform.localScale = Vector3.one;
        //    sequence.Kill(true);
        //}

        realValue = value;
    }
    public void SetValue(long value, float delayTime = 0)
    {
        if (zero)
        {
            if (value == 0)
            {
                _text.text = "";
                currentValue = 0;
            }
            else
            {
                //if (value > currentValue)
                //    OnUpEffect();
                DOTween.To(() => currentValue, (n) => currentValue = n, value, duration).SetDelay(delayTime).SetEase(Ease.Linear).OnUpdate(() => _text.text = ConvertNumber.GetChipNumber(currentValue)).OnComplete(() =>
                {
                    _text.text = ConvertNumber.GetChipNumber(value);
                }).SetId(gameObject.GetInstanceID());
            }
        }
        else
        {
            //if (value > currentValue)
            //    OnUpEffect();
            DOTween.To(() => currentValue, (n) => currentValue = n, value, duration).SetDelay(delayTime).SetEase(Ease.Linear).OnUpdate(() => _text.text = ConvertNumber.GetChipNumber(currentValue)).OnComplete(() =>
            {
                _text.text = ConvertNumber.GetChipNumber(value);
            }).SetId(gameObject.GetInstanceID());
        }

        realValue = value;
    }
    public void SetValueDelay(long value, float delayTime)
    {
        if (zero)
        {
            if (value == 0)
            {
                _text.text = "";
                currentValue = 0;
            }
            else
            {
                //if (value > currentValue)
                //    OnUpEffect();
                DOTween.To(() => currentValue, (n) => currentValue = n, value, duration).SetDelay(delayTime).SetEase(Ease.Linear).OnUpdate(() => _text.text = ConvertNumber.GetChipNumber(currentValue)).SetId(gameObject.GetInstanceID());
            }
        }
        else
        {
            //if (value > currentValue)
            //    OnUpEffect();
            DOTween.To(() => currentValue, (n) => currentValue = n, value, duration).SetDelay(delayTime).SetEase(Ease.Linear).OnUpdate(() => _text.text = ConvertNumber.GetChipNumber(currentValue)).SetId(gameObject.GetInstanceID());
        }

        realValue = value;
    }




    public void FixLPValue(long value, bool dot = true)
    {
        currentValue = value;

        if (zero)
        {
            if (value == 0)
            {
                _text.text = "";
                return;
            }
        }

        //if (_isChip)
            _text.text = ConvertNumber.GetLPNumber(currentValue, _text.fontSize, dot);
        //else
        //    _text.text = ConvertNumber.GetBetNumber(currentValue, dotCount);

        //if (sequence != null)
        //{
        //    sequenceStop = false;
        //    transform.localScale = Vector3.one;
        //    sequence.Kill(true);
        //}

        realValue = value;
    }
    public void SetLPValue(long value, bool dot = true)
    {
        if (currentValue == value)
            return;

        if (zero)
        {
            if (value == 0)
            {
                _text.text = "";
                currentValue = 0;
            }
            else
            {
                //if (value > currentValue)
                //    OnUpEffect();
                DOTween.To(() => currentValue, (n) => currentValue = n, value, duration).SetEase(Ease.Linear).OnUpdate(() => _text.text = ConvertNumber.GetLPNumber(currentValue, _text.fontSize, dot)).OnComplete(()=>
                {
                    _text.text = ConvertNumber.GetLPNumber(value, _text.fontSize, dot);
                }).SetId(gameObject.GetInstanceID());
            }
        }
        else
        {
            //if (value > currentValue)
            //    OnUpEffect();
            DOTween.To(() => currentValue, (n) => currentValue = n, value, duration).SetEase(Ease.Linear).OnUpdate(() => _text.text = ConvertNumber.GetLPNumber(currentValue, _text.fontSize, dot)).OnComplete(() =>
            {
                _text.text = ConvertNumber.GetLPNumber(value, _text.fontSize, dot);
            }).SetId(gameObject.GetInstanceID());
        }

        realValue = value;
    }
    public void SetLPValueDelay(long value, float delayTime, bool dot = true)
    {
        if (zero)
        {
            if (value == 0)
            {
                _text.text = "";
                currentValue = 0;
            }
            else
            {
                DOTween.To(() => currentValue, (n) => currentValue = n, value, duration).SetDelay(delayTime).SetEase(Ease.Linear).OnUpdate(() => _text.text = ConvertNumber.GetLPNumber(currentValue, _text.fontSize, dot)).SetId(gameObject.GetInstanceID());
            }
        }
        else
        {
            DOTween.To(() => currentValue, (n) => currentValue = n, value, duration).SetDelay(delayTime).SetEase(Ease.Linear).OnUpdate(() => _text.text = ConvertNumber.GetLPNumber(currentValue, _text.fontSize, dot)).SetId(gameObject.GetInstanceID());
        }

        realValue = value;
    }








    public void FixSLPValue(long value, bool dot = false)
    {
        currentValue = value;

        if (zero)
        {
            if (value == 0)
            {
                _text.text = "";
                return;
            }
        }

        //if (_isChip)
        _text.text = ConvertNumber.GetSLPNumber(currentValue, _text.fontSize, dot);
        //else
        //    _text.text = ConvertNumber.GetBetNumber(currentValue, dotCount);

        //if (sequence != null)
        //{
        //    sequenceStop = false;
        //    transform.localScale = Vector3.one;
        //    sequence.Kill(true);
        //}

        realValue = value;
    }
    public void SetSLPValue(long value, bool dot = false)
    {
        if (currentValue == value)
            return;

        if (zero)
        {
            if (value == 0)
            {
                _text.text = "";
                currentValue = 0;
            }
            else
            {
                //if (value > currentValue)
                //    OnUpEffect();
                DOTween.To(() => currentValue, (n) => currentValue = n, value, duration).SetEase(Ease.Linear).OnUpdate(() => _text.text = ConvertNumber.GetSLPNumber(currentValue, _text.fontSize, dot)).OnComplete(() =>
                {
                    _text.text = ConvertNumber.GetSLPNumber(value, _text.fontSize, dot);
                }).SetId(gameObject.GetInstanceID());
            }
        }
        else
        {
            //if (value > currentValue)
            //    OnUpEffect();
            DOTween.To(() => currentValue, (n) => currentValue = n, value, duration).SetEase(Ease.Linear).OnUpdate(() => _text.text = ConvertNumber.GetSLPNumber(currentValue, _text.fontSize, dot)).OnComplete(() =>
            {
                _text.text = ConvertNumber.GetSLPNumber(value, _text.fontSize, dot);
            }).SetId(gameObject.GetInstanceID());
        }

        realValue = value;
    }
    public void SetSLPValueDelay(long value, float delayTime, bool dot = false)
    {
        if (zero)
        {
            if (value == 0)
            {
                _text.text = "";
                currentValue = 0;
            }
            else
            {
                DOTween.To(() => currentValue, (n) => currentValue = n, value, duration).SetDelay(delayTime).SetEase(Ease.Linear).OnUpdate(() => _text.text = ConvertNumber.GetSLPNumber(currentValue, _text.fontSize, dot)).SetId(gameObject.GetInstanceID());
            }
        }
        else
        {
            DOTween.To(() => currentValue, (n) => currentValue = n, value, duration).SetDelay(delayTime).SetEase(Ease.Linear).OnUpdate(() => _text.text = ConvertNumber.GetSLPNumber(currentValue, _text.fontSize, dot)).SetId(gameObject.GetInstanceID());
        }

        realValue = value;
    }






    public void FixSignValue(long value)
    {
        currentValue = value;

        if (zero)
        {
            if (value == 0)
            {
                _text.text = "";
                return;
            }
        }

        if (_isChip)
        {
            if (currentValue > 0)
            {
                _text.color = Color.green;
                _text.text = "+" + ConvertNumber.GetChipNumber(currentValue);
            }
            else
            {
                _text.color = Color.red;
                _text.text = ConvertNumber.GetChipNumber(currentValue);
            }
        }
        else
        {
            if (currentValue > 0)
            {
                _text.color = Color.green;
                _text.text = "+" + ConvertNumber.GetBetNumber(currentValue);
            }
            else
            {
                _text.color = Color.red;
                _text.text = ConvertNumber.GetBetNumber(currentValue);
            }
        }

        realValue = value;
    }
    public void SetSignValue(long value)
    {
        if (zero)
        {
            if (value == 0)
            {
                _text.text = "";
                currentValue = 0;
            }
            else
            {
                //if (value > currentValue)
                //    OnUpEffect();

                DOTween.To(() => currentValue, (n) => currentValue = n, value, duration).SetEase(Ease.Linear).OnUpdate(() =>
                {
                    if (currentValue > 0)
                    {
                        _text.color = Color.green;
                        _text.text = "+" + ConvertNumber.GetChipNumber(currentValue);
                    }
                    else
                    {
                        _text.color = Color.red;
                        _text.text = ConvertNumber.GetChipNumber(currentValue);
                    }

                }).SetId(gameObject.GetInstanceID());

            }
        }
        else
        {
            //if (value > currentValue)
            //    OnUpEffect();
            DOTween.To(() => currentValue, (n) => currentValue = n, value, duration).SetEase(Ease.Linear).OnUpdate(() =>
            {
                if (currentValue > 0)
                {
                    _text.color = Color.green;
                    _text.text = "+" + ConvertNumber.GetChipNumber(currentValue);
                }
                else
                {
                    _text.color = Color.red;
                    _text.text = ConvertNumber.GetChipNumber(currentValue);
                }
            }).SetId(gameObject.GetInstanceID());
        }

        realValue = value;
    }

    private void OnUpEffect()
    {
        sequenceStop = false;

        if (sequence != null)
        {
            if (sequence.IsActive())
            {
                if (!sequence.IsPlaying())
                {
                    sequence = DOTween.Sequence();

                    sequence.Append(transform.DOScale(1.2f, 0.15f).SetEase(Ease.InBack))
                            .Append(transform.DOScale(1.0f, 0.15f).SetEase(Ease.InBack)).OnStepComplete(() =>
                            {
                                if (sequenceStop)
                                {
                                    transform.localScale = Vector3.one;
                                    sequence.Kill(true);
                                }
                            }).SetLoops(-1);
                }
            }
            else
            {
                sequence = DOTween.Sequence();

                sequence.AppendInterval(0.1f).Append(transform.DOScale(1.2f, 0.15f).SetEase(Ease.InBack))
                        .Append(transform.DOScale(1.0f, 0.15f).SetEase(Ease.InBack)).OnStepComplete(() =>
                        {
                            if (sequenceStop)
                            {
                                transform.localScale = Vector3.one;
                                sequence.Kill(true);
                            }
                        }).SetLoops(-1);
            }
        }
        else
        {
            sequence = DOTween.Sequence();

            sequence.AppendInterval(0.1f).Append(transform.DOScale(1.2f, 0.15f).SetEase(Ease.InBack))
                    .Append(transform.DOScale(1.0f, 0.15f).SetEase(Ease.InBack)).OnStepComplete(() =>
                    {
                        if (sequenceStop)
                        {
                            transform.localScale = Vector3.one;
                            sequence.Kill(true);
                        }
                    }).SetLoops(-1);
        }
    }

    private void OnDestroy()
    {
        DOTween.Kill(gameObject.GetInstanceID());
    }

    //private void OnDisable()
    //{
    //    if (sequence != null)
    //    {
    //        sequenceStop = false;
    //        transform.localScale = Vector3.one;
    //        sequence.Kill(true);
    //    }
    //}

    //private void Update()
    //{
    //    if (Input.GetKeyDown(KeyCode.A))
    //        SetLPValue(realValue + 123456);

    //    if (Input.GetKey(KeyCode.C))
    //    {
    //        if (sequence != null)
    //        {
    //            if (!sequence.IsPlaying())
    //            {
    //                sequenceStop = false;
    //                sequence = DOTween.Sequence();

    //                sequence.Append(transform.DOScale(1.2f, 0.15f).SetEase(Ease.InBack))
    //                        .Append(transform.DOScale(1.0f, 0.15f).SetEase(Ease.InBack)).OnStepComplete(() =>
    //                {
    //                    if (sequenceStop)
    //                        sequence.Kill(true);
    //                }).SetLoops(-1);
    //            }
    //        }
    //        else
    //        {
    //            sequenceStop = false;
    //            sequence = DOTween.Sequence();

    //            sequence.Append(transform.DOScale(1.2f, 0.15f).SetEase(Ease.InBack))
    //                    .Append(transform.DOScale(1.0f, 0.15f).SetEase(Ease.InBack)).OnStepComplete(() =>
    //            {
    //                if (sequenceStop)
    //                    sequence.Kill(true);
    //            }).SetLoops(-1);
    //        }
    //    }

    //    if (Input.GetKey(KeyCode.D))
    //    {
    //        sequence.SmoothRewind();
    //    }

    //}

    private float duration = 0.7f;
    private bool sequenceStop = false;
    private Sequence sequence = null;
    public long realValue = 0;
    public bool zero = false;

}
