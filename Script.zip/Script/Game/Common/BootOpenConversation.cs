﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using System.Linq;
using System;
using Spine.Unity;
using ForuOnes.T3.LuckyTeenPatti.Table;

namespace ForuOnes.T3.LuckyTeenPatti
{
    public class BootOpenConversation : MonoBehaviour
    {
        #region Inspector Fields
        [SerializeField] private int _contentId = 0;        
        [SerializeField] private bool _main = false;

        [SerializeField] private Transform _bootOpenPanel = null;
        [SerializeField] private LocalizationText _message = null;
        #endregion

        // Start is called before the first frame update
        void Start()
        {
            sequence = DOTween.Sequence();

            sequence.Append(_bootOpenPanel.DOScale(Vector3.one, 1.0f).SetEase(Ease.OutBounce))
                    .AppendInterval(10.0f)
                    .Append(_bootOpenPanel.DOScale(Vector3.zero, 0.5f).SetEase(Ease.InOutBack))
                    .OnComplete(() =>
                    {
                        sequence.Restart();
                        sequence.Pause();
                        OnBootPanelOpen();
                    });

            sequence.Pause();

            gameModeDataList = GameModeTable.Instance.GetDataList(_contentId, _main);
        }

        private void OnBootPanelOpen()
        {
            if (gameRoomTableDataList.Count > 0)
            {
                _message.SetString(LocalizationSentenceTable.Instance.GetString(10055).Replace("{0}", ConvertNumber.GetChipNumber(gameRoomTableDataList[0].BootChip))
                                                                                       .Replace("{1}", LocalizationSentenceTable.Instance.GetString(GameModeTable.Instance.GetData(gameRoomTableDataList[0].GameModeId).GameModeNameId)));

                gameRoomTableDataList.RemoveAt(0);
                sequence.Restart();
            }
        }

        public void OnBootOpenPanel(List<int> indexList)
        {
            for (int i = 0; i < indexList.Count; i++)
            {
                GameRoomTableData data = GameRoomTable.Instance.GetData(indexList[i]);

                if (gameModeDataList.Contains(GameModeTable.Instance.GetData(data.GameModeId)))
                {
                    gameRoomTableDataList.Add(data);
                }
            }

            gameRoomTableDataList = gameRoomTableDataList.OrderBy(x => x.BootChip).ToList();

            OnBootPanelOpen();
        }

        private void OnDisable()
        {
            gameRoomTableDataList.Clear();
            sequence.Restart();
            sequence.Pause();
        }

        private void OnDestroy()
        {
            sequence.Kill();

            gameRoomTableDataList.Clear();
            gameRoomTableDataList = null;

            gameModeDataList.Clear();
            gameModeDataList = null;
        }

        private List<GameRoomTableData> gameRoomTableDataList = new List<GameRoomTableData>();
        private List<GameModeTableData> gameModeDataList = new List<GameModeTableData>();
        private Sequence sequence = null;
    }
}
