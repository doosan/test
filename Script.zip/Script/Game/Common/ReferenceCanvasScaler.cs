﻿using UnityEngine;
using UnityEngine.UI;

namespace Wolfship.UI {

	[RequireComponent(typeof(CanvasScaler))]
	public class ReferenceCanvasScaler : MonoBehaviour 
    {
        public static readonly Vector2 CanvasReferenceResolution = new Vector2(1920.0f, 1200.0f);

        public static float CanvasReferenceAspect
        {

            get { return CanvasReferenceResolution.x / CanvasReferenceResolution.y; }
        }

		private enum ScreenMatchMode {

			Expand,
			ShrinkHorizontalOnly,
			ShrinkVerticalOnly
		}

		#region Inspector Fields
		[SerializeField] private ScreenMatchMode _screenMatchMode = ScreenMatchMode.Expand;
		#endregion

		#region MonoBehaviour Messages
		private void OnEnable()
        {
            var canvasScaler = GetComponent<CanvasScaler>();
			canvasScaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
			canvasScaler.referenceResolution = CanvasReferenceResolution;

			switch (_screenMatchMode) {

			case ScreenMatchMode.Expand:
				canvasScaler.screenMatchMode = CanvasScaler.ScreenMatchMode.Expand;
				break;

			case ScreenMatchMode.ShrinkHorizontalOnly:
				canvasScaler.screenMatchMode = (float)Screen.width / Screen.height > CanvasReferenceAspect
					? CanvasScaler.ScreenMatchMode.Shrink
					: CanvasScaler.ScreenMatchMode.Expand;
				break;

			case ScreenMatchMode.ShrinkVerticalOnly:
				canvasScaler.screenMatchMode = (float)Screen.width / Screen.height < CanvasReferenceAspect
					? CanvasScaler.ScreenMatchMode.Shrink
					: CanvasScaler.ScreenMatchMode.Expand;
				break;
			}
		}
		#endregion
	}
}
