﻿using System.Collections;
using System.Collections.Generic;
using UniRx;
using UnityEngine;
using UnityEngine.UI;


namespace ForuOnes.T3.LuckyTeenPatti
{
    public class DropLanguageItem : MonoBehaviour
    {
        private void Start()
        {
            Text _text = GetComponent<Text>();

            _text.ObserveEveryValueChanged(x => x.text)
                .DistinctUntilChanged().Subscribe(
                text =>
                {
                    FontManager.Instance.ForceConvert(_text, text);
                }).AddTo(this);
        }
    }
}
