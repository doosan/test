﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Spine.Unity;


public class DirectSpine : MonoBehaviour
{
    #region Inspector Fields
    [SerializeField] protected SkeletonGraphic _directSpine = null;
    #endregion

    public IEnumerator OnSpine(string ani, bool loop = false, float dealyTime = 0)
    {
        yield return new WaitForSeconds(dealyTime);        
        _directSpine.gameObject.SetActive(true);
        
        Spine.TrackEntry trackEntry = _directSpine.AnimationState.SetAnimation(0, ani, loop);

        if (!loop)
        {
            trackEntry.Complete += ((track) =>
            {
                _directSpine.Skeleton.SetToSetupPose();
                _directSpine.gameObject.SetActive(false);
            });
        }
    }

    public void CloseSpine()
    {
        if (_directSpine.gameObject.activeSelf)
        {
            if (_directSpine.Skeleton != null)
                _directSpine.Skeleton.SetToSetupPose();
        }
        _directSpine.gameObject.SetActive(false);
    }
}

