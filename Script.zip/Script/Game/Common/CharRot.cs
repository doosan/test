﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class CharRot : MonoBehaviour , IBeginDragHandler, IDragHandler
{
    [SerializeField] private Transform tChar = null;

    private float x = 0;
    private Quaternion quaternion = Quaternion.identity;

    void Start()
    {
        quaternion = tChar.localRotation;
    }

    void OnDisable()
    {
        ResetRot();
    }

    public void ResetRot()
    {
        tChar.localRotation = quaternion;
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        x = eventData.position.x;
    }

    public void OnDrag(PointerEventData eventData)
    {
        tChar.Rotate(Vector3.up * (x - eventData.position.x) * 0.5f, Space.World);
        x = eventData.position.x;
    }
}
