﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace ForuOnes.T3.LuckyTeenPatti
{
    public class SetColorGraphic : MonoBehaviour
    {
        #region Inspector Fields
        [SerializeField] private Graphic _graphic = null;

        [SerializeField] private Color _onColor = Color.white;
        [SerializeField] private Color _offColor = Color.white;
        #endregion

        public void SetColor(bool flag)
        {
            if(flag)
                _graphic.color = _onColor;
            else
                _graphic.color = _offColor;
        }
    }
}
