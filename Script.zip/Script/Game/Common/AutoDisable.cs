﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AutoDisable : MonoBehaviour
{
    #region Inspector Fields
    [SerializeField] private GameObject _parent = null;
    [SerializeField] private float _fTotalTime = 0;
    #endregion

    private void Awake()
    {
        particleSystems = GetComponentsInChildren<ParticleSystem>();
    }

    private void OnEnable()
    {
        if (particleSystems == null)
            particleSystems = GetComponentsInChildren<ParticleSystem>();

        for (int i = 0; i < particleSystems.Length; i++)
        {
            particleSystems[i].time = 0;
            particleSystems[i].Play();
        }

        if (_fTotalTime != -1)
            StartCoroutine(OnRelease());
    }

    private void OnDisable()
    {
        if (gameObject.activeSelf)
        {
            gameObject.SetActive(false);
            if (_parent != null)
                _parent.gameObject.SetActive(false);
        }
    }

    IEnumerator OnRelease()
    {
        yield return new WaitForSeconds(_fTotalTime);
        gameObject.SetActive(false);
        if (_parent != null)
            _parent.gameObject.SetActive(false);
    }

    private ParticleSystem[] particleSystems = null;
}
