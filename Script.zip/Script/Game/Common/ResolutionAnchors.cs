﻿using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResolutionAnchors : MonoBehaviour
{
    public float offSet = 35.0f;
    public static readonly Vector2 CanvasReferenceResolution = new Vector2(1920.0f, 1200.0f);
    
    public static float CanvasReferenceAspect
    {
        get { return CanvasReferenceResolution.x / CanvasReferenceResolution.y; }
    }

    // Use this for initialization
    void Awake ()
    {
        float ratio = ((float)Screen.width / Screen.height) - CanvasReferenceAspect;
        
        if (ratio > 0.3f)
        {
            RectTransform rectTransform = transform.GetComponent<RectTransform>();

            ratio = rectTransform.anchorMin.x == 1 ? ratio * -1 : ratio;

            rectTransform.anchoredPosition = new Vector3(rectTransform.anchoredPosition.x + ratio * offSet, rectTransform.anchoredPosition.y);
        }
    }
}
