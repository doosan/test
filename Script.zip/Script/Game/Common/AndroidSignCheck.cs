﻿using UnityEngine;

public static class AndroidSignCheck
{
    private const string c_PackageName = "com.t3.luckyteenpatti";

    public static byte[] GetSignature()
    {
        //Player = new UnityPlayer();
        AndroidJavaClass Player = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
        //Activity = Player.currentActivity;
        AndroidJavaObject Activity = Player.GetStatic<AndroidJavaObject>("currentActivity");
        //PackageManager = Activity.getPackageManager();
        AndroidJavaObject PackageManager = Activity.Call<AndroidJavaObject>("getPackageManager");
        //GET_SIGNATURES = PackageManager.GET_SIGNATURES;
        int GET_SIGNATURES = PackageManager.GetStatic<int>("GET_SIGNATURES");
        //PackageInfo = PackageManager.getPackageInfo("com.ztx.uni", PackageManager.GET_SIGNATURES);
        AndroidJavaObject PackageInfo = PackageManager.Call<AndroidJavaObject>("getPackageInfo", c_PackageName,
            GET_SIGNATURES);
        //Signatures = PackageInfo.signatures;
        AndroidJavaObject[] Signatures = PackageInfo.Get<AndroidJavaObject[]>("signatures");
        //return Signatures[0].toByteArray();
        return (Signatures != null && Signatures.Length > 0) ? Signatures[0].Call<byte[]>("toByteArray") : null;
    }

    public static string GetPublicKey()
    {
        byte[] Signatures = GetSignature();

        if (Signatures != null)
        {
            //CCertificateFactory = new CertificateFactory();
            AndroidJavaClass CCertificateFactory = new AndroidJavaClass("java.security.cert.CertificateFactory");
            //OCertFactory = CCertificateFactory.getInstance();
            AndroidJavaObject OCertFactory = CCertificateFactory.CallStatic<AndroidJavaObject>("getInstance", "X.509");
            //OByteArrayInputStream = new ByteArrayInputStream(Signatures);
            AndroidJavaObject OByteArrayInputStream = new AndroidJavaObject("java.io.ByteArrayInputStream", Signatures);
            //OX509Certificate = OCertFactory.generateCertificate(OByteArrayInputStream);
            AndroidJavaObject OX509Certificate = OCertFactory.Call<AndroidJavaObject>("generateCertificate",
                OByteArrayInputStream);
            //OPublicKey = OX509Certificate.getPublicKey();
            AndroidJavaObject OPublicKey = OX509Certificate.Call<AndroidJavaObject>("getPublicKey");

            string publickey = OPublicKey.Call<string>("toString");
            AndroidJavaObject CString = new AndroidJavaObject("java/lang/String", publickey);
            int start = CString.Call<int>("indexOf", "modulus");
            int end = CString.Call<int>("indexOf", "public");

            if (start >= 0 && end >= 0)
            {
                return CString.Call<string>("substring", start + 8, end - 1);
            }
        }

        return null;
    }
}
