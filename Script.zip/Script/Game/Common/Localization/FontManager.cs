﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Pie;
using Unity8bitConverter;
using Unity8bitConverter.common;
using System;


namespace ForuOnes.T3.LuckyTeenPatti
{
    public class FontManager : MonoBehaviourSingleton<FontManager>
    {
        #region Inspector Fields
        [SerializeField] private Font hindi = null;
        #endregion


        #region Override from MonoBehaviourSingleton<FontManager>
        public override bool IsGlobal
        {
            get { return true; }
        }
        #endregion

        // Use this for initialization
        void Start()
        {
            uniConv.Initialize();
        }      

        public void ConvertText(Text text, string str, Font font, bool isBold)
        {
            if (PlayerPrefsManager.Instance.languageType == eLanguageType.TYPE_INDIA)
            {
                text.font = hindi;
                text.text = uniConv.Convert(str, RevLangConstants.Lang_Hindi);
            }
            else
            {
                text.font = font;
                text.text = str;
            }
        }

        public void ChangeFont(Text text, string str, Font font, bool isBold)
        {
            if (PlayerPrefsManager.Instance.languageType == eLanguageType.TYPE_INDIA)
            {
                text.font = hindi;
            }
            else
            {
                text.font = font;
                text.text = str;
            }
        }

        public void ConvertText(Text text, int id)
        {

        }
        public void ConvertText(Text text, string str)
        {

        }

       

        public void ForceConvert(Text text, string str)
        {
            text.text = uniConv.Convert(str, RevLangConstants.Lang_Hindi);
        }

        public string GetConvertString(string str)
        {
            return uniConv.Convert(str, RevLangConstants.Lang_Hindi);
        }

        protected override void OnDestroy()
        {
            base.OnDestroy();
            uniConv = null;
        }

        private IConverter uniConv = new UnicodeConverter();
    }
}
