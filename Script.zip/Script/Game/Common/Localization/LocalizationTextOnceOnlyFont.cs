﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Serialization;
using UnityEngine.Events;
using UnityEngine.EventSystems;

namespace ForuOnes.T3.LuckyTeenPatti
{
    public class LocalizationTextOnceOnlyFont : LocalizationText
    {
        //protected override void Awake()
        //{
        //    base.Awake();
        //    str = LocalizationSentenceTable.Instance.GetString(m_Index);
        //    FontManager.Instance.ChangeFont(m_TargetText, str, m_Font, m_Bold);
        //}

        protected override void ChangeLanguage()
        {
            if (languageType != PlayerPrefsManager.Instance.languageType)
            {
                languageType = PlayerPrefsManager.Instance.languageType;

                FontManager.Instance.ChangeFont(m_TargetText, str, m_Font, m_Bold);
            }
        }
    }
}
