﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Serialization;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using ForuOnes.T3.LuckyTeenPatti.Table;

namespace ForuOnes.T3.LuckyTeenPatti
{
    public class LocalizationTextOnce : LocalizationText
    {
        protected override void Awake()
        {
            base.Awake();
            str = LocalizationSentenceTable.Instance.GetString(m_Index);
            FontManager.Instance.ConvertText(m_TargetText, str, m_Font, m_Bold);
        }

        protected override void OnEnable()
        {
            ChangeLanguage();
        }
    }
}
