﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Serialization;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using ForuOnes.T3.LuckyTeenPatti.Table;

namespace ForuOnes.T3.LuckyTeenPatti
{
    [RequireComponent(typeof(Text))]
    public class LocalizationText : UIBehaviour
    {
        #region Inspector Fields
        [SerializeField] protected RectTransform m_RectTransform = null;
        [SerializeField] protected Text m_TargetText = null;
        [SerializeField] protected Font m_Font = null;
        [SerializeField] protected int m_Index = 0;
        [SerializeField] protected int m_FontSize = 0;
        [SerializeField] protected string m_Str = string.Empty;
        [SerializeField] protected bool m_Bold = true;
        #endregion

        public RectTransform targetRectTransform { get { return m_RectTransform; } set { SetPropertyUtilityC.SetClass(ref m_RectTransform, value); } }
        public Text targetText { get { return m_TargetText; } set { SetPropertyUtilityC.SetClass(ref m_TargetText, value); } }

        protected override void Awake()
        {
            if (m_TargetText == null)
            {
                m_TargetText = GetComponent<Text>();
            }
            if (m_Font == null)
            {
                m_Font = m_TargetText.font;
                m_FontSize = m_TargetText.fontSize;
                languageType = PlayerPrefsManager.Instance.languageType;
            }
        }

        protected override void OnEnable()
        {
            ChangeLanguage();
        }

        protected virtual void ChangeLanguage()
        {
            if (languageType != PlayerPrefsManager.Instance.languageType)
            {
                languageType = PlayerPrefsManager.Instance.languageType;
                str = LocalizationSentenceTable.Instance.GetString(m_Index);
                FontManager.Instance.ConvertText(m_TargetText, str, m_Font, m_Bold);
            }
        }

        public void SetString(string _str)
        {
            if (m_TargetText == null)
            {
                m_TargetText = GetComponent<Text>();
            }
            if (m_Font == null)
            {
                m_Font = m_TargetText.font;
                m_FontSize = m_TargetText.fontSize;                
            }
            languageType = PlayerPrefsManager.Instance.languageType;
            str = _str;
            targetText.text = str;
            ChangeLanguage();
        }

        public void SetIndex(int _index)
        {
            if (m_TargetText == null)
            {
                m_TargetText = GetComponent<Text>();
            }

            if (m_Font == null)
            {
                m_Font = m_TargetText.font;
                m_FontSize = m_TargetText.fontSize;
                languageType = PlayerPrefsManager.Instance.languageType;
            }

            m_Index = _index;
            if (m_Index != 0)
            {
                str = LocalizationSentenceTable.Instance.GetString(m_Index);
                FontManager.Instance.ConvertText(m_TargetText, str, m_Font, m_Bold);
            }
            else
            {
                str = string.Empty;
                targetText.text = "";
            }
        }

        public void FixString(string _str)
        {
            targetText.text = _str;
        }


        protected string str = string.Empty;
        protected eLanguageType languageType = eLanguageType.TYPE_ENG;
    }
}
