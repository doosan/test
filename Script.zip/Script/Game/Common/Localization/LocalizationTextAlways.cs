﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Serialization;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using ForuOnes.T3.LuckyTeenPatti.Table;

namespace ForuOnes.T3.LuckyTeenPatti
{
    public class LocalizationTextAlways : LocalizationText
    {
        protected override void Awake()
        {
            base.Awake();
            if (m_Index != 0)
                str = LocalizationSentenceTable.Instance.GetString(m_Index);
            FontManager.Instance.ConvertText(m_TargetText, str, m_Font, m_Bold);
        }

        protected override void OnEnable()
        {
            base.OnEnable();
            PlayerPrefsManager.Instance.changeLanguage += ChangeLanguage;
        }

        protected override void OnDisable()
        {
            if (PlayerPrefsManager.Instance != null)
                PlayerPrefsManager.Instance.changeLanguage -= ChangeLanguage;
        }

        protected override void OnDestroy()
        {
            if (PlayerPrefsManager.Instance != null)
                PlayerPrefsManager.Instance.changeLanguage -= ChangeLanguage;
        }
    }
}
