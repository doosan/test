﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Serialization;
using UnityEngine.Events;
using UnityEngine.EventSystems;

namespace ForuOnes.T3.LuckyTeenPatti
{
    public class LocalizationTextOnceMix : LocalizationText
    {
        protected override void ChangeLanguage()
        {
            //if (languageType != PlayerPrefsManager.Instance.languageType)
            {
                languageType = PlayerPrefsManager.Instance.languageType;
                FontManager.Instance.ConvertText(m_TargetText, str, m_Font, m_Bold);
            }
        }
    }
}
