﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Serialization;
using UnityEngine.Events;
using UnityEngine.EventSystems;

namespace ForuOnes.T3.LuckyTeenPatti
{

    public class LocalizationTextAlwaysMix : LocalizationText
    {
        //protected override void Awake()
        //{
        //    base.Awake();
        //    FontManager.Instance.ConvertText(m_TargetText, str, m_Font, m_Bold);
        //}

        protected override void OnEnable()
        {
            base.OnEnable();
            PlayerPrefsManager.Instance.changeLanguage += ChangeLanguage;
        }

        protected override void OnDisable()
        {
            if (PlayerPrefsManager.Instance != null)
                PlayerPrefsManager.Instance.changeLanguage -= ChangeLanguage;
        }

        protected override void OnDestroy()
        {
            if (PlayerPrefsManager.Instance != null)
                PlayerPrefsManager.Instance.changeLanguage -= ChangeLanguage;
        }

        protected override void ChangeLanguage()
        {
            //if (languageType != PlayerPrefsManager.Instance.languageType)
            {
                languageType = PlayerPrefsManager.Instance.languageType;
                FontManager.Instance.ConvertText(m_TargetText, str, m_Font, m_Bold);
            }
        }
    }
}
