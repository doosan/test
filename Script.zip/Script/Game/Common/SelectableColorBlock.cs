﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Serialization;

public class SelectableColorBlock : MonoBehaviour
{
    [FormerlySerializedAs("colors")]
    [SerializeField] public ColorBlock m_Colors = ColorBlock.defaultColorBlock;

    [SerializeField] private Graphic targetGraphic = null;

    public void ColorTween(Color targetColor, bool instant)
    {
        if (targetGraphic == null)
        {
            return;
        }
        //targetGraphic.color = targetColor;
        targetGraphic.CrossFadeColor(targetColor, (!instant) ? m_Colors.fadeDuration : 0f, true, true);
    }
}
