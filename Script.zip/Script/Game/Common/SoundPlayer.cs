﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pie.Logging;
using ILogger = Pie.Logging.ILogger;

[RequireComponent(typeof(AudioSource))]
public class SoundPlayer : MonoBehaviour
{
    [SerializeField] private AudioSource _audioSource = null;

    void Awake()
    {
        _logger = LogManager.Instance.GetLogger(GetType());
    }

    public void Play(string name)
    {
        if (ResourcesManager.Instance == null)
            return;

        AudioClip clip = ResourcesManager.Instance.GetAudioClip(name);

        if (clip == null)
        {
            _logger.Warn(name + "에 대한 사운드가 없습니다.");
            return;
        }

        _audioSource.PlayOneShot(clip);
    }

    public void Play(AudioClip clip)
    {
        if (clip != null)
            _audioSource.PlayOneShot(clip);
    }

    public void Stop()
    {
        _audioSource.Stop();
    }

    private ILogger _logger;
}
