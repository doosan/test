﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Pool<T> where T : MonoBehaviour
{
	T origin;

	List<T> objects;
	List<T> used;

	Transform tmParent;

    void OnDestory()
    {
        objects.Clear();
        objects = null;

        used.Clear();
        used = null;
    }

	public Pool(T _origin, Transform _parent)
	{
		origin = _origin;

		objects = new List<T>();
		used = new List<T>();

		tmParent = _parent;
	}	

	public T Get()
	{
		if(0 >= objects.Count)
		{
			T add = GameObject.Instantiate<T>(origin);
			objects.Add(add);
		}

		T obj = objects[0];
		objects.RemoveAt(0);

		used.Add(obj);

		return obj;
	}

	public void Release(T obj)
	{
		if(true == used.Contains(obj))
		{
			used.Remove(obj);

			objects.Add(obj);

			obj.transform.SetParent(tmParent);
		}
	}

	public void Clear()
	{
		for(int count = 0; count < objects.Count; ++count)
		{
			GameObject.Destroy(objects[count].gameObject);
		}

		objects.Clear();

		for (int count = 0; count < used.Count; ++count)
		{
			GameObject.Destroy(used[count].gameObject);
		}
		used.Clear();
	}

    void OnDestroy()
    {
        objects.Clear();
        objects = null;

        used.Clear();
        used = null;
    }
}

public class Pool
{
    GameObject origin;

    List<GameObject> objects;
    List<GameObject> used;

    Transform tmParent;

    public Pool(GameObject _origin, GameObject _parent)
    {
        origin = _origin;

        objects = new List<GameObject>();
        used = new List<GameObject>();

        tmParent = _parent.transform;
    }

    public GameObject Get()
    {
        if (0 >= objects.Count)
        {
            GameObject add = GameObject.Instantiate<GameObject>(origin);
            objects.Add(add);
        }

        GameObject obj = objects[0];
        objects.RemoveAt(0);

        used.Add(obj);

        return obj;
    }

    public void Release(GameObject obj)
    {
        if (true == used.Contains(obj))
        {
            used.Remove(obj);

            objects.Add(obj);

            obj.transform.SetParent(tmParent);
        }
    }

    public void Clear()
    {
        for (int count = 0; count < objects.Count; ++count)
        {
            GameObject.Destroy(objects[count].gameObject);
        }

        objects.Clear();

        for (int count = 0; count < used.Count; ++count)
        {
            GameObject.Destroy(used[count].gameObject);
        }
        used.Clear();
    }
}

