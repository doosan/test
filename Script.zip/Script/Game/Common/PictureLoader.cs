﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using ForuOnes.T3.LuckyTeenPatti.Table;
using UnityEngine.Networking;

namespace ForuOnes.T3.LuckyTeenPatti
{
    public class PictureLoader : MonoBehaviour
    {
        #region Inspector Fields
        [SerializeField] private Sprite _baseSprite = null;
        [SerializeField] private bool _isAuto = true;
        #endregion

        public void SetPicture(int _pictureDataId, string _userId, Image _image)
        {
            apply = true;
            picture = _image;
            userId = _userId;
            pictureDataId = _pictureDataId;

            if (pictureDataId != 0)
                picture.sprite = ResourcesManager.Instance.GetSprite(GamePictureTable.Instance.GetData(pictureDataId).Image);
            else
            {
                if(gameObject.activeInHierarchy)
                {
                    StartCoroutine(ISetPicture());
                }
            }
        }

        private void OnEnable()
        {
            if (!apply)
                return;

            if (picture != null)
            {
                if (pictureDataId == 0)
                    StartCoroutine(ISetPicture());
            }
        }

        public IEnumerator ISetPicture()
        {
            FacebookImage fbImg = FacebookManager.Instance.GetFacebookImage(userId);

            if (fbImg != null && fbImg.size >= picture.rectTransform.rect.width)
            {
                picture.sprite = fbImg.sprite;
                apply = false;
            }
            else
            {
                if(fbImg != null)
                    picture.sprite = fbImg.sprite;

                string address = "https://graph.facebook.com/{id}/picture?type=large&width={size}&height={size}";          

                address = address.Replace("{id}", userId).Replace("{size}", picture.rectTransform.rect.width.ToString());

               // Debug.Log("https://graph.facebook.com/{id}/picture?type=large&width={size}&height={size}");
                using (UnityWebRequest uwr = UnityWebRequestTexture.GetTexture(address))
                {
                    yield return uwr.SendWebRequest();
                    //yield return www;

                    if (uwr.isNetworkError || uwr.isHttpError)
                    {
                        Debug.Log(uwr.error);
                    }
                    else
                    {
                        var texture = DownloadHandlerTexture.GetContent(uwr);

                        Sprite sprite = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), new Vector2());

                        if (sprite != null)
                        {
                            picture.sprite = sprite;
                            FacebookManager.Instance.AddFacebookImage(userId, texture.width, picture.sprite);
                            apply = false;

                            //else
                            //{
                            //    DestroyImmediate(sprite);
                            //}
                        }
                    }
                }

            }
        }

        private void OnDisable()
        {
            if (uwr != null)
                uwr.Dispose();

            if (_isAuto)
                Release();
        }

        public void Release()
        {
            if (picture != null)
            {
                picture.sprite = _baseSprite;
                picture = null;
            }

            userId = string.Empty;
        }

        private UnityWebRequest uwr;
        private bool apply = false;
        private string userId = string.Empty;
        private int pictureDataId = 0;
        private Image picture = null;
    }
}
