﻿using System.Collections;
using System.Collections.Generic;
using UniRx;
using UnityEngine;
using UnityEngine.UI;


namespace ForuOnes.T3.LuckyTeenPatti
{
    public class DromItemLabel : MonoBehaviour
    {
        private void OnEnable()
        {
            if (_text == null)
                _text = GetComponent<Text>();

            _text.ObserveEveryValueChanged(x => x.text)
               .DistinctUntilChanged().Subscribe(
               text =>
               {
                   FontManager.Instance.ForceConvert(_text, text);
               }).AddTo(disposalbles);
        }

        private void OnDisable()
        {
            disposalbles.Clear();
        }

        private void OnDestroy()
        {
            disposalbles.Clear();
            disposalbles = null;
        }

        private Text _text = null;
        private CompositeDisposable disposalbles = new CompositeDisposable();
    }
}
