﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using ForuOnes.T3.LuckyTeenPatti.Table;

namespace ForuOnes.T3.LuckyTeenPatti
{
    [RequireComponent(typeof(Button))]
    public class ButtonClickSound : MonoBehaviour, IPointerClickHandler
    {
        // Use this for initialization
        void Start()
        {
            _button = GetComponent<Button>();
            data = GameSoundTable.Instance.GetData(soundIndex);
        }

        public void OnPointerClick(PointerEventData pointerEventData)
        {
            if (data == null)
                return;

            if(_button.interactable)
                UISoundManager.Instance.Play(data.SoundResource);
        }

        private Button _button = null;
        private GameSoundTableData data = null;
        public int soundIndex = 10001;
    }


}
