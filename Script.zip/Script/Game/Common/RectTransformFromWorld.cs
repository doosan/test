﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class RectTransformFromWorld : MonoBehaviour
{
    #region Inspector Fields
    [SerializeField] private RectTransform _canvas = null;
    [SerializeField] private RectTransform _thisTransform = null;
    [SerializeField] private Transform _worldTransform = null;
    #endregion

    private void Start()
    {
        Vector2 ViewportPosition = Camera.main.WorldToViewportPoint(_worldTransform.position);

        ViewportPosition.x *= _canvas.sizeDelta.x;
        ViewportPosition.y *= _canvas.sizeDelta.y;

        ViewportPosition.x -= _canvas.sizeDelta.x * _canvas.pivot.x;
        ViewportPosition.y -= _canvas.sizeDelta.y * _canvas.pivot.y;

        _thisTransform.localPosition = ViewportPosition;


        //Vector2 WorldObject_ScreenPosition = new Vector2(
        //((ViewportPosition.x * _canvas.sizeDelta.x) - (_canvas.sizeDelta.x * 0.5f)),
        //((ViewportPosition.y * _canvas.sizeDelta.y) - (_canvas.sizeDelta.y * 0.5f)));
        //_thisTransform.GetComponent<RectTransform>().anchoredPosition = WorldObject_ScreenPosition;
    }
}
