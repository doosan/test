﻿using System;
using UnityEditor;
using UnityEngine.Events; 
 using UnityEngine.EventSystems; 
 using UnityEngine.Serialization;


namespace UnityEngine.UI
{
    /// <summary> 
    /// Simple toggle -- something that has an 'on' and 'off' states: checkbox, toggle button, radio button, etc. 
    /// </summary> 

    [RequireComponent(typeof(RectTransform))]
    public class MultiImageToggle : Selectable, IEventSystemHandler, IPointerClickHandler, ISubmitHandler, ICanvasElement
    {
        /// <summary> 
        ///   <para>Transition mode for the toggle.</para> 
        /// </summary> 
        public MultiImageToggle.ToggleTransition toggleTransition = MultiImageToggle.ToggleTransition.Fade;
        /// <summary> 
        ///   <para>Callback executed when the value of the toggle is changed.</para> 
        /// </summary> 
        public MultiImageToggle.ToggleEvent onValueChanged = new MultiImageToggle.ToggleEvent();
        /// <summary> 
        ///   <para>Graphic affected by the toggle.</para> 
        /// </summary> 
        public Graphic[] graphics = null;
        public SelectableColorBlock[] targetGraphics = null;

        [SerializeField]
        private ToggleGroupsMulti m_Group;
        [SerializeField]
        [FormerlySerializedAs("m_IsActive")]
        [Tooltip("Is the toggle currently on or off?")]
        private bool m_IsOn;


        /// <summary> 
        ///   <para>Group the toggle belongs to.</para> 
        /// </summary> 
        public ToggleGroupsMulti group
        {
            get
            {
                return this.m_Group;
            }
            set
            {
                this.m_Group = value;
                if (!Application.isPlaying)
                    return;
                this.SetToggleGroup(this.m_Group, true);
                this.PlayEffect(true);
            }
        }


        /// <summary> 
        ///   <para>Is the toggle on.</para> 
        /// </summary> 
        public bool isOn
        {
            get
            {
                return this.m_IsOn;
            }
            set
            {
                this.Set(value);
            }
        }


        protected MultiImageToggle()
        {
        }


        //protected override void OnValidate()
        //{
        //    base.OnValidate();
        //    this.Set(this.m_IsOn, false);
        //    this.PlayEffect(this.toggleTransition == MultiImageToggle.ToggleTransition.None);
        //    if (PrefabUtility.GetPrefabType((UnityEngine.Object)this) == PrefabType.Prefab || Application.isPlaying)
        //        return;
        //    CanvasUpdateRegistry.RegisterCanvasElementForLayoutRebuild((ICanvasElement)this);
        //}


        /// <summary> 
        ///   <para>Handling for when the canvas is rebuilt.</para> 
        /// </summary> 
        /// <param name="executing"></param> 
        public virtual void Rebuild(CanvasUpdate executing)
        {
            if (executing != CanvasUpdate.Prelayout)
                return;
            this.onValueChanged.Invoke(this.m_IsOn);
        }


        /// <summary> 
        ///   <para>See ICanvasElement.LayoutComplete.</para> 
        /// </summary> 
        public virtual void LayoutComplete()
        {
        }


        /// <summary> 
        ///   <para>See ICanvasElement.GraphicUpdateComplete.</para> 
        /// </summary> 
        public virtual void GraphicUpdateComplete()
        {
        }


        protected override void OnEnable()
        {
            base.OnEnable();
            this.SetToggleGroup(this.m_Group, false);
            this.PlayEffect(true);
        }


        /// <summary> 
        ///   <para>See MonoBehaviour.OnDisable.</para> 
        /// </summary> 
        protected override void OnDisable()
        {
            this.SetToggleGroup((ToggleGroupsMulti)null, false);
            base.OnDisable();
        }


        protected override void OnDidApplyAnimationProperties()
        {
            for (int i = 0; i < graphics.Length; i++)
            {
                if ((UnityEngine.Object)this.graphics[i] != (UnityEngine.Object)null)
                {
                    bool flag = !Mathf.Approximately(this.graphics[i].canvasRenderer.GetColor().a, 0.0f);
                    if (this.m_IsOn != flag)
                    {
                        this.m_IsOn = flag;
                        this.Set(!flag);
                    }
                }
            }
            base.OnDidApplyAnimationProperties();
        }


        private void SetToggleGroup(ToggleGroupsMulti newGroup, bool setMemberValue)
        {
            ToggleGroupsMulti group = this.m_Group;
            if ((UnityEngine.Object)this.m_Group != (UnityEngine.Object)null)
                this.m_Group.UnregisterToggle(this);
            if (setMemberValue)
                this.m_Group = newGroup;
            if ((UnityEngine.Object)this.m_Group != (UnityEngine.Object)null && this.IsActive())
                this.m_Group.RegisterToggle(this);
            if (!((UnityEngine.Object)newGroup != (UnityEngine.Object)null) || !((UnityEngine.Object)newGroup != (UnityEngine.Object)group) || (!this.isOn || !this.IsActive()))
                return;
            this.m_Group.NotifyToggleOn(this);
        }


        private void Set(bool value)
        {
            this.Set(value, true);
        }

        public void Set(bool value, bool sendCallback)
        {          
            if (this.m_IsOn == value)
                return;
            this.m_IsOn = value;
            if ((UnityEngine.Object)this.m_Group != (UnityEngine.Object)null && this.IsActive() && (this.m_IsOn || !this.m_Group.AnyTogglesOn() && !this.m_Group.allowSwitchOff))
            {
                this.m_IsOn = true;
                this.m_Group.NotifyToggleOn(this);
            }
            this.PlayEffect(this.toggleTransition == MultiImageToggle.ToggleTransition.None);
            if (!sendCallback)
                return;
            this.onValueChanged.Invoke(this.m_IsOn);
        }


        private void PlayEffect(bool instant)
        {
            if (graphics == null)
                return;
            for (int i = 0; i < graphics.Length; i++)
            {
                if ((UnityEngine.Object)this.graphics[i] == (UnityEngine.Object)null)
                    break;
                if (!Application.isPlaying)
                    this.graphics[i].canvasRenderer.SetAlpha(!this.m_IsOn ? 0.0f : 1f);
                else
                    this.graphics[i].CrossFadeAlpha(!this.m_IsOn ? 0.0f : 1f, !instant ? 0.1f : 0.0f, true);
            }
        }


        protected override void Start()
        {
            this.PlayEffect(true);
        }


        private void InternalToggle()
        {
            if (!this.IsActive() || !this.IsInteractable())
                return;
            this.isOn = !this.isOn;
        }


        /// <summary> 
        ///   <para>Handling for when the toggle is 'clicked'.</para> 
        /// </summary> 
        /// <param name="eventData">Current event.</param> 
        public virtual void OnPointerClick(PointerEventData eventData)
        {
            if (eventData.button != PointerEventData.InputButton.Left)
                return;
            this.InternalToggle();
        }


        /// <summary> 
        ///   <para>Handling for when the submit key is pressed.</para> 
        /// </summary> 
        /// <param name="eventData">Current event.</param> 
        public virtual void OnSubmit(BaseEventData eventData)
        {
            this.InternalToggle();
        }


        bool ICanvasElement.IsDestroyed()
        {
            return this.IsDestroyed();
        }



        protected override void DoStateTransition(SelectionState state, bool instant)
        {
            Color color;
            switch (state)
            {
                case Selectable.SelectionState.Normal:
                    color = this.colors.normalColor;
                    if (targetGraphics != null)
                    {
                        for (int i = 0; i < targetGraphics.Length; i++)
                        {
                            targetGraphics[i].ColorTween(targetGraphics[i].m_Colors.normalColor, instant);
                        }
                    }
                    break;
                case Selectable.SelectionState.Highlighted:
                    color = this.colors.highlightedColor;
                    break;
                case Selectable.SelectionState.Pressed:
                    color = this.colors.pressedColor;
                    break;
                case Selectable.SelectionState.Disabled:
                    color = this.colors.disabledColor;
                    if (targetGraphics != null)
                    {
                        for (int i = 0; i < targetGraphics.Length; i++)
                        {
                            targetGraphics[i].ColorTween(targetGraphics[i].m_Colors.disabledColor, instant);
                        }
                    }
                    break;
                default:
                    color = Color.black;
                    break;
            }

            if (base.gameObject.activeInHierarchy)
            {
                switch (this.transition)
                {
                    case Selectable.Transition.ColorTint:
                        ColorTween(color * this.colors.colorMultiplier, instant);
                        break;
                    default:
                        throw new NotSupportedException();
                }
            }
        }

        private void ColorTween(Color targetColor, bool instant)
        {
            if (this.targetGraphic == null)
            {
                return;
            }

           // targetGraphic.CrossFadeColor(targetColor, (!instant) ? this.colors.fadeDuration : 0f, true, true);
        }




        //Transform ICanvasElement.get_transform()
        //{ 
        //  return this.transform; 
        //} 


        /// <summary> 
        ///   <para>Display settings for when a toggle is activated or deactivated.</para> 
        /// </summary> 
        public enum ToggleTransition
        {
            None,
            Fade,
        }


        /// <summary> 
        ///   <para>UnityEvent callback for when a toggle is toggled.</para> 
        /// </summary> 
        [Serializable]
        public class ToggleEvent : UnityEvent<bool>
        {
        }
    }
} 

