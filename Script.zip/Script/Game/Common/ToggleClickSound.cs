﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using ForuOnes.T3.LuckyTeenPatti.Table;

namespace ForuOnes.T3.LuckyTeenPatti
{
    [RequireComponent(typeof(Toggle))]
    public class ToggleClickSound : MonoBehaviour, IPointerClickHandler
    {
        // Use this for initialization
        void Start()
        {
            positiveData = GameSoundTable.Instance.GetData(positiveSoundIndex);
            negativeData = GameSoundTable.Instance.GetData(negativeSoundIndex);

            _toggle = GetComponent<Toggle>();
        }

        public void OnPointerClick(PointerEventData pointerEventData)
        {
            if (gameObject.activeSelf && transform.root.gameObject.activeSelf)
            {
                if (_toggle.isOn)
                {
                    UISoundManager.Instance.Play(positiveData.SoundResource);
                }
                else
                {
                    if (useNegative)
                    {
                        if (negativeData != null)
                            UISoundManager.Instance.Play(negativeData.SoundResource);
                    }
                    else
                    {

                    }
                }
            }
        }

        private GameSoundTableData positiveData = null;
        private GameSoundTableData negativeData = null;

        private Toggle _toggle = null;
        public bool useNegative = true;
        public int positiveSoundIndex = 10001;
        public int negativeSoundIndex = 10002;
    }
}

