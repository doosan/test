﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;
using System.Linq;
using Pie;
using UnityEngine.SceneManagement;
using ForuOnes.T3.LuckyTeenPatti;

public class AssetBundleManager : MonoBehaviourSingleton<AssetBundleManager>
{
    public class AssetbundleInfo
    {
        public string bundle { get; private set; }
        public Hash128 hash128 { get; private set; }

        public AssetbundleInfo(string bundle, Hash128 hash128)
        {
            this.bundle = bundle;
            this.hash128 = hash128;
        }
    }

    [SerializeField] private Image _gage = null;

    #region Override from MonoBehaviourSingleton<AssetBundleManager>
    public override bool IsGlobal
    {
        get { return true; }
    }
    #endregion

    public bool IsDownTable
    {
        get { return downAsset.Contains("tables"); }
    }

    private List<string> downAsset = new List<string>();
    private List<string> depenciAsset = new List<string>();

    private List<AssetbundleInfo> oldAsset = new List<AssetbundleInfo>();
    private List<AssetbundleInfo> newAsset = new List<AssetbundleInfo>();

    public string platformPath = string.Empty;

    public List<string> DepenciesAssetList
    {
        get
        {
            //newAsset.Sort((c1, c2) => depenciAsset.Contains(c1.bundle).CompareTo(depenciAsset.Contains(c2.bundle)));
            return depenciAsset;
        }
    }

    public List<AssetbundleInfo> NewAssetList
    {
        get
        {
            //newAsset.Sort((c1, c2) => depenciAsset.Contains(c1.bundle).CompareTo(depenciAsset.Contains(c2.bundle)));
            return newAsset;
        }
    }


    private void Start()
    {
#if UNITY_IOS
            userId = Device.generation;
#elif UNITY_EDITOR
        platformPath = "Android";
#elif UNITY_ANDROID
            platformPath = "Android";
#elif UNITY_WebGL
            platformPath = "WebGL";
#endif
    }

    public static void CleanAssetBundleCache()
    {
        Debug.Log(Caching.ClearCache() ? "Successfully removed Cache" : "Cache in use");
    }

    public IEnumerator CheckAsset()
    {
        //CleanAssetBundleCache(); yield break;
        newAsset.Clear();
        oldAsset.Clear();
        downAsset.Clear();
        depenciAsset.Clear();

        if (!File.Exists(Path.Combine(Application.persistentDataPath, "AssetBundles/" + platformPath + ".unity3d")))
        {
            yield return StartCoroutine(SaveAndDownload(AcNetworkBase._remoteWebAdress_Patch + platformPath + "/" + "Android", Application.persistentDataPath + "/AssetBundles/", platformPath + ".unity3d"));

            yield return StartCoroutine(LoadFromLocal("Android.unity3d"));

            for (int i = 0; i < oldAsset.Count; i++)
            {
                if (!downAsset.Contains(oldAsset[i].bundle))
                {
                    //Debug.Log(oldAsset[i].bundle.name);
                    downAsset.Add(oldAsset[i].bundle);
                }
            }

            newAsset = oldAsset;
        }
        else
        {
            yield return StartCoroutine(LoadFromLocal("Android.unity3d"));

            for (int i = 0; i < oldAsset.Count; i++)
            {
                if (!File.Exists(Path.Combine(Application.persistentDataPath, "AssetBundles/" + oldAsset[i].bundle + ".unity3d")))
                {
                    if (!downAsset.Contains(oldAsset[i].bundle))
                    {
                        downAsset.Add(oldAsset[i].bundle);
                    }
                }
            }

            //서버
            yield return StartCoroutine(LoadFromCacheOrDownload(AcNetworkBase._remoteWebAdress_Patch + platformPath + "/" + platformPath, (manifest) =>
            {
                bool changed = false;
                for (int i = 0; i < newAsset.Count; i++)
                {
                    if (!File.Exists(Path.Combine(Application.persistentDataPath, "AssetBundles/" + newAsset[i].bundle + ".unity3d")))
                    {
                        if (!downAsset.Contains(newAsset[i].bundle))
                        {
                            changed = true;
                            downAsset.Add(newAsset[i].bundle);
                            continue;
                        }
                    }

                    if (oldAsset.Any(x => x.bundle == newAsset[i].bundle && x.hash128 != newAsset[i].hash128) || !oldAsset.Any(x => x.bundle == newAsset[i].bundle))
                    {
                        Debug.Log(newAsset[i].bundle);
                        if (!downAsset.Contains(newAsset[i].bundle))
                        {
                            downAsset.Add(newAsset[i].bundle);
                            changed = true;
                        }
                    }
                }

                if (changed)
                    downAsset.Add("Android");
            }));
        }
    }

    public IEnumerator LoadObject()
    {
        if (downAsset.Contains("tables"))
        {
            downAsset.Remove("tables");
        }

        if (downAsset.Count > 0)
            TitleManager.Instance.OnGage();



        if (downAsset.Count > 0)
        {
            for (int i = 0; i < downAsset.Count; i++)
            {
                yield return StartCoroutine(SaveAndDownload(AcNetworkBase._remoteWebAdress_Patch + platformPath + "/" + downAsset[i], Application.persistentDataPath + "/AssetBundles/", downAsset[i] + ".unity3d"));
                TitleManager.Instance.SetPatchGage((i + 1) / (float)downAsset.Count);
                if (downAsset.Count - 1 == i)
                {
                    downAsset.Clear();
                    Debug.Log("Cleararareawr");
                }
            }
        }
        else
        {
            TitleManager.Instance.OnFakeGage();
        }
    }

    public void RestartAppForAOS()
    {
        AndroidJavaObject AOSUnityActivity = new AndroidJavaClass("com.unity3d.player.UnityPlayer").GetStatic<AndroidJavaObject>("currentActivity");
        AndroidJavaObject baseContext = AOSUnityActivity.Call<AndroidJavaObject>("getBaseContext");
        AndroidJavaObject intentObj = baseContext.Call<AndroidJavaObject>("getPackageManager").Call<AndroidJavaObject>("getLaunchIntentForPackage", baseContext.Call<string>("getPackageName"));
        AndroidJavaObject componentName = intentObj.Call<AndroidJavaObject>("getComponent");
        AndroidJavaObject mainIntent = intentObj.CallStatic<AndroidJavaObject>("makeMainActivity", componentName);

        AndroidJavaClass intentClass = new AndroidJavaClass("android.content.Intent");
        mainIntent = mainIntent.Call<AndroidJavaObject>("addFlags", intentClass.GetStatic<int>("FLAG_ACTIVITY_NEW_TASK"));
        mainIntent = mainIntent.Call<AndroidJavaObject>("addFlags", intentClass.GetStatic<int>("FLAG_ACTIVITY_CLEAR_TASK"));

        baseContext.Call("startActivity", mainIntent);
        AndroidJavaClass JavaSystemClass = new AndroidJavaClass("java.lang.System");
        JavaSystemClass.CallStatic("exit", 0);

    }

    IEnumerator LoadFromLocal(string assetName)
    {
        var path = Path.Combine(Application.persistentDataPath + "/AssetBundles/", assetName);
        Debug.Log(path);

        AssetBundleCreateRequest req = AssetBundle.LoadFromFileAsync(path);
        yield return req;

        var assetBundle = req.assetBundle;

        if (assetBundle == null)
        {
            Debug.Log("Failed to load AssetBundle!");
            RestartAppForAOS();
            yield break;
        }

        Debug.Log(assetBundle);

        AssetBundleManifest manifest = assetBundle.LoadAsset<AssetBundleManifest>("AssetBundleManifest");

        Debug.Log("manifest: " + manifest);

        foreach (var bundle in manifest.GetAllAssetBundles())
        {
            oldAsset.Add(new AssetbundleInfo(bundle, manifest.GetAssetBundleHash(bundle)));
            Debug.LogFormat("{0}, {1}", bundle, manifest.GetAssetBundleHash(bundle));

            string[] depenci = manifest.GetAllDependencies(bundle);
            for (int i = 0; i < depenci.Length; i++)
            {
                if (!depenciAsset.Contains(depenci[i]))
                    depenciAsset.Add(depenci[i]);
            }
        }

        assetBundle.Unload(true);
    }

    IEnumerator LoadAssetBundle(string uri, System.Action onComplete)
    {
        UnityWebRequest request = UnityWebRequestAssetBundle.GetAssetBundle(uri, 0);
        //var request = UnityWebRequest.Get(uri);
        yield return request.SendWebRequest();

        //Debug.LogFormat("{0}, {1}", request.isHttpError, request.isNetworkError);

        AssetBundle assetBundle = DownloadHandlerAssetBundle.GetContent(request);

        Debug.Log(assetBundle);

        Debug.Log("assetBundle: " + assetBundle);

        AssetBundleManifest manifest = assetBundle.LoadAsset<AssetBundleManifest>("AssetBundleManifest");

        foreach (var bundle in manifest.GetAllAssetBundles())
        {
            Debug.LogFormat("{0}", manifest.GetAssetBundleHash(bundle));

            newAsset.Add(new AssetbundleInfo(bundle, manifest.GetAssetBundleHash(bundle)));
        }

        assetBundle.Unload(false);

        onComplete();
    }

    public IEnumerator LoadFromCacheOrDownload(string uri, System.Action<AssetBundleManifest> onComplete)
    {
        WWW wwwVersion = new WWW(AcNetworkBase._remoteWebAdress_Patch + platformPath + "/" + "version.txt");
        yield return wwwVersion;

        using (WWW www = WWW.LoadFromCacheOrDownload(uri, Convert.ToInt32(wwwVersion.text)))
        {
            yield return www;

            AssetBundle assetBundle = www.assetBundle;

            Debug.Log("assetBundle: " + assetBundle);

            AssetBundleManifest manifest = assetBundle.LoadAsset<AssetBundleManifest>("AssetBundleManifest");


            Debug.Log("manifest: " + manifest);

            foreach (var bundle in manifest.GetAllAssetBundles())
            {
                this.newAsset.Add(new AssetbundleInfo(bundle, manifest.GetAssetBundleHash(bundle)));
                Debug.Log(manifest.GetAssetBundleHash(bundle));
                string[] depenci = manifest.GetAllDependencies(bundle);
                for (int i = 0; i < depenci.Length; i++)
                {
                    if (!depenciAsset.Contains(depenci[i]))
                        depenciAsset.Add(depenci[i]);
                }
            }
            assetBundle.Unload(false);
            onComplete(manifest);
        }
    }

    public IEnumerator SaveAndDownload(string url, string localPath, string fileName)
    {
        WWW www = new WWW(url);

        Debug.Log(url);

        yield return www;

        //yield return www;
        byte[] bytes = www.bytes;

        Debug.Log("<color=red>" + bytes.Length + "</color>");

        // Create the directory if it doesn't already exist
        if (!Directory.Exists(localPath))
        {
            Directory.CreateDirectory(localPath);
        }

        Debug.Log(localPath);

        File.WriteAllBytes(localPath + fileName, bytes);
    }


    //    BuildPlatform getRuntimePlatform()
    //    {
    //        if (Application.platform == RuntimePlatform.WindowsPlayer ||
    //            Application.platform == RuntimePlatform.OSXPlayer)
    //        {
    //            return BuildPlatform.Standalones;
    //        }
    //        else if (Application.platform == RuntimePlatform.OSXWebPlayer ||
    //                Application.platform == RuntimePlatform.WindowsWebPlayer)
    //        {
    //            return BuildPlatform.WebPlayer;
    //        }
    //        else if (Application.platform == RuntimePlatform.IPhonePlayer)
    //        {
    //            return BuildPlatform.IOS;
    //        }
    //        else if (Application.platform == RuntimePlatform.Android)
    //        {
    //            return BuildPlatform.Android;
    //        }
    //#if !UNITY_4_0 && !UNITY_4_1
    //        else if (Application.platform == RuntimePlatform.WP8Player)
    //        {
    //            return BuildPlatform.WP8;
    //        }
    //#endif
    //#if UNITY_5
    //		else if(Application.platform == RuntimePlatform.WebGLPlayer)
    //		{
    //			return BuildPlatform.WebGL;
    //		}
    //		else if(Application.platform == RuntimePlatform.WSAPlayerARM ||
    //				Application.platform == RuntimePlatform.WSAPlayerX64 ||
    //				Application.platform == RuntimePlatform.WSAPlayerX86)
    //		{
    //			return BuildPlatform.WinStoreApp;
    //		}
    //#endif
    //        else
    //        {
    //            Debug.LogError("Platform " + Application.platform + " is not supported by BundleManager.");
    //            return BuildPlatform.Standalones;
    //        }
    //    }
}
