﻿using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pie;

namespace ForuOnes.T3.LuckyTeenPatti
{
    [Serializable]
    public class AutoHistoryInfo
    {
        [SerializeField] public int gameModeId = 0;
        [SerializeField] public long win = 0;
        [SerializeField] public long lose = 0;
    }

    [Serializable]
    public class AutoHistoryList
    {
        [SerializeField] public List<AutoHistoryInfo> autoHistoryInfoList = new List<AutoHistoryInfo>();
    }

    public class AutoHistoryManager : MonoBehaviourSingleton<AutoHistoryManager>
    {
        #region Override from MonoBehaviourSingleton<HistoryManager>
        public override bool IsGlobal
        {
            get { return false; }
        }
        #endregion


        // Use this for initialization
        void Start()
        {
            for (int i = 0; i < autoHistoryLists.Length; i++)
            {
                string prefsName = "AutoHistory" + i.ToString();

                if (PlayerPrefs.HasKey(prefsName))
                {
                    string json = PlayerPrefs.GetString(prefsName);

                    autoHistoryLists[i] = JsonUtility.FromJson<AutoHistoryList>(json);
                }
            }
        }

        public void ClearHistory(int index)
        {
            if (autoHistoryLists[index] != null)
            {
                autoHistoryLists[index].autoHistoryInfoList.Clear();

                string json = JsonUtility.ToJson(autoHistoryLists[index]);
                PlayerPrefs.SetString("AutoHistory" + index.ToString(), json);
                PlayerPrefs.Save();
            }
        }

        public void AddAutoHistory(int index, int gameModeId, bool win)
        {
            if(autoHistoryLists[index] == null)
            {
                autoHistoryLists[index] = new AutoHistoryList();
                AutoHistoryInfo info = new AutoHistoryInfo();
                info.gameModeId = gameModeId;
                if (win)
                    info.win = 1;
                else
                    info.lose = 1;

                autoHistoryLists[index].autoHistoryInfoList.Add(info);
            }
            else
            {
                AutoHistoryInfo info = autoHistoryLists[index].autoHistoryInfoList.Where(x => x.gameModeId == gameModeId).FirstOrDefault();

                if (info == null)
                {
                    AutoHistoryInfo temp = new AutoHistoryInfo();
                    temp.gameModeId = gameModeId;
                    if (win)
                        temp.win = 1;
                    else
                        temp.lose = 1;

                    autoHistoryLists[index].autoHistoryInfoList.Add(temp);
                }
                else
                {
                    if (win)
                        info.win++;
                    else
                        info.lose++;
                }
            }

            string json = JsonUtility.ToJson(autoHistoryLists[index]);
            PlayerPrefs.SetString("AutoHistory" + index.ToString(), json);
            PlayerPrefs.Save();
        }        

        public AutoHistoryList[] autoHistoryLists = new AutoHistoryList[10];
    }
}
