﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pie;
using Facebook.Unity;
using System;
using System.Linq;

namespace ForuOnes.T3.LuckyTeenPatti
{
    public class AppEventManager : MonoBehaviourSingleton<AppEventManager>
    {
        #region Override from MonoBehaviourSingleton<AppEventManager>
        public override bool IsGlobal
        {
            get { return true; }
        }
        #endregion

        // Use this for initialization
        void Start()
        {
            eventList.Add("registration", new AppEvent("registration", "", 1, AppEvent.CheckType.DEVICE));      //로그인
            eventList.Add("login_fb", new AppEvent("login_fb", "login_fb", 1, AppEvent.CheckType.DEVICE));                        //페북 로그인 시도
            eventList.Add("login_guest", new AppEvent("login_guest", "login_guest", 1, AppEvent.CheckType.DEVICE));                  //게스트 로그인 시도
            eventList.Add("success_fb", new AppEvent("success_fb", "success_fb", 1, AppEvent.CheckType.DEVICE));                     //페북 로그인 성공
            eventList.Add("success_guest", new AppEvent("success_guest", "success_guest", 1, AppEvent.CheckType.DEVICE));            //게스트 로그인 성공
            eventList.Add("lobby_first", new AppEvent("lobby_first", "lobby_first", 1, AppEvent.CheckType.DEVICE));                //최초 로비 진입
            eventList.Add("game_first", new AppEvent("game_first", "game_first", 1, AppEvent.CheckType.DEVICE));                   //최초 게임룸 입장
            eventList.Add("play_start", new AppEvent("play_start", "play_start", 1, AppEvent.CheckType.DEVICE));                   //최초 게임 플레이 시작
            eventList.Add("play_first", new AppEvent("play_first", AppEventName.ViewedContent, 1, AppEvent.CheckType.DEVICE));                 //최초 게임 플레이 완료
            eventList.Add("play_result", new AppEvent("play_result", "play_result", 1, AppEvent.CheckType.DEVICE));                //최초 게임 플레이 결과
            eventList.Add("account_pop", new AppEvent("account_pop", "account_pop", 1, AppEvent.CheckType.DEVICE));                //계정 생성 팝업
            eventList.Add("account_com", new AppEvent("account_com", "account_com", 1, AppEvent.CheckType.DEVICE));                //계정 생성 완료
            eventList.Add("5play_first", new AppEvent("5play_first", "5play_first", 5, AppEvent.CheckType.DEVICE));                //계정 생성 후 최초 5회 플레이 완료
                                                                                                                
            eventList.Add("purchase", new AppEvent("", AppEventName.Purchased, 1, AppEvent.CheckType.NONE));                           //구매
            eventList.Add("purchase_fail", new AppEvent("purchase_fail", "purchase_fail", 1, AppEvent.CheckType.NONE));                           //구매
            eventList.Add("invite", new AppEvent("invite", "invite", 1, AppEvent.CheckType.NONE));                               //친구 초대
            eventList.Add("get_free", new AppEvent("get_free", "get_free", 1, AppEvent.CheckType.NONE));                           //무료 충전소
                                                                                                                
            eventList.Add("classic_1play", new AppEvent("classic_1play", "classic_1play", 1, AppEvent.CheckType.LOGIN));             //
            eventList.Add("classic_5play", new AppEvent("classic_5play", "classic_5play", 5, AppEvent.CheckType.LOGIN));             //
            eventList.Add("classic_10play", new AppEvent("classic_10play", "classic_10play", 10, AppEvent.CheckType.LOGIN));           //

            eventList.Add("variation_1play", new AppEvent("variation_1play", "variation_1play", 1, AppEvent.CheckType.LOGIN));         //
            eventList.Add("variation_5play", new AppEvent("variation_5play", "variation_5play", 5, AppEvent.CheckType.LOGIN));         //
            eventList.Add("variation_10play", new AppEvent("variation_10play", "variation_10play", 10, AppEvent.CheckType.LOGIN));       //

            eventList.Add("multi_1play", new AppEvent("multi_1play", "multi_1play", 1, AppEvent.CheckType.LOGIN));                 //
            eventList.Add("multi_5play", new AppEvent("multi_5play", "multi_5play", 5, AppEvent.CheckType.LOGIN));                 //
            eventList.Add("multi_10play", new AppEvent("multi_10play", "multi_10play", 10, AppEvent.CheckType.LOGIN));                 //

            eventList.Add("LuckyLeague_Rank1", new AppEvent("LuckyLeague_Rank1", "LuckyLeague_Rank1", 1, AppEvent.CheckType.NONE));                 //
            eventList.Add("LuckyLeague_Rank2", new AppEvent("LuckyLeague_Rank2", "LuckyLeague_Rank2", 1, AppEvent.CheckType.NONE));                 //
            eventList.Add("LuckyLeague_Rank3", new AppEvent("LuckyLeague_Rank3", "LuckyLeague_Rank3", 1, AppEvent.CheckType.NONE));                 //

            eventList.Add("BronzeLeague_Rank1", new AppEvent("BronzeLeague_Rank1", "BronzeLeague_Rank1", 1, AppEvent.CheckType.NONE));                 //
            eventList.Add("BronzeLeague_Rank2", new AppEvent("BronzeLeague_Rank2", "BronzeLeague_Rank2", 1, AppEvent.CheckType.NONE));                 //
            eventList.Add("BronzeLeague_Rank3", new AppEvent("BronzeLeague_Rank3", "BronzeLeague_Rank3", 1, AppEvent.CheckType.NONE));                 //

            eventList.Add("SilverLeague_Rank1", new AppEvent("SilverLeague_Rank1", "SilverLeague_Rank1", 1, AppEvent.CheckType.NONE));                 //
            eventList.Add("SilverLeague_Rank2", new AppEvent("SilverLeague_Rank2", "SilverLeague_Rank2", 1, AppEvent.CheckType.NONE));                 //
            eventList.Add("SilverLeague_Rank3", new AppEvent("SilverLeague_Rank3", "SilverLeague_Rank3", 1, AppEvent.CheckType.NONE));                 //

            eventList.Add("GoldLeague_Rank1", new AppEvent("GoldLeague_Rank1", "GoldLeague_Rank1", 1, AppEvent.CheckType.NONE));                 //
            eventList.Add("GoldLeague_Rank2", new AppEvent("GoldLeague_Rank2", "GoldLeague_Rank2", 1, AppEvent.CheckType.NONE));                 //
            eventList.Add("GoldLeague_Rank3", new AppEvent("GoldLeague_Rank3", "GoldLeague_Rank3", 1, AppEvent.CheckType.NONE));                 //

            eventList.Add("RubyLeague_Rank1", new AppEvent("RubyLeague_Rank1", "RubyLeague_Rank1", 1, AppEvent.CheckType.NONE));                 //
            eventList.Add("RubyLeague_Rank2", new AppEvent("RubyLeague_Rank2", "RubyLeague_Rank2", 1, AppEvent.CheckType.NONE));                 //
            eventList.Add("RubyLeague_Rank3", new AppEvent("RubyLeague_Rank3", "RubyLeague_Rank3", 1, AppEvent.CheckType.NONE));                 //

            eventList.Add("DiamondLeague_Rank1", new AppEvent("DiamondLeague_Rank1", "DiamondLeague_Rank1", 1, AppEvent.CheckType.NONE));                 //
            eventList.Add("DiamondLeague_Rank2", new AppEvent("DiamondLeague_Rank2", "DiamondLeague_Rank2", 1, AppEvent.CheckType.NONE));                 //
            eventList.Add("DiamondLeague_Rank3", new AppEvent("DiamondLeague_Rank3", "DiamondLeague_Rank3", 1, AppEvent.CheckType.NONE));                 //

            eventList.Add("_LoginTermsButtonPush", new AppEvent("_LoginTermsButtonPush", "_LoginTermsButtonPush", 1, AppEvent.CheckType.NONE));                 //
            eventList.Add("_PayTmExchangeButtonPush", new AppEvent("_PayTmExchangeButtonPush", "_PayTmExchangeButtonPush", 1, AppEvent.CheckType.NONE));                 //
            eventList.Add("_PayTmtermsButtonPush", new AppEvent("_PayTmtermsButtonPush", "_PayTmtermsButtonPush", 1, AppEvent.CheckType.NONE));                 //

            eventList.Add("TESTON", new AppEvent("", "TESTON", 1, AppEvent.CheckType.NONE));                 //
            eventList.Add("TESTOFF", new AppEvent("", "TESTOFF", 1, AppEvent.CheckType.NONE));                 //

            eventList.Add("TersPopupOn", new AppEvent("", "TersPopupOn", 1, AppEvent.CheckType.NONE));                 //

            eventList.Add("FeeRechanging_UI_Open", new AppEvent("FeeRechanging_UI_Open", "FeeRechanging_UI_Open", 1, AppEvent.CheckType.NONE));                 //
            eventList.Add("FeeRechanging_UI_Close", new AppEvent("FeeRechanging_UI_Close", "FeeRechanging_UI_Close", 1, AppEvent.CheckType.NONE));                 //
            eventList.Add("FeeRechanging_UI_AD_1", new AppEvent("FeeRechanging_UI_AD_1", "FeeRechanging_UI_AD_1", 1, AppEvent.CheckType.NONE));                 //
            eventList.Add("FeeRechanging_UI_AD_2", new AppEvent("FeeRechanging_UI_AD_2", "FeeRechanging_UI_AD_2", 1, AppEvent.CheckType.NONE));                 //
            eventList.Add("FeeRechanging_UI_OK", new AppEvent("FeeRechanging_UI_OK", "FeeRechanging_UI_OK", 1, AppEvent.CheckType.NONE));                 //

            eventList.Add("PAYTM_ButtonClick", new AppEvent("PAYTM_ButtonClick", "PAYTM_ButtonClick", 1, AppEvent.CheckType.NONE));
            eventList.Add("PAYTM_CreatButtonClick", new AppEvent("PAYTM_CreatButtonClick", "PAYTM_CreatButtonClick", 1, AppEvent.CheckType.NONE));
            eventList.Add("PAYTM_CreatAccount_UI_Open", new AppEvent("PAYTM_CreatAccount_UI_Open", "PAYTM_CreatAccount_UI_Open", 1, AppEvent.CheckType.NONE));
            eventList.Add("PAYTM_CreatAccount_OTP_Click", new AppEvent("PAYTM_CreatAccount_OTP_Click", "PAYTM_CreatAccount_OTP_Click", 1, AppEvent.CheckType.NONE));
            eventList.Add("PAYTM_CreatAccount_Button_Click", new AppEvent("PAYTM_CreatAccount_Button_Click", "PAYTM_CreatAccount_Button_Click", 1, AppEvent.CheckType.NONE));
            eventList.Add("PAYTM_CreatAccount_Fail_PhonNum", new AppEvent("PAYTM_CreatAccount_Fail_PhonNum", "PAYTM_CreatAccount_Fail_PhonNum", 1, AppEvent.CheckType.NONE));
            eventList.Add("PAYTM_CreatAccount_Fail_OTP", new AppEvent("PAYTM_CreatAccount_Fail_OTP", "PAYTM_CreatAccount_Fail_OTP", 1, AppEvent.CheckType.NONE));
            eventList.Add("PAYTM_CreatAccount_OK", new AppEvent("PAYTM_CreatAccount_OK", "PAYTM_CreatAccount_OK", 1, AppEvent.CheckType.NONE));
            eventList.Add("PAYTM_FACEBOOK_UI_Open", new AppEvent("PAYTM_FACEBOOK_UI_Open", "PAYTM_FACEBOOK_UI_Open", 1, AppEvent.CheckType.NONE));
            eventList.Add("PAYTM_Exchange_Button_Click", new AppEvent("PAYTM_Exchange_Button_Click", "PAYTM_Exchange_Button_Click", 1, AppEvent.CheckType.NONE));
            eventList.Add("PAYTM_Exchange_Button_Click_Open_FaceBook", new AppEvent("PAYTM_Exchange_Button_Click_Open_FaceBook", "PAYTM_Exchange_Button_Click_Open_FaceBook", 1, AppEvent.CheckType.NONE));
            eventList.Add("PAYTM_Exchange_Button_Click_Open_CreatAccount", new AppEvent("PAYTM_Exchange_Button_Click_Open_CreatAccount", "PAYTM_Exchange_Button_Click_Open_CreatAccount", 1, AppEvent.CheckType.NONE));
#if UNITY_EDITOR

#elif UNITY_ANDROID
            SingularSDK.InitializeSingularSDK();
#endif
        }

        public void SendGamePlay(eGameType gameType)
        {
            if(gameType == eGameType.TYPE_CLASSIC)
            {
                SendEvent("classic_1play");
                SendEvent("classic_5play");
                SendEvent("classic_10play");
            }
            else
            {
                SendEvent("variation_1play");
                SendEvent("variation_5play");
                SendEvent("variation_10play");
            }

            if (PlayerPrefsManager.Instance.isPlayMulti)
            {
                SendEvent("multi_1play");
                SendEvent("multi_5play");
                SendEvent("multi_10play");
            }
        }

        public void SendRankEvent(eLeagueGradeType grade, int rank)
        {
            if (grade == eLeagueGradeType.TYPE_LUCKY)
            {
                if (rank == 1)
                    SendEvent("LuckyLeague_Rank1");
                else if (rank == 2)
                    SendEvent("LuckyLeague_Rank2");
                else if (rank == 3)
                    SendEvent("LuckyLeague_Rank3");
            }
            else if (grade == eLeagueGradeType.TYPE_BRONZE)
            {
                if (rank == 1)
                    SendEvent("BronzeLeague_Rank1");
                else if (rank == 2)
                    SendEvent("BronzeLeague_Rank2");
                else if (rank == 3)
                    SendEvent("BronzeLeague_Rank3");
            }
            else if (grade == eLeagueGradeType.TYPE_SILVER)
            {
                if (rank == 1)
                    SendEvent("SilverLeague_Rank1");
                else if (rank == 2)
                    SendEvent("SilverLeague_Rank2");
                else if (rank == 3)
                    SendEvent("SilverLeague_Rank3");
            }
            else if (grade == eLeagueGradeType.TYPE_GOLD)
            {
                if (rank == 1)
                    SendEvent("GoldLeague_Rank1");
                else if (rank == 2)
                    SendEvent("GoldLeague_Rank2");
                else if (rank == 3)
                    SendEvent("GoldLeague_Rank3");
            }
            else if (grade == eLeagueGradeType.TYPE_RUBY)
            {
                if (rank == 1)
                    SendEvent("RubyLeague_Rank1");
                else if (rank == 2)
                    SendEvent("RubyLeague_Rank2");
                else if (rank == 3)
                    SendEvent("RubyLeague_Rank3");
            }
            else if (grade == eLeagueGradeType.TYPE_DIAMOND)
            {
                if (rank == 1)
                    SendEvent("DiamondLeague_Rank1");
                else if (rank == 2)
                    SendEvent("DiamondLeague_Rank2");
                else if (rank == 3)
                    SendEvent("DiamondLeague_Rank3");
            }
        }

        public void SendEvent(string strEvent)
        {
#if UNITY_EDITOR
            return;
#endif
            if (eventList.ContainsKey(strEvent))
                eventList[strEvent].SendEvent();
            else
            {
                FB.LogAppEvent(strEvent, 1);
                SingularSDK.Event(strEvent);
            }
        }

        public void SendRevenue(string currency, double mount)
        {
#if UNITY_EDITOR
            return;
#endif
            SingularSDK.Revenue(currency, mount);
        }

        public void ResetLoginTypeEvent()
        {
            List<AppEvent> appEvents = eventList.Values.Where(x => x.checkType == AppEvent.CheckType.LOGIN).ToList();

            for (int i = 0; i < appEvents.Count; i++)
            {
                appEvents[i].ClearEvent();
            }
        }

        protected override void OnDestroy()
        {
            base.OnDestroy();
            eventList.Clear();
            eventList = null;
        }

        private Dictionary<string, AppEvent> eventList = new Dictionary<string, AppEvent>();
    }

    public class AppEvent
    {
        public enum CheckType
        {
            NONE = 0,
            DEVICE = 1,
            LOGIN = 2,
        }

        public CheckType checkType = CheckType.NONE;
        public int maxCount = 0;
        public bool complete = false;
        public int currentCount = 0;
        public string singularMessage = string.Empty;
        public string faceBookMessage = string.Empty;

        public void ClearEvent()
        {
            complete = false;
            currentCount = 0;
        }

        public AppEvent(string sMessage, string fbMessage, int max, CheckType type)
        {
            maxCount = max;
            singularMessage = sMessage;
            faceBookMessage = fbMessage;
            checkType = type;

            if (checkType == CheckType.DEVICE)
            {
                string prefsMessage = "AppEvent_" + singularMessage;
                if (PlayerPrefs.HasKey(prefsMessage))
                {
                    currentCount = PlayerPrefs.GetInt(prefsMessage);
                    complete = currentCount >= maxCount;
                }
            }
        }

        public void SendEvent()
        {
            Action send = (() =>
            {
                if(faceBookMessage!="")
                    FB.LogAppEvent(faceBookMessage, 1);

                if(singularMessage!="")
                    SingularSDK.Event(singularMessage);
            });

            if(checkType == CheckType.NONE)
            {
                send();
            }
            else
            {
                if (complete)
                {
                    return;
                }

                currentCount++;
                complete = currentCount >= maxCount;

                if (checkType == CheckType.DEVICE)
                {
                    string prefsMessage = "AppEvent_" + singularMessage;
                    PlayerPrefs.SetInt(prefsMessage, currentCount);
                    PlayerPrefs.Save();
                }

                if (complete)
                    send();
            }
        }
    }
}
