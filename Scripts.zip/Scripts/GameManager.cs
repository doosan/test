using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

namespace SlotKingdoms
{
    public class GameManager : MonoBehaviour, IPointerDownHandler
    {
        // Start is called before the first frame update
        void Start()
        {
            if(TutorialSystem.Instance.CheckPlayFirstBigCoinTutorial())
            {

            }
            else
            {
                StartCoroutine(TutorialSystem.Instance.PlayFirstTutorial());
            }
            
        }

        public void OnPointerDown(PointerEventData eventData)
        {
            Debug.Log("downdown");
        }
    }
}
