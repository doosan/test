using System;
using System.Collections.Generic;

#pragma warning disable 8618
namespace SlotKingdoms.Net
{
    [Serializable]
    public class ClientResponse
    {
        public string code;
        public string message;
        public long ts;

        // 아래는 클라이언트에서만 사용하는 값
        public bool isSuccess;
        public string rawData;
        public int statusCode;
        public string error;
    }

    [Serializable]
    public class AssetVersionResponse : ClientResponse
    {
        public AssetVersionData data;
    }

    [Serializable]
    public class RegisterResponse : ClientResponse
    {
        public string pwd;
    }

    [Serializable]
    public class Profiles
    {
        public string imageType;  // index or url
        public string imageValue;
        public string nickName;
    }

    [Serializable]
    public class SignalRInfo
    {
        public string accessToken { get; set; } = string.Empty;
    }

    [Serializable]
    public class EnergyInfo
    {
        public long chargedEnergyAmount { get; set; }

        public long energy { get; set; }

        public long energyMax { get; set; }

        public long chargeEnergyTs { get; set; }
    }

    [Serializable]
    public class SkinInfo
    {
        public string SkinName { get; set; }
        public int Idx { get; set; }
    }

    [Serializable]
    public class EquippedSkinData
    {
        public SkinInfo Card { get; set; }

        public SkinInfo Attack { get; set; }

        public SkinInfo Shield { get; set; }
    }

    [Serializable]
    public class LoginResponse : ClientResponse
    {
        public LoginData data;
    }

    [Serializable]
    public class LoginData : ClientResponse
    {
        public string pid { get; set; }

        public long gameMoney { get; set; }

        public int star { get; set; }

        public int starMax { get; set; }

        public int shield { get; set; }

        public int shieldMax { get; set; }

        public int hammer { get; set; }        

        public long megaEndTs { get; set; }

        public EnergyInfo userEnergyInfo { get; set; }

        public Profiles userProfiles { get; set; }

        public EquippedSkinData userEquippedSkinData { get; set; }

        public SignalRInfo signalRInfo { get; set; }
    }

    public enum ObjectStatus
    {
        normal = 0,     // 정상
        destroy = 1     // 파괴
    }



    public enum ObjectProgress
    {
        None = 0,  // 오브젝트가 없는 상태
        Level1 = 1, // 오브젝트 1단계 상태
        Level2 = 2, // 오브젝트 2단계 상태
        Level3 = 3, // 오브젝트 3단계 상태
        Level4 = 4, // 오브젝트 4단계 상태
        Level5 = 5, // 오브젝트 5단계 상태, 완료
    }

    public class ObjectProgressInfo
    {
        public int level { get; set; }              // 1 ~ 5
        public long money { get; set; }             // 오브젝트 건립 또는 복구시 필요한 돈
    }

    [Serializable]
    public class ObjectInfo
    {
        public int objectNo { get; set; } = 0;              // 오브젝트 번호
        public string objectName { get; set; } = "";        // 오브젝트 이름
        public int maxProgress { get; set; } = 0;           // 최대 단계
        public ObjectProgressInfo progressInfo { get; set; } = new(); // 현재 정보
    }

    [Serializable]
    public class UserObjectInfo : ObjectInfo
    {
        public string status { get; set; }       // 0 : 정상, 1: 1단계 파괴, 2: 2단계 파괴
        public int destoryCount { get; set; } = 0;                      // 파괴 횟수
        public string destoryerPid { get; set; } = "";                  // 파괴한 pid
        public Profiles destroyerProfile { get; set; }
        public string destoryerImg { get; set; } = "";                  // 파괴한 pid 프로필 이미지
        public int destoryerEmoji { get; set; } = 0;                    // 파괴한 이모티콘
        public int progress { get; set; } = 0;                          // ( 0 - 5 ), 0: 아무것도 없는 상태
    }

    [Serializable]
    public class TownInfo
    {
        public int townNo { get; set; } = 0;                        // 마을 번호
        public string townName { get; set; } = "";                  // 마을 이름
        public int objectCount { get; set; } = 0;                   // 오브젝트 개수
        public int cutSceanStartNo { get; set; } = 0;               // 컷씬 시작 번호
        public int cutSceanEndNo { get; set; } = 0;                 // 컷씬 끝 번호
        public string desc { get; set; } = "";                      // 마을 설명
    }


    [Serializable]
    public class UserTownInfo : TownInfo
    {
        public List<UserObjectInfo> objectList { get; set; } = new();   // 오브젝트 정보
    }

    [Serializable]
    public class TownViewData
    {
        public int townMax { get; set; }
        public UserTownInfo townInfo { get; set; }
    }

    [Serializable]
    public class RewardInfo
    {
        public eGoodsType type { get; set; } = 0;      // 1: 게임머니  2: 에너지 3: 쉴드 // Common GoodsType 참고
        public long value { get; set; } = 0;    // 보상 값

        public RewardInfo(eGoodsType type, long value)
        {
            this.type = type;
            this.value = value;
        }

        public RewardInfo()
        {
        }
    }

    [Serializable]
    public class TownUpgradeData
    {
        public UserObjectInfo objectInfo { get; set; } = new();   // 오브젝트 정보
        public Int64 money { get; set; } = 0;                          // 현재 돈
        public Int64 useMoney { get; set; } = 0;                       // 사용한 돈
        public List<RewardInfo> rewardList { get; set; } = new();       // 보상 리스트
        public List<RewardInfo> completeRewardList { get; set; } = new(); // 마을 완료 보상 리스트
        public UserTownInfo nextTownInfo { get; set; } = new(); // 다음 마을 정보
        public int star;
        public int addStar;
        public List<RewardInfo> starRewardList { get; set; }
        public int nextInflationIndex;
        public int unlockInflationIndex;
    }

    [Serializable]
    public class MemoryListData
    {
        public List<MainMemoryInfo> MemoryList { get; set; } = new(); // 메모리 리스트
    }

    [Serializable]
    public class MemoryRestoreData
    {
        public int mainNo { get; set; } = 0; // 메인 카테고리
        public int subNo { get; set; } = 0;  // 서브 카테고리
        public List<TileInfo> restoreTileList { get; set; } = new(); // 복원 타일 리스트
        public List<RewardInfo> tileRewardList { get; set; } = new(); // 타일 오픈시 확율적으로 지급되는 보상 리스트
        public List<RewardInfo> pieceCompleteRewardList { get; set; } = new(); // 조각 완성 보상 리스트
        public List<RewardInfo> mainMemoryRewardList { get; set; } = new(); // 메인 메모리 보상 리스트
        public Int64 gameMoney { get; set; } = 0; // 게임머니
        public Int64 energy { get; set; } = 0; // 에너지
        public Int64 shield { get; set; } = 0; // 쉴드
        public int hammer { get; set; } = 0; // 망치갯수
        public int cutSceanNo { get; set; } = 0; // 컷씬 번호
    }

    [Serializable]
    public class TownViewResponse : ClientResponse
    {
        public TownViewData data;
    }

    [Serializable]
    public class TownUpgradeResponse : ClientResponse
    {
        public TownUpgradeData data;
    }

    [Serializable]
    public class TutorialStringData
    {        
        public string tutorialData { get; set; }
    }

    [Serializable]
    public class GetTutorialResponse : ClientResponse
    {
        public TutorialStringData data;
    }

    [Serializable]
    public class SetTutorialResponse : ClientResponse
    {
        
    }

    [Serializable]
    public class TownMaxData
    {
        public int townMax { get; set; }
    }

    [Serializable]
    public class TownMapResponse : ClientResponse
    {
        public TownMaxData data;
    }

    [Serializable]
    public class TargetResponse : ClientResponse
    {
        public string address;
        public string type;
    }

    [Serializable]
    public class PurchaseResponse : ClientResponse
    {
        public long coin;
        public int cnt;
    }

    //[Serializable]
    //public class FanpageRewardResponse : ClientResponse
    //{
    //    public CommonRewardData data;
    //}

    [Serializable]
    public class AttackTargetListResponse : ClientResponse
    {
        public AttackTargetListData data;
    }

    [Serializable]
    public class SetProfileResponse : ClientResponse
    {
        public string pid;

        public Profiles userProfiles;
    }

    [Serializable]
    public class UserDatas
    {
        public long gameMoney { get; set; }
        public int star { get; set; }
        public int starMax { get; set; }
        public long energy { get; set; }
        public long megaEndTs { get; set; }
        public int shield { get; set; }
        public int shieldMax { get; set; }
        public int hammer { get; set; }
        public EnergyInfo userEnergyInfo { get; set; }
    }

    [Serializable]
    public class GetProfileData
    {
        public string pid;

        public Profiles userProfiles;
        public UserDatas userData;
    }

    [Serializable]
    public class GetProfileResponse : ClientResponse
    {
        public GetProfileData data;
    }

    [Serializable]
    public class MemoryListResponse : ClientResponse
    {
        public MemoryListData data;
    }

    [Serializable]
    public class MemoryRestoreResponse : ClientResponse
    {
        public MemoryRestoreData data;
    }

    [Serializable]
    public class GrothInflationInfo
    {
        public int idx { get; set; } = 0;                                   // 성장 인플레이션 번호
        public InflationType type { get; set; } = InflationType.None;       // 인플레이션 타입
        public int level { get; set; } = 0;                                 // 인플레이션 타입별 현재 레벨    
        public int maxLevel { get; set; } = 0;                              // 인플레이션 타입별 최대 레벨
        public int unlockLevel { get; set; } = 0;                           // 인플레이션 타입별 해금 레벨    
        public InflationState state { get; set; } = InflationState.Lock;    // 상태        
        public BenefitType benefitType { get; set; } = BenefitType.None;    // 혜택 타입
        public int benefitValue { get; set; } = 0;                          // 혜택 값
        public int benefitValueExt { get; set; } = 0;                       // 혜택 값        
        public int cutSceanNo { get; set; } = 0;                       
    }

    [Serializable]
    public class GrothInflationData
    {
        public int prevInflationStarLevel { get; set; } = 0; // 이전 인플레이션 레벨
        public int starLevel { get; set; } = 0;              // 현재 스타 레벨
        public int nextInflationStarLevel { get; set; } = 0; // 다음 인플레이션 레벨
        public List<RewardInfo> nextInflationReward { get; set; } // 다음 인플레이션 보상
        public List<GrothInflationInfo> inflationList { get; set; } // 타입별 정보 전달
        public int nextInflationIdx;
        public GrothInflationInfo nextInflationInfo { get; set; }
    }   

    [Serializable]
    public class GrowthinflationResponse : ClientResponse
    {
        public GrothInflationData data;
    }

    [Serializable]
    public class GrowthInflationTypeNextInfonData
    {
        public int InflationNo;
        public GrothInflationInfo InflationInfo { get; set; }
    }

    [Serializable]
    public class GrowthInflationTypeNextInfoResponse : ClientResponse
    {
        public GrowthInflationTypeNextInfonData data;
    }

    [Serializable]
    public class StealTargetData
    {
        public string pid { get; set; }
        public string targetPid { get; set; }
        public string targetImageType { get; set; } = string.Empty;
        public string targetImageValue { get; set; } = string.Empty;
        public string targetNickName { get; set; } = string.Empty;
        public long targetCoin { get; set; }
        public long targetSettingTs { get; set; }
    }

    [Serializable]
    public class StealTargetResponse : ClientResponse
    {
        public StealTargetData data;
    } 


    [Serializable]
    public class CheatData
    {
        public string pid { get; set; }
        public long game_money { get; set; } = 0; // 게임머니
        public long energy { get; set; } = 0; // 에너지
        public int shield { get; set; } = 0; // 쉴드
        public int star { get; set; } = 0; // 별

        public long mega_end_ts { get; set; } // mega 종료 시간                 // 공격 성공 여부
    }


    [Serializable]
    public class CheatResponse : ClientResponse
    {
        public CheatData data;
    }


    [Serializable]
    public class UserLogNotiResponse : ClientResponse
    {
        public UserLogNotiData data;
    }

    [Serializable]
    public class UserLogNotiData
    {
        public List<UserLogData> userLogDataList { get; set; } = new();
    }

    [Serializable]
    public class UserLogData
    {
        public eUserLogType type { get; set; }                  // 유저 로그 타입
        public Profiles attackerProfile { get; set; } = new();  // 공격자 정보
        public long stealMoney { get; set; } = 0;               // 스틸당한 금액
        public long regDateTs { get; set; } = 0;                // DB에 등록된 시간
    }

    [Serializable]
    public class SymbolRemained
    {
        public string symbol { get; set; }
        public int remainedAmount { get; set; }
    }

    [Serializable]
    public class MainGameStateData
    {

        public string deckType { get; set; }
        public int canShuffleCount { get; set; }
        public long bet { get; set; }
        public int totalfreeRemainCount { get; set; }
        public int remainDeckCount { get; set; }
        public int maxCardDeckCount { get; set; }
        public string gameState { get; set; }
        public List<SymbolRemained> remainSymbolCountList { get; set; }
        public List<string> selectedSymbolIdList { get; set; }
        public List<int> totalBetList { get; set; }
        public EnergyInfo energyInfo { get; set; }  
    }

    [Serializable]
    public class MainGameStateResponse : ClientResponse
    {
        public MainGameStateData data;
    }

    [Serializable]
    public class DrawData
    {
        public List<string> selectedSymbolIdList { get; set; } //drawData에서 사용하지 않고 mainGameInfo에서만 사용
        public long deckCompleteCoin { get; set; }
        public int totalfreeRemainCount { get; set; }
        public int remainDeckCount { get; set; }
        public int maxCardDeckCount { get; set; }
        public EnergyInfo userEnergyInfo { get; set; }
    }

    [Serializable]
    public class DrawResponse : ClientResponse
    {
        public DrawData data;
    }

    [Serializable]
    public class FeatureResult
    {
        public long totalGetCoin { get; set; }
        public long totalGetEnergy { get; set; }
        public long totalGetShield { get; set; }

#nullable enable
        public AttackFeatureRes? attack { get; set; }
        public MoneyFeatureRes? money { get; set; }
        public ShieldFeatureRes? shield { get; set; }
        public StealFeatureRes? steal { get; set; }
        public EnergyFeatureRes? energy { get; set; }
        public HatchFeatureRes? hatch { get; set; }
        public FreeFeatureRes? free { get; set; }
        public ShuffleFeatureRes? shuffle { get; set; }
    }

    [Serializable]
    public class AttackTargetData
    {
        public string targetPid { get; set; } = string.Empty;
        public string targetImageType { get; set; } = string.Empty;
        public string targetImageValue { get; set; } = string.Empty;
        public string targetNickName { get; set; } = string.Empty;
    }

    [Serializable]
    public class AttackFeatureRes
    {
        public AttackTargetData target { get; set; }
        public bool triggered { get; set; } = false;
    }

    [Serializable]
    public class EnergyFeatureRes
    {
        public long getEnergyCount { get; set; } = 0;
    }

    [Serializable]
    public class ShieldFeatureRes
    {
        public long getShieldCount { get; set; } = 0;
        public long getEnergyCount { get; set; } = 0;
    }

    [Serializable]
    public class MoneyFeatureRes
    {
        public string type { get; set; } = string.Empty;
        public long moneyReward { get; set; } = 0;
    }

    public class StealTarget
    {
        public string targetPid { get; set; } = string.Empty;
        public string targetImageType { get; set; } = string.Empty;
        public string targetImageValue { get; set; } = string.Empty;
        public string targetNickName { get; set; } = string.Empty;
        public long targetCoin { get; set; }
    }

    [Serializable]
    public class StealFeatureReward
    {
        public bool isWheel { get; set; } = false;
        public List<int> wheelInfo { get; set; }
        public int stopIndex { get; set; } = -1;
        public long stolenCoin { get; set; } = 0;
        public long totalStolenCoin { get; set; } = 0;
    }

    [Serializable]
    public class StealFeatureRes
    {
        public bool isMega { get; set; } = false;
        public long bet { get; set; } = 0;
        public StealTarget target { get; set; }
        public long totalStolenCoin { get; set; } = 0;
        public List<StealFeatureReward> actions { get; set; } = new();
    }


    [Serializable]
    public class HatchFeatureReward
    {
        public int orders { get; set; }

        public List<string> reelValues;
        public List<string> reelTiers;
        public List<int>? stopIndex;

        public string types { get; set; } = string.Empty;
        public long addCoin { get; set; }
        public long addEnergy { get; set; }

        public int leftPickCount { get; set; }
        public long totalCoin { get; set; }
        public long totalEnergy { get; set; }
    }

    [Serializable]
    public class HatchFeatureRes
    {
        public List<string> types { get; set; }
        public int basePickCount { get; set; }
        public long baseCoinReward { get; set; }
        public List<HatchFeatureReward> actions { get; set; }

        public string? FindType(int index)
        {
            if (index == 0)
            {
                return types.Find(x => x == "Red");
            }
            else if (index == 1)
            {
                return types.Find(x => x == "Blue");
            }
            else if (index == 2)
            {
                return types.Find(x => x == "Purple");
            }

            return null;
        }
    }

    [Serializable]
    public class FreeFeatureRes
    {
        public int freeRemainCount { get; set; }
    }

    [Serializable]
    public class ShuffleFeatureRes
    {
        public int bet { get; set; }
        public long deckCompleteCoin { get; set; }
        public int maxCardDeckCount { get; set; }
        public List<SymbolRemained> remainSymbolCountList { get; set; }
        public string deckType { get; set; } = string.Empty;
    }

    [Serializable]
    public class PickData
    {
        public string pickedSymbol { get; set; } = string.Empty; 
        public List<SymbolRemained> remainSymbolCountList { get; set; }
        public List<int> totalBetList { get; set; }
        public EnergyInfo userEnergyInfo { get; set; }
        public FeatureResult gameFeatureResult { get; set; }
    }

    [Serializable]
    public class PickResponse : ClientResponse
    {
        public PickData data;
    }

    [Serializable]
    public class ShuffleData
    {
        public int maxCardDeckCount { get; set; }
        public string deckType { get; set; }
        public List<SymbolRemained> remainSymbolCountList { get; set; }
        public EnergyInfo energyInfo { get; set; }
    }

    [Serializable]
    public class ShuffleResponse : ClientResponse
    {
        public ShuffleData data;
    }

    [Serializable]
    public class TownAttackTargetViewResponse : ClientResponse
    {
        public TownAttackTargetViewData data;
    }

    [Serializable]
    public class TownAttackTargetViewData
    {
        public string targetPid { get; set; } = "";                  // 공격할 pid
        public UserTownInfo targetTownInfo { get; set; } = new();
        public int bet { get; set; } = 0; // 베팅 배수
        public Profiles targetProfile { get; set; } = new(); // 공격할 pid 프로
    }

    [Serializable]
    public class TownAttackData
    {
        public UserObjectInfo TargetObjectInfo { get; set; } = new();   // 오브젝트 정보
        public Int64 Money { get; set; } = 0;                          // 현재 돈
        public Int64 GainMoney { get; set; } = 0;                      // 획득한 돈
        public bool IsSuccess { get; set; } = false;                    // 공격 성공 여부
    }

    [Serializable]
    public class TownAttackResponse : ClientResponse
    {
        public TownAttackData data;
    }

    [Serializable]
    public class TownAttackTargetTownData
    {
        public string targetPid { get; set; } = "";                  // 공격할 pid
        public UserTownInfo targetTownInfo { get; set; } = new();
        public int bet { get; set; } = 0; // 베팅 배수
        public Profiles targetProfile { get; set; } = new(); // 공격할 pid 프로필 정보
    }

    [Serializable]
    public class TownAttackTargetTownResponse : ClientResponse
    {
        public TownAttackData data;
    }

    [Serializable]
    public class AttackTargetRevengeData
    {
        public string pid { get; set; } = "0";
        public Profiles profile { get; set; } = new();
        public long attackTime { get; set; }
    }

    [Serializable]
    public class AttackerDataList
    {
        public List<AttackTargetRevengeData> targetProfileList { get; set; } = new(); // 공격할 pid 프로필 정보
    }

    [Serializable]
    public class TownAttackTargetChangeListResponse : ClientResponse
    {
        public AttackerDataList data;
    }

    [Serializable]
    public class BetData
    {
        public long bet { get; set; } = 0;
    }

    [Serializable]
    public class BetResponse : ClientResponse
    {
        public BetData data;
    }
}
#pragma warning restore 8618