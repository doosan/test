using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace SlotKingdoms.Net
{
    [Serializable]
    public sealed class UserInfo
    {
        public string pid;
        public string ssionid = "";
        public Profiles profiles = new Profiles();
        public Dictionary<eGoodsType, long> goodsDic = new Dictionary<eGoodsType, long>();
        public long preStar;
        public long nextStar;
        public int shield_max;
        public EnergyInfo energyInfo = new EnergyInfo();
        public BetInfo bet_info = new BetInfo();
        public long megaEndTs = 0;
        public MainGameSkinData cardSkinData;
    }

    [Serializable]
    public sealed class MainGameInfo
    {
        public string deckType { get; set; }
        public int canShuffleCount { get; set; }
        public int totalfreeRemainCount { get; set; }
        public int remainDeckCount { get; set; }
        public int maxCardDeckCount { get; set; }
        public string gameState { get; set; }
        public List<SymbolRemained> remainSymbolCountList { get; set; }
        public List<string> selectedSymbolIdList { get; set; }
    }

    //[Serializable]
    //public sealed class RewardInfo
    //{
    //    public eGoodsType type;
    //    public long value;

    //    public RewardInfo(eGoodsType type, long value)
    //    {
    //        this.type = type;
    //        this.value = value;
    //    }
    //}

    //[Serializable]
    //public class Profiles
    //{
    //    public string ImageType { get; set; } = string.Empty;
    //    public string ImageValue { get; set; } = string.Empty;
    //    public string NickName { get; set; } = string.Empty;
    //}

    //[Serializable]
    //public class SignalRInfo
    //{
    //    public string AccessToken { get; set; } = string.Empty;
    //}

    //[Serializable]
    //public class EnergyInfo
    //{
    //    public long chargedEnergyAmount { get; set; }

    //    public long energy { get; set; }

    //    public long energyMax { get; set; }

    //    public long chargeEnergyTs { get; set; }
    //}

    [Serializable]
    public sealed class BetInfo
    {        
        public List<int> betList = new List<int>();
        
        public int betIndex = 0;
        private long currentBet = 1;
        public long CurrentBet
        {
            get { return currentBet; }
            set
            {
                currentBet = value;
                betIndex = betList.FindIndex(item => item == currentBet);
            }
        }

        public bool IsMax
        {
            get
            {                
                return CurrentBet >= betList[^1] && CurrentBet != 1;
            }
        }

        public long GetNextBetValue()
        {
            return betList[betList.Count <= betIndex + 1 ? 0 : betIndex + 1];
        }

        public long GetMaxBet
        {
            get 
            {
                for(int i= betList.Count - 1; i>=0;i--)
                {
                    if(betList[i] <= GameInfo.EnergyInfo.energy)
                    {
                        return betList[i];
                    }
                }
                
                return 1; 
            }
        }
    }
    

    [Serializable]
    public sealed class BuildingInfo
    {
        public int index;
        public int level;
        public bool broken;
        public long price;
        public Profiles profile;
    }

    [Serializable]
    public sealed class TownDataInfo
    {
        public int stage;
        public int tutorialIndex = 0;
        public List<BuildingInfo> buildings_info;
    }

    [Serializable]
    public sealed class AttackTargetInfo
    {
        public string uid;
        public string nick;
        public string profile_image;
        public long bet_mul;

        public TownDataInfo townInfo;
    }

    [Serializable]
    public sealed class AttackResultInfo
    {
        public bool block;
        public long crystal;
    }

    [Serializable]
    public sealed class AttackTargetListInfo
    {
        public string uid;
        public string nick;
        public string profile_image;
        public long star;
    }

    [Serializable]
    public sealed class RaidTargetInfo
    {
        public string uid;
        public string nick;
        public string profile_image;
        public long cristal;
    }

    [Serializable]
    public sealed class RaidResultInfo
    {
        public RaidTargetInfo targetInfo;
        public long[] list;
        public bool isBonus;
        public long[] wheel_mul;
        public long crystal;
        public long bet_mul;
        public long total;
    }

    [Serializable]
    public sealed class NewsInfo
    {
        public long type;
        public string nick;
        public string profile_image;
        public long time;
        public long value;
    }

    [Serializable]
    public sealed class LeaderBoardInfo
    {
        public long rank;
        public string nick;
        public string profile_image;
        public long star;
    }

    [Serializable]
    public sealed class LeaderBoardList
    {
        public LeaderBoardInfo[] list;
        public long my_rank;
    }

    [Serializable]
    public sealed class LeaderBoardListInfo
    {
        public LeaderBoardList friends;
        public LeaderBoardList local;
        public LeaderBoardList global;
    }

    [Serializable]
    public sealed class FriendInfo
    {
        public string uid;
        public string nick;
        public string profile_image;
        public long cristal;
        public bool send;
        public long time;
    }

    [Serializable]
    public sealed class ShopItemInfo
    {
        public long index;
        public long value;
        public bool most;
        public long need_value;
    }

    [Serializable]
    public sealed class ShopPackageInfo
    {
        public long index;
        public RewardInfo[] list;
        public bool most;
        public long need_value;
    }

    [Serializable]
    public sealed class ShopListInfo
    {
        public ShopItemInfo[] energy;
        public ShopItemInfo[] cristal;
    }

    [Serializable]
    public sealed class StoryBoardInfo
    {
        public RewardInfo[] rewards;
        public long need_starcoin;
        public long open_lis;
        public bool complete;
        public long probability;
        public long step;
    }

    [Serializable]
    public sealed class StoryChapterInfo
    {
        public long state;              // 0:잠김, 1:진행중, 2:클리어(보상못받음), 3:보상받음
        public RewardInfo[] rewards;
        public StoryBoardInfo[] boardInfo;
    }

    [Serializable]
    public sealed class StoryInfo
    {
        public StoryChapterInfo[] chapterInfo_list;
    }

    [Serializable]
    public sealed class TileInfo
    {
        //public int TilePosX;
        //public int TilePosY;
        //public int TileStatus;
        public int X;
        public int Y;
        public int S;
    }

    [Serializable]
    //public sealed class MemoryPiece
    public sealed class SubMemory
    {
        public int MainNo; // 메인 카테고리
        public int SubNo; // 서브 카테고리
        public int Height; // 높이
        public int Width; // 너비
        public List<TileInfo> TileList; // 타일 리스트
        //public int OpenLevel; // 해금 레벨
        public int UnlockLevel;
        //public List<GoodsInfo> RewardList; // 보상 리스트
        public List<RewardInfo> RewardList;
        //public int Complete; // 조각 완성 여부 // 0: 미완성, 1: 완성
        public int State;   // 조각 완성 여부 // 0: 잠김, 1: 미완성, 2: 완성
    }

    [Serializable]
    public sealed class MainMemoryInfo
    {
        public int MainNo; // 메인 카테고리
        public int OpenLevel; // 해금 레벨
        public int State; // 메인 메모리 상태 // 0: 잠김, 1: 미완성, 2: 완성
        public List<SubMemory> PeiceList; // 메모리 조각 리스트
        //public List<GoodsInfo> RewardList; // 보상 리스트
        public List<RewardInfo> mainMemoryRewardList; // 보상 리스트
    }

    [Serializable]
    public sealed class DailygiftInfo
    {
        public long bonus_point;
        public long[] bonus_points;
        public long step;
        public DailygiftDayInfo[] daily_rewards;
        public RewardInfo[] day_rewards;
    }

    [Serializable]
    public sealed class DailygiftDayInfo
    {
        public RewardInfo[] rewards;
    }

    [Serializable]
    public sealed class MainGameSkinData
    {
        //스킨 이름
        public string cardSkinName;
        //스킨 Id
        public string cardSkinId;

        //스킨 이름
        public string attackSkinName;
        //스킨 Id
        public string attackSkinId;

        //스킨 이름
        public string shieldSkinName;
        //스킨 Id
        public string shieldSkinId;
    }

    public class AlarmInfo
    {
        public UnityEvent onUserLogInfoAdded = new();
        public UnityEvent onUserLogInfoRemoved = new();

        public bool IsInStop
        {
            get;
            private set;
        }

        public long LatestRegDateTs
        {
            get;
            private set;
        }

        private bool isDataLoadRequired;

        private Queue<UserLogInfo> userLogInfoList = new();

        public int UserLogInfoCount
        {
            get => userLogInfoList.Count;
        }

        public void UpdateInStop(bool value)
        {
            IsInStop = value;
        }

        public void UpdateDataLoadRequired(bool value)
        {
            isDataLoadRequired = value;
        }

        public bool ConsumeDataLoadRequired()
        {
            bool result = isDataLoadRequired;
            isDataLoadRequired = false;
            return result;
        }

        public void EnqueueUserLogs(List<UserLogData> datas)
        {
            foreach (UserLogData data in datas)
            {
                var info = new UserLogInfo();
                info.type = data.type;
                info.profiles = data.attackerProfile;
                info.stealMoney = data.stealMoney;
                userLogInfoList.Enqueue(info);

                if (LatestRegDateTs < data.regDateTs)
                {
                    LatestRegDateTs = data.regDateTs;
                    Debug.Log($"LatestRegDateTs : {LatestRegDateTs}");
                }
            }

            onUserLogInfoAdded?.Invoke();
        }

        public UserLogInfo DequeueUserLog()
        {
            UserLogInfo info = userLogInfoList.Dequeue();
            onUserLogInfoRemoved?.Invoke();
            return info;
        }
    }

    public class UserLogInfo
    {
        public eUserLogType type;
        public Profiles profiles;
        public long stealMoney;
        public string message;
    }
}