using SlotKingdoms.Popup;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace SlotKingdoms.Net
{
    public enum EpochChatState
    {
        None = 0,
        NeedAccessToken,
        Init,
        Connected,
        Closed,
        Errored,
        ChatConnected,
    }

    public class ChatMessageEvent : UnityEvent<long> { }

    public static class NetworkSystem
    {
        private static bool isInitialize;

        public static HttpRequester Requester
        {
            get;
            private set;
        }
        public static ChatHandler ChatHandler
        {
            get;
            private set;
        }

        public static bool ShowErrorPopup
        {
            private get;
            set;
        }

        private static HashSet<string> manualHandlingErrorCodes;

        public static void Initialize()
        {
            if (isInitialize)
            {
                return;
            }

            isInitialize = true;

            var networkSystemObj = new GameObject("NetworkSystem");
            GameObject.DontDestroyOnLoad(networkSystemObj);

            Requester = new GameObject("HttpRequester").AddComponent<HttpRequester>();
            Requester.transform.SetParent(networkSystemObj.transform);
            Requester.onError.AddListener(OnRequestError);

            ChatHandler = new ChatHandler();
            ChatHandler.onMessageArrived.AddListener(OnChatMessageArrived);

            manualHandlingErrorCodes = new HashSet<string>()
            {
                // 수동으로 처리할 에러 코드를 추가해 주세요.
                "User_NotEnoughMoney",
            };
        }

        public static void UpdateHttpRequesterSetting_AsFail()
        {
            Debug.Log("UpdateHttpRequesterSetting_AsFail");
            Requester.Setting = new HttpRequesterSetting()
            {
                connectTimeout = 0.001,
                timeout = 0.001,
                retry = 3
            };
        }

        public static void UpdateHttpRequesterSetting_AsDefault()
        {
            Debug.Log("UpdateHttpRequesterSetting_AsDefault");
            Requester.Setting = Requester.DefaultSetting;
        }

        private static void OnRequestError(string code, string error)
        {
            Debug.Log($"[NetworkSystem.OnRequestError] : {code}, {error}");
            if (ShowErrorPopup == true
                && manualHandlingErrorCodes.Contains(code) == false)
            {
                PopupSystem.Instance.OpenPopup<ErrorPopup>()
                                    .Init(code, error, ErrorPopup.ActionType.Intro);
            }
        }

        private static void OnChatMessageArrived(SignalRType type, string sourcePid, string targetPid, long regDateTs)
        {
            Debug.Log($"OnChatMessageArrived : {type}, {sourcePid}, {targetPid}, {regDateTs}");

            if (targetPid == GameInfo.userInfo.pid)
            {
                if (type == SignalRType.Defense || type == SignalRType.Attack || type == SignalRType.Steal)
                {
                    AlarmInfo alarmInfo = GameInfo.alarmInfo;
                    if (alarmInfo.LatestRegDateTs < regDateTs)
                    {
                        if (alarmInfo.IsInStop == false)
                        {
                            LoadUserLogNoti();
                        }
                        else
                        {
                            alarmInfo.UpdateDataLoadRequired(true);
                        }
                    }
                }
                    

                ////////////////////////////////////////////
                ///
                if(type == SignalRType.Defense)
                {
                    UserShieldInfo();
                }
                else if(type == SignalRType.Attack)
                {

                }
                else if(type == SignalRType.Steal)
                {
                    UserMoneyInfo();
                }
            }
        }

        public static IRequest<LoginResponse> Login(string pid, string accessToken, Action<LoginResponse> onComplete = null)
        {
            return Requester.Login(pid, accessToken, result =>
            {
                onComplete?.Invoke(result);

                if (result.isSuccess)
                {
                    GameInfo.SetLogin(result.data);
                }

            });
        }

        public static IRequest<TownViewResponse> TownView(Action<TownViewResponse> onComplete = null)
        {
            return Requester.TownView(result =>
            {
                onComplete?.Invoke(result);
                if (result.isSuccess)
                {
                    GameInfo.SetTown(result.data);
                }
            });
        }

        public static IRequest<GrowthinflationResponse> Growthinflation(Action<GrowthinflationResponse> onComplete = null)
        {
            return Requester.Growthinflation(result =>
            {
                onComplete?.Invoke(result);
                if (result.isSuccess)
                {
                    GameInfo.SetLevel(result.data);
                    GameInfo.SetContents(result.data);
                }
            });
        }

        public static IRequest<StealTargetResponse> StealTarget(Action<StealTargetResponse> onComplete = null)
        {
            return Requester.StealTarget(result =>
            {
                onComplete?.Invoke(result);
                if (result.isSuccess)
                {
                    GameInfo.StealTargetData = result.data;
                }
            });
        }

        public static IRequest<GetProfileResponse> UserEnergyInfo(Action<GetProfileResponse> onComplete = null)
        {
            return Requester.GetProfile(result =>
            {
                onComplete?.Invoke(result);
                if (result.isSuccess)
                {
                    //GameInfo.set
                    GameInfo.EnergyInfo = result.data.userData.userEnergyInfo;
                    // GameInfo.StealTargetData = result.data;
                }
            });
        }

        public static IRequest<GetProfileResponse> UserInfo(Action<GetProfileResponse> onComplete = null)
        {
            return Requester.GetProfile(result =>
            {
                onComplete?.Invoke(result);
                if (result.isSuccess)
                {
                    //GameInfo.set
                    GameInfo.EnergyInfo = result.data.userData.userEnergyInfo;
                    GameInfo.userInfo.shield_max = result.data.userData.shieldMax;
                    GameInfo.SetGoods(eGoodsType.shield, result.data.userData.shield);
                }
            });
        }

        public static IRequest<GetProfileResponse> UserShieldInfo(Action<GetProfileResponse> onComplete = null)
        {
            return Requester.GetProfile(result =>
            {
                onComplete?.Invoke(result);
                if (result.isSuccess)
                {                    
                    GameInfo.SetGoods(eGoodsType.shield, result.data.userData.shield);
                }
            });
        }

        public static IRequest<GetProfileResponse> UserMoneyInfo(Action<GetProfileResponse> onComplete = null)
        {
            return Requester.GetProfile(result =>
            {
                onComplete?.Invoke(result);
                if (result.isSuccess)
                {
                    GameInfo.SetGoods(eGoodsType.money, result.data.userData.gameMoney);
                }
            });
        }

        public static IRequest<MainGameStateResponse> MainGameState(Action<MainGameStateResponse> onComplete = null)
        {
            return Requester.MainGameState(result =>
            {
                onComplete?.Invoke(result);
                if (result.isSuccess)
                {
                    onComplete?.Invoke(result);

                    GameInfo.EnergyInfo = result.data.energyInfo;
                    GameInfo.BetList = result.data.totalBetList;

                    // 배수 리스트에 베팅 가능한 값이 없는 경우에 대한 예외처리가 되어야 함.
                    // 24.01.11 지금은 처리가 안되어 있고 서버에서 주는 값으로 세팅하고 있음.                    
                    GameInfo.userInfo.bet_info.CurrentBet = result.data.bet;

                    GameInfo.mainGameInfo.deckType = result.data.deckType;
                    GameInfo.mainGameInfo.canShuffleCount = result.data.canShuffleCount;
                    GameInfo.TotalfreeRemainCount = result.data.totalfreeRemainCount;

                    GameInfo.mainGameInfo.remainDeckCount = result.data.remainDeckCount;
                    GameInfo.mainGameInfo.maxCardDeckCount = result.data.maxCardDeckCount;
                    GameInfo.mainGameInfo.gameState = result.data.gameState;
                    GameInfo.mainGameInfo.remainSymbolCountList = result.data.remainSymbolCountList;
                    GameInfo.mainGameInfo.selectedSymbolIdList = result.data.selectedSymbolIdList;
                }
                else
                {

                }
            });
        }

        public static IRequest<UserLogNotiResponse> LoadUserLogNoti(Action<UserLogNotiResponse> onComplete = null)
        {
            return Requester.UserLogNoti(result => 
            {
                onComplete?.Invoke(result);
                if (result.isSuccess)
                {
                    GameInfo.alarmInfo.EnqueueUserLogs(result.data.userLogDataList);
                }
            });
        }

        public static IRequest<AssetVersionResponse> AssetVersion(Action<AssetVersionResponse> onComplete = null)
        {
            return Requester.AssetVersion(result =>
            {
                onComplete?.Invoke(result);
                if (result.isSuccess)
                {
                    string oldAddressablesVersionStr = GameAddress.AddressablesVersion;
                    int.TryParse(oldAddressablesVersionStr, out int oldAddressablesVersion);
                    string newAddressablesVersionStr = result.data.assetVersion;
                    int.TryParse(newAddressablesVersionStr, out int newAddressablesVersion);

                    GameAddress.UpdateAddressablesVersion(result.data.assetVersion);

                    Debug.Log($"LoadNewCatalog : {oldAddressablesVersion} -> {newAddressablesVersion}");
                    if (newAddressablesVersion > oldAddressablesVersion)
                    {
                        //AddressablesLoader.Instance.LoadNewCatalog(newAddressablesVersion);
                    }
                }
            });
        }
    }
}