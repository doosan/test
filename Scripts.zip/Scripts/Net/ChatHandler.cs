using BestHTTP.SignalRCore;
using epoch.Client.Chat;
using Newtonsoft.Json;
using System;
using UnityEngine;
using UnityEngine.Events;

namespace SlotKingdoms.Net
{
    public enum SignalRType
    {
        None = 0, // 아무상태 아님
        Steal = 1, // 스틸당한 상태
        Attack = 2, // 공격받은 상태
        Defense = 3, // 방어에 성공한 상태
        Upgrade = 4,
        Repaire = 5,
    }

    public class SignalRNotice
    {
        public int Type { get; set; } = 0;          // SignalRType
        public string SourcePid { get; set; } = ""; // 발신자 pid
        public string TargetPid { get; set; } = ""; // 수신자 pid
        public long RegDateTs { get; set; } = 0;    // DB에 등록된 시간
    }

    public sealed class ChatMessageArrivedEvent : UnityEvent<SignalRType, string, string, long> { }

    public sealed class ChatHandler
    {
        public EpochChatState EpochChatState
        {
            get;
            private set;
        }

        public ChatMessageArrivedEvent onMessageArrived = new ChatMessageArrivedEvent();

        public string AccessToken
        {
            private get;
            set;
        }
        public string Pid
        {
            private get;
            set;
        }

        public void InitAndConnectChat()
        {
            if (string.IsNullOrEmpty(AccessToken))
            {
                SetEpochChatState(EpochChatState.NeedAccessToken);
            }
            else
            {
                SetEpochChatState(EpochChatState.Init);

                EpochChat.Init(
                    AccessToken,
                    _onConnected: (HubConnection connection) =>
                    {
                        SetEpochChatState(EpochChatState.Connected);
                    },
                    _onCloseCB: (HubConnection connect) =>
                    {
                        SetEpochChatState(EpochChatState.Closed);
                    },
                    _onErrorCB: (HubConnection connect, string error) =>
                    {
                        SetEpochChatState(EpochChatState.Errored);
                    },
                    _onEnterFullGroupMember: (ChatPartnerInfoModel model) =>
                    {
                        Debug.Log($"[EpochChat._onEnterFullGroupMember] {model.PartnerPid}");
                    },
                    _onLeaveFullGroupMember: (string pid) =>
                    {
                        Debug.Log($"[EpochChat._onLeaveFullGroupMember] {pid}");
                    },
                    _onCallerRcvMessage: (ChatReceivedMessageModel model) =>
                    {
                        Debug.Log($"[EpochChat._onCallerRcvMessage] {model.Pid}, {model.Message}, {model.GroupKey}, {model.GetGroupType()}");
                    },
                    _onRcvMessage: (ChatReceivedMessageModel model) =>
                    {
                        Debug.Log($"[EpochChat._onRcvMessage] {model.Pid}, {model.Message}, {model.GroupKey}, {model.GetGroupType()}");
                    },
                    _onRcvGameGroupMessage: (string model) =>
                    {
                        Debug.Log($"[EpochChat._onRcvGameGroupMessage] {model}");

                        var message = JsonConvert.DeserializeObject<SignalRNotice>(model);

                        int typeValue = message.Type;
                        SignalRType type = (SignalRType)typeValue;
                        string sourcePid = message.SourcePid;
                        string targetPid = message.TargetPid;
                        long regDateTs = message.RegDateTs;
                        onMessageArrived.Invoke(type, sourcePid, targetPid, regDateTs);
                        if (Enum.IsDefined(typeof(SignalRType), type) == false)
                        {
                            Debug.LogWarning($"SignalRType 에 정의되지 않은 타입입니다 : {typeValue}, {sourcePid}, {targetPid}, {regDateTs}");
                        }
                    },
                    _onChatConnectedChange: (bool isConnected) =>
                    {
                        Debug.Log($"[EpochChat._onChatConnectedChange] {isConnected}");
                        if (isConnected)
                        {
                            SetEpochChatState(EpochChatState.ChatConnected);
                        }
                    },
                    _onChatError: (OnErrorChatModel model) =>
                    {
                        Debug.Log($"[EpochChat._onChatError] {model.ResultNo}, {model.ResultMsg}");
                    }
                );
                EpochChat.Connect();
            }
        }

        private void SetEpochChatState(EpochChatState state)
        {
            Debug.Log($"[EpochChat.SetEpochChatState] {state}");
            EpochChatState = state;

            if (state == EpochChatState.Connected)
            {
                EpochChat.OpenChat();
            }
        }
    }
}
