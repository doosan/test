using System;
using System.Collections.Generic;

namespace SlotKingdoms.Net
{
    [Serializable]
    public sealed class AssetVersionData
    {
        public string assetVersion;
    }

    //[Serializable]
    //public sealed class CommonRewardData
    //{
    //    public string rwd;
    //    public long val;

    //    public CommonRewardData(string rwd, long val)
    //    {
    //        this.rwd = rwd;
    //        this.val = val;
    //    }
    //}

    [Serializable]
    public sealed class AttackTargetFriendData
    {
        public string pid;
        public Profiles profile { get; set; } = new();
        public int target_count;

        public AttackTargetFriendData(Profiles profile, int target_count)
        {
            pid = "0";
            this.profile = profile;
            this.target_count = target_count;
        }
    }

    [Serializable]
    public sealed class AttackTargetListData
    {
        public List<AttackTargetRevengeData> revengeList;
        public List<AttackTargetFriendData> friendsList;
    }
}