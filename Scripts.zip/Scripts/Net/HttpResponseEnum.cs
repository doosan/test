using System;
using System.Collections.Generic;

namespace SlotKingdoms.Net
{
#pragma warning disable IDE1006 // 명명 스타일

    //[Flags]
    public enum eGoodsType   // : byte
    {
        none = 0,        
        money = 1,   //1<<0
        energy = 2,
        shield = 3,
        hammer = 4,
        star = 100,  //클라에서 임시로 사용
    }

    ////서버에서 넘어오는 재화 타입
    //public enum GoodsType
    //{
    //    GoodsType_None = 0,
    //    GoodsType_Money = 1, // 게임머니
    //    GoodsType_Energy = 2, // 에너지
    //    GoodsType_Shield = 3, // 쉴드
    //    GoodsType_Hammer = 4, // 망치
    //}

    public enum eSlotResultType
    {
        None = 0,
        Coin = 1,
        Spin = 2,
        Shield = 3,
        Attack = 4,
        Raid = 5,
    }

    public enum eNewsType
    {
        Attack = 0,
        Raid = 1,
        Shield = 2,
    }

    public enum InflationState
    {
        Lock = 0,
        Unlock = 1,
        Max = 2,
    }

    public enum InflationType
    {
        None = 0,
        AutoPlay = 1,               // AUTO 플레이 해금
        Multiply = 2,               // 멀티플라이어 배수 해금
        Album = 3,                  // 앨범 해금
        DailyMission = 4,           // 데일리 미션 해금
        DailyGift = 5,              // 데일리 선물 해금
        AttackMultiple = 6,         // 공격 보상 계수(배수)
        StealMultiple = 7,          // 스틸 보상 계수(배수)
        HatchMultiple = 8,          // 해치보난자 배수
        ChargeEnergyMax = 9,        // 충전 에너지 최대치 증가
        ChargeEnergyPerHour = 10,   // 시간당 에너지 충전량 증가
        StickerConvert = 11,        // 스티커 컨버트
        ShieldMax = 12,             // 쉴드 최대치 증가
        DailyGiftRewardInc = 13,    // 데일리 선물 보상 증가
        RotationEvent = 14,         // 로테이션 이벤트 해금
        RotationTonerment = 15,     // 로테이션 토너먼트 해금
        Memory = 16,                // 메모리 해금
    }

    public enum BenefitType
    {
        None = 0,
        Percent = 1,
        Add = 2,
        Memory = 3,
    }

    public enum eSkinType
    {
        None = 0,
        Card = 1,
        Attack = 2,
        Shield = 3,
    }

    public enum eProfilesImageType
    {
        Index,  // (int 값이 아닌) string 값으로 리턴 받습니다.
        Url
    }

    public enum eUserLogType
    {
        None = 0,       // 아무상태 아님
        Steal = 1,      // 스틸당한 상태
        Attack = 2,     // 공격받은 상태
        Defense = 3,    // 방어에 성공한 상태
    }

#pragma warning restore IDE1006 // 명명 스타일
}
