using UnityEngine;
using System;
using System.Collections;
using BestHTTP;
using Newtonsoft.Json;
using UnityEngine.Events;

namespace SlotKingdoms.Net
{
    public enum RetryError
    {
        None,
        NetworkOrHttp,
        JsonParsing
    }

    public interface IRequest<T>
    {
        bool IsSuccess { get; }

        T Data { get; }

        IEnumerator WaitForResponse();
    }

    public sealed class RequestInfo<T> where T : ClientResponse
    {
        public T data;
        public bool isDone;
    }

    public sealed class Request<T> : IRequest<T>
                                     where T : ClientResponse
    {
        public T Data
        {
            get => info != null ? info.data : null;
        }

        public bool IsDone
        {
            get => info != null ? info.isDone : false;
        }

        public bool IsSuccess
        {
            get => Data.isSuccess;
        }

        private RequestInfo<T> info;

        public Request(RequestInfo<T> info)
        {
            this.info = info;
        }

        public IEnumerator WaitForResponse()
        {
            while (IsDone == false)
            {
                yield return null;
            }
        }
    }

    public class ErrorEvent : UnityEvent<string, string> { }

    public struct HttpRequesterSetting
    {
        public double connectTimeout;
        public double timeout;
        public int retry;
    }

    public sealed class HttpRequester : MonoBehaviour
    {
        public HttpRequesterSetting Setting
        {
            private get;
            set;
        }
        public readonly HttpRequesterSetting DefaultSetting = new HttpRequesterSetting()
        {
            connectTimeout = 5,
            timeout = 20,
            retry = 3
        };
        
        public ErrorEvent onError = new ErrorEvent();

        private Hashtable cachedBody;

        private void Awake()
        {
            cachedBody = new Hashtable();
            Setting = DefaultSetting;
        }

        private Hashtable GetCommonBody(bool addPidAndSessionid = true)
        {
            cachedBody.Clear();
            if (addPidAndSessionid)
            {
                cachedBody["pid"] = GameInfo.userInfo.pid;
                cachedBody["ssionid"] = GameInfo.userInfo.ssionid;
            }
            return cachedBody;
        }

        public Request<T> Get<T>(string uri, Hashtable body, Action<T> onComplete) where T : ClientResponse, new()
        {
            return Send<T>(HTTPMethods.Get, uri, body, onComplete);
        }

        public Request<T> Post<T>(string uri, Hashtable body, Action<T> onComplete) where T : ClientResponse, new()
        {
            return Send<T>(HTTPMethods.Post, uri, body, onComplete);
        }

        public Request<T> Put<T>(string uri, Hashtable body, Action<T> onComplete) where T : ClientResponse, new()
        {
            return Send<T>(HTTPMethods.Put, uri, body, onComplete);
        }

        private Request<T> Send<T>(HTTPMethods methods, string uri, Hashtable body, Action<T> onComplete) where T : ClientResponse, new()
        {
            string json = null;

            if (body != null)
            {
                json = JsonConvert.SerializeObject(body);
            }

            var info = new RequestInfo<T>();
            var req = new Request<T>(info);

            StartCoroutine(SendCoroutine<T>(methods, uri, json, info, onComplete));
            return req;
        }

        private IEnumerator SendCoroutine<T>(HTTPMethods methods, string uri, string json, RequestInfo<T> info, Action<T> onComplete) where T : ClientResponse, new()
        {
            Debug.Log($"<color=#13A10E>[SendCoroutine.Send]</color> method: {methods}, uri: {uri}, json: {json}");

            HTTPRequest httpRequest = new HTTPRequest(new Uri(uri), methods);
            httpRequest.SetHeader("Content-Type", "application/json; charset=UTF-8");
            httpRequest.RawData = System.Text.Encoding.UTF8.GetBytes(json);
            httpRequest.ConnectTimeout = TimeSpan.FromSeconds(Setting.connectTimeout);
            httpRequest.Timeout = TimeSpan.FromSeconds(Setting.timeout);
            httpRequest.MaxRetries = Setting.retry;
            httpRequest.Send();

            yield return httpRequest;

            T resp;
            string responseStatus;
            switch (httpRequest.State)
            {
                case HTTPRequestStates.Finished:
                    HTTPResponse httpResponse = httpRequest.Response;
                    responseStatus = $"{httpResponse.StatusCode}-{httpResponse.Message}";
                    if (httpResponse.IsSuccess)
                    {
                        string respJson = httpResponse.DataAsText;
                        Debug.Log($"<color=#13A10E>[SendCoroutine.Receive]</color> method: {methods}, uri: {uri}, detail: {responseStatus}, json: {respJson}");

                        resp = JsonConvert.DeserializeObject<T>(respJson);
                        resp.isSuccess = true;
                        resp.rawData = respJson;
                        resp.statusCode = httpResponse.StatusCode;

                        if (resp.message != "success")
                        {
                            resp.isSuccess = false;
                            Debug.LogWarning($"<color=#EAA300>[SendCoroutine.Receive]</color> method: {methods}, uri: {uri}, detail: {responseStatus}, json: {respJson}");
                        }
                    }
                    else
                    {
                        string respJson = httpResponse.DataAsText;
                        Debug.LogWarning($"<color=#EAA300>[SendCoroutine.Receive]</color> method: {methods}, uri: {uri}, detail: {responseStatus}, json: {respJson}");

                        resp = string.IsNullOrEmpty(respJson) == false ?
                               JsonConvert.DeserializeObject<T>(respJson) :
                               new T();
                        resp.isSuccess = false;
                        resp.rawData = respJson;
                        resp.statusCode = httpResponse.StatusCode;

                        resp.error = $"{responseStatus}: {resp.code}";

                        onError.Invoke(resp.code, respJson);
                    }
                    break;

                default:
                    responseStatus = httpRequest.State.ToString();
                    string exception = httpRequest.Exception?.ToString();

                    Debug.LogWarning($"<color=#D13438>[SendCoroutine.Error]</color> method: {methods}, uri: {uri}, detail: {responseStatus}, exception: {exception}");

                    resp = new T();
                    resp.isSuccess = false;
                    resp.error = $"{responseStatus}: {exception}";

                    onError.Invoke(responseStatus, exception);
                    break;
            }

            if (resp.isSuccess == true)
            {
                GlobalTime.Instance.SetTimeStamp(resp.ts);
            }

            if (onComplete != null)
            {
                onComplete(resp);
            }

            if (info != null)
            {
                info.data = resp;
                info.isDone = true;
            }
        }

        public IRequest<AssetVersionResponse> AssetVersion(Action<AssetVersionResponse> onComplete = null)
        {
            var body = GetCommonBody(false);
            body["platform"] = (int)GameConfig.RuntimeTarget;
            body["clientVersion"] = Application.version;

            return Post(GameAddress.UriRoute("v1/etc/assetversion"), body, onComplete);
        }

        public IRequest<LoginResponse> Login(string pid, string accessToken, Action<LoginResponse> onComplete = null)
        {
            Hashtable body = GetCommonBody();
            body["pid"] = pid;
            body["accessToken"] = accessToken;
            
            return Post(GameAddress.UriRoute("v1/lobby/login"), body, onComplete);
        }

        public Request<TargetResponse> Target(string platform, Action<TargetResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["platform"] = platform;
            body["version"] = Application.version;

            return Post(GameAddress.UriRoute("v1/target"), body, onComplete);
        }

        public Request<PurchaseResponse> Purchase(string sessionTicket, string itemID, Action<PurchaseResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pf_sess"] = sessionTicket;
            body["itemid"] = itemID;
            
            return Post(GameAddress.UriRoute("v1/purchase"), body, onComplete);
        }

        public Request<SetProfileResponse> SetProfile(string pid, Profiles userProfiles, Action<SetProfileResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pid"] = GameInfo.userInfo.pid;
            body["ssionid"] = GameInfo.userInfo.ssionid;
            body["userProfiles"] = userProfiles;

            return Put(GameAddress.UriRoute("v1/lobby/profile"), body, onComplete);
        }

        public Request<GetProfileResponse> GetProfile(Action<GetProfileResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pid"] = GameInfo.userInfo.pid;
            body["ssionid"] = GameInfo.userInfo.ssionid;

            return Get(GameAddress.UriRoute("v1/lobby/profile"), body, onComplete);
        }

        public Request<TownViewResponse> TownView(Action<TownViewResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pid"] = GameInfo.userInfo.pid;
            body["ssionid"] = GameInfo.userInfo.ssionid;

            return Post(GameAddress.UriRoute("v1/town/townview"), body, onComplete);
        }

        public Request<TownUpgradeResponse> TownUpgrade(int townNo, int objectNo, Action<TownUpgradeResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pid"] = GameInfo.userInfo.pid;
            body["ssionid"] = GameInfo.userInfo.ssionid;
            body["townNo"] = townNo;
            body["objectNo"] = objectNo;

            return Post(GameAddress.UriRoute("v1/town/townupgrade"), body, onComplete);
        }

        public Request<TownUpgradeResponse> TownRepair(int townNo, int objectNo, Action<TownUpgradeResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pid"] = GameInfo.userInfo.pid;
            body["ssionid"] = GameInfo.userInfo.ssionid;
            body["townNo"] = townNo;
            body["objectNo"] = objectNo;

            return Post(GameAddress.UriRoute("v1/town/townrepair"), body, onComplete);
        }

        public Request<GetTutorialResponse> GetTutorial(Action<GetTutorialResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pid"] = GameInfo.userInfo.pid;
            body["ssionid"] = GameInfo.userInfo.ssionid;

            return Post(GameAddress.UriRoute("v1/etc/gettutorial"), body, onComplete);
        }

        public Request<GetTutorialResponse> SetTutorial(string tutorialData, Action<GetTutorialResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pid"] = GameInfo.userInfo.pid;
            body["ssionid"] = GameInfo.userInfo.ssionid;
            body["tutorialData"] = tutorialData;

            return Post(GameAddress.UriRoute("v1/etc/settutorial"), body, onComplete);
        }

        public Request<TownMapResponse> TownMap(Action<TownMapResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pid"] = GameInfo.userInfo.pid;
            body["ssionid"] = GameInfo.userInfo.ssionid;

            return Post(GameAddress.UriRoute("v1/town/townmap"), body, onComplete);
        }

        public Request<MemoryRestoreResponse> MemoryRestore(int mainNo, int subNo, TileInfo tileInfo, Action<MemoryRestoreResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pid"] = GameInfo.userInfo.pid;
            body["ssionid"] = GameInfo.userInfo.ssionid;
            body["mainNo"] = mainNo;
            body["subNo"] = subNo;
            body["tileInfo"] = tileInfo;

            return Post(GameAddress.UriRoute("v1/memory/memoryrestore"), body, onComplete);
        }

        public Request<MemoryListResponse> MemoryList(Action<MemoryListResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pid"] = GameInfo.userInfo.pid;
            body["ssionid"] = GameInfo.userInfo.ssionid;

            return Post(GameAddress.UriRoute("v1/memory/memorylist"), body, onComplete);
        }

        public Request<GrowthinflationResponse> Growthinflation(Action<GrowthinflationResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pid"] = GameInfo.userInfo.pid;
            body["ssionid"] = GameInfo.userInfo.ssionid;

            return Post(GameAddress.UriRoute("v1/GrowthInflation/inflation"), body, onComplete);
        }

        public Request<GrowthInflationTypeNextInfoResponse> GrowthInflationTypeNextInfo(int inflationNo, Action<GrowthInflationTypeNextInfoResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pid"] = GameInfo.userInfo.pid;
            body["ssionid"] = GameInfo.userInfo.ssionid;
            body["inflationNo"] = inflationNo;

            return Post(GameAddress.UriRoute("v1/GrowthInflation/inflationtypenextinfo"), body, onComplete);
        }

        public Request<StealTargetResponse> StealTarget(Action<StealTargetResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pid"] = GameInfo.userInfo.pid;
            body["ssionid"] = GameInfo.userInfo.ssionid;

            return Post(GameAddress.UriRoute("v1/lobby/StealTarget"), body, onComplete);
        }       

        public IRequest<UserLogNotiResponse> UserLogNoti(Action<UserLogNotiResponse> onComplete = null)
        {
            Hashtable body = GetCommonBody();

            return Post(GameAddress.UriRoute("v1/etc/userlognoti"), body, onComplete);
        }

        public Request<MainGameStateResponse> MainGameState(Action<MainGameStateResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pid"] = GameInfo.userInfo.pid;
            body["ssionid"] = GameInfo.userInfo.ssionid;            

            return Get(GameAddress.UriRoute("v1/maingame/state"), body, onComplete);
        }
        public Request<DrawResponse> MainGameDraw(Action<DrawResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pid"] = GameInfo.userInfo.pid;
            body["ssionid"] = GameInfo.userInfo.ssionid;
            body["bet"] = GameInfo.userInfo.bet_info.CurrentBet;

            return Post(GameAddress.UriRoute("v1/maingame/draw"), body, onComplete);
        }
        public Request<PickResponse> MainGamePick(string _cheatsym = null, string _cheatDetail = null, Action<PickResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pid"] = GameInfo.userInfo.pid;
            body["ssionid"] = GameInfo.userInfo.ssionid;
            if (_cheatsym != null)
            {
                body["cheatSym"] = _cheatsym;
                if (_cheatDetail != null)
                {
                    body["cheatDetail"] = _cheatDetail; //HatchStartPickCount
                    //body["cheatValue"] = 25;
                }
            }

            return Post(GameAddress.UriRoute("v1/maingame/pick"), body, onComplete);
        }
        public Request<ShuffleResponse> MainGameShuffle(Action<ShuffleResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pid"] = GameInfo.userInfo.pid;
            body["ssionid"] = GameInfo.userInfo.ssionid;

            return Post(GameAddress.UriRoute("v1/maingame/shuffle"), body, onComplete);
        }

        public Request<TownAttackTargetViewResponse> TownAttackTargetView(Action<TownAttackTargetViewResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pid"] = GameInfo.userInfo.pid;
            body["ssionid"] = GameInfo.userInfo.ssionid;

            return Post(GameAddress.UriRoute("v1/town/townattacktargetview"), body, onComplete);
        }

        public Request<TownAttackTargetViewResponse> TownAttackTargetTown(string targetPid, Action<TownAttackTargetViewResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pid"] = GameInfo.userInfo.pid;
            body["ssionid"] = GameInfo.userInfo.ssionid;
            body["targetPid"] = targetPid;

            return Post(GameAddress.UriRoute("v1/town/townattacktargettown"), body, onComplete);
        }

        public Request<TownAttackResponse> TownAttack(string targetPid, int targetTownNo, int targetObjectNo, Action<TownAttackResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pid"] = GameInfo.userInfo.pid;
            body["ssionid"] = GameInfo.userInfo.ssionid;
            body["targetPid"] = targetPid;
            body["targetTownNo"] = targetTownNo;
            body["targetObjectNo"] = targetObjectNo;

            return Post(GameAddress.UriRoute("v1/town/townattack"), body, onComplete);
        }

        public Request<TownAttackTargetChangeListResponse> TownAttackTargetChangeList(Action<TownAttackTargetChangeListResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pid"] = GameInfo.userInfo.pid;
            body["ssionid"] = GameInfo.userInfo.ssionid;
           
            return Post(GameAddress.UriRoute("v1/town/townattacktargetchangelist"), body, onComplete);
        }

        public Request<ClientResponse> PickHatchAction(int pickIndex, Action<ClientResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pid"] = GameInfo.userInfo.pid;
            body["ssionid"] = GameInfo.userInfo.ssionid;
            body["types"] = "hatch";
            body["pickIndex"] = pickIndex;

            return Post(GameAddress.UriRoute("v1/maingame/pickaction"), body, onComplete);
        }

        public Request<ClientResponse> PickStealAction(int pickIndex, Action<ClientResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pid"] = GameInfo.userInfo.pid;
            body["ssionid"] = GameInfo.userInfo.ssionid;
            body["types"] = "steal";
            body["pickIndex"] = pickIndex;

            return Post(GameAddress.UriRoute("v1/maingame/pickaction"), body, onComplete);
        }

        public Request<BetResponse> Bet(long bet, Action<BetResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pid"] = GameInfo.userInfo.pid;
            body["ssionid"] = GameInfo.userInfo.ssionid;
            body["bet"] = bet;

            return Post(GameAddress.UriRoute("v1/maingame/bet"), body, onComplete);
        }



        /// <summary>
        /// 치트 관련 패킷
        /// </summary>
        public Request<CheatResponse> CheatMoney(long value, Action<CheatResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pid"] = GameInfo.userInfo.pid;
            body["ssionid"] = GameInfo.userInfo.ssionid;
            body["game_money"] = value;
            //body["energy"] = 10;

            return Post(GameAddress.UriRoute("v1/system/cheat"), body, onComplete);
        }

        public Request<CheatResponse> CheatEnergy(long value, Action<CheatResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pid"] = GameInfo.userInfo.pid;
            body["ssionid"] = GameInfo.userInfo.ssionid;
            body["energy"] = value;

            return Post(GameAddress.UriRoute("v1/system/cheat"), body, onComplete);
        }

        public Request<CheatResponse> CheatMega(long value, Action<CheatResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pid"] = GameInfo.userInfo.pid;
            body["ssionid"] = GameInfo.userInfo.ssionid;
            body["cheatType"] = "Mega";
            body["values"] = value;

            return Post(GameAddress.UriRoute("v1/system/cheat"), body, onComplete);
        }

        public Request<ClientResponse> CheatStealTarget(string targetPid, Action<ClientResponse> onComplete = null)
        {
            var body = GetCommonBody();
            body["pid"] = GameInfo.userInfo.pid;
            body["ssionid"] = GameInfo.userInfo.ssionid;
            body["stealTargetPid"] = targetPid;

            return Post(GameAddress.UriRoute("v1/system/stealTargetChangeCheat"), body, onComplete);
        }
    }
}