using DG.Tweening;
using SlotKingdoms.Effect;
using SlotKingdoms.Net;
using SlotKingdoms.Popup;
using SlotKingdoms.Sound;
using SlotKingdoms.Transition;
using UnityEngine;

namespace SlotKingdoms
{
    public class GameInitializer
    {
        private static bool initOnce = false;
        
        public static void Init()
        {
            if (initOnce == true)
            {
                return;
            }

            Debug.Log("GameInitializer.Init()");
            initOnce = true;

            // #주의사항
            // 1. 이곳에서 호출하는 메서드에 Addressables 에셋을 로드하는 로직이 포함되어 있으면 게임 진행이 되지 않는 문제가 있습니다.
            // 2. 따라서 Addresssbles 에셋을 로드하는 로직은 IntroLoadingScreen 에 포함되어야 합니다.
            
            GameAddress.Init(GameConfig.BuildType, GameConfig.RuntimeTarget);

            ScreenSystem.Instance.Initialize();
            ScreenSystem.Instance.SetResolution(GameConfig.ResolutionWidth, GameConfig.ResolutionHeight, ScreenMatchMode.Height);

            LoadingScreenSystem.Instance.Initialize("Loading", GameConfig.ResolutionWidth, GameConfig.ResolutionHeight, ScreenMatchMode.Expand, pixelsPerUnit: 100, depth: 40);

            PopupSystem.Instance.Initialize("S_Popup", GameConfig.ResolutionWidth, GameConfig.ResolutionHeight, ScreenMatchMode.Expand, pixelsPerUnit: 100, depth: 50);
            GoodsEffectSystem.Instance.Initialize("Effect", GameConfig.ResolutionWidth, GameConfig.ResolutionHeight, 60);
            TransitionSystem.Instance.Initialize("Transition", GameConfig.ResolutionWidth, GameConfig.ResolutionHeight, ScreenMatchMode.Expand, pixelsPerUnit: 100, depth: 70);
            SoundSystem.Instance.Initialize();

            Input.multiTouchEnabled = false;

            // todo : 유저 세팅 정보를 불러와서 사운드 볼륨을 설정해줘야 함
            //MySettings mySettings = MyInfo.Settings;
            //SoundSystem.Instance.SfxVolumeLimit = mySettings.SoundVolume;
            //SoundSystem.Instance.BgmVolumeLimit = mySettings.BgmVolume;

            AddressablesLoader.Instance.Initialize();

            NetworkSystem.Initialize();
            DownloadSystem.Instance.Initialize();
            DownloadMonitor.Instance.Initialize(15);

            DOTween.SetTweensCapacity(1000, 200);
        }
    }
}