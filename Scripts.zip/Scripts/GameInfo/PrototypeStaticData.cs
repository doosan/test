
namespace SlotKingdoms
{
    public class PrototypeStaticData
    {
        //#region 유저 초기 세팅 테이블
        /**
         * 0: 코인, 1: 에너지, 2: 루비, 3: 별, 4: 쉴드, 5: 스타코인
         */
        public static readonly long[] InitValueTable =
        {
            200000,
            50,
            500,
            0,
            0,
            0,
        };
        //#endregion

        public static readonly long[][] BetTable =
        {
            new long[] {0, 0, 1 },
            new long[] {1, 50, 2},
            new long[] {1, 100, 3},
            new long[] {1, 150, 5},
            new long[] {1, 250, 10},
            new long[] {1, 500, 15},
            new long[] {1, 1000, 20},
            new long[] {1, 1500, 30},
            new long[] {1, 2000, 50},
            new long[] {2, 3000, 100},
            new long[] {3, 4000, 200},
            new long[] {3, 5000, 300},
            new long[] {3, 7000, 500},
            new long[] {3, 10000, 1000},
        };

        //#region 건물비용 테이블
        /**
         * 맵 -> 건물인덱스 -> 레벨 3차원 배열
         */
        public static readonly long[][][] PriceTable =
        {
            new long[][] {   //맵0
                new long[] {50000,50000,50000,50000,50000},     //건물1
                new long[] {60000,60000,60000,60000,60000},     //건물2
                new long[] {80000,80000,80000,80000,80000},     //건물3
                new long[] {130000,130000,130000,130000,130000},   //건물4
                new long[] {160000,160000,160000,160000,160000}    //건물5
            },
            new long[][] {   //맵1
                new long[] {60000,81000,102000,118000,162000},     //건물1
                new long[] {72000,97000,133000,142000,194000},     //건물2
                new long[] {84000,117000,160000,172000,226000},     //건물3
                new long[] {144000,202000,276000,297000,388000},   //건물4
                new long[] {186000,259000,342000,368000,485000}    //건물5
            },
            new long[][] {   //맵2
                new long[] {100000,135000,169000,195000,267000},  //건물1 
                new long[] {120000,162000,221000,234000,320000},  //건물2 
                new long[] {140000,195000,267000,283000,373000},  //건물3 
                new long[] {240000,337000,460000,488000,640000},  //건물4 
                new long[] {310000,431000,570000,605000,800000}   //건물5
            },
            new long[][] {   //맵3
                new long[] {160000,216000,271000,313000,429000},   //건물1 
                new long[] {192000,259000,354000,376000,515000},   //건물2 
                new long[] {224000,312000,427000,455000,600000},   //건물3 
                new long[] {384000,539000,736000,784000,1029000},  //건물4 
                new long[] {495000,690000,913000,972000,1286000}   //건물5
            },
            new long[][] {   //맵4
                new long[] {220000,297000,372000,430000,589000}, //건물1 
                new long[] {264000,356000,485000,516000,707000}, //건물2 
                new long[] {308000,429000,585000,624000,824000}, //건물3 
                new long[] {528000,740000,1008000,1076000,1413000}, //건물4 
                new long[] {681000,947000,1250000,1334000,1776000}   //건물5
            },
            new long[][] {   //맵5
                new long[] {254000,343000,430000,497000,681000}, //건물1 
                new long[] {305000,412000,561000,596000,817000}, //건물2 
                new long[] {356000,497000,624000,721000,953000}, //건물3 
                new long[] {610000,858000,1075000,1243000,1634000}, //건물4 
                new long[] {787000,1098000,1333000,1541000,204300}  //건물5
            },
            new long[][] {   //맵6
                new long[] {269000,364000,456000,527000,722000}, //건물1 
                new long[] {323000,437000,547000,632000,866000}, //건물2 
                new long[] {377000,528000,661000,764000,1011000}, //건물3 
                new long[] {646000,910000,1140000,1318000,1733000}, //건물4 
                new long[] {834000,1165000,1414000,1634000,2166000}  //건물5
            },
            new long[][] {   //맵7
                new long[] {317000,433000,543000,627000,859000}, //건물1 
                new long[] {380000,520000,652000,752000,1031000}, //건물2 
                new long[] {444000,628000,787000,909000,1203000}, //건물3 
                new long[] {761000,1083000,1358000,1568000,2062000}, //건물4 
                new long[] {982000,1386000,1683000,1944000,2577000}  //건물5
            },
            new long[][] {   //맵8
                new long[] {396000,541000,679000,784000,1074000}, //건물1 
                new long[] {475000,649000,815000,941000,1289000}, //건물2 
                new long[] {554000,784000,985000,1137000,1504000}, //건물3 
                new long[] {950000,1353000,1698000,1960000,2578000}, //건물4 
                new long[] {1228000,1731000,2105000,2430000,3222000}  //건물5
            },
            new long[][] {   //맵8
                new long[] {463000,635000,799000,923000,1264000}, //건물1 
                new long[] {556000,762000,959000,1108000,1517000}, //건물2 
                new long[] {674800,912000,1159000,1338000,1770000}, //건물3 
                new long[] {1111000,1588000,1998000,2308000,3034000}, //건물4 
                new long[] {1435000,2032000,2477000,2861000,3792000}  //건물5
            },
        };
        //#endregion

        public static readonly long[][] TownRewardTable =
        {
            new long[] {5, 30, 10 },
            new long[] {5, 30, 10},
            new long[] {7, 50, 15},
            new long[] {10, 70, 20},
            new long[] {15, 90, 25},
            new long[] {15, 120, 30},
            new long[] {20, 150, 35},
            new long[] {20, 180, 40},
            new long[] {25, 210, 50},
            new long[] {30, 250, 60},
        };

        //#region 공격 보상 테이블
        /**
         * 레벨 그룹 -> 공격성공, 공격실패 보상 2차원 배열
         */
        public static readonly long[][] AttackRewardTable =
        {
            new long[] {200000,50000},
            new long[] {250000,75000},
            new long[] {300000,75000},
            new long[] {350000,75000},
            new long[] {400000,100000},
            new long[] {450000,100000},
            new long[] {500000,100000},
            new long[] {550000,125000},
            new long[] {600000,150000}
        };
        //#endregion

        public static readonly long[] StoryRewardTable =
        {
            10, 10, 15, 15, 20, 20, 25, 25
        };

        public static readonly long[] StoryNeedTable =
        {
            5, 10, 15, 20, 25, 30, 35, 40
        };

        //#region 챕터 보상 테이블
        /**
         * 각 챕터 -> 코인, 에너지 보상 2차원 배열
         */
        public static readonly long[][] ChapterRewardTable =
        {
            new long[] {1120000,50 },
            new long[] {1220000,60},
            new long[] {1340000,70},
            new long[] {1460000,80},
            new long[] {1560000,90},
            new long[] {1780000,100},
            new long[] {2000000,120},
            new long[] {2220000,150},
            new long[] {2440000,1000}
        };
        //#endregion
    
        //#region  코인심볼 테이블
        /**
         * 별레벨 -> 코인심볼 1,2,3 히트에 따른 코인보상
         */
        public static readonly long[][] CoinPaytable =
        {
            new long[] {10000,11800,71400},
            new long[] {10500,12400,75000},
            new long[] {11000,12900,78600},
            new long[] {11500,13500,82100},
            new long[] {12000,14100,85700},
            new long[] {12500,14700,89300},
            new long[] {12800,15100,91400},
            new long[] {13100,15400,94600},
            new long[] {13400,15800,95700}
        };
        //#endregion

        //#region  빅코인심볼 테이블
        /**
         * 별레벨 -> 빅코인심볼 1,2,3 히트에 따른 코인보상
         */
        public static readonly long[][] BigCoinPaytable =
        {
            new long[] {22000,45800,180000},
            new long[] {22800,47500,185000},
            new long[] {22800,47500,185000},
            new long[] {23500,49000,190000},
            new long[] {23500,49000,190000},
            new long[] {24100,50200,195000},
            new long[] {24100,50200,195000},
            new long[] {24600,51300,202000},
            new long[] {24600,51300,20200}
        };
        //#endregion

        public static readonly long[] OrangePotTable =
        {
            2, 3, 2, 3, 2, 5, 2, 3, 2, 3, 2
        };

        public static readonly long[] OrangePotTypeTable =
        {
            0, 1, 0, 1, 0, 2, 0, 1, 0, 1, 0
        };

        public static readonly long[] BluePotTableTemp =
        {
            10, 25, 3, 50, 5, 20, 15, 3, 5, 3, 5, 3, 5
        };

        public static readonly long[] BluePotTable =
        {
            10, 25, 3, 50, 5, 20, 15
        };

        public static readonly long[] BluePotTypeTable =
        {
            0, 1, 0, 2, 0, 1, 0
        };

        public static readonly long[] VioletPotTableTemp =
        {
            2, 3, 2, 5, 2, 3, 2, 2,2,2,3,3,3
        };

        public static readonly long[] VioletPotTable =
        {
            2, 3, 2, 5, 2, 3, 2
        };

        public static readonly long[] VioletPotTypeTable =
        {
            0, 1, 0, 2, 0, 1, 0
        };

        public static readonly long[] PotBonusBaseTable =
        {
            50000, 50000, 50000, 75000, 75000, 75000, 100000, 100000, 100000
        };

        public static readonly long[][] ShopTable =
        {
            new long[] {239,140, 670000},
            new long[] {299, 210, 1010000},
            new long[] {719, 595, 2850000},
            new long[] {1199, 1120, 5420000},
            new long[] {2999, 3150, 15700000},
            new long[] {5999, 7000, 34270000}
        };
    }
}
