
namespace SlotKingdoms
{
    public enum PurchaseRewardType
    {
        Coin
    }

    public class PurchaseRewardInfo
    {
        public PurchaseRewardType Type
        {
            get;
            private set;
        }
        public long Value
        {
            get;
            private set;
        }

        public PurchaseRewardInfo(PurchaseRewardType type, long value)
        {
            this.Type = type;
            this.Value = value;
        }
    }
}
