using SlotKingdoms.Net;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace SlotKingdoms
{
    public class ChangeGoodsInfoEvent : UnityEvent<long> { }

    public class GameInfo
    {
        public static int MaxStage = 10;
        public static UserInfo userInfo = new UserInfo();
        public static MainGameInfo mainGameInfo = new MainGameInfo();
        public static StoryInfo storyInfo;
        public static TownDataInfo townInfo;
        public static StealTargetData stealTargetData;
        public static AlarmInfo alarmInfo = new AlarmInfo();

        public static Dictionary<eGoodsType, long> waitGoodsDic = new Dictionary<eGoodsType, long>();
        public static Dictionary<eGoodsType, ChangeGoodsInfoEvent> OnChangeGoodsInfo = new();
        public static Dictionary<InflationType, int> inflationTypesInfo = new();
        public static Dictionary<int, int> inflationTutorialDic = new();

        public static UnityEvent OnChangeTownInfo = new();
        public static UnityEvent OnChangeStealTargetInfo = new();
        public static UnityEvent OnChangeBetInfo = new();
        public static UnityEvent OnChangeFreeCountInfo = new();
        //public static UnityEvent OnChangeMegaEndTs = new();

        public static readonly long TownBuildingCount = 5;
        public static readonly long TownBuildingLevelMax = 5;
        public static int TotalfreeRemainCount
        {
            set
            {
                mainGameInfo.totalfreeRemainCount = value;
                OnChangeFreeCountInfo.Invoke();
            }
        }

        public static EnergyInfo EnergyInfo
        {
            get { return userInfo.energyInfo; }
            set
            {
                userInfo.energyInfo = value;
                SetGoods(eGoodsType.energy, value.energy);
            }
        }

        public static bool moreBet = false;

        public static List<int> BetList
        {
            set
            {
                if (!moreBet && userInfo.bet_info.betList.Count > 0)
                {
                    moreBet = userInfo.bet_info.betList.Count < value.Count;
                }

                userInfo.bet_info.betList = value;

                if (moreBet == true && userInfo.bet_info.IsMax == false)
                {
                    moreBet = true;
                }
                else
                {
                    moreBet = false;
                }

                OnChangeBetInfo.Invoke();
            }
        }

        public static bool CanAutoBet
        {
            get { return inflationTypesInfo[InflationType.AutoPlay] == 0; }
        }

        public static long MegaEndTs
        {
            get { return userInfo.megaEndTs; }
            set
            {
                userInfo.megaEndTs = value;
                OnChangeStealTargetInfo.Invoke();
            }
        }

        public static long CanBuildCount
        {
            get
            {
                int count = 0;
                foreach (BuildingInfo buildingInfo in townInfo.buildings_info)
                {
                    if ((buildingInfo.broken || buildingInfo.level != TownBuildingLevelMax)
                        && buildingInfo.price <= GetGoodsValue(eGoodsType.money))
                    {
                        count++;
                    }
                }
                return count;
            }
        }

        public static bool CanSpin
        {
            get
            {
                //return false;
                return userInfo.bet_info.CurrentBet <= GetGoodsValue(eGoodsType.energy) || mainGameInfo.totalfreeRemainCount > 0;
            }
        }

        public static TownDataInfo TownInfo
        {
            set
            {
                townInfo = value;
                OnChangeTownInfo.Invoke();
            }
        }

        public static StealTargetData StealTargetData
        {
            set
            {
                stealTargetData = value;
                OnChangeStealTargetInfo.Invoke();
            }
        }

        public static void Release()
        {
            foreach (KeyValuePair<eGoodsType, ChangeGoodsInfoEvent> pair in OnChangeGoodsInfo)
            {
                pair.Value.RemoveAllListeners();
            }
            OnChangeTownInfo.RemoveAllListeners();
            OnChangeStealTargetInfo.RemoveAllListeners();
        }

        public static void AddGoodsListener(eGoodsType type, UnityAction<long> func)
        {
            if (OnChangeGoodsInfo.ContainsKey(type) == false)
            {
                OnChangeGoodsInfo.Add(type, new ChangeGoodsInfoEvent());
            }

            OnChangeGoodsInfo[type].AddListener(func);
        }

        public static void RemoveGoodsListener(eGoodsType type, UnityAction<long> func)
        {
            if (OnChangeGoodsInfo.ContainsKey(type) == false)
            {
                OnChangeGoodsInfo.Add(type, new ChangeGoodsInfoEvent());
            }

            OnChangeGoodsInfo[type].RemoveListener(func);
        }

        public static long GetGoods(eGoodsType type)
        {
            return userInfo.goodsDic[type];
        }

        public static long GetGoodsValue(eGoodsType type)
        {
            return userInfo.goodsDic[type];
        }

        private static void NotifyChangeGoodsInfo(eGoodsType type, long value)
        {
            if (OnChangeGoodsInfo.ContainsKey(type))
            {
                OnChangeGoodsInfo[type].Invoke(value);
            }
        }

        public static void AddWaitGoods(eGoodsType type, long value)
        {
            if (waitGoodsDic.ContainsKey(type))
            {
                waitGoodsDic[type] = waitGoodsDic[type] + value;
            }
            else
            {
                waitGoodsDic.Add(type, value);
            }
        }

        public static void SetGoods(eGoodsType type, long value)
        {
            if (waitGoodsDic.ContainsKey(type))
            {
                value -= waitGoodsDic[type];
            }

            if (userInfo.goodsDic.ContainsKey(type))
            {
                userInfo.goodsDic[type] = value;
            }
            else
            {
                userInfo.goodsDic.Add(type, value);
            }

            NotifyChangeGoodsInfo(type, value);
        }

        public static void AddGoods(eGoodsType type, long value, bool waitClear = false)
        {
            if (waitClear)
            {
                GameInfo.AddWaitGoods(type, -value);
            }

            long result = userInfo.goodsDic[type] + value;
            userInfo.goodsDic[type] = result;

            NotifyChangeGoodsInfo(type, result);
        }

        public static bool CanSubGoods(eGoodsType type, long value)
        {
            return GetGoodsValue(type) - value >= 0;
        }

        public static void SubGoods(eGoodsType type, long value)
        {
            long result = userInfo.goodsDic[type] - value;

            if (result < 0)
            {
                result = 0;
            }

            userInfo.goodsDic[type] = result;

            NotifyChangeGoodsInfo(type, result);
        }

        public static void SetLogin(LoginData data)
        {
            userInfo.pid = data.pid;

            SetGoods(eGoodsType.money, data.gameMoney);
            SetGoods(eGoodsType.energy, data.userEnergyInfo.energy);
            SetGoods(eGoodsType.shield, data.shield);
            SetGoods(eGoodsType.hammer, data.hammer);

            userInfo.megaEndTs = data.megaEndTs;
            userInfo.energyInfo = data.userEnergyInfo;
            userInfo.profiles = data.userProfiles;
            userInfo.shield_max = data.shieldMax;
        }

        public static TownDataInfo ConverTownData(UserTownInfo info)
        {
            TownDataInfo townDataInfo = new TownDataInfo();

            townDataInfo.stage = info.townNo;

            townDataInfo.buildings_info = new();
            for (int i = 0; i < 5; i++)
            {
                BuildingInfo bi = new BuildingInfo();
                bi.index = info.objectList[i].objectNo;
                bi.level = info.objectList[i].progress;
                bi.broken = info.objectList[i].status != "normal";
                bi.profile = info.objectList[i].destroyerProfile;
                bi.price = info.objectList[i].progressInfo.money;
                townDataInfo.buildings_info.Add(bi);
            }

            townDataInfo.tutorialIndex = info.cutSceanStartNo;
            return townDataInfo;
        }

        public static void SetTown(TownViewData data)
        {
            townInfo = ConverTownData(data.townInfo);
            //new TownDataInfo();
            //townInfo.stage = data.townInfo.townNo;

            //townInfo.buildings_info = new();
            //for (int i = 0; i < 5;i++)
            //{                
            //    BuildingInfo bi = new BuildingInfo();
            //    bi.index = data.townInfo.objectList[i].objectNo;
            //    bi.level = data.townInfo.objectList[i].progress;
            //    bi.broken = data.townInfo.objectList[i].status != "normal";
            //    bi.price = data.townInfo.objectList[i].progressInfo.money;
            //    townInfo.buildings_info.Add(bi);
            //}

            //townInfo.tutorialIndex = data.townInfo.cutSceanStartNo;
        }

        public static void SetLevel(GrothInflationData data)
        {
            userInfo.preStar = data.prevInflationStarLevel;
            userInfo.nextStar = data.nextInflationStarLevel;

            SetGoods(eGoodsType.star, data.starLevel);
        }

        public static void SetContents(GrothInflationData data)
        {
            foreach (var item in data.inflationList)
            {
                if (inflationTypesInfo.ContainsKey(item.type))
                {
                    inflationTypesInfo[item.type] = item.state == InflationState.Lock ? item.unlockLevel : 0;
                }
                else
                {
                    inflationTypesInfo.Add(item.type, item.state == InflationState.Lock ? item.unlockLevel : 0);
                }

                if (item.cutSceanNo > 0)
                {
                    if (!inflationTutorialDic.ContainsKey(item.idx))
                    {
                        inflationTutorialDic.Add(item.idx, item.cutSceanNo);
                    }
                }
            }
        }
    }
}