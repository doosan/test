

using System.Text;
using System;
using UnityEngine.Localization.Settings;
using UnityEngine.Localization.Tables;
using UnityEngine;

namespace SlotKingdoms
{
    public class LocalizationSystem : GameObjectSingleton<LocalizationSystem>
    {
        private StringBuilder timeSb = new StringBuilder();
        private StringTable stringTable = null;

        public void Initialize()
        {
            int language = PlayerPrefs.GetInt("language", 0);
            LocalizationSettings.SelectedLocale = LocalizationSettings.AvailableLocales.Locales[language];
            SetTable();
        }

        public void SetLanguage(int language)
        {
            PlayerPrefs.SetInt("language", language);
            LocalizationSettings.SelectedLocale = LocalizationSettings.AvailableLocales.Locales[language];
            SetTable();
        }

        public void SetTable()
        {
            stringTable = LocalizationSettings.StringDatabase.GetTable("LocalizationString_Common");
        }

        public string ToDHMS(long seconds, int count = 2)
        {
            TimeSpan timeSpan = TimeSpan.FromSeconds(seconds);

            int addCount = 0;
            timeSb.Length = 0;
            if ((int)timeSpan.TotalDays > 0)
            {
                timeSb.Append((int)timeSpan.TotalDays);
                timeSb.Append(stringTable.GetEntry("common-d").GetLocalizedString());
                addCount++;
            }

            if(addCount == count)
            {
                return timeSb.ToString().TrimEnd();
            }

            if ((int)timeSpan.TotalHours > 0)
            {
                if (addCount > 0)
                {
                    timeSb.Append(" ");
                }
                timeSb.Append(timeSpan.Hours);
                timeSb.Append(stringTable.GetEntry("common-h").GetLocalizedString());
                addCount++;
            }

            if (addCount == count)
            {
                return timeSb.ToString().TrimEnd();
            }

            if ((int)timeSpan.TotalMinutes > 0)
            {
                if (addCount > 0)
                {
                    timeSb.Append(" ");
                }
                timeSb.Append(timeSpan.Minutes);
                timeSb.Append(stringTable.GetEntry("common-m").GetLocalizedString());
                addCount++;
            }

            if (addCount == count)
            {
                return timeSb.ToString().TrimEnd();
            }

            if ((int)timeSpan.TotalSeconds > 0)
            {
                if (addCount > 0)
                {
                    timeSb.Append(" ");
                }
                timeSb.Append(timeSpan.Seconds);
                timeSb.Append(stringTable.GetEntry("common-s").GetLocalizedString());
            }

            return timeSb.ToString().TrimEnd();
        }
    }
}
