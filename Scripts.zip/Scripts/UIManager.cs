
using SlotKingdoms.Effect;
using SlotKingdoms.Net;
using SlotKingdoms.Popup;
using SlotKingdoms.UI;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Localization.Settings;

namespace SlotKingdoms
{
    public class UIManager : GameObjectSingleton<UIManager>
    {
        private List<UIGoods> uiGoodsList = new List<UIGoods>();

        private GameUI gameUI = null;

        public GameUI GameUI { get => gameUI; set => gameUI = value; }
        public bool CanClick { get => canClick; set => canClick = value; }

        private bool canClick = true;

        private void OnEnable()
        {
            PopupSystem.Instance.AllCloseEvent.AddListener(RestoreTopUI);
        }

        private void OnDisable()
        {
            PopupSystem.Instance.AllCloseEvent.RemoveListener(RestoreTopUI);
        }



        public void AddUIGoods(UIGoods uiGoods)
        {
            uiGoodsList.Add(uiGoods);
        }

        public void RemoveUIGoods(UIGoods uiGoods)
        {
            uiGoodsList.Remove(uiGoods);
        }

        public TopUI ShowTopUI(TopUIUseInfo topUIUseInfo)
        {
            return ShowTopUI(topUIUseInfo.useMenu, topUIUseInfo.type);
        }

        public TopUI ShowTopUI(bool useMenu, params eGoodsType[] type)
        {
            gameUI.TopUI.SetTopUI(useMenu, type);
            gameUI.TopUI.Show();
            return gameUI.TopUI;
        }

        public void HideTopUI()
        {
            //
            gameUI.TopUI.Hide();
        }

        public void RestoreTopUI()
        {
            // IntroScene 에서 경고 팝업 발생 후 닫힐 때, 에러가 발생해 null 체크 넣었습니다.
            if (gameUI != null)
            {
                gameUI.TopUI.Restore();
                ShowTopUI(gameUI.currentPage.TopUIUseInfo);
            }
        }

        public Vector3 GetUIgoodsPosition(eGoodsType type)
        {
            return uiGoodsList.Where(x => x.Type.Equals(type)).OrderBy(x => x.Priority).FirstOrDefault().Icon.position;
        }

        public void AddGoodsEffect(eGoodsType type,
                                  long value,
                                  Vector2 startPos,
                                  bool textVisible = false,
                                  Vector2 textOffset = default /* new Vector2(0.5f, -0.5f) */,
                                  Action<GoodsEffect> onBegin = null,
                                  Action<GoodsEffect.CompleteType> onComplete = null,
                                  Action onFirstArrived = null,
                                  Action onArrived = null,
                                  int displayCount = 0)
        {
            if(value <= 0 && displayCount == 0)
            {
                Debug.LogWarning("value is 0");
                return;
            }

            UIGoods ug = uiGoodsList.Where(x => x.Type.Equals(type)).OrderBy(x => x.Priority).FirstOrDefault();

            if (ug != null)
            {
                GameInfo.AddWaitGoods(type, value);
                displayCount = displayCount == 0 ? (int)value : displayCount;
                if (type == eGoodsType.money)
                {
                    GoodsEffectSystem.Instance.Coin(displayCount, startPos, ug.Icon.position, textVisible, textOffset, onBegin, onComplete,
                    () =>
                    {
                        GameInfo.AddGoods(type, value, true);
                        onFirstArrived?.Invoke();
                    },
                    () =>
                    {
                        //ug.IconAnimation();
                        onArrived?.Invoke();
                    });
                }
                else if (type == eGoodsType.shield)
                {
                    GoodsEffectSystem.Instance.Shield(0, displayCount, startPos, ug.Icon.position, textVisible, textOffset, onBegin, onComplete,
                    () =>
                    {
                        GameInfo.AddGoods(type, value, true);
                        onFirstArrived?.Invoke();
                    },
                    () =>
                    {
                        //ug.IconAnimation();
                        onArrived?.Invoke();
                    });
                }
                else if(type == eGoodsType.energy)
                {
                    GoodsEffectSystem.Instance.Energy(displayCount, startPos, ug.Icon.position, textVisible, textOffset, onBegin, onComplete,
                    () =>
                    {
                        GameInfo.AddGoods(type, value, true);
                        onFirstArrived?.Invoke();
                    },
                    () =>
                    {
                        //ug.IconAnimation();
                        onArrived?.Invoke();
                    });
                }
                else if (type == eGoodsType.star)
                {
                    GoodsEffectSystem.Instance.Star(displayCount, startPos, ug.Icon.position, textVisible, textOffset, onBegin, onComplete,
                    () =>
                    {
                        GameInfo.AddGoods(type, value, true);
                        onFirstArrived?.Invoke();
                    },
                    () =>
                    {
                        //ug.IconAnimation();
                        onArrived?.Invoke();
                    });
                }
                else if (type == eGoodsType.hammer)
                {
                    GoodsEffectSystem.Instance.Hammer(displayCount, startPos, ug.Icon.position, textVisible, textOffset, onBegin, onComplete,
                    () =>
                    {
                        GameInfo.AddGoods(type, value, true);
                        onFirstArrived?.Invoke();
                    },
                    () =>
                    {
                        //ug.IconAnimation();
                        onArrived?.Invoke();
                    });
                }
            }
            else
            {
                GameInfo.AddGoods(type, value);
                Debug.LogError($"{type} : 해당 재화가 없습니다.");
            }
        }
    }
}