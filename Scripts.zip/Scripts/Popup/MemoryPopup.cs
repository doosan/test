using Newtonsoft.Json;
using SlotKingdoms.Net;
using SlotKingdoms.Popup;
using SlotKingdoms.UI;
using System;
using System.Collections.Generic;
using UnityEngine;

namespace Game.Popup
{
    public class MemoryPopup : PopupBehaviour, IRecyclingItemProvider
    {
        [Header("Item List")]
        [SerializeField] private MemoryPopupItem itemContainerRef;
        [SerializeField] private Transform itemRootRef;
        [SerializeField] private RecyclerListView itemListView;

        [Header("ListView Control")]
        [SerializeField] private Transform listViewControl;
        [SerializeField] private CanvasGroup blockRaycast;

        private int mainIndex = 0;

        public static List<MemoryPopupItemInfo> ItemInfoList = new List<MemoryPopupItemInfo> { };

        private bool isChangePage = false;

        public enum itemStatuType
        {
            Lock,
            Complete,
            Ing
        }

        public enum ItemPopupType
        {
            Show,
            Hide,
            LockDrag,
            UnLockDrag,
            Close
        }

        public sealed class MemoryPopupItemInfo
        {
            public int chapterIndex = 0;
            public int chapterSubIndex = 0;
            public itemStatuType itemStatuType = itemStatuType.Lock;
            public List<int> itemTileStatuList = new List<int> { };
            public List<RewardInfo> goodsList = new List<RewardInfo> { };
        }

        public void CreateItemInfos()
        {
            for (int i = 0; i < 10; i++)
            {
                MemoryPopupItemInfo memoryPopupItemInfo = new MemoryPopupItemInfo();
                float rn = UnityEngine.Random.Range(0f, 1f);
                if (rn > 0.5f)
                {
                    memoryPopupItemInfo.itemStatuType = itemStatuType.Lock;
                }
                else
                {
                    memoryPopupItemInfo.itemStatuType = itemStatuType.Ing;
                    bool isComp = true;
                    for (int j = 0; j < 9; j++)
                    {
                        memoryPopupItemInfo.itemTileStatuList.Add(UnityEngine.Random.Range(0, 6));
                        if (memoryPopupItemInfo.itemTileStatuList[j] > 0)
                        {
                            isComp = false;
                        }
                    }
                    if (isComp)
                    {
                        memoryPopupItemInfo.itemStatuType = itemStatuType.Complete;
                    }
            }

                memoryPopupItemInfo.goodsList.Add(new RewardInfo(eGoodsType.money, 100));
                memoryPopupItemInfo.goodsList.Add(new RewardInfo(eGoodsType.hammer, 3000));

                memoryPopupItemInfo.chapterSubIndex = i + 1;
                memoryPopupItemInfo.chapterIndex = 1;
                ItemInfoList.Add(memoryPopupItemInfo);
            }

        }

        public MemoryPopup Initialize(int k, int j)
        {
            
            mainIndex = k;

            //CreateItemInfos();
            UpdateItemList();
            GoTo(j);

            return this;

        }

        public void UpdateItemList()
        {
            if (itemListView.IsInitialize == false)
            {
                itemListView.Initialize();
            }

            itemListView.ItemProvider = this;
            itemListView.ReactivateAllItems();

            itemListView.onTargetIndexChanged -= OnListIndexChanged;
            itemListView.onTargetIndexChanged += OnListIndexChanged;

            itemListView.onUpdate -= OnListItemUpdate;
            itemListView.onUpdate += OnListItemUpdate;
        }

        public void ClosePopup()
        {
            Close();
        }

        private void OnListItemUpdate()
        {
            
        }

        private void OnListIndexChanged(int index)
        {
            isChangePage = true;
        }

        public RectTransform CreateItem()
        {
            MemoryPopupItem memoryPopupItem = Instantiate(itemContainerRef);
            return memoryPopupItem.GetComponent<RectTransform>();

            //return Instantiate(itemRootRef).GetComponent<RectTransform>();
        }

        private void itemComplete(ItemPopupType type)
        {
            switch(type)
            {
                case ItemPopupType.Show:
                    itemListView.enableDrag = false;
                    listViewControl.gameObject.SetActive(false);
                    //listViewControl.transform.GetComponent<CanvasGroup>().blocksRaycasts = false;
                    break;
                case ItemPopupType.Hide:
                    itemListView.enableDrag = true;
                    listViewControl.gameObject.SetActive(true);
                    //listViewControl.transform.GetComponent<CanvasGroup>().blocksRaycasts = true;
                    break;
                case ItemPopupType.LockDrag:
                    itemListView.enableDrag = false;
                    blockRaycast.blocksRaycasts = true;
                    break;
                case ItemPopupType.UnLockDrag:
                    itemListView.enableDrag = true;
                    blockRaycast.blocksRaycasts = false;
                    break;
                case ItemPopupType.Close:
                    ClosePopup();
                    break;
                default: 
                    break;
            }
        }

        public void GoTo(int index)
        {
            itemListView.GoTo(index, 0f);
        }

        private void OnListMoveOver()
        {
            if (!isChangePage) return;
            isChangePage = false;

            RectTransform rectTransform = null;
            MemoryPopupItem item = null;
            for (int i = 0; i < itemListView.GetCount(); i++)
            {
                rectTransform = itemListView.GetActiveItem(i);
                if (rectTransform == null)
                {
                    continue;
                }
                item = rectTransform.GetComponent<MemoryPopupItem>();
                //item = rectTransform.GetComponentInChildren<MemoryPopupItem>();
                if (item != null)
                if (item.chapterSubIndex == itemListView.TargetIndex + 1)
                {
                    item.OnPage();
                }
            }
        }

        public int GetItemsCount()
        {
            //return MemoryListPopup.memoryInfos[mainIndex].PeiceList.Count;
            return MemoryListPopup.memoryInfos.Find(i => i.MainNo == mainIndex).PeiceList.Count;
            //return ItemInfoList.Count;
        }

        public void OnItemDisable(int index, RectTransform item)
        {
            Debug.Log(String.Format("OnItemDisable index = {0}, item = {1}", index, item));
            //item.GetComponentInChildren<MemoryPopupItem>().transform.SetParent(null, false);
            OnListMoveOver();
        }

        public void OnItemEnable(int index, RectTransform item)
        {
            //MemoryPopupItem memoryPopupItem = Instantiate(itemContainerRef);
            //memoryPopupItem.GetComponent<RectTransform>().SetParent(item);
            //memoryPopupItem.transform.localScale = Vector3.one;
            //memoryPopupItem.transform.localPosition = Vector3.zero;
            //item.GetComponentInChildren<MemoryPopupItem>().Setup(ItemInfoList[index], (ItemPopupType str) => itemComplete(str));

            Debug.Log("OnItemEnable === " + index);

            item.GetComponent<MemoryPopupItem>().Setup(MemoryListPopup.memoryInfos.Find(i => i.MainNo == mainIndex).PeiceList[index], (ItemPopupType str) => itemComplete(str));
            //item.GetComponent<MemoryPopupItem>().Setup(MemoryListPopup.memoryInfos.Find(i => i.MainNo == mainIndex).PeiceList.Find(i => i.SubNo == index), (ItemPopupType str) => itemComplete(str));
        }

        public RecyclerListView.InitializationItemInfo OnItemInitialize(int index, RectTransform item)
        {
            return new RecyclerListView.InitializationItemInfo(item);
        }

        public void RemoveItem(int index)
        {
            Debug.Log(String.Format("RemoveItem index = {0}", index));
        }

        void Awake()
        {
            
        }

        // Start is called before the first frame update
        void Start()
        {
            
        }

        // Update is called once per frame
        void Update()
        {

        }
    }
}
