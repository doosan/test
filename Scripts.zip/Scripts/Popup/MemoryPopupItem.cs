using DG.Tweening;
using SlotKingdoms;
using Spine.Unity;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using SlotKingdoms.UI;
using static Game.Popup.MemoryPopup;
using System.Linq;
using SlotKingdoms.Net;
using SlotKingdoms.Popup;
using Newtonsoft.Json;

namespace Game.Popup
{
    public class MemoryPopupItem : MonoBehaviour
    {
        [Header("Chapter Txt")]
        [SerializeField] public TextMeshProUGUI chapterTxt = null;
        [SerializeField] public GameObject chapterObj = null;

        [Header("Reward Item")]
        [SerializeField] public GameObject rewardCompleteObj = null;
        [SerializeField] public Animator rewardCompleteAnimator = null;
        [SerializeField] public GameObject rewardItemObj = null;
        [SerializeField] public TextMeshProUGUI rewardItemTxt = null;
        [SerializeField] public RewardItemList rewardItemList = null;
        [SerializeField] public GameObjectVisibleToggle itemState = null;

        [Header("Under Coin")]
        [SerializeField] public TextMeshProUGUI hammerTxt = null;

        [Header("Complete Ani")]
        [SerializeField] public Animator completeAnimator = null;
        [SerializeField] public GameObject completeObj = null;
        [SerializeField] public SkeletonGraphic completeSkeleton = null;
        [SerializeField] public Animator completeResultAnimator = null;
        [SerializeField] public Button bgBtn = null;
        [SerializeField] public GameObject checkOutBtn = null;
        [SerializeField] public Button resultBtn = null;

        [Header("Crush Obj")]
        [SerializeField] public Animator crushAnimator = null;
        [SerializeField] public GameObject crushObj = null;
        [SerializeField] public GameObject hammerPoolRoot = null;
        [SerializeField] public Transform hammerRoot = null;

        [Header("Lock Obj")]
        [SerializeField] public SkeletonGraphic lockSkeleton = null;
        [SerializeField] public GameObject lockObj = null;
        [SerializeField] public TextMeshProUGUI openLvText = null;

        [Header("Not Coin Message")]
        [SerializeField] public GameObject nonCoinObj = null;

        [Header("Cursh Shake")]
        [SerializeField] public Transform board = null;
        [SerializeField] private float duration = .395f;
        [SerializeField] private float strengthPosition = .3f;
        [SerializeField] public int vibrato = 20;
        [SerializeField] private float randomness = 90f;

        [Header("Tile setting")]
        [SerializeField] public Animator tileAnimator = null;
        [SerializeField] public Transform tiles = null;
        [SerializeField] public GridLayoutGroup tilesGridLayout = null;
        [SerializeField] public Image itemImage = null;
        [SerializeField] public Image itemResultImage = null;

        [Header("Tile Effect")]
        [SerializeField] public MemoryTileEffect tileEffectPre = null;
        [SerializeField] public GameObject tileEffectPoolRoot = null;
        [SerializeField] public Transform tileEffectRoot = null;
        public GameObjectPool<MemoryTileEffect> tileEffectPool = null;

        [Header("Free Hammer")]
        [SerializeField] public Transform freeHammerObj = null;

        [Header("Ani Time")]
        [SerializeField] private float completeAniTime = 0;
        [SerializeField] private float tileCrushGap = 0;
        [SerializeField] private float tileCrushEndShowResultTime = 0;

        [SerializeField] public List<Button> tileButtonList = new List<Button>();
        public GameObjectPool<Transform> hammerPool = null;

        public readonly string CRUSH_ANI = "crush";
        public readonly string FAIL_ANI = "fail";
        public readonly string SUCCESS_ANI = "success";

        public int chapterIndex = 0;
        public int chapterSubIndex = 0;

        private int tileBoardX = 0;
        private int tileBoardY = 0;

        private bool mainMemoryComplete = false;

        private SubMemory info = null;

        public UnityAction<ItemPopupType> callBackFunc = null;

        private void Awake()
        {
            if(tileEffectPool == null) 
            {
                tileEffectPool = new GameObjectPool<MemoryTileEffect>(
                    root: tileEffectPoolRoot,
                    size: 2,
                    create: () => Instantiate(tileEffectPre)
                );
            }

            if(hammerPool == null)
            {
                hammerPool = new GameObjectPool<Transform>(
                    root: hammerPoolRoot,
                    size: 2,
                    create: () => Instantiate(crushObj).transform
                );
            }
        }

        // Start is called before the first frame update
        void Start()
        {
            
        }

        // Update is called once per frame
        void Update()
        {
        }

        private void OnClick(int i)
        {
            if (!CheckStarCoin())
            {
                //ShowNotCoinMessage();
                StartCoroutine(ShowNotCoinMessage());
                return;
            }

            StartCoroutine(ClickTileCoroutine(i));
        }

        private void InitTileBtns()
        {
            if (tileButtonList.Count == 0)
            {
                tileButtonList = tiles.GetComponentsInChildren<Button>(true).ToList();

                for (int i = 0; i < tileButtonList.Count; i++)
                {
                    int Index = new();
                    Index = i;
                    tileButtonList[i].onClick.AddListener(delegate { OnClick(Index); });
                    tileButtonList[i].gameObject.SetActive(true);
                }
            }

            for (int i = 0; i < tileButtonList.Count; i++)
            {
                tileButtonList[i].gameObject.SetActive(true);
            }
        }

        private void InitTileBoardSize()
        {
            tilesGridLayout.enabled = true;
            tileAnimator.SetTrigger((tileBoardX) + "" + (tileBoardY));
            //tilesGridLayout.enabled = false;
        }

        public void OnPage()
        {

            //if (lockObj.activeSelf)
            //{
            //    lockSkeleton.AnimationState.SetAnimation(0, "swing", false);
            //}
        }

        public void OnCompleteBgClick()
        {
            Debug.Log("OnCompleteBgClick ===========");
            StartCoroutine(CompleteCutSceneCroutine());
        }

        IEnumerator CompleteCutSceneCroutine()
        {
            //var popup = PopupSystem.Instance.OpenPopup<MemorySubCutScenePopup>();
            //popup.Initialize(chapterIndex + 1, chapterSubIndex);
            //yield return popup.WaitForClose();
            yield return PopupSystem.Instance.OpenPopupWaitForClose<MemorySubCutScenePopup>((p) => p.Initialize(chapterIndex+1, chapterSubIndex), CutSceneOpen);
        }

        public void CutSceneOpen(MemorySubCutScenePopup obj = null)
        {
            obj.Open();
        }

        private void Shake()
        {
            board.DOShakePosition(duration, strengthPosition, vibrato, randomness).SetEase(Ease.OutBack);
        }

        private IEnumerator ClickTileCoroutine(int i)
        {
            PopupSystem.Instance.ShowLoading(false);

            TileInfo tileInfo = new TileInfo();
            tileInfo.X = i % tileBoardX;
            tileInfo.Y = Mathf.FloorToInt(i/tileBoardX) ;
            tileInfo.S = 0;

            var req = NetworkSystem.Requester.MemoryRestore(chapterIndex, chapterSubIndex, tileInfo);
            yield return req.WaitForResponse();

            if (req.IsSuccess)
            {
                GameInfo.SubGoods(eGoodsType.hammer, 1);
                //SetBtnIteractable(false);

                //yield return StartCoroutine(ShowTileScaleAni(tileInfo.X, tileInfo.Y));

                List<RewardInfo> goodsList = req.Data.data.tileRewardList;
                List<TileInfo> tileInfos = req.Data.data.restoreTileList;

                yield return StartCoroutine(ShowHammerEffect(tileButtonList[i].gameObject.transform.localPosition, tileInfos));

                RewardInfo goods = null;
                if (goodsList[0].value > 0)
                {
                    goods = goodsList[0];
                }
                StartCoroutine(ShowTileCrushEffect(i, goods));

                //yield return new WaitForSeconds(tileCrushGap);
                if (tileInfos.Count > 1)
                {
                    //yield return new WaitForSeconds(tileCrushGap);

                    for (int j = 1; j < tileInfos.Count; j++)
                    {
                        if (tileInfos[j].X != tileInfo.X || tileInfos[j].Y != tileInfo.Y)
                        {
                            var index = tileInfos[j].X + tileBoardX * tileInfos[j].Y;
                            goods = null;
                            if (goodsList[j].value > 0)
                            {
                                goods = goodsList[j];
                            }
                            StartCoroutine(ShowTileCrushEffect(index, goods));
                        }
                    }
                }

                PopupSystem.Instance.HideLoading();
                callBackFunc.Invoke(ItemPopupType.LockDrag);

                //yield return new WaitForSeconds(1 / 3f);

                //crushObj.SetActive(false);
                //hammerPool.Return(hammerObj.transform);

                var realRewardList = goodsList.Where<RewardInfo>(item => item.value > 0).ToList();

                if (req.Data.data.pieceCompleteRewardList.Count > 0)
                {
                    PopupSystem.Instance.ShowLoading(false);

                    if(req.Data.data.mainMemoryRewardList.Count > 0) mainMemoryComplete = true;

                    yield return new WaitForSeconds(tileCrushEndShowResultTime);

                    if (realRewardList.Count > 0) yield return new WaitForSeconds(2f);

                    yield return StartCoroutine(ShowCompleteResult());
                }
                else
                {
                    //PopupSystem.Instance.HideLoading();
                }

                //SetBtnIteractable(true);

                yield return null;
            }
            else
            {
                //PopupSystem.Instance.HideLoading();
            }
        }

        IEnumerator ShowHammerEffect(Vector3 v3, List<TileInfo> tInfo)
        {
            var hammerObj = hammerPool.Get().gameObject;
            hammerObj.transform.parent = hammerRoot;

            hammerObj.transform.localPosition = v3;


            if (tInfo.Count > 8)
            {
                hammerObj.GetComponent<Animator>().SetTrigger("Hammer3");

                yield return new WaitForSeconds(0.66f);
            }
            else if (tInfo.Count > 3)
            {
                hammerObj.GetComponent<Animator>().SetTrigger("Hammer2");
            }
            else
            {
                hammerObj.GetComponent<Animator>().SetTrigger("Hammer1");
            }
            
            hammerObj.SetActive(true);

            yield return null;

            StartCoroutine(HammerReturnCoroutine(hammerObj));
        }

        IEnumerator HammerReturnCoroutine( GameObject hammerObj)
        {
            yield return new WaitForSeconds(1f);

            hammerPool.Return(hammerObj.transform);

            yield return null;
        }

        IEnumerator ShowTileScaleAni(int indexX, int indexY)
        {
            int count = 0;
            ShowSingleTileScaleAni(indexX, indexY, count);

            for (int i = 0; i <= Mathf.Max(tileBoardX, tileBoardY); i++)
            {
                count++;
                ShowSingleTileScaleAni(indexX, indexY, count);
            }
            yield return new WaitForSeconds(0.3f);
        }

        private void ShowSingleTileScaleAni(int indexX, int indexY, int index)
        {
            for(int i = indexX - index; i <= indexX + index; i++)
            {
                for(int j = indexY - index; j <= indexY + index; j++)
                {
                    if (i < 0 || i >= tileBoardX) continue;
                    if (j < 0 || j >= tileBoardY) continue;

                    if (Mathf.Abs(i - indexX) == Mathf.Abs(index ) || Mathf.Abs(j - indexY) == Mathf.Abs(index))
                    {
                        var tileIndex = i + tileBoardX * j;

                        if (!tileButtonList[tileIndex].gameObject.activeSelf) continue;

                        var sc = 0.6f + 0.4f * index / Mathf.Max(tileBoardX, tileBoardY);
                        tileButtonList[tileIndex].transform.localScale = new Vector2(sc, sc);
                        tileButtonList[tileIndex].transform.DOScale(Vector2.one, 0.3f);
                    } 
                }
            }
        }

        IEnumerator FreeHammerCoroutine()
        {
            freeHammerObj.gameObject.SetActive(true);

            yield return new WaitForSeconds(3.7f);

            freeHammerObj.gameObject.SetActive(false);
        }

        IEnumerator ShowTileCrushEffect(int i, RewardInfo ri = null)
        {
            MemoryTileEffect mte = tileEffectPool.Get();
            mte.transform.parent = tileEffectRoot.transform;
            mte.transform.position = tileButtonList[i].transform.position;
            mte.OnComplete -= TileEffectComplete;
            mte.OnComplete += TileEffectComplete;
            mte.silingIndex = i;

            var index = i + tileBoardX;
            if(index < tileButtonList.Count)
            {
                mte.SetBlockImageSize(tileButtonList[index].gameObject.activeSelf);
                if (Mathf.FloorToInt(i / tileBoardX) == tileBoardY - 1) mte.SetBlockImageSize(true);
            }

            var list = tileEffectRoot.transform.GetComponentsInChildren<MemoryTileEffect>().OrderBy(item => item.silingIndex).ToList();
            for (int j = 0; j < list.Count(); j++)
            {
                list[j].transform.SetSiblingIndex(j);
            }

            mte.ShowReward(tileButtonList[i].gameObject.GetComponent<Image>().sprite.name, ri);

            for (int j = 0; j < info.TileList.Count; j++)
            {
                if (i == j)
                {
                    info.TileList[j].S = 1;
                    break;
                }
            }

            tileButtonList[i].gameObject.SetActive(false);
            
            yield return null;
        }

        public void TileEffectComplete(MemoryTileEffect mte)
        {
            tileEffectPool.Return(mte);

            if(tileEffectRoot.GetComponentsInChildren<MemoryTileEffect>().Length <= 0)
            {
                callBackFunc.Invoke(ItemPopupType.UnLockDrag);
            }
        }

        private IEnumerator ShowCompleteResult()
        {

            SetItemState();

            SubMemory info = MemoryListPopup.memoryInfos.Find(i => i.MainNo == chapterIndex).PeiceList[chapterSubIndex];
            if (info.State == 2)
            {
                rewardCompleteAnimator.SetTrigger("Complete");
                checkOutBtn.gameObject.SetActive(false);
                resultBtn.interactable = false;

                callBackFunc(ItemPopupType.Show);

                completeObj.gameObject.SetActive(true);
                completeResultAnimator.SetTrigger((tileBoardX) + "" + (tileBoardY));
                completeSkeleton.AnimationState.SetAnimation(0, "Bravo", false);

                yield return new WaitForSeconds(completeAniTime);

                SetCompleteState();

                yield return StartCoroutine(CompleteCutSceneCroutine());

                checkOutBtn.gameObject.SetActive(true);
                resultBtn.interactable = true;

                callBackFunc(ItemPopupType.LockDrag);
            }
            
            PopupSystem.Instance.HideLoading();
            

            yield return null;
        }

        public void CloseLastResultPopup()
        {
            PopupSystem.Instance.ShowLoading(false);

            resultBtn.interactable = false;
            //completeAnimator.SetTrigger("Close");

            StartCoroutine(CloseResultCoroutine());
        }

        private IEnumerator CloseResultCoroutine()
        {
            completeObj.SetActive(false);
            callBackFunc(ItemPopupType.Hide);

            yield return new WaitForSeconds(0.5f);

            callBackFunc(ItemPopupType.UnLockDrag);

            yield return PopupSystem.Instance.OpenPopup<CommonRewardPopup>().Open(info.RewardList).WaitForClose();

            PopupSystem.Instance.HideLoading();

            if (mainMemoryComplete)
            {
                callBackFunc.Invoke(ItemPopupType.Close);
            }
        }

        private bool CheckStarCoin()
        {
            //return false;
            if(GameInfo.CanSubGoods(eGoodsType.hammer, 1))
                return true;

            return false;
        }

        private void ShowRewardPopup()
        {

        }

        IEnumerator ShowNotCoinMessage()
        {
            PopupSystem.Instance.ShowLoading(false);
            Shake();

            yield return new WaitForSeconds(0.1f);

            nonCoinObj.gameObject.SetActive(true);

            yield return ShowNotCoinCoroutine();
        }

        IEnumerator ShowNotCoinCoroutine()
        {
            yield return new WaitForSeconds(2f);

            HideNotCoinMessage();
        }

        public void HideNotCoinMessage()
        {
            nonCoinObj.gameObject.SetActive(false);
            //callBackFunc(ItemPopupType.Hide);
            PopupSystem.Instance.HideLoading();
        }

        public void Setup(SubMemory info, UnityAction<ItemPopupType> func)
        {
            InitTileBtns();
            completeObj.gameObject.SetActive(false);
            bgBtn.interactable = false;
            mainMemoryComplete = false;

            this.info = info;
            callBackFunc = func;


            chapterTxt.text = (info.MainNo+1) + "-" + (info.SubNo+1);
            chapterIndex = info.MainNo;
            chapterSubIndex = info.SubNo;

            tileBoardX = info.Width;
            tileBoardY = info.Height;

            itemImage.sprite = AddressablesLoader.Instance.LoadAsset<Sprite>("MemoryPopup/Memory_00" + (chapterIndex + 1) + "/Memory_00" + (chapterIndex + 1) + "_" + (chapterSubIndex + 1) + ".png");
            itemResultImage.sprite = itemImage.sprite;

            InitTileBoardSize();

            StartCoroutine(SetBlock(info));
        }

        IEnumerator SetBlock(SubMemory info)
        {
            yield return new WaitForSeconds(0.05f);
            tilesGridLayout.enabled = false;

            for (int i = 0; i < info.TileList.Count; i++)
            {
                var index = info.TileList[i].X + tileBoardX * info.TileList[i].Y;
                if (info.State == 0)
                {
                    tileButtonList[index].gameObject.SetActive(true);
                }
                else if(info.State == 2)
                {
                    tileButtonList[index].gameObject.SetActive(false);
                }
                else
                {
                    tileButtonList[index].gameObject.SetActive(info.TileList[i].S == 0 ? true : false);
                }
            }

            rewardItemList.SetRewardItemList(info.RewardList);

            SetItemState();
            SetCompleteState();
            //SetBtnIteractable(true);
        }

        public void SetItemState()
        {
            if (info.State == 0)
            {
                lockObj.SetActive(true);
                openLvText.text = info.UnlockLevel + "";
                itemState.TurnOnByNameInMultiple("RewardItemList");
            }
            else
            {
                var isComp = true;
                for(int i = 0;i < info.TileList.Count;i++)
                {
                    if(info.TileList[i].S == 0)
                        isComp = false;
                }

                if (isComp)
                    info.State = 2;

                lockObj.SetActive(false);
                if (info.State == 1)
                {
                    itemState.TurnOnByNameInMultiple("RewardItemList");
                }
                else if (info.State == 2)
                {
                    itemState.TurnOnByNameInMultiple("Text (TMP)_Completed");
                }
            }    
            
        }

        private void SetCompleteState()
        {
            if (info.State != 2) return;

            tileAnimator.SetTrigger((7) + "" + (9));
            for (int i = 0; i<tileButtonList.Count;i++)
            {
                tileButtonList[i].gameObject.SetActive(false);
            }

            bgBtn.interactable = true;
        }

        private void SetBtnIteractable(bool type)
        {
            for (int i = 0; i < tileButtonList.Count; i++)
            {
                tileButtonList[i].interactable = false;
            }

            for (int i = 0; i < info.TileList.Count; i++)
            {
                var index = info.TileList[i].X + tileBoardX * info.TileList[i].Y;
                if (info.State == 0)
                {
                    tileButtonList[index].gameObject.SetActive(true);
                }
                else
                {
                    tileButtonList[index].gameObject.SetActive(info.TileList[i].S == 0 ? true : false);
                }
                tileButtonList[index].interactable =
                    info.State == 0 ? false : (info.TileList[i].S == 0 ? type : false);
            }
        }

        private void OnDisable()
        {
            var effectList = tileEffectRoot.GetComponentsInChildren<MemoryTileEffect>();
            foreach(var effect in effectList)
            {
                tileEffectPool.Return(effect);
            }

            var hammerEffectList = hammerRoot.GetComponentsInChildren<Transform>();
            foreach(var hammer in hammerEffectList)
            {
                if(hammer.name != hammerRoot.name)
                {
                    hammerPool.Return(hammer);
                }
            }
        }
    }
}
