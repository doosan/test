using SlotKingdoms.Popup;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Localization.Components;

public class MemoryCutScenePopup : PopupBehaviour
{

    [SerializeField] private VideoControlTool controlTool = null;

    [SerializeField] private LocalizeStringEvent localizeStringEvent = null;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    public void Init(int clipIndex)
    {
        localizeStringEvent.StringReference.TableEntryReference = "memory_title_0" + (clipIndex + 1);

        controlTool.PlayVideoByIndex(clipIndex, ClosePopupDelay);
    }

    public void ClosePopup()
    {
        controlTool.ResetPlayer();
        Close();
    }

    public void ClosePopupDelay()
    {
        StartCoroutine(ClosePopupDelayCoroutine());
    }

    IEnumerator ClosePopupDelayCoroutine()
    {
        yield return new WaitForSeconds(1);

        ClosePopup();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
