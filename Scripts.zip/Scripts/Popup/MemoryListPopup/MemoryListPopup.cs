using Newtonsoft.Json;
using SlotKingdoms;
using SlotKingdoms.Net;
using SlotKingdoms.Popup;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.Localization.Settings;
using UnityEngine.UI;
using static Game.Popup.MemoryPopup;

namespace Game.Popup
{
    public class MemoryListPopup : PopupBehaviour
    {
        [Header("Item Ref")]
        [SerializeField] private MemoryListItem itemRef = null;
        [SerializeField] private GameObject chainRef = null;
        [SerializeField] private Transform contentRoot;
        [SerializeField] private GameObject itemPoolRoot;

        [SerializeField] private ScrollRect scrollRect = null;
        [SerializeField] private GameObject loadingIndicator = null;

        [Header("Memory Hammer")]
        [SerializeField] private TextMeshProUGUI hammerTxt;

        public static Dictionary<int, List<MemoryPopupItemInfo>> ItemInfoData = new Dictionary<int, List<MemoryPopupItemInfo>>();

        public static List<MainMemoryInfo> memoryInfos = new List<MainMemoryInfo>();

        private GameObjectPool<MemoryListItem> itemPool;
        private GameObjectPool<Transform> chainPool;

        private List<MemoryListItem> itemObjList = new List<MemoryListItem>();
        private List<Transform> chainObjList = new List<Transform>();

        public static float contentY = 0;

        // Start is called before the first frame update
        void Start()
        {
            //Init();
        }

        public void CreateItemInfo()
        {
            for (int z = 0; z < 5; z++) {
                List<MemoryPopupItemInfo> ItemInfoList = new List<MemoryPopupItemInfo> { };
                for (int i = 0; i < 10; i++)
                {
                    MemoryPopupItemInfo memoryPopupItemInfo = new MemoryPopupItemInfo();
                    float rn = UnityEngine.Random.Range(0f, 1f);
                    if (rn > 0.5f)
                    {
                        memoryPopupItemInfo.itemStatuType = itemStatuType.Lock;
                    }
                    else
                    {
                        memoryPopupItemInfo.itemStatuType = itemStatuType.Ing;
                        bool isComp = true;
                        for (int j = 0; j < 9; j++)
                        {
                            memoryPopupItemInfo.itemTileStatuList.Add(UnityEngine.Random.Range(0, 6));
                            if (memoryPopupItemInfo.itemTileStatuList[j] > 0)
                            {
                                isComp = false;
                            }
                        }
                        if (isComp)
                        {
                            memoryPopupItemInfo.itemStatuType = itemStatuType.Complete;
                        }
                    }

                    memoryPopupItemInfo.goodsList.Add(new RewardInfo(eGoodsType.money, 100));
                    memoryPopupItemInfo.goodsList.Add(new RewardInfo(eGoodsType.hammer, 3000));

                    memoryPopupItemInfo.chapterSubIndex = i + 1;
                    memoryPopupItemInfo.chapterIndex = z+1;
                    ItemInfoList.Add(memoryPopupItemInfo);
                }
                ItemInfoData.Add(z, ItemInfoList);
            }
        }

        public void NewCreateInfo()
        {
            for(int i = 0; i < 5; i++)
            {
                MainMemoryInfo mainMemoryInfo = new MainMemoryInfo();
                mainMemoryInfo.PeiceList = new List<SubMemory> { };
                for (int j = 0;j < 8; j++) 
                {
                    mainMemoryInfo.MainNo = i;
                    mainMemoryInfo.OpenLevel = 100;

                    SubMemory memoryPiece = new SubMemory();
                    memoryPiece.MainNo = i;
                    memoryPiece.SubNo = j;
                    memoryPiece.Width = UnityEngine.Random.Range(3, 7);
                    memoryPiece.Height = UnityEngine.Random.Range(5, 9);
                    bool isLock = false;
                    bool isComp = false;
                    if(UnityEngine.Random.Range(0f, 1f) > 0.5f)
                    {
                        memoryPiece.UnlockLevel = 100;
                        isLock = true;
                    }
                    if (!isLock)
                    {
                        if (UnityEngine.Random.Range(0f, 1f) > 0.5f)
                        {
                            memoryPiece.State = 2;
                            isComp = true;
                        }
                        else
                        {
                            memoryPiece.State = 1;
                        }
                    }
                    else
                    {
                        memoryPiece.State = 1;
                    }

                    List<TileInfo> tileList = new List<TileInfo>();
                    for (int hIndex = 0; hIndex < memoryPiece.Height; hIndex++)
                    {
                        for (int wIndex = 0; wIndex < memoryPiece.Width; wIndex++)
                        {
                            tileList.Add(GetTileInfo(wIndex, hIndex, isComp, isLock));
                        }
                    }
                    memoryPiece.TileList = tileList;

                    memoryPiece.RewardList = new List<RewardInfo> { };
                    var reward = new RewardInfo();
                    reward.type = eGoodsType.energy;
                    reward.value = 100;
                    memoryPiece.RewardList.Add(reward);
                    reward = new RewardInfo();
                    reward.type = eGoodsType.money;
                    reward.value = 1000;
                    memoryPiece.RewardList.Add(reward);

                    
                    mainMemoryInfo.PeiceList.Add(memoryPiece);
                }
                mainMemoryInfo.mainMemoryRewardList = new List<RewardInfo> { };
                var reward1 = new RewardInfo();
                reward1.type = eGoodsType.energy;
                reward1.value = 100;
                mainMemoryInfo.mainMemoryRewardList.Add(reward1);
                reward1 = new RewardInfo();
                reward1.type = eGoodsType.money;
                reward1.value = 1000;
                mainMemoryInfo.mainMemoryRewardList.Add(reward1);
                memoryInfos.Add(mainMemoryInfo);
            }
        }

        public TileInfo GetTileInfo(int xIndex, int yIndex, bool isComp, bool isLock)
        {
            TileInfo tileInfo = new TileInfo();
            tileInfo.X = xIndex;
            tileInfo.Y = yIndex;
            if(isLock)
            {
                tileInfo.S = 0;
            }
            else
            {
                if(isComp )
                {
                    tileInfo.S = 1;
                }
                else
                {
                    tileInfo.S = UnityEngine.Random.Range(0f, 1f) > 0.5f ? 1 : 0;
                }
            }
            return tileInfo;
        }

        public override IEnumerator Load()
        {
            loadingIndicator.SetActive(true);

            Init();

            //Debug.Log(LocalizationSettings.SelectedLocale.ToString().Contains("English"));

            yield return base.Load();

            yield return StartCoroutine(GetMemoryListCoroutine());

            loadingIndicator.SetActive(false);
        }

        public void Init()
        {
            //if(memoryInfos.Count == 0 )
            //    NewCreateInfo();

            scrollRect.content.transform.localPosition = new Vector2(scrollRect.content.transform.localPosition.x, 0);
            //scrollRect.verticalNormalizedPosition

            if (itemPool == null)
            {
                itemPool = new GameObjectPool<MemoryListItem>(
                    root: itemPoolRoot,
                    size: 2,
                    create: () => Instantiate(itemRef)
                );

                chainPool = new GameObjectPool<Transform>(
                    root: itemPoolRoot,
                    size: 2,
                    create: () => Instantiate(chainRef.transform)
                ) ;

                if(contentRoot.childCount > 0)
                {
                    List<MemoryListItem> itemList = contentRoot.GetComponentsInChildren<MemoryListItem>(true).ToList();
                    for(int i = 0; i < itemList.Count; i++)
                    {
                        itemPool.Return(itemList[i]);
                    }
                    itemList.Clear(); 

                    List<Transform> chainList = contentRoot.GetComponentsInChildren<Transform>().ToList();
                    for (int i = 0; i < chainList.Count; i++)
                    {
                        if(chainList[i].gameObject.name == "Chain")
                            chainPool.Return(chainList[i]);
                    }
                    chainList.Clear();
                }
            }
            
            //StartCoroutine(GetMemoryListCoroutine());
        }

        IEnumerator GetMemoryListCoroutine()
        {
            var req = NetworkSystem.Requester.MemoryList();
            yield return req.WaitForResponse();

            if(req.IsSuccess )
            {
                memoryInfos.Clear();
                memoryInfos = req.Data.data.MemoryList.Where<MainMemoryInfo>(i => i.State > 0).ToList();
                foreach(MainMemoryInfo info in memoryInfos)
                {
                    info.PeiceList = info.PeiceList.OrderBy(i => i.SubNo).ToList();
                }
            }
            else
            {

            }

            

            SetUp();
        }

        public void SetUp() 
        {
            //hammerTxt.text = GameInfo.GetGoodsValue(eGoodsType.hammer).ToString();
            for (int i = 0; i< memoryInfos.Count; i++)
            {

                MemoryListItem item = itemPool.Get();
                item.transform.SetParent(contentRoot);
                itemObjList.Add(item); 

                Transform chain = chainPool.Get();
                chain.SetParent(contentRoot);
                chainObjList.Add(chain);
                item.chainTransform = chain;

                if(i == memoryInfos.Count - 1)
                {
                    chain.gameObject.SetActive(false);
                }

                item.SetUp(memoryInfos[i].MainNo, OnClickSubItem);
            }

            contentY = scrollRect.content.anchoredPosition.y;
        }

        public void OnClickSubItem(int memoryIndex ,int subIndex)
        {
            Debug.Log("OnClickSubItem === " + memoryIndex + " ==== " + subIndex);
            StartCoroutine(OpenMemoryItemPopup(memoryIndex, subIndex));
        }

        private IEnumerator OpenMemoryItemPopup(int mIndex, int sIndex)
        {
            MemoryPopup mp = PopupSystem.Instance.OpenPopup<MemoryPopup>().Initialize(mIndex, sIndex);
            //PopupSystem.Instance.SetBackgroundPanelAlpha(mp.name, 0.01f);

            yield return mp.WaitForClose();

            OnMemoryComplete(mIndex);

            yield return null;

        }

        private void OnMemoryComplete(int mIndex)
        {
            var item = itemObjList.Find(x => x.memoryIndex == mIndex);
            item.ResetInfo();

            //item.memoryComplete = true;
            if (item.memoryComplete)
            {
                item.OnMemoryComplete();
            }
        }

        private void OnDisable()
        {
            for (int i = 0; i < itemObjList.Count; i++)
            {
                itemObjList[i].Clear();
                itemPool.Return(itemObjList[i]);
            }

            for (int i = 0; i < chainObjList.Count; i++)
            {
                chainPool.Return(chainObjList[i]);
            }

            itemObjList.Clear();
            chainObjList.Clear();
        }

        // Update is called once per frame
        void Update()
        {

        }
    }
}
