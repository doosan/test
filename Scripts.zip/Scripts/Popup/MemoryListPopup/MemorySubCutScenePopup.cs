using DG.Tweening;
using Newtonsoft.Json;
using SlotKingdoms;
using SlotKingdoms.Popup;
using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Localization.Components;
using UnityEngine.Localization.Settings;
using UnityEngine.UI;
using static DialogData;

namespace Game.Popup
{
    public class MemorySubCutScenePopup : PopupBehaviour
    {
        [Header("Scroll View")]
        [SerializeField] private ScrollRect scroll = null;
        [SerializeField] private Button bgBtn = null;

        [Header("Text Obj")]
        [SerializeField] private TextMeshProUGUI txtPref = null;
        [SerializeField] private TextMeshProUGUI noneTxt = null;
        [SerializeField] private GameObject prefPoolRoot = null;
        [SerializeField] private GameObject contentRoot = null;
        [SerializeField] private GameObject guidObj = null;
        [SerializeField] private float timeTurn = 0f;

        private List<TextMeshProUGUI> txtItemList = new List<TextMeshProUGUI>();
        private GameObjectPool<TextMeshProUGUI> itemPool = null;

        private int mainNo = 0;
        private int subNo = 0;
        private int currIndex = 0;

        private Coroutine currCoroutine = null;
        private float textScrollTime = 1f;
        private float textScrollTime2 = 1f;

        private int index = 0;
        private int subIndex = 0;
        private TutorialDialog tutorialDialog = null;

        private DialogData data = null;
        public int Index { get => index; set => index = value; }

        public int SubIndex { get => subIndex; set => subIndex = value; }

        private List<List<int>> cutsceneNumList = new List<List<int>>() 
            { 
                new List<int> { 20, 50, 30, 10, 50, 60, 8, 5}, 
                new List<int> { 20, 10, 30, 10, 50, 60, 8, 5 } 
            };

        private void Awake()
        {
            
        }

        public override IEnumerator Load()
        {
            yield return AddressablesLoader.Instance.LoadAssetCoroutine<TutorialDialog>(
                name: $"DialogData/MemoryCutScene_{Index:D3}.asset",
                onComplete: (result) =>
                {
                    tutorialDialog = result;
                }
            );


            yield return base.Load();
        }

        IEnumerator ShowGame()
        {
            yield return StartCoroutine(Load());
            Open();
        }

        public void Initialize(int index, int subIndex)
        {
            this.index = index;
            this.subIndex = subIndex;

            //StartCoroutine(ShowGame());
        }

        public void Open()
        {
            if (tutorialDialog != null)
            {
                //if(Index <= 1)
                    bgBtn.transform.GetComponent<Image>().sprite 
                        = AddressablesLoader.Instance.LoadAsset<Sprite>($"MemoryPopup/Memory_{Index:D3}/Memory_{Index:D3}_{this.subIndex + 1}.png");

                textScrollTime = timeTurn;
                textScrollTime2 = 1f;
                PopupSystem.Instance.SetBackgroundPanelAlpha("MemorySubCutScenePopup", 0.3f);
                //currCoroutine = StartCoroutine(PlayDialog());
                ShowCutScene(Index, this.subIndex);
            }
            else
            {
                ClosePopup();
            }
        }

        private IEnumerator PlayDialog()
        {
            bgBtn.interactable = true;
            scroll.verticalNormalizedPosition = 1f;

            //yield return new WaitForSeconds(0.5f);

            noneTxt.text = string.Empty;
            data = tutorialDialog.data[this.subIndex];
            string str = data.localizedString.GetLocalizedString();

            noneTxt.alignment = data.alignType == DialogData.Align.Center ? TextAlignmentOptions.Center : TextAlignmentOptions.TopLeft;
            noneTxt.GetComponent<RectTransform>().anchoredPosition = new Vector2(0, data.alignType == DialogData.Align.Center ? 0 : -19);
            if (data.typingType == Typing.Typing)
            {
                yield return RevealText(str, data);
            }
            else
            {
                noneTxt.text = str;
            }
        }

        int visibleCharacterCount = 0;

        IEnumerator RevealText(string str, DialogData data)
        {
            var strList = str.Split("\n");

            textScrollTime2 = data.typingTime;

            for (int i=0; i<strList.Length; i++)
            {
                scroll.DOVerticalNormalizedPos(0, 0.5f);
                if (data.state == DialogData.State.Talk)
                {
                    var visibleChaCount = 0;

                    while (visibleChaCount < strList[i].Length)
                    {
                        char currentChar = strList[i][visibleChaCount];
                        if (currentChar == '<')
                        {
                            visibleChaCount++;

                            while (visibleChaCount < strList[i].Length && strList[i][visibleChaCount] != '>')
                            {
                                visibleChaCount++;
                            }

                            visibleChaCount++;
                        }
                        else
                        {
                            if (visibleChaCount < strList[i].Length && strList[i][visibleChaCount] != '<')
                            {
                                noneTxt.text += strList[i][visibleChaCount];
                                yield return new WaitForSeconds(textScrollTime2);

                                visibleChaCount++;
                            }
                        }
                    }
                    noneTxt.text += "\n";
                }
                else
                {
                    noneTxt.text += strList[i] + "\n";
                }

                if (textScrollTime != 0)
                    yield return new WaitForSeconds(textScrollTime);

                scroll.DOVerticalNormalizedPos(0, 0.5f);
            }

            scroll.DOVerticalNormalizedPos(0, 0.5f);

            guidObj.SetActive(true);
        }

        public void ShowCutScene(int _mainNo, int _subNo)
        {
            mainNo = _mainNo;
            subNo = _subNo;
            textScrollTime = timeTurn;
            currCoroutine = StartCoroutine(ShowCutSceneCoroutine());
        }

        IEnumerator ShowCutSceneCoroutine()
        {
            data = tutorialDialog.data[this.subIndex];
            string str = data.localizedString.GetLocalizedString();
            var strList = str.Split("\n");

            bgBtn.interactable = true;
            currIndex = 0;
            guidObj.SetActive(false);

            //int total = cutsceneNumList[mainNo][subNo];
            for (int i = 0; i < strList.Length; i++)
            {

                CreateTxt(strList[i]);

                yield return new WaitForSeconds(textScrollTime);
            }
            guidObj.SetActive(true);

            yield return null;
        }

        private void ImmediateShow()
        {
            bgBtn.interactable = false;

            textScrollTime = 0.01f;
            textScrollTime2 = 0.001f;

            bgBtn.interactable = true;
        }

        public void OnClickBg()
        {
            if(guidObj.activeSelf)
            {
                ClosePopup();
                return;
            }

            ImmediateShow();
        }

        private void ClosePopup()
        {
            guidObj.SetActive(false);
            bgBtn.interactable = false;
            StopCoroutine(currCoroutine);
            noneTxt.text = string.Empty;
            Close();
        }

        private void CreateTxt(string str)
        {
            //currIndex++;

            var txt = itemPool.Get();
            txt.transform.parent = contentRoot.transform;
            txtItemList.Add(txt);

            if(str.Length == 0)
            {
                txt.text = "\n";
            }
            else
            {
                txt.text = str;
            }
            
            noneTxt.transform.SetSiblingIndex(txtItemList.Count+1);

            if (str.Length > 0)
                scroll.DOVerticalNormalizedPos(0, 0.5f);
        }

        private void OnDisable()
        {
            foreach(var item in txtItemList)
            {
                itemPool.Return(item);
            }
            txtItemList.Clear();
        }

        // Start is called before the first frame update
        void Start()
        {
            if (itemPool == null)
            {
                itemPool = new GameObjectPool<TextMeshProUGUI>(
                    root: prefPoolRoot,
                    size: 2,
                    create: () => Instantiate(txtPref)
                );
                itemPool.Return(txtPref);
            }
            //ShowCutScene(0, 0);
            //StartCoroutine(ShowGame());
        }

        // Update is called once per frame
        void Update()
        {

        }
    }
}
