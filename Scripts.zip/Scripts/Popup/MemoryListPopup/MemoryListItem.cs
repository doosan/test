using DG.Tweening;
using Newtonsoft.Json;
using SlotKingdoms;
using SlotKingdoms.Net;
using SlotKingdoms.Popup;
using SlotKingdoms.UI;
using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Localization.Components;
using UnityEngine.UI;
using static Game.Popup.MemoryPopup;

namespace Game.Popup
{
    public class MemoryListItem : MonoBehaviour
    {

        [Header("Memory Item Info")]
        [SerializeField] private RewardItemList ItemList;
        [SerializeField] private TextMeshProUGUI successTotalTxt;
        [SerializeField] private TextMeshProUGUI successProgressTxt;

        [Header("Item Obj")]
        [SerializeField] private Image itemImage = null;
        [SerializeField] private Transform subMemoryObj = null;
        [SerializeField] private Button mainItemBtn = null;

        [Header("Complete Obj")]
        [SerializeField] private GameObject itemCheck = null;
        [SerializeField] private Button videoBtn = null;
        [SerializeField] private GameObject completeObj = null;
        [SerializeField] private GameObject mainCompObj = null;
        [SerializeField] private Image compImage = null;
        [SerializeField] private LocalizeStringEvent compLocalStringEvent = null;

        [Header("Localize Obj")]
        [SerializeField] private LocalizeStringEvent localizeStringEvent = null;
        [SerializeField] private LocalizationValueInt localizationValueInt = null;  

        [SerializeField] private List<MemoryListSubItem> memoryListSubItemList = new List<MemoryListSubItem>();

        private LayoutElement layoutElement;
        private float initialPreferredHeigh;
        private List<MemoryPopupItemInfo> ItemInfoList = null;

        public MainMemoryInfo memoryInfo { get; set; } = null;
        
        public bool memoryComplete { get; set; } = false;

        public int memoryIndex { get ; set; } = 0;

        public Transform chainTransform { get; set; }

        // Start is called before the first frame update
        void Start()
        {
            
        }

        public void SetUp(int index, Action<int, int> onClick)
        {
            if (layoutElement == null)
            {
                layoutElement = GetComponent<LayoutElement>();
                initialPreferredHeigh = layoutElement.preferredHeight;
                Debug.Log(initialPreferredHeigh);
            }

            memoryIndex = index;

            localizeStringEvent.StringReference.TableEntryReference = "memory_title_0"+(memoryIndex+1);

            memoryInfo = MemoryListPopup.memoryInfos.Find(x => x.MainNo == memoryIndex);

            if(MemoryListPopup.memoryInfos.Count > 0)
                if (MemoryListPopup.memoryInfos[0].MainNo == memoryIndex)
                {
                    subMemoryObj.gameObject.SetActive(true);
                    subMemoryObj.localPosition = new Vector2(subMemoryObj.localPosition.x, .395f);
                    layoutElement.preferredHeight = initialPreferredHeigh * 2.303f; 
                }

            ItemList.SetRewardItemList(memoryInfo.mainMemoryRewardList);

            for (int i = 0; i < memoryInfo.PeiceList.Count; i++)
            {
                memoryListSubItemList[i].SetUp(memoryInfo.PeiceList[i].MainNo, memoryInfo.PeiceList[i].SubNo, onClick);
            }
            
            //if(index == 0)
            itemImage.sprite = AddressablesLoader.Instance.LoadAsset<Sprite>("MemoryPopup/Memory_00"+(memoryIndex+1)+"/Memory_00"+(memoryIndex+1)+"_titleimg.png");

            SetItemInfos();
            SetVideoBtn();
        }
        private void SetItemInfos()
        {
            int compCount = 0;
            for (int i = 0;i < memoryInfo.PeiceList.Count; i++)
            {
                compCount = memoryInfo.PeiceList[i].State == 2 ? compCount +1 : compCount;
            }

            memoryComplete = compCount == memoryInfo.PeiceList.Count ? true : false;
            successProgressTxt.text = compCount +"";

        }

        public void ResetInfo()
        {
            for (int i = 0; i < memoryInfo.PeiceList.Count; i++)
            {
                memoryListSubItemList[i].ResetItem();
            }
            SetItemInfos();
        }

        private void SetVideoBtn()
        {
            if (memoryComplete)
            {
                foreach (var reward in ItemList.RewardList)
                {
                    reward.gameObject.SetActive(false);
                }

                itemCheck.SetActive(true);

                videoBtn.gameObject.SetActive(true);
                videoBtn.interactable = true;
            }
            else
            {
                foreach (var reward in ItemList.RewardList)
                {
                    reward.gameObject.SetActive(true);
                }

                itemCheck.SetActive(false);

                videoBtn.gameObject.SetActive(false);
                videoBtn.interactable = false;
            }
        }

        public void MoveToCenter()
        {
            var scroll = GetComponentInParent<ScrollRect>();

            var sHeight = scroll.transform.GetComponent<RectTransform>().rect.height;
            var cHeight = scroll.content.GetComponent<RectTransform>().rect.height;
            var size = MemoryListPopup.contentY + (transform.localPosition.y - 330);

            //scroll.DOVerticalNormalizedPos(1 - Mathf.Clamp01(-size / (cHeight - sHeight)), 0.2f);
            scroll.verticalNormalizedPosition = 1 - Mathf.Clamp01(-size / (cHeight - sHeight));
        }

        public void MainMemoryBtnClick()
        {
            if(!subMemoryObj.gameObject.activeSelf) 
            {
                subMemoryObj.gameObject.SetActive(true);
                subMemoryObj.DOLocalMoveY(0f, .395f);
                layoutElement
                    .DOPreferredSize(new Vector2(layoutElement.preferredWidth, initialPreferredHeigh * 2.303f), .395f)
                    .OnUpdate(MoveToCenter);
            }
            else
            {
                subMemoryObj.DOLocalMoveY(470f, .395f);
                layoutElement
                    .DOPreferredSize(new Vector2(layoutElement.preferredWidth, initialPreferredHeigh), .35f)
                    .OnComplete(() => { subMemoryObj.gameObject.SetActive(false); }) ;
                
            }
        }

        public void OnMemoryComplete()
        {
            if (videoBtn.gameObject.activeSelf) return;

            PopupSystem.Instance.ShowLoading(false);

            mainItemBtn.interactable = false;
            subMemoryObj.DOLocalMoveY(470f, .395f);
            layoutElement.DOPreferredSize(new Vector2(layoutElement.preferredWidth, initialPreferredHeigh), .35f).OnComplete(() => { StartCoroutine(MemoryAniCompleteCoroutine()); });
        }

         IEnumerator MemoryAniCompleteCoroutine()
        {
            yield return new WaitForSeconds(0.5f);

            subMemoryObj.gameObject.SetActive(false);

            mainCompObj.transform.position = itemImage.transform.position;
            compImage.sprite = itemImage.sprite;

            compLocalStringEvent.StringReference.TableEntryReference = "memory_title_0" + (memoryIndex + 1);

            completeObj.SetActive(true);    
            yield return new WaitForSeconds(2.5f);
            completeObj.SetActive(false);

            PopupSystem.Instance.HideLoading();

            yield return StartCoroutine(PlayMemoryCutSceneCoroutine());

            yield return PopupSystem.Instance.OpenPopup<CommonRewardPopup>().Open(memoryInfo.mainMemoryRewardList).WaitForClose();

            SetVideoBtn();

            mainItemBtn.interactable = true;
        }

        public void PlayMemoryCutScene()
        {
            StartCoroutine(PlayMemoryCutSceneCoroutine());
        }

        IEnumerator PlayMemoryCutSceneCoroutine()
        {
            var popup = PopupSystem.Instance.OpenPopup<MemoryCutScenePopup>();
            popup.Init(memoryIndex);
            yield return popup.WaitForClose();
        }

        public void ScaleDown(Action<MemoryListItem> onScaleDownComplete)
        {
            chainTransform.DOScale(new Vector2(0, 0), 0.3f);
            layoutElement.DOPreferredSize(new Vector2(layoutElement.preferredWidth, 0f), .3f);
            transform.DOScale(new Vector2(0, 0), 0.3f).OnComplete(() => {   Clear(); onScaleDownComplete(this); });
            
        }

        public void Clear()
        {
            subMemoryObj.localPosition = new Vector2(subMemoryObj.localPosition.x, 470f);
            subMemoryObj.gameObject.SetActive(false) ;
            layoutElement.preferredHeight = initialPreferredHeigh;
            gameObject.SetActive(false);
            chainTransform.gameObject.SetActive(false);
        }

        // Update is called once per frame
        void Update()
        {

        }
    }
}
