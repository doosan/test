using SlotKingdoms.Net;
using SlotKingdoms.UI;
using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class MemoryTileEffect : MonoBehaviour
{
    [SerializeField] public RewardItem rewardItem;
    [SerializeField] public Transform freeTransform;
    [SerializeField] public TextMeshProUGUI freeTxt;
    [SerializeField] public Animator animator;
    [SerializeField] public Image blockImage;
    [SerializeField] public GameObject borderObj;
    [SerializeField] public GameObject uiParticleObj;

    [SerializeField] public float uiParticleShowTime = 0;
    [SerializeField] public float effectShowTime = 0;

    public int silingIndex = 0;

    public Action<MemoryTileEffect> OnComplete = null;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    public void SetRewardItem(RewardInfo gi)
    {
        rewardItem.SetRewardItem(gi);
        rewardItem.gameObject.SetActive(true);
        freeTransform.gameObject.SetActive(false);
    }

    public void ShowReward(string tr, RewardInfo gi = null)
    {
        if (gi == null)
        {
            borderObj.SetActive(false);
            rewardItem.gameObject.SetActive(false);
            freeTransform.gameObject.SetActive(false);
            StartCoroutine(ShowAniCoroutine(tr));
            return;
        }

        borderObj.SetActive(true);
        if (gi.type == eGoodsType.hammer)
        {
            rewardItem.gameObject.SetActive(false);
            freeTransform.gameObject.SetActive(true);
            //freeTxt.text = gi.value.ToString();
        }
        else
        {
            SetRewardItem(gi);
        }

        StartCoroutine(ShowAniCoroutine(tr, gi));
    }

    IEnumerator ShowAniCoroutine(string tr, RewardInfo gi = null)
    {
        animator.SetTrigger(tr);

        if(gi != null)
        {
            yield return new WaitForSeconds(uiParticleShowTime);
            uiParticleObj.SetActive(true);
            yield return new WaitForSeconds(effectShowTime - uiParticleShowTime);
        }
        else
        {
            yield return new WaitForSeconds(effectShowTime);
        }

        uiParticleObj.SetActive(false);

        if (gi != null)
        {
            if (!rewardItem.gameObject.activeSelf)
            {
                rewardItem.SetRewardItem(gi);
            }

            rewardItem.gameObject.SetActive(false);
            freeTransform.gameObject.SetActive(false);

            //rewardItem.PlayEffect(() => { OnComplete.Invoke(this); });
            rewardItem.PlayEffect(() => { });
        }
        //else
        //{
            OnComplete.Invoke(this);
        //}

    }

    public void SetBlockImageSize(bool type)
    {
        blockImage.fillAmount = 1f;
        if (type)
        {
            blockImage.fillAmount = 0.719f;
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
