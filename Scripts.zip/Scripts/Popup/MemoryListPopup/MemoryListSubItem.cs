using SlotKingdoms;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System;
using UnityEngine.UI;
using static Game.Popup.MemoryPopup;
using SlotKingdoms.Net;

namespace Game.Popup
{
    public class MemoryListSubItem : MonoBehaviour
    {
        public enum MemoryType
        {
            Ing,
            Complet,
            Lock
        }

        [SerializeField] private Image itemImage = null;

        [SerializeField] private GameObjectVisibleToggle visibleToggle = null;
        [SerializeField] private GameObjectVisibleToggle imgToggle = null;

        [SerializeField] private Slider slider = null;
        [SerializeField] private TextMeshProUGUI progressTxt = null;
        [SerializeField] private Image progressImage = null;

        [SerializeField] private Button itemBtn = null;

        private int itemNo { get; set; } = 0;
        private int memoryNo { get; set; } = 0;
        private Action<int, int> OnClickHandler = null;

        private MemoryPopupItemInfo ItemInfoList = null;
        private SubMemory pieceInfo = null;

        // Start is called before the first frame update
        void Start()
        {

        }

        public void SetUp(int _memoryNo ,int _itemNo, Action<int, int> onClick)
        {
            itemNo = _itemNo;
            memoryNo = _memoryNo;
            OnClickHandler = onClick;
            
            itemImage.sprite = AddressablesLoader.Instance.LoadAsset<Sprite>("MemoryPopup/Memory_00" + (memoryNo + 1) + "/thumbnail/thumbnail_" + (itemNo+1) + ".png");
            
            pieceInfo = MemoryListPopup.memoryInfos.Find(x => x.MainNo == memoryNo).PeiceList.Find(x => x.SubNo == itemNo);

            ResetItem();
        }

        public void ResetItem()
        {
            itemBtn.interactable = true;
            imgToggle.TurnOnByNameInMultiple("Process");
            if(pieceInfo.State == 0)
            {
                visibleToggle.TurnOnByNameInMultiple("Text (TMP)_lock");
                imgToggle.TurnOnByNameInMultiple("Lock");
                itemBtn.interactable = false;
            }
            else if(pieceInfo.State == 2)
            {
                visibleToggle.TurnOnByNameInMultiple("complete");
                progressTxt.text = pieceInfo.TileList.Count+"/"+ pieceInfo.TileList.Count;
                progressImage.fillAmount = 0f;
            }
            else
            {
                visibleToggle.TurnOnByNameInMultiple("Slider");

                float count = 0;

                foreach (var item in pieceInfo.TileList)
                {
                    if (item.S == 1) count++;
                }

                progressTxt.text = count +"/"+ pieceInfo.TileList.Count;
                slider.value = (float)(count/ pieceInfo.TileList.Count);
                progressImage.fillAmount = 1f - (float)(count / pieceInfo.TileList.Count);
            }
        }

        public void OnClick()
        {
            Debug.Log("Button click == " + itemNo);
            if(OnClickHandler != null)
                OnClickHandler(memoryNo, itemNo);
        }

        public void UpdateItem()
        {

        }

        // Update is called once per frame
        void Update()
        {

        }
    }
}
