using UnityEngine;

namespace SlotKingdoms
{
    public static class SdkConfig
    {
        public static SdkInfo CurrentSdkInfo
        {
            get;
            private set;
        }

        public static void Initialize(BuildType buildType)
        {
            if (CurrentSdkInfo == null)
            {
                if (buildType == BuildType.Real)
                {
                    CurrentSdkInfo = new RealSdkInfo();
                }
                else if(buildType == BuildType.QA
                        || buildType == BuildType.Stage)
                {
                    CurrentSdkInfo = new QASdkInfo();
                }
                else
                {
                    CurrentSdkInfo = new DevSdkInfo();
                }
            }
        }

        public sealed class DevSdkInfo : SdkInfo
        {
            public DevSdkInfo() : base()
            {
                playfabSharedSettings                = "PlayFabSharedSettings_dev";
                facebookAppID                        = "366011297861936";
                epochZoneIndex                       = 2;
                firebaseServicesAosFile              = "google-services-dev.xml";
                firebaseServicesIosFile              = "GoogleService-Info-dev.plist";
                singularAPI                          = "";
                singularSecret                       = "";
            }

            public override UnityProjectInfo CreateUnityProjectInfo()
            {
                return new UnityProjectInfo(
                                                name: "Aquuua Casino - QA", 
                                                cloudID: "6a13f574-40ae-4a97-91ac-535acdf16f96", 
                                                adsTestMode: true,
                                                adsIosGameID: "3500728",
                                                adsAndroidGameID: "3500729"
                                            );
            }
        }

        public sealed class QASdkInfo : SdkInfo
        {
            public QASdkInfo() : base()
            {
                playfabSharedSettings                = "PlayFabSharedSettings_qa";
                facebookAppID                        = "3323068587779341";
                epochZoneIndex                       = 0;
                firebaseServicesAosFile              = "google-services-qa.xml";
                firebaseServicesIosFile              = "GoogleService-Info-qa.plist";
                singularAPI                          = "";
                singularSecret                       = "";
            }

            public override UnityProjectInfo CreateUnityProjectInfo()
            {
                return new UnityProjectInfo(name: "Aquuua Casino - QA", 
                                            cloudID: "6a13f574-40ae-4a97-91ac-535acdf16f96", 
                                            adsTestMode: true,
                                            adsIosGameID: "3500728",
                                            adsAndroidGameID: "3500729");
            }
        }

        public sealed class RealSdkInfo : SdkInfo
        {
            public RealSdkInfo() : base()
            {
                playfabSharedSettings                = "PlayFabSharedSettings_real";
                facebookAppID                        = "1629946540508289";
                epochZoneIndex                       = 1;
                firebaseServicesAosFile              = "google-services-real.xml";
                firebaseServicesIosFile              = "GoogleService-Info-real.plist";
                singularAPI                          = "zempot_d8d64b22";
                singularSecret                       = "2f6fe7ea5debd9744720a27dff1424a7";
            }

            public override UnityProjectInfo CreateUnityProjectInfo()
            {
                return new UnityProjectInfo(name: "Aquuua Casino - Live", 
                                            cloudID: "0994deff-bfad-4881-8b3c-99c28497002d", 
                                            adsTestMode: false,
                                            adsIosGameID: "3764940",
                                            adsAndroidGameID: "3764941");
            }
        }

        public abstract class SdkInfo
        {
            public readonly string FIREBASE_SERVICES_PATH       = Application.dataPath + "/0.UNDERC/Common/Assets/GoogleServices/";
            public readonly string FIREBASE_AOS_VALUES_PATH     = Application.dataPath + "/Plugins/Android/Firebase.androidlib/res/values/";
            public readonly string FIREBASE_AOS_VALUES_FILE     = "google-services.xml";
            public readonly string FIREBASE_IOS_PLIST_PATH      = Application.dataPath;
            public readonly string FIREBASE_IOS_PLIST_FILE      = "GoogleService-Info.plist";

            public string playfabSharedSettings{get; protected set;}
            public string facebookAppID;
            public int epochZoneIndex{get; protected set;}
            public string firebaseServicesAosFile{get; protected set;}
            public string firebaseServicesIosFile{get; protected set;}
            public string singularAPI{get; protected set;}
            public string singularSecret{get; protected set;}

            private UnityProjectInfo unityProjectInfo;
            public abstract UnityProjectInfo CreateUnityProjectInfo();
            public UnityProjectInfo GetUnityProjectInfo()
            {
                if (unityProjectInfo == null)
                {
                    unityProjectInfo = CreateUnityProjectInfo();
                }

                return unityProjectInfo;
            }
        }

        public class UnityProjectInfo
        {
            public string name;
            public string cloudID;
            public string adsIosGameID;
            public string adsAndroidGameID;
            public bool adsTestMode;

            public UnityProjectInfo(string name, 
                                    string cloudID, 
                                    string adsIosGameID, 
                                    string adsAndroidGameID,
                                    bool adsTestMode)
            {
                this.name = name;
                this.cloudID = cloudID;
                this.adsIosGameID = adsIosGameID;
                this.adsAndroidGameID = adsAndroidGameID;
                this.adsTestMode = adsTestMode;
            }

            public string GetGameID()
            {
                string gameID = "";
    #if UNITY_ANDROID
                gameID = adsAndroidGameID;
    #elif UNITY_IOS || UNITY_IPHONE
                gameID = adsIosGameID;
    #endif
                return gameID;
            }
        }
    }
}