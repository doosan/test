namespace SlotKingdoms
{
#pragma warning disable IDE1006 // 명명 스타일
    public enum eTransitionType
    {        
        AttackTransition = 1,
        StealTransition = 2,
        MapTransition = 3,
        CloudTransition = 4,
        CloseTransition = 5,
        StealTransition_Mega = 6,
    };

    public enum eLoadingScreenType
    {
        IntroLoadingScreen = 0,
    };

    public enum eLoadingIntent
    {
        None,
        FacebookLogin,
        Reload
    }

    public enum ePosType
    {
        TOP = 0,
        BOTTOM = 1, 
        LEFT = 2, 
        RIGHT = 3
    }

#pragma warning restore IDE1006 // 명명 스타일
}