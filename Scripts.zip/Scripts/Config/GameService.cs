using UnityEngine;
using epoch.Client.WebView;

#if UNITY_EDITOR
using UnityEditor;
#endif

namespace SlotKingdoms
{
    public static class GameService
    {
#pragma warning disable 0414
        private static readonly string AppleStoreId         = "1531042278";
        private static readonly string MsStoreId            = "9PDMZ6532RWD";
        private static readonly string FacebookFanpageId    = "101712631675250";

        private static readonly string UrlBase             = "https://static.wplpoker.com";

        private static readonly string UrlTermsOfService    = UrlBase + "/policy/termsofservice.html";
        private static readonly string UrlPrivacyPolicy     = UrlBase + "/policy/privacypolicy.html";
        //private static readonly string UrlFaq               = UrlBase + "/hc/en-us/categories/900000190866-FAQ";
        //private static readonly string UrlAskEmma           = UrlBase + "/hc/en-us/requests/new";
        //private static readonly string UrlGdpr              = UrlBase + "/hc/en-us/articles/900003425246-GDPR";

        private static WebViewSettings webViewSettings;
#pragma warning restore 0414

        public static string GetAppVersion()
        {
            return $"{GameAddress.ServerName} {Application.version}{GameAddress.AddressablesDisplayName ?? string.Empty}";
        }

        public static void OpenStore()
        {
            string storeUri = "";
            if (Application.isEditor)
            {
                storeUri = $"https://play.google.com/store/apps/details?id={Application.identifier}";
            }
            else
            {
                switch (GameConfig.RuntimeTarget)
                {
                    case RuntimeTarget.Android:
                        storeUri = $"market://details?id={Application.identifier}";
                        break;

                    case RuntimeTarget.iOS:
                        storeUri = $"itms-apps://itunes.apple.com/app/id{AppleStoreId}";
                        break;

                    case RuntimeTarget.WSAPlayer:
                        storeUri = $"ms-windows-store://pdp/?productid={MsStoreId}";
                        break;
                }
            }
            storeUri = string.Format(System.Globalization.CultureInfo.InvariantCulture, storeUri);

            if (string.IsNullOrEmpty(storeUri) == false)
            {
                Application.OpenURL(storeUri);
                Debug.Log($"[GameService.OpenStore] {storeUri}");
            }
            else
            {
                Debug.LogWarning("[GameService.OpenStore] storeUri is empty");
            }
        }

        public static void OpenTextLink(TextLinkId linkId)
        {
            switch (linkId)
            {
                case TextLinkId.TermsOfService:
                    OpenWebView(UrlTermsOfService);
                    break;

                case TextLinkId.PrivacyPolicy:
                    OpenWebView(UrlPrivacyPolicy);
                    break;
            }
        }

        private static void OpenWebView(string url)
        {
            RuntimeTarget runtimeTarget = GameConfig.RuntimeTarget;
            if (Application.isEditor
                || runtimeTarget == RuntimeTarget.WSAPlayer)
            {
                // 1. todo: uwp 에선 웹뷰가 현재 동작 하지 않으므로 브라우저에서 url을 뛰움
                // 2. 추후 웹뷰에서 동작하도록 변경 해야 함
                Application.OpenURL(url);
            }
            else if (runtimeTarget == RuntimeTarget.Android
                     || runtimeTarget == RuntimeTarget.iOS)
            {
                if (webViewSettings == null)
                {
                    webViewSettings = new WebViewSettings();
                    webViewSettings.ShowFullScreen = true;
                    webViewSettings.ShowNotToday = false;
                    webViewSettings.ShowTitleBar = false;
                }

                WebView.ShowWebView(url, webViewSettings, (WebState state) =>
                {
                    if (state == WebState.Open)
                    {
                    }
                    else if (state == WebState.Fail)
                    {
                    }
                    else if (state == WebState.Close)
                    {
                    }
                });
            }
        }

        private static void OpenFaq()
        {
            //OpenWebView(UrlFaq);
        }

        public static void GoToFanpage()
        {
            string baseUrl = "https://www.facebook.com/";
            RuntimeTarget runtimeTarget = GameConfig.RuntimeTarget;
            if (runtimeTarget == RuntimeTarget.Android)
            {
                Debug.Log($"[GameService.GoToFanpage] CheckPackageExists : {CheckPackageExists("com.facebook.katana")}");
                if (CheckPackageExists("com.facebook.katana"))
                {
                    baseUrl = "fb://page/";
                }
            }
            else if (runtimeTarget == RuntimeTarget.iOS)
            {
                Debug.Log($"[GameService.GoToFanpage] CheckFacebookAppExists : {SlotKingdomsIosPlugin.CheckFacebookAppExists()}");
                if (SlotKingdomsIosPlugin.CheckFacebookAppExists())
                {
                    baseUrl = "fb://profile/";
                }
            }

            string fanpageUrl = $"{baseUrl}{FacebookFanpageId}";
            if (string.IsNullOrEmpty(fanpageUrl) == false)
            {
                Application.OpenURL(fanpageUrl);
                Debug.Log($"[GameService.GoToFanpage] fanpageURL : {fanpageUrl}");
            }
        }

        private static bool CheckPackageExists(string package)
        {
            bool result = false;

            AndroidJavaClass up = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
            AndroidJavaObject ca = up.GetStatic<AndroidJavaObject>("currentActivity");
            AndroidJavaObject packageManager = ca.Call<AndroidJavaObject>("getPackageManager");

            //take the list of all packages on the device
            AndroidJavaObject appList = packageManager.Call<AndroidJavaObject>("getInstalledPackages", 0);
            int num = appList.Call<int>("size");
            for (int i = 0; i < num; i++)
            {
                AndroidJavaObject appInfo = appList.Call<AndroidJavaObject>("get", i);
                string packageNew = appInfo.Get<string>("packageName");
                if (packageNew.CompareTo(package) == 0)
                {
                    result = true;
                    break;
                }
            }

            return result;
        }

        public static void OpenGdpr()
        {
            //OpenWebView(UrlGdpr);
        }

        public static void ExitApp()
        {
#if UNITY_EDITOR
                EditorApplication.isPlaying = false;
#else
                Application.Quit();
#endif
        }

        public static void SendEmailToSupport(string message = null)
        {
            //var url = string.Format(System.Globalization.CultureInfo.InvariantCulture, $"{UrlAskEmma}?pid={AccountSystem.Instance.Pid}");
            //Application.OpenURL(url);
        }
    }
}