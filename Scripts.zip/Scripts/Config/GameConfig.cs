using UnityEngine;

namespace SlotKingdoms
{
    public enum BuildType
    {
        Dev,
        QA,
        Stage,
        Real
    }

    public enum RuntimeTarget
    {
        None        = -1,
        Android     = 0,
        iOS         = 1,
        WSAPlayer   = 2
    }

    public class GameConfig : MonoBehaviour
    {
        public const int ResolutionWidth = 720;
        public const int ResolutionHeight = 1280;
        public const int TargetFrameRate = 60;

        public static BuildType BuildType
        {
            get
            {
#if REAL
                    buildType = BuildType.Real;
#elif STAGE
                    buildType = BuildType.Stage;
#elif QA
                    buildType = BuildType.QA;
#else
                    buildType = BuildType.Dev;
#endif
                return buildType;
            }
        }
        private static BuildType buildType;

        public static RuntimeTarget RuntimeTarget
        {
            get
            {
                if (runtimeTarget == RuntimeTarget.None)
                {
#if UNITY_ANDROID
                    runtimeTarget = RuntimeTarget.Android;
#elif UNITY_IOS
                    runtimeTarget = RuntimeTarget.iOS;
#elif UNITY_WSA
                    runtimeTarget = RuntimeTarget.WSAPlayer;
#endif
                }
                return runtimeTarget;
            }
        }
        private static RuntimeTarget runtimeTarget;
    }
}
