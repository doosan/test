using System.Text;
using UnityEngine;
using UnityEngine.Events;

namespace SlotKingdoms
{
    public class GameAddress 
    {
        public static UnityEvent OnAddressablesVersionUpdated = new UnityEvent();
        public static string AddressablesDisplayName
        {
            get => $"{AddressablesDirectoryName}{AddressablesVersion}";
        }

#if DEV
        private static readonly string KeyUseCustomUri = "key_use_custom_uri";
        private static readonly string KeyLatestProtocol = "key_latest_protocol";
        private static readonly string KeyLatestIp = "key_latest_ip";
        private static readonly string KeyLatestPort = "key_latest_port";

        public static bool UseCustomUri
        {
            get
            {
                if (useCustomUri == -1)
                {
                    useCustomUri = PlayerPrefs.GetInt(KeyUseCustomUri, 0);
                }

                return useCustomUri == 1;
            }
            set
            {
                PlayerPrefs.SetInt(KeyUseCustomUri, value ? 1 : 0);
                useCustomUri = value ? 1 : 0;
            }
        }
        private static int useCustomUri = -1;

        public static string CustomProtocol
        {
            get
            {
                return PlayerPrefs.GetString(KeyLatestProtocol, "");
            }
            set
            {
                PlayerPrefs.SetString(KeyLatestProtocol, value);
            }
        }

        public static string CustomIp
        {
            get
            {
                return PlayerPrefs.GetString(KeyLatestIp, "");
            }
            set
            {
                PlayerPrefs.SetString(KeyLatestIp, value);
            }
        }

        public static string CustomPort
        {
            get
            {
                return PlayerPrefs.GetString(KeyLatestPort, "");
            }
            set
            {
                PlayerPrefs.SetString(KeyLatestPort, value);
            }
        }
#endif

        private static string forceUri;

        private static StringBuilder stringBuilder = new StringBuilder();

        public static string ServerName
        {
            get
            {
                string result;
                if (string.IsNullOrEmpty(forceUri) == false)
                {
                    result = "Force";
                }
#if DEV
                else if (UseCustomUri)
                {
                    result = "Custom";
                }
#endif
                else
                {
                    result = serverName;
                }

                return result;
            }
        }
        private static string serverName;
        public static string Protocol
        {
            get;
            private set;
        }
        public static string Ip
        {
            get;
            private set;
        }
        public static string Port
        {
            get;
            private set;
        }
        // Unity 메뉴 - Window - Asset Management - Addressables - Profiles 창의 SlotKingdoms - Remote.LoadPath 필드에 {SlotKingdoms.GameAddress.BlobStorage} 와 같은 형태로 참조하고 있습니다.
        public static string AddressablesRoute
        {
            get;
            private set;
        }

        public static string AddressablesVersion
        {
            get;
            private set;
        }

        public static string AddressablesDirectoryName
        {
            get;
            private set;
        }
        
        private static bool initOnce;

        public static void Init(BuildType buildType, RuntimeTarget runtimeTarget)
        {
            if (initOnce == false)
            {
                initOnce = true;

                var gameBuilderPreset = Resources.Load<GameBuilderPreset>("GameBuilderPreset");
                string addressablesBlobContainer = gameBuilderPreset.AddressablesBlobContainer;
                string directoryName = gameBuilderPreset.DirectoryName;
                AddressablesVersion = gameBuilderPreset.AddressablesVersion;
                AddressablesDirectoryName = directoryName;

                switch (buildType)
                {
                    case BuildType.Real:
                        UpdateAddress(
                            protocol: "https://",
                            serverName: buildType.ToString(), 
                            ip: "live.aquuuacasino.com", 
                            port: "443", 
                            addressablesRoute: $"https://cw.aquuuacasino.com/{addressablesBlobContainer}/{runtimeTarget}/{directoryName}"
                        );
                        break;

                    case BuildType.Stage:
                        UpdateAddress(
                            protocol: "http://",
                            serverName: buildType.ToString(), 
                            ip: "10.145.83.68", 
                            port: "20826",
                            addressablesRoute: $"https://cw-qa.aquuuacasino.com/{addressablesBlobContainer}/{runtimeTarget}/{directoryName}"
                        );
                        break;

                    case BuildType.QA:
                        UpdateAddress(
                            protocol: "http://",
                            serverName: buildType.ToString(), 
                            ip: "skqa.zempot.com", 
                            port: "20826",
                            addressablesRoute: $"https://cw-qa.aquuuacasino.com/{addressablesBlobContainer}/{runtimeTarget}/{directoryName}"
                        );
                        break;

                    case BuildType.Dev:
                        UpdateAddress(
                            protocol: "http://",
                            serverName: buildType.ToString(), 
                            ip: "skdev.zempot.com", 
                            port: "10826",
                            addressablesRoute: $"https://cw-dev.aquuuacasino.com/{addressablesBlobContainer}/{runtimeTarget}/{directoryName}"
                        );
                        break;
                }
            }
        }

        public static void UpdateAddressablesVersion(string value)
        {
            AddressablesVersion = value;

            OnAddressablesVersionUpdated.Invoke();
        }

        private static void UpdateAddress(string protocol, string serverName, string ip, string port, string addressablesRoute)
        {
            GameAddress.serverName = serverName;
            Protocol = protocol;
            Ip = ip;
            Port = port;
            AddressablesRoute = addressablesRoute;

            Debug.Log($"UpdateAddress : {serverName}, {protocol}, {ip}, {port}, {addressablesRoute}");
        }

        public static void SetForceURI(string uri)
        {
            if (string.IsNullOrEmpty(uri) == false)
            {
                forceUri = uri;
            }
        }

        public static string UriRoute(string route)
        {
            if (string.IsNullOrEmpty(forceUri) == false)
            {
                return MakeUri(forceUri, route);
            }
#if DEV
            else if (UseCustomUri)
            {
                return MakeUri(CustomProtocol, CustomIp, CustomPort, route);
            }
#endif
            else
            {
                return MakeUri(Protocol, Ip, Port, route);
            }
        }

        private static string MakeUri(string uri, string route)
        {
            stringBuilder.Clear();
            stringBuilder.Append(uri).Append("/")
                         .Append(route);

            return stringBuilder.ToString();
        }

        private static string MakeUri(string protocol, string ip, string port, string route)
        {
            stringBuilder.Clear();
            stringBuilder.Append(protocol)
                         .Append(ip).Append(":")
                         .Append(port).Append("/")
                         .Append(route);
            Debug.Log(stringBuilder.ToString());
            return stringBuilder.ToString();
        }

        private static void SetCustomIpPort(int index, string ip, string port)
        {
#if DEV
            if (index < 0)
            {
                UseCustomUri = false;
                SceneSystem.LoadIntro();
            }
            else if(string.IsNullOrEmpty(ip) == false
                    && string.IsNullOrEmpty(port) == false)
            {
                CustomProtocol = ip.Contains("http://") ?
                                 "http://" :
                                 "https://";

                ip = ip.Replace(CustomProtocol, "");

                string key = $"serverlist_{index}";
                string value = $"{ip}:{port}";
                PlayerPrefs.SetString(key, value);
                PlayerPrefs.Save();

                UseCustomUri = true;
                CustomIp = ip;
                CustomPort = port;

                SceneSystem.LoadIntro();
            }
#endif
        }
    }
}