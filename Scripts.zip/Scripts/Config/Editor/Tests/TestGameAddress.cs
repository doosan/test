using NUnit.Framework;

namespace SlotKingdoms
{
    public class TestGameAddress
    {
        [Test]
        public void TestApiRoute()
        {
            // 1. Arrange
            GameAddress.Init(GameConfig.BuildType, GameConfig.RuntimeTarget);

            // 2. Act
            string uri = GameAddress.UriRoute("lobby/login");

            // 3. Assert
            Assert.AreEqual("http://10.145.128.82:10826/api/v1/lobby/login", uri);
        }
    }
}
