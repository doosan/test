using Underc.Ocean;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Game
{
    public sealed class UnlockFishView : BaseGameUnlock
    {
        public enum FishType
        {
            Normal,
            Unique
        }

        public FishType fishType = FishType.Normal;
        [SerializeField] private RectTransform bg;
        [SerializeField] private float normalBgSizeY;
        [SerializeField] private float bigBgSizeY;
        [SerializeField] private Image thumbnail;

        protected override void OnPlay(string fishID)
        {
            if (string.IsNullOrEmpty(fishID))
            {
                Stop();
                return;
            }

            int fishIdValue;

            if (int.TryParse(fishID, out fishIdValue))
            {
                var seaItemType = fishType == FishType.Normal ? User.SeaItemType.f : User.SeaItemType.s;
                var isLongHeight = FishSystem.Instance.GetFishPreset(seaItemType, fishIdValue).ui.longHeight;
                bg.sizeDelta = new Vector2(bg.sizeDelta.x, isLongHeight ? bigBgSizeY : normalBgSizeY);
                var sprite = FishIconSystem.Instance.GetFishIcon(seaItemType, fishIdValue);

                if (sprite != null)
                {
                    thumbnail.gameObject.SetActive(true);
                    thumbnail.sprite = sprite;
                    thumbnail.preserveAspect = true;
                }
                else
                {
                    Stop();
                }
            }
            else
            {
                Stop();
            }
        }

        public void TestAction()
        {
#if GGDEV_TEST
            FishType tempFishType = fishType; 
            fishType = FishType.Normal;
            var id = UnityEngine.Random.Range(0, 124);
            Play(id.ToString(), null);
            fishType = tempFishType;
#endif
        }

        public void TestActionSwimmer()
        {
#if GGDEV_TEST
            FishType tempFishType = fishType; 
            fishType = FishType.Unique;
            var id = UnityEngine.Random.Range(0, 6);
            Play(id.ToString(), null);
            fishType = tempFishType;
#endif
        }

        public void TestActionLongIcon()
        {
#if GGDEV_TEST
            FishType tempFishType = fishType; 
            fishType = FishType.Normal;
            var id = 107;
            Play(id.ToString(), null);
            fishType = tempFishType;
#endif
        }
    }
}