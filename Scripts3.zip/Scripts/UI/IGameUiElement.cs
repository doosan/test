using SlotGame.UI;
using Underc.UI;

namespace Underc.Game
{
    public interface IGameUiElement
    {
        void Initialize(GameUI gameUI, TopUI topUI);
        void Show(bool animation);
        void Hide(bool animation);
    }
}