using DG.Tweening;
using Gaga.Util;
using Underc.Net;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using Gaga.Sound;
using Underc.User;
using Gaga.Skin;

namespace Underc.Game
{
    public sealed class WinNoti : MonoBehaviour
    {
        public delegate void CollectDelegate(NotiData data);
        public event CollectDelegate OnCollect;

        #pragma warning disable 0649
        [SerializeField] private CanvasGroup canvasGroup;
        [SerializeField] private Animator animator;
        [SerializeField] private WinBroadcastTexture winBroadcastTexture;

        [Header("Normal")]
        [SerializeField] private GameObject normalRoot;
        [SerializeField] private Text normalNicknameText;
        [SerializeField] private TextMeshProUGUI winText;
        [SerializeField] private Image slotThumbnale;
        [SerializeField] private Image normalUserThumbnale;
        [SerializeField] private GameObject normalCollectButton;

        [Space]
        [SerializeField] private GameObject hugewin;
        [SerializeField] private GameObject megawin;
        [SerializeField] private GameObject epicwin;
        [SerializeField] private GameObject jackpot;

        [Header("Unlock")]
        [SerializeField] private GameObject unlockRoot;
        [SerializeField] private Text unlockNicknameText;
        [SerializeField] private Image unlockUserThumbnale;
        [SerializeField] private GameObject unlockCollectButton;

        [Header("Sounds")]
        [SerializeField] private SoundPlayer winSound;
        [SerializeField] private SoundPlayer clickSound;
        #pragma warning restore 0649

        private NotiData data;

        public bool Interactable
        {
            get {return canvasGroup.interactable;}
            set
            {
                canvasGroup.interactable = value;
                canvasGroup.blocksRaycasts = value;
            }
        }

        public void Set(NotiData notiData)
        {
            data = notiData;

            normalCollectButton.SetActive(true);
            unlockCollectButton.SetActive(true);

            if (notiData.type == "unlock")
            {
                unlockRoot.SetActive(true);
                normalRoot.SetActive(false);

                unlockNicknameText.text = notiData.nick;
            }
            else
            {      
                unlockRoot.SetActive(false);
                normalRoot.SetActive(true);

                hugewin.SetActive(notiData.type == "huge");
                megawin.SetActive(notiData.type == "mega");
                epicwin.SetActive(notiData.type == "epic");
                jackpot.SetActive(notiData.type == "jp");

                normalNicknameText.text = notiData.nick;
                winText.text = StringUtils.ToKMB(notiData.win, StringUtils.GeneralKMBOption(1000000));

                var slotData = MyInfo.SlotGame.GetSlotData(notiData.sid);
                var posterSkin = slotData == null ? SkinType.None : Skin.ConvertToSkinType(slotData.Skin);
                var poster = winBroadcastTexture.Get(notiData.sid, posterSkin);
                
                if (poster != null)
                {
                    slotThumbnale.color = new Color(1,1,1,1);
                    slotThumbnale.sprite = poster;
                }
                else
                {
                    slotThumbnale.color = new Color(1,1,1,0);
                }
            }

            SetPicture(null);
            
            if (string.IsNullOrEmpty(data.url) == false)
            {
                DownloadSystem.Instance.GetSprite(data.url, SetPicture);
            }
            else
            {
                ProfileIconSystem.Instance.GetAsync(data.pic,SetPicture);
            }
        }

        private void SetPicture(Sprite sprite)
        {
            if (sprite != null)
            {
                if (normalUserThumbnale != null)
                {
                    normalUserThumbnale.DOFade(1.0f, 0.3f);
                    normalUserThumbnale.sprite = sprite;
                }

                if (unlockUserThumbnale != null)
                {
                    unlockUserThumbnale.DOFade(1.0f, 0.3f);
                    unlockUserThumbnale.sprite = sprite;
                }
            }
            else
            {
                if (normalUserThumbnale != null)
                {
                    normalUserThumbnale.color = new Color(1,1,1,0);
                    normalUserThumbnale.sprite = null;
                }

                if (unlockUserThumbnale != null)
                {
                    unlockUserThumbnale.color = new Color(1,1,1,0);
                    unlockUserThumbnale.sprite = null;
                }
            }
        }

        public void Show()
        {
            winSound.Play();
            animator.SetTrigger("Open");
        }

        public void Hide()
        {
            animator.SetTrigger("Close");
        }

        public void OnCollectButtonClicked()
        {
#if UNITY_EDITOR == false
            UndercGameLog.Fobis.ButtonSlot(3);
#endif

            clickSound.Play();

            normalCollectButton.SetActive(false);
            unlockCollectButton.SetActive(false);

            if (OnCollect != null && data != null)
            {
                OnCollect(data);
            }
        }

        public Vector2 GetCollectButtonPosition()
        {
            string type = "";
            if (data == null)
            {
                type = "huge";
            }
            else
            {
                type = data.type;
            }
            
            if (type == "unlock")
            {
                return unlockCollectButton.transform.position;
            }
            else
            {
                return normalCollectButton.transform.position;
            }
        }
    }
}