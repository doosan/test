using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Underc.User;
using Underc.Net;
using Underc.Effect;
using Underc.UI;
using Gaga.System;
using DG.Tweening;
using Underc.Net.Client;
using Gaga.Sound;

namespace Underc.Game
{
    public sealed class WinBroadcast : MonoBehaviour
    {
        #pragma warning disable 0649
        [Header("Common")]
        [SerializeField] private GameObject failureEffect;

        [Header("Win Noti")]
        [SerializeField] private WinNoti winNoti;
        [SerializeField] private float winNotiShowDuration = 0.5f;
        [SerializeField] private float winNotiHideDuration = 0.5f;
        [SerializeField] private float winNotiWaitDuration = 4.0f;
        [SerializeField] private float winNotiCollectDelay = 0.3f;

        [Header("Win Congrats")]
        [SerializeField] private Transform winCongratsSpawnPosition;
        [SerializeField] private float winCongratsSpawnRange = 100.0f;
        [SerializeField] private float winCongratsMoveDistance = 1000.0f;
        [SerializeField] private float winCongratsMoveTime = 10.0f;
        [SerializeField] private Ease winCongratsMoveEase = Ease.Linear;
        [SerializeField] private float winCongratsDelayMin = 0.3f;
        [SerializeField] private float winCongratsDelayMax = 0.6f;
        [SerializeField] private WinCongrats winCongratsReference;
        [SerializeField] private GameObject winCongratsPoolRoot;
        [SerializeField] private SoundPlayer winCongratsSound;
        #pragma warning restore 0649

        public bool RunAsFake
        {
            set;
            private get;
        }

        private Queue<NotiData> notiDatas;
        private bool isWinNotiOn;
        private bool closeWinNotiImmediately;
        private NotiData collectNoti;
        private TopUI topUI;
        private GameObjectPool<WinCongrats> winCongratsPool;
        private bool isWinCongratsOn;
        private bool isBroadcastAlarmOn;
        private float pollingGauge;

        private void Start()
        {
            SetupWinNoti();
            SetupTopUI();
            SetupWinCongrats();
            SetupWinBroadcast();

            failureEffect.SetActive(false);
        }

        private void OnDestroy()
        {
            MyInfo.Challenge.onChange -= OnChallengeChange;
            MyInfo.Settings.onBroadcastAlarm -= OnBroadcastAlarm;
        }

        private void SetupWinNoti()
        {
            notiDatas = new Queue<NotiData>();

            winNoti.gameObject.SetActive(false);
            winNoti.OnCollect += OnCollectHandler;
        }

        private void SetupTopUI()
        {
            topUI = GameObject.FindObjectOfType<TopUI>();
        }

        private void SetupWinCongrats()
        {
            winCongratsPool = new GameObjectPool<WinCongrats>(winCongratsPoolRoot
                                                             ,8
                                                             ,()=>
                                                             {
                                                                 return Instantiate(winCongratsReference).GetComponent<WinCongrats>();
                                                             });
        }

        private void SetupWinBroadcast()
        {
            if (MyInfo.Challenge.GetState(MyChallenge.ChallengeType.Broadcast) == MyChallenge.State.Completed
                || RunAsFake == true)
            {
                StartCoroutine(Polling(5f));
            }
            else
            {
                MyInfo.Challenge.onChange += OnChallengeChange;
            }
        }

        private void OnChallengeChange(MyChallenge.ChallengeType challengeType, MyChallenge.State state)
        {
            if (challengeType == MyChallenge.ChallengeType.Broadcast && state == MyChallenge.State.CompleteNow)
            {
                MyInfo.Challenge.onChange -= OnChallengeChange;

                StartCoroutine(Polling(10.0f));
            }
        }

        private void OnBroadcastAlarm(bool value)
        {
            isBroadcastAlarmOn = value;

            pollingGauge = value ? 
                           MyInfo.broadcastPollingTime : // 켜졌을 때 즉시 노티를 보내기 위함
                           0f;
        }

        private IEnumerator Polling(float firstPollingDelay = 0.0f)
        {
            var pollingTime = MyInfo.broadcastPollingTime;
            if (pollingTime <= 0.0f)
            {
                yield break;
            }

            yield return new WaitForSeconds(firstPollingDelay);

            OnBroadcastAlarm(MyInfo.Settings.BroadcastAlarm);
            MyInfo.Settings.onBroadcastAlarm += OnBroadcastAlarm;

            while (true)
            {
                if (pollingGauge >= pollingTime)
                {
                    pollingGauge %= pollingTime;

                    try
                    {
                        if (RunAsFake == false)
                        {
                            NetworkSystem.HTTPRequester.Noti(OnNoti);
                        }
                        else
                        {
                            FakeHttpRequester.Instance.Noti(OnNoti);
                        }
                    }
                    catch (System.Exception){}
                }

                if (isBroadcastAlarmOn)
                {
                    pollingGauge += Time.deltaTime;
                }

                yield return null;
            }
        }

        private void OnNoti(NotiResponse resp)
        {
            if (resp.isSuccess == true && resp.ret == 0)
            {
                for (int i = 0; i < resp.data.Length; i++)
                {
                    notiDatas.Enqueue(resp.data[i]);
                }

                try
                {
                    ShowNoti();
                }
                catch (System.Exception){}

            }
        }

        private void ShowNoti()
        {
            if (isWinNotiOn == false
                && gameObject != null 
                && gameObject.activeInHierarchy == true
                && notiDatas != null
                && notiDatas.Count > 0)
            {
                try
                {
                    StartCoroutine(PlayWinNoti());
                }
                catch (System.Exception){}
            }
        }

        private IEnumerator PlayWinNoti()
        {
            isWinNotiOn = true;

            while (notiDatas.Count > 0)
            {
                if (winNoti == null || gameObject == null || notiDatas == null)
                {
                    yield break;
                }

                Debug.Log($"==== PlayWinNoti : {notiDatas.Count}");
                collectNoti = null;
                closeWinNotiImmediately = false;

                var data = notiDatas.Dequeue();
                winNoti.Set(data);
                winNoti.gameObject.SetActive(true);
                winNoti.Show();

                yield return new WaitForSeconds(winNotiShowDuration);     

                winNoti.Interactable = true; 

                float t = 0.0f;
                while (t < winNotiWaitDuration && closeWinNotiImmediately == false)
                {
                    t += Time.deltaTime;
                    yield return null;

                    if (collectNoti != null && collectNoti.ts == data.ts)
                    {
                        yield return CollectWinNoti(collectNoti);
                        closeWinNotiImmediately = true;
                    }
                }

                winNoti.Interactable = false;
                winNoti.Hide();

                yield return new WaitForSeconds(winNotiHideDuration);

                winNoti.gameObject.SetActive(false);
            }

            isWinNotiOn = false;
        }

        private IEnumerator CollectWinNoti(NotiData data)
        {
            var coinEffectStartPos = winNoti.GetCollectButtonPosition();

            IRequest<ClapResponse> req;
            if (RunAsFake == false)
            {
                req = NetworkSystem.HTTPRequester.Clap(data.uid, data.ts);
            }
            else
            {
                req = FakeHttpRequester.Instance.Clap(data.uid, data.ts);
            }

            yield return req.WaitForResponse();

            ClapResponse resp = req.data;
            bool isSuccess = req.data != null && req.data.isSuccess && resp.ret == 0;
            
            if (isSuccess)
            {
                if (topUI != null)
                {
                    var coinEffectEndPos = topUI.GetCoinIconPosition();
                    EffectSystem.Instance.Coin(
                        coinEffectStartPos, 
                        coinEffectEndPos, 
                        topUI.GetCoinIcon(),
                        null,
                        null, 
                        () => MyInfo.Coin += resp.data.bonus,
                        () => topUI.CoinIconAnimation());
                }
                else
                {
                    MyInfo.Coin += resp.data.bonus;
                }

                yield return new WaitForSeconds(winNotiCollectDelay);
            }
            else
            {
                failureEffect.transform.position = coinEffectStartPos;
                failureEffect.SetActive(false);
                failureEffect.SetActive(true);
            }
        }

        private void OnCollectHandler(NotiData data)
        {
            collectNoti = data;
        }

        public void PlayWinCongrats(long timeStamp)
        {
            if (isWinCongratsOn == true)
            {
                return;
            }

            isWinCongratsOn = true;

            NetworkSystem.HTTPRequester.Claps(timeStamp, resp =>
            {
                if (resp.isSuccess == true && resp.ret == 0)
                {
                    if (resp.data == null)
                    {
                        isWinCongratsOn = false;
                    }
                    else
                    {
                        StartCoroutine(PlayWinCongratsCoroutine(resp.data));
                    }
                }
            });
        }

        private IEnumerator PlayWinCongratsCoroutine(ClapsData[] dataList)
        {
            if (dataList.Length > 0)
            {
                winCongratsSound.Play();
            }

            for (int i = 0; i < dataList.Length; i++)
            {
                var data = dataList[i];

                var spawnDelay = UnityEngine.Random.Range(winCongratsDelayMin, Mathf.Clamp(winCongratsDelayMax, winCongratsDelayMin, winCongratsDelayMax));
                yield return new WaitForSeconds(spawnDelay);

                var winCongratsItem = winCongratsPool.Get();
                winCongratsItem.Set(data.pic, data.url);

                var winCongratsItemTr = winCongratsItem.transform;
                winCongratsItemTr.SetParent(winCongratsSpawnPosition, false);

                var spawnRangeHalf = Mathf.Abs(winCongratsSpawnRange) * 0.5f;
                var spawnPosX = UnityEngine.Random.Range(spawnRangeHalf * -0.5f, spawnRangeHalf * 0.5f);

                winCongratsItemTr.localPosition = new Vector3(spawnPosX, 0, 0);

                winCongratsItemTr.DOKill(false);
                winCongratsItemTr.DOLocalMoveY(winCongratsMoveDistance, winCongratsMoveTime)
                                 .SetEase(winCongratsMoveEase)
                                 .OnComplete(()=>
                                 {
                                     winCongratsPool.Return(winCongratsItem);
                                 });
            }

            yield return new WaitForSeconds(winCongratsMoveTime * 0.5f);

            isWinCongratsOn = false;
        }

#if GGDEV
        public void TestClaps()
        {
            List<ClapsData> a = new List<ClapsData>();
            a.Add(new ClapsData(){pic = 1});
            a.Add(new ClapsData(){pic = 3});
            a.Add(new ClapsData());
            a.Add(new ClapsData(){pic = 5});
            a.Add(new ClapsData());
            a.Add(new ClapsData());
            a.Add(new ClapsData());
            a.Add(new ClapsData(){pic = 8});
            a.Add(new ClapsData());

            StartCoroutine(PlayWinCongratsCoroutine(a.ToArray()));
        }
#endif
    }
}