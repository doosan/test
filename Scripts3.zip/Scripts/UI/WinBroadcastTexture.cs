using Gaga.Skin;
using UnityEngine;
using UnityEngine.U2D;

namespace Underc.Game
{
    // 게임씬에서만 사용한다는 판단하에 에셋번들로 빼지않고 씬에 종속 시켜 사용함.

    public sealed class WinBroadcastTexture : MonoBehaviour
    {
        public const string POSTER_PREFIX = "Broad_SlotImg_";

        [SerializeField] private SpriteAtlas atlas;

        public Sprite Get(string slotID, SkinType skin = SkinType.None)
        {
            string posterName;

            if (skin != SkinType.None)
            {
                posterName = string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0}{1}_{2}", POSTER_PREFIX, slotID, skin);
                var sprite = atlas.GetSprite(posterName);

                if (sprite != null)
                {
                    return sprite;
                }
            }

            posterName = string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0}{1}", POSTER_PREFIX, slotID);
            return atlas.GetSprite(posterName);
        }
    }
}