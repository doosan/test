using Underc.Net;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using TMPro;

namespace Underc.Game
{
    public sealed class WinCongrats : MonoBehaviour
    {
        #pragma warning disable 0649
        [SerializeField] private TextMeshProUGUI congratsText;
        [SerializeField] private Animator animator;
        [SerializeField] private string[] congrats;
        [SerializeField] private string[] animTriggers;

        [Space]
        [SerializeField] private Image picture;
        #pragma warning restore 0649

        private DownloadSystem.ID downloadID;

        public void Set(int pic, string url)
        {
            var congratsStr = congrats[UnityEngine.Random.Range(0, congrats.Length)];
            congratsText.text = congratsStr;

            var animTrigger = animTriggers[UnityEngine.Random.Range(0, animTriggers.Length)];
            animator.SetTrigger(animTrigger);

            if (string.IsNullOrEmpty(url) == false)
            {
                downloadID = DownloadSystem.Instance.GetSprite(url, SetPicture);
            }
            else
            {
                ProfileIconSystem.Instance.GetAsync(pic,SetPicture);
            }
        }

        private void OnDisable()
        {
            if (string.IsNullOrEmpty(downloadID.value) == false)
            {
                DownloadSystem.Instance.Abort(downloadID);
            }

            SetPicture(null);
            downloadID.value = null;
        }

        private void SetPicture(Sprite sprite)
        {
            if (sprite != null)
            {
                picture.DOFade(1.0f, 0.3f);
                picture.sprite = sprite;
            }
            else
            {
                picture.color = new Color(1,1,1,0);
                picture.sprite = null;
            }
        }
    }
}