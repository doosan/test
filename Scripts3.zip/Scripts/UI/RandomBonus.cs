using System;
using Gaga.System;
using Underc.UI;
using Underc.User;
using UnityEngine;

namespace Underc.Game
{
    public sealed class RandomBonus : MonoBehaviour
    {
        public enum RandomBonusType
        {
            Fish = 0,
            Swimmer = 1,
            Pearl = 2,
            Ticket = 3
        }

        [SerializeField] private GameObject viewPoolRoot;
        [SerializeField] private RandomBonusView viewRefernce;
        public float fishPotShowDelay = 1.5f;
        public float fishPotHideDelay = 0.3f;

        private GameObjectPool<RandomBonusView> viewPool;
        private TopUI topUI;
        private FishPot fishPot;

        private void Awake()
        {
            viewRefernce.gameObject.SetActive(false);
        }

        public void Initialize(TopUI topUI, FishPot fishPot)
        {
            this.topUI = topUI;
            this.fishPot = fishPot;

            viewPool = new GameObjectPool<RandomBonusView>(viewPoolRoot,
                                                            1,
                                                            ()=>
                                                            {
                                                                return Instantiate(viewRefernce).GetComponent<RandomBonusView>();
                                                            });
}

        public void CollectFish(int id, long point, bool isNew, bool isPrize, Action onCollect)
        {
            fishPot.Show(fishPotShowDelay);

            Collect(RandomBonusType.Fish, id, point, fishPot.GetCollectPosition(), onCollect, ()=>
            {
                fishPot.ShowBadge(isNew, isPrize);
                fishPot.CollectAnimation();
                fishPot.Hide();
            });
        }

        public void CollectSwimmer(int id, long point, bool isNew, bool isPrize, Action onCollect)
        {
            fishPot.Show(fishPotShowDelay);

            Collect(RandomBonusType.Swimmer, id, point, fishPot.GetCollectPosition(), onCollect, ()=>
            {
                fishPot.ShowBadge(isNew, isPrize);
                fishPot.CollectAnimation();
                fishPot.Hide();
            });
        }

        public void CollectPearl(long value, Action onCollect)
        {
            Collect(RandomBonusType.Pearl, 0, value, topUI.GetPearlIconPosition(), onCollect, ()=>
            {
                topUI.PearlIconAnimation();
            });
        }

        public void CollectTicket(long value, Action onCollect)
        {
            Collect(RandomBonusType.Ticket, 0, value, topUI.GetTicketIconPosition(), onCollect, ()=>
            {
                topUI.TicketIconAnimation();
            });
        }

        public void Collect(RandomBonusData data, Action onCollect)
        {
            if (data == null || data.value == 0)
            {
                onCollect?.Invoke();
                return;
            }

            RandomBonusType randomBonusType = (RandomBonusType)data.type;
            
            if (randomBonusType == RandomBonusType.Fish)
            {
                CollectFish(data.id, data.value, data.IsNew, data.IsPrize, onCollect);
            }
            else if (randomBonusType == RandomBonusType.Swimmer)
            {
                CollectSwimmer(data.id, data.value, data.IsNew, data.IsPrize, onCollect);
            }
            else if (randomBonusType == RandomBonusType.Pearl)
            {
                CollectPearl(data.value, onCollect);
            }
            else if (randomBonusType == RandomBonusType.Ticket)
            {
                CollectTicket(data.value, onCollect);
            }
        }

        private void Collect(RandomBonusType randomBonusType, int id, long value, Vector2 endPos, Action onCollect, Action onEnd)
        {
            var view = viewPool.Get();
            view.transform.SetParent(transform, false);
            view.transform.position = Vector3.zero;

            view.Play(randomBonusType, id, value, endPos, onCollect, ()=>
            {
                if (randomBonusType == RandomBonusType.Pearl)
                {
                    MyInfo.Pearl += value;
                }
                else if (randomBonusType == RandomBonusType.Ticket)
                {
                    MyInfo.Ticket += value;
                }

                viewPool.Return(view);

                onEnd?.Invoke();
            });
        }

        private void TestAction(int index, bool isNew, bool isPrize)
        {
#if GGDEV_TEST
            if ((RandomBonusType)index == RandomBonusType.Fish)
            {
                Debug.Log("Collect Fish");
                int rv = UnityEngine.Random.Range(1, 100);
                CollectFish(rv, 1, isNew, isPrize, null);
            }

            if ((RandomBonusType)index == RandomBonusType.Pearl)
            {
                Debug.Log("Collect Pearl");
                long rv = UnityEngine.Random.Range(1000, 99999);
                CollectPearl(rv, null);
            }

            if ((RandomBonusType)index == RandomBonusType.Ticket)
            {
                Debug.Log("Collect Ticket");
                long rv = UnityEngine.Random.Range(1, 30);
                CollectTicket(rv, null);
            }
#endif
        }

        public void TestAction(int index)
        {
#if GGDEV_TEST
            TestAction(index, false, false);
#endif
        }

        public void TestActionWithNew(int index)
        {
#if GGDEV_TEST
            TestAction(index, true, false);
#endif
        }

        public void TestActionWidhPrize(int index)
        {
#if GGDEV_TEST
            TestAction(index, false, true);
#endif
        }
    }
}