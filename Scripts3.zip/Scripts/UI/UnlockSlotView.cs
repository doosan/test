using Gaga.Skin;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Game
{
    public sealed class UnlockSlotView : BaseGameUnlock
    {
        [SerializeField] private WinBroadcastTexture winBroadcastTexture;
        [SerializeField] private Image thumbnail;

        protected override void OnPlay(string slotID)
        {
            var slotData = MyInfo.SlotGame.GetSlotData(slotID);
            var posterSkin = slotData == null ? SkinType.None : Skin.ConvertToSkinType(slotData.Skin);
            var sprite = winBroadcastTexture.Get(slotID, posterSkin);

            if (sprite != null)
            {
                thumbnail.sprite = sprite;
            }
            else
            {
                Stop();
            }
        }

        public void TestAction()
        {
#if GGDEV_TEST
            string[] arr = new string[]{"1003", "1004"};
            var id = arr[UnityEngine.Random.Range(0, arr.Length)];
            Play(id, null);
#endif
        }
    }
}