using UnityEngine;
using TMPro;
using SlotGame.UI;
using Gaga.Util;

namespace Underc.Game
{
    public sealed class MaxBetNoticePanel : MonoBehaviour 
    {
        #pragma warning disable 0649
        [SerializeField] private GameObject root;
        public Vector2 rootOffset;
        [SerializeField] private TextMeshProUGUI coinText;
        [SerializeField, TextArea] private string textFormat;

        #pragma warning restore 0649

        private BottomUI bottomUI;

        private void Awake()
        {
            Hide();
        }

        public void Show()
        {
            Show(0);
        }

        public void Show(long coins)
        {
            Hide();

            coinText.text = string.Format(System.Globalization.CultureInfo.InvariantCulture, textFormat, StringUtils.ToComma(coins));

            root.SetActive(true);
            BottomUI bottomUI = GetBottomUI();
            var targetPos = transform.InverseTransformPoint(bottomUI.GetMaxBetButtonPosition());
            root.transform.localPosition = new Vector2(targetPos.x, targetPos.y) + rootOffset;
        }

        public void Hide()
        {
            root.SetActive(false);
        }

        private BottomUI GetBottomUI()
        {
            if (bottomUI == null)
            {
                bottomUI = FindObjectOfType<BottomUI>();
            }

            return bottomUI;
        }
    }
}