using System;
using UnityEngine;

namespace Underc.Game
{
    public abstract class BaseGameUnlock : MonoBehaviour
    {
        private Action onComplete;

        protected virtual void Awake()
        {
            gameObject.SetActive(false);
        }

        public void Play(string id, Action onComplete = null)
        {
            this.onComplete = onComplete;

            gameObject.SetActive(false);
            gameObject.SetActive(true);

            OnPlay(id);
        }

        protected abstract void OnPlay(string id);

        public void Stop()
        {
            gameObject.SetActive(false);
            onComplete?.Invoke();
        }
    }
}