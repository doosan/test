using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Gaga.Sound;

namespace Underc.Game
{
    public sealed class GameUnlockController : MonoBehaviour
    {
        public enum UnlockType
        {
            Slot,
            Fish,
            Swimmer
        }

        private struct UnlockSequenceItem
        {
            public BaseGameUnlock unlockView;
            public string id;
        }

        [SerializeField] private UnlockSlotView slotUnlockView;
        [SerializeField] private UnlockFishView fishUnlockView;
        [SerializeField] private UnlockFishView swimmerUnlockView;

        [Space]
        [SerializeField] private SoundPlayer unlockSFX;

        public RectTransform CachedTransform
        {
            get
            {
                if (cachedTransform == null)
                {
                    cachedTransform = GetComponent<RectTransform>();
                }
                return cachedTransform;
            }
        }
        private RectTransform cachedTransform;

        private Queue<UnlockSequenceItem> sequence;
        private Coroutine sequenceCoroutine;

        private void OnEnable()
        {
            sequence = new Queue<UnlockSequenceItem>();
            sequenceCoroutine = null;
        }

        public void Unlock(UnlockType unlockType, string id)
        {
            BaseGameUnlock unlockView = null;

            if (unlockType == UnlockType.Slot)
            {
                unlockView = slotUnlockView;
            }
            else if (unlockType == UnlockType.Fish)
            {
                unlockView = fishUnlockView;
            }
            else
            {
                unlockView = swimmerUnlockView;
            }

            if (unlockView == null || string.IsNullOrEmpty(id))
            {
                return;
            }

            UnlockSequenceItem item = new UnlockSequenceItem();
            item.unlockView = unlockView;
            item.id = id;

            sequence.Enqueue(item);

            if (sequenceCoroutine == null)
            {
                sequenceCoroutine = StartCoroutine("PlaySequence");
            }
        }

        private IEnumerator PlaySequence()
        {
            while (sequence.Count > 0)
            {
                var item = sequence.Dequeue();
                bool isDone = false;

                unlockSFX.Play();

                item.unlockView.Play(item.id, ()=>
                {
                    isDone = true;
                });

                while (isDone == false)
                {
                    yield return null;
                }
            }

            sequenceCoroutine = null;
        }

        public void TestAction()
        {
#if GGDEV_TEST
            if (UnityEngine.Random.Range(0,2) == 0)
            {
                string[] arr = new string[]{"1001", "1002", "1003", "1004", "1005", "1013", "1020", "1030"};
                var id = arr[UnityEngine.Random.Range(0, arr.Length)];
                Unlock(UnlockType.Slot, id);

                Debug.Log("slot : "+id);
            }
            else
            {
                if (UnityEngine.Random.Range(0,2) == 0)
                {
                    var id = UnityEngine.Random.Range(0, 124).ToString();
                    id = "f," + id;
                    Unlock(UnlockType.Fish, id);

                    Debug.Log("fish : "+id);
                }
                else
                {
                    var id = UnityEngine.Random.Range(0, 6).ToString();
                    id = "s," + id;
                    Unlock(UnlockType.Swimmer, id);

                    Debug.Log("swimmer : "+id);
                }
            }
#endif
        }
    }
}