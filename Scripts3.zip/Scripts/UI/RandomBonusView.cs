using System;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using Gaga.Util;
using Underc.Util;
using Underc.Ocean;
using DG.Tweening;
using Gaga;
using Underc.Effect;
using Gaga.Sound;

namespace Underc.Game
{
    public sealed class RandomBonusView : MonoBehaviour
    {   
        [Serializable]
        public sealed class RandomBonusItem
        {
            public RandomBonus.RandomBonusType bonusType;
            public GameObject root;
            public Image image;
            public string prefix;
            public float startSize = 1.0f;
            public float endSize = 0.3f;
            public AnimationCurve moveEase;
        }

        [SerializeField] private Animator animator;
        [SerializeField] private AnimationEventTrigger animationEventTrigger;
        [SerializeField] private Text earnText;
        [SerializeField] private TextMeshProUGUI prefixText;

        [Space]
        [SerializeField] private CurveMovement itemEffect;
        [SerializeField] private int pearlTicketEffectCount = 10;
        [SerializeField] private RandomBonusItem[] items;
        [SerializeField] private SoundPlayer fishCollectSFX;

        private bool collectTrigger;
        private Action onCollect;
        private Action onComplete;
        private Transform itemOriginParent;
        private Vector2 itemOriginLocalPos;
        private Vector2 endPosition;
        private RandomBonusItem currentItem;

        private void Awake()
        {
            itemOriginParent = itemEffect.transform.parent;
            itemOriginLocalPos = itemEffect.transform.localPosition;
            animator.gameObject.SetActive(false);
            animationEventTrigger.OnTrigger.AddListener(Collect);
        }

        private void OnDisable()
        {
            collectTrigger = false;
        }

        public void Play( RandomBonus.RandomBonusType randomBonusType, int id, long value, Vector2 endPos, Action onCollect, Action onComplete)
        {
            this.onCollect = onCollect;
            this.onComplete = onComplete;
            collectTrigger = false;
            endPosition = endPos;

            itemEffect.gameObject.SetActive(true);
            itemEffect.transform.DOKill(false);
            itemEffect.transform.SetParent(itemOriginParent, true);
            itemEffect.transform.localPosition = itemOriginLocalPos;
            
            animator.gameObject.SetActive(true);

            float startSize = 1.0f;

            for (int i = 0; i < items.Length; i++)
            {
                var item = items[i];

                if (item.bonusType == randomBonusType)
                {
                    currentItem = item;
                    startSize = item.startSize;
                    item.root.SetActive(true);

                    prefixText.text = item.prefix;
                    earnText.text = StringUtils.ToComma(value);

                    if (randomBonusType == RandomBonus.RandomBonusType.Fish || randomBonusType == RandomBonus.RandomBonusType.Swimmer)
                    {
                        SeaItemType seaItemType = randomBonusType == RandomBonus.RandomBonusType.Fish ? SeaItemType.f : SeaItemType.s;
                        var fishIcon = FishIconSystem.Instance.GetFishIcon(seaItemType, id);
                        
                        if (fishIcon != null)
                        {
                            item.image.gameObject.SetActive(true);

                            item.image.sprite = fishIcon;
                            item.image.SetNativeSize();
                        }
                        else
                        {
                            item.image.gameObject.SetActive(false);
                        }
                    }
                }
                else
                {
                    item.root.SetActive(false);
                }
            }

            itemEffect.transform.localScale = new Vector3(startSize, startSize, 1.0f);
        }

        private void Collect()
        {
            collectTrigger = true;

            onCollect?.Invoke();

            if (currentItem.bonusType == RandomBonus.RandomBonusType.Fish)
            {
                fishCollectSFX.Play();

                itemEffect.transform.SetParent(transform, true);
                itemEffect.Move(endPosition, ()=>
                {
                    onComplete?.Invoke();
                    animator.gameObject.SetActive(false);
                });

                itemEffect.transform.DOKill(false);
                itemEffect.transform.DOScale(new Vector3(currentItem.endSize, currentItem.endSize, 1.0f), itemEffect.duration)
                                    .SetEase(currentItem.moveEase);
            }
            else
            {
                itemEffect.gameObject.SetActive(false);

                if (currentItem.bonusType == RandomBonus.RandomBonusType.Pearl)
                {
                    EffectSystem.Instance.Pearl(pearlTicketEffectCount,
                                                itemOriginLocalPos,
                                                endPosition,
                                                null,
                                                null,
                                                ()=> onComplete?.Invoke());
                }
                else
                {
                    EffectSystem.Instance.Ticket(pearlTicketEffectCount,
                                                itemOriginLocalPos,
                                                endPosition,
                                                null,
                                                null,
                                                ()=> onComplete?.Invoke());
                }
            }
        }
    }
}