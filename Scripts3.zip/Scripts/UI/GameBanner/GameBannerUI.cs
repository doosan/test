using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using Underc.UI;
using SlotGame.UI;
using SlotGame.Machine;
using Underc.User;
using Underc.Tutorial;
using System.Collections.Generic;

namespace Underc.Game
{
    public class GameBannerUI : MonoBehaviour, IGameUiElement
    {
#pragma warning disable 0649
        [Header("General")]
        [SerializeField] private RectTransform root;
        [SerializeField] public float hidePosX = -250.0f;

        [SerializeField] public BaseGameBanner[] banners;
        [SerializeField] public VerticalLayoutGroup layoutGroup = null;
        [SerializeField] public float bannerAlignDuration = 0.5f;
        [SerializeField] public Ease bannerAlignEase = Ease.InCubic;
        [SerializeField] public float bannerAlignInterval = 0.1f;

#pragma warning restore 0649

        private bool bannerChanged;

        //awake 시점과 같다
        public void Initialize(GameUI gameUI, TopUI topUI)
        {
            SlotMachine slot = GameObject.FindObjectOfType<SlotMachine>();
            foreach (var banner in banners)
            {
                banner.Initialize(slot, gameUI, topUI);
                banner.OnActiveChanged += OnBannerActiveChanged;
            }
        }

        private void Start()
        {
            var tutorialInfo = MyInfo.Tutorial;
            if (MyInfo.Tutorial.IsComplete(TutorialChapter.PlaySlot) == false)
            {
                foreach (var banner in banners) banner.Hide(false);

                TutorialSystem.Instance.onComplete += OnTutorialCompleteHandler;
            }
        }

        private void OnTutorialCompleteHandler(TutorialChapter chapter)
        {
            if (chapter == TutorialChapter.PlaySlot)
            {
                foreach (var banner in banners)
                {
                    banner.Show(true, ()=>
                    {
                        banner.BannerStarted();
                    });
                }

                TutorialSystem.Instance.onComplete -= OnTutorialCompleteHandler;
            }
        }
        
        private void OnBannerActiveChanged(BaseGameBanner banner)
        {
            //특정 배너가 없어졌거나 생겼다! 레이아웃 그룹을 켜두면 뚝! 하고 움직이므로 부드럽게 움직일 수 있도록 레이아웃 그룹은 잠시 비활성한다
            //같은 프레임에서 여러개의 배너가 변경될수도 있으므로 여기서 바로 배너 정렬을 하지 않고 플래그만 꺽어둔다. 다음 update 시점에 한번에 처리
            layoutGroup.enabled = false;
            bannerChanged = true;
        }

        private void OnDestroy()
        {
            TutorialSystem.Instance.onComplete -= OnTutorialCompleteHandler;
            foreach (var banner in banners)
            {
                banner.OnActiveChanged -= OnBannerActiveChanged;
            }
        }

        public void Show(bool animation)
        {
            root.DOKill(false);

            if (animation == true)
            {
                root.DOLocalMoveX(0.0f, 0.5f).SetEase(Ease.OutQuint).OnComplete(AllBannerStarted);
            }
            else
            {
                root.localPosition = Vector3.zero;
                AllBannerStarted();
            }
        }

        private void AllBannerStarted()
        {
            foreach (var banner in banners)
            {
                banner.BannerStarted();
            }
        }


        public void Hide(bool animation)
        {
            root.DOKill(false);

            if (animation == true)
            {
                root.DOLocalMoveX(hidePosX, 0.5f).SetEase(Ease.OutQuint);
            }
            else
            {
                var tempPos = root.localPosition;
                tempPos.x = hidePosX;
                root.localPosition = tempPos;
            }
        }

        private void AlignBanners()
        {
            var paddingTop = layoutGroup.padding.top;
            var spacing = layoutGroup.spacing;
            float ty = -paddingTop;
            var delay = 0f;

            List<BaseGameBanner> acitveBanners = null;

            for (int i = 0; i < banners.Length; ++i)
            {
                var banner = banners[i];
                if (banner.IsActiveBanner == false) continue;
                if (acitveBanners == null) acitveBanners = new List<BaseGameBanner>();

                acitveBanners.Add(banner);
            }

            bool isActiveBannerEmpty = acitveBanners == null || acitveBanners.Count == 0;
            layoutGroup.gameObject.SetActive(isActiveBannerEmpty == false);
            if (isActiveBannerEmpty)
            {
                return;
            }

            var seq = DOTween.Sequence();
            for (int i = 0; i < acitveBanners.Count; ++i)
            {
                var bannerRect = acitveBanners[i].GetComponent<RectTransform>();
                bannerRect.DOKill();

                var bannerHeight = bannerRect.rect.height;
                ty -= bannerHeight * 0.5f;

                var tween = bannerRect.DOAnchorPosY(ty, bannerAlignDuration).SetEase(bannerAlignEase).SetDelay(delay);
                seq.Insert(0f, tween);

                delay += bannerAlignInterval;
                ty -= bannerHeight * 0.5f + spacing;
            }

            seq.AppendCallback(() => layoutGroup.enabled = true);
        }

        private void Update()
        {
            if (bannerChanged == true)
            {
                AlignBanners();
                bannerChanged = false;
            }
        }
    }
}