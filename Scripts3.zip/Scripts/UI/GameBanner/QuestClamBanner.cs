using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Gaga.Attribute;
using Gaga.Util;
using Gaga.Sound;
using Underc.UI;
using Underc.User;
using Underc.Popup;
using SlotGame.Machine;
using TMPro;
using Underc.Tutorial;
using System;
using DG.Tweening;

namespace Underc.Game
{
    public class QuestClamBanner : BaseGameBanner
    {
        private readonly int ANIM_LOCK = Animator.StringToHash("Lock");
        private readonly int ANIM_UNLOCK = Animator.StringToHash("Unlock");
        private readonly int ANIM_OPEN = Animator.StringToHash("Open");
        private readonly int ANIM_ON = Animator.StringToHash("On");

#pragma warning disable 0649
        [Separator("QuestClam")]
        [SerializeField] private SlantedText unlockLevelText = null;
        [SerializeField] private TextMeshProUGUI missionText;
        [SerializeField] private TextMeshProUGUI missionProgressText;
        [SerializeField] private float missionSwapTime = 0.2f;
        [SerializeField] private float missionSwapDelay = 1.5f;

        [Space]
        [SerializeField] private float gaugeDuration = 0.3f;
        [SerializeField] private Slider gauge;
        [SerializeField] protected Animator animator;

        [Space]
        [SerializeField] private SoundPlayer fullSound;
        [SerializeField] protected SoundPlayer revealSound;

        [Header("Status")]
        [SerializeField] protected GameObject fullStatus;
        [SerializeField] private GameObject spinStatus;

        [Header("ToopTip")]
        [SerializeField] protected Animator tooltipAnimator;
        [SerializeField] protected TextMeshProUGUI tooltipText;
        [SerializeField] private Animator completeAlarm = null;
#pragma warning restore 0649


        private long currentValue = -1;
        private long maxValue = -1;
        private long unlockLevel;
        private bool isLocked;
        private Coroutine collectCoroutine;
        private Coroutine missionSwapCoroutine;
        private bool completeAlarmTriggered = false;

        private void Start()
        {
            var questInfo = MyInfo.QuestClam;
            if (MyInfo.Tutorial.IsComplete(TutorialChapter.PlaySlot) == true &&
                MyInfo.Level >= questInfo.UnlockLevel &&
                questInfo.HasQuest() == false)
            {
                Deactivate(false);
                return;
            }

            CheckUnlock();

            if (isLocked)
            {
                unlockLevelText.text = string.Format(System.Globalization.CultureInfo.InvariantCulture, "LV.{0}", unlockLevel);
            }

            UpdateCurrentProgress(0.0f);
            slot.OnStateChange.AddListener(OnStateChangeHandler);
        }

        private void CheckUnlock()
        {
            var info = MyInfo.QuestClam;
            unlockLevel = info.UnlockLevel;
            isLocked = MyInfo.Level < unlockLevel;

            animator.SetBool(ANIM_LOCK, isLocked);
        }

        public override void BannerStarted()
        {
            if (fullStatus.activeSelf && completeAlarmTriggered == false)
            {
                completeAlarm.SetTrigger(ANIM_ON);
            }
            
            completeAlarmTriggered = true;
        }

        public bool LevelUP()
        {
            var wasLocked = isLocked;
            CheckUnlock();

            if (wasLocked == true && isLocked == false)
            {
                animator.ResetAllTriggers();
                UpdateCurrentProgress(0.0f);
                tooltipAnimator.SetTrigger(ANIM_UNLOCK);
                revealSound.Play();
                return true;
            }
            else
            {
                return false;
            }
        }

        protected virtual void OnStateChangeHandler(string state)
        {
            if (state != SlotMachineState.RESULT_END)
            {
                return;
            }

            if (gameObject.activeInHierarchy == false)
            {
                return;
            }

            if (MyInfo.Tutorial.IsComplete(TutorialChapter.PlaySlot) == false)
            {
                return;
            }

            if (isLocked == true)
            {
                return;
            }

            UpdateCurrentProgress(gaugeDuration, true);
        }

        protected void UpdateCurrentProgress(float duration, bool playSound = false)
        {
            bool isComplete = MyInfo.QuestClam.IsCompelte;

            SetProgress(duration, () =>
            {
                SetStatus(isComplete);

                if (isComplete == true)
                {
                    FullAnimation();

                    if (playSound == true)
                    {
                        fullSound.Play();
                    }
                }
            });
        }

        private void SetProgress(float duration, Action onComplete)
        {
            var questInfo = MyInfo.QuestClam;
            var missionType = questInfo.CurrentMission;
            long current = questInfo.Current;
            long max = questInfo.Max;

            if (currentValue == current && maxValue == max)
            {
                return;
            }

            // Debug.LogFormat("QuestClam SetProgress mission: {0} current: {1} > {2} max: {3} > {4}", missionType, currentValue, current, maxValue, max);

            currentValue = current;
            maxValue = max;

            if (maxValue <= 0)
            {
                return;
            }

            SetTexts();

            gauge.DOKill(false);

            float gaugeVal = (float)currentValue / (float)maxValue;

            if (currentValue == 0)
            {
                gauge.value = 0.0f;

                if (onComplete != null)
                {
                    onComplete();
                }
            }
            else
            {
                if (duration <= 0.0f)
                {
                    gauge.value = gaugeVal;

                    if (onComplete != null)
                    {
                        onComplete();
                    }
                }
                else
                {
                    gauge.DOValue(gaugeVal, duration)
                        .SetEase(Ease.OutQuint)
                        .OnComplete
                        (
                            () =>
                            {
                                if (onComplete != null)
                                {
                                    onComplete();
                                }
                            }
                        );
                }
            }
        }

        public void OnClickHandler()
        {
            PlaySound(isLocked);

            if (isLocked == true)
            {
                Shake();
                return;
            }

            if (collectCoroutine == null
                && MyInfo.QuestClam.IsCompelte == true
                && fullStatus.activeInHierarchy == true)
            {
                collectCoroutine = StartCoroutine(CollectQuestClam());
            }
            else
            {
                tooltipAnimator.SetTrigger(ANIM_OPEN);
            }
        }

        protected IEnumerator CollectQuestClam()
        {
            UndercGameLog.Fobis.ButtonSlot(10);

            OpenAnimation();
            PauseSlotMachine();

            float openTime = 0.4f;
            yield return Popups.QuestClam(MyInfo.QuestClam.CurrentMission, MyInfo.QuestClam.Max)
                               .SetDelay(openTime)
                               .Async()
                               .WaitForClose();

            CloseAnimation();
            ResumeSlotMachine();

            if (MyInfo.QuestClam.HasQuest())
            {
                UpdateCurrentProgress(0.0f);
            }
            else
            {
                Deactivate();
            }

            collectCoroutine = null;
        }

        private IEnumerator SwapMissionText()
        {
            missionProgressText.DOKill(false);
            missionText.DOKill(false);

            missionProgressText.alpha = 0.0f;
            missionText.alpha = 1.0f;

            var waitForDelay = new WaitForSeconds(missionSwapDelay);
            var waitForSwap = new WaitForSeconds(missionSwapTime);

            while (true)
            {
                yield return waitForDelay;

                var progressAlpha = missionProgressText.alpha <= 0.5f ?
                                    1.0f :
                                    0.0f;
                missionProgressText.DOFade(progressAlpha, missionSwapTime);

                var missionAlpha = missionText.alpha <= 0.5f ?
                                   1.0f :
                                   0.0f;
                missionText.DOFade(missionAlpha, missionSwapTime);

                yield return waitForSwap;
            }
        }

        private void SetStatus(bool isComplete)
        {
            fullStatus.SetActive(isComplete);
            spinStatus.SetActive(!isComplete);

            if (isComplete)
            {
                if (missionSwapCoroutine != null)
                {
                    StopCoroutine(missionSwapCoroutine);
                    missionSwapCoroutine = null;
                }
            }
            else
            {
                if (missionSwapCoroutine == null)
                {
                    missionSwapCoroutine = StartCoroutine("SwapMissionText");
                }
            }
        }

        private void SetTexts()
        {
            var questInfo = MyInfo.QuestClam;
            long current = questInfo.Current;
            long max = questInfo.Max;
            string maxKMV = StringUtils.ToKMB(max);
            var missionType = questInfo.CurrentMission;

            missionText.text = questInfo.GetMissionName(missionType);
            tooltipText.text = string.Format(System.Globalization.CultureInfo.InvariantCulture, questInfo.GetToolTipText(missionType), maxKMV);
            missionProgressText.text = string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0}/{1}", StringUtils.ToKMB(current), maxKMV);
        }

        protected void PauseSlotMachine()
        {
            slot.Pause();
        }

        protected void ResumeSlotMachine()
        {
            slot.Resume();
        }

        private void FullAnimation()
        {
            animator.SetTrigger("Full");
        }

        protected void OpenAnimation()
        {
            animator.SetTrigger("Open");
        }

        protected void CloseAnimation()
        {
            animator.SetTrigger("Close");
        }
    }
}