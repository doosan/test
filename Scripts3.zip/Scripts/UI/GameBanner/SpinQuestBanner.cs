using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using Underc.User;
using Underc.UI;
using Underc.Net;
using Underc.Effect;
using Underc.Tutorial;
using Gaga.Attribute;
using Gaga.Util;
using Gaga.Sound;
using TMPro;
using DG.Tweening;
using static Underc.Popup.WarningPopup;
using Underc.Popup;

namespace Underc.Game
{
    public class SpinQuestBanner : BaseGameBanner
    {
        public enum QuestUpdateResult
        {
            None,
            Progress,
            Complete
        }

#pragma warning disable 0649

        [Separator("SpinQuestBanner")]
        [SerializeField] private TextMeshProUGUI missionText;
        [SerializeField] private TextMeshProUGUI missionProgressText;
        [SerializeField] private float missionSwapTime = 0.2f;
        [SerializeField] private float missionSwapDelay = 1.5f;
        [SerializeField] private float collectDelay = 1.5f;

        [Space]
        [SerializeField] private float gaugeDuration = 0.3f;
        [SerializeField] private Slider gauge;
        [SerializeField] protected Animator animator;

        [Space]
        [SerializeField] private SoundPlayer fullSound;
        [SerializeField] protected SoundPlayer revealSound;

        [Header("Status")]
        [SerializeField] protected GameObject fullStatus;
        [SerializeField] private GameObject spinStatus;

        [Header("ToopTip")]
        [SerializeField] protected Animator tooltipAnimator;
        [SerializeField] protected TextMeshProUGUI tooltipText;


        [SerializeField] private GameObject[] stepObjects = null;
        [SerializeField] private TextMeshProUGUI missionRewardText = null;
        [SerializeField] private LoadingIndicator loading = null;
        [SerializeField] private RectTransform rewardStartPos = null;
#pragma warning restore 0649

        private long currentValue = -1;
        private long maxValue = -1;
        private Coroutine missionSwapCoroutine;
        private Coroutine collectCoroutine;

        private void Start()
        {
            var questInfo = MyInfo.SpinQuest;
            if (MyInfo.Tutorial.IsComplete(TutorialChapter.PlaySlot) == true &&
                questInfo.HasQuest() == false)
            {
                Deactivate(false);
                return;
            }

            UpdateCurrentProgress(0.0f);
        }

        public QuestUpdateResult UpdateQuest()
        {
            if (MyInfo.Tutorial.IsComplete(TutorialChapter.PlaySlot) == false)
            {
                return QuestUpdateResult.None;
            }

            var questInfo = MyInfo.SpinQuest;
            if (questInfo.HasQuest() == false)
            {
                return QuestUpdateResult.None;
            }

            if (gameObject.activeInHierarchy == false)
            {
                Reactivate();
                UpdateCurrentProgress(0.0f);

                return QuestUpdateResult.None;
            }
            else
            {
                UpdateCurrentProgress(gaugeDuration, true);

                return MyInfo.SpinQuest.IsCompelte ? QuestUpdateResult.Complete : QuestUpdateResult.Progress;
            }
        }

        public override void Show(bool animation, Action onComplete = null)
        {
            base.Show(animation, onComplete);
            UpdateCurrentProgress(0.0f);
        }

        protected void UpdateCurrentProgress(float duration, bool playSound = false)
        {
            bool isComplete = MyInfo.SpinQuest.IsCompelte;

            SetProgress(duration, () =>
            {
                SetStatus(isComplete);

                if (isComplete == true)
                {
                    FullAnimation();

                    if (playSound == true)
                    {
                        fullSound.Play();
                    }

                    TryCollectReward();
                }
            });
        }

        private void SetProgress(float duration, Action onComplete)
        {
            var questInfo = MyInfo.SpinQuest;
            var missionType = questInfo.CurrentMission;
            long current = questInfo.Current;
            long max = questInfo.Max;

            if (currentValue == current && maxValue == max)
            {
                return;
            }

            // Debug.LogFormat("SpinQuestBanner SetProgress mission: {0} current: {1} > {2} max: {3} > {4}", missionType, currentValue, current, maxValue, max);

            currentValue = current;
            maxValue = max;

            if (maxValue <= 0)
            {
                return;
            }

            SetTexts();

            gauge.DOKill(false);

            float gaugeVal = (float)currentValue / (float)maxValue;

            if (currentValue == 0)
            {
                gauge.value = 0.0f;

                if (onComplete != null)
                {
                    onComplete();
                }
            }
            else
            {
                if (duration <= 0.0f)
                {
                    gauge.value = gaugeVal;

                    if (onComplete != null)
                    {
                        onComplete();
                    }
                }
                else
                {
                    gauge.DOValue(gaugeVal, duration)
                        .SetEase(Ease.OutQuint)
                        .OnComplete
                        (
                            () =>
                            {
                                if (onComplete != null)
                                {
                                    onComplete();
                                }
                            }
                        );
                }
            }
        }

        protected virtual void SetTexts()
        {
            var questInfo = MyInfo.SpinQuest;

            long current = questInfo.Current;
            long max = questInfo.Max;
            var coin = questInfo.Coin;
            var missionType = questInfo.CurrentMission;
            var stepIndex = questInfo.Step - 1;
            if (stepIndex < 0) stepIndex = 0;

            missionText.text = questInfo.GetMissionName(missionType); ;
            tooltipText.text = string.Format(System.Globalization.CultureInfo.InvariantCulture, questInfo.GetToolTipText(missionType), max);
            missionProgressText.text = string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0}/{1}", StringUtils.ToKMB(current), StringUtils.ToKMB(max));

            for (int i = 0; i < stepObjects.Length; ++i)
            {
                stepObjects[i].SetActive(i == stepIndex);
            }

            missionRewardText.text = StringUtils.ToKMB(coin);
        }

        private void SetStatus(bool isComplete)
        {
            fullStatus.SetActive(isComplete);
            spinStatus.SetActive(!isComplete);

            if (isComplete)
            {
                if (missionSwapCoroutine != null)
                {
                    StopCoroutine(missionSwapCoroutine);
                    missionSwapCoroutine = null;
                }
            }
            else
            {
                if (missionSwapCoroutine == null)
                {
                    missionSwapCoroutine = StartCoroutine("SwapMissionText");
                }
            }
        }

        private IEnumerator SwapMissionText()
        {
            missionProgressText.DOKill(false);
            missionText.DOKill(false);

            missionProgressText.alpha = 0.0f;
            missionText.alpha = 1.0f;

            var waitForDelay = new WaitForSeconds(missionSwapDelay);
            var waitForSwap = new WaitForSeconds(missionSwapTime);

            while (true)
            {
                yield return waitForDelay;

                var progressAlpha = missionProgressText.alpha <= 0.5f ?
                                    1.0f :
                                    0.0f;
                missionProgressText.DOFade(progressAlpha, missionSwapTime);

                var missionAlpha = missionText.alpha <= 0.5f ?
                                   1.0f :
                                   0.0f;
                missionText.DOFade(missionAlpha, missionSwapTime);

                yield return waitForSwap;
            }
        }

        public void OnClickHandler()
        {
            if (loading.IsActive == true)
            {
                return;
            }

            if (collectCoroutine == null
                && MyInfo.SpinQuest.IsCompelte == true
                && fullStatus.activeInHierarchy == true)
            {
                collectCoroutine = StartCoroutine(CollectRewardCoroutine());
            }
            else
            {
                tooltipAnimator.SetTrigger("Open");
            }
        }

        private void TryCollectReward()
        {
            if (loading.IsActive == true)
            {
                return;
            }

            if (collectCoroutine == null
                && MyInfo.SpinQuest.IsCompelte == true
                && fullStatus.activeInHierarchy == true)
            {
                collectCoroutine = StartCoroutine(CollectRewardCoroutine());
            }
        }

        private void CollectRewardEffect(MySpinQuest info)
        {
            var startPos = rewardStartPos.position;
            if (info.RewardCoin > 0)
            {
                Vector2 endPos = topUI.GetCoinIconPosition();

                EffectSystem.Instance.Coin(
                    startPosition: startPos
                    , endPosition: endPos
                    , scaleTarget: topUI.GetCoinIcon()
                    , onFirstArrived: () => MyInfo.Coin += info.RewardCoin
                    , onArrived: topUI.CoinIconAnimation
                );
            }

            if (info.RewardPearl > 0)
            {
                Vector2 endPos = topUI.GetPearlIconPosition();

                EffectSystem.Instance.Pearl(
                    startPosition: startPos
                    , endPosition: endPos
                    , scaleTarget: topUI.GetPearlIcon()
                    , onFirstArrived: () => MyInfo.Pearl += info.RewardPearl
                    , onArrived: topUI.PearlIconAnimation
                );
            }

            if (info.RewardTicket > 0)
            {
                Vector2 endPos = topUI.GetTicketIconPosition();

                EffectSystem.Instance.Ticket(
                    startPosition: startPos
                    , endPosition: endPos
                    , scaleTarget: topUI.GetTicketIcon()
                    , onFirstArrived: () => MyInfo.Ticket += info.RewardTicket
                    , onArrived: topUI.TicketIconAnimation
                );
            }
        }

        private IEnumerator CollectRewardCoroutine()
        {
            loading.Show();
            var req = NetworkSystem.HTTPRequester.CollectSpinQuest();
            yield return req.WaitForResponse();
            loading.Hide();

            if (req.isSuccess == false)
            {
                Popups.Warning(req.data.error, ActionType.None, TitleType.Network);
                collectCoroutine = null;
                yield break;
            }

            MySpinQuest info = MyInfo.SpinQuest;
            info.Update(req.data.data);

            OpenAnimation();
            yield return new WaitForSeconds(collectDelay);
            CloseAnimation();
            CollectRewardEffect(info);

            if (info.HasQuest())
            {
                revealSound.Play();
                UpdateCurrentProgress(0.0f);
            }
            else
            {
                yield return new WaitForSeconds(0.25f);
                Deactivate();
            }

            collectCoroutine = null;
            yield break;
        }

        private void FullAnimation()
        {
            animator.SetTrigger("Full");
        }

        protected void OpenAnimation()
        {
            animator.SetTrigger("Open");
        }

        protected void CloseAnimation()
        {
            animator.SetTrigger("Close");
        }
    }
}