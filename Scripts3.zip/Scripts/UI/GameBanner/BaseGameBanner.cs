using System;
using UnityEngine;
using DG.Tweening;
using Underc.UI;
using SlotGame.UI;
using SlotGame.Machine;
using Underc.Transition;
using Gaga.Sound;

namespace Underc.Game
{
    public abstract class BaseGameBanner : MonoBehaviour
    {
        public event Action<BaseGameBanner> OnActiveChanged;

        [Header("Content")]
        [SerializeField] protected RectTransform content;
        [SerializeField] private float contentHidePosX = -250f;
        [SerializeField] private float conentEaseDuration = 0.5f;
        [SerializeField] private Ease contentShowEase = Ease.OutCubic;
        [SerializeField] private Ease contentHideEase = Ease.InCubic;

        [Header("Lock")]
        [SerializeField] private TransformShaker shaker = null;

        [Header("Sound")]
        [SerializeField] private SoundPlayer normalSFX;
        [SerializeField] private SoundPlayer lockSFX;

        protected SlotMachine slot;
        protected GameUI gameUI;
        protected TopUI topUI;

        private float contentOriginPosX;
        public bool IsActiveBanner 
        { 
            get; 
            private set; 
        }

        public virtual void Initialize(SlotMachine slot, GameUI gameUI, TopUI topUI)
        {
            this.slot = slot;
            this.gameUI = gameUI;
            this.topUI = topUI;

            IsActiveBanner = true;

            if (content != null)
            {
                contentOriginPosX = content.anchoredPosition.x;
            }
        }

        public virtual void BannerStarted()
        {
            //해당배너가 슬롯 화면에서 보여지는 첫 순간에 호출된다
        }

        public void Hide(bool animation, Action onComplete = null)
        {
            if (content == null)
            {
                onComplete?.Invoke();
                return;
            }

            if (animation == true)
            {
                content.DOAnchorPosX(contentHidePosX, conentEaseDuration).SetEase(contentHideEase).OnComplete(() =>
                {
                    onComplete?.Invoke();
                });
            }
            else
            {
                var tempPos = content.anchoredPosition;
                tempPos.x = contentHidePosX;
                content.anchoredPosition = tempPos;

                onComplete?.Invoke();
            }
        }

        public virtual void Show(bool animation, Action onComplete = null)
        {
            if (content == null)
            {
                onComplete?.Invoke();
                return;
            }

            if (animation == true)
            {
                content.DOAnchorPosX(contentOriginPosX, conentEaseDuration).SetEase(contentShowEase).OnComplete(() =>
                {
                    onComplete?.Invoke();
                });
            }
            else
            {
                var tempPos = content.anchoredPosition;
                tempPos.x = contentOriginPosX;
                content.anchoredPosition = tempPos;

                onComplete?.Invoke();
            }
        }

        protected void Deactivate(bool animation = true)
        {
            if (IsActiveBanner == false)
            {
                return;
            }

            Debug.LogFormat("BaseGameBanner ({0}) deactivated.", name);

            IsActiveBanner = false;
            if (animation == true)
            {
                Hide(true, () => gameObject.SetActive(false));
            }
            else
            {
                gameObject.SetActive(false);
            }

            OnActiveChanged?.Invoke(this);
        }

        protected void Reactivate(bool animation = true)
        {
            if (IsActiveBanner == true)
            {
                return;
            }

            Debug.LogFormat("BaseGameBanner ({0}) Reactivate.", name);

            IsActiveBanner = true;
            gameObject.SetActive(true);

            if (animation == true)
            {
                Show(true);
            }

            OnActiveChanged?.Invoke(this);
        }

        protected void Shake()
        {
            if (shaker != null)
            {
                shaker.Do();
            }
        }

        protected void PlaySound(bool isLock)
        {
            if (isLock)
            {
                lockSFX?.Play();
            }
            else
            {
                normalSFX?.Play();
            }
        }
    }
}
