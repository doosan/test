using System.Collections;
using System.Collections.Generic;
using SlotGame.Machine;
using Underc.Net.Client;
using Underc.Popup;
using Underc.Scene;
using Underc.UI;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;
using Gaga.System;
using Gaga.UI;
using SlotGame;
using Gaga.Attribute;
using UnityEngine.Serialization;
using Gaga;
using Gaga.Popup;
using Underc.Net;

namespace Underc.Game
{
    public sealed class GameUI : MonoBehaviour
    {
#pragma warning disable 0649
        [FormerlySerializedAs("missionItemManager")]
        [SerializeField] private MissionIconManager missionIconManager;

        [Separator]
        [SerializeField] private CanvasGroup canvasGroup;
        [SerializeField] private Transform topUiRoot;
        [SerializeField] private RectTransform bottomUiRoot;
        [SerializeField] private BetNoticePanel betNoticePanel;
        [SerializeField] private MaxBetNoticePanel maxBetNoticePanel;
        [SerializeField] private GameChallenge gameChallenge;
        [SerializeField] private WinBroadcast winBroadcast;
        [SerializeField] private SpinQuestBanner spinQuestBanner;
        [SerializeField] private RandomBonus randomBonus;
        [SerializeField] private GameUnlockController unlockController;
        [SerializeField] private FishPot fishPot;
        [SerializeField] private GraphicRaycaster graphicRaycaster;
        [SerializeField] private SlotCanvasScaler canvasScaler = null;

        [Header("Level Up")]
        [SerializeField] private float levelUpDuration = 0.8f;
        [SerializeField] private float levelUpWithFeatureDuration = 1.5f;
        [SerializeField] private float levelUpQuestSpinDuration = 1.5f;
        [SerializeField] private float missionPassOpenDelay = 1.5f;
        [SerializeField] private float dailyRewardOpenDelay = 3f;
        [SerializeField] private float unlockDelay = 1.0f;
        [SerializeField] private float totalGrowthDelay = 0.5f;
        [SerializeField] private float betNoticeDuration = 2f;
        [SerializeField] private float vipLevelUpDelay = 1f;
        [SerializeField] private float openPopupDelay = 0.5f;
        #pragma warning restore 0649

        public RandomBonus RandomBonus
        {
            get => randomBonus;
        }
        public GameUnlockController UnlockController
        {
            get => unlockController;
        }
        public BetNoticePanel BetNotice
        {
            get => betNoticePanel;
        }
        public MaxBetNoticePanel MaxBetNotice
        {
            get => maxBetNoticePanel;
        }
        public TopUI TopUI
        {
            get; 
            private set;
        }

        public RectTransform BottomUI
        {
            get
            {
                return bottomUiRoot;
            }
        }

        private GameObject root;
        private Gaga.AssetBundle.AssetBundle commonAssetBundle;
        private Dictionary<SlotMachine.OutsideUIType, Coroutine> coroutineDic;
        private SlotMachine slotMachine;
        private bool hasBetNotice;
        private NoActionTimer noActionTimer;
        private List<Coroutine> missionIconCoroutines;

        public void Initialize(GameObject root, Gaga.AssetBundle.AssetBundle commonAssetBundle)
        {
            this.root = root;
            this.commonAssetBundle = commonAssetBundle;

            coroutineDic = new Dictionary<SlotMachine.OutsideUIType, Coroutine>();
            missionIconCoroutines = new List<Coroutine>();

            SetupCanvas();
            SetupSafePanels();
            SetupTopUI();
            SetupGameUiElements();
            SetupGameChallenge();
            SetupRandomBonus();
        }

        private void Start()
        {
            SetupUnlockController();
        }

        private void OnDestroy()
        {
            if (TopUI != null)
            {
                TopUI.LevelHUD.LevelUpResultView.SetFishPot(null);
            }

            UnlistenNoActionTimer();
        }

        private void SetupCanvas()
        {
            if (canvasScaler == null)
            {
                canvasScaler = gameObject.AddComponent<SlotCanvasScaler>();
            }

            canvasScaler.SetReferenceSize(AppConfig.RESOLUTION_WIDTH, AppConfig.RESOLUTION_HEIGHT);
            canvasScaler.SetOrientation(ScreenSystem.IsLandscape ? SlotOrientationType.Landscape : SlotOrientationType.Portrait);
            canvasScaler.UpdateCanvas();
        }
        
        private void SetupSafePanels()
        {
            if (ScreenSystem.IsPortrait)
            {
                var safePanels = GetComponentsInChildren<SafePanel>();

                foreach (var panel in safePanels)
                {
                    panel.direction = SafePanel.Direction.Vertical;
                }
            }
        }

        public void SetSlotMachine(SlotMachine slotMachine)
        {
            this.slotMachine = slotMachine;

            slotMachine.MachineUI.SetupExternalIcon(missionIconManager.CachedTransform);
            missionIconManager.Setup(slotMachine);

            noActionTimer = gameObject.AddComponent<NoActionTimer>();
            noActionTimer.Play(count: 1, seconds: 10f);
            ListenNoActionTimer();
        }

        private void ListenNoActionTimer()
        {
            if (noActionTimer != null)
            {
                noActionTimer.onConsumed.AddListener(UnlistenNoActionTimer);
                noActionTimer.onTimeout.AddListener(ShowPaytableGuideTooltip);
            }
            if (slotMachine != null)
            {
                slotMachine.OnStateChange.AddListener(OnSlotMachineStateChange);
            }
            PopupSystem.Instance.onCountChanged += OnPopupCountChanged; 
        }

        private void ShowPaytableGuideTooltip()
        {
            StartCoroutine(ShowPaytableGuideTooltipCoroutine());
        }

        private IEnumerator ShowPaytableGuideTooltipCoroutine()
        {
            TopUI.PaytableGuideTooltip.SetActive(false);
            TopUI.PaytableGuideTooltip.SetActive(true);

            float timeBegin = Time.time;
            float timePassed = 0;
            while (timePassed < TopUI.PaytableGuideTooltipDuration)
            {
                timePassed = Time.time - timeBegin;
                if (noActionTimer.HasAnyTouch())
                {
                    TopUI.PaytableGuideTooltipEndAnimation.SetTrigger();
                    break;
                }

                yield return null;
            }

            yield break;
        }

        private void UnlistenNoActionTimer()
        {
            if (noActionTimer != null)
            {
                noActionTimer.onConsumed.RemoveAllListeners();
                noActionTimer.onTimeout.RemoveAllListeners();
            }
            if (slotMachine != null)
            {
                slotMachine.OnStateChange.RemoveListener(OnSlotMachineStateChange);
            }
            PopupSystem.Instance.onCountChanged -= OnPopupCountChanged;
        }

        private void OnPopupCountChanged(int count)
        {
            noActionTimer.Pause(value: count > 0);
        }

        private void OnSlotMachineStateChange(string state)
        {
            noActionTimer.Pause(value: state != SlotMachineState.IDLE);
        }

        private void SetupTopUI()
        {
            TopUI = TopUISystem.Instance.Get(topUiRoot, ScreenSystem.IsLandscape);

            TopUI.transform.SetAsFirstSibling();

            TopUI.UseHomeButton = true;
            TopUI.UseSettingButton = true;

            TopUI.UseLevel = true;
            TopUI.UseCoin = true;
            TopUI.UseProfile = true;
            TopUI.UseShopButton = true;
            TopUI.UseSecondaryCurrencies = false;
            TopUI.OrderAsDefault();

            TopUI.SetSettingMenuItemType(TopUI.SettingMenuItemType.Help 
                                         | TopUI.SettingMenuItemType.System
                                         | TopUI.SettingMenuItemType.Paytable);

            TopUI.SetHomeButtonDisplayType(TopUI.HomeButtonDisplayType.Basic);
            TopUI.LevelHUD.LevelUpResultView.SetFishPot(fishPot);

            TopUI.OnHomeButtonClicked += GoLobby;
        }

        private void SetupGameUiElements()
        {
            var gameUiList = root.GetComponentsInChildren<IGameUiElement>();

            if (gameUiList != null)
            {
                foreach (var gameUiItem in gameUiList)
                {
                    gameUiItem.Initialize(this, TopUI);
                }
            }
        }

        private void SetupGameChallenge()
        {
            gameChallenge.OnChallengeComplete += OnChallengeComplete;
        }

        private void SetupRandomBonus()
        {
            randomBonus.Initialize(TopUI, fishPot);
        }

        private void SetupUnlockController()
        {
            Transform originParent = unlockController.transform.parent;
            // B-1. 먼저 자식들의 x 피봇과 x 좌표를 중앙으로
            foreach (Transform child in unlockController.CachedTransform)
            {
                RectTransform childTransform = child.GetComponent<RectTransform>();
                Vector2 childOriginPosition = childTransform.anchoredPosition;
                Vector2 childProginPivot = childTransform.pivot;
                childTransform.pivot = new Vector2(.5f, childProginPivot.y);
                childTransform.anchoredPosition = new Vector2(0, childOriginPosition.y);
            }
            Vector2 originPositionBefore = unlockController.CachedTransform.anchoredPosition;
            unlockController.CachedTransform.SetParent(TopUI.LevelHUD.XpGaugeTransform, true);
            unlockController.CachedTransform.anchoredPosition = new Vector2(0, 0);
            unlockController.CachedTransform.SetParent(originParent, true);
            // B-2. 레벨 게이지의 자식으로 넣었다가 다시 원래 하이어라키로 이동시키는 방법으로 (x 좌표를) 중앙으로 맞춘다.
            Vector2 originPositionAfter = unlockController.CachedTransform.anchoredPosition;
            unlockController.CachedTransform.anchoredPosition = new Vector2(originPositionAfter.x, originPositionBefore.y);
        }

        public bool SetInteractable(bool value)
        {
            bool originValue = canvasGroup.interactable;

            canvasGroup.interactable = value;
            canvasGroup.blocksRaycasts = value;
            return originValue;
        }

        private void OnChallengeComplete(MyChallenge.ChallengeType challengeType)
        {
            if (challengeType == MyChallenge.ChallengeType.Broadcast)
            {
                WinCongrats(MyInfo.myWinNotiTimeStamp);
            }
        }

        private void OnSceneExit()
        {
            if (TopUI != null)
            {
                TopUI.OnHomeButtonClicked -= GoLobby;
                TopUI.OnPayTable.RemoveAllListeners();
                TopUISystem.Instance.Return(TopUI);
            }
        }

        public void GoLobby()
        {
            GoLobby(SceneSystem.LOBBY_STATE_INDEX_GAME);
        }

        public void GoLobby(int startState)
        {
            SceneSystem.LoadLobby(startState);
        }

        public void WinCongrats(long timeStamp)
        {
            if (timeStamp <= 0)
            {
                return;
            }

            if (gameChallenge.IsChallengeComplete(User.MyChallenge.ChallengeType.Broadcast) == false)
            {
                return;
            }

            winBroadcast.PlayWinCongrats(timeStamp);
        }

        public void Show(SlotMachine.OutsideUIType uiType, bool animation)
        {
            SetActiveUI(uiType, true, animation, 0.0f);
        }

        public void Show(SlotMachine.OutsideUIType uiType, bool animation, float delay)
        {
            SetActiveUI(uiType, true, animation, delay);
        }

        public void Hide(SlotMachine.OutsideUIType uiType, bool animation)
        {
            SetActiveUI(uiType, false, animation, 0.0f);   
        }

        public void Hide(SlotMachine.OutsideUIType uiType, bool animation, float delay)
        {
            SetActiveUI(uiType, false, animation, delay);   
        }

        private void ShowTopUI(bool animation)
        {
            TopUI.Show(animation);

            // A-1. TopUI 내부 구성이 변경된 후 자리를 잡은 시점에
            // A-2. 언락뷰를 레벨 게이지 중앙에 맞춘다.
            SetupUnlockController();
        }

        private void HideTopUI(bool animation)
        {
            TopUI.Hide(animation);
        }

        private void ShowSideUI(bool animation)
        {
            var gameUiList = root.GetComponentsInChildren<IGameUiElement>();
            foreach (var gameUiItem in gameUiList)
            {
                gameUiItem.Show(animation);
            }
        }

        private void HideSideUI(bool animation)
        {
            var gameUiList = root.GetComponentsInChildren<IGameUiElement>();
            foreach (var gameUiItem in gameUiList)
            {
                gameUiItem.Hide(animation);
            }
        }

        private void SetActiveUI(SlotMachine.OutsideUIType uiType, bool isOn, bool animation, float delay)
        {
            if (coroutineDic.ContainsKey(uiType))
            {
                var prevCoroutine = coroutineDic[uiType];
                if (prevCoroutine != null)
                {
                    StopCoroutine(prevCoroutine);
                }

                prevCoroutine = null;
            }

            if (delay > 0.0f)
            {
                var coroutine = StartCoroutine(SetActiveUICoroutine(uiType, isOn, animation, delay));

                if (coroutineDic.ContainsKey(uiType))
                {
                    coroutineDic[uiType] = coroutine;
                }
                else
                {
                    coroutineDic.Add(uiType, coroutine);
                }
            }
            else
            {
                if (isOn)
                {
                    if (uiType == SlotMachine.OutsideUIType.All)
                    {
                        ShowTopUI(animation);
                        ShowSideUI(animation);
                    }
                    else if (uiType == SlotMachine.OutsideUIType.Top)
                    {
                        ShowTopUI(animation);
                    }
                    else if (uiType == SlotMachine.OutsideUIType.Side)
                    {
                        ShowSideUI(animation);
                    }
                }
                else
                {
                    if (uiType == SlotMachine.OutsideUIType.All)
                    {
                        HideTopUI(animation);
                        HideSideUI(animation);
                    }
                    else if (uiType == SlotMachine.OutsideUIType.Top)
                    {
                        HideTopUI(animation);
                    }
                    else if (uiType == SlotMachine.OutsideUIType.Side)
                    {
                        HideSideUI(animation);
                    }
                }
            }
        }

        private IEnumerator SetActiveUICoroutine(SlotMachine.OutsideUIType uiType, bool isOn, bool animation, float delay)
        {
            yield return new WaitForSeconds(delay);

            SetActiveUI(uiType, isOn, animation, 0.0f);
        }

        public void SetRaycast(bool isOn)
        {
            graphicRaycaster.enabled = isOn;
        }

        public void SetXP(float xp, bool animation)
        {
            TopUI.LevelHUD.SetXP(xp, animation);
        }

        public void SetXP(float baseXP, float currXP, float nextXP, bool animation)
        {
            TopUI.LevelHUD.SetXP(baseXP, currXP, nextXP, animation);
        }

        public void UpdateSpinResult(bool isLevelUp, GameSpinResponse spinResp)
        {
            // 1-1. 데일리 퀘스트도 (미션 패스와 마찬가지로) 데이터 갱신 타이밍 때문에 
            // 1-2. IDLE 상태에 와서 뒤늦게 업데이트 해줌
            MyInfo.DailyMission.Update(spinResp.ts, spinResp.daily_quest);
            MyInfo.AquaBlitz.Update(checkUpdateTs: true, spinResp.ts, spinResp.aqua_blitz_mission);

            UpdateMissionIconsCoroutine();

            //
            if (MyInfo.myWinNotiTimeStamp > 0)
            {
                WinCongrats(MyInfo.myWinNotiTimeStamp);
            }

            //
            if (isLevelUp)
            {
                LevelData levelData = spinResp.level;
                VipClassType vipClass = MyInfo.VipClass.Type;

                SetXP(levelData.xp_base, levelData.xp, levelData.next_xp, false);
                LevelUp(levelData.current,
                        levelData.levelup_bonus,
                        levelData.levelup_bonus_added,
                        vipClass,
                        levelData.vip_point,
                        levelData.unlock_slot,
                        levelData.unlock_swimmer,
                        levelData.any_bet,
                        levelData.max_bet > 0,
                        levelData.random_bonus,
                        levelData.growth);
            }
            else
            {
                spinQuestBanner.UpdateQuest();
                StartCoroutine(CheckReward(delay: 1f));
            }
        }

        private void LevelUp(long level, 
                             long levelUpBonus, 
                             long challengeBonus, 
                             VipClassType vipClassType,
                             long levelUpVipPoint,
                             string unlockSlotID, 
                             string unlockFishID,
                             bool unlockAnybet, 
                             bool unlockMaxBet, 
                             RandomBonusData randomBonus, 
                             GrowthData growthData)
        {
            StartCoroutine(LevelUpCoroutine(level, levelUpBonus, challengeBonus, vipClassType, levelUpVipPoint, unlockSlotID, unlockFishID, unlockAnybet, unlockMaxBet, randomBonus, growthData));
        }

        private IEnumerator LevelUpCoroutine(long level, 
                                             long levelUpBonus, 
                                             long challengeBonus, 
                                             VipClassType vipClassType,
                                             long levelUpVipPoint, 
                                             string unlockSlotID, 
                                             string unlockFishID, 
                                             bool unlockAnybet, 
                                             bool unlockMaxBet, 
                                             RandomBonusData randomBonus, 
                                             GrowthData growthData)
        {
            TopUI.LevelHUD.SetLevel(level);

            PauseMachine(true);
            
            //
            bool growthBonus = growthData.IsValid;
            if (growthBonus)
            {
                yield return new WaitForSeconds(totalGrowthDelay);
                yield return Popups.TotalGrowth(level, levelUpBonus, growthData.shop, growthData.daily, growthData.free, growthData.feed, growthData.chest, growthData.congrat)
                                   .Async()
                                   .WaitForClose();
            }
            else
            {
                TopUI.LevelHUD.ShowLevelUP(level, levelUpBonus, vipClassType, levelUpVipPoint, randomBonus);
            }

            bool hasBetNotice = unlockAnybet || unlockMaxBet;
            if (unlockAnybet)
            {
                BetNotice.ShowUnlockAll();
            }
            else if (unlockMaxBet)
            {
                BetNotice.ShowUnlock();
            }

            if (MyInfo.VipClass.ConsumeLevelUp())
            {
                yield return WaitForBetNotice();
                yield return new WaitForSeconds(vipLevelUpDelay + openPopupDelay);
                yield return Popups.VipLevelUpCoroutine();
            }

            //
            if (growthBonus)
            {
                yield return WaitForBetNotice();
                yield return new WaitForSeconds(openPopupDelay);

                bool openShop = false;
                yield return Popups.ShopGrowth(growthData.shop, 
                                               () => openShop = true)
                                   .Async()
                                   .WaitForClose();

                if (openShop)
                {
                    yield return Popups.Shop().Async().WaitForClose();
                }
            }

            SetInteractable(false);

            bool isMissionPassUnlocked = MyInfo.DailyMission.DisplayInfo.ConsumeJustUnlockState();
            if (IsGameChallengeDone())
            {
                yield return new WaitForSeconds(levelUpWithFeatureDuration);

                //
                if (CheckIfSpinQuestComplete())
                {
                    yield return new WaitForSeconds(levelUpQuestSpinDuration);
                }

                //
                gameChallenge.LevelUp(challengeBonus);
                while (gameChallenge.IsBusy())
                {
                    yield return null;
                }
            }
            else
            {
                yield return new WaitForSeconds(levelUpDuration);

                if (isMissionPassUnlocked
                    && CheckIfSpinQuestComplete())
                {
                    yield return new WaitForSeconds(levelUpQuestSpinDuration);
                }
            }

            if (isMissionPassUnlocked)
            {
                yield return ShowMissionPassOpen();
            }

            yield return CheckReward(delay: dailyRewardOpenDelay);

            PauseMachine(false);
            SetInteractable(true);

            if (string.IsNullOrEmpty(unlockSlotID) == false)
            {
                yield return new WaitForSeconds(unlockDelay);
                unlockController.Unlock(GameUnlockController.UnlockType.Slot, unlockSlotID);
            }

            if (string.IsNullOrEmpty(unlockFishID) == false)
            {
                yield return new WaitForSeconds(unlockDelay);

                var fishArr = unlockFishID.Split(',');

                if (fishArr != null && fishArr.Length == 2)
                {
                    var fishType = fishArr[0] == "f" ? GameUnlockController.UnlockType.Fish : GameUnlockController.UnlockType.Swimmer;
                    var fishID = fishArr[1];

                    unlockController.Unlock(fishType, fishID);
                }
            }
        }

        private void PauseMachine(bool value)
        {
            if (value)
            {
                slotMachine.Pause();
            }
            else
            {
                slotMachine.Resume();
            }

            noActionTimer.Pause(value);
        }

        private IEnumerator WaitForBetNotice()
        {
            if (hasBetNotice)
            {
                hasBetNotice = false;
                yield return new WaitForSeconds(betNoticeDuration);
            }
            yield break;
        }

        public void UpdateMissionIcons()
        {
            foreach (BaseMissionIcon missionIcon in missionIconManager.GetAllIcon())
            {
                missionIcon.UpdateInfo(isProgressive: false);
            }
        }

        public void UpdateMissionIconsCoroutine()
        {
            foreach (Coroutine coroutine in missionIconCoroutines)
            {
                if (coroutine != null)
                { 
                    StopCoroutine(coroutine);
                }
            }

            missionIconCoroutines.Clear();
            foreach (BaseMissionIcon missionIcon in missionIconManager.GetAllIcon())
            {
                // 데일리 미션 아이콘만 SetActiveCoroutine 을 통해 자신의 방향으로 스위칭 후 업데이트 하고 있다.
                missionIconCoroutines.Add(StartCoroutine(missionIcon.UpdateInfoCoroutine()));
            }
        }

        public IEnumerator CheckReward(float delay)
        {
            bool prevInteractable = SetInteractable(false);
            PauseMachine(true);

            if (MyInfo.DailyMission.DisplayInfo.Progress >= 1)
            {
                Debug.Log($"==== CheckReward : {MyInfo.DailyMission.DisplayInfo.Progress}");
                yield return new WaitForSeconds(delay);

                DailyMissionIcon dailyMissionIcon = missionIconManager.DailyMissionIcon;
                yield return dailyMissionIcon.GetReward(missionIconManager.IsInPlay, missionIconManager.GetActiveMissionIcon);
            }

            PauseMachine(false);
            SetInteractable(prevInteractable);
        }

        public IEnumerator ShowMissionPassOpen()
        {
            yield return new WaitForSeconds(missionPassOpenDelay);
            yield return Popups.MissionPassOpen().Async().WaitForClose();
            yield return new WaitForSeconds(.25f);

            // 미션 데이터가 존재하지 않아서 먼저 로드
            yield return LoadMission();

            // 언락시 스핀 데이터 내부에 아쿠아 블리츠 정보가 존재하지 않아 수동으로 세팅
            MyInfo.AquaBlitz.FindLatestMissionSpinIndex();

            BaseMissionIcon dailyMissionIcon = missionIconManager.GetIcon(MissionIconType.DailyMission);
            yield return dailyMissionIcon.UnlockCoroutine();
            dailyMissionIcon.UpdateInfo(false);

            yield return Popups.MissionPass(tab: MissionPassPopupTab.MissionPass, syncData: false).Async().Cache().WaitForClose();

            missionIconManager.Unlock();
        }

        private IEnumerator LoadMission()
        {
            Popups.ShowLoading();
            var req = NetworkSystem.HTTPRequester.Mission();
            yield return req.WaitForResponse();
            Popups.HideLoading();

            if (req.isSuccess == true)
            {
                NetworkSystem.HTTPHandler.Do(req.data);
            }
            yield break;
        }

        private bool CheckIfSpinQuestComplete()
        {
            var spinQuestResult = spinQuestBanner.UpdateQuest();
            return spinQuestResult == SpinQuestBanner.QuestUpdateResult.Complete;
        }

        public bool IsGameChallengeDone()
        {
            return gameChallenge.IsDone();
        }
    }
}