using Gaga;
using Gaga.System;
using SlotGame;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Underc;
using Underc.Game;
using Underc.LoadingScreen;
using Underc.Net;
using Underc.Net.Client;
using Underc.Popup;
using Underc.UI;
using Underc.User;
using Underc.Util;
using UnityEngine;

public class TestWinBroadcast : TestSceneScaffold
{
    [SerializeField] private Transform topUiRoot;
    [SerializeField] private WinBroadcast winBroadcast;

    public TopUI TopUI
    {
        get;
        private set;
    }

    private List<NotiData> notiDatas;

    private IEnumerator Start()
    {
        Init();

        yield return SetupAndLoad(new BaseLoadingItem[]
        {
            new LoginLoadingItem(),
            new ProfileIconLoadingItem(),
            new TopUILoadingItem(),
            new ABLoadingItem(AssetBundleName.EFFECT),
        });

        SetupTopUI();
        ShowWinNoti();
    }

    private void Init()
    {
        notiDatas = new List<NotiData>();
    }

    private void SetupTopUI()
    {
        TopUI = TopUISystem.Instance.Get(topUiRoot, ScreenSystem.IsLandscape);

        TopUI.transform.SetAsFirstSibling();
        TopUI.UseCoin = true;
        TopUI.UseProfile = true;
        TopUI.UseLevel = true;
        TopUI.UseSecondaryCurrencies = false;

        TopUI.UseHomeButton = true;
        TopUI.UseShopButton = true;
        TopUI.UseSettingButton = true;

        TopUI.SetHomeButtonDisplayType(TopUI.HomeButtonDisplayType.Basic);
        TopUI.LevelHUD.LevelUpResultView.SetFishPot(null);

        TopUI.OnHomeButtonClicked += null;
    }

    public void ShowWinNoti()
    {
        FakeHttpRequester.Instance.LoadedNotiResponse = () =>
        {
            notiDatas.Clear();
            notiDatas.Add(MakeNotiData());
            notiDatas.Add(MakeNotiData());
            notiDatas.Add(MakeNotiData());
            notiDatas.Add(MakeNotiData());

            var notiResponse = new NotiResponse();
            notiResponse.data = notiDatas.ToArray();

            return notiResponse;
        };

        FakeHttpRequester.Instance.LoadedClapResponse = (long uid, long ts) =>
        {
            var clapData = new ClapData();
            clapData.bonus = 2000;

            var clapResponse = new ClapResponse();
            clapResponse.data = clapData;

            return clapResponse;
        };

        if (winBroadcast.gameObject.activeInHierarchy == false)
        {
            winBroadcast.RunAsFake = true;
            winBroadcast.gameObject.SetActive(true);
        }
    }

    private NotiData MakeNotiData()
    {
        List<string> bigwinTypes = Enum.GetNames(typeof(BigwinType)).ToList();
        bigwinTypes.Remove("none");

        SlotPresetList slotPresetList = Resources.Load("SlotPresetList") as SlotPresetList;

        var data = new NotiData();
        data.ts = GlobalTime.Instance.GetTimeStamp();
        data.type = bigwinTypes[UnityEngine.Random.Range(0, bigwinTypes.Count)];
        data.uid = 1000000329614;
        data.nick = "TunMin";
        data.win = UnityEngine.Random.Range(100000, 100000000);
        data.sid = slotPresetList.Items[UnityEngine.Random.Range(0, slotPresetList.Items.Count)].id.ToString();
        data.pic = UnityEngine.Random.Range(0, ProfileIconSystem.Instance.AssetCount);
        data.url = "";

        return data; 
    }
}
