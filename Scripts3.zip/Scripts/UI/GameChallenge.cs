using Underc.Tutorial;
using Underc.User;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;
using Underc.UI;
using SlotGame.UI;
using DG.Tweening;
using Underc.Net;
using Gaga;
using SlotGame.Machine;
using Underc.Popup;
using Gaga.Sound;
using Underc.Effect;
using UnityEngine.UI;

namespace Underc.Game
{
    public sealed class GameChallenge : MonoBehaviour, IGameUiElement
    {
        private struct ChallengeInfo
        {
            public MyChallenge.ChallengeType challenge;
            public MyChallenge.State state;

            public ChallengeInfo(MyChallenge.ChallengeType challenge, MyChallenge.State state)
            {
                this.challenge = challenge;
                this.state = state;
            }
        }

        [Serializable]
        public class ChallengeContent
        {
            public MyChallenge.ChallengeType challenge;
            public Text lockText;
            public Text unlockText;
            public GameObject[] contents;
        }

        public delegate void ChallengeDelegate(MyChallenge.ChallengeType challengeType);
        public event ChallengeDelegate OnChallengeComplete;

        #pragma warning disable 0649
        [SerializeField] private GameObject root;
        [SerializeField] public float hidePosX = 350.0f;
        [SerializeField] private float expandDelay = 0.5f;
        [SerializeField] private float completeDelay = 3.0f;
        [SerializeField] private float hideDelay = 1.0f;
        
        [Space]
        [SerializeField] private Animator rootAnimator;
        [SerializeField] private Animator frameAnimator;
        [SerializeField] private Animator contentAnimator;
        [SerializeField] private Animator characterAnimator;

        [Space]
        [SerializeField] private RectTransform boosterEffectContainer;
        [SerializeField] private float boosterEffectDelay = 0.5f;
        [SerializeField] private GameObject boosterCompleteEffect;
        [SerializeField] private CurveMovement boosterProjectileEffect;
        [SerializeField] private GameObject boosterExplosionEffect;

        [Space]
        [SerializeField] private ChallengeContent[] challengeContents;

        [Space]
        [SerializeField] private SoundPlayer revealSound;
        #pragma warning restore 0649

        private bool isExtand;
        private bool needUpdate;
        private Queue<ChallengeInfo> challengeQueue;
        private Coroutine challengeCoroutine;
        private RectTransform cachedTransform;
        private TopUI topUI;
        private List<MyChallenge.ChallengeType> completedList;
        private List<MyChallenge.ChallengeType> challengeTypes;
        private long bonusCoin;
 
        private void OnDestroy()
        {
            TutorialSystem.Instance.onComplete -= OnTutorialCompleteHandler;
            MyInfo.Challenge.onChange -= OnChallengeChange;
        }

        public void Initialize(GameUI gameUI, TopUI topUI)
        {
            this.topUI = topUI;

            cachedTransform = GetComponent<RectTransform>();
            challengeQueue = new Queue<ChallengeInfo>();
            completedList = new List<MyChallenge.ChallengeType>();

            challengeTypes = new List<MyChallenge.ChallengeType>((MyChallenge.ChallengeType[])Enum.GetValues(typeof(MyChallenge.ChallengeType)));

            TutorialSystem.Instance.onComplete += OnTutorialCompleteHandler;
            MyInfo.Challenge.onChange += OnChallengeChange;

            root.SetActive(false);

            UpdateCurrentChallenge();
            UpdateCompletedList();
        }

        public void LevelUp(long bonus)
        {
            bonusCoin = bonus;

            if (needUpdate == true)
            {
                needUpdate = false;
                UpdateChallenge();
            }
        }

        public bool IsDone()
        {
            return needUpdate;
        }

        public bool IsBusy()
        {
            return challengeCoroutine != null;
        }

        private void OnTutorialCompleteHandler(TutorialChapter chapter)
        {
            if (chapter == TutorialChapter.PlaySlot)
            {
                UpdateCurrentChallenge();
                revealSound.Play();
            }
        }

        private void OnChallengeChange(MyChallenge.ChallengeType challengeType, MyChallenge.State state)
        {
            if (state == MyChallenge.State.CompleteEnd)
            {
                return;
            }

            needUpdate = true;
            challengeQueue.Enqueue(new ChallengeInfo(challengeType, state));
        }

        private void UpdateCurrentChallenge()
        {
            var currentChallenge = MyInfo.Challenge.GetCurrentChallenge();
            if (currentChallenge != MyChallenge.ChallengeType.None)
            {
                var state = MyInfo.Challenge.GetState(currentChallenge);
                if (state != MyChallenge.State.CompleteNow)
                {
                    challengeQueue.Enqueue(new ChallengeInfo(currentChallenge, state));
                    UpdateChallenge();
                }
            }
            else
            {
                root.SetActive(false);
            }
        }

        private void UpdateCompletedList()
        {
            foreach (MyChallenge.ChallengeType item in challengeTypes)
            {
                var state = MyInfo.Challenge.GetState(item);
                if (state == MyChallenge.State.Completed || state == MyChallenge.State.CompleteNow || state == MyChallenge.State.CompleteEnd)
                {
                    if (completedList.Contains(item) == false)
                    {
                        completedList.Add(item);
                    }
                }
            }
        }

        private void UpdateChallenge()
        {
            if (MyInfo.Tutorial.IsComplete(TutorialChapter.PlaySlot) == false)
            {
                root.SetActive(false);
                return;
            }

            if (challengeCoroutine == null)
            {
                challengeCoroutine = StartCoroutine("UpdateChallengeCoroutine");
            }
        }

        public bool IsChallengeComplete(MyChallenge.ChallengeType challengeType)
        {
            return completedList.Contains(challengeType);
        }

        private IEnumerator UpdateChallengeCoroutine()
        {
            while (challengeQueue.Count > 0)
            {
                var info = challengeQueue.Dequeue();

                if (info.state == MyChallenge.State.Disable || info.state == MyChallenge.State.Completed)
                {
                    continue;
                }
                else
                {
                    if (root.activeInHierarchy == false)
                    {
                        root.SetActive(true);
                        rootAnimator.SetTrigger("On");
                    }

                    if (isExtand == false)
                    {
                        Expand(true);
                        yield return new WaitForSeconds(expandDelay);
                    }

                    foreach (var challengeItem in challengeContents)
                    {
                        var isActive = challengeItem.challenge == info.challenge;

                        if (isActive)
                        {
                            var levelText = MyInfo.Challenge.GetLevel(challengeItem.challenge).ToString();
                            challengeItem.lockText.text = levelText;
                            challengeItem.unlockText.text = levelText;
                        }

                        foreach (var contentItem in challengeItem.contents)
                        {
                            contentItem.SetActive(isActive);
                        }
                    }

                    if (info.state == MyChallenge.State.CompleteNow)
                    {
                        contentAnimator.SetTrigger("Levelup");
                        characterAnimator.SetTrigger("Levelup");

                        var slotMachine = FindObjectOfType<SlotMachine>();
                        slotMachine.pauseStateTransition = true;

                        yield return new WaitForSeconds(completeDelay);

                        slotMachine.ReelGroup.PauseSpins = true;

                        if (MyInfo.Challenge.RewardCoin > 0)
                        {
                            yield return Popups.GameChallengeComplete(info.challenge)
                                               .Async()
                                               .WaitForClose();

                            CollectRewardCoin(MyInfo.Challenge.RewardCoin);
                        }

                        if (info.challenge == MyChallenge.ChallengeType.Booster)
                        {
                            yield return BoosterComplete();
                        }
                        else if (info.challenge == MyChallenge.ChallengeType.Sea)
                        {
                            yield return UnlockSeaComplete();
                        }

                        characterAnimator.SetTrigger("Close");
                        Expand(false);

                        yield return new WaitForSeconds(expandDelay);

                        slotMachine.ReelGroup.PauseSpins = false;
                        slotMachine.pauseStateTransition = false;

                        UpdateCompletedList();

                        OnChallengeComplete?.Invoke(info.challenge);
                        MyInfo.Challenge.SetState(info.challenge, MyChallenge.State.CompleteEnd);
                    }
                }
            }

            bool isCloseAll = true;
            foreach (MyChallenge.ChallengeType challenge in challengeTypes)
            {
                if (MyInfo.Challenge.GetState(challenge) == MyChallenge.State.Enable)
                {
                    isCloseAll = false;
                    break;
                }
            }

            if (isCloseAll == true)
            {
                rootAnimator.SetTrigger("Off");
                yield return new WaitForSeconds(hideDelay);
                root.SetActive(false);
            }

            challengeCoroutine = null;
        }

        private void CollectRewardCoin(long reward)
        {
            if(reward <= 0 )
            {
                return;
            }

            var startPos = boosterEffectContainer.position;
            var endPos = topUI.GetCoinIconPosition();

            EffectSystem.Instance.Coin(count: 20,
                                       startPosition: startPos,
                                       endPosition: endPos,
                                       scaleTarget: topUI.GetCoinIcon(),
                                       onComplete: null,
                                       onFirstCoinArrived: () =>
                                       {
                                           MyInfo.Coin += reward;
                                       },
                                       onCoinArrived: () =>
                                       {
                                           topUI.CoinIconAnimation();
                                       });
        }

        private IEnumerator UnlockSeaComplete()
        {
            var gameUI = FindObjectOfType<GameUI>();
            var slotMachine = FindObjectOfType<SlotMachine>();
            var slotID = slotMachine.Info.ID;
            var totalBet = slotMachine.Info.CurrentTotalBet;
            var autoSpinCount = slotMachine.MachineUI.IsAutoSpin ? slotMachine.MachineUI.AutoSpinCount : 0;

            if (MyInfo.Tutorial.backToSlotAfterSwimmerTuto)
            {
                MyInfo.SlotGame.SetSlotPlayInfo(slotID, totalBet, autoSpinCount);
            }

            UndercGameLog.Fobis.TutorialSeaStep(10);

            yield return Popups.UnlockSea()
                               .Async()
                               .WaitForClose();

            UndercGameLog.Fobis.TutorialSeaStep(20);

            yield return Popups.BackToLobby()
                               .Async()
                               .WaitForClose();
        }

        private IEnumerator BoosterComplete()
        {
            yield return PlayProjectileBoosterEffect();

            // userCore 호출해서 부스터 정보 갱신하기 (4레벨 달성시 서버에서 부스터가 활성화 되어있음)
            var req = NetworkSystem.HTTPRequester.UserCore();
            yield return req.WaitForResponse();

            if (req.data.isSuccess == true && req.data.ret == 0)
            {
                MyInfo.Booster.Update(req.data.user);
                yield return Popups.Booster()
                                   .Async()
                                   .WaitForClose();
            }
        }

        private IEnumerator PlayProjectileBoosterEffect()
        {
            boosterCompleteEffect.SetActive(false);
            boosterCompleteEffect.SetActive(true);

            var targetPos = topUI.GetSecondaryCurrenciesPosition();

            boosterProjectileEffect.transform.localPosition = Vector2.zero;
            boosterProjectileEffect.gameObject.SetActive(true);
            boosterProjectileEffect.duration = boosterEffectDelay;
            boosterProjectileEffect.Move(targetPos);

            yield return new WaitForSeconds(boosterEffectDelay);

            boosterProjectileEffect.gameObject.SetActive(false);

            boosterExplosionEffect.transform.position = targetPos;
            boosterExplosionEffect.SetActive(true);

            boosterCompleteEffect.SetActive(false);
        }

        public void OnClickHandler()
        {
            if (challengeCoroutine != null)
            {
                return;
            }

            Expand(!isExtand);
        }

        public void Expand(bool value)
        {
            isExtand = value;
            string trigger = value == true ? "Open" : "Close";
            frameAnimator.SetTrigger(trigger);

            if (value == true)
            {
                contentAnimator.SetTrigger("Open");
            }
        }

        public void Show(bool animation)
        {
            cachedTransform.DOKill(false);

            if (animation == true)
            {
                cachedTransform.DOAnchorPosX(0.0f, 0.5f).SetEase(Ease.OutQuint);
            }
            else
            {
                cachedTransform.anchoredPosition = Vector3.zero;
            }
        }

        public void Hide(bool animation)
        {
            cachedTransform.DOKill(false);

            if (animation == true)
            {
                cachedTransform.DOAnchorPosX(hidePosX, 0.5f).SetEase(Ease.OutQuint);
            }
            else
            {
                var tempPos = cachedTransform.anchoredPosition;
                tempPos.x = hidePosX;
                cachedTransform.anchoredPosition = tempPos;
            }
        }
    }
}