using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using SlotGame.UI;
using SlotGame.Machine;
using Gaga.Attribute;

namespace Underc.Game
{
    public sealed class BetNoticePanel : MonoBehaviour 
    {
        private enum State
        {
            None,
            LevelLock,
            CoinLock,
            Unlock,
            UnlockAll
        }

        #pragma warning disable 0649
        [Separator("Bet Notice")]
        public float showTime = 4.0f;
        [SerializeField] private GameObject root;
        [SerializeField] private Animator animator;
        public Vector2 rootOffset;

        [SerializeField] private Text levelText;
        [SerializeField] private GameObject levelLockRoot;
        [SerializeField] private GameObject coinLockRoot;
        [SerializeField] private GameObject unlockRoot;
        [SerializeField] private GameObject unlockAllRoot;

        [Space]
        [Separator("Effect")]
        [SerializeField] private GameObject betUpEffect;

        #pragma warning restore 0649

        private Coroutine coroutine;
        private State currentState;
        private SlotMachine slotMachine;
        private BottomUI bottomUI;
        private Coroutine betUpEffectCoroutine;

        private void Awake()
        {
            currentState = State.None;

            StopAnimation();
            HideBetUpEffect();
        }

        private void PlayAnimation()
        {
            BottomUI bottomUI = GetBottomUI();

            root.SetActive(true);
            var targetPos = transform.InverseTransformPoint(bottomUI.GetBetUpButtonPosition());
            root.transform.localPosition = new Vector2(targetPos.x, targetPos.y) + rootOffset;

            animator.SetTrigger("Play");
        }

        private void StopAnimation()
        {
            root.SetActive(false);

            if (coroutine != null)
            {
                StopCoroutine(coroutine);
            }

            coroutine = null;

            HideBetUpEffect();
        }

        public void ShowLevelLock(int level)
        {
            levelText.text = level.ToString();
            Show(State.LevelLock, showTime);
        }

        public void ShowCoinLock()
        {
            Show(State.CoinLock, showTime);
        }

        public void ShowUnlock()
        {
            Show(State.Unlock, showTime);
        }

        public void ShowUnlockAll()
        {
            Show(State.UnlockAll, showTime);
        }

        private void Show(State state, float showTime)
        {
            if (coroutine != null && currentState == state)
            {
                return;
            }

            StopAnimation();

            currentState = state;
            coroutine = StartCoroutine(ShowCoroutine(state, showTime));
        }

        private IEnumerator ShowCoroutine(State state, float showTime)
        {
            if (state == State.LevelLock)
            {
                SetActiveOnly(levelLockRoot);
            }
            else if (state == State.CoinLock)
            {
                SetActiveOnly(coinLockRoot);
            }
            else if (state == State.Unlock)
            {
                SetActiveOnly(unlockRoot);
                ShowBetUpEffect();
            }
            else
            {
                SetActiveOnly(unlockAllRoot);
            }

            PlayAnimation();

            yield return new WaitForSeconds(showTime);

            StopAnimation();
        }

        private void SetActiveOnly(GameObject obj)
        {
            levelLockRoot.SetActive(obj == levelLockRoot);
            unlockRoot.SetActive(obj == unlockRoot);
            unlockAllRoot.SetActive(obj == unlockAllRoot);
            coinLockRoot.SetActive(obj == coinLockRoot);
        }

        private void ShowBetUpEffect()
        {
            HideBetUpEffect();

            betUpEffectCoroutine = StartCoroutine(ShowBetUpEffectCoroutine());
        }

        private IEnumerator ShowBetUpEffectCoroutine()
        {
            BottomUI bottomUI = GetBottomUI();
            SlotMachine slotMachine = GetSlotMachine();

            if (bottomUI == null || slotMachine == null)
            {
                yield break;
            }

            yield return null;

            if (bottomUI.IsBetUpButtonActivated() == false)
            {
                yield break;
            }

            betUpEffect.SetActive(true);

            var betUpEffectTr = betUpEffect.transform;
            var startTotalBet = slotMachine.Info.CurrentTotalBet;

            while (true)
            {
                betUpEffectTr.position = bottomUI.GetBetUpButtonPosition();

                // 현재 토탈벳이 시작시 토탈벳보다 크면 즉 유저가 토탈벳을 상향하면
                // 이펙트를 종료한다.
                if (slotMachine.Info.CurrentTotalBet > startTotalBet)
                {
                    HideBetUpEffect();
                    yield break;
                }

                yield return null;
            }
        }

        private void HideBetUpEffect()
        {
            if (betUpEffectCoroutine != null)
            {
                StopCoroutine(betUpEffectCoroutine);
                betUpEffectCoroutine = null;
            }

            betUpEffect.SetActive(false);
        }

        private SlotMachine GetSlotMachine()
        {
            if (slotMachine == null)
            {
                slotMachine = FindObjectOfType<SlotMachine>();
            }

            return slotMachine;
        }

        private BottomUI GetBottomUI()
        {
            if (bottomUI == null)
            {
                bottomUI = FindObjectOfType<BottomUI>();
            }

            return bottomUI;
        }
    }
}