using DG.Tweening;
using Gaga.Sound;
using UnityEngine;

namespace Underc.Game
{
    public sealed class FishPot : MonoBehaviour
    {
        [SerializeField] private Transform content;
        [SerializeField] private Transform icon;
        [SerializeField] private Vector2 collectOffset;
        [SerializeField] private SoundPlayer collectSFX;

        [Space]
        [SerializeField] private GameObject newBadge;
        [SerializeField] private GameObject prizeBadge;

        public float moveDistance = 2.5f;
        public float showDuration = 0.3f;
        public AnimationCurve showEase;
        public float hideDelay = 0.5f;
        public float hideDuration = 0.3f;
        public AnimationCurve hideEase;

        private int showCount;
        private Transform rootTransform;
        private float defaultContentLocalPosX;

        private void Awake()
        {
            rootTransform = transform;

            HideBadge();
        }

        private void Start()
        {
            defaultContentLocalPosX = content.localPosition.x;
            content.localPosition = new Vector3(defaultContentLocalPosX + moveDistance, content.localPosition.y, 0.0f);
            content.gameObject.SetActive(false);
        }

        public void Show(float delay = 0.0f)
        {
            HideBadge();

            showCount++;

            if (showCount == 1)
            {
                content.DOKill(false);
                content.gameObject.SetActive(true);
                content.DOLocalMoveX(defaultContentLocalPosX, showDuration)
                       .SetDelay(delay)
                       .SetEase(showEase);
            }
        }

        public void Hide()
        {
            showCount--;

            if (showCount <= 0)
            {
                content.DOKill(false);
                content.DOLocalMoveX(defaultContentLocalPosX + moveDistance, hideDuration)
                       .SetDelay(hideDelay)
                       .SetEase(hideEase)
                       .OnComplete(() =>
                       {
                           content.gameObject.SetActive(false);
                       });
            }
        }

        public void ShowBadge(bool isNew, bool isPrize)
        {
            newBadge.SetActive(isNew);
            prizeBadge.SetActive(isPrize);
        }

        public void HideBadge()
        {
            newBadge.SetActive(false);
            prizeBadge.SetActive(false);
        }

        public void CollectAnimation()
        {
            icon.DOKill(true);
            icon.DOScale(new Vector3(1.5f, 1.5f, 1.0f), 0.3f).SetEase(Ease.OutBack).From();

            collectSFX.Play();
        }

        public Vector2 GetCollectPosition()
        {
            return  new Vector2(rootTransform.position.x, rootTransform.position.y) + collectOffset;
        }
    }
}