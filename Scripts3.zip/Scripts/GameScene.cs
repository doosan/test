using SlotGame.Machine;
using UnityEngine;
using Gaga.AssetBundle;
using SlotGame.Util;
using Underc.Scene;
using System.Collections.Generic;
using SlotGame;
using Underc.Net;
using Gaga.Popup;
using Gaga.System;
using System.Globalization;

#if GGDEV
using Gaga.DeveloperTools;
using SlotGame.DeveloperTools;
#endif

namespace Underc.Game
{
    public sealed class GameScene : BaseScene
    {
        private readonly string PROP_SHOW_UI = "show_ui";

        private readonly string TESTACTION_HOLD_AUTO_ID           = "slot_hold_mode_auto";
        private readonly string TESTACTION_HOLD_OFF_ID            = "slot_hold_mode_off";

        #pragma warning disable 0649
        [SerializeField] private GameManager gameManager;
        [SerializeField] private GameUI gameUI;
        [SerializeField] private float otherTypeUIShowDelay = 0.4f;
        #pragma warning restore 0649

        private SlotMachine slotMachinePrefab;
        private SlotMachine slotMachine;

        private Gaga.AssetBundle.AssetBundle commonAssetBundle;
        private Gaga.AssetBundle.AssetBundle slotAssetBundle;

        private string slotID;
        private EnterData enterData;
        private BetData betData;
        private int continueAutospinCount;

        private Dictionary<string, string> properties;
        private Dictionary<int, ScreenSystem.Orientation> lastOrientations;

        private SlotPreset slotPreset;

        private void Awake()
        { 
            ScreenSystem.Instance.SetFrameRate(AppConfig.TARGET_FRAME_SLOT);

            SetupParameters();
            SetupAssetBundles();
            SetupSlotPreset();

            if (commonAssetBundle == null || slotAssetBundle == null)
            {
                SceneSystem.LoadLobby(SceneSystem.LOBBY_STATE_INDEX_GAME);
                return;
            }

            SetupProperties(slotPreset);
            SetupSlotMachine();
            SetupUI(commonAssetBundle);

            #if GGDEV && GGDEV_SLOT
            AddDeveloperTools();
            #endif
        }

        private void Start()
        {
            SetupSlotGame();

            lastOrientations = new Dictionary<int, ScreenSystem.Orientation>();
            PopupSystem.Instance.onPopupOpen += OnPopupOpen;
            PopupSystem.Instance.onPopupClose += OnPopupStartClosing;
        }

        protected override void OnDestroy()
        {
            base.OnDestroy();

            AssetBundleSystem.Instance.Unload(AssetBundleName.COMMON);
            AssetBundleSystem.Instance.Unload(AssetBundleName.Slot(slotID));

            PopupSystem.Instance.onPopupOpen -= OnPopupOpen;
            PopupSystem.Instance.onPopupClose -= OnPopupStartClosing;

            #if GGDEV && GGDEV_SLOT
            RemoveDeveloperTools();
            RemoveTestActions();
            #endif
        }

        private void SetupParameters()
        {
            if (parameters.Count <= 0)
            {
                return;
            }
            
            slotID = parameters[0].ToString();
            enterData = parameters[1] as EnterData;
            betData = parameters[2] as BetData;

            slotMachinePrefab = parameters[4] as SlotMachine;

            continueAutospinCount = (int)parameters[5];
        }

        private void SetupProperties(SlotPreset slotPreset)
        {
            properties = new Dictionary<string, string>();

            if (slotPreset != null)
            {
                if (slotPreset.general.properties != null && slotPreset.general.properties.Length > 0)
                {
                    var slotProps = slotPreset.general.properties.Split(',');
                    foreach (var item in slotProps)
                    {
                        var keyVal = item.Split('=');
                        var key = keyVal[0];
                        var val = keyVal[1];

                        if (properties.ContainsKey(key) == false)
                        {
                            properties.Add(key, val);
                        }
                    }
                }
            }
        }

        private void SetupAssetBundles()
        {
            commonAssetBundle = AssetBundleSystem.Instance.GetLoadedAssetBundle(AssetBundleName.COMMON); 
            slotAssetBundle = AssetBundleSystem.Instance.GetLoadedAssetBundle(AssetBundleName.Slot(slotID));
        }

        private void SetupSlotPreset()
        {
            if (slotAssetBundle != null)
            {
                slotPreset = slotAssetBundle.GetAsset<SlotPreset>(typeof(SlotPreset).Name);
            }
        }

        private void SetupSlotGame()
        {
            gameManager.Initialize(enterData, betData, commonAssetBundle, slotMachine, gameUI, continueAutospinCount);
        }

        private void SetupUI(Gaga.AssetBundle.AssetBundle commonAssetBundle)
        {
            gameUI.Initialize(gameObject, commonAssetBundle);
            ShowUI();
        }

        private void ShowUI()
        {
            if (properties.ContainsKey(PROP_SHOW_UI) == true)
            {
                float delay = float.Parse(properties[PROP_SHOW_UI], CultureInfo.InvariantCulture);

                gameUI.Hide(SlotMachine.OutsideUIType.All, false);
                gameUI.Show(SlotMachine.OutsideUIType.All, true, delay);
            }
            else
            {
                gameUI.Hide(SlotMachine.OutsideUIType.Side, false);
                gameUI.Show(SlotMachine.OutsideUIType.Side, true, otherTypeUIShowDelay);
            }
        }

        private void SetupSlotMachine()
        {
            if (slotMachinePrefab != null)
            {
                slotMachine = Instantiate(slotMachinePrefab.gameObject).GetComponent<SlotMachine>();
                slotMachine.transform.SetParent(gameManager.transform, false);

                slotMachine.OnShare.AddListener(OnShareHandler);

                #if GGDEV && GGDEV_SLOT
                AddTestActions(slotMachine);
                #endif
            }
        }

        private void OnShareHandler()
        {
            if (slotMachine.CurrentState == SlotMachineState.HIT_BIGWIN)
            {
                UndercGameLog.Fobis.ButtonSlot(4);
            }
            
            if (slotMachine.CurrentState == SlotMachineState.HIT_JACKPOT)
            {
                UndercGameLog.Fobis.ButtonSlot(5);
            }

            Underc.Util.ScreenshotSystem.Instance.TakeAndShare();
        }

        public override bool CanBack()
        {
            if ( gameUI.TopUI.InteratableHomeButton == false )
            {
                return false;
            }
            else if ( PopupSystem.Instance.Count > 0 )
            {
                return false;
            }

            return base.CanBack();
        }

        public override void GoBack()
        {
            base.GoBack();

            gameUI.GoLobby();            
        }


        private void OnPopupOpen(PopupBehaviour popup)
        {
            var popupOrientation = popup.orientation == PopupOrientationType.LandscapeOnly ? ScreenSystem.Orientation.Landscape :
                                   popup.orientation == PopupOrientationType.PortraitOnly ? ScreenSystem.Orientation.Portrait :
                                   ScreenSystem.Orientation.None;

            var currentOrientation = ScreenSystem.Instance.CurrentOrienation;
            if (popupOrientation != currentOrientation)
            {
                // 해당 팝업이 닫힐 때 돌아갈 회전 방향을 남김
                lastOrientations[popup.GetHashCode()] = currentOrientation;
                if (popupOrientation == ScreenSystem.Orientation.Landscape)
                {
                    ScreenSystem.Instance.SetLandscape();
                }
                else if (popupOrientation == ScreenSystem.Orientation.Portrait)
                {
                    ScreenSystem.Instance.SetPortrait();
                }
            }
        }

        private void OnPopupStartClosing(PopupBehaviour popup)
        {
            if (popup.orientation == PopupOrientationType.LandscapeOnly
                || popup.orientation == PopupOrientationType.PortraitOnly)
            {
                ScreenSystem.Orientation lastOrientation = ConsumeLastOrientation(popup);
                if (lastOrientation == ScreenSystem.Orientation.Portrait)
                {
                    ScreenSystem.Instance.SetPortrait();
                }
                else if (lastOrientation == ScreenSystem.Orientation.Landscape)
                {
                    ScreenSystem.Instance.SetLandscape();
                }
            }
        }

        private ScreenSystem.Orientation ConsumeLastOrientation(PopupBehaviour popup)
        {
            ScreenSystem.Orientation lastOrientation = ScreenSystem.Orientation.None;

            int orientationKey = popup.GetHashCode();
            if (lastOrientations.ContainsKey(orientationKey))
            {
                lastOrientation = lastOrientations[orientationKey];

                lastOrientations.Remove(orientationKey);
            }

            return lastOrientation;
        }

        #if GGDEV && GGDEV_SLOT
        private void AddDeveloperTools()
        {
            DeveloperTools.Instance.AddSeparator("sepa_game1");
            DeveloperTools.Instance.AddContentsItem("syms", "Syms", Instantiate(Resources.Load("SymbolsContents") as GameObject).GetComponent<SymbolsContents>(), DeveloperToolsIcon.IconType.Symbol);
            DeveloperTools.Instance.AddContentsItem("cheat", "Cheat", Instantiate(Resources.Load("CheatContents") as GameObject).GetComponent<CheatContents>(), DeveloperToolsIcon.IconType.Star);

            DeveloperTools.Instance.AddSeparator("sepa_game2");
            DeveloperTools.Instance.AddActionItem("exit", "Exit", ()=>
            {
                NetworkSystem.HTTPRequester.GameClear(slotID);
                gameUI.GoLobby();
            }, DeveloperToolsIcon.IconType.Exit);
        }

        private void RemoveDeveloperTools()
        {
            DeveloperTools.Instance.RemoveItem("syms");
            DeveloperTools.Instance.RemoveItem("cheat");
            DeveloperTools.Instance.RemoveItem("exit");
            DeveloperTools.Instance.RemoveItem("sepa_game1");
            DeveloperTools.Instance.RemoveItem("sepa_game2");
        }

        private void AddTestActions(SlotMachine slotMachine)
        {
            TestActionInfo holdModeAutoInfo = new TestActionInfo(TESTACTION_HOLD_AUTO_ID, "Hold Mode", "Auto (Aquuua)", "", new UnityEngine.Events.UnityEvent());
            holdModeAutoInfo.Action.AddListener(()=>
            {
                slotMachine.holdType = SlotMachine.HoldType.Auto;
            });

            TestActionInfo holdModeOffInfo = new TestActionInfo(TESTACTION_HOLD_OFF_ID, "Hold Mode", "Off (Winjoy)", "", new UnityEngine.Events.UnityEvent());
            holdModeOffInfo.Action.AddListener(()=>
            {
                slotMachine.holdType = SlotMachine.HoldType.Off;
            });

            TestActionSystem.Instance.Add(holdModeAutoInfo);
            TestActionSystem.Instance.Add(holdModeOffInfo);
        }

        private void RemoveTestActions()
        {
            TestActionSystem.Instance.Remove(TESTACTION_HOLD_AUTO_ID);
            TestActionSystem.Instance.Remove(TESTACTION_HOLD_OFF_ID);
        }
        #endif
    }
}