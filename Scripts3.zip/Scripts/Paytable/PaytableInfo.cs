using UnityEngine;
using System;

namespace Underc.Game
{
	[CreateAssetMenu(fileName="PaytableInfo", menuName="Underc/Paytable/Paytable Info")]
	public class PaytableInfo : ScriptableObject
	{
        [Serializable]
        public class Item
        {
            public string title;
            public Sprite texure;
        }

        #pragma warning disable 0649
		[SerializeField] private Item[] items;
        public Item[] Items{get{return items;}}
        #pragma warning restore 0649
	}
}
