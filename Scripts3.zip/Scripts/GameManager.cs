using System;
using System.Collections;
using SlotGame.DeveloperTools;
using SlotGame.Machine;
using Underc.Net;
using Underc.Net.Client;
using Underc.Popup;
using Underc.Tutorial;
using Underc.User;
using UnityEngine;

namespace Underc.Game
{
    public sealed class GameManager : MonoBehaviour
    {
        private readonly string WARNING_MSG_NETWORK = "Please move to the lobby\nand select a slot again.";

        private SlotMachine slotMachine;
        private bool enalbleBetRequest;
        private bool enableSpinRequset;
        private string slotID;
        private GameUI gameUI;
        private GameSpinResponse latestSpinResp;
        private bool isLevelUp;
        private bool isFirstIdleState;

        // 게임진입시 유저 가입일 수
        private int playDays;
        private bool enableLeaveRequest;
        private int[] betExtendLevels;

        public GameUI GameUI { get => gameUI; }

        public void Initialize(EnterData enterData, BetData betData, Gaga.AssetBundle.AssetBundle ab, SlotMachine slotMachine, GameUI gameUI, int startAutoSpinCount)
        {
            this.gameUI = gameUI;
            this.slotMachine = slotMachine;

            enableLeaveRequest = true;
            betExtendLevels = enterData.bet_extend_levels;

            slotID = enterData.slotid;

            SetupSlotMachine(slotMachine, gameUI.BottomUI, enterData, betData, ab);
            SetupUI(slotMachine, enterData, betData, startAutoSpinCount);

            MyInfo.OnCoinsChanged += OnCoinChangedHandler;
            MyInfo.Settings.onVibrate += OnVibrate;

            playDays = MyInfo.PlayDays;

            isFirstIdleState = true;
            StartCoroutine(ObserveDeepLinkCoroutine());
        }

        private void OnDestroy()
        {
            MyInfo.DailyMission.DisplayInfo?.ConsumeRewardInProgress();

            MyInfo.OnCoinsChanged -= OnCoinChangedHandler;
            MyInfo.Settings.onVibrate -= OnVibrate;

            AdminNoticeSystem.Instance.ExitSlot();
            LeaveRequest();
        }

        private void OnApplicationQuit() 
        {
            Debug.Log("OnApplicationQuit - ingame");

            LeaveRequest();
        }

        private void SetupSlotMachine(SlotMachine slotMachine, RectTransform uiContainer, EnterData enterData, BetData betData, Gaga.AssetBundle.AssetBundle ab)
        {
            slotMachine.OnAutoSpin.AddListener(OnAutoSpinHandler);
            slotMachine.OnStateChange.AddListener(OnStateStartHandler);
            slotMachine.OnPayCoins.AddListener(OnPayCoinsHandler);
            slotMachine.OnEarnCoins.AddListener(OnEarnCoinsHandler);
            slotMachine.OnEarnPearls.AddListener(OnEarnPearlsHandler);
            slotMachine.OnEarnTickets.AddListener(OnEarnTicketsHandler);
            slotMachine.OnMoreCoins.AddListener(OnMoreCoinsHander);
            slotMachine.OnChoice.AddListener(OnChoiceHandler);
            slotMachine.OnUiActive.AddListener(OnUiActiveHandler);
            slotMachine.OnGameUiRaycast.AddListener(OnGameUiRaycastHandler);
            slotMachine.OnSpecialRequest.AddListener(OnSpecialRequestHandler);
            slotMachine.OnBigWinClosed.AddListener(OnBigwinClosed);
            slotMachine.OnJackpotClosed.AddListener(OnJackpotClosed);
            slotMachine.OnStateEnd.AddListener(OnStateEndHandler);
            slotMachine.OnTotalBetRequest.AddListener(OnTotalBetChangeHandler);
            slotMachine.OnPaytable.AddListener(OnPayTableButtonClicked);
            slotMachine.OnKenoRequest.AddListener(OnKenoSpecialRequestHandler);

            slotMachine.Initialize(enterData, betData, ab, 0, uiContainer, SlotMachine.HoldType.Auto, SlotMachine.MaxbetType.Index);
            slotMachine.SetCoins(MyInfo.Coin);

            slotMachine.useShare = true;
            slotMachine.useVibrate = MyInfo.Settings.Vibrate;
            slotMachine.Info.MaxTotalbetIndex = CalcMaxTotalBetIndex(MyInfo.Level);
        }

        private void SetupUI(SlotMachine slotMachine, EnterData enterData, BetData betData, int startAutoSpinCount)
        {
            gameUI.SetSlotMachine(slotMachine);
            gameUI.UpdateMissionIcons();
            slotMachine.MachineUI.OnMaxbet.AddListener(OnMaxBetButtonClicked);
            GameUI.TopUI.OnPayTable.AddListener(OnPayTableButtonClicked);

            if (startAutoSpinCount != 0)
            {
                slotMachine.MachineUI.OnAutoCountButtonClick(startAutoSpinCount);
            }
        }

        private void OnCoinChangedHandler(long coin)
        {
            if (slotMachine.CurrentState == SlotMachineState.IDLE)
            {
                //sync coins
                slotMachine.SetCoins(coin);
            }
        }

        private void OnVibrate(bool value)
        {
            slotMachine.useVibrate = value;
        }

        private void OnAutoSpinHandler(bool isOn)
        {
            UpdateButtons();
        }

        private void OnStateStartHandler(string state)
        {
            enalbleBetRequest = false;

            UpdateButtons();

            if (state == SlotMachineState.IDLE)
            {
                //sync coins
                slotMachine.SetCoins(MyInfo.Coin);
                slotMachine.ReelGroup.ignoreInterval = false;

                enableSpinRequset = true;
                enalbleBetRequest = true;

                if (isFirstIdleState == false && latestSpinResp != null)
                {
                    var levelData = latestSpinResp.level;
                    MyInfo.Update(levelData);
                    gameUI.UpdateSpinResult(isLevelUp, latestSpinResp);
                    isLevelUp = false;
                }

                isFirstIdleState = false;
            }
            else if (state == SlotMachineState.SPIN_START)
            {
                if (enableSpinRequset == true)
                {
                    enableSpinRequset = false;
                    SpinRequest(StopSpin);
                }
            }
            else if (state == SlotMachineState.SPIN_STOP)
            {
                if (isLevelUp)
                {
                    gameUI.SetXP(1.0f, true);
                }
                else
                {
                    var levelData = latestSpinResp.level;
                    gameUI.SetXP(levelData.xp_base, levelData.xp, levelData.next_xp, true);
                }
            }
            else if (state == SlotMachineState.SPIN_END)
            {
                // 스핀이 멈춘후 레벨업 상황에서 게임챌린지가 달성되면 게임챌린지 연출을 보여주기위해 ui 입력을 막는다.
                if (isLevelUp && gameUI.IsGameChallengeDone())
                {
                    gameUI.SetInteractable(false);
                }
            }
            else if (state == SlotMachineState.ENTER)
            {
                gameUI.SetInteractable(false);
            }
        }

        private void OnStateEndHandler(string state)
        {
            if (state == SlotMachineState.ENTER)
            {
                StartCoroutine(EnterStateEndCoroutine());
            }
        }

        private IEnumerator EnterStateEndCoroutine()
        {
            yield return CheckSlotNotice();

            yield return CheckBoosterAdded();

            yield return CheckVipOpen();
            yield return CheckMissionPassOpen();

            yield return gameUI.CheckReward(delay: .1f);

            gameUI.SetInteractable(true);
        }

        private IEnumerator CheckVipOpen()
        {
            // 공지 팝업을 통한 슬롯 이동으로 VIP 오픈 팝업을 보지 못한 유저
            if (TutorialSystem.Instance.IsInPlay == false
                && VipOpenPopup.IsOpened == false)
            {
                slotMachine.Pause();

                yield return Popups.VipOpenCoroutine();

                slotMachine.Resume();
            }

            yield break;
        }

        private IEnumerator CheckMissionPassOpen()
        {
            // 공지 팝업을 통한 슬롯 이동으로 데일리 퀘스트 언락 팝업을 보지 못한 유저
            if (TutorialSystem.Instance.IsInPlay == false
                && MyInfo.DailyMission.DisplayInfo.ConsumeJustUnlockState())
            {
                slotMachine.Pause();

                yield return gameUI.ShowMissionPassOpen();

                slotMachine.Resume();
            }

            yield break;
        }

        private IEnumerator CheckSlotNotice()
        {
            if (TutorialSystem.Instance.IsInPlay == false &&
                AdminNoticeSystem.Instance.HasData == true)
            {
                slotMachine.Pause();
                
                AdminNoticeSystem.Instance.ShowSlotNotice(() =>
                {
                    slotMachine.Resume();
                });
            }

            while (slotMachine.pauseStateTransition)
            {
                yield return null;
            }
            yield break;
        }

        private IEnumerator CheckBoosterAdded()
        {
            if (TutorialSystem.Instance.IsInPlay == false &&
                MyInfo.Booster.SecondaryCurrenciesAddedSec > 0)
            {
                slotMachine.Pause();

                NetworkSystem.HTTPRequester.UserCore(resp =>
                {
                    if (resp.isSuccess == true && resp.ret == 0)
                    {
                        MyInfo.Booster.Update(resp.user);

                        MyInfo.Booster.ConsumeSecondaryCurrenciesAddedSec();

                        Popups.Booster(onComplete: () =>
                                       {
                                           slotMachine.Resume();
                                       })
                              .Async();
                    }
                    else
                    {
                        slotMachine.Resume();
                    }
                });
            }

            while (slotMachine.pauseStateTransition)
            {
                yield return null;
            }
            yield break;
        }

        private void OnSpinStartHandler()
        {
            slotMachine.StartSpin();
        }

        private void OnTotalBetChangeHandler(long totalBet)
        {
            if (enalbleBetRequest == false 
                || slotMachine.AutoSpin == true)
            {
                return;
            }

            var currentTotalBet = slotMachine.Info.CurrentTotalBet;

            if (currentTotalBet < totalBet)
            {
                UndercGameLog.Fobis.ButtonSlot(6);
            }
            else if (currentTotalBet > totalBet)
            {
                UndercGameLog.Fobis.ButtonSlot(7);
            }

            BetRequest(totalBet);
        }

        private void OnPrevTotalBetHandler()
        {
            if (enalbleBetRequest == false 
                || slotMachine.IsFirstTotalBet() == true 
                || slotMachine.AutoSpin == true)
            {
                return;
            }

            long prevTotalBet = slotMachine.GetPrevTotalBet();
            BetRequest(prevTotalBet);
        }

        private void BetRequest(long totalBet, Action onComplete = null)
        {
            enalbleBetRequest = false;

            NetworkSystem.HTTPRequester.GameBet(slotID, totalBet, resp=>
            {
                if (resp.isSuccess == true && resp.ret == 0)
                {
                    if (slotMachine.CurrentState == SlotMachineState.IDLE)
                    {
                        enalbleBetRequest = true;
                    }

                    var betData = resp.data;

                    slotMachine.SetBet(betData);

                    if (betData.unlock_level > 0)
                    {
                        gameUI.BetNotice.ShowLevelLock(betData.unlock_level);
                    }
                }
                else
                {
                    OpenWarningPopup(WARNING_MSG_NETWORK, WarningPopup.ActionType.Lobby, resp.error);
                }

                onComplete?.Invoke();
            });
        }

        private void OnFastSpinValueChangeHandler(bool isOn)
        {
            slotMachine.FastSpin = isOn;
        }

        public void OnPayTableButtonClicked()
        {
            UndercGameLog.Fobis.ButtonSlot(11);

            Popups.Paytable(slotID).Async();
        }

        private void OnMoreCoinsHander()
        {
            StartCoroutine(MoreCoin());
        }

        private IEnumerator MoreCoin()
        {
            //올인 되었을 때 오퍼 팝업이 있으면 노출한다.
            //오퍼를 노출 하지 않았다면 치어 보너스 1회 지급한다.
            //오퍼구매를 하지 않고 보너스도 못받았다면 상점을 연다

            SendSingularLogAtFirstAllIn();
            UndercGameLog.Fobis.SlotAllIn(slotMachine.GetCurrentTotalBet());

            slotMachine.Pause();

            var offerReq = OfferSystem.Instance.OpenAllin();
            yield return offerReq;

            if (offerReq.Purchased == false)
            {
                yield return Popups.Shop()
                                   .Async()
                                   .Cache()
                                   .WaitForClose();
            }

            slotMachine.Resume();
            yield break;
        }

        private void OnChoiceHandler(int index)
        {
            ChoiceRequest(index, Choice);
        }

        private void OnPayCoinsHandler(long coins)
        {
            MyInfo.Coin -= coins;
        }

        private void OnEarnCoinsHandler(long coins)
        {
            MyInfo.Coin += coins;
        }

        private void OnEarnPearlsHandler(long pearls)
        {
            MyInfo.Pearl += pearls;
        }

        private void OnEarnTicketsHandler(long tickets)
        {
            MyInfo.Ticket += tickets;
        }

        private void SpinRequest(Action<SpinData> onComplete)
        {
            isLevelUp = false;

            NetworkSystem.HTTPRequester.GameSpin(slotID, CheatInfo.symbols, CheatInfo.cheatkey, (GameSpinResponse resp) =>
            {
                if (resp.isSuccess == true && resp.ret == 0)
                {
                    latestSpinResp = resp;

                    MyInfo.spins++;
                    Debug.Log("Spins : " + MyInfo.spins);

                    MyInfo.SpinQuest.Update(resp.spin_quest);
                    MyInfo.QuestClam.Update(resp.quest_clam);
                    MyInfo.Challenge.Update(resp.challenge);
                    MyInfo.myWinNotiTimeStamp = resp.noti.ts;

                    bool rewardInProgress = resp.daily_quest.curr == resp.daily_quest.all;
                    MyInfo.DailyMission.DisplayInfo.Update(rewardInProgress);

                    isLevelUp = resp.level != null && resp.level.levelup_bonus > 0 && resp.level.current > MyInfo.Level;

                    if (isLevelUp)
                    {
                        slotMachine.Info.MaxTotalbetIndex = CalcMaxTotalBetIndex(resp.level.current);
                    }

                    MyInfo.VipClass.Update(resp.level.vip_class);
                    SendSingularLogBySpin(resp.level.current, isLevelUp, MyInfo.spins);
                   
                    // todo : 랜덤 보너스 더이상 받지 않으니 지워도 되지 않을까요?
                    var randomBonus = resp.random_bonus;
                    if (randomBonus != null || randomBonus.value > 0)
                    {
                        GameUI.RandomBonus.Collect(randomBonus, ()=>
                        {
                            onComplete(resp.data);
                        });                    
                    }
                    else
                    {
                        onComplete(resp.data);
                    }
                }
                else
                {
                    OpenWarningPopup(WARNING_MSG_NETWORK, WarningPopup.ActionType.Lobby, resp.error);
                }
            });
        }

        private void StopSpin(SpinData spinData)
        {
            slotMachine.StopSpin(spinData);
        }

        private void ChoiceRequest(int choice, Action<ChoiceData> onComplete)
        {
            NetworkSystem.HTTPRequester.GameChoice(slotID, choice, CheatInfo.cheatkey, (GameChoiceResponse resp)=>
            {
                if (resp.isSuccess == true && resp.ret == 0)
                {
                    onComplete(resp.data);

                    UpdateMissionData(resp.ts, resp.daily_quest, resp.aqua_blitz_mission);
                }
                else
                {
                    OpenWarningPopup(WARNING_MSG_NETWORK, WarningPopup.ActionType.Lobby, resp.error);
                }
            });
        }

        private void Choice(ChoiceData choiceData)
        {
            slotMachine.Choice(choiceData);
        }

        private void OnUiActiveHandler(bool isOn, SlotMachine.OutsideUIType uiType, bool animation)
        {
            if (isOn)
            {
                gameUI.Show(uiType, animation);
            }
            else
            {
                gameUI.Hide(uiType, animation);
            }
        }

        private void OnGameUiRaycastHandler(bool isOn)
        {
            gameUI.SetRaycast(isOn);
        }

        private void OnSpecialRequestHandler(string act)
        {
            slotMachine.pauseStateTransition = true;

            int currentCheat = CheatInfo.cheatkey;
            CheatInfo.cheatkey = -1;

            NetworkSystem.HTTPRequester.GameSpecial(slotID, act, currentCheat, resp =>
            {
                if (resp.isSuccess == true && resp.ret == 0)
                {
                    slotMachine.pauseStateTransition = false;

                    slotMachine.SetSpecial(resp.data);

                    UpdateMissionData(resp.ts, resp.daily_quest, resp.aqua_blitz_mission);
                }
                else
                {
                    Popups.Error(resp.error, ErrorPopup.ActionType.Lobby);
                }
            });
        }

        private void OnKenoSpecialRequestHandler(int[] extras)
        {
            NetworkSystem.HTTPRequester.KenoSpecial(slotID, extras, resp =>
            {
                if (resp.isSuccess)
                {
                    slotMachine.SetSpecial(resp.data);

                    UpdateMissionData(resp.ts, resp.daily_quest, resp.aqua_blitz_mission);
                }
                else
                {
                    Popups.Error(resp.error, ErrorPopup.ActionType.Lobby);
                }
            });
        }

        private void UpdateMissionData(long ts, DailyMissionData dailyQuest, AquaBlitzMissionSpinData aquaBlitzMission)
        {
            // special 에 의해서도 미션이 수행될 수 있다.
            MyInfo.DailyMission.Update(ts, dailyQuest);
            MyInfo.AquaBlitz.Update(checkUpdateTs: true, ts, aquaBlitzMission);
        }

        private void OnBigwinClosed(long coins, WinGrade winGrade, int jackpotGrade)
        {
            StartCoroutine(BigwinClosed(coins, winGrade, jackpotGrade));
        }

        private void OnJackpotClosed(long coins, int jackpotGrade)
        {
            StartCoroutine(BigwinClosed(coins, WinGrade.None, jackpotGrade));
        }

        private IEnumerator BigwinClosed(long coins, WinGrade winGrade, int jackpotGrade)
        {
            slotMachine.Pause();

            long winMultiplier = coins / slotMachine.Info.CurrentTotalBet;
            var offerReq = OfferSystem.Instance.OpenBigwin(winMultiplier);
            yield return offerReq;

            if (offerReq.Purchased == false && CanRateus(coins) == true)
            {
                yield return Popups.Rateus().Async().WaitForClose();
            }

            slotMachine.Resume();

            yield break;
        }

        private bool CanRateus(long coins)
        {
            return slotMachine.Info.CurrentTotalBet * 30 <= coins && RateusPopup.CanOpen == true;
        }

        private bool TryOpenPushConsent(long coins)
        {
            if (slotMachine.Info.CurrentTotalBet * 30 <= coins && IosNotiConsentPopup.CanOpen == true)
            {
                slotMachine.Pause();
                
                Popups.IosNotiConsent(() =>
                {
                    slotMachine.Resume();
                }).Async();

                return true;
            }
            else
            {
                return false;
            }
        }

        private void OpenWarningPopup(string message, WarningPopup.ActionType actionType, string error = null)
        {
            slotMachine.Pause();

            if (string.IsNullOrEmpty(error) == false )
            {
                message = string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0}\n<color=#07356F><size=20>({1})</color></size>",message,error);
            }

            Popups.Warning(message, actionType, WarningPopup.TitleType.Network, "", false).Async();
        }

        private void UpdateButtons()
        {
            bool interactable = slotMachine.CurrentState == SlotMachineState.IDLE 
                                && slotMachine.Info.IsRespin == false 
                                && slotMachine.Info.IsFreespin == false 
                                && slotMachine.AutoSpin == false;

            gameUI.TopUI.InteratableHomeButton = interactable;
            gameUI.TopUI.InteratableSettingButton = interactable;
            gameUI.TopUI.InteratableProfileButton = interactable;
        }

        private IEnumerator ObserveDeepLinkCoroutine()
        {
            var interval = new WaitForSeconds(1f);
            while (true)
            {
                if (DeepLinkReward.Fanpage.HasReward())
                {
                    yield return DeepLinkReward.Fanpage.WaitForClaim();
                }

                yield return interval;
            }
        }

        private void SendSingularLogBySpin(long level, bool isLevelUp, long spins)
        {
            if (spins == 400 && playDays == 0)
            {
                UndercGameLog.Singular.D0Spin400();
                UndercGameLog.Firebase.D0Spin400();
            }
            else if (playDays == 7 
                     && spins >= 600)
            {
                var key = "d7s600";
                bool isComplete = UndercPrefs.GetRemoteValue(key, "0") == "1";

                if (isComplete == false)
                {
                    UndercGameLog.Singular.D7Spin600();
                    UndercGameLog.Firebase.D7Spin600();
                    UndercPrefs.SetRemoteValue(key, "1");
                }
            }
                    
            if (isLevelUp)
            {
                if (level == 75)
                {
                    UndercGameLog.Singular.Lv75();
                    UndercGameLog.Firebase.Lv75();
                }
                else if (level == 100)
                {
                    UndercGameLog.Singular.Lv100();
                    UndercGameLog.Firebase.Lv100();
                }
            }
        }

        private void SendSingularLogAtFirstAllIn()
        {
            var key = "first_allin";
            bool isComplete = UndercPrefs.GetRemoteValue(key, "0") == "1";

            if (isComplete == false)
            {
                UndercGameLog.Singular.FirstAllin();
                UndercGameLog.Firebase.FirstAllin();
                UndercPrefs.SetRemoteValue(key, "1");
            }
        }

        private void LeaveRequest()
        {
            if (enableLeaveRequest == false)
            {
                return;
            }

            enableLeaveRequest = false;
            NetworkSystem.HTTPRequester.GameLeave(slotID);
        }

        private int CalcMaxTotalBetIndex(long userLevel)
        {
            int maxIndex = 0;

            for (int i = 0; i < betExtendLevels.Length; i++)
            {
                var targetLevel = betExtendLevels[i];

                if (userLevel < targetLevel)
                {
                    break;
                }

                maxIndex = i;
            }

            return maxIndex;
        }

        private void OnMaxBetButtonClicked()
        {
            if (slotMachine.Info.MaxTotalbetIndex >= slotMachine.Info.GetTotalBetCount() - 1)
            {
                var coins = slotMachine.Info.GetTotalBet(slotMachine.Info.GetTotalBetCount() - 1);
                gameUI.MaxBetNotice.Show(coins);
            }
            else
            {
                int nextLevel = 0;

                for (int i = 0; i < betExtendLevels.Length; i++)
                {
                    var targetLevel = betExtendLevels[i];

                    if (MyInfo.Level < targetLevel)
                    {
                        nextLevel = targetLevel;
                        break;
                    }
                }

                gameUI.BetNotice.ShowLevelLock(nextLevel);
            }
        }
    }
}
