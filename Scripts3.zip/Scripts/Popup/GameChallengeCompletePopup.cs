using Gaga.Popup;
using Underc.User;
using UnityEngine;
using System;
using TMPro;
using Gaga.UI;
using Gaga.Util;

namespace Underc.Popup
{
    public sealed class GameChallengeCompletePopup : PopupBehaviour
    {
        [Serializable]
        public sealed class ChallengeInfo
        {
            public MyChallenge.ChallengeType challengeType;
            public GameObject view;
        }

#pragma warning disable 0649
        [SerializeField] private ChallengeInfo[] challengeList;
        [SerializeField] private TextMeshProUGUI challengeRewardText;
#pragma warning restore 0649

        public void Initialize(MyChallenge.ChallengeType challengeType)
        {
            SetChallenge(challengeType);
            SetRewardCoin(MyInfo.Challenge.RewardCoin);
        }

        private void SetChallenge(MyChallenge.ChallengeType challengeType)
        {
            foreach (var item in challengeList)
            {
                item.view.SetActive(item.challengeType == challengeType);
            }
        }

        private void SetRewardCoin(long coin)
        {
            challengeRewardText.text = StringUtils.ToKMB(coin);
        }
    }
}