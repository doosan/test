using System;
using Gaga.Popup;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Popup
{
    public sealed class ShopGrowthPopup : PopupBackable
    {
        [SerializeField] private Text bigText;

        private Action onAction;

        public void Initialize(int percent, Action onAction)
        {
            bigText.text = ConvertPercent(percent);

            this.onAction = onAction;
        }

        private string ConvertPercent(int value)
        {
            return string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0}%", value);
        }

        public void Action()
        {
            onAction?.Invoke();

            Close();
        }
    }
}