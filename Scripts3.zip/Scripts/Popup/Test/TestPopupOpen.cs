using Underc.Popup;
using UnityEngine;

public class TestPopupOpen : MonoBehaviour
{
    [Header("TotalGrowth")]
    [SerializeField] private long level = 100;
    [SerializeField] private long bonusCoin = 1150000;
    [SerializeField] private int shop = 25;
    [SerializeField] private int daily = 50;
    [SerializeField] private int free = 75;
    [SerializeField] private int feed = 100;
    [SerializeField] private int chest = 125;
    [SerializeField] private int congrat = 150;

    [Header("ShopGrowth")]
    [SerializeField] private int percent = 111;

    public void OpenTotalGrowthPopup()
    {
        Popups.TotalGrowth(level, bonusCoin, shop, daily, free, feed, chest, congrat);
    }

    public void OpenShopGrowthPopup()
    {
        Popups.ShopGrowth(percent, null);
    }

    public void OpenDailyQuestUnlock()
    {
        Popups.DailyQuestUnlock();
    }
}
