using Gaga.Popup;
using TMPro;
using Underc.UI;
using UnityEngine;
using System.Collections;
using Underc.Scene;

namespace Underc.Popup
{
    public sealed class BackToLobbyPopup : PopupBehaviour
    {
        public float delay = 4.0f;

        [SerializeField] private TextMeshProUGUI infoText;
        [SerializeField] private GameObject loadingIndicatorRoot;

        private LoadingIndicator loadingIndicator;

        private void OnEnable()
        {
            Open();
        }

        public void Open(float delay)
        {
            CreateLoadingIndicator();
            StartCoroutine(BackToLobby(delay));
        }

        public void Open()
        {
            Open(delay);
        }

        public void Open(string info)
        {
            infoText.text = info;
            Open(delay);
        }

        public void Open(string info, float delay)
        {
            infoText.text = info;
            Open(delay);
        }

        private void CreateLoadingIndicator()
        {
            if (loadingIndicator != null)
            {
                LoadingIndicator.Return(loadingIndicator);
            }

            loadingIndicator = LoadingIndicator.Get(loadingIndicatorRoot.transform, false);
            loadingIndicator.transform.localScale = Vector3.one;
            loadingIndicator.Show();
        }

        private void DestoryLoadingIndicator()
        {
            if (loadingIndicator == null)
            {
                return;
            }

            LoadingIndicator.Return(loadingIndicator);
            loadingIndicator = null;
        }

        private IEnumerator BackToLobby(float delay)
        {
            yield return new WaitForSeconds(delay);
            DestoryLoadingIndicator();
            Close();

            SceneSystem.LoadLobby(SceneSystem.LOBBY_STATE_INDEX_MAIN);
        }
    }
}