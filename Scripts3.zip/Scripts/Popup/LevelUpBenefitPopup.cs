using Gaga.Popup;
using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using System.Linq;
using Gaga.UI;
using DG.Tweening;
using Underc.Ocean;
using Underc.User;
using TMPro;
using Underc.Scene;

namespace Underc.Popup 
{
    public sealed class LevelUpBenefitPopup : PopupBackable
    {
        private readonly string LEVEL_FORMAT = "l {0} n";

        #pragma warning disable 0649
        [SerializeField] private Transform fishRoot;
        [SerializeField] private UIDragRotator dragRotator;

        [Header("Buttons")]
        [SerializeField] private GameObject nextButtonObject;
        [SerializeField] private GameObject prevButtonObject;

        [Header("Info")]
        [SerializeField] private Text levelText;
        [SerializeField] private TextMeshProUGUI fishNameText;
        #pragma warning restore 0649

        private int pageIndex = -1;
        private int totalPage;
        private List<Benefit> benefitList;

        public void Initialize(int level, List<int> fishIdList, List<int> swimmerIdList = null)
        {
            nextButtonObject.SetActive(false);
            prevButtonObject.SetActive(false);

            if (fishIdList.Count == 0)
            {
                Close();
                return;
            }

            levelText.text = string.Format(System.Globalization.CultureInfo.InvariantCulture, LEVEL_FORMAT, level.ToString());

            var tempList = new List<Benefit>();

            for (int i = 0; i < fishIdList.Count; i++)
            {
                int fishID = fishIdList[i];
                tempList.Add(new Benefit(SeaItemType.f, fishID));
            }

            var sortResult = tempList.OrderByDescending(item => item.id)
                                     .Select(item => item);

            benefitList = new List<Benefit>();
            benefitList.AddRange(sortResult);

            totalPage = benefitList.Count;
            pageIndex = -1;

            SetPage(0);
        }

        private void SetPage(int index)
        {
            if (pageIndex == index)
            {
                return;
            }

            Benefit benefit = benefitList[index];
            pageIndex = index;

            SeaItemType fishType = benefit.type;
            int fishID = benefit.id;

            UpdateSideButtons();
            UpdateFish(fishType, fishID);
            UpdateFishName(fishType, fishID);
        }

        private void UpdateFishName(SeaItemType fishType, int fishID)
        {
            fishNameText.text = FishSystem.Instance.GetFishPreset(fishType, fishID).book.titleName;
        }

        private void UpdateFish(SeaItemType fishType, int fishID)
        {
            DestroyFish();

            var fish = FishSystem.Instance.GetFish(fishType, fishID, true);
            fish.transform.SetParent(fishRoot, false);

            var fishInfo = FishSystem.Instance.GetFishPreset(fishType, fishID);
            fishNameText.text = fishInfo.book.titleName;

            dragRotator.Target = fish.transform;
            dragRotator.ResetRotationImmediately();

            Renderer[] renderers = fish.GetComponentsInChildren<Renderer>();
            foreach(var renderer in renderers)
            {
                renderer.gameObject.layer = LayerMask.NameToLayer("S_Popup");
            }

            fishRoot.transform.DOKill(true);
            fishRoot.transform.DOScale(new Vector3(0.5f, 0.5f, 1.0f), 1.0f)
                              .SetEase(Ease.OutBack)
                              .From();
            dragRotator.Reveal();
        }

        private void UpdateSideButtons()
        {
            bool enablePrevButton = pageIndex > 0;
            prevButtonObject.SetActive(enablePrevButton);

            bool enableNextButton = pageIndex + 1 < totalPage;
            nextButtonObject.SetActive(enableNextButton);
        }

        private void DestroyFish()
        {
            if (fishRoot.childCount > 0)
            {
                for (int i = 0; i < fishRoot.childCount; i++)
                {
                    Destroy(fishRoot.GetChild(i).gameObject);
                }
            }
        }

        public void OnNextButtonClick()
        {
            int nextPageIndex = pageIndex + 1;

            if (nextPageIndex >= totalPage)
            {
                return;
            }

            SetPage(nextPageIndex);
        }

        public void OnPrevButtonClick()
        {
            int prevPageIndex = pageIndex - 1;

            if (prevPageIndex < 0)
            {
                return;
            }

            SetPage(prevPageIndex);
        }

        public void OnGrowButtonClick()
        {
            fishRoot.gameObject.SetActive(false);
            Popups.WarningConfirm(message: "You will be moved to sea.",
                                  titleMessage: "Are you sure?",
                                  useCloseButton: false, onOK: ()=>
                                  {
                                      MyInfo.Ocean.SetPopupInPending(PopupInPending.GrowFish);
                                      SceneSystem.LoadLobby(SceneSystem.LOBBY_STATE_INDEX_MAIN);
                                  },
                                  onNO: () =>
                                  {

                                  }).OnClose(()=> fishRoot.gameObject.SetActive(true));
        }
    }

    public struct Benefit
    {
        public SeaItemType type;
        public int id;
        public Benefit(SeaItemType type, int id)
        {
            this.type = type;
            this.id = id;
        }
    }
}