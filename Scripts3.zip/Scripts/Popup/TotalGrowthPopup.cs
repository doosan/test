using Gaga.Popup;
using Gaga.Util;
using TMPro;
using Underc.Effect;
using Underc.UI;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;
using static Gaga.Util.StringUtils;

namespace Underc.Popup
{
    public sealed class TotalGrowthPopup : PopupBehaviour
    {
        [SerializeField] private string percentForamt = "+{0}%";
        [SerializeField] private Transform bonusCoinStartPos;

        [Space]
        [SerializeField] private Text levelText;
        [SerializeField] private TextMeshProUGUI bonusCoinText;
        [SerializeField] private TextMeshProUGUI shopText;
        [SerializeField] private TextMeshProUGUI dailyText;
        [SerializeField] private TextMeshProUGUI freeText;
        [SerializeField] private TextMeshProUGUI feedText;
        [SerializeField] private TextMeshProUGUI chestText;
        [SerializeField] private TextMeshProUGUI congratText;

        private long bonusCoin;

        public void Initialize(long level, long bonusCoin, int shop, int daily, int free, int feed, int chest, int congrat)
        {
            this.bonusCoin = bonusCoin;
            KMBOption kmbOption = StringUtils.GeneralKMBOption();

            levelText.text = level.ToString();
            bonusCoinText.text = StringUtils.ToKMB(bonusCoin, kmbOption);
            shopText.text = ConvertPercent(shop);
            dailyText.text = ConvertPercent(daily);
            freeText.text = ConvertPercent(free);
            feedText.text = ConvertPercent(feed);
            chestText.text = ConvertPercent(chest);
            congratText.text = ConvertPercent(congrat);
        }

        private string ConvertPercent(int value)
        {
            return string.Format(System.Globalization.CultureInfo.InvariantCulture, percentForamt, value);
        }

        public override void Close()
        {
            var topUI = GameObject.FindObjectOfType<TopUI>();

            if (topUI != null)
            {
                var coinStartPos = bonusCoinStartPos.position;
                var coinEndPos = topUI.GetCoinIconPosition();

                EffectSystem.Instance.Coin(coinStartPos
                                            ,coinEndPos
                                            ,topUI.GetCoinIcon()
                                            ,null
                                            ,null
                                            ,()=> MyInfo.Coin += bonusCoin
                                            ,()=> topUI.CoinIconAnimation());
                
            }
            else
            {
                MyInfo.Coin += bonusCoin;
            }
            
            base.Close();
        }
    }
}