using Gaga.Popup;
using Gaga.Util;
using TMPro;
using Underc.User;
using UnityEngine;

namespace Underc.Popup
{
    public enum BoosterPopupType
    { 
        None,
        ShowRemainTime
    }

    public sealed class BoosterPopup : PopupBackable
    {
        [SerializeField] private TextMeshProUGUI timeText;
        private BoosterPopupType type;

        private bool initOnce;
        private void Init()
        {
            if (initOnce == false)
            {
                initOnce = true;
            }
        }

        public void Open(BoosterPopupType type = BoosterPopupType.ShowRemainTime)
        {
            this.type = type;

            Init();
            Reset();
            UpdateContent();
        }

        private void Reset()
        {
            timeText.text = "";
            timeText.gameObject.SetActive(false);
        }

        private void UpdateContent()
        {
            if (type == BoosterPopupType.ShowRemainTime)
            {
                timeText.gameObject.SetActive(true);
                MyInfo.Booster.onSecondaryCurrenciesAddedRemainSeconds += OnSeconds;
                OnSeconds(MyInfo.Booster.SecondaryCurrenciesAddedRemainSec);
            }
        }

        private void OnSeconds(long sec)
        {
            timeText.text = sec.ToSummaryDHMS();
        }

        public override void Close()
        {
            MyInfo.Booster.onSecondaryCurrenciesAddedRemainSeconds -= OnSeconds;

            base.Close();
        }
    }
}