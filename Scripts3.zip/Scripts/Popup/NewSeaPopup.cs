using System;
using System.Collections.Generic;
using Gaga.Popup;
using Underc.Net;
using Underc.LoadingScreen;
using Underc.Ocean;
using Underc.User;
using UnityEngine;
using TMPro;

namespace Underc.Popup
{
    public sealed class NewSeaPopup : PopupBehaviour
    {
        #pragma warning disable 0649
        [SerializeField] private GameObject thumbnailRoot;
        [SerializeField] private GameObject goButton;
        [SerializeField] private TextMeshPro seaNameText;
        #pragma warning restore 0649

        private Action<int> onClose;
        private int seaID;
        private List<BaseLoadingItem> loadingItems;

        public void Open(int seaID, Action<int> onClose)
        {
            this.seaID = seaID;
            this.onClose = onClose;

            Clear();
            SetupSeaName(seaID);
            CreateThumbnailObject(seaID);
            goButton.SetActive(true);
        }

        private void Clear()
        {
            seaNameText.text = "";

            for (int i = 0; i < thumbnailRoot.transform.childCount; i++)
            {
                Destroy(thumbnailRoot.transform.GetChild(i).gameObject);
            }
        }

        public override void Close()
        {
            Popups.ShowLoading();

            NetworkSystem.HTTPRequester.SeaList(resp =>
            {
                if (resp.isSuccess == true && resp.ret == 0)
                {
                    Popups.HideLoading();
                    MyInfo.Ocean.UpdateSeaList(resp.data);
                }

                base.Close();
            });
        }

        private void SetupSeaName(int seaID)
        {
            var sea = MyInfo.Ocean.GetSea(seaID);
            if (sea == null)
            {
                seaNameText.text = "";
            }
            else
            {
                seaNameText.text = sea.Name;
            }
        }

        private void CreateThumbnailObject(int seaID)
        {
            if (SeaThumbnailSystem.Instance.ContainsID(seaID))
            {
                SeaThumbnailSystem.Instance.Get(seaID, thumbnailObj =>
                {
                    if (thumbnailObj != null)
                    {
                        SetThumbnailObject(thumbnailObj);
                    }
                    else
                    {
                        CreateEmptyThumbnailObject();        
                    }
                });
            }
            else
            {
                CreateEmptyThumbnailObject();
            }
        }

        private void CreateEmptyThumbnailObject()
        {
            var sea = MyInfo.Ocean.GetSea(seaID);
            if (sea == null)
            {
                SeaThumbnailSystem.Instance.GetEmptyWithComing(thumbnailObj => SetThumbnailObject(thumbnailObj));
            }
            else
            {
                SeaThumbnailSystem.Instance.GetEmpty(thumbnailObj => SetThumbnailObject(thumbnailObj));
            }
                
        }

        private void SetThumbnailObject(GameObject thumbnailObj)
        {
            if (thumbnailObj != null)
            {
                thumbnailObj.transform.SetParent(thumbnailRoot.transform, false);
                thumbnailObj.transform.localPosition = Vector3.zero;
                thumbnailObj.transform.localScale = Vector3.one;
            }
        }

        public void Go()
        {
            if (onClose != null)
            {
                onClose(seaID);
            }
            Close();
        }
    }
}