using Gaga.AssetBundle;
using Gaga.Popup;
using Underc.Game;
using Underc.Net;
using Underc.Util;
using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using DG.Tweening;

namespace Underc.Popup
{
    public sealed class PaytablePopup : PopupBackable
    {
        #pragma warning disable 0649
        [SerializeField] private RectTransform content;
        [SerializeField] private RectTransform pageRoot;
        [SerializeField] private Text titleText;

        [Header("Buttons")]
        [SerializeField] private GameObject closeButton;
        [SerializeField] private GameObject prevButton;
        [SerializeField] private GameObject nextButton;

        [Header("Animation")]
        [SerializeField] private float pageMoveTime = 0.6f;
        [SerializeField] private AnimationCurve pageMoveCurve;
        #pragma warning restore 0649

        private PaytableInfo paytableInfo;
        private Queue<Page> pages;
        private int currentPageIndex;
        private bool isMoving;

        private enum Direction
        {
            None    = 0,
            Left    = -1,
            Right   = 1
        }

        private class Page : MonoBehaviour
        {
            public RectTransform RectTransform{get; private set;}
            private Image image;

            public void Initialize()
            {
                if (RectTransform != null)
                {
                    return;
                }

                RectTransform = gameObject.AddComponent<RectTransform>();
                RectTransform.localPosition = Vector3.zero;

                var imageInstance = new GameObject("Image");
                imageInstance.transform.SetParent(RectTransform, false);
                image = imageInstance.AddComponent<Image>();
                image.transform.localPosition = Vector3.zero;

                SetImage(null);
            }

            public void SetImage(Sprite texture)
            {
                if (RectTransform == null)
                {
                    return;
                }

                if (texture == null)
                {
                    image.sprite = null;
                    gameObject.SetActive(false);
                    return;
                }

                image.sprite = texture;
                image.SetNativeSize();

                gameObject.SetActive(true);
            }
        }

        public void Initialize(string slotID)
        {
            SetupPages();
            UseCloseButton(false);
            UseArrowButtons(false);
            Load(slotID);
        }

        private void SetupPages()
        {
            if (pages != null)
            {
                return;
            }

            pages = new Queue<Page>();

            for (int i = 0; i < 2; i++)
            {
                var page = new GameObject("Page").AddComponent<Page>();
                page.Initialize();
                page.RectTransform.SetParent(pageRoot, false);

                pages.Enqueue(page);
            }
        }

        private void UseCloseButton(bool value)
        {
            closeButton.SetActive(value);
        }

        private void UseArrowButtons(bool value)
        {
            prevButton.SetActive(value);
            nextButton.SetActive(value);
        }

        private void Load(string slotID)
        {
            Popups.ShowLoading();
            allowBackButton = false;
            AssetBundleSystem.Instance.Load(AssetBundleLoadType.Load
                                            ,Address.CDN_ASSETBUNDLES
                                            ,AssetBundleName.Paytable(slotID)
                                            ,OnLoadComplte);
        }

        private void OnLoadComplte(bool success, Gaga.AssetBundle.AssetBundle ab)
        {
            Popups.HideLoading();
            UseCloseButton(true);
           
            if (success == true)
            {
                SetupPaytable(ab);
                UseArrowButtons(paytableInfo != null && paytableInfo.Items.Length > 1);

                allowBackButton = true;
            }
            else
            {
                Close();
            }
        }

        private void SetupPaytable(Gaga.AssetBundle.AssetBundle paytableAB)
        {
            if (paytableAB == null)
            {
                return;
            }

            paytableInfo = paytableAB.GetAsset<PaytableInfo>("PaytableInfo");

            if (paytableInfo == null)
            {
                Close();
                return;
            }

            var commonAB = AssetBundleSystem.Instance.GetLoadedAssetBundle(SlotGame.Util.AssetBundleName.COMMON);

            if (commonAB == null)
            {
                Close();
                return;
            }

            Reset();
        }

        private void SetPage(int index, Direction direction = Direction.None)
        {
            if (IsReady() == false)
            {
                return;
            }

            index = Mathf.Clamp(index, 0, paytableInfo.Items.Length);
            var info = paytableInfo.Items[index];

            var newPage = pages.Dequeue();
            pages.Enqueue(newPage);

            newPage.SetImage(info.texure);
            titleText.text = info.title;

            currentPageIndex = index;

            if (direction != Direction.None)
            {
                isMoving = true;

                var pageSize = content.rect.size.x;
                var newPageStartPosX = pageSize * -(float)direction;

                newPage.RectTransform.localPosition = new Vector2(newPageStartPosX, 0.0f);

                foreach (var page in pages)
                {
                    var isNewPage = newPage == page;
                    var endPosX = 0.0f;

                    if (isNewPage == false)
                    {
                        endPosX = pageSize * (float)direction;
                    }

                    page.RectTransform.DOKill(false);
                    var tween = page.RectTransform.DOLocalMoveX(endPosX, pageMoveTime)
                                                   .SetEase(pageMoveCurve);

                    if (isNewPage == false)
                    {
                        tween.OnComplete(
                        ()=>
                        {
                            isMoving = false;
                            page.SetImage(null);
                        });
                    }
                }

            }
            else
            {
                foreach (var page in pages)
                {
                    if (newPage != page)
                    {
                        page.SetImage(null);
                    }
                }

                newPage.RectTransform.localPosition = Vector3.zero;
                isMoving = false;
            }
        }

        public bool IsReady()
        {
            return isMoving == false && pages.Count > 0 && paytableInfo != null && paytableInfo.Items.Length > 0;
        }

        public void Next()
        {
            if (IsReady() == false)
            {
                return;
            }

            var targetIndex = currentPageIndex + 1;

            if (targetIndex >= paytableInfo.Items.Length)
            {
                targetIndex = 0;
            }

            SetPage(targetIndex, Direction.Left);
        }

        public void Prev()
        {
            if (IsReady() == false)
            {
                return;
            }

            var targetIndex = currentPageIndex - 1;

            if (targetIndex < 0)
            {
                targetIndex = paytableInfo.Items.Length - 1;
            }

            SetPage(targetIndex, Direction.Right);
        }

        public void Reset()
        {
            SetPage(0);
        }
    }
}