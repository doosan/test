using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using System.Collections;
using Gaga.AssetBundle;
using SlotGame.Machine;
using Underc.User;
using Underc.Game;
using System.Collections.Generic;
using Underc.Net.Client;
using Underc.Net;
using Underc.Lobby;
using Gaga.Skin;

namespace Underc.LoadingScreen
{
    public sealed class GameLoadingScreen : GaugeLoadingScreen<GameLoadingResult>
    {
        private readonly string ASSETBUNDLE_NAME        = "game_loading_info";
        private readonly float EXIT_DELAY               = 0.05f;
        private readonly int DEFAULT_AB_WEIGHT          = 6;

        #pragma warning disable 0649
        [Header("General")]
        [SerializeField] private float fadeInDuration = 0.18f;
        [SerializeField] private float fadeOutDuration = 0.18f;

        [Header("Main")]
        [SerializeField] private CanvasGroup mainCanvasGroup;
        [SerializeField] private Text loadingText;
        [SerializeField] private GameObject gaugeRoot;
        [SerializeField] private float gaugeShowAnimation = 0.75f;
        [SerializeField] private RectTransform gaugeBar;
        [SerializeField] private CanvasGroup symbolRoot;
        [SerializeField] private float symbolShowAnimation = 0.3f;
        [SerializeField] private Image symbol1;
        [SerializeField] private Text description1;
        [SerializeField] private Image symbol2;
        [SerializeField] private Text description2;

        [Header("Poster")]
        [SerializeField] private GameObject posterContainer;
        [SerializeField] private float posterShowAnimation = 0.6f;

        [Header("Gauge")]
        #pragma warning restore 0649

        private string slotID;
        private SlotCardSkin poster;

        private void Awake()
        {
            SetupMain();
        }

        private void OnDisable()
        {
            if (poster != null)
            {
                Destroy(poster.gameObject);
                poster = null;
            }
        }

        private void SetupMain()
        {
            mainCanvasGroup.alpha = 0.0f;
            loadingText.text = "0%";
            UpdateGauge(0.0f);
            symbol1.gameObject.SetActive(false);
            symbol2.gameObject.SetActive(false);
            description1.text = "";
            description2.text = "";
        }

        public void Initialize(string slotID, SlotCardSkin poster, string sceneName = null)
        {
            this.slotID = slotID;
            this.poster = poster;

            MyInfo.Position = int.Parse(slotID);

            poster.gameObject.SetActive(true);
            poster.StopIncreaseJackpotProgress();
            poster.StopUpdateSlotCardFrameGroups();
            poster.ClearFrames(true);
            poster.interactable = false;

            var slotData = MyInfo.SlotGame.GetSlotData(slotID);

            if (slotData != null)
            {
                var slotSkin = Skin.ConvertToSkinType(slotData.Skin);
                Skin.SetGlobalSkin(slotSkin);
            }
            
            // 스파인 애니를 멈춤. 
            // if (poster.CurrentPoster.SkeletonGraphic != null)
            // {
            //     var posterSpine = poster.CurrentPoster.SkeletonGraphic;
            //     var currentAnimationName = posterSpine.AnimationState.GetCurrent(0).Animation.Name;
            //     posterSpine.AnimationState.SetEmptyAnimation(0, 0.0f);
            //     posterSpine.AnimationState.SetAnimation(0, currentAnimationName, true);
            //     posterSpine.AnimationState.TimeScale = 0.0f;
            // }

            symbolRoot.gameObject.SetActive(false);
            mainCanvasGroup.alpha = 0.0f;

            MyInfo.SlotGame.currentSlotID = slotID;
            
            base.Initialize(sceneName);
        }

        protected override BaseLoadingItem[] SetupLoadingItems(GameLoadingResult result)
        {
            List<BaseLoadingItem> loadingItems = new List<BaseLoadingItem>();
            
            result.slotID = slotID;

            loadingItems.Add(new HTTPLoadingItem<UserCoreResponse>(() => {return NetworkSystem.HTTPRequester.UserCore();}
                                                                   ,resp => NetworkSystem.HTTPHandler.Do(resp)));
            // A-1 아쿠아 블리츠 패널을 통해 바로 슬롯 이동이 가능해서
            // A-2 슬롯 로딩할 때 갱신된 미션 데이터를 다시 로드해준다. 
            // A-3 (스핀 중 미션 팝업을 열었을 때는 데이터를 갱신하지 않기 때문에)
            loadingItems.Add(new HTTPLoadingItem<MissionResponse>(() => NetworkSystem.HTTPRequester.Mission()
                                                                  ,resp => NetworkSystem.HTTPHandler.Do(resp)));
            loadingItems.Add(new SlotEnterAndBetLoadingItem(slotID,
                                                            (itemResut, data, autoSpinCount)=>
                                                            {
                                                                if (itemResut.success == true)
                                                                {
                                                                    result.enterData = data.enterData;
                                                                    result.betData = data.betData;
                                                                    result.autoSpinCount = autoSpinCount;
                                                                }
                                                            }));

            loadingItems.Add(new ABLoadingItem(Util.AssetBundleName.SLOT_POSTERS, DEFAULT_AB_WEIGHT));
            loadingItems.Add(new ABLoadingItem(SlotGame.Util.AssetBundleName.COMMON, DEFAULT_AB_WEIGHT));
            loadingItems.Add(new ABLoadingItem(SlotGame.Util.AssetBundleName.Slot(slotID), DEFAULT_AB_WEIGHT));
            loadingItems.Add(new SlotMachineLoadingItem(slotID
                                                        ,(itemResult, slotMachineRef) =>
                                                        {
                                                            if (itemResult.success == true)
                                                            {
                                                                result.slotMachinePrefab = slotMachineRef;
                                                            }
                                                        }));

            return loadingItems.ToArray();
        }

        protected override IEnumerator Enter()
        {
            PosterAnimation();
            GaugeAnimation();

            mainCanvasGroup.DOFade(1.0f, fadeInDuration);

            yield return new WaitForSeconds(gaugeShowAnimation);
        }

        protected override IEnumerator Execute(GameLoadingResult result)
        {
            yield return LoadInfo();
            yield return base.Execute(result);
        }

        protected override IEnumerator Exit()
        {
            MyInfo.SlotGame.ClearSlotPlayInfo();

            yield return new WaitForSeconds(EXIT_DELAY);

            mainCanvasGroup.DOFade(0.0f, fadeOutDuration);

            poster.gameObject.SetActive(false);

            yield return new WaitForSeconds(fadeOutDuration);

            AssetBundleSystem.Instance.Unload(ASSETBUNDLE_NAME);
            Destroy(poster.gameObject);
            poster = null;
        }

        private IEnumerator LoadInfo()
        {
            bool isDone = false;
            GameLoadingInfo gameLoadingInfo = null;

            AssetBundleSystem.Instance.Load(AssetBundleLoadType.Load
                                            ,Net.Address.CDN_ASSETBUNDLES
                                            ,ASSETBUNDLE_NAME
                                            ,(success, ab) => 
                                            {
                                                if (success == true)
                                                {
                                                    var infoName = string.Format(System.Globalization.CultureInfo.InvariantCulture, "GameLoadingInfo_{0}", slotID);
                                                    ab.GetAssetAsync<GameLoadingInfo>(infoName
                                                                                     ,info =>
                                                                                     {
                                                                                        gameLoadingInfo = info;
                                                                                        isDone = true;
                                                                                     });
                                                }
                                                else
                                                {
                                                    isDone = true;
                                                }
                                            });

            while(isDone == false)
            {
                yield return null;
            }

            if (gameLoadingInfo != null)
            {
                symbolRoot.gameObject.SetActive(true);
                symbolRoot.alpha = 0.0f;

                if (gameLoadingInfo.Symbol1 != null)
                {
                    symbol1.sprite = gameLoadingInfo.Symbol1;
                    symbol1.SetNativeSize();
                    symbol1.gameObject.SetActive(true);
                }

                if (gameLoadingInfo.Symbol2 != null)
                {
                    symbol2.sprite = gameLoadingInfo.Symbol2;
                    symbol2.SetNativeSize();
                    symbol2.gameObject.SetActive(true);
                }

                if (gameLoadingInfo.Description1 != null)
                {
                    description1.text = gameLoadingInfo.Description1;
                }

                if (gameLoadingInfo.Description2 != null)
                {
                    description2.text = gameLoadingInfo.Description2;
                }

                symbolRoot.DOFade(1.0f, symbolShowAnimation)
                        .SetDelay(0.1f);
                
                yield return new WaitForSeconds(symbolShowAnimation);
            }
        }

        private void PosterAnimation()
        {
            if (poster == null)
            {
                return;
            }

            poster.transform.DOKill(false);
            poster.transform.SetParent(posterContainer.transform, true);
            poster.transform.localScale = Vector3.one;
            poster.transform.position = Vector3.zero;

            poster.transform.DOLocalMove(Vector3.one, posterShowAnimation).SetEase(Ease.OutBack);
        }

        private void GaugeAnimation()
        {
            var tempPos = gaugeRoot.transform.localPosition;
            gaugeRoot.transform.localPosition = new Vector3(tempPos.x, tempPos.y - 200.0f, 0.0f);

            gaugeRoot.transform.DOLocalMoveY(tempPos.y, gaugeShowAnimation).SetEase(Ease.OutQuint);
        }
    }

    public class GameLoadingResult : LoadingResult
    {
        public string slotID;
        public EnterData enterData;
        public BetData betData;
        public long userBet;
        public SlotMachine slotMachinePrefab;
        public int autoSpinCount;
    }
}