using UnityEngine;
using Gaga.Attribute;

namespace Underc.Game
{
	[CreateAssetMenu(fileName="GameLoadingInfo", menuName="Underc/Loading/Game Loading Info")]
	public class GameLoadingInfo : ScriptableObject
	{
        #pragma warning disable 0649
        [Header("Symbol 1")]
		[SerializeField, LabelOverride("Sprite")] private Sprite symbol1Sprite;
        public Sprite Symbol1{get{return symbol1Sprite;}}
        [SerializeField, TextArea] private string symbol1Description;
        public string Description1{get{return symbol1Description;}}

        [Header("Symbol 2")]
		[SerializeField, LabelOverride("Sprite")]  private Sprite symbol2Sprite;
        public Sprite Symbol2{get{return symbol2Sprite;}}
        [SerializeField, TextArea] private string symbol2Description;
        public string Description2{get{return symbol2Description;}}
        #pragma warning restore 0649
	}
}
