import AnimatorBase, { AnimationPlayer } from "./core/AnimatorBase";
import AnimatorStateLogic from "./core/AnimatorStateLogic";

const { ccclass, property, requireComponent, disallowMultiple } = cc._decorator;

/** 
 * 사용자 지정 애니메이션 제어를 위한 상태 머신 구성 요소
 */
@ccclass
@disallowMultiple
export default class AnimatorCustomization extends AnimatorBase 
{
    /** 이 구성 요소는 초기화를 위해 onInit를 적극적으로 호출해야 합니다. */
    @property({ override: true, visible: false })
    protected PlayOnStart: boolean = false;

    /**
     * 상태 머신을 수동으로 초기화하고 0-3개의 매개변수를 전달할 수 있으며 유형은 다음과 같습니다.
     *-onStateChangeCall 상태 전환 시 콜백
     *-stateLogicMap 각 상태 논리 제어
     *-animationPlayer 사용자 정의 애니메이션 컨트롤
     * @override
     */
    public onInit(...args: Array<Map<string, AnimatorStateLogic> | ((fromState: string, toState: string) => void) | AnimationPlayer>) 
    {
        if (this._hasInit) 
        {
            return;
        }

        cc.log("AnimatorCustomization:onInit() =>");

        this._hasInit = true;

        this.initArgs(...args);

        if (this.AssetRawUrl !== null) 
        {
            this.initJson(this.AssetRawUrl.json);
        }
    }

    /**
     * 애니메이션 재생
     * @override
     * @param animName 애니메이션 이름
     * @param loop 루프에서 재생할지 여부
     */
    protected playAnimation(animName: string, loop: boolean) 
    {
        if (this._animationPlayer && animName) 
        {
            //cc.log("AnimatorCustomization:playAnimation() animName=>"+animName);

            this._animationPlayer.playAnimation(animName, loop);
        }
    }

    /**
     * 확대/축소 애니메이션 재생 속도
     * @override
     * @param scale 배율
     */
    public scaleTime(scale: number) 
    {
        if (this._animationPlayer) 
        {
            this._animationPlayer.scaleTime(scale);
        }
    }
}
