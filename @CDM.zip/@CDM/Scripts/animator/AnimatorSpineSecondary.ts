import AnimatorSpine from "./AnimatorSpine";
import AnimatorBase, { AnimationPlayer } from "./core/AnimatorBase";
import AnimatorStateLogic from "./core/AnimatorStateLogic";

const { ccclass, property, requireComponent } = cc._decorator;

/** 
 * Spine 상태 머신 구성 요소(보조 상태 머신), 
 * 동일한 노드를 여러 개 추가할 수 있으며, 
 * 다른 트랙에서 애니메이션을 재생하는 데 사용되며 trackIndex는 0보다 커야 합니다.
 */
@ccclass
@requireComponent(sp.Skeleton)
export default class AnimatorSpineSecondary extends AnimatorBase 
{
    @property({ tooltip: CC_DEV && '애니메이션 재생의 trackIndex는 0보다 커야 합니다' }) TrackIndex: number = 1;

    /** 메인 상태 머신 */
    private _main: AnimatorSpine = null;
    /** spine */
    private _spine: sp.Skeleton = null;

    protected start() 
    {
        if (!this.PlayOnStart || this._hasInit) 
        {
            return;
        }

        cc.log("AnimatorSpineSecondary:start =>");

        this._hasInit = true;

        this._spine = this.getComponent(sp.Skeleton);
        this._main  = this.getComponent(AnimatorSpine);
        this._main.addSecondaryListener(this.onAnimFinished, this);

        if (this.AssetRawUrl !== null) 
        {
            this.initJson(this.AssetRawUrl.json);
        }
    }

    /**
     * 상태 머신을 수동으로 초기화하고 0-3개의 매개변수를 전달할 수 있으며 유형은 다음과 같습니다.
     * - onStateChangeCall 상태 전환 시 콜백
     * - stateLogicMap 각 상태 논리 제어
     * - animationPlayer 사용자 정의 애니메이션 컨트롤
     * @override
     */
    public onInit(...args: Array<Map<string, AnimatorStateLogic> | ((fromState: string, toState: string) => void) | AnimationPlayer>) 
    {
        if (this.PlayOnStart || this._hasInit) 
        {
            return;
        }

        cc.log("AnimatorSpineSecondary:onInit =>");
        
        this._hasInit = true;

        this.initArgs(...args);

        this._spine = this.getComponent(sp.Skeleton);
        this._main = this.getComponent(AnimatorSpine);
        this._main.addSecondaryListener(this.onAnimFinished, this);

        if (this.AssetRawUrl !== null) 
        {
            this.initJson(this.AssetRawUrl.json);
        }
    }

    /**
     * 애니메이션 재생
     * @override
     * @param animName 애니메이션 이름
     * @param loop 루프에서 재생할지 여부
     */
    protected playAnimation(animName: string, loop: boolean) 
    {
        cc.log("AnimatorSpineSecondary:playAnimation =>"+animName);

        if (animName) 
        {
            this._spine.setAnimation(this.TrackIndex, animName, loop); 
         } 
         else 
         {
             this._spine.clearTrack(this.TrackIndex);
         }
    }
}
