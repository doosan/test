import AnimatorBase, { AnimationPlayer } from "./core/AnimatorBase";
import AnimatorStateLogic from "./core/AnimatorStateLogic";

const { ccclass, property, requireComponent, disallowMultiple } = cc._decorator;

/** 
 * DragonBones 상태 머신 구성 요소
 */
@ccclass
@disallowMultiple
@requireComponent(dragonBones.ArmatureDisplay)
export default class AnimatorDragonBones extends AnimatorBase 
{
    /** DragonBones 컴포넌트 */
    private _dragonBones: dragonBones.ArmatureDisplay = null;

    protected start() 
    {
        if (!this.PlayOnStart || this._hasInit) 
        {
            return;
        }
        this._hasInit = true;

        this._dragonBones = this.getComponent(dragonBones.ArmatureDisplay);
        this._dragonBones.addEventListener(dragonBones.EventObject.COMPLETE, this.onAnimFinished, this);

        if (this.AssetRawUrl !== null) 
        {
            this.initJson(this.AssetRawUrl.json);
        }
    }

    /**
     * 상태 머신을 수동으로 초기화하고 0-3개의 매개변수를 전달할 수 있으며 유형은 다음과 같습니다.
     *-onStateChangeCall 상태 전환 시 콜백
     *-stateLogicMap 각 상태 논리 제어
     *-animationPlayer 사용자 정의 애니메이션 컨트롤
     * @override
     */
    public onInit(...args: Array<Map<string, AnimatorStateLogic> | ((fromState: string, toState: string) => void) | AnimationPlayer>) 
    {
        if (this.PlayOnStart || this._hasInit) 
        {
            return;
        }
        this._hasInit = true;

        this.initArgs(...args);

        this._dragonBones = this.getComponent(dragonBones.ArmatureDisplay);
        this._dragonBones.addEventListener(dragonBones.EventObject.COMPLETE, this.onAnimFinished, this);

        if (this.AssetRawUrl !== null) 
        {
            this.initJson(this.AssetRawUrl.json);
        }
    }

    /**
     * 애니메이션 재생
     * @override
     * @param animName 애니메이션 이름
     * @param loop 루프에서 재생할지 여부
     */
    protected playAnimation(animName: string, loop: boolean) 
    {
        animName && this._dragonBones.playAnimation(animName, loop ? 0 : -1);
    }

    /**
     * 확대/축소 애니메이션 재생 속도
     * @override
     * @param scale 배율
     */
    public scaleTime(scale: number) 
    {
        this._dragonBones.timeScale = scale;
    }
}
