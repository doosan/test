/**
 * 상태 논리 기본 클래스
 */
export default class AnimatorStateLogic 
{
    /**
     * state 진입시 호출
     * @virtual
     */
    public onEntry() 
    {
    }

    /**
     * 상태 머신의 논리가 업데이트될 때마다 호출됩니다.
     * @virtual
     */
    public onUpdate() 
    {
    }

    /**
     * 상태를 떠날 때 호출됨
     * @virtual
     */
    public onExit() 
    {
    }
}
