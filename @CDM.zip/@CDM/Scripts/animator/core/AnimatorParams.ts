import { ParamType } from "./AnimatorCondition";

/**
 * 매개변수 구조
 */
interface Param 
{
    type: ParamType;
    value: number;
}

/**
 * 상태 머신 매개변수
 */
export default class AnimatorParams 
{
    public _paramMap: Map<string, Param> = new Map();

    constructor(dataArr: any[]) 
    {
        dataArr.forEach((data: any) => 
        {
            //cc.log("AnimatorParams:constructor() data=>"+data);

            let param: Param = 
            {
                type: data.type,
                value: data.init
            };
            this._paramMap.set(data.param, param);
        }, this);
    }

    public cotainKey(key : string) : boolean
    {
        let param: Param = this._paramMap.get(key);
        if (param) 
        {
            return true;
        } 
        else 
        {
            return false;
        }
    }

    public HasParameter(key: string, type:ParamType):boolean{
        let param: Param = this._paramMap.get(key);
        if(param && param.type == type){
            return true;
        }else{
            return false;
        }

    }

    public getParamType(key: string): ParamType 
    {
        //cc.log("AnimatorParams:getParamType() key=>"+key);

        let param: Param = this._paramMap.get(key);
        if (param) 
        {
            return param.type;
        } 
        else 
        {
            return null;
        }
    }

    public SetInteger(key: string, value: number) 
    {
        //cc.log("AnimatorParams:SetInteger() key=>"+key);

        let param: Param = this._paramMap.get(key);
        if (param && param.type === ParamType.NUMBER) 
        {
            param.value = value;
        }
    }

    public SetBool(key: string, value: boolean) 
    {
        //cc.log("AnimatorParams:SetBool() key=>"+key);
       
        let param: Param = this._paramMap.get(key);
        if (param && param.type === ParamType.BOOLEAN) 
        {
            param.value = value ? 1 : 0;
        }
    }

    public SetTrigger(key: string) 
    {
        //cc.log("AnimatorParams:setTrigger() key=>"+key);
        // this._paramMap.forEach((value, key)=>
        // {   
        //     this.ResetTrigger(key);
        // }, this);

        let param: Param = this._paramMap.get(key);
        if (param && param.type === ParamType.TRIGGER) 
        {
            //cc.log("setTrigger : " + key);
            param.value = 1;
        }
        else 
        {
            if (param == null)
                cc.warn("setTrigger fail key : " + key + " key를 못 찾음");
            else 
                cc.warn("setTrigger fail key : " + key + " type :"+ param.type);
        }
    }

    public ResetTrigger(key: string) 
    {
        //cc.log("AnimatorParams:ResetTrigger() key=>"+key);

        let param: Param = this._paramMap.get(key);
        if (param && param.type === ParamType.TRIGGER) 
        {
            //cc.log("ResetTrigger Success : " + key);

            param.value = 0;
        }
    }

    public ResetAllTriggers() 
    {
        //cc.log("AnimatorParams:ResetAllTriggers() =>");

        this._paramMap.forEach(param=>
        {
            if (param && param.type === ParamType.TRIGGER) 
            {
                param.value = 0;
            }
        });
    }

    public AutoTrigger(key: string) 
    {
        //cc.log("AnimatorParams:autoTrigger() key=>"+key);

        let param: Param = this._paramMap.get(key);
        if (param && param.type === ParamType.AUTO_TRIGGER) 
        {
            param.value = 1;
        }
    }

    public resetAutoTrigger(key: string) 
    {
        //cc.log("AnimatorParams:resetAutoTrigger() key=>"+key);

        let param: Param = this._paramMap.get(key);
        if (param && param.type === ParamType.AUTO_TRIGGER) 
        {
            param.value = 0;
        }
    }

    public resetAllAutoTrigger() 
    {
        //cc.log("AnimatorParams:resetAllAutoTrigger() =>");

        this._paramMap.forEach((param: Param, key: string) => 
        {
            if (param.type === ParamType.AUTO_TRIGGER) 
            {
                param.value = 0;
            }
        }, this);
    }

    public GetInteger(key: string): number 
    {
        //cc.log("AnimatorParams:getNumber() key=>"+key);

        let param: Param = this._paramMap.get(key);
        if (param && param.type === ParamType.NUMBER) 
        {
            return param.value;
        } 
        else 
        {
            return 0;
        }
    }

    public GetBool(key: string): number 
    {
        //cc.log("AnimatorParams:getBool() key=>"+key);

        let param: Param = this._paramMap.get(key);
        if (param && param.type === ParamType.BOOLEAN) 
        {
            return param.value;
        } 
        else 
        {
            return 0;
        }
    }

    public GetTrigger(key: string): number 
    {
        //cc.log("AnimatorParams:getTrigger() key=>"+key);

        let param: Param = this._paramMap.get(key);
        
        if (param && param.type === ParamType.TRIGGER) 
        {
            return param.value;
        } 
        else 
        {
            return 0;
        }
    }

    public GetAutoTrigger(key: string): number 
    {
        //cc.log("AnimatorParams:GetAutoTrigger() key=>"+key);

        let param: Param = this._paramMap.get(key);
        if (param && param.type === ParamType.AUTO_TRIGGER) 
        {
            return param.value;
        } 
        else 
        {
            return 0;
        }
    }
}