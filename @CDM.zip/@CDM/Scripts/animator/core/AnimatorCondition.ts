import AnimatorController from "./AnimatorController";

/** 매개변수 유형 */
export enum ParamType 
{
    COMPLETE = 0,
    BOOLEAN = 1,
    NUMBER = 2,
    TRIGGER = 3,
    AUTO_TRIGGER = 4
}

/** 로직 타입 */
export enum LogicType 
{
    EQUAL = 0,
    NOTEQUAL = 1,
    GREATER = 2,
    LESS = 3,
    GREATER_EQUAL = 4,
    LESS_EQUAL = 5
}

/**
 * 개별 조건
 */
export default class AnimatorCondition 
{
    private _ac: AnimatorController = null;
    /** 조건에 해당하는 매개변수 이름 */
    private _param: string = "";
    /** 조건에 해당하는 값 */
    private _value: number = 0;
    /** 조건을 값과 비교하는 논리 */
    private _logic: LogicType = LogicType.EQUAL;

    constructor(data: any, ac: AnimatorController) 
    {
        this._ac = ac;
        this._param = data.param;
        this._value = data.value;
        this._logic = data.logic;
    }

    public getParamName()
    {
        return this._param;
    }

    public getParamType(): ParamType 
    {
        return this._ac.params.getParamType(this._param);
    }

    /** 조건이 충족되는지 확인 */
    public check(): boolean 
    {
        //cc.log("AnimatorCondition:check() =>");

        let type: ParamType = this.getParamType();
        if (type === ParamType.BOOLEAN) 
        {
            return this._ac.params.GetBool(this._param) === this._value;
        } 
        else if (type === ParamType.NUMBER) 
        {
            let value: number = this._ac.params.GetInteger(this._param);
            switch (this._logic) 
            {
                case LogicType.EQUAL:
                    return value === this._value;
                case LogicType.NOTEQUAL:
                    return value !== this._value;
                case LogicType.GREATER:
                    return value > this._value;
                case LogicType.LESS:
                    return value < this._value;
                case LogicType.GREATER_EQUAL:
                    return value >= this._value;
                case LogicType.LESS_EQUAL:
                    return value <= this._value;
                default:
                    return false;
            }
        } 
        else if (type === ParamType.AUTO_TRIGGER) 
        {
            return this._ac.params.GetAutoTrigger(this._param) !== 0;
        } 
        else if (type === ParamType.TRIGGER) 
        {
            return this._ac.params.GetTrigger(this._param) !== 0;
        } 
        else 
        {
            cc.error(`[AnimatorCondition.check] 잘못된Type: ${type}`);
            return false;
        }
    }
}
