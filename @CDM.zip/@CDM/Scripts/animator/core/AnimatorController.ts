import AnimatorBase from "./AnimatorBase";
import AnimatorParams from "./AnimatorParams";
import AnimatorState from "./AnimatorState";

/**
 * Animator컨트롤러
 */
export default class AnimatorController 
{
    private _jsonData: any = null;
    public _animator: AnimatorBase = null;

    private _params: AnimatorParams = null;
    private _states: Map<string, AnimatorState> = null;
    private _anyState: AnimatorState = null;
    private _curState: AnimatorState = null;

    private _defaultState : string = "";
    /** Change카운터 */
    private _changeCount: number = 0;
    /** AnimComplete의 상태 */
    public animCompleteState: AnimatorState = null;
    /** 애니메이션 재생 완료 */
    public animComplete: boolean = false;
    /** 현재 상태 */
    public get curState(): AnimatorState { return this._curState; }
    public get params(): AnimatorParams { return this._params; }

    constructor(player: AnimatorBase, json: any) 
    {
        this._animator = player;
        this._jsonData = json;
        this._states = new Map<string, AnimatorState>();
        this._params = new AnimatorParams(json.parameters);
        this.init(json);
    }

    public HasState(name : string) : boolean
    {
        return this._states.has(name);
    }

    /**
     * 초기화
     */
    private init(json: any) 
    {        
        if (json.states.length <= 0) 
        {
            cc.error(`[AnimatorController.init()] 상태 머신 JSON 오류`);
            return;
        }

        let defaultState: string = json.defaultState;
        
        this._defaultState = defaultState;

        this._anyState = new AnimatorState(json.anyState, this);

        //cc.log("AnimatorController.Init() : " + this._animator.node.name);
        
        for (let i = 0; i < json.states.length; i++) 
        {
            let state: AnimatorState = new AnimatorState(json.states[i], this);
            this._states.set(state.name, state);

            //cc.log("AnimatorController:init().State : " + state.name);
        }

        this.changeState(defaultState);
    }

    // AutoReset이 체크된 상태에서 Disable이 되면 자동 호출이 된다.
    public resetState()
    {
        //cc.log("AnimatorController:resetState() _defaultState=>"+this._defaultState);
        
        this._curState = null;
        this.changeState(this._defaultState);        
    }

    private updateState() 
    {
        this._curState.checkAndTrans();

        if (this._curState !== this._anyState && this._anyState !== null)
        {
            this._anyState.checkAndTrans();
        }
    }

    /**
     * 상태 머신 로직 업데이트
     */
    public updateAnimator() 
    {
        // 카운트 재설정
        this._changeCount = 0;

        this.updateState();

        // 애니메이션 완료 표시 재설정
        if (this.animComplete && this.animCompleteState.loop)
        {
            this.animComplete = false;
        }
        // autoTrigger 재설정
        this.params.resetAllAutoTrigger();
    }

    public onAnimationComplete() 
    {
        this.animComplete = true;
        this.animCompleteState = this._curState;
        //cc.log(`AnimatorController:onAnimationComplete().animation complete: ${this._curState.name}`);
    }

    /**
     * 조건에 관계없이 바로 상태로 점프, 현재 이 상태라면 상태 리셋
     * @param 상태 이름
     */
    public play(stateName: string) 
    {
        if (!this._states.has(stateName))// || this._curState.name === stateName) 
        {
            return;
        }

        //cc.log(`AnimatorController:play() stateName : ${this._curState.name}`);

        // 애니메이션 완료 표시 재설정
        this.animComplete = false;
        //this.changeState(stateName);

        let oldState = this._curState;
        this._curState = this._states.get(stateName)!;
        this._animator.onStateChange(oldState, this._curState);
        this.updateState();
    }

    /**
     * 애니메이션 상태 전환
     */
    public changeState(stateName: string) 
    {
        this._changeCount++;
        if (this._changeCount > 1000) 
        {
            cc.error('[AnimatorController.changeState()] error: 상태 전환이 반복적으로 1000 회 이상 호출하면 전환 설정이 잘못되었을 수 있습니다!');
            return;
        }

        if (this._states.has(stateName) && (this._curState === null || this._curState.name !== stateName)) 
        { 
            //cc.log("AnimatorController:changeState() ==> changeState : " + this._animator.node.name + " , state : " + stateName);

            let oldState = this._curState;
            this._curState = this._states.get(stateName);

            this._animator.onStateChange(oldState, this._curState);

            this.updateState();
        } 
        // 같은 상태일때에는 위 함수에 안 들어가기때문에 아래 코드를 호출해주면 안된다.( Error가 아니다. )
        // else 
        // {
        //     cc.error(`[AnimatorController.changeState] error state: ${stateName}`);
        //     cc.log(this._animator.node.name);
        // }
    }
}
