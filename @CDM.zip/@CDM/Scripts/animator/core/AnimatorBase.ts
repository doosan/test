import { ParamType } from "./AnimatorCondition";
import AnimatorController from "./AnimatorController";
import AnimatorState from "./AnimatorState";
import AnimatorStateLogic from "./AnimatorStateLogic";

const { ccclass, property, executionOrder } = cc._decorator;

/**
 * 애니메이션 재생 제어를 위한 인터페이스 사용자 정의
 */
export interface AnimationPlayer 
{
    /** 애니메이션 종료에 대한 콜백 설정 */
    setFinishedCallback(callback: () => void, target: any): void;
    /** 애니메이션 재생 */
    playAnimation(animName: string, loop: boolean): void;
    /** 확대/축소 애니메이션 재생 속도 */
    scaleTime(scale: number): void;
}

/**
 * 상태 머신 구성 요소 기본 클래스 우선 순위 실행 수명 주기
 */
@ccclass
@executionOrder(-1000)
export default class AnimatorBase extends cc.Component 
{
    @property({ type: cc.JsonAsset, tooltip: CC_DEV && '상태 머신 json 파일' })
    protected AssetRawUrl: cc.JsonAsset = null;

    @property({ tooltip: CC_DEV && '시작시 상태 머신을 자동으로 시작할지 여부' })
    protected PlayOnStart: boolean = true;

    @property({ tooltip: CC_DEV && '업데이트에서 상태 시스템 논리 업데이트를 자동으로 트리거할지 여부' })
    protected AutoUpdate: boolean = true;

    @property({ tooltip: CC_DEV && 'True가 되면 주황색 Default State로 강제 이동을 시킨다. - Exit State가 없기 때문에..' })
    protected AutoReset: boolean = true;

    /** Animation 컴포넌트 */
    @property({ type: cc.Animation, tooltip: CC_DEV && '수동으로 세팅을 할때 사용한다.' })
    public animation: cc.Animation = null;

    /** 초기화 여부 */
    protected _hasInit: boolean = false;
    /** 컨트롤러 */
    public _ac: AnimatorController = null;

    /** 각 상태의 논리 제어, 키는 상태 이름 */
    protected _stateLogicMap: Map<string, AnimatorStateLogic> = null;
    /** 상태가 전환될 때 콜백 */
    protected _onStateChangeCall: (fromState: string, toState: string) => void = null;
    /** 사용자 지정 애니메이션 재생 컨트롤러 */
    protected _animationPlayer: AnimationPlayer = null;


    protected KeepSetTriggerKey: string = "";

    protected _extraMulti: number = 1;
    /** 모든 애니메이션 재생 속도의 통합 제어 매개변수 */
    public get extraMulti(): number { return this._extraMulti; }
    public set extraMulti(v: number) 
    {
        if (this._extraMulti === v) 
        {
            return;
        }
        this._extraMulti = v;
        this.updatePlaySpeed();
    }

    /** 현재 상태 이름 */
    public get curStateName(): string { return this._ac.curState.name; }

    /** 현재 애니메이션 이름 */
    public get curStateMotion(): string { return this._ac.curState.motion; }

    /** 현재 애니메이션이 완료되었는지 여부 */
    public get animComplete(): boolean { return this._ac.animComplete; }

    /**
     * 상태 머신을 수동으로 초기화하고 0-3개의 매개변수를 전달할 수 있으며 유형은 다음과 같습니다.
     * - onStateChangeCall 상태 전환 시 콜백
     * - stateLogicMap 각 상태 논리 제어
     * - animationPlayer 사용자 정의 애니메이션 컨트롤
     * @virtual
     */
    public onInit(...args: Array<Map<string, AnimatorStateLogic> | ((fromState: string, toState: string) => void) | AnimationPlayer>) 
    {
    }

    /**
     * 초기화 매개변수 처리
     */
    protected initArgs(...args: Array<Map<string, AnimatorStateLogic> | ((fromState: string, toState: string) => void) | AnimationPlayer>) 
    {
        //cc.log("AnimatorBase:initArgs() =>");

        args.forEach((arg) => 
        {
            if (!arg) 
            {
                return;
            }

            if (typeof arg === 'function') 
            {
                this._onStateChangeCall = arg;
            }
            else if (typeof arg === 'object') 
            {
                if (arg instanceof Map) 
                {
                    this._stateLogicMap = arg;
                }
                else 
                {
                    this._animationPlayer = arg;
                    this._animationPlayer.setFinishedCallback(this.onAnimFinished.bind(this), this);
                }
            }
        }, this);
    }

    /**
     * 애니메이션 재생 속도 업데이트
     */
    private updatePlaySpeed() 
    {
        if (this._ac.curState == null)
        {
            return;
        }
        // 현재 애니메이션 재생 속도 믹스
        let playSpeed = this._ac.curState.speed * this.extraMulti;
        if (this._ac.curState.multi) 
        {
            playSpeed *= this._ac.params.GetInteger(this._ac.curState.multi) || 1;
        }
        this.scaleTime(playSpeed);
    }


    /**
     * 애니메이션 재생 속도 업데이트
     */
    private updateAnimator() 
    {
        if (this._ac == null)
        {
            return;
        }
        // 애니메이션 재생 속도 업데이트
        this.updatePlaySpeed();

        // AnimatorStateLogic 업데이트
        if (this._stateLogicMap) 
        {
            let curLogic = this._stateLogicMap.get(this._ac.curState.name);
            curLogic && curLogic.onUpdate();
        }

        // 상태 머신 로직 업데이트
        this._ac.updateAnimator();


        // if(null == this._ac)
        // {        
        //     return;    
        // }

        // // 현재 애니메이션 재생 속도 혼합
        // //let playSpeed = this._ac.curState.speed;

        // let playSpeed = this._ac.curState.speed * this.extraMulti;
        // if (this._ac.curState.multi) 
        // {
        //     playSpeed *= this._ac.params.getNumber(this._ac.curState.multi) || 1;
        // }
        // this.scaleTime(playSpeed);


        // // if (this._ac.curState.multi) 
        // // {
        // //     playSpeed *= this._ac.params.getNumber(this._ac.curState.multi) || 1;
        // // }
        // // this.scaleTime(playSpeed);

        // // AnimatorStateLogic 업데이트
        // if (this._stateLogicMap) 
        // {
        //     let curLogic = this._stateLogicMap.get(this._ac.curState.name);
        //     curLogic && curLogic.onUpdate();
        // }

        // // 상태 머신 로직 업데이트
        // this._ac.updateAnimator();
    }



    protected update() 
    {
        if (this._hasInit && this.AutoUpdate) 
        {
            this.updateAnimator();
        }
    }

    /**
     * 수동 업데이트
     */
    public manualUpdate() 
    {
        if (this._hasInit && !this.AutoUpdate) 
        {
            this.updateAnimator();
        }
    }

    /**
     * 상태 머신 json 파일 구문 분석
     */
    protected initJson(json: any) 
    {
        this._ac = new AnimatorController(this, json);

        // 기본 상태 수행
        this._ac.changeState(json.defaultState);
    }

    /**
     * 애니메이션 종료에 대한 콜백
     */
    protected onAnimFinished() 
    {
        //cc.log("AnimatorBase:onAnimFinished() => " + this._ac.curState.name);

        this._ac.onAnimationComplete();
    }

    /**
     * 애니메이션 재생
     * @virtual
     * @param animName 애니메이션 이름
     * @param loop 루프에서 재생할지 여부
     */
    protected playAnimation(animName: string, loop: boolean) 
    {
    }

    /**
     * 확대/축소 애니메이션 재생 속도
     * @virtual
     * @param scale 스케일 줌 배율
     */
    public scaleTime(scale: number) 
    {
    }

    /** 
     * 상태 전환 중 논리(상태 머신의 내부 메서드는 외부에서 직접 호출할 수 없음)
     */
    public onStateChange(fromState: AnimatorState, toState: AnimatorState)
    {
        //cc.log("AnimatorBase:onStateChange() fromState=>"+fromState + " toState=>"+toState);

        this.playAnimation(toState.motion, toState.loop);

        let fromStateName = fromState ? fromState.name : '';

        if (this._stateLogicMap) 
        {
            let fromLogic = this._stateLogicMap.get(fromStateName);
            fromLogic && fromLogic.onExit();
            let toLogic = this._stateLogicMap.get(toState.name);
            toLogic && toLogic.onEntry();
        }

        this._onStateChangeCall && this._onStateChangeCall(fromStateName, toState.name);
    }

    public HasParameter(key: string, type:ParamType):boolean{
        if(!this._ac) return false;
        if(!this._ac.params) return false;
        return this._ac.params.HasParameter(key, type);
    }

    /**
     * boolean 유형 매개변수의 값 설정
     */
    public SetBool(key: string, value: boolean) 
    {
        //cc.log(this._ac.params);
        this._ac.params.SetBool(key, value);
    }

    /**
     * boolean 유형 매개변수의 값을 가져옵니다.
     */
    public GetBool(key: string): boolean 
    {
        return this._ac.params.GetBool(key) !== 0;
    }

    /**
     * number 유형 매개변수의 값을 설정합니다.
     */
    public SetInteger(key: string, value: number) 
    {
        this._ac.params.SetInteger(key, value);
    }

    /**
     * number 유형 매개변수의 값을 가져옵니다.
     */
    public GetInteger(key: string): number 
    {
        return this._ac.params.GetInteger(key);
    }

    /**
     * trigger Event핸들러일때 사용한다.
     */
    public SetTriggerEvent(event, customEventData)
    {
        this.SetTrigger(customEventData);
    }

    /**
     * trigger 유형 매개변수의 값 설정
     */
    public SetTrigger(event, customEventData)
    public SetTrigger(key: string)
    public SetTrigger(param1: any, param2?: any) 
    {
        let key: string = "";

        if (typeof param1 === "string")
        {
            key = param1;
        }
        else 
        {
            key = param2;
        }


        if (this._ac == null)
        {
            cc.log("AnimatorController이 없습니다" + "  노드 이름 : " + this.node.name + "   Key : " + key);

            // onload후에 호출한다.
            this.KeepSetTriggerKey = key;

               // this.initJson(this.AssetRawUrl.json);
               this._ac = new AnimatorController(this, this.AssetRawUrl.json);
                if(this._ac != null)
                {
                    this._ac.params.SetTrigger(key);
                }
                else 
                {
                    cc.error("AnimatorController이 진짜 없습니다(error2)" + "  노드 이름 : " + this.node.name + "   Key : " + key);
                }
        }
        else
        {
            //cc.log(this.node.name + " AnimatorBase:setTrigger() Current_State ( "+this._ac.curState.name + " ) => Next_State: ( "+key + " )");
            
            this._ac.params.SetTrigger(key);
        }
    }

    /**
     * trigger 유형 매개변수의 값 재설정
     */
    public ResetTrigger(key: string) 
    {
        //cc.log("AnimatorBase:ResetTrigger() key=>"+key);

        if (this._ac != null)
            this._ac.params.ResetTrigger(key);
    }

    public ResetAllTriggers()
    {
        //cc.log("AnimatorBase:ResetAllTriggers() =>");
        if (this._ac != null)
            this._ac.params.ResetAllTriggers();
    }

    /**
     * autoTrigger 유형 매개변수의 값을 설정합니다
     * (autoTrigger 유형 매개변수는 적극적으로 재설정할 필요가 없으며 각 상태 머신 업데이트 후에 자동으로 재설정됨)
     */
    public AutoTrigger(key: string) 
    {
        //cc.log("AnimatorBase:autoTrigger() key=>"+key);

        this._ac.params.AutoTrigger(key);
    }

    /**
     * 조건에 관계없이 직접 상태로 점프
     * @param 상태 이름
     */
    public play(stateName: string) 
    {
        //cc.log("AnimatorBase:play() stateName=>"+stateName);

        if (!this._hasInit) 
        {
            return;
        }

        this._ac.play(stateName);
    }

    public IsStateName(stateName: string)
    {
        return this.curStateName == stateName;
    }

    // 현재 Animation의 전체 길이를 얻는다. -999이면 값을 못 얻은 상태이다.
    public getCurAnimationDuration():number
    {
        let animState:cc.AnimationState = this.animation.getAnimationState(this.curStateMotion);
        if(animState)
        {
            return animState.duration;
        }
        else 
        {
            cc.warn("getCurAnimationDuration null");
        }

        return -1;
    }

    // 현재 Animation의 전체 길이 중 어느정도 경과되었는지 얻는다. -999이면 값을 못 얻은 상태이다.
    public getCurAnimationTime():number
    {
        let animState:cc.AnimationState = this.animation.getAnimationState(this.curStateMotion);
        if(animState)
        {
            return animState.time;
        }
        else 
        {
            cc.warn("getCurAnimationTime null");
        }

        return -999;
    }
}
