const {ccclass, property} = cc._decorator;

@ccclass
export default class AnimationAutoPlay extends cc.Component 
{
    @property(cc.Animation) ani: cc.Animation = null;

    protected onEnable(): void
    {
        this.ani.play();
    }
}
