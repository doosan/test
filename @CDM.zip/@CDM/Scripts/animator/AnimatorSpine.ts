import AnimatorSpineSecondary from "./AnimatorSpineSecondary";
import AnimatorBase, { AnimationPlayer } from "./core/AnimatorBase";
import AnimatorStateLogic from "./core/AnimatorStateLogic";

const { ccclass, property, requireComponent, disallowMultiple } = cc._decorator;

/** 
 * Spine状态机组件（主状态机），trackIndex为0
 */
@ccclass
@disallowMultiple
@requireComponent(sp.Skeleton)
export default class AnimatorSpine extends AnimatorBase 
{
    /** spine */
    private _spine: sp.Skeleton = null;
    /** 애니메이션 완료 콜백 */
    private _completeListenerMap: Map<(entry?: any) => void, any> = new Map();
    /** 두 번째 상태 머신 등록을 위한 콜백 */
    private _secondaryListenerMap: Map<(entry?: any) => void, AnimatorSpineSecondary> = new Map();

    protected start() 
    {
        if (!this.PlayOnStart || this._hasInit) 
        {
            return;
        }

        cc.log("AnimatorSpine:start() =>");

        this._hasInit = true;

        this._spine = this.getComponent(sp.Skeleton);
        this._spine.setCompleteListener(this.onSpineComplete.bind(this));

        if (this.AssetRawUrl !== null) 
        {
            this.initJson(this.AssetRawUrl.json);
        }
    }

    /**
     * 상태 머신을 수동으로 초기화하고 0-3개의 매개변수를 전달할 수 있으며 유형은 다음과 같습니다.
     *-onStateChangeCall 상태 전환 시 콜백
     *-stateLogicMap 각 상태 논리 제어
     *-animationPlayer 사용자 정의 애니메이션 컨트롤
     * @override
     */
    public onInit(...args: Array<Map<string, AnimatorStateLogic> | ((fromState: string, toState: string) => void) | AnimationPlayer>) 
    {
        if (this.PlayOnStart || this._hasInit) 
        {
            return;
        }

        cc.log("AnimatorSpine:onInit() =>");


        this._hasInit = true;

        this.initArgs(...args);

        this._spine = this.getComponent(sp.Skeleton);
        this._spine.setCompleteListener(this.onSpineComplete.bind(this));

        if (this.AssetRawUrl !== null) 
        {
            this.initJson(this.AssetRawUrl.json);
        }
    }

    private onSpineComplete(entry: any) 
    {
        cc.log("AnimatorSpine:onSpineComplete() =>");

        entry.trackIndex === 0 && this.onAnimFinished();
        this._completeListenerMap.forEach((target, cb) => { target ? cb.call(target, entry) : cb(entry); });
        this._secondaryListenerMap.forEach((target, cb) => { entry.trackIndex === target.TrackIndex && cb.call(target, entry); });
    }

    /**
     * 애니메이션 재생
     * @override
     * @param animName 애니메이션 이름
     * @param loop 루프에서 재생할지 여부
     */
    protected playAnimation(animName: string, loop: boolean) 
    {
        cc.log("AnimatorSpine:playAnimation() aniName =>"+animName);

        if (animName) 
        {
            this._spine.setAnimation(0, animName, loop);
        } 
        else 
        {
            this._spine.clearTrack(0);
        }
    }

    /**
     * 확대/축소 애니메이션 재생 속도
     * @override
     * @param scale 배율
     */
    public scaleTime(scale: number) 
    {
        this._spine.timeScale = scale;
    }

    /**
     * 2차 상태 머신의 애니메이션 종료를 위한 콜백 등록(상태 머신의 내부 메소드는 외부에서 직접 호출할 수 없음)
     */
    public addSecondaryListener(cb: (entry?: any) => void, target: AnimatorSpineSecondary) 
    {
        this._secondaryListenerMap.set(cb, target);
    }

    /**
     * 등록 애니메이션 완료 시 모니터링
     * @param cb 콜백
     * @param target 콜백을 호출하는 이 객체를 대상으로 합니다.
     */
    public addCompleteListener(cb: (entry?: any) => void, target: any = null) 
    {
        if (this._completeListenerMap.has(cb)) 
        {
            return;
        }
        
        this._completeListenerMap.set(cb, target);
    }

    /**
     * 애니메이션 완료 모니터링 로그오프
     * @param cb 콜백
     */
    public removeCompleteListener(cb: (entry?: any) => void) 
    {
        this._completeListenerMap.delete(cb);
    }

    /**
     * 애니메이션 완료 모니터링 지우기
     */
    public clearCompleteListener() 
    {
        cc.log("AnimatorSpine:clearCompleteListener() =>");


        this._completeListenerMap.clear;
    }
}
