import AnimatorBase, { AnimationPlayer } from "./core/AnimatorBase";
import AnimatorStateLogic from "./core/AnimatorStateLogic";

const { ccclass, property, requireComponent, disallowMultiple,menu } = cc._decorator;

/** 
 * Cocos 애니메이션 상태 머신 구성 요소
 */
@ccclass
@disallowMultiple
@requireComponent(cc.Animation)
@menu("Animator/Animator")
export default class Animator extends AnimatorBase 
{
    /** 현재 애니메이션 인스턴스 */
    private _animState: cc.AnimationState = null;    

    public get AnimState():cc.AnimationState
    {
        return this._animState;
    }

    /** wrapmode 저장 */
    private _wrapModeMap: Map<cc.AnimationState, cc.WrapMode> = new Map();



    protected onLoad() 
    {
        if (this._hasInit) 
        {
            return;
        }
        this._hasInit = true;

        if(null == this.animation)
        {
            this.animation = this.getComponent(cc.Animation);
        }

        this.animation.on(cc.Animation.EventType.FINISHED, this.onAnimFinished, this);
        this.animation.on(cc.Animation.EventType.LASTFRAME, this.onAnimFinished, this);

        if (this.AssetRawUrl !== null) 
        {
            this.initJson(this.AssetRawUrl.json);
        }

        // onload보다 먼저 호출된 경우 Process상 처리가 안된다.
        // key값을 저장한 후에 초기화한후 호출한다.
        if("" != this.KeepSetTriggerKey)
        {
            this.SetTrigger(this.KeepSetTriggerKey);
            this.KeepSetTriggerKey = "";
        }
    }

    onEnable()
    {
        if(false == this.animation.hasEventListener(cc.Animation.EventType.FINISHED))
            this.animation.on(cc.Animation.EventType.FINISHED, this.onAnimFinished, this);

        if(false == this.animation.hasEventListener(cc.Animation.EventType.LASTFRAME))
            this.animation.on(cc.Animation.EventType.LASTFRAME, this.onAnimFinished, this);
    }

    onDisable()
    {    
        //this.animation.setCurrentTime(0, this.animation.currentClip.name);
        this.animation.setCurrentTime(0);

        // 자동으로 state를 Reset하기 위해 추가 함. - doosan
        if(this.AutoReset)
        {
            if (this._hasInit && this.AutoUpdate)
            {
                this._ac.resetState();
            }
        }        
    }

    public resetState()
    {
        this.animation.setCurrentTime(0);
        this._ac.resetState();
    }


    /**
     * 상태 머신을 수동으로 초기화하고 0-3개의 매개변수를 전달할 수 있으며 유형은 다음과 같습니다.
     *-onStateChangeCall 상태 전환 시 콜백
     *-stateLogicMap 각 상태 논리 제어
     *-animationPlayer 사용자 정의 애니메이션 컨트롤
     * @override
     */
    public onInit(...args: Array<Map<string, AnimatorStateLogic> | ((fromState: string, toState: string) => void) | AnimationPlayer>) 
    {
        if (this.PlayOnStart || this._hasInit) 
        {
            return;
        }

        //cc.log("AnimatorCustomization:onInit() =>");

        this._hasInit = true;

        this.initArgs(...args);

        if(null == this.animation)
        {
            this.animation = this.getComponent(cc.Animation);
        }
        this.animation.on(cc.Animation.EventType.FINISHED, this.onAnimFinished, this);
        this.animation.on(cc.Animation.EventType.LASTFRAME, this.onAnimFinished, this);

        if (this.AssetRawUrl !== null) 
        {
            this.initJson(this.AssetRawUrl.json);
        }
    }

    /**
     * 애니메이션 재생
     * @override
     * @param animName 애니메이션 이름
     * @param loop 루프에서 재생할지 여부
     */
    protected playAnimation(animName: string, loop: boolean) 
    {
        if (!animName) 
        {
            return;
        }

        //cc.log("AnimatorCustomization:playAnimation() animName=>"+animName);
        
        this._animState = this.animation.play(animName);
        if (!this._animState) 
        {
            return;
        }       


        if (!this._wrapModeMap.has(this._animState)) 
        {
            this._wrapModeMap.set(this._animState, this._animState.wrapMode);
        }
        this._animState.wrapMode = loop ? cc.WrapMode.Loop : this._wrapModeMap.get(this._animState);
    }

    /**
     * 확대/축소 애니메이션 재생 속도
     * @override
     * @param scale 배율
     */
    public scaleTime(scale: number) 
    {
        if (this._animState) 
        {
            this._animState.speed = scale;            
        }
    }

    public Pause():void
    {
        if (this._animState) 
        {
            this._animState.pause();
        }
    }

    public Resume():void
    {
        if (this._animState) 
        {
            this._animState.resume();
        }
    }
}
