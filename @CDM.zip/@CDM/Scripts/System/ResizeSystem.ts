import SingleObjects from "./SingleObjects";
import InstanceEvent from "./InstanceEvent";

const { ccclass, property } = cc._decorator;

@ccclass
export default class ResizeSystem extends cc.Component
{
    static instance: ResizeSystem;

    static get Instance(): ResizeSystem
    {
        if (ResizeSystem.instance != null)
        {
            return ResizeSystem.instance;
        }

        let newNode = new cc.Node("ResizeSystem");
        ResizeSystem.instance = newNode.addComponent(ResizeSystem);        
        cc.game.addPersistRootNode(newNode);
        newNode.setParent(SingleObjects.Instance.node);

        return ResizeSystem.instance;
    }

    private instanceEvent : InstanceEvent = new InstanceEvent();
    private subInstanceEvent : InstanceEvent = new InstanceEvent();
    private subbInstanceEvent : InstanceEvent = new InstanceEvent();

    onLoad()
    {
        cc.view.setResizeCallback(this.EmitEvent.bind(this));
    }

    public EmitEvent()
    {
        this.instanceEvent.Invoke();
        this.subInstanceEvent.Invoke();
        this.subbInstanceEvent.Invoke();
    }

    public AddEvent(callback : Function, taget? : any)
    {
        this.instanceEvent.AddListener(callback, taget);
    }

    public RemoveEvent(callback : Function, taget? : any)
    {
        this.instanceEvent.RemoveListener(callback, taget);
    }

    public AddSubEvent(callback : Function, taget? : any)
    {
        this.subInstanceEvent.AddListener(callback, taget);
    }

    public RemoveSubEvent(callback : Function, taget? : any)
    {
        this.subInstanceEvent.RemoveListener(callback, taget);
    }

    public AddSubbEvent(callback : Function, taget? : any)
    {
        this.subbInstanceEvent.AddListener(callback, taget);
    }

    public RemoveSubbEvent(callback : Function, taget? : any)
    {
        this.subbInstanceEvent.RemoveListener(callback, taget);
    }
}