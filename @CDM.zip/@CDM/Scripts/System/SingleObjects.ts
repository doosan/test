
const { ccclass, property } = cc._decorator;

@ccclass
export default class SingleObjects extends cc.Component
{
    static instance: SingleObjects;

    static get Instance(): SingleObjects
    {
        if (SingleObjects.instance != null)
        {
            return SingleObjects.instance;
        }
        
        let newNode = new cc.Node("SingleObjects");
        SingleObjects.instance = newNode.addComponent(SingleObjects);
        let widget = newNode.addComponent(cc.Widget);
        widget.alignMode = cc.Widget.AlignMode.ON_WINDOW_RESIZE;
        widget.isAlignTop = true;
        widget.isAlignBottom = true;
        widget.isAlignLeft = true;
        widget.isAlignRight = true;
        widget.top = 0;
        widget.bottom = 0;
        widget.left = 0;
        widget.right = 0;

        newNode.parent = null;
        cc.game.addPersistRootNode(newNode);

        return SingleObjects.instance;
    }
}
