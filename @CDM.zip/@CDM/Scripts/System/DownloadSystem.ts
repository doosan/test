import CoroutineComponent, { WaitForSeconds }  from "./CoroutineComponent";
import InstanceEvent from "./InstanceEvent";
import ObjectPool from "../ObjectPool/ObjectPool";
import { Util } from "../Util/Util";
import SingleObjects from "./SingleObjects";
import StringUtils from "../Util/StringUtils";

const { ccclass, property } = cc._decorator;

export class Task
{
    public OnDownloadComplete: InstanceEvent = new InstanceEvent();

    public id: string = '';
    public isEnabled: boolean = false;
    public url: string = '';
    public useCache: boolean = false;
    public type: any = null;

    public callback: Function = null;
    //public callbackMethodTarget: cc.Object;
    //public callbackMethodInfo: MethodInfo;
    public retryCount: number = 0;    

    public Done(): void
    {
        if (this.OnDownloadComplete != null)
        {
            this.OnDownloadComplete.Invoke(this.url);
        }
    }

    public Reset(): void
    {
        this.isEnabled = false;
        this.OnDownloadComplete.RemoveAllListeners();
        this.callback = null;
        this.retryCount = 0;
    }
}

export class ID
{
    public value: string = "";
}

@ccclass
export default class DownloadSystem extends CoroutineComponent
{
    static instance: DownloadSystem;

    static get Instance(): DownloadSystem
    {
        if (DownloadSystem.instance != null)
        {
            return DownloadSystem.instance;
        }

        let newNode = new cc.Node("DownloadSystem");
        DownloadSystem.instance = newNode.addComponent(DownloadSystem);
        cc.game.addPersistRootNode(newNode);
        newNode.setParent(SingleObjects.Instance.node);

        return DownloadSystem.instance;
    }

    private readonly MAX_RETRY: number = 3;

    public OnStart: InstanceEvent = new InstanceEvent();
    public OnSuccess: InstanceEvent = new InstanceEvent();
    public OnFail: InstanceEvent = new InstanceEvent();

    private idCount: number = 0;
    private taskPool: ObjectPool<Task> = null;
    private taskList: Array<Task> = null;
    private resourceParam: cc.Asset[] = null;
    private isDownloading: boolean = false;
    private tempTaskList: Array<Task> = null;

    private spriteCache: Map<string, cc.SpriteFrame> = null;  

    public Initialize(): void
    {
        this.idCount = 10000;
        this.resourceParam = [];
        this.resourceParam.push(new cc.Asset());
        this.taskList = [];
        this.tempTaskList = [];

        this.taskPool = new ObjectPool<Task>(10
            , () =>
            {
                return new Task();
            });

        this.spriteCache = new Map<string, cc.SpriteFrame>(); 
    }

    private CreateID(): ID
    {
        if (this.idCount == Number.MAX_SAFE_INTEGER)
        {
            this.idCount = 10000;
        }

        this.idCount++;

        var id = new ID();
        id.value = this.idCount.toString();
        return id;
    }

    public Abort(id: ID): void
    {
        for (let i = 0; i < this.taskList.length; i++)
        {
            var targetTask = this.taskList[i];

            if (targetTask.id == id.value)
            {
                targetTask.isEnabled = false;
                break;
            }
        }
    }

    public AbortAll(): void
    {
        for (let i = 0; i < this.taskList.length; i++)
        {
            var targetTask = this.taskList[i];
            targetTask.isEnabled = false;
        }
    }

    public HasCachedSprite(url: string): boolean
    {
        return this.spriteCache.has(url);
    }

    public RemoveCachedSprite(url: string, destroyImmediate: boolean = true): void
    {
        if (this.spriteCache.has(url) == false)
        {
            return;
        }

        if (destroyImmediate)
        {
            var sprite = this.spriteCache.get(url);
            
            // var tex = sprite.texture;
            // Texture2D.DestroyImmediate(tex);
            // GameObject.DestroyImmediate(sprite);

        }

        this.spriteCache.delete(url);
    }


    public GetCachedSprite(url: string): cc.SpriteFrame
    {
        return this.HasCachedSprite(url) ? this.spriteCache.get(url) : null;
    }

    public GetSprite(url: string, onComplete: Function, useCache: boolean = false): ID
    {
        if (useCache == true && this.HasCachedSprite(url) == true)
        {
            onComplete(this.GetCachedSprite(url));
            return new ID();
        }
        else
        {
            if (StringUtils.IsNullOrEmpty(url))
            {
                if (onComplete != null)
                {
                    onComplete(null, new ID());
                }
                return new ID();
            }
            let id = this.AddTask<cc.SpriteFrame>(cc.SpriteFrame, url, onComplete, useCache);
            this.StartDownload();

            return id;
        }
    }

    private AddTask<T extends cc.Asset>(type: { new(): T }, url: string, onComplete: Function, useCache: boolean): ID
    {
        if (StringUtils.IsNullOrEmpty(url))
        {
            if (onComplete != null)
            {
                onComplete(null);
            }
            return new ID();
        }

        var id = this.CreateID();

        var task = this.taskPool.Get();
        task.id = id.value;
        task.isEnabled = true;
        task.url = url;
        task.useCache = useCache;
        task.type = type;

        Object.setPrototypeOf(type, type.prototype);

        if (onComplete != null)
        {
            task.callback = onComplete;
            //task.callbackMethodTarget = onComplete.Target;
        }

        this.taskList.push(task);

        return id;
    }

    private RemoveTask(task: Task): void
    {
        task.Reset();
        let listIndex = this.taskList.findIndex(x => x == task);
        if (listIndex != -1)
        {
            this.taskList.splice(listIndex, 1);
        }
        this.taskPool.Return(task);
    }

    private StartDownload(): void
    {
        if (this.isDownloading == true)
        {
            return;
        }

        this.startCoroutine(this.DownloadCoroutine(), this);
    }

    *DownloadCoroutine()
    {
        this.isDownloading = true;

        while (this.taskList.length > 0)
        {
            var task = this.taskList[0];
            this.resourceParam[0] = null;

            if (task.isEnabled == false)
            {
                this.RemoveTask(task);
                continue;
            }

            cc.log("------------------------------------------------------------");
            if (task.retryCount == 0)
            {
                cc.log(StringUtils.Format("Download Start - type : {0} , url : {1}", task.type, task.url));
            }
            else
            {
                cc.log(StringUtils.Format("Download Retry - type : {0} , url : {1} retryCount: {2}", task.type, task.url, task.retryCount));
            }

            if (task.type instanceof cc.SpriteFrame)
            {
                yield this.DownloadTexture(task, this.resourceParam);
            }
            else
            {
                cc.log('not spriteFrame');
            }

            if (!task.isEnabled)
            {
                cc.log("Download Aborted");
            }
            else if (this.resourceParam[0] == null)
            {
                cc.log("Download Failed");
                if (task.retryCount < this.MAX_RETRY)
                {
                    task.retryCount++;
                    cc.log("Download retry");
                    continue;
                }
                else
                {
                    if (this.OnFail != null)
                    {
                        this.OnFail.Invoke(task.url);
                    }
                }

            }
            else
            {
                cc.log("Download Success");
                if (this.OnSuccess != null)
                {
                    this.OnSuccess.Invoke(task.url);
                }
            }

            for (let i = 0; i < this.taskList.length; i++)
            {
                var targetTask = this.taskList[i];

                if (targetTask.url == task.url)
                {
                    if (targetTask.isEnabled == true)
                    {
                        if (targetTask.callback != null)
                        {
                            if (task.type instanceof cc.SpriteFrame)
                            {
                                targetTask.callback(this.resourceParam[0]);
                            }

                        }

                        targetTask.Done();
                    }

                    this.tempTaskList.push(targetTask);
                }
            }

            for (let i = 0; i < this.tempTaskList.length; i++)
            {
                this.RemoveTask(this.tempTaskList[i]);
            }

            this.tempTaskList = [];
        }

        this.isDownloading = false;
    }

    AsyncDownloadTexture(task: Task, returnVal: cc.Asset[]): Promise<cc.SpriteFrame>
    {
        return new Promise((resolve, reject) => 
        {
            cc.assetManager.loadRemote<cc.Texture2D>(task.url, {ext: '.png'}, (err, texture) =>
            {
                if (err == null)
                {
                    let spriteFrame: cc.SpriteFrame = new cc.SpriteFrame(texture);
                    returnVal[0] = spriteFrame;
                    if (task.useCache == true)
                    {
                        this.spriteCache.set(task.url, spriteFrame);
                    }
                    resolve(spriteFrame);
                }
                else
                {
                    resolve(null);
                }
            });
        });
    }

    *DownloadTexture(task: Task, returnVal: cc.Asset[])
    {
        if (this.OnStart != null)
        {
            this.OnStart.Invoke(task.url);
        }
        yield Util.waitForPromise<cc.SpriteFrame>(this.AsyncDownloadTexture(task, returnVal), this);
    }

    //     using(UnityWebRequest uwr = UnityWebRequest.Get(task.url))
    //     {
    //         DownloadHandlerTexture textureHandler = new DownloadHandlerTexture(true);
    //         uwr.downloadHandler = textureHandler;

    //         yield return uwr.SendWebRequest();

    //         if (!(uwr.isNetworkError || uwr.isHttpError) && task.enabled == true)
    //         {
    //             Texture2D tex2D = textureHandler.texture;
    //             Sprite sprite = Sprite.Create(tex2D, new Rect(0, 0, tex2D.width, tex2D.height), new Vector2(0.5f, 0.5f), 100);
    //             returnVal[0] = sprite;

    //             if (task.useCache == true)
    //             {
    //                 spriteCache[task.url] = sprite;
    //             }
    //         }
    //     }
    // }

    public HasTask(url: string): boolean
    {
        return this.GetTask(url) != null;
    }

    private GetTask(url: string): Task
    {
        let found: Task = null;
        for (let i = 0; i < this.taskList.length; i++)
        {
            var task = this.taskList[i];
            if (task.isEnabled == true && task.url == url)
            {
                found = task;
                break;
            }
        }

        return found;
    }

    public GetDownloadID(url: string): ID
    {
        var id = new ID();
        var task = this.GetTask(url);
        if (task != null)
        {
            id.value = task.id;
        }

        return id;
    }

    public AddTaskListener(url: string, downloadHandler: Function): void
    {
        if (downloadHandler == null)
        {
            return;
        }

        let task: Task = this.GetTask(url);
        if (task == null)
        {
            if (downloadHandler != null)
            {
                downloadHandler(url);
            }
        }
        else
        {
            task.OnDownloadComplete.AddListener(() => downloadHandler.bind(this), this);
        }
    }
    //IEnumerable<string>
    public LoadSprites(urls, onComplete: Function = null): void
    {
        urls.forEach(url => 
        {
            this.LoadSprite(url, onComplete);
        }, this);
    }

    public LoadSprite(url: string, onComplete: Function = null): void
    {
        if (this.HasCachedSprite(url) == true)
        {
            if (onComplete != null)
            {
                onComplete(url);
            }
            return;
        }

        if (this.HasTask(url) == false)
        {
            this.AddTask<cc.SpriteFrame>(cc.SpriteFrame, url, null, true);
        }

        this.AddTaskListener(url, onComplete);
        this.StartDownload();
    }
}
