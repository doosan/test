
export default class PrefsManager
{
    public static SetLocalValue(key: string, value: any): void
    {
        cc.sys.localStorage.setItem(key, value);
    }

    public static GetLocalValue(key: string, defaultValue?: any): any
    {
        var rv = cc.sys.localStorage.getItem(key);

        if (rv == null || rv == undefined)
        {
            if(defaultValue!=null)
            {
                this.SetLocalValue(key, defaultValue);
            }
        }

        return rv;
    }

    public static DeleteLocalValue(key: string): void
    {
        cc.sys.localStorage.removeItem(key);
    }

    public static DeleteAllLocalValues(): void
    {
        cc.sys.localStorage.clear();
    }
}
