/**
 * @example 
 * const startEvent = new InstanceEvent();
 * startEvent.AddListener(this.onStart, this);  - 일반호출
 * startEvent.AddListenerOnce(this.onStart, this) - 한번만 호출
 * startEvent.Invoke();
 * startEvent.RemoveListener(this.onStart, this);
 */

interface Subscription 
{
    callback: Function;
    target: any;
}

export default class InstanceEvent 
{
    private events: Array<Subscription> = null;
    private onceEvents: Array<Subscription> = null;

    public get IsEventEmpty() : boolean
    {
        return this.events.length == 0 && this.onceEvents.length == 0;
    }

    constructor() 
    {
        this.events = new Array<Subscription>();
        this.onceEvents = new Array<Subscription>();
    }

    public AddListener(callback: Function, target: any) 
    {
        this.events.push({ callback, target });
    }
    
    public AddListenerOnce(callback: Function, target: any) 
    {
        this.onceEvents.push({ callback, target });
    }

    public RemoveListener(callback: Function, target: any) 
    {
        for (let i = 0; i < this.events.length; i++) 
        {
            if (this.events[i].callback.name === callback.name && (!target || this.events[i].target === target)) 
            {
                this.events.splice(i, 1);
            }
        }
        
        // 일회성 이벤트
        for (let i = 0; i < this.onceEvents.length; i++) 
        {
            if (this.onceEvents[i].callback === callback && (!target || this.onceEvents[i].target === target)) 
            {
                this.onceEvents.splice(i, 1);
            }
        }
    }
    
    public Invoke(...args: any[]) 
    {
        let promises = [];
        //for (let i = this.events.length-1; i >= 0 ; --i) 
        // for (let i = 0; i < this.events.length ; i++) 
        // {
        //     promises.push(this.events[i].callback.apply(this.events[i].target, args));


        // }

        // 일회성 이벤트
        for (let i = this.onceEvents.length-1; i >= 0; --i) 
        {
            promises.push(this.onceEvents[i].callback.apply(this.onceEvents[i].target, args));
        }

        this.onceEvents.length = 0;
        
        let total_count = this.events.length;
        let index = 0;
        while(index < total_count)
        {
            this.events[index].callback.apply(this.events[index].target, args);
            if(this.events.length == total_count)
            {
                index++;
            }
            else
            {
                total_count = this.events.length;
            }
        }
        
        //promises = promises.reverse();
        //return Promise.all(promises);
    }

    public Invoke_return(...args: any[]):any
    {       
        let Value:any = null;

        //for (let i = this.onceEvents.length-1; i >= 0; --i) 
        if(null != this.onceEvents[0])
        {
            Value = this.onceEvents[0].callback.apply(this.onceEvents[0].target, args);
        }

        //this.onceEvents.length = 0;

        return Value;
    }
    
    public RemoveAllListeners() 
    {
        this.events.length = 0;
        this.onceEvents.length = 0;
    }
}