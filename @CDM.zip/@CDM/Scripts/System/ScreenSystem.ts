import SingleObjects from "./SingleObjects";

const { ccclass, property } = cc._decorator;

export enum ScreenMatchMode
{
    None,
    Width,
    Height
}

export enum Orientation
{
    Landscape,
    Portrait,
    None,
}

@ccclass
export default class ScreenSystem extends cc.Component
{
    static instance: ScreenSystem;

    static get Instance(): ScreenSystem
    {
        if (ScreenSystem.instance != null)
        {
            return ScreenSystem.instance;
        }

        let newNode = new cc.Node("ScreenSystem");
        ScreenSystem.instance = newNode.addComponent(ScreenSystem);
        let widget = newNode.addComponent(cc.Widget);
        widget.alignMode = cc.Widget.AlignMode.ON_WINDOW_RESIZE;
        widget.isAlignTop = true;
        widget.isAlignBottom = true;
        widget.isAlignLeft = true;
        widget.isAlignRight = true;
        widget.top = 0;
        widget.bottom = 0;
        widget.left = 0;
        widget.right = 0;

        cc.game.addPersistRootNode(newNode);
        newNode.setParent(SingleObjects.Instance.node);

        return ScreenSystem.instance;
    }

    public CurrentOrienation: Orientation = Orientation.None;
    public static get IsLandscape(): boolean { return this.Instance.CurrentOrienation == Orientation.Landscape; }
    public static get IsPortrait(): boolean { return this.Instance.CurrentOrienation == Orientation.Portrait; }

    
    //public verticalCanvasScaler : VerticalCanvasScaler = null;

    public nodeList: cc.Node[] = [];

    screenAdapter() 
    {

    }

    public Initialize()
    {
        cc.resources.load<cc.Prefab>("Black", cc.Prefab, function (err, prefab: cc.Prefab)
        {
            if (err == null)
            {
                let screenObject = cc.instantiate(prefab);
                screenObject.setParent(ScreenSystem.Instance.node);
                ScreenSystem.Instance.AddNode(screenObject);
            }
            else
            {
                cc.error(err);
            }
        });
    }

    public AddNode(node: cc.Node)
    {
        this.nodeList.push(node);
    }

    public SetPortrait(excute : boolean = true)
    {
        this.CurrentOrienation = Orientation.Portrait;
        // if(excute)
        // {
        //     cc.view["_resizeEvent"](true);
        // }
    }

    public SetLandscape(excute : boolean = true)
    {
        this.CurrentOrienation = Orientation.Landscape;
        if(excute)
        {
            cc.view["_resizeEvent"](true);
        }
    }

    public Restore()
    {
        this.CurrentOrienation = Orientation.Portrait;
        cc.view["_resizeEvent"](true);
    }

    public Rotate()
    {
        this.nodeList.forEach(node=>
        {
            node.angle = 90;
            node.setContentSize(cc.Canvas.instance.node.height, cc.Canvas.instance.node.width);
        }, this);
    }

    public ReRotate()
    {
        this.nodeList.forEach(node=>
        {
            node.angle = 0;
            node.setContentSize(cc.Canvas.instance.node.width, cc.Canvas.instance.node.height);
        }, this);
    }

    //public get Node() : cc.Node {return this.node}
}
