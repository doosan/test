import GlobalData from "../../../Scripts/GlobalData";

const { ccclass, property, executionOrder } = cc._decorator;

export type CoroutineValidator = cc.Component | Func0<boolean> | null | cc.Node;

//type CoroutineIterator = IterableIterator<undefined | WaitForSeconds | IterableIterator<any> | Coroutine>;
type CoroutineIterator = IterableIterator<any>;
export class WaitForSeconds extends cc.ValueType
{
    sec: number;

    constructor(sec: number) 
    {
        super();
        this.sec = sec;
    }
}

// 매개변수인  함수가 true를 반환할 때까지 계속 돌다가 true를 반환하면 루틴을 통과하게 된다.
export class WaitUntil
{
    call:Function;
    constructor(call:Function) 
    {
        this.call = call;
    }
}

// 매개변수인  함수가 false를 반환할 때까지 계속 돌다가 false를 반환하면 루틴을 통과하게 된다.
export class WaitWhile
{
    call:Function;
    constructor(call:Function) 
    {
        this.call = call;
    }
}

export class Coroutine 
{
    private static idMaker = 1;

    id: number;
    iterator: CoroutineIterator;
    
    validator: CoroutineValidator;
    private _done: boolean;

    firstFrame?: boolean;
    availableTiming?: number;

    ucallback?:Function;    // Until Callback
    wcallback?:Function;    // While Callback

    isDone : boolean;

    nextedCoroutine: Coroutine;
    nextedCoroutineDoneValue: any;
    private promiseResolves: Action0[] = [];

    constructor(iterator: CoroutineIterator, validator: CoroutineValidator) 
    {
        this.id = Coroutine.idMaker++;

        this.iterator = iterator;
        this.validator = validator;

        this.done = false;
    }

    get done() 
    { 
        return this._done; 
    }
    set done(value: boolean) 
    {
        this._done = value;
        if (value === true) 
        {
            this.promiseResolves.forEach(r => r(), this);
            this.promiseResolves.length = 0;
        }
    }

    getDonePromise() 
    {
        return new Promise<void>(resolve => this._done ? resolve() : this.promiseResolves.push(resolve));
    }
}
@ccclass
export default class CoroutineComponent extends cc.Component 
{
    coroutiness: Coroutine[] = [];
    totalElapsed = 0;

    startCoroutine(iterator: CoroutineIterator, validator?: CoroutineValidator): Coroutine 
    {
        if(null == iterator)
        {
            cc.error("startCoroutine에 등록된 함수가 Generator Function이 맞는지 체크해야 합니다.")
        }

        return this._startCoroutine(iterator, this);
    }

    onDisable()
    {
        if(!GlobalData.isLoading)
        {
            this.stopAllCoroutines();
        }
    }

    stopCoroutine(coroutine: Coroutine) 
    {
        this._removeCoroutine(coroutine);
    }

    stopAllCoroutines()
    {
        this.coroutiness.length = 0;
    }

    update(dt: number) 
    {
        if(!cc.sys.isMobile)
        if (document.visibilityState === 'hidden') {
            dt = 0.016666666665;
        }
        this.lateUpdateRender(dt);
    }

    lateUpdateRender(dt: number) 
    {
        this.totalElapsed += dt;
        if (this.coroutiness.length === 0) 
        {
            return;
        }

        let coroutines = this.coroutiness.slice(0);
        for (let i = 0; i < coroutines.length; i++) 
        {
            let c = coroutines[i];
            let done = this.runOnce(c);
            if (done) 
            {
                this._removeCoroutine(c);
            }
        }
    }

    protected _startCoroutine(iterator: CoroutineIterator, validator: CoroutineValidator) : Coroutine
    {
        let cs = new Coroutine(iterator, validator);
        let done = this.runOnce(cs);
        if (!done) 
        {
            cs.firstFrame = true;
            this.coroutiness.push(cs);
        }

        return cs;
    }

    protected _removeCoroutine(coroutine: Coroutine) 
    {
        let coroutines = this.coroutiness;
        for (let i = 0; i < coroutines.length; i++) 
        {
            let c = coroutines[i];
            if (c === coroutine) 
            {
                coroutines.splice(i, 1);
                break;
            }
        }
    }

    protected runOnce(cor: Coroutine): { doneValue: any } | undefined 
    {
        if (cor. validator !== null) 
        {
            if (cor.validator instanceof cc.Component) 
            {
                if (!cor.validator.node || !cor.validator.node.activeInHierarchy) 
                {
                    cor.done = true;
                    return { doneValue: undefined }
                };
            } 
            else if (typeof cor.validator === "function" && !(cor.validator as Func0<boolean>)()) 
            {
                cor.done = true;
                return { doneValue: undefined };
            } 
            else if (cor.validator instanceof cc.Node) 
            {
                if (!cor.validator || !cor.validator.activeInHierarchy) 
                {
                    cor.done = true;
                    return { doneValue: undefined }
                };
            }
        }       

        if (cor.nextedCoroutine) 
        {
            let done = this.runOnce(cor.nextedCoroutine);
            if (done) 
            {
                delete cor.nextedCoroutine;
                cor.nextedCoroutineDoneValue = done.doneValue;
            } 
            else 
            {
                return;
            }
        }

        if (cor.firstFrame) 
        {
            cor.firstFrame = false;
            return;
        }

        // 값이 false이면 리턴한다.
        if(cor.ucallback != null && false == cor.ucallback())
        {
            return;
        }

        // 사용했으면 값을 초기화시킨다.(2022.03.21)
        if(cor.ucallback != null && true == cor.ucallback())
        {
            cor.ucallback = null;
        }

        // 값이 true이면 리턴한다.
        if(cor.wcallback != null && true == cor.wcallback())
        {
            return;
        }

        // 사용했으면 값을 초기화시킨다.(2022.03.21)
        if(cor.wcallback != null && false == cor.wcallback())
        {
            cor.wcallback = null;
        }

        if(cor.isDone != null && !cor.isDone)
        {
            return;
        }

        if (cor.availableTiming && cor.availableTiming > this.totalElapsed) 
        {
            return;
        }
        
        let next = cor.iterator.next(cor.nextedCoroutineDoneValue);
        
        delete cor.nextedCoroutineDoneValue;
        if (next.done) 
        {
            cor.done = true;
            return { doneValue: next.value };
        } 
        else if (!next.value) 
        {
            return;
        } 
        else if (next.value instanceof WaitUntil) 
        {
            cor.ucallback = next.value.call;
            //next.value = null;
        }
        else if (next.value instanceof WaitWhile) 
        {
            cor.wcallback = next.value.call;
            //next.value = null;
        }
        else if (next.value instanceof WaitForSeconds) 
        {
            cor.availableTiming = this.totalElapsed + next.value.sec;
        } 
        else if (next.value instanceof Coroutine) 
        {
            this._removeCoroutine(next.value);
            cor.nextedCoroutine = next.value;
        } 
        // babel이 번역해준 것에서는 generator가 [object Generator]였는데 지금은typescript가 번역해 주며, [object Object]로 온다. 흠...
        else if (next.value.toString() === "[object Object]" || next.value.toString() === "[object Generator]") 
        { 
            let cs = new Coroutine(next.value, cor.validator);
            let done = this.runOnce(cs);
            if (!done) 
            {
                cor.nextedCoroutine = cs;
            }
        } 
        else 
        {
            throw "Wrong yield";
        }
        return;
    }
}
