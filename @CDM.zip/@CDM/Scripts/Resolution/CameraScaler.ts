import ResizeSystem from "../System/ResizeSystem";

const { ccclass, property } = cc._decorator;

@ccclass
export default class CameraScaler extends cc.Component 
{
    onLoad() 
    {
        ResizeSystem.Instance.AddEvent(this.screenAdapter.bind(this), this);
        this.screenAdapter();
    }

    onDestroy()
    {
        ResizeSystem.Instance.RemoveEvent(this.screenAdapter.bind(this), this);
    }

    screenAdapter() 
    {
        //Current screen resolution scale
        let screenRatio = cc.view.getFrameSize().width / cc.view.getFrameSize().height;
        //Resolution ratio of design draft
        let designRatio1 = cc.Canvas.instance.designResolution.width / cc.Canvas.instance.designResolution.height;

        let designRatio2 = cc.Canvas.instance.designResolution.width / 960;

        //The screen height is greater than or equal to the width, i.e. vertical screen
        if (screenRatio <= designRatio2) 
        {
            let ratio: number = (720 * cc.view.getFrameSize().width) / cc.Canvas.instance.designResolution.width / cc.view.getFrameSize().height;
            this.node.getComponent(cc.Camera).zoomRatio = ratio;
        }
        else if (screenRatio < designRatio1) 
        {
            let ratio: number = (cc.Canvas.instance.designResolution.height * cc.view.getFrameSize().width) / cc.Canvas.instance.designResolution.width / cc.view.getFrameSize().height;

            this.node.getComponent(cc.Camera).zoomRatio = ratio;
        }
        else
        {
            this.node.getComponent(cc.Camera).zoomRatio = 1;
        }
    }

    setFitWidth()
    {
        cc.Canvas.instance.fitHeight = false;
        cc.Canvas.instance.fitWidth = true;
    }

    setFitHeight()
    {
        cc.Canvas.instance.fitHeight = true;
        cc.Canvas.instance.fitWidth = false;
    }

    // update (dt) {}
}
