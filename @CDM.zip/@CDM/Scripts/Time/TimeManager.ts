import { Time } from "./Time";

const { ccclass, property, executionOrder } = cc._decorator;

@ccclass @executionOrder(-99) export class TimeManager extends cc.Component 
{
    update(dt: number) 
    {
        Time.update(dt);      
    }
}