import CoroutineComponent  from "../System/CoroutineComponent";
import { Coroutine, WaitForSeconds } from "../System/CoroutineComponent";
import SingleObjects from "../System/SingleObjects";
import InstanceEvent from "../System/InstanceEvent";

const { ccclass, property } = cc._decorator;

@ccclass
export default class GlobalTime extends CoroutineComponent
{
    static instance: GlobalTime;

    static get Instance(): GlobalTime
    {
        if (GlobalTime.instance != null)
        {
            return GlobalTime.instance;
        }

        let newNode = new cc.Node("GlobalTime");
        GlobalTime.instance = newNode.addComponent(GlobalTime);

        newNode.parent = null;
        cc.game.addPersistRootNode(newNode);
        newNode.setParent(SingleObjects.Instance.node);
        return GlobalTime.instance;
    }

    public onUpdate: InstanceEvent = new InstanceEvent();

    private timeStamp: number = 0;
    private tempTimeStamp: number = 0;
    private needSync: boolean = false;
    private isStart: boolean = false;
    private pauseTime: number = 0;

    private coroutine: Coroutine = null;

    onLoad()
    {
        cc.game.on(cc.game.EVENT_SHOW, ()=> 
        {
            this.OnApplicationPause(false);
        }, this);

        cc.game.on(cc.game.EVENT_HIDE, ()=> 
        {
            this.OnApplicationPause(true);
        }, this);
    }

    public Dispose(): void
    {
        this.isStart = false;
        this.StopTime();
    }

    private StartTimer(): void
    {
        this.StopTime();
        this.coroutine = this.startCoroutine(this.UpdateTimeStamp(), this);
    }

    private StopTime(): void
    {
        if(this.coroutine != null)
        {
            this.stopCoroutine(this.coroutine);
        }
    }

    public SetTimeStamp(ts: number): void
    {
        if (ts == this.tempTimeStamp)
        {
            return;
        }

        this.tempTimeStamp = ts;
        this.needSync = true;

        if (this.isStart == false)
        {
            this.isStart = true;
            this.StartTimer();
        }
    }

    public GetTimeStamp(): number
    {
        return Math.trunc(this.timeStamp);
    }

    public SecondDiff(to: number): number
    {
        if(to==null)
        {
            return 0;
        }
        
        let sec: number = to - this.timeStamp;
        if (sec < 0)
        {
            sec = 0;
        }

        return sec;
    }

    *UpdateTimeStamp()
    {
        this.timeStamp = this.tempTimeStamp;

        let ts: number = 0;

        while (true)
        {
            if (this.needSync)
            {
                ts = this.tempTimeStamp;
                this.needSync = false;
            }

            yield new WaitForSeconds(1);//  WaitForSecondsRealtime(1.0);
            ts++;

            this.timeStamp = ts;

            if (this.onUpdate != null)
            {
                this.onUpdate.Invoke(this.timeStamp);
            }
        }
    }
    
    private OnApplicationPause(pause : boolean)
    {
        if (this.isStart == false)
        {
            return;
        }

        if (pause)
        {
            this.pauseTime = Date.now() * 0.001;
        }
        else
        {
            let pauseEndTime = Date.now() * 0.001;
            
            let elapsedTime = (pauseEndTime - this.pauseTime);//.TotalSeconds;
            let currentTS = elapsedTime + this.timeStamp;

            if(cc.sys.isMobile)
                this.SetTimeStamp(currentTS);
        }
    }
}
