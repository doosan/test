export class Time 
{
    protected static _time = 0;

    protected static TimeScale = 1; // 아직 사용하지는 않음.

    static get deltaTime() 
    {
        return cc.director.getDeltaTime();
    }
    
    static get timeScale():number
    {
        return Time.TimeScale;
    }

    static set timeScale(value:number) 
    {
        Time.TimeScale = value;        
    }

    static get time() 
    {
        return Time._time;
    }

    static get utcNow(): number 
    {
        return cc.sys.now();
    }

    static update(dt: number) 
    {
        // cc.director.getDeltaTime() 와 dt는 항상 같은 값이 온다.
        Time._time += dt;
        this._frameCount++;
    }

    static resetTime()
    {
        Time._time = 0;
    }

    //The total number of frames that have passed (Read Only).
    // same as unity3D Time.frameCount
    private static _frameCount = 0;
    static get frameCount(): number 
    {
        return this._frameCount;
    }
}