import InstanceEvent from "../System/InstanceEvent";
import PrefsManager from "../System/PrefsManager";

export default class MySettings
{
    public static onAutoFreeGameAndFeature: InstanceEvent = new InstanceEvent();

    public static onBgmVolume: InstanceEvent = new InstanceEvent();
    public static onSoundVolume: InstanceEvent = new InstanceEvent();

    public static onVibrate: InstanceEvent = new InstanceEvent();
    public static onAlwaysScreenOn: InstanceEvent = new InstanceEvent();
    public static onPlayersMessage: InstanceEvent = new InstanceEvent();
    public static onBroadcastAlarm: InstanceEvent = new InstanceEvent();

    private static readonly KEY_BGM_VOLUME: string = "k_b_volume";
    private static readonly KEY_SOUND_VOLUME: string = "k_s_volume";
    private static readonly KEY_VIBRATE: string = "k_vibrate";
    private static readonly KEY_ALWAYS_SCREEN_ON: string = "k_a_s_on";
    private static readonly KEY_BROADCAST_ALARM: string = "k_b_alarm";

    private static readonly VALUE_DEFAULT_BGM_VOLUME: number = 1;
    private static readonly VALUE_DEFAULT_SOUND_VOLUME: number = 1;
    private static readonly VALUE_DEFAULT_VIBRATE: number = 0;
    private static readonly VALUE_DEFAULT_ALWAYS_SCREEN_ON: number = 1;
    private static readonly VALUE_DEFAULT_BROADCAST_ALARM: number = 1;

    public static Dispose() 
    {
        this.onAutoFreeGameAndFeature.RemoveAllListeners();
        this.onBgmVolume.RemoveAllListeners();
        this.onSoundVolume.RemoveAllListeners();
        this.onVibrate.RemoveAllListeners();
        this.onAlwaysScreenOn.RemoveAllListeners();
        this.onPlayersMessage.RemoveAllListeners();
        this.onBroadcastAlarm.RemoveAllListeners();
    }

    public static get BgmVolume(): number
    {
        return PrefsManager.GetLocalValue(this.KEY_BGM_VOLUME, this.VALUE_DEFAULT_BGM_VOLUME);
    }
    public static set BgmVolume(value)
    {
        PrefsManager.SetLocalValue(this.KEY_BGM_VOLUME, value);
        this.onBgmVolume.Invoke(value);
    }

    public static get SoundVolume(): number
    {
        return PrefsManager.GetLocalValue(this.KEY_SOUND_VOLUME, this.VALUE_DEFAULT_SOUND_VOLUME);
    }
    public static set SoundVolume(value)
    {
        PrefsManager.SetLocalValue(this.KEY_SOUND_VOLUME, value);
        this.onSoundVolume.Invoke(value);
    }

    public static get Vibrate(): boolean
    {
        return PrefsManager.GetLocalValue(this.KEY_VIBRATE, this.VALUE_DEFAULT_VIBRATE) > 0;
    }
    public static set Vibrate(value)
    {
        PrefsManager.SetLocalValue(this.KEY_VIBRATE, value == true ? 1 : 0);
        this.onVibrate.Invoke(value);
    }

    public static get AlwaysScreenOn(): boolean
    {
        return PrefsManager.GetLocalValue(this.KEY_ALWAYS_SCREEN_ON, this.VALUE_DEFAULT_ALWAYS_SCREEN_ON) == 1 ? true : false;
    }
    public static set AlwaysScreenOn(value)
    {
        PrefsManager.SetLocalValue(this.KEY_ALWAYS_SCREEN_ON, value == true ? 1 : 0);
        this.onAlwaysScreenOn.Invoke(value);
    }

    public static get BroadcastAlarm(): boolean
    {
        return PrefsManager.GetLocalValue(this.KEY_BROADCAST_ALARM, this.VALUE_DEFAULT_BROADCAST_ALARM) > 0;
    }
    public static set BroadcastAlarm(value)
    {
        PrefsManager.SetLocalValue(this.KEY_BROADCAST_ALARM, value == true ? 1 : 0);
        this.onBroadcastAlarm.Invoke(value);
    }
}
