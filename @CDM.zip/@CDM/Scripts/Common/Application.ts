import * as UAParser from "../../../Scripts/Util/ua-parser"
import GlobalData, { ePlatformType, eServerType } from "../../../Scripts/GlobalData";

export default class Application
{
    static version: string = "";
    static deviceModel: string = "";
    static targetFrameRate : number = 120;

    public static LoadInfo()
    {
        if (!GlobalData.IsToolDev)
        {
            Application.version = window["version"];
            let service: string = window["service"];
            let platform: string = window["platform"];
            GlobalData.SeverType = eServerType[service];
            GlobalData.PlatformType = ePlatformType[platform];

            cc.log(navigator.userAgent);
            let parser = new UAParser(navigator.userAgent);
            let result = parser.getResult();
            if (result != undefined && result.device.model != undefined)
            {
                this.deviceModel = parser.getResult().device.model;
            }
            cc.log(service);
            cc.log(platform);
        }

        cc.log("DeviceModel :",this.deviceModel);
        cc.log("AppVersion :", Application.version);
    }

    public static async LoadVersion(): Promise<boolean>
    {
        return new Promise((resolve, reject) => 
        {
            cc.resources.load<cc.JsonAsset>("Version", cc.JsonAsset, function (err, result: cc.JsonAsset)
            {
                if (err == null)
                {
                    cc.log("APPVersion" + result.json.Version);
                    Application.version = result.json.Version;
                    resolve(true);
                }
                else
                {
                    cc.error(err);
                    resolve(null);
                }
            })
        });
    }
}