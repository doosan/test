﻿export enum PathSpace {xyz, xy, xz};

