﻿import InstanceEvent from "../../../../System/InstanceEvent";
import BezierPath from "./BezierPath";
import GlobalDisplaySettings from "./GlobalDisplaySettings";
import PathCreatorData from "./PathCreatorData";
import VertexPath from "./VertexPath";


const { ccclass, property } = cc._decorator;

@ccclass

export default class PathCreator extends cc.Component 
{
    /// This class stores data for the path editor, and provides accessors to get the current vertex and bezier path.
    /// Attach to a GameObject to create a new path editor.

    public pathUpdated: InstanceEvent = new InstanceEvent();

    //[SerializeField, HideInInspector]
    @property(PathCreatorData) editorData: PathCreatorData = null;
    //[SerializeField, HideInInspector]
    initialized: boolean = false;

    globalEditorDisplaySettings: GlobalDisplaySettings = null;

    // Vertex path created from the current bezier path
    public get path(): VertexPath
    {
        if (!this.initialized) 
        {
            this.InitializeEditorData(false);
        }
        return this.editorData.GetVertexPath(this.node);
    }

    // The bezier path created in the editor
    public get bezierPath(): BezierPath
    {
        if (!this.initialized)
        {
            this.InitializeEditorData(false);
        }
        return this.editorData.bezierPath;
    }

    public set bezierPath(value)
    {
        if (!this.initialized) 
        {
            this.InitializeEditorData(false);
        }
        this.editorData.bezierPath = value;
    }

    //#region Internal methods

    /// Used by the path editor to initialise some data
    public InitializeEditorData(in2DMode: boolean): void
    {
        if (this.editorData == null) 
        {
            this.editorData = new PathCreatorData();
        }
        this.editorData.bezierOrVertexPathModified.RemoveListener(this.TriggerPathUpdate.bind(this), this);
        this.editorData.bezierOrVertexPathModified.AddListener(this.TriggerPathUpdate.bind(this), this);

        this.editorData.Initialize(in2DMode);
        this.initialized = true;
    }

    public get EditorData(): PathCreatorData 
    {
        return this.editorData;
    }

    public TriggerPathUpdate(): void
    {
        if (this.pathUpdated != null) 
        {
            this.pathUpdated.Invoke();
        }
    }

    // #if UNITY_EDITOR

    //         // Draw the path when path objected is not selected (if enabled in settings)
    //         void OnDrawGizmos () {

    //             // Only draw path gizmo if the path object is not selected
    //             // (editor script is resposible for drawing when selected)
    //             GameObject selectedObj = UnityEditor.Selection.activeGameObject;
    //             if (selectedObj != gameObject) {

    //                 if (path != null) {
    //                     path.UpdateTransform (transform);

    //                     if (globalEditorDisplaySettings == null) {
    //                         globalEditorDisplaySettings = GlobalDisplaySettings.Load ();
    //                     }

    //                     if (globalEditorDisplaySettings.visibleWhenNotSelected) {

    //                         Gizmos.color = globalEditorDisplaySettings.bezierPath;

    //                         for (int i = 0; i < path.NumPoints; i++) {
    //                             int nextI = i + 1;
    //                             if (nextI >= path.NumPoints) {
    //                                 if (path.isClosedLoop) {
    //                                     nextI %= path.NumPoints;
    //                                 } else {
    //                                     break;
    //                                 }
    //                             }
    //                             Gizmos.DrawLine (path.GetPoint (i), path.GetPoint (nextI));
    //                         }
    //                     }
    //                 }
    //             }
    //         }
    // #endif

    //         #endregion
}