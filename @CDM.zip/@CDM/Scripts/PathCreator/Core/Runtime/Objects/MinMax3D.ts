﻿export default class MinMax3D 
{
    public Min: cc.Vec3;
    public Max: cc.Vec3;

    public constructor()
    {
        this.Min = cc.Vec3.ONE.mul(Number.MAX_VALUE);
        this.Max = cc.Vec3.ONE.mul(Number.MIN_VALUE);
    }

    public AddValue(v : cc.Vec3) : void
    {
        this.Min = new cc.Vec3(Math.min(this.Min.x, v.x), Math.min(this.Min.y, v.y), Math.min(this.Min.z, v.z));
        this.Max = new cc.Vec3(Math.max(this.Max.x, v.x), Math.max(this.Max.y, v.y), Math.max(this.Max.z, v.z));
    }
}