﻿import InstanceEvent from "../../../../System/InstanceEvent";
import BezierPath from "./BezierPath";
import { PathSpace } from "./PathSpace";
import VertexPath from "./VertexPath";

const { ccclass, property } = cc._decorator;
/// Stores state data for the path creator editor

//[System.Serializable]
@ccclass("PathCreatorData")
export default class PathCreatorData 
{
    public bezierOrVertexPathModified: InstanceEvent = new InstanceEvent();
    public bezierCreated: InstanceEvent = new InstanceEvent();

    //[SerializeField]
    @property(BezierPath) bbezierPath: BezierPath = null;
    @property(VertexPath) vvertexPath : VertexPath = null;

    @property(cc.Boolean) vertexPathUpToDate: boolean = false;

    // vertex path settings
    public vertexPathMaxAngleError: number = 0.3;
    public vertexPathMinVertexSpacing: number = 0.01;

    // bezier display settings
    public showTransformTool: boolean = true;
    public showPathBounds: boolean = false;
    public showPerSegmentBounds: boolean = false;
    public displayAnchorPoints: boolean = true;
    public displayControlPoints: boolean = true;
    public bezierHandleScale: number = 1;
    public globalDisplaySettingsFoldout: boolean = false;
    public keepConstantHandleSize: boolean = false;

    // vertex display settings
    public showNormalsInVertexMode: boolean = false;
    public showBezierPathInVertexMode: boolean = false;

    // Editor display states
    public showDisplayOptions: boolean = false;
    public showPathOptions: boolean = true;
    public showVertexPathDisplayOptions: boolean = false;
    public showVertexPathOptions: boolean = true;
    public showNormals: boolean = false;
    public showNormalsHelpInfo: boolean = false;
    public tabIndex: number = 0;

    public Initialize(defaultIs2D: boolean): void
    {
        if (this.bbezierPath == null)
        {
            this.CreateBezier(cc.Vec3.ZERO, defaultIs2D);
        }
        this.vertexPathUpToDate = false;
        this.bbezierPath.OnModified.RemoveListener(this.BezierPathEdited.bind(this), this);
        this.bbezierPath.OnModified.AddListener(this.BezierPathEdited.bind(this), this);
    }

    public ResetBezierPath(centre: cc.Vec3, defaultIs2D: boolean = false): void
    {
        this.CreateBezier(centre, defaultIs2D);
    }

    CreateBezier(centre: cc.Vec3, defaultIs2D: boolean = false): void
    {
        if (this.bbezierPath != null)
        {
            this.bbezierPath.OnModified.RemoveListener(this.BezierPathEdited.bind(this), this);
        }

        var space = (defaultIs2D) ? PathSpace.xy : PathSpace.xyz;
        this.bbezierPath = new BezierPath(new cc.Vec2(centre.x, centre.y), false, space);

        this.bbezierPath.OnModified.AddListener(this.BezierPathEdited, this);
        this.vertexPathUpToDate = false;

        if (this.bezierOrVertexPathModified != null) 
        {
            this.bezierOrVertexPathModified.Invoke();
        }
        if (this.bezierCreated != null) 
        {
            this.bezierCreated.Invoke();
        }
    }

    public get bezierPath(): BezierPath
    {
        return this.bbezierPath;
    }

    public set bezierPath(value)
    {
        this.bbezierPath.OnModified.RemoveListener(this.BezierPathEdited.bind(this), this);
        this.vertexPathUpToDate = false;
        this.bbezierPath = value;
        this.bbezierPath.OnModified.AddListener(this.BezierPathEdited.bind(this), this);

        if (this.bezierOrVertexPathModified != null)
        {
            this.bezierOrVertexPathModified.Invoke();
        }
        if (this.bezierCreated != null)
        {
            this.bezierCreated.Invoke();
        }
    }

    // Get the current vertex path
    public GetVertexPath (transform : cc.Node) : VertexPath
    {
        // create new vertex path if path was modified since this vertex path was created
        if (!this.vertexPathUpToDate || this.vvertexPath == null) {
            this.vertexPathUpToDate = true;
            this.vvertexPath = new VertexPath (this.bezierPath, transform, this.vertexPathMaxAngleError, this.vertexPathMinVertexSpacing);
        }
        return this.vvertexPath;
    }

    public PathTransformed () : void
    {
        if (this.bezierOrVertexPathModified != null) {
            this.bezierOrVertexPathModified.Invoke();
        }
    }

    public VertexPathSettingsChanged () : void
    {
        this.vertexPathUpToDate = false;
        if (this.bezierOrVertexPathModified != null) {
            this.bezierOrVertexPathModified.Invoke();
        }
    }

    public PathModifiedByUndo () : void
    {
        this.vertexPathUpToDate = false;
        if (this.bezierOrVertexPathModified != null) {
            this.bezierOrVertexPathModified.Invoke();
        }
    }

    BezierPathEdited(): void
    {
        this.vertexPathUpToDate = false;
        if (this.bezierOrVertexPathModified != null)
        {
            this.bezierOrVertexPathModified.Invoke();
        }
    }
}

