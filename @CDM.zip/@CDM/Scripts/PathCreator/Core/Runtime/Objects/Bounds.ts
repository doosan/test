const {ccclass, property} = cc._decorator;

@ccclass
export default class Bounds
    {
        private m_Center : cc.Vec3;
        //[NativeName("m_Extent")]
        private m_Extents : cc.Vec3;

        // Creates new Bounds with a given /center/ and total /size/. Bound ::ref::extents will be half the given size.
        //public constructor(center : cc.Vec3, size : cc.Vec3)
        constructor(...params : any)
        {
            this.m_Center = params[0];
            this.m_Extents = params[1].mul(0.5);
        }

        // used to allow Bounds to be used as keys in hash tables
        // public override int GetHashCode()
        // {
        //     return center.GetHashCode() ^ (extents.GetHashCode() << 2);
        // }

        // also required for being able to use Vector4s as keys in hash tables
        // public Equals(object other) : boolean
        // {
        //     if (!(other is Bounds)) return false;

        //     return Equals((Bounds)other);
        // }

        // public bool Equals(Bounds other)
        // {
        //     return center.Equals(other.center) && extents.Equals(other.extents);
        // }

        // The center of the bounding box.
        public get center() : cc.Vec3
        { 
            return this.m_Center; 
        }

        public set center(value)
        { 
            this.m_Center = value;
        }

        public get size() : cc.Vec3
        { 
            return this.m_Extents.mul(2.0); 
        }

        public set size(value)
        { 
            this.m_Extents = value.mul(0.5);
        }

        public get extents() : cc.Vec3
        { 
            return this.m_Extents; 
        }

        public set extents(value)
        { 
            this.m_Extents = value;
        }

        public get min() : cc.Vec3
        { 
            return this.center.sub(this.extents); 
        }

        public set min(value)
        { 
            this.SetMinMax(value, this.max)
        }

        public get max() : cc.Vec3
        { 
            return this.center.add(this.extents); 
        }

        public set max(value)
        { 
            this.SetMinMax(this.min, value)
        }

        //*undoc*
        public static IsEquals(lhs : Bounds, rhs : Bounds)
        {
            // Returns false in the presence of NaN values.
            return (lhs.center == rhs.center && lhs.extents == rhs.extents);
        }

        //*undoc*
        public static IsNotEquals(lhs : Bounds, rhs : Bounds)
        {
            // Returns true in the presence of NaN values.
            return !(lhs == rhs);
        }

        // Sets the bounds to the /min/ and /max/ value of the box.
        public SetMinMax(min : cc.Vec3, max : cc.Vec3) : void
        {
            this.extents = (max.sub(min)).mul(0.5);
            this.center = min.add(this.extents);
        }

        // Grows the Bounds to include the /Bounds/.
        public Encapsulate(point : cc.Vec3) : void;
        public Encapsulate(bounds : Bounds) : void;
        public Encapsulate(param1 : cc.Vec3 | Bounds) : void
        {
            if(param1 instanceof Bounds)
            {
                let bounds : Bounds = param1;

                this.Encapsulate(bounds.center.sub(bounds.extents));
                this.Encapsulate(bounds.center.add(bounds.extents));
            }
            else
            {
                let point : cc.Vec3 = param1;
                let min : cc.Vec3 = cc.Vec3.ZERO;
                let max : cc.Vec3 = cc.Vec3.ZERO;

                this.SetMinMax(cc.Vec3.min(min, this.min, point), cc.Vec3.max(max, this.max, point));
            }
        }

        // Expand the bounds by increasing its /size/ by /amount/ along each side.
        public Expand(amount : number) : void;
        public Expand(amount : cc.Vec3) : void;
        public Expand(param1 : number | cc.Vec3) : void
        {
            if(param1 instanceof cc.Vec3)
            {
                let amount : cc.Vec3 = param1;
                this.extents = this.extents.add(amount.mul(0.5));
            }
            else
            {
                let amount : number = param1;

                amount *= .5;
                this.extents = this.extents.add(new cc.Vec3(amount, amount, amount));
            }
        }

        // Does another bounding box intersect with this bounding box?
        // public bool Intersects(Bounds bounds) : boolean
        // {
        //     return (min.x <= bounds.max.x) && (max.x >= bounds.min.x) &&
        //         (min.y <= bounds.max.y) && (max.y >= bounds.min.y) &&
        //         (min.z <= bounds.max.z) && (max.z >= bounds.min.z);
        // }

        // public bool IntersectRay(Ray ray) { float dist; return IntersectRayAABB(ray, this, out dist); }
        // public bool IntersectRay(Ray ray, out float distance) { return IntersectRayAABB(ray, this, out distance); }


        /// *listonly*
        // override public string ToString()
        // {
        //     return ToString(null, null);
        // }

        // // Returns a nicely formatted string for the bounds.
        // public string ToString(string format)
        // {
        //     return ToString(format, null);
        // }

        // public string ToString(string format, IFormatProvider formatProvider)
        // {
        //     if (string.IsNullOrEmpty(format))
        //         format = "F2";
        //     if (formatProvider == null)
        //         formatProvider = CultureInfo.InvariantCulture.NumberFormat;
        //     return UnityString.Format("Center: {0}, Extents: {1}", m_Center.ToString(format, formatProvider), m_Extents.ToString(format, formatProvider));
        // }
    }
