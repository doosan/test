﻿import InstanceEvent from "../../../../System/InstanceEvent";
import CubicBezierUtility from "../Utility/CubicBezierUtility";
import Bounds from "./Bounds";
import { PathSpace } from "./PathSpace";

const { ccclass, property } = cc._decorator;
/// A bezier path is a path made by stitching together any number of (cubic) bezier curves.
/// A single cubic bezier curve is defined by 4 points: anchor1, control1, control2, anchor2
/// The curve moves between the 2 anchors, and the shape of the curve is affected by the positions of the 2 control points

/// When two curves are stitched together, they share an anchor point (end anchor of curve 1 = start anchor of curve 2).
/// So while one curve alone consists of 4 points, two curves are defined by 7 unique points.

/// Apart from storing the points, this class also provides methods for working with the path.
/// For example, adding, inserting, and deleting points.

export enum ControlMode { Aligned, Mirrored, Free, Automatic };

@ccclass("BezierPath")
export default class BezierPath 
{
    public OnModified: InstanceEvent = new InstanceEvent();


    //#region Fields

    //[SerializeField, HideInInspector]
    @property([cc.Vec3]) points: cc.Vec3[] = [];
    //[SerializeField, HideInInspector]
    @property(cc.Boolean) isClosed: boolean = false;
    //[SerializeField, HideInInspector]
    @property({type:cc.Enum(PathSpace)}) space: PathSpace = PathSpace.xy;
    //[SerializeField, HideInInspector]
    @property({type:cc.Enum(ControlMode)}) controlMode: ControlMode = ControlMode.Aligned;
    //[SerializeField, HideInInspector]
    @property() autoControlLength: number = 0.3;
    //[SerializeField, HideInInspector]
    boundsUpToDate: boolean = false;
    //[SerializeField, HideInInspector]
    bounds: Bounds;

    // Normals settings
    //[SerializeField, HideInInspector]
    @property([cc.Float]) perAnchorNormalsAngle: number[] = [];
    //[SerializeField, HideInInspector]
    @property() globalNormalsAngle: number = 0;
    //[SerializeField, HideInInspector]
    @property(cc.Boolean) flipNormals: boolean = false;

    //#endregion

    //#region Constructors

    /// <summary> Creates a two-anchor path centred around the given centre point </summary>
    ///<param name="isClosed"> Should the end point connect back to the start point? </param>
    ///<param name="space"> Determines if the path is in 3d space, or clamped to the xy/xz plane </param>
    //  public constructor(centre : cc.Vec2, isClosed : boolean = false, space : PathSpace = PathSpace.xyz) 
    //  {

    //  let dir : cc.Vec3 = (space == PathSpace.xz) ? cc.Vec3.FORWARD : cc.Vec3.UP;
    //  let width : number = 2;
    //  let controlHeight : number = 0.5;
    //  let controlWidth : number = 1;
    //  this.points = [];
    //  let right : cc.Vec3 = cc.Vec3.RIGHT;
    //  let left : cc.Vec3 = new cc.Vec3(cc.Vec3.RIGHT.x * -1, cc.Vec3.RIGHT.y, cc.Vec3.RIGHT.z);

    //  let centre3 : cc.Vec3 = new cc.Vec3(centre.x, centre.y);

    //  this.points = [(centre3.add(left.mul(width))),
    //                 (centre3.add(left.mul(controlWidth)).add(dir.mul(controlHeight))),
    //                 (centre3.add(right.mul(controlWidth)).sub(dir.mul(controlHeight))),
    //                 (centre3.add(right.mul(width)))]

    //  let perAnchorNormalsAngle : number[] = [0, 0];
    //  this.Space = space;
    //  this.IsClosed = isClosed;
    // }

    /// <summary> Creates a path from the supplied 3D points </summary>
    ///<param name="points"> List or array of points to create the path from. </param>
    ///<param name="isClosed"> Should the end point connect back to the start point? </param>
    ///<param name="space"> Determines if the path is in 3d space, or clamped to the xy/xz plane </param>
    // public constructor(centre: cc.Vec2, isClosed?: boolean, space?: PathSpace);
    // public constructor(points: Array<cc.Vec3>, isClosed?, space?: PathSpace);
    // public constructor(param1: cc.Vec2 | Array<cc.Vec3>, isClosed: boolean = false, space: PathSpace = PathSpace.xyz)


    public constructor(...params:any)
    {
        if(params[0]==null)
        {
            return;
        }

        if (params[0] instanceof cc.Vec2)
        {
            let centre: cc.Vec2 = params[0];

            let dir: cc.Vec3 = (params[2] == PathSpace.xz) ? cc.Vec3.FORWARD : cc.Vec3.UP;
            let width: number = 2;
            let controlHeight: number = 0.5;
            let controlWidth: number = 1;
            this.points = [];
            let right: cc.Vec3 = cc.Vec3.RIGHT;
            let left: cc.Vec3 = new cc.Vec3(cc.Vec3.RIGHT.x * -1, cc.Vec3.RIGHT.y, cc.Vec3.RIGHT.z);

            let centre3: cc.Vec3 = new cc.Vec3(centre.x, centre.y);

            this.points = [(centre3.add(left.mul(width))),
            (centre3.add(left.mul(controlWidth)).add(dir.mul(controlHeight))),
            (centre3.add(right.mul(controlWidth)).sub(dir.mul(controlHeight))),
            (centre3.add(right.mul(width)))]

            let perAnchorNormalsAngle: number[] = [0, 0];
            this.Space = params[2] == null ? PathSpace.xyz : params[2];
            this.IsClosed = params[1] == null ? false : params[1];
        }
        else
        {
            let points: Array<cc.Vec3> = params[0];
            let pointsArray: Array<cc.Vec3> = [];
            points.forEach(value =>
            {
                pointsArray.push(value);
            }, this);



            if (pointsArray.length < 2) 
            {
                //cc.LogError ("Path requires at least 2 anchor points.");
            }
            else
            {
                this.controlMode = ControlMode.Automatic;
                this.points = [];
                this.points = [pointsArray[0], cc.Vec3.ZERO, cc.Vec3.ZERO, pointsArray[1]];
                this.perAnchorNormalsAngle = [0, 0];

                for (let i = 2; i < pointsArray.length; i++) 
                {
                    this.AddSegmentToEnd(pointsArray[i]);
                    this.perAnchorNormalsAngle.push(0);
                }
            }

            this.Space = params[2] == null ? PathSpace.xyz : params[2];
            this.IsClosed = params[1] == null ? false : params[1];
        }
    }

    /// <summary> Creates a path from the positions of the supplied 2D points </summary>
    ///<param name="transforms"> List or array of transforms to create the path from. </param>
    ///<param name="isClosed"> Should the end point connect back to the start point? </param>
    ///<param name="space"> Determines if the path is in 3d space, or clamped to the xy/xz plane </param>
    // public BezierPath (IEnumerable<Vector2> transforms, bool isClosed = false, PathSpace space = PathSpace.xy):
    //     this (transforms.Select (p => new Vector3 (p.x, p.y)), isClosed, space) { }

    // /// <summary> Creates a path from the positions of the supplied transforms </summary>
    // ///<param name="transforms"> List or array of transforms to create the path from. </param>
    // ///<param name="isClosed"> Should the end point connect back to the start point? </param>
    // ///<param name="space"> Determines if the path is in 3d space, or clamped to the xy/xz plane </param>
    // public BezierPath (IEnumerable<Transform> transforms, bool isClosed = false, PathSpace space = PathSpace.xy):
    //     this (transforms.Select (t => t.position), isClosed, space) { }

    // /// <summary> Creates a path from the supplied 2D points </summary>
    // ///<param name="points"> List or array of 2d points to create the path from. </param>
    // ///<param name="isClosed"> Should the end point connect back to the start point? </param>
    // ///<param name="pathSpace"> Determines if the path is in 3d space, or clamped to the xy/xz plane </param>
    // public BezierPath (IEnumerable<Vector2> points, PathSpace space = PathSpace.xyz, bool isClosed = false):
    //     this (points.Select (p => new Vector3 (p.x, p.y)), isClosed, space) { }

    //#endregion

    //#region Public methods and accessors

    /// Get world space position of point
    
    // public Vector3 this [int i] {
    //     get {
    //         return GetPoint (i);
    //     }
    // }

    /// Get world space position of point
    public GetPoint(i: number): cc.Vec3
    {
        return this.points[i];
    }

    /// Get world space position of point
    public SetPoint(i: number, localPosition: cc.Vec3, suppressPathModifiedEvent: boolean = false): void
    {
        this.points[i] = localPosition;
        if (!suppressPathModifiedEvent)
        {
            this.NotifyPathModified();
        }
    }

    /// Total number of points in the path (anchors and controls)
    public get NumPoints(): number
    {
        return this.points.length;
    }

    /// Number of anchor points making up the path
    public get NumAnchorPoints(): number
    {
        return (this.IsClosed) ? Math.trunc(this.points.length / 3) : Math.trunc((this.points.length + 2) / 3);
    }

    /// Number of bezier curves making up this path
    public get NumSegments(): number
    {
        return Math.trunc(this.points.length / 3);
    }

    /// Path can exist in 3D (xyz), 2D (xy), or Top-Down (xz) space
    /// In xy or xz space, points will be clamped to that plane (so in a 2D path, for example, points will always be at 0 on z axis)
    public get Space(): PathSpace
    {
        return this.space;
    }

    public set Space(value)
    {
        if (value != this.space) 
        {
            let previousSpace: PathSpace = this.space;
            this.space = value;
            this.UpdateToNewPathSpace(previousSpace);
        }
    }

    /// If closed, path will loop back from end point to start point
    public get IsClosed(): boolean
    {
        return this.isClosed;
    }

    public set IsClosed(value)
    {
        if (this.isClosed != value) 
        {
            this.isClosed = value;
            this.UpdateClosedState();
        }
    }

    /// The control mode determines the behaviour of control points.
    /// Possible modes are:
    /// Aligned = controls stay in straight line around their anchor
    /// Mirrored = controls stay in straight, equidistant line around their anchor
    /// Free = no constraints (use this if sharp corners are needed)
    /// Automatic = controls placed automatically to try make the path smooth
    public get ControlPointMode(): ControlMode
    {
        return this.controlMode;
    }
    public set ControlPointMode(value)
    {
        if (this.controlMode != value) 
        {
            this.controlMode = value;
            if (this.controlMode == ControlMode.Automatic) 
            {
                this.AutoSetAllControlPoints();
                this.NotifyPathModified();
            }
        }
    }

    /// When using automatic control point placement, this value scales how far apart controls are placed
    public get AutoControlLength(): number 
    {
        return this.autoControlLength;
    }

    public set AutoControlLength(value)
    {
        value = Math.max(value, 0.01);
        if (this.autoControlLength != value)
        {
            this.autoControlLength = value;
            this.AutoSetAllControlPoints();
            this.NotifyPathModified();
        }
    }

    /// Add new anchor point to end of the path
    public AddSegmentToEnd(anchorPos: cc.Vec3): void
    {
        if (this.isClosed) 
        {
            return;
        }

        let lastAnchorIndex: number = this.points.length - 1;
        // Set position for new control to be mirror of its counterpart
        let secondControlForOldLastAnchorOffset: cc.Vec3 = (this.points[lastAnchorIndex].sub(this.points[lastAnchorIndex - 1]));
        if (this.controlMode != ControlMode.Mirrored && this.controlMode != ControlMode.Automatic) 
        {
            // Set position for new control to be aligned with its counterpart, but with a length of half the distance from prev to new anchor
            let dstPrevToNewAnchor: number = (this.points[lastAnchorIndex].sub(anchorPos)).mag();
            secondControlForOldLastAnchorOffset = (this.points[lastAnchorIndex].sub(this.points[lastAnchorIndex - 1])).normalize().mul(dstPrevToNewAnchor).mul(0.5);
        }
        let secondControlForOldLastAnchor: cc.Vec3 = this.points[lastAnchorIndex].add(secondControlForOldLastAnchorOffset);
        let controlForNewAnchor: cc.Vec3 = anchorPos.add(secondControlForOldLastAnchor).mul(0.5);

        this.points.push(secondControlForOldLastAnchor);
        this.points.push(controlForNewAnchor);
        this.points.push(anchorPos);
        this.perAnchorNormalsAngle.push(this.perAnchorNormalsAngle[this.perAnchorNormalsAngle.length - 1]);

        if (this.controlMode == ControlMode.Automatic) 
        {
            this.AutoSetAllAffectedControlPoints(this.points.length - 1);
        }

        this.NotifyPathModified();
    }

    /// Add new anchor point to start of the path
    public AddSegmentToStart(anchorPos: cc.Vec3)  
    {
        if (this.isClosed) 
        {
            return;
        }

        // Set position for new control to be mirror of its counterpart
        let secondControlForOldFirstAnchorOffset: cc.Vec3 = this.points[0].sub(this.points[1]);
        if (this.controlMode != ControlMode.Mirrored && this.controlMode != ControlMode.Automatic)
        {
            // Set position for new control to be aligned with its counterpart, but with a length of half the distance from prev to new anchor
            let dstPrevToNewAnchor: number = this.points[0].sub(anchorPos).mag();
            secondControlForOldFirstAnchorOffset = secondControlForOldFirstAnchorOffset.normalize().mul(dstPrevToNewAnchor).mul(0.5);
        }

        let secondControlForOldFirstAnchor: cc.Vec3 = this.points[0].add(secondControlForOldFirstAnchorOffset);
        let controlForNewAnchor: cc.Vec3 = anchorPos.add(secondControlForOldFirstAnchor).mul(0.5);
        this.points.splice(0, 0, anchorPos);
        this.points.splice(1, 0, controlForNewAnchor);
        this.points.splice(2, 0, secondControlForOldFirstAnchor);
        this.perAnchorNormalsAngle.splice(0, 0, this.perAnchorNormalsAngle[0]);

        if (this.controlMode == ControlMode.Automatic) 
        {
            this.AutoSetAllAffectedControlPoints(0);
        }
        this.NotifyPathModified();
    }

    /// Insert new anchor point at given position. Automatically place control points around it so as to keep shape of curve the same
    public SplitSegment(anchorPos: cc.Vec3, segmentIndex: number, splitTime: number): void
    {
        splitTime = cc.misc.clamp01(splitTime);

        if (this.controlMode == ControlMode.Automatic)
        {
            this.points.splice(segmentIndex * 3 + 2, 0, cc.Vec3.ZERO);
            this.points.splice(segmentIndex * 3 + 3, 0, anchorPos);
            this.points.splice(segmentIndex * 3 + 4, 0, cc.Vec3.ZERO);
            //InsertRange (segmentIndex * 3 + 2, new Vector3[] { Vector3.zero, anchorPos, Vector3.zero });
            this.AutoSetAllAffectedControlPoints(segmentIndex * 3 + 3);
        }
        else
        {
            // Split the curve to find where control points can be inserted to least affect shape of curve
            // Curve will probably be deformed slightly since splitTime is only an estimate (for performance reasons, and so doesn't correspond exactly with anchorPos)
            let splitSegment: cc.Vec3[][] = CubicBezierUtility.SplitCurve(this.GetPointsInSegment(segmentIndex), splitTime);
            this.points.splice(segmentIndex * 3 + 2, 0, splitSegment[0][2]);
            this.points.splice(segmentIndex * 3 + 3, 0, splitSegment[1][0]);
            this.points.splice(segmentIndex * 3 + 4, 0, splitSegment[1][1]);

            //points.InsertRange (segmentIndex * 3 + 2, new Vector3[] { splitSegment[0][2], splitSegment[1][0], splitSegment[1][1] });
            let newAnchorIndex: number = segmentIndex * 3 + 3;
            this.MovePoint(newAnchorIndex - 2, splitSegment[0][1], true);
            this.MovePoint(newAnchorIndex + 2, splitSegment[1][2], true);
            this.MovePoint(newAnchorIndex, anchorPos, true);

            if (this.controlMode == ControlMode.Mirrored) 
            {
                let avgDst: number = ((splitSegment[0][2].sub(anchorPos)).mag() + (splitSegment[1][1].sub(anchorPos)).mag()) / 2;
                this.MovePoint(newAnchorIndex + 1, anchorPos.add((splitSegment[1][1].sub(anchorPos)).normalize().mul(avgDst)), true);
            }
        }

        // Insert angle for new anchor (value should be set inbetween neighbour anchor angles)
        let newAnchorAngleIndex: number = (segmentIndex + 1) % this.perAnchorNormalsAngle.length;
        let numAngles: number = this.perAnchorNormalsAngle.length;
        let anglePrev: number = this.perAnchorNormalsAngle[segmentIndex];
        let angleNext: number = this.perAnchorNormalsAngle[newAnchorAngleIndex];
        let splitAngle: number = Math.LerpAngle(anglePrev, angleNext, splitTime);
        this.perAnchorNormalsAngle.splice(newAnchorAngleIndex, 0, splitAngle);

        this.NotifyPathModified();
    }

    /// Delete the anchor point at given index, as well as its associated control points
    public DeleteSegment(anchorIndex: number): void
    {
        // Don't delete segment if its the last one remaining (or if only two segments in a closed path)
        if (this.NumSegments > 2 || !this.isClosed && this.NumSegments > 1) 
        {
            if (anchorIndex == 0) 
            {
                if (this.isClosed) 
                {
                    this.points[this.points.length - 1] = this.points[2];
                }
                this.points.splice(0, 3);
            }
            else if (anchorIndex == this.points.length - 1 && !this.isClosed) 
            {
                this.points.splice(anchorIndex - 2, 3);
            }
            else 
            {
                this.points.splice(anchorIndex - 1, 3);
            }

            this.perAnchorNormalsAngle.splice(Math.trunc(anchorIndex / 3), 1);

            if (this.controlMode == ControlMode.Automatic) 
            {
                this.AutoSetAllControlPoints();
            }

            this.NotifyPathModified();
        }
    }

    /// Returns an array of the 4 points making up the segment (anchor1, control1, control2, anchor2)
    public GetPointsInSegment(segmentIndex: number): cc.Vec3[]
    {
        segmentIndex = cc.misc.clampf(segmentIndex, 0, this.NumSegments - 1);
        return [this.GetPoint(segmentIndex * 3), this.GetPoint(segmentIndex * 3 + 1), this.GetPoint(segmentIndex * 3 + 2), this.GetPoint(this.LoopIndex(segmentIndex * 3 + 3))];
    }

    /// Move an existing point to a new position
    public MovePoint(i: number, pointPos: cc.Vec3, suppressPathModifiedEvent: boolean = false): void
    {
        if (this.space == PathSpace.xy)
        {
            pointPos.z = 0;
        } else if (this.space == PathSpace.xz)
        {
            pointPos.y = 0;
        }
        let deltaMove: cc.Vec3 = pointPos.sub(this.points[i]);
        let isAnchorPoint: boolean = i % 3 == 0;

        // Don't process control point if control mode is set to automatic
        if (isAnchorPoint || this.controlMode != ControlMode.Automatic) 
        {
            this.points[i] = pointPos;

            if (this.controlMode == ControlMode.Automatic) 
            {
                this.AutoSetAllAffectedControlPoints(i);
            }
            else 
            {
                // Move control points with anchor point
                if (isAnchorPoint) 
                {
                    if (i + 1 < this.points.length || this.isClosed) 
                    {
                        this.points[this.LoopIndex(i + 1)] = this.points[this.LoopIndex(i + 1)].add(deltaMove);
                    }
                    if (i - 1 >= 0 || this.isClosed) 
                    {
                        this.points[this.LoopIndex(i - 1)] = this.points[this.LoopIndex(i - 1)].add(deltaMove);
                    }
                }
                // If not in free control mode, then move attached control point to be aligned/mirrored (depending on mode)
                else if (this.controlMode != ControlMode.Free) 
                {
                    let nextPointIsAnchor: boolean = (i + 1) % 3 == 0;
                    let attachedControlIndex: number = (nextPointIsAnchor) ? i + 2 : i - 2;
                    let anchorIndex: number = (nextPointIsAnchor) ? i + 1 : i - 1;

                    if (attachedControlIndex >= 0 && attachedControlIndex < this.points.length || this.isClosed) 
                    {
                        let distanceFromAnchor: number = 0;
                        // If in aligned mode, then attached control's current distance from anchor point should be maintained
                        if (this.controlMode == ControlMode.Aligned) 
                        {
                            distanceFromAnchor = (this.points[this.LoopIndex(anchorIndex)].sub(this.points[this.LoopIndex(attachedControlIndex)])).mag();
                        }
                        // If in mirrored mode, then both control points should have the same distance from the anchor point
                        else if (this.controlMode == ControlMode.Mirrored) 
                        {
                            distanceFromAnchor = (this.points[this.LoopIndex(anchorIndex)].sub(this.points[i])).mag();

                        }
                        let dir: cc.Vec3 = (this.points[this.LoopIndex(anchorIndex)].sub(pointPos)).normalize();
                        this.points[this.LoopIndex(attachedControlIndex)] = this.points[this.LoopIndex(anchorIndex)].add(dir.mul(distanceFromAnchor));
                    }
                }
            }

            if (!suppressPathModifiedEvent)
            {
                this.NotifyPathModified();
            }
        }
    }

    /// Update the bounding box of the path
    // public Bounds CalculateBoundsWithTransform (Transform transform) {
    //     // Loop through all segments and keep track of the minmax points of all their bounding boxes
    //     MinMax3D minMax = new MinMax3D ();

    //     for (int i = 0; i < NumSegments; i++) {
    //         Vector3[] p = GetPointsInSegment (i);
    //         for (int j = 0; j < p.Length; j++) {
    //             p[j] = MathUtility.TransformPoint (p[j], transform, space);
    //         }

    //         minMax.AddValue (p[0]);
    //         minMax.AddValue (p[3]);

    //         List<float> extremePointTimes = CubicBezierUtility.ExtremePointTimes (p[0], p[1], p[2], p[3]);
    //         foreach (float t in extremePointTimes) {
    //             minMax.AddValue (CubicBezierUtility.EvaluateCurve (p, t));
    //         }
    //     }

    //     return new Bounds ((minMax.Min + minMax.Max) / 2, minMax.Max - minMax.Min);
    // }

    /// Flip the normal vectors 180 degrees
    public get FlipNormals(): boolean
    {
        return this.flipNormals;
    }
    public set FlipNormals(value)
    {
        if (this.flipNormals != value)
        {
            this.flipNormals = value;
            this.NotifyPathModified();
        }
    }

    /// Global angle that all normal vectors are rotated by (only relevant for paths in 3D space)
    public get GlobalNormalsAngle(): number
    {
        return this.globalNormalsAngle;
    }
    public set GlobalNormalsAngle(value)
    {
        if (value != this.globalNormalsAngle)
        {
            this.globalNormalsAngle = value;
            this.NotifyPathModified();
        }
    }

    /// Get the desired angle of the normal vector at a particular anchor (only relevant for paths in 3D space)
    public GetAnchorNormalAngle(anchorIndex: number): number 
    {
        return this.perAnchorNormalsAngle[anchorIndex] % 360;
    }

    /// Set the desired angle of the normal vector at a particular anchor (only relevant for paths in 3D space)
    public SetAnchorNormalAngle(anchorIndex: number, angle: number): void
    {
        angle = (angle + 360) % 360;
        if (this.perAnchorNormalsAngle[anchorIndex] != angle)
        {
            this.perAnchorNormalsAngle[anchorIndex] = angle;
            this.NotifyPathModified();
        }
    }

    /// Reset global and anchor normal angles to 0
    public ResetNormalAngles(): void
    {
        for (let i = 0; i < this.perAnchorNormalsAngle.length; i++) 
        {
            this.perAnchorNormalsAngle[i] = 0;
        }
        this.globalNormalsAngle = 0;
        this.NotifyPathModified();
    }

    /// Bounding box containing the path
    public get PathBounds(): Bounds
    {
        if (!this.boundsUpToDate)
        {
            this.UpdateBounds();
        }
        return this.bounds;
    }

    //#endregion

    //#region Internal methods and accessors

    /// Update the bounding box of the path
    UpdateBounds(): void
    {
        if (this.boundsUpToDate)
        {
            return;
        }

        // Loop through all segments and keep track of the minmax points of all their bounding boxes
        
        // MinMax3D minMax = new MinMax3D ();

        // for (int i = 0; i < NumSegments; i++) {
        //     Vector3[] p = GetPointsInSegment (i);
        //     minMax.AddValue (p[0]);
        //     minMax.AddValue (p[3]);

        //     List<float> extremePointTimes = CubicBezierUtility.ExtremePointTimes (p[0], p[1], p[2], p[3]);
        //     foreach (float t in extremePointTimes) {
        //         minMax.AddValue (CubicBezierUtility.EvaluateCurve (p, t));
        //     }
        // }

        // boundsUpToDate = true;
        // bounds = new Bounds ((minMax.Min + minMax.Max) / 2, minMax.Max - minMax.Min);
    }

    /// Determines good positions (for a smooth path) for the control points affected by a moved/inserted anchor point
    AutoSetAllAffectedControlPoints(updatedAnchorIndex: number): void
    {
        for (let i = updatedAnchorIndex - 3; i <= updatedAnchorIndex + 3; i += 3) 
        {
            if (i >= 0 && i < this.points.length || this.isClosed)
            {
                this.AutoSetAnchorControlPoints(this.LoopIndex(i));
            }
        }

        this.AutoSetStartAndEndControls();
    }

    /// Determines good positions (for a smooth path) for all control points
    AutoSetAllControlPoints(): void
    {
        if (this.NumAnchorPoints > 2)
        {
            for (let i = 0; i < this.points.length; i += 3)
            {
                this.AutoSetAnchorControlPoints(i);
            }
        }

        this.AutoSetStartAndEndControls();
    }

    /// Calculates good positions (to result in smooth path) for the controls around specified anchor
    AutoSetAnchorControlPoints(anchorIndex: number): void
    {
            // Calculate a vector that is perpendicular to the vector bisecting the angle between this anchor and its two immediate neighbours
            // The control points will be placed along that vector
            let anchorPos : cc.Vec3 = this.points[anchorIndex];
            let dir : cc.Vec3 = cc.Vec3.ZERO;
        let neighbourDistances : number[] = new Array<number>(2);

        if (anchorIndex - 3 >= 0 || this.isClosed)
        {
            let offset : cc.Vec3 = this.points[this.LoopIndex(anchorIndex - 3)].sub(anchorPos);
            dir = dir.add(offset).normalize();
            neighbourDistances[0] = offset.mag();
        }
        if (anchorIndex + 3 >= 0 || this.isClosed)
        {
            let offset : cc.Vec3 = this.points[this.LoopIndex(anchorIndex + 3)].sub(anchorPos);
            dir = dir.sub(offset).normalize();
            neighbourDistances[1] = offset.mul(-1).mag();
        }

        dir.normalizeSelf();

        // Set the control points along the calculated direction, with a distance proportional to the distance to the neighbouring control point
        for (let i = 0; i < 2; i++) 
        {
            let controlIndex : number = anchorIndex + i * 2 - 1;
            if (controlIndex >= 0 && controlIndex < this.points.length || this.isClosed)
            {
                this.points[this.LoopIndex(controlIndex)] = anchorPos.add(dir.mul(neighbourDistances[i]).mul(this.autoControlLength));
            }
        }
    }

    /// Determines good positions (for a smooth path) for the control points at the start and end of a path
    AutoSetStartAndEndControls(): void 
    {
        if (this.isClosed)
        {
            // Handle case with only 2 anchor points separately, as will otherwise result in straight line ()
            if (this.NumAnchorPoints == 2)
            {
                let dirAnchorAToB : cc.Vec3 = (this.points[3].sub(this.points[0])).normalize();
                let dstBetweenAnchors : number = (this.points[0].sub(this.points[3])).mag();
                let perp : cc.Vec3 = cc.Vec3.ZERO;
                cc.Vec3.cross(perp, dirAnchorAToB, (this.space == PathSpace.xy) ? cc.Vec3.FORWARD : cc.Vec3.UP);
                this.points[1] = this.points[0].add(perp.mul(dstBetweenAnchors / 2));
                this.points[5] = this.points[0].sub(perp.mul(dstBetweenAnchors / 2));
                this.points[2] = this.points[3].add(perp.mul(dstBetweenAnchors / 2));
                this.points[4] = this.points[3].sub(perp.mul(dstBetweenAnchors / 2));

            } else
            {
                this.AutoSetAnchorControlPoints(0);
                this.AutoSetAnchorControlPoints(this.points.length - 3);
            }
        } else
        {
            // Handle case with 2 anchor points separately, as otherwise minor adjustments cause path to constantly flip
            if (this.NumAnchorPoints == 2)
            {
                this.points[1] = this.points[0].add((this.points[3].sub(this.points[0])).mul(0.25));
                this.points[2] = this.points[3].add((this.points[0].sub(this.points[3])).mul(0.25));
            } else
            {
                this.points[1] = (this.points[0].add(this.points[2])).mul(0.5);
                this.points[this.points.length - 2] = (this.points[this.points.length - 1].add(this.points[this.points.length - 3])).mul(0.5);
            }
        }
    }

    /// Update point positions for new path space
    /// (for example, if changing from xy to xz path, y and z axes will be swapped so the path keeps its shape in the new space)
    UpdateToNewPathSpace(previousSpace: PathSpace): void
    {
        // If changing from 3d to 2d space, first find the bounds of the 3d path.
        // The axis with the smallest bounds will be discarded.
        if (previousSpace == PathSpace.xyz)
        {
            //     Vector3 boundsSize = this.PathBounds.size;
            //     float minBoundsSize = Mathf.Min(boundsSize.x, boundsSize.y, boundsSize.z);

            // for (let i = 0; i < this.NumPoints; i++) 
            // {
            //     if (this.space == PathSpace.xy)
            //     {
            //         float x = (minBoundsSize == boundsSize.x) ? points[i].z : points[i].x;
            //         float y = (minBoundsSize == boundsSize.y) ? points[i].z : points[i].y;
            //         points[i] = new Vector3(x, y, 0);
            //     } 
            //     else if (this.space == PathSpace.xz)
            //     {
            //             float x = (minBoundsSize == boundsSize.x) ? points[i].y : points[i].x;
            //             float z = (minBoundsSize == boundsSize.z) ? points[i].y : points[i].z;
            //             this.points[i] = new cc.Vec3(x, 0, z);
            //     }
            // }
        } 
        else
        {
            // Nothing needs to change when going to 3d space
            if (this.space != PathSpace.xyz)
            {
                for (let i = 0; i < this.NumPoints; i++) {
                    // from xz to xy
                    if (this.space == PathSpace.xy)
                    {
                        this.points[i] = new cc.Vec3(this.points[i].x, this.points[i].z, 0);
                    }
                    // from xy to xz
                    else if (this.space == PathSpace.xz)
                    {
                        this.points[i] = new cc.Vec3(this.points[i].x, 0, this.points[i].y);
                    }
                }
            }
        }

        this.NotifyPathModified();
    }

    /// Add/remove the extra 2 controls required for a closed path
    UpdateClosedState(): void
    {
        if (this.isClosed)
        {
            // Set positions for new controls to mirror their counterparts
            let lastAnchorSecondControl : cc.Vec3 = this.points[this.points.length - 1].mul(2).sub(this.points[this.points.length - 2]);
            let firstAnchorSecondControl : cc.Vec3  = this.points[0].mul(2).sub(this.points[1]);
            if (this.controlMode != ControlMode.Mirrored && this.controlMode != ControlMode.Automatic)
            {
                // Set positions for new controls to be aligned with their counterparts, but with a length of half the distance between start/end anchor
                let dstBetweenStartAndEndAnchors : number = (this.points[this.points.length - 1].sub(this.points[0])).mag();
                lastAnchorSecondControl = this.points[this.points.length - 1].add((this.points[this.points.length - 1].sub(this.points[this.points.length - 2]).normalize()).mul(dstBetweenStartAndEndAnchors * 0.5));
                firstAnchorSecondControl = this.points[0].add((this.points[0].sub(this.points[1])).normalize().mul(dstBetweenStartAndEndAnchors * 0.5));
            }
            this.points.push(lastAnchorSecondControl);
            this.points.push(firstAnchorSecondControl);
        } else
        {
            this.points.splice(this.points.length - 2, 2);

        }

        if (this.controlMode == ControlMode.Automatic)
        {
            this.AutoSetStartAndEndControls();
        }

        if (this.OnModified != null)
        {
            this.OnModified.Invoke();
        }
    }

    /// Loop index around to start/end of points array if out of bounds (useful when working with closed paths)
    LoopIndex(i: number): number
    {
        return (i + this.points.length) % this.points.length;
    }

    // Called when the path is modified
    public NotifyPathModified(): void
    {
        this.boundsUpToDate = false;
        if (this.OnModified != null)
        {
            this.OnModified.Invoke();
        }
    }
    //#endregion
}