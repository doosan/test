import { Quaternion } from "../../../../Util/Util";
import MathUtility from "../Utility/MathUtility";
import VertexPathUtility, { PathSplitData } from "../Utility/VertexPathUtility";
import BezierPath from "./BezierPath";
import Bounds from "./Bounds";
import { EndOfPathInstruction } from "./EndOfPathInstruction";
import { PathSpace } from "./PathSpace";

const { ccclass, property } = cc._decorator;
/// A vertex path is a collection of points (vertices) that lie along a bezier path.
/// This allows one to do things like move at a constant speed along the path,
/// which is not possible with a bezier path directly due to how they're constructed mathematically.

/// This class also provides methods for getting the position along the path at a certain distance or time
/// (where time = 0 is the start of the path, and time = 1 is the end of the path).
/// Other info about the path (tangents, normals, rotation) can also be retrieved in this manner.
@ccclass("VertexPath")
export default class VertexPath
{
    //#region Fields
    public space: PathSpace;
    public isClosedLoop: boolean;
    public localPoints: cc.Vec3[];
    public localTangents: cc.Vec3[];
    public localNormals: cc.Vec3[];
    public anchorVertexMap: number[];

    /// Percentage along the path at each vertex (0 being start of path, and 1 being the end)
    public times: number[];
    /// Total distance between the vertices of the polyline
    public length: number;
    /// Total distance from the first vertex up to each vertex in the polyline
    public cumulativeLengthAtEachVertex: number[];
    /// Bounding box of the path
    public bounds: Bounds;
    /// Equal to (0,0,-1) for 2D paths, and (0,1,0) for XZ paths
    public up: cc.Vec3;

    // Default values and constants:
    readonly accuracy: number = 1; // A scalar for how many times bezier path is divided when determining vertex positions
    readonly minVertexSpacing: number = 0.01;

    transform: cc.Node;

    //#endregion

    //#region Constructors

    // /// <summary> Splits bezier path into array of vertices along the path.</summary>
    // ///<param name="maxAngleError">How much can the angle of the path change before a vertex is added. This allows fewer vertices to be generated in straighter sections.</param>
    // ///<param name="minVertexDst">Vertices won't be added closer together than this distance, regardless of angle error.</param>
    // public VertexPath (BezierPath bezierPath, Transform transform, float maxAngleError = 0.3f, float minVertexDst = 0):
    //     this (bezierPath, VertexPathUtility.SplitBezierPathByAngleError (bezierPath, maxAngleError, minVertexDst, VertexPath.accuracy), transform) { }

    // /// <summary> Splits bezier path into array of vertices along the path.</summary>
    // ///<param name="maxAngleError">How much can the angle of the path change before a vertex is added. This allows fewer vertices to be generated in straighter sections.</param>
    // ///<param name="minVertexDst">Vertices won't be added closer together than this distance, regardless of angle error.</param>
    // ///<param name="accuracy">Higher value means the change in angle is checked more frequently.</param>
   
    //     this (bezierPath, VertexPathUtility.SplitBezierPathEvenly (bezierPath, Mathf.Max (vertexSpacing, minVertexSpacing), VertexPath.accuracy), transform) { }

    // /// Internal contructor

    //public constructor (bezierPath : BezierPath, transform : cc.Node, maxAngleError : number, minVertexDst : number)
    public constructor(...params:any)
    {
        this.Set(params[0], VertexPathUtility.SplitBezierPathByAngleError (params[0], params[3], params[2], this.accuracy), params[1]);
    }

    Set (bezierPath : BezierPath, pathSplitData : PathSplitData, transform : cc.Node)
    {
        this.transform = transform;
        this.space = bezierPath.Space;
        this.isClosedLoop = bezierPath.IsClosed;
        let numVerts : number = pathSplitData.vertices.length;
        this.length = pathSplitData.cumulativeLength[numVerts - 1];

        this.localPoints = new Array<cc.Vec3>(numVerts);
        this.localNormals = new Array<cc.Vec3>(numVerts);
        this.localTangents = new Array<cc.Vec3>(numVerts);
        this.cumulativeLengthAtEachVertex = new Array<number>(numVerts);
        this.times = new Array<number>(numVerts);
        this.bounds = new Bounds((pathSplitData.minMax.Min.add(pathSplitData.minMax.Max)).div(2), pathSplitData.minMax.Max.sub(pathSplitData.minMax.Min));

        // Figure out up direction for path
        this.up = (this.bounds.size.z > this.bounds.size.y) ? cc.Vec3.UP : cc.Vec3.FORWARD.mul(-1);
        let lastRotationAxis : cc.Vec3 = this.up;

        // Loop through the data and assign to arrays.
        for (let i = 0; i < this.localPoints.length; i++) 
        {
            this.localPoints[i] = pathSplitData.vertices[i];
            this.localTangents[i] = pathSplitData.tangents[i];
            this.cumulativeLengthAtEachVertex[i] = pathSplitData.cumulativeLength[i];
            this.times[i] = this.cumulativeLengthAtEachVertex[i] / this.length;

            // Calculate normals
            if (this.space == PathSpace.xyz) 
            {
                if (i == 0) 
                {
                    let normal : cc.Vec3 =  cc.Vec3.ZERO;
                    this.localNormals[0] = cc.Vec3.cross(normal, lastRotationAxis, pathSplitData.tangents[0]).normalize();
                }
                else
                {
                    // First reflection
                    let offset : cc.Vec3= this.localPoints[i].sub(this.localPoints[i - 1]);
                    let sqrDst : number = offset.magSqr();
                    let r : cc.Vec3 = lastRotationAxis.sub(offset.mul(2).div(sqrDst).mul(cc.Vec3.dot(offset, lastRotationAxis)));
                    let t : cc.Vec3 = this.localTangents[i - 1].sub(offset.mul(2).div(sqrDst).mul(cc.Vec3.dot(offset, this.localTangents[i - 1])));

                    // Second reflection
                    let v2 : cc.Vec3 = this.localTangents[i].sub(t);
                    let c2 : number = cc.Vec3.dot(v2, v2);

                    let finalRot : cc.Vec3 = r.sub(v2.mul(2).div(c2).mul(cc.Vec3.dot(v2, r)));
                    let n : cc.Vec3 = cc.Vec3.ZERO; 
                    cc.Vec3.cross(n, finalRot, this.localTangents[i]).normalize();
                    this.localNormals[i] = n;
                    lastRotationAxis = finalRot;
                }
            }
            else 
            {
                let n : cc.Vec3 = cc.Vec3.ZERO; 
                this.localNormals[i] = cc.Vec3.cross(n, this.localTangents[i], this.up).mul((bezierPath.FlipNormals) ? 1 : -1);
            }
        }

        // Apply correction for 3d normals along a closed path
        
        // if (this.space == PathSpace.xyz && this.isClosedLoop) 
        // {
        //     // Get angle between first and last normal (if zero, they're already lined up, otherwise we need to correct)
        //     float normalsAngleErrorAcrossJoin = Vector3.SignedAngle (localNormals[localNormals.Length - 1], localNormals[0], localTangents[0]);
        //     // Gradually rotate the normals along the path to ensure start and end normals line up correctly
        //     if (Math.abs (normalsAngleErrorAcrossJoin) > 0.1f) // don't bother correcting if very nearly correct
        //     {
        //         for (int i = 1; i < localNormals.Length; i++) {
        //             float t = (i / (localNormals.Length - 1f));
        //             float angle = normalsAngleErrorAcrossJoin * t;
        //             Quaternion rot = Quaternion.AngleAxis (angle, localTangents[i]);
        //             localNormals[i] = rot * localNormals[i] * ((bezierPath.FlipNormals) ? -1 : 1);
        //         }
        //     }
        // }

        // // Rotate normals to match up with user-defined anchor angles
        if (this.space == PathSpace.xyz)
        {
            for (let anchorIndex = 0; anchorIndex < pathSplitData.anchorVertexMap.length - 1; anchorIndex++) 
            {
                let nextAnchorIndex : number = (this.isClosedLoop) ? (anchorIndex + 1) % bezierPath.NumSegments : anchorIndex + 1;

                let startAngle : number = bezierPath.GetAnchorNormalAngle (anchorIndex) + bezierPath.GlobalNormalsAngle;
                let endAngle : number = bezierPath.GetAnchorNormalAngle (nextAnchorIndex) + bezierPath.GlobalNormalsAngle;
                let deltaAngle : number = Math.DeltaAngle (startAngle, endAngle);

                let startVertIndex : number = pathSplitData.anchorVertexMap[anchorIndex];
                let endVertIndex : number = pathSplitData.anchorVertexMap[anchorIndex + 1];

                let num : number = endVertIndex - startVertIndex;
                if (anchorIndex == pathSplitData.anchorVertexMap.length - 2) {
                    num += 1;
                }
                for (let i = 0; i < num; i++) 
                {
                    let vertIndex : number = startVertIndex + i;
                    let t : number = num == 1 ? 1 : i / (num - 1);
                    let angle : number = startAngle + deltaAngle * t;
                    let rot : cc.Quat = Quaternion.AngleAxis (angle, this.localTangents[vertIndex]);
                    this.localNormals[vertIndex] = Quaternion.Multiple(rot, this.localNormals[vertIndex]).mul((bezierPath.FlipNormals) ? -1 : 1);
                }
            }
        }

        this.anchorVertexMap = [];
        for (let anchorIndex = 0; anchorIndex < pathSplitData.anchorVertexMap.length; anchorIndex++)
        {
            this.anchorVertexMap[anchorIndex] = pathSplitData.anchorVertexMap[anchorIndex];
        }
    }

    //public constructor (bezierPath : BezierPath, transform : cc.Node, vertexSpacing : number);    
    //public constructor (bezierPath : BezierPath, pathSplitData : PathSplitData, transform : cc.Node);
    //public constructor (bezierPath : BezierPath, param1 : PathSplitData | cc.Node, param2 : any, param3? : number)
    // {
    //     if(param1 instanceof cc.Node)
    //     {
    //         let vertexSpacing : number = param2;
    //         //VertexPath(bezierPath, VertexPathUtility.SplitBezierPathEvenly (bezierPath, Math.max(vertexSpacing, this.minVertexSpacing), VertexPath.accuracy), transform)
    //     }
    //     else
    //     {

    //     }
    //     this.transform = transform;
    //     space = bezierPath.Space;
    //     isClosedLoop = bezierPath.IsClosed;
    //     int numVerts = pathSplitData.vertices.Count;
    //     length = pathSplitData.cumulativeLength[numVerts - 1];

    //     localPoints = new Vector3[numVerts];
    //     localNormals = new Vector3[numVerts];
    //     localTangents = new Vector3[numVerts];
    //     cumulativeLengthAtEachVertex = new float[numVerts];
    //     times = new float[numVerts];
    //     bounds = new Bounds ((pathSplitData.minMax.Min + pathSplitData.minMax.Max) / 2, pathSplitData.minMax.Max - pathSplitData.minMax.Min);

    //     // Figure out up direction for path
    //     up = (bounds.size.z > bounds.size.y) ? Vector3.up : -Vector3.forward;
    //     Vector3 lastRotationAxis = up;

    //     // Loop through the data and assign to arrays.
    //     for (int i = 0; i < localPoints.Length; i++) {
    //         localPoints[i] = pathSplitData.vertices[i];
    //         localTangents[i] = pathSplitData.tangents[i];
    //         cumulativeLengthAtEachVertex[i] = pathSplitData.cumulativeLength[i];
    //         times[i] = cumulativeLengthAtEachVertex[i] / length;

    //         // Calculate normals
    //         if (space == PathSpace.xyz) {
    //             if (i == 0) {
    //                 localNormals[0] = Vector3.Cross (lastRotationAxis, pathSplitData.tangents[0]).normalized;
    //             } else {
    //                 // First reflection
    //                 Vector3 offset = (localPoints[i] - localPoints[i - 1]);
    //                 float sqrDst = offset.sqrMagnitude;
    //                 Vector3 r = lastRotationAxis - offset * 2 / sqrDst * Vector3.Dot (offset, lastRotationAxis);
    //                 Vector3 t = localTangents[i - 1] - offset * 2 / sqrDst * Vector3.Dot (offset, localTangents[i - 1]);

    //                 // Second reflection
    //                 Vector3 v2 = localTangents[i] - t;
    //                 float c2 = Vector3.Dot (v2, v2);

    //                 Vector3 finalRot = r - v2 * 2 / c2 * Vector3.Dot (v2, r);
    //                 Vector3 n = Vector3.Cross (finalRot, localTangents[i]).normalized;
    //                 localNormals[i] = n;
    //                 lastRotationAxis = finalRot;
    //             }
    //         } else {
    //             localNormals[i] = Vector3.Cross (localTangents[i], up) * ((bezierPath.FlipNormals) ? 1 : -1);
    //         }
    //     }

    //     // Apply correction for 3d normals along a closed path
    //     if (space == PathSpace.xyz && isClosedLoop) {
    //         // Get angle between first and last normal (if zero, they're already lined up, otherwise we need to correct)
    //         float normalsAngleErrorAcrossJoin = Vector3.SignedAngle (localNormals[localNormals.Length - 1], localNormals[0], localTangents[0]);
    //         // Gradually rotate the normals along the path to ensure start and end normals line up correctly
    //         if (Math.abs (normalsAngleErrorAcrossJoin) > 0.1f) // don't bother correcting if very nearly correct
    //         {
    //             for (int i = 1; i < localNormals.Length; i++) {
    //                 float t = (i / (localNormals.Length - 1f));
    //                 float angle = normalsAngleErrorAcrossJoin * t;
    //                 Quaternion rot = Quaternion.AngleAxis (angle, localTangents[i]);
    //                 localNormals[i] = rot * localNormals[i] * ((bezierPath.FlipNormals) ? -1 : 1);
    //             }
    //         }
    //     }

    //     // Rotate normals to match up with user-defined anchor angles
    //     if (space == PathSpace.xyz) {
    //         for (int anchorIndex = 0; anchorIndex < pathSplitData.anchorVertexMap.Count - 1; anchorIndex++) {
    //             int nextAnchorIndex = (isClosedLoop) ? (anchorIndex + 1) % bezierPath.NumSegments : anchorIndex + 1;

    //             float startAngle = bezierPath.GetAnchorNormalAngle (anchorIndex) + bezierPath.GlobalNormalsAngle;
    //             float endAngle = bezierPath.GetAnchorNormalAngle (nextAnchorIndex) + bezierPath.GlobalNormalsAngle;
    //             float deltaAngle = Mathf.DeltaAngle (startAngle, endAngle);

    //             int startVertIndex = pathSplitData.anchorVertexMap[anchorIndex];
    //             int endVertIndex = pathSplitData.anchorVertexMap[anchorIndex + 1];

    //             int num = endVertIndex - startVertIndex;
    //             if (anchorIndex == pathSplitData.anchorVertexMap.Count - 2) {
    //                 num += 1;
    //             }
    //             for (int i = 0; i < num; i++) {
    //                 int vertIndex = startVertIndex + i;
    //                 float t = num == 1 ? 1f : i / (num - 1f);
    //                 float angle = startAngle + deltaAngle * t;
    //                 Quaternion rot = Quaternion.AngleAxis (angle, localTangents[vertIndex]);
    //                 localNormals[vertIndex] = (rot * localNormals[vertIndex]) * ((bezierPath.FlipNormals) ? -1 : 1);
    //             }
    //         }
    //     }

    //     anchorVertexMap = new int[pathSplitData.anchorVertexMap.Count];
    //     for (int anchorIndex = 0; anchorIndex < pathSplitData.anchorVertexMap.Count; anchorIndex++)
    //     {
    //         anchorVertexMap[anchorIndex] = pathSplitData.anchorVertexMap[anchorIndex];
    //     }
    //}

    // #endregion

    // #region Public methods and accessors

    public UpdateTransform(transform: cc.Node): void
    {
        this.transform = transform;
    }
    public get NumPoints(): number
    {
        return this.localPoints.length;
    }

    public GetTangent(index: number): cc.Vec3
    {
        return MathUtility.TransformDirection(this.localTangents[index], this.transform, this.space);
    }

    public GetPoint(index: number): cc.Vec3
    {
        return MathUtility.TransformPoint(this.localPoints[index], this.transform, this.space);
    }

    /// Gets point on path based on distance travelled.
    public GetPointAtDistance(dst: number, endOfPathInstruction: EndOfPathInstruction = EndOfPathInstruction.Loop): cc.Vec3
    {
        let t: number = dst / this.length;
        return this.GetPointAtTime(t, endOfPathInstruction);
    }

    /// Gets forward direction on path based on distance travelled.
    public GetDirectionAtDistance(dst: number, endOfPathInstruction: EndOfPathInstruction = EndOfPathInstruction.Loop): cc.Vec3
    {
        let t: number = dst / this.length;
        return this.GetDirection(t, endOfPathInstruction);
    }

    /// Gets normal vector on path based on distance travelled.
    public GetNormalAtDistance(dst: number, endOfPathInstruction: EndOfPathInstruction = EndOfPathInstruction.Loop): cc.Vec3
    {
        let t: number = dst / this.length;
        return this.GetNormal(t, endOfPathInstruction);
    }

    /// Gets a rotation that will orient an object in the direction of the path at this point, with local up point along the path's normal
    public GetRotationAtDistance(dst: number, endOfPathInstruction: EndOfPathInstruction = EndOfPathInstruction.Loop): cc.Quat
    {
        let t: number = dst / this.length;
        return this.GetRotation(t, endOfPathInstruction);
    }

    /// Gets point on path based on 'time' (where 0 is start, and 1 is end of path).
    public GetPointAtTime(t: number, endOfPathInstruction: EndOfPathInstruction = EndOfPathInstruction.Loop): cc.Vec3
    {
        var data = this.CalculatePercentOnPathData(t, endOfPathInstruction);
        let result : cc.Vec3 = cc.Vec3.ZERO;
        return cc.Vec3.lerp(result, this.GetPoint(data.previousIndex), this.GetPoint(data.nextIndex), data.percentBetweenIndices);
    }

    /// Gets forward direction on path based on 'time' (where 0 is start, and 1 is end of path).
    public GetDirection(t: number, endOfPathInstruction: EndOfPathInstruction = EndOfPathInstruction.Loop): cc.Vec3
    {
        var data = this.CalculatePercentOnPathData(t, endOfPathInstruction);
        let dir : cc.Vec3 = cc.Vec3.ZERO;
        cc.Vec3.lerp(dir, this.localTangents[data.previousIndex], this.localTangents[data.nextIndex], data.percentBetweenIndices);
        return MathUtility.TransformDirection(dir, this.transform, this.space);
    }

    /// Gets normal vector on path based on 'time' (where 0 is start, and 1 is end of path).
    public GetNormalInt(index: number): cc.Vec3
    {
        return MathUtility.TransformDirection(this.localNormals[index], this.transform, this.space);
    }
    public GetNormal(t: number, endOfPathInstruction: EndOfPathInstruction = EndOfPathInstruction.Loop): cc.Vec3
    {
        var data = this.CalculatePercentOnPathData(t, endOfPathInstruction);
        let normal : cc.Vec3 = cc.Vec3.ZERO;
        cc.Vec3.lerp(normal, this.localNormals[data.previousIndex], this.localNormals[data.nextIndex], data.percentBetweenIndices);
        return MathUtility.TransformDirection(normal, this.transform, this.space);
    }

    /// Gets a rotation that will orient an object in the direction of the path at this point, with local up point along the path's normal
    public GetRotation(t: number, endOfPathInstruction: EndOfPathInstruction = EndOfPathInstruction.Loop): cc.Quat
    {
        var data = this.CalculatePercentOnPathData(t, endOfPathInstruction);
        let direction : cc.Vec3 = cc.Vec3.ZERO;
        cc.Vec3.lerp(direction, this.localTangents[data.previousIndex], this.localTangents[data.nextIndex], data.percentBetweenIndices);
        let normal : cc.Vec3 = cc.Vec3.ZERO;
        cc.Vec3.lerp(normal, this.localNormals[data.previousIndex], this.localNormals[data.nextIndex], data.percentBetweenIndices);        
        return Quaternion.QuaternionLookRotation(MathUtility.TransformDirection(direction, this.transform, this.space), MathUtility.TransformDirection(normal, this.transform, this.space));        
    }

    /// Finds the closest point on the path from any point in the world
    public GetClosestPointOnPath(worldPoint: cc.Vec3): cc.Vec3
    {
        // Transform the provided worldPoint into VertexPath local-space.
        // This allows to do math on the localPoint's, thus avoiding the need to
        // transform each local vertexpath point into world space via GetPoint.
        let localPoint: cc.Vec3 = MathUtility.InverseTransformPoint(worldPoint, this.transform, this.space);

        let data: TimeOnPathData = this.CalculateClosestPointOnPathData(localPoint);
        let localResult: cc.Vec3 = cc.Vec3.ZERO;
        cc.Vec3.lerp(localResult, this.localPoints[data.previousIndex], this.localPoints[data.nextIndex], data.percentBetweenIndices);

        // Transform local result into world space
        return MathUtility.TransformPoint(localResult, this.transform, this.space);
    }

    /// Finds the 'time' (0=start of path, 1=end of path) along the path that is closest to the given point
    public GetClosestTimeOnPath(worldPoint: cc.Vec3): number
    {
        let localPoint = MathUtility.InverseTransformPoint(worldPoint, this.transform, this.space);
        let data : TimeOnPathData = this.CalculateClosestPointOnPathData(localPoint);
        return cc.misc.lerp(this.times[data.previousIndex], this.times[data.nextIndex], data.percentBetweenIndices);
    }

    /// Finds the distance along the path that is closest to the given point
    public GetClosestDistanceAlongPath(worldPoint: cc.Vec3): number
    {
        let localPoint = MathUtility.InverseTransformPoint(worldPoint, this.transform, this.space);
        let data : TimeOnPathData = this.CalculateClosestPointOnPathData(localPoint);
        return cc.misc.lerp(this.cumulativeLengthAtEachVertex[data.previousIndex], this.cumulativeLengthAtEachVertex[data.nextIndex], data.percentBetweenIndices);
    }

    public GetDistanceOfAnchor(anchorIndex: number): number
    {
        let vertexIndex : number = this.anchorVertexMap[anchorIndex];
        let cumulativeLength : number = this.cumulativeLengthAtEachVertex[vertexIndex];
        return cumulativeLength;
    }
    //#endregion

    //#region Internal methods

    /// For a given value 't' between 0 and 1, calculate the indices of the two vertices before and after t.
    /// Also calculate how far t is between those two vertices as a percentage between 0 and 1.
    CalculatePercentOnPathData(t: number, endOfPathInstruction: EndOfPathInstruction): TimeOnPathData 
    {
        // Constrain t based on the end of path instruction
        switch (endOfPathInstruction)
        {
            case EndOfPathInstruction.Loop:
                // If t is negative, make it the equivalent value between 0 and 1
                if (t < 0)
                {
                    t += Math.trunc(Math.ceil(Math.abs(t)));
                }
                t %= 1;
                break;
            case EndOfPathInstruction.Reverse:
                t = Math.PingPong(t, 1);
                break;
            case EndOfPathInstruction.Stop:
                t = cc.misc.clamp01(t);
                break;
        }

        let prevIndex: number = 0;
        let nextIndex: number = this.NumPoints - 1;
        let i : number = Math.trunc(Math.round(t * (this.NumPoints - 1))); // starting guess

        // Starts by looking at middle vertex and determines if t lies to the left or to the right of that vertex.
        // Continues dividing in half until closest surrounding vertices have been found.
        while (true)
        {
            // t lies to left
            if (t <= this.times[i])
            {
                nextIndex = i;
            }
            // t lies to right
            else
            {
                prevIndex = i;
            }
            i = Math.trunc((nextIndex + prevIndex) / 2);

            if (nextIndex - prevIndex <= 1)
            {
                break;
            }
        }

        let abPercent : number = Math.InverseLerp(this.times[prevIndex], this.times[nextIndex], t);
        return new TimeOnPathData(prevIndex, nextIndex, abPercent);
    }

    /// Calculate time data for closest point on the path from given world point
    CalculateClosestPointOnPathData(localPoint: cc.Vec3): TimeOnPathData
    {
        let minSqrDst: number = Number.MAX_VALUE;
        let closestPoint: cc.Vec3 = cc.Vec3.ZERO;
        let closestSegmentIndexA: number = 0;
        let closestSegmentIndexB: number = 0;

        for (let i = 0; i < this.localPoints.length; i++)
        {
            let nextI: number = i + 1;
            if (nextI >= this.localPoints.length) 
            {
                if (this.isClosedLoop) 
                {
                    nextI %= this.localPoints.length;
                }
                else 
                {
                    break;
                }
            }

            let closestPointOnSegment: cc.Vec3 = MathUtility.ClosestPointOnLineSegment(localPoint, this.localPoints[i], this.localPoints[nextI]);
            let sqrDst: number = (localPoint.sub(closestPointOnSegment)).magSqr();
            if (sqrDst < minSqrDst)
            {
                minSqrDst = sqrDst;
                closestPoint = closestPointOnSegment;
                closestSegmentIndexA = i;
                closestSegmentIndexB = nextI;
            }

        }
        let closestSegmentLength: number = (this.localPoints[closestSegmentIndexA].sub(this.localPoints[closestSegmentIndexB])).mag();
        let t: number = (closestPoint.sub(this.localPoints[closestSegmentIndexA])).mag() / closestSegmentLength;
        return new TimeOnPathData(closestSegmentIndexA, closestSegmentIndexB, t);
    }
    //#endregion
}

export class TimeOnPathData 
{
    public previousIndex: number;
    public nextIndex: number;
    public percentBetweenIndices: number;

    public constructor(prev: number, next: number, percentBetweenIndices: number) 
    {
        this.previousIndex = prev;
        this.nextIndex = next;
        this.percentBetweenIndices = percentBetweenIndices;
    }
}
