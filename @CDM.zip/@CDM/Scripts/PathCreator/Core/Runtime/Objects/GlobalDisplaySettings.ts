﻿//[CreateAssetMenu()]
const { ccclass, property } = cc._decorator;

export enum HandleType { Sphere, Circle, Square };

@ccclass
export default class GlobalDisplaySettings extends cc.Component 
{
    //[Header("Appearance")]
    @property anchorSize: number = 10;
    @property controlSize: number = 7;

    //[Tooltip("Should the path still be drawn when behind objects in the scene?")]
    @property visibleBehindObjects: boolean = true;
    //[Tooltip("Should the path be drawn even when the path object is not selected?")]
    @property visibleWhenNotSelected: boolean = true;
    //[Tooltip("If true, control points will be hidden when the control point mode is set to automatic. Otherwise they will inactive, but still visible.")]
    @property hideAutoControls: boolean = true;

    @property({ type: cc.Enum(HandleType) }) anchorShape: HandleType = HandleType.Sphere;
    @property({ type: cc.Enum(HandleType) }) controlShape: HandleType = HandleType.Sphere;

    //[Header("Anchor Colours")]
    @property(cc.Color) anchor = new cc.Color(242.25, 63.75, 63.75, 216.75);
    @property(cc.Color) anchorHighlighted = new cc.Color(255, 145.35, 102);
    @property(cc.Color) anchorSelected = cc.Color.WHITE;

    //[Header("Control Colours")]
    @property(cc.Color) control = new cc.Color(89.25, 153, 255, 216.75);
    @property(cc.Color) controlHighlighted = new cc.Color(216.75, 170.85, 247.35);
    @property(cc.Color) controlSelected = cc.Color.WHITE;
    @property(cc.Color) handleDisabled = new cc.Color(255, 255, 255, 51);
    @property(cc.Color) controlLine = new cc.Color(0, 0, 0, 89.25);

    //[Header("Bezier Path Colours")]
    @property(cc.Color) bezierPath = cc.Color.GREEN;
    @property(cc.Color) highlightedPath = new cc.Color(255, 153, 0);
    @property(cc.Color) bounds = new cc.Color(255, 255, 255, 102);
    @property(cc.Color) segmentBounds = new cc.Color(255, 255, 255, 102);

    //[Header("Vertex Path Colours")]
    @property(cc.Color) vertexPath = cc.Color.WHITE;

    //[Header("Normals")]
    @property(cc.Color) normals = cc.Color.YELLOW;
    //[Range(0,1)]
    @property normalsLength: number = 0.1;

    // #if UNITY_EDITOR
    //         public static GlobalDisplaySettings Load() {
    //             string[] guids = UnityEditor.AssetDatabase.FindAssets("t:GlobalDisplaySettings");
    //             if (guids.Length == 0)
    //             {
    //                 Debug.LogWarning("Could not find DisplaySettings asset. Will use default settings instead.");
    //                 return ScriptableObject.CreateInstance<GlobalDisplaySettings>();
    //             }
    //             else
    //             {
    //                 string path = UnityEditor.AssetDatabase.GUIDToAssetPath(guids[0]);
    //                 return UnityEditor.AssetDatabase.LoadAssetAtPath<GlobalDisplaySettings>(path);
    //             }
    //         }
    // #endif
}