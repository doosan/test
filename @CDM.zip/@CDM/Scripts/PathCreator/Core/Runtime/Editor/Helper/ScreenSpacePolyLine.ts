﻿import BezierPath from "../../Objects/BezierPath";
import CubicBezierUtility from "../../Utility/CubicBezierUtility";
import MathUtility from "../../Utility/MathUtility";

export default class ScreenSpacePolyLine
{
    readonly accuracyMultiplier: number = 10;
    // dont allow vertices to be spaced too far apart, as screenspace-worldspace conversion can then be noticeably off
    readonly intermediaryThreshold: number = 0.2;

    public readonly verticesWorld: Array<cc.Vec3>;
    // For each point in the polyline, says which bezier segment it belongs to
    readonly vertexToPathSegmentMap: Array<number>;
    // Stores the index in the vertices list where the start point of each segment is
    readonly segmentStartIndices: number[];

    readonly pathLengthWorld: number;
    readonly cumululativeLengthWorld: number[];

    points: cc.Vec2[];

    prevCamPos: cc.Vec3;
    prevCamRot: cc.Quat;
    premCamIsOrtho: boolean;

    readonly transform: cc.Node;
    readonly transformPosition: cc.Vec3;
    readonly transformRotation: cc.Quat;
    readonly transformScale: cc.Vec3;

    public constructor(bezierPath: BezierPath, transform: cc.Node, maxAngleError: number, minVertexDst: number, accuracy: number = 1)
    {
        this.transform = transform;
        this.transformPosition = transform.position;
        transform.getRotation(this.transformRotation);
        transform.getScale(this.transformScale);

        // Split path in vertices based on angle error
        this.verticesWorld = [];
        this.vertexToPathSegmentMap = [];
        this.segmentStartIndices = [bezierPath.NumSegments + 1];

        this.verticesWorld.push(bezierPath[0]);
        this.vertexToPathSegmentMap.push(0);
        let prevPointOnPath: cc.Vec3 = bezierPath[0];
        let dstSinceLastVertex: number = 0;
        let lastAddedPoint: cc.Vec3 = prevPointOnPath;
        let dstSinceLastIntermediary: number = 0;

        for (let segmentIndex = 0; segmentIndex < bezierPath.NumSegments; segmentIndex++)
        {
            let segmentPoints: cc.Vec3[] = bezierPath.GetPointsInSegment(segmentIndex);
            this.verticesWorld.push(segmentPoints[0]);
            this.vertexToPathSegmentMap.push(segmentIndex);
            this.segmentStartIndices[segmentIndex] = this.verticesWorld.length - 1;

            prevPointOnPath = segmentPoints[0];
            lastAddedPoint = prevPointOnPath;
            dstSinceLastVertex = 0;
            dstSinceLastIntermediary = 0;

            let estimatedSegmentLength: number = CubicBezierUtility.EstimateCurveLength(segmentPoints[0], segmentPoints[1], segmentPoints[2], segmentPoints[3]);
            let divisions: number = Math.floor(Math.ceil(estimatedSegmentLength * accuracy * this.accuracyMultiplier));
            let increment: number = 1 / divisions;

            for (let t = increment; t <= 1; t += increment)
            {
                let pointOnPath: cc.Vec3 = CubicBezierUtility.EvaluateCurve(segmentPoints[0], segmentPoints[1], segmentPoints[2], segmentPoints[3], t);
                let nextPointOnPath: cc.Vec3 = CubicBezierUtility.EvaluateCurve(segmentPoints[0], segmentPoints[1], segmentPoints[2], segmentPoints[3], t + increment);

                // angle at current point on path
                let localAngle: number = 180 - MathUtility.MinAngle(prevPointOnPath, pointOnPath, nextPointOnPath);
                // angle between the last added vertex, the current point on the path, and the next point on the path
                let angleFromPrevVertex: number = 180 - MathUtility.MinAngle(lastAddedPoint, pointOnPath, nextPointOnPath);
                let angleError: number = Math.max(localAngle, angleFromPrevVertex);


                if (angleError > maxAngleError && dstSinceLastVertex >= minVertexDst)
                {
                    dstSinceLastVertex = 0;
                    dstSinceLastIntermediary = 0;
                    this.verticesWorld.push(pointOnPath);
                    this.vertexToPathSegmentMap.push(segmentIndex);
                    lastAddedPoint = pointOnPath;
                }
                else
                {
                    if (dstSinceLastIntermediary > this.intermediaryThreshold)
                    {
                        this.verticesWorld.push(pointOnPath);
                        this.vertexToPathSegmentMap.push(segmentIndex);
                        dstSinceLastIntermediary = 0;
                    }
                    else
                    {
                        dstSinceLastIntermediary += (pointOnPath.sub(prevPointOnPath)).mag();
                    }
                    dstSinceLastVertex += (pointOnPath.sub(prevPointOnPath)).mag();
                }
                prevPointOnPath = pointOnPath;
            }
        }

        this.segmentStartIndices[bezierPath.NumSegments] = this.verticesWorld.length;

        // ensure final point gets added (unless path is closed loop)
        if (!bezierPath.IsClosed)
        {
            this.verticesWorld.push(bezierPath.GetPoint(bezierPath.NumPoints - 1));
        }
        else
        {
            this.verticesWorld.push(bezierPath.GetPoint(0));
        }

        // Calculate length
        this.cumululativeLengthWorld = [this.verticesWorld.length];
        for (let i = 0; i < this.verticesWorld.length; i++)
        {
            this.verticesWorld[i] = MathUtility.TransformPoint(this.verticesWorld[i], transform, bezierPath.Space);
            if (i > 0) 
            {
                this.pathLengthWorld += (this.verticesWorld[i - 1].sub(this.verticesWorld[i])).mag();
                this.cumululativeLengthWorld[i] = this.pathLengthWorld;
            }
        }

    }

    ComputeScreenSpace(): void
    {
        // if (Camera.current.transform.position != prevCamPos || Camera.current.transform.rotation != prevCamRot || Camera.current.orthographic != premCamIsOrtho)
        // {
        //     points = new Vector2[verticesWorld.Count];
        //     for (int i = 0; i < verticesWorld.Count; i++)
        //     {
        //         points[i] = HandleUtility.WorldToGUIPoint(verticesWorld[i]);
        //     }

        //     prevCamPos = Camera.current.transform.position;
        //     prevCamRot = Camera.current.transform.rotation;
        //     premCamIsOrtho = Camera.current.orthographic;
        // }
    }

    public CalculateMouseInfo(): MouseInfo
    {
        this.ComputeScreenSpace();

        //let mousePos : cc.Vec2 = Event.current.mousePosition;
        let mousePos : cc.Vec2 = cc.Vec2.ZERO;
        let minDst = Number.MAX_VALUE;
        let closestPolyLineSegmentIndex = 0;
        let closestBezierSegmentIndex = 0;

        for (let i = 0; i < this.points.length - 1; i++)
        {
            //복구
            //let dst : number = HandleUtility.DistancePointToLineSegment(mousePos, points[i], points[i + 1]);

            let dst : number = 10;
            if (dst < minDst)
            {
                minDst = dst;
                closestPolyLineSegmentIndex = i;
                closestBezierSegmentIndex = this.vertexToPathSegmentMap[i];
            }
        }

        let closestPointOnLine : cc.Vec2 = MathUtility.ClosestPointOnLineSegment(mousePos, this.points[closestPolyLineSegmentIndex], this.points[closestPolyLineSegmentIndex + 1]);
        let dstToPointOnLine : number = (this.points[closestPolyLineSegmentIndex].sub(closestPointOnLine)).mag();
        let percentBetweenVertices = dstToPointOnLine / (this.points[closestPolyLineSegmentIndex].sub(this.points[closestPolyLineSegmentIndex + 1])).mag();
        let closestPoint3D : cc.Vec3 = cc.Vec3.ZERO;
        cc.Vec3.lerp(closestPoint3D, this.verticesWorld[closestPolyLineSegmentIndex], this.verticesWorld[closestPolyLineSegmentIndex + 1], percentBetweenVertices);

        let distanceAlongPathWorld : number = this.cumululativeLengthWorld[closestPolyLineSegmentIndex] + cc.Vec3.distance(this.verticesWorld[closestPolyLineSegmentIndex], closestPoint3D);
        let timeAlongPath : number = distanceAlongPathWorld / this.pathLengthWorld;

        // Calculate how far between the current bezier segment the closest point on the line is
        
        let bezierSegmentStartIndex : number = this.segmentStartIndices[closestBezierSegmentIndex];
        let bezierSegmentEndIndex : number = this.segmentStartIndices[closestBezierSegmentIndex + 1];
        let bezierSegmentLength : number = this.cumululativeLengthWorld[bezierSegmentEndIndex] - this.cumululativeLengthWorld[bezierSegmentStartIndex];
        let distanceAlongBezierSegment : number = distanceAlongPathWorld - this.cumululativeLengthWorld[bezierSegmentStartIndex];
        let timeAlongBezierSegment : number = distanceAlongBezierSegment / bezierSegmentLength;

        return new MouseInfo(minDst, closestPoint3D, distanceAlongPathWorld, timeAlongPath, timeAlongBezierSegment, closestBezierSegmentIndex);
    }

    public TransformIsOutOfDate(): boolean
    {
        let a = !this.transform.position.equals(this.transformPosition);

        let q : cc.Quat = new cc.Quat();

        this.transform.getRotation(q);

        let s : cc.Vec3 = cc.Vec3.ZERO;

        this.transform.getScale(s);

        return !this.transform.position.equals(this.transformPosition) || 
               !q.equals(this.transformRotation) ||
               !s.equals(this.transformScale);
    }
}

export class MouseInfo
{
    public readonly mouseDstToLine : number;
    public readonly closestWorldPointToMouse : cc.Vec3;
    public readonly distanceAlongPathWorld : number;
    public readonly timeOnPath : number;
    public readonly timeOnBezierSegment : number;
    public readonly closestSegmentIndex : number;

    public constructor(mouseDstToLine : number, closestWorldPointToMouse : cc.Vec3, distanceAlongPathWorld : number, timeOnPath : number, timeOnBezierSegment : number, closestSegmentIndex : number)
    {
        this.mouseDstToLine = mouseDstToLine;
        this.closestWorldPointToMouse = closestWorldPointToMouse;
        this.distanceAlongPathWorld = distanceAlongPathWorld;
        this.timeOnPath = timeOnPath;
        this.timeOnBezierSegment = timeOnBezierSegment;
        this.closestSegmentIndex = closestSegmentIndex;
    }
}