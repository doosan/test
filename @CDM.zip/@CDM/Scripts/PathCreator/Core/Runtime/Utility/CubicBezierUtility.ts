﻿

/// Collection of functions related to cubic bezier curves
/// (a curve with a start and end 'anchor' point, and two 'control' points to define the shape of the curve between the anchors)
export default class CubicBezierUtility 
{
    /// Returns point at time 't' (between 0 and 1) along bezier curve defined by 4 points (anchor_1, control_1, control_2, anchor_2)

    /// Returns point at time 't' (between 0 and 1)  along bezier curve defined by 4 points (anchor_1, control_1, control_2, anchor_2)
    public static EvaluateCurve(points: cc.Vec3[], t: number): cc.Vec3;
    public static EvaluateCurve(a1: cc.Vec3, c1: cc.Vec3, c2: cc.Vec3, a2: cc.Vec3, t: number): cc.Vec3;
    public static EvaluateCurve(param1: any, param2: any, c2?: cc.Vec3, a2?: cc.Vec3, t?: number): cc.Vec3
    {
        if (param2 instanceof cc.Vec3)
        {
            let a1 = param1;
            let c1 = param2;

            t = cc.misc.clamp01(t);
            return (a1.mul((1 - t) * (1 - t) * (1 - t))).add(c1.mul(3 * (1 - t) * (1 - t) * t)).add(c2.mul(3 * (1 - t) * t * t).add(a2.mul(t * t * t)));
        }
        else
        {
            let points = param1;
            let t = param2;
            return this.EvaluateCurve(points[0], points[1], points[2], points[3], t);
        }
    }

    /// Returns a vector tangent to the point at time 't'
    /// This is the vector tangent to the curve at that point

    public static EvaluateCurveDerivative(points: cc.Vec3[], t: number): cc.Vec3;
    public static EvaluateCurveDerivative(a1: cc.Vec3, c1: cc.Vec3, c2: cc.Vec3, a2: cc.Vec3, t: number): cc.Vec3;
    public static EvaluateCurveDerivative(param1: any, param2: any, c2?: cc.Vec3, a2?: cc.Vec3, t?: number): cc.Vec3
    {
        if (param2 instanceof cc.Vec3)
        {
            let a1 = param1;
            let c1 = param2;

            t = cc.misc.clamp01(t);
            return (c1.sub(a1).mul(3 * (1 - t) * (1 - t))).add(c2.sub(c1).mul(6 * (1 - t) * t)).add(a2.sub(c2).mul(3 * t * t));
        }
        else
        {
            let points = param1;
            let t = param2;
            return this.EvaluateCurveDerivative(points[0], points[1], points[2], points[3], t);
        }
    }

    public static EvaluateCurveSecondDerivative(points: cc.Vec3[], t: number): cc.Vec3;
    public static EvaluateCurveSecondDerivative(a1: cc.Vec3, c1: cc.Vec3, c2: cc.Vec3, a2: cc.Vec3, t: number): cc.Vec3;
    public static EvaluateCurveSecondDerivative(param1: any, param2: any, c2?: cc.Vec3, a2?: cc.Vec3, t?: number): cc.Vec3
    {
        if (param2 instanceof cc.Vec3)
        {
            let a1 = param1;
            let c1 = param2;

            t = cc.misc.clamp01(t);
            return (c2.sub(c1.add(a1).mul(2)).mul(6 * (1 - t))).add((a2.sub(c2.add(c1).mul(2))).mul(6 * t));
        }
        else
        {
            let points = param1;
            let t = param2;
            return this.EvaluateCurveSecondDerivative(points[0], points[1], points[2], points[3], t);
        }
    }

    public static Normal(points: cc.Vec3[], t: number): cc.Vec3;
    public static Normal(a1: cc.Vec3, c1: cc.Vec3, c2: cc.Vec3, a2: cc.Vec3, t: number): cc.Vec3;
    public static Normal(param1: any, param2: any, c2?: cc.Vec3, a2?: cc.Vec3, t?: number): cc.Vec3
    {
        if (param2 instanceof cc.Vec3)
        {
            let a1 = param1;
            let c1 = param2;

            let tangent: cc.Vec3 = this.EvaluateCurveDerivative(a1, c1, c2, a2, t);
            let nextTangent: cc.Vec3 = this.EvaluateCurveSecondDerivative(a1, c1, c2, a2, t);
            let c: cc.Vec3 = cc.Vec3.ZERO;
            cc.Vec3.cross(c, nextTangent, tangent);
            let result: cc.Vec3 = cc.Vec3.ZERO;
            result = cc.Vec3.cross(result, c, tangent).normalize();
            return result;
        }
        else
        {
            let points = param1;
            let t = param2;
            return this.Normal(points[0], points[1], points[2], points[3], t);
        }
    }

    // public static Bounds CalculateSegmentBounds (Vector3 p0, Vector3 p1, Vector3 p2, Vector3 p3) {
    //     MinMax3D minMax = new MinMax3D ();
    //     minMax.AddValue (p0);
    //     minMax.AddValue (p3);

    //     List<float> extremePointTimes = ExtremePointTimes (p0,p1,p2,p3);
    //     foreach (float t in extremePointTimes) {
    //         minMax.AddValue (CubicBezierUtility.EvaluateCurve (p0, p1, p2, p3, t));
    //     }

    //     return new Bounds ((minMax.Min + minMax.Max) / 2, minMax.Max - minMax.Min);
    // }

    /// Splits curve into two curves at time t. Returns 2 arrays of 4 points.
    public static SplitCurve(points: cc.Vec3[], t: number): cc.Vec3[][] 
    {
        let a1: cc.Vec3 = cc.Vec3.ZERO;
        cc.Vec3.lerp(a1, points[0], points[1], t);
        let a2: cc.Vec3 = cc.Vec3.ZERO;
        cc.Vec3.lerp(a2, points[1], points[2], t);
        let a3: cc.Vec3 = cc.Vec3.ZERO;
        cc.Vec3.lerp(a3, points[2], points[3], t);
        let b1: cc.Vec3 = cc.Vec3.ZERO;
        cc.Vec3.lerp(b1, a1, a2, t);
        let b2: cc.Vec3 = cc.Vec3.ZERO;
        cc.Vec3.lerp(b2, a2, a3, t);
        let pointOnCurve = cc.Vec3.ZERO;
        cc.Vec3.lerp(pointOnCurve, b1, b2, t);

        let v31: cc.Vec3[] = [points[0], a1, b1, pointOnCurve];
        let v32: cc.Vec3[] = [pointOnCurve, b2, a3, points[3]];
        let result: cc.Vec3[][] = [v31, v32];

        return result;
    }

    // Crude, but fast estimation of curve length.
    public static EstimateCurveLength(p0: cc.Vec3, p1: cc.Vec3, p2: cc.Vec3, p3: cc.Vec3): number
    {
        let controlNetLength: number = p0.sub(p1).mag() + p1.sub(p2).mag() + p2.sub(p3).mag();
        let estimatedCurveLength: number = p0.sub(p3).mag() + controlNetLength / 2;
        return estimatedCurveLength;
    }

    /// Times of stationary points on curve (points where derivative is zero on any axis)
    public static ExtremePointTimes(p0: cc.Vec3, p1: cc.Vec3, p2: cc.Vec3, p3: cc.Vec3): Array<number>
    {
        // coefficients of derivative function
        let a: cc.Vec3 = p0.mul(-1).add(p1.mul(3).sub(p2.add(p3).mul(3))).mul(3);
        let b: cc.Vec3 = p0.sub((p1.add(p2)).mul(2)).mul(6);
        let c: cc.Vec3 = (p1.sub(p0)).mul(3);

        let times: Array<number> = [];
        this.StationaryPointTimes(a.x, b.x, c.x).forEach(value =>
        {
            times.push(value);
        }, this);
        this.StationaryPointTimes(a.y, b.y, c.y).forEach(value =>
        {
            times.push(value);
        }, this);
        this.StationaryPointTimes(a.y, b.y, c.y).forEach(value =>
        {
            times.push(value);
        }, this);

        return times;
    }

    // Finds times of stationary points on curve defined by ax^2 + bx + c.
    // Only times between 0 and 1 are considered as Bezier only uses values in that range
    static StationaryPointTimes(a: number, b: number, c: number): Array<number>
    {
        let times: Array<number> = [];

        // from quadratic equation: y = [-b +- sqrt(b^2 - 4ac)]/2a
        if (a != 0) 
        {
            let discriminant: number = b * b - 4 * a * c;
            if (discriminant >= 0) 
            {
                let s: number = Math.sqrt(discriminant);
                let t1: number = (-b + s) / (2 * a);
                if (t1 >= 0 && t1 <= 1)
                {
                    times.push(t1);
                }

                if (discriminant != 0)
                {
                    let t2: number = (-b - s) / (2 * a);

                    if (t2 >= 0 && t2 <= 1)
                    {
                        times.push(t2);
                    }
                }
            }
        }
        return times;
    }
}
