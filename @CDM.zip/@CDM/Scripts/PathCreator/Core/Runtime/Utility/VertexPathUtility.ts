﻿import BezierPath from "../Objects/BezierPath";
import MinMax3D from "../Objects/MinMax3D";
import CubicBezierUtility from "./CubicBezierUtility";
import MathUtility from "./MathUtility";

const { ccclass, property } = cc._decorator;

@ccclass
export default class VertexPathUtility
{
    public static SplitBezierPathByAngleError(bezierPath : BezierPath, maxAngleError : number, minVertexDst : number, accuracy : number) : PathSplitData
    {
    	let splitData : PathSplitData = new PathSplitData();

        splitData.vertices.push(bezierPath.GetPoint(0));
        splitData.tangents.push(CubicBezierUtility.EvaluateCurveDerivative(bezierPath.GetPointsInSegment(0), 0).normalize());
        splitData.cumulativeLength.push(0);
        splitData.anchorVertexMap.push(0);
    	splitData.minMax.AddValue(bezierPath.GetPoint(0));

        let prevPointOnPath : cc.Vec3 = bezierPath.GetPoint(0);
        let lastAddedPoint : cc.Vec3 = bezierPath.GetPoint(0);

        let currentPathLength : number = 0;
        let dstSinceLastVertex : number = 0;

        // Go through all segments and split up into vertices
        for (let segmentIndex = 0; segmentIndex < bezierPath.NumSegments; segmentIndex++)
        {
            let segmentPoints : cc.Vec3[] = bezierPath.GetPointsInSegment(segmentIndex);            

            let estimatedSegmentLength : number = CubicBezierUtility.EstimateCurveLength(segmentPoints[0], segmentPoints[1], segmentPoints[2], segmentPoints[3]);

            let divisions : number = Math.floor(Math.ceil(estimatedSegmentLength * accuracy));
            let increment : number = 1 / divisions;

            for (let t = increment; t <= 1; t += increment)
            {
                let isLastPointOnPath : boolean = (t + increment > 1 && segmentIndex == bezierPath.NumSegments - 1);
                if (isLastPointOnPath)
                {
                    t = 1;
                }
                let pointOnPath : cc.Vec3 = CubicBezierUtility.EvaluateCurve(segmentPoints, t);
                let nextPointOnPath : cc.Vec3 = CubicBezierUtility.EvaluateCurve(segmentPoints, t + increment);

                // angle at current point on path
                let localAngle : number = 180 - MathUtility.MinAngle(prevPointOnPath, pointOnPath, nextPointOnPath);
                // angle between the last added vertex, the current point on the path, and the next point on the path
                let angleFromPrevVertex : number = 180 - MathUtility.MinAngle(lastAddedPoint, pointOnPath, nextPointOnPath);
                let angleError : number = Math.max(localAngle, angleFromPrevVertex);

                if ((angleError > maxAngleError && dstSinceLastVertex >= minVertexDst) || isLastPointOnPath)
                {
                    currentPathLength += (lastAddedPoint.sub(pointOnPath)).mag();
                    splitData.cumulativeLength.push(currentPathLength);
                    splitData.vertices.push(pointOnPath);
                    splitData.tangents.push(CubicBezierUtility.EvaluateCurveDerivative(segmentPoints, t).normalize());
    				splitData.minMax.AddValue(pointOnPath);
                    dstSinceLastVertex = 0;
                    lastAddedPoint = pointOnPath;
                }
                else
                {
                    dstSinceLastVertex += (pointOnPath.sub(prevPointOnPath)).mag();
                }
                prevPointOnPath = pointOnPath;
            }
            splitData.anchorVertexMap.push(splitData.vertices.length - 1);
        }
    	return splitData;
    }

    // public static PathSplitData SplitBezierPathEvenly(BezierPath bezierPath, float spacing, float accuracy)
    // {
    // 	PathSplitData splitData = new PathSplitData();

    //     splitData.vertices.Add(bezierPath[0]);
    //     splitData.tangents.Add(CubicBezierUtility.EvaluateCurveDerivative(bezierPath.GetPointsInSegment(0), 0).normalized);
    //     splitData.cumulativeLength.Add(0);
    //     splitData.anchorVertexMap.Add(0);
    // 	splitData.minMax.AddValue(bezierPath[0]);

    //     Vector3 prevPointOnPath = bezierPath[0];
    //     Vector3 lastAddedPoint = bezierPath[0];

    //     float currentPathLength = 0;
    //     float dstSinceLastVertex = 0;

    //     // Go through all segments and split up into vertices
    //     for (int segmentIndex = 0; segmentIndex < bezierPath.NumSegments; segmentIndex++)
    //     {
    //         Vector3[] segmentPoints = bezierPath.GetPointsInSegment(segmentIndex);
    //         float estimatedSegmentLength = CubicBezierUtility.EstimateCurveLength(segmentPoints[0], segmentPoints[1], segmentPoints[2], segmentPoints[3]);
    //         int divisions = Mathf.CeilToInt(estimatedSegmentLength * accuracy);
    //         float increment = 1f / divisions;

    //         for (float t = increment; t <= 1; t += increment)
    //         {
    //             bool isLastPointOnPath = (t + increment > 1 && segmentIndex == bezierPath.NumSegments - 1);
    //             if (isLastPointOnPath)
    //             {
    //                 t = 1;
    //             }
    //             Vector3 pointOnPath = CubicBezierUtility.EvaluateCurve(segmentPoints, t);
    // 			dstSinceLastVertex += (pointOnPath - prevPointOnPath).magnitude;

    // 			// If vertices are now too far apart, go back by amount we overshot by
    // 			if (dstSinceLastVertex > spacing) {
    // 				float overshootDst = dstSinceLastVertex - spacing;
    // 				pointOnPath += (prevPointOnPath-pointOnPath).normalized * overshootDst;
    // 				t-=increment;
    // 			}

    //             if (dstSinceLastVertex >= spacing || isLastPointOnPath)
    //             {
    //                 currentPathLength += (lastAddedPoint - pointOnPath).magnitude;
    //                 splitData.cumulativeLength.Add(currentPathLength);
    //                 splitData.vertices.Add(pointOnPath);
    //                 splitData.tangents.Add(CubicBezierUtility.EvaluateCurveDerivative(segmentPoints, t).normalized);
    // 				splitData.minMax.AddValue(pointOnPath);
    //                 dstSinceLastVertex = 0;
    //                 lastAddedPoint = pointOnPath;
    //             }
    //             prevPointOnPath = pointOnPath;
    //         }
    //         splitData.anchorVertexMap.Add(splitData.vertices.Count - 1);
    //     }
    // 	return splitData;
    // }



}

export class PathSplitData 
{
    public vertices : Array<cc.Vec3> = [];
    public tangents : Array<cc.Vec3> = [];
    public cumulativeLength : Array<number> = [];
    public anchorVertexMap : Array<number> = [];
    public minMax : MinMax3D = new MinMax3D();
}