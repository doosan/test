﻿import { Quaternion } from "../../../../Util/Util";
import { PathSpace } from "../Objects/PathSpace";

export default class MathUtility 
{
    // Transform point from local to world space
    public static TransformPoint(p: cc.Vec3, t: cc.Node, space: PathSpace): cc.Vec3
    {
        // // path only works correctly for uniform scales, so average out xyz global scale

        let s : cc.Vec3 = cc.Vec3.ZERO;
        t.getScale(s);

        let scale : number = cc.Vec3.dot(s, cc.Vec3.ONE) / 3;
        let constrainedPos : cc.Vec3 = t.position;
        let constrainedRot : cc.Quat = new cc.Quat();
        t.getRotation(constrainedRot);
        let [pos, rot] = this.ConstrainPosRot (constrainedPos, constrainedRot, space);
        return Quaternion.Multiple(rot, p).mul(scale).add(pos);

        //return cc.Vec3.ZERO;
    }

    // Transform point from world to local space
    public static InverseTransformPoint(p: cc.Vec3, t: cc.Node, space: PathSpace): cc.Vec3
    {
        // Vector3 constrainedPos = t.position;
        // Quaternion constrainedRot = t.rotation;
        // ConstrainPosRot (ref constrainedPos, ref constrainedRot, space);

        // // path only works correctly for uniform scales, so average out xyz global scale
        // float scale = Vector3.Dot (t.lossyScale, Vector3.one) / 3;
        // var offset = p - constrainedPos;

        // return Quaternion.Inverse (constrainedRot) * offset / scale;

        return cc.Vec3.ZERO;
    }

    // Transform vector from local to world space (affected by rotation and scale, but not position)
    public static TransformVector(p: cc.Vec3, t: cc.Node, space: PathSpace): cc.Vec3
    {
        // path only works correctly for uniform scales, so average out xyz global scale
        // float scale = Vector3.Dot (t.lossyScale, Vector3.one) / 3;
        // Quaternion constrainedRot = t.rotation;
        // ConstrainRot (ref constrainedRot, space);
        // return constrainedRot * p * scale;

        return cc.Vec3.ZERO;
    }

    // Transform vector from world to local space (affected by rotation and scale, but not position)
    public static InverseTransformVector(p: cc.Vec3, t: cc.Node, space: PathSpace): cc.Vec3
    {
        // Quaternion constrainedRot = t.rotation;
        // ConstrainRot (ref constrainedRot, space);
        // // path only works correctly for uniform scales, so average out xyz global scale
        // float scale = Vector3.Dot (t.lossyScale, Vector3.one) / 3;
        // return Quaternion.Inverse (constrainedRot) * p / scale;

        return cc.Vec3.ZERO;
    }

    // Transform vector from local to world space (affected by rotation, but not position or scale)
    public static TransformDirection(p: cc.Vec3, t: cc.Node, space: PathSpace): cc.Vec3
    {
        let constrainedRot : cc.Quat = new cc.Quat();
        t.getRotation(constrainedRot);
        this.ConstrainRot (constrainedRot, space);
        return Quaternion.Multiple(constrainedRot, p);
    }

    // Transform vector from world to local space (affected by rotation, but not position or scale)
    public static InverseTransformDirection(p: cc.Vec3, t: cc.Node, space: PathSpace): cc.Vec3
    {
        // Quaternion constrainedRot = t.rotation;
        // ConstrainRot (ref constrainedRot, space);
        // return Quaternion.Inverse (constrainedRot) * p;

        return cc.Vec3.ZERO;
    }

    public static LineSegmentsIntersect(a1: cc.Vec2, a2: cc.Vec2, b1: cc.Vec2, b2: cc.Vec2): boolean 
    {
        let d: number = (b2.x - b1.x) * (a1.y - a2.y) - (a1.x - a2.x) * (b2.y - b1.y);
        if (d == 0)
            return false;
        let t: number = ((b1.y - b2.y) * (a1.x - b1.x) + (b2.x - b1.x) * (a1.y - b1.y)) / d;
        let u: number = ((a1.y - a2.y) * (a1.x - b1.x) + (a2.x - a1.x) * (a1.y - b1.y)) / d;

        return t >= 0 && t <= 1 && u >= 0 && u <= 1;
    }

    public static LinesIntersect(a1: cc.Vec2, a2: cc.Vec2, a3: cc.Vec2, a4: cc.Vec2): boolean
    {
        return (a1.x - a2.x) * (a3.y - a4.y) - (a1.y - a2.y) * (a3.x - a4.x) != 0;
    }

    public static PointOfLineLineIntersection(a1: cc.Vec2, a2: cc.Vec2, a3: cc.Vec2, a4: cc.Vec2): cc.Vec2
    {
        let d: number = (a1.x - a2.x) * (a3.y - a4.y) - (a1.y - a2.y) * (a3.x - a4.x);
        if (d == 0) 
        {
            //    Debug.LogError ("Lines are parallel, please check that this is not the case before calling line intersection method");
            return cc.Vec2.ZERO;
        }
        else 
        {
            let n: number = (a1.x - a3.x) * (a3.y - a4.y) - (a1.y - a3.y) * (a3.x - a4.x);
            let t: number = n / d;
            return a1.add(a2.sub(a1)).mul(t);
        }
    }

    // public static ClosestPointOnLineSegment(p: cc.Vec2, a: cc.Vec2, b: cc.Vec2): cc.Vec2 
    // {
    //     let aB: cc.Vec2 = b.sub(a);
    //     let aP: cc.Vec2 = p.sub(a);
    //     let sqrLenAB: number = aB.magSqr();

    //     if (sqrLenAB == 0)
    //         return a;

    //     let t: number = cc.misc.clamp01(cc.Vec2.dot(aP, aB) / sqrLenAB);
    //     return a.add(aB.mul(t));
    // }
    
    public static ClosestPointOnLineSegment(p: cc.Vec3 | cc.Vec2, a: cc.Vec3 | cc.Vec2, b: cc.Vec3 | cc.Vec2): any
    {
        if(a instanceof cc.Vec3 && b instanceof cc.Vec3 && p instanceof cc.Vec3)
        {
            let aB: cc.Vec3 = b.sub(a);
            let aP: cc.Vec3 = p.sub(a);
            let sqrLenAB: number = aB.magSqr();

            if (sqrLenAB == 0)
                return a;

            let t: number = cc.misc.clamp01(cc.Vec3.dot(aP, aB) / sqrLenAB);
            return a.add(aB.mul(t));
        }
        else if(a instanceof cc.Vec2 && b instanceof cc.Vec2 && p instanceof cc.Vec2)
        {
            let aB: cc.Vec2 = b.sub(a);
            let aP: cc.Vec2 = p.sub(a);
            let sqrLenAB: number = aB.magSqr();

            if (sqrLenAB == 0)
                return a;

            let t: number = cc.misc.clamp01(cc.Vec2.dot(aP, aB) / sqrLenAB);
            return a.add(aB.mul(t));
        }
    }

    public static SideOfLine(a: cc.Vec2, b: cc.Vec2, c: cc.Vec2): number
    {
        return Math.trunc(Math.sign((c.x - a.x) * (-b.y + a.y) + (c.y - a.y) * (b.x - a.x)));
    }

    /// returns the smallest angle between ABC. Never greater than 180
    public static MinAngle(a: cc.Vec3, b: cc.Vec3, c: cc.Vec3): number
    {
        return cc.Vec3.angle(a.sub(b), c.sub(b));
    }

    public static PointInTriangle(a: cc.Vec2, b: cc.Vec2, c: cc.Vec2, p: cc.Vec2): boolean
    {
        let area: number = 0.5 * (-b.y * c.x + a.y * (-b.x + c.x) + a.x * (b.y - c.y) + b.x * c.y);
        let s: number = 1 / (2 * area) * (a.y * c.x - a.x * c.y + (c.y - a.y) * p.x + (a.x - c.x) * p.y);
        let t: number = 1 / (2 * area) * (a.x * b.y - a.y * b.x + (a.y - b.y) * p.x + (b.x - a.x) * p.y);
        return s >= 0 && t >= 0 && (s + t) <= 1;
    }

    public static PointsAreClockwise(points: cc.Vec2[]): boolean
    {
        let signedArea: number = 0;
        for (let i = 0; i < points.length; i++) 
        {
            let nextIndex: number = (i + 1) % points.length;
            signedArea += (points[nextIndex].x - points[i].x) * (points[nextIndex].y + points[i].y);
        }

        return signedArea >= 0;
    }

    //static void ConstrainPosRot (ref Vector3 pos, ref Quaternion rot, PathSpace space)
    static ConstrainPosRot(pos: cc.Vec3, rot: cc.Quat, space: PathSpace) : [cc.Vec3, cc.Quat]
    {
        if (space == PathSpace.xy) 
        {
            var eulerAngles = cc.Vec3.ZERO;
            rot.toEuler(eulerAngles);
            if (eulerAngles.x != 0 || eulerAngles.y != 0) 
            {
                rot = Quaternion.AngleAxis(eulerAngles.z, cc.Vec3.FORWARD);
            }
            pos = new cc.Vec3(pos.x, pos.y, 0);
        }
        else if (space == PathSpace.xz) 
        {
            var eulerAngles = cc.Vec3.ZERO;
            rot.toEuler(eulerAngles);
            if (eulerAngles.x != 0 || eulerAngles.z != 0) 
            {
                rot = Quaternion.AngleAxis(eulerAngles.y, cc.Vec3.UP);
            }
            pos = new cc.Vec3(pos.x, 0, pos.z);
        }

        return [pos, rot];
    }

    //static ConstrainRot (ref Quaternion rot, PathSpace space) : void
    static ConstrainRot(rot: cc.Quat, space: PathSpace): void
    {
        if (space == PathSpace.xy) 
        {
            var eulerAngles = cc.Vec3.ZERO;
            rot.toEuler(eulerAngles);
            if (eulerAngles.x != 0 || eulerAngles.y != 0) 
            {
                rot = Quaternion.AngleAxis(eulerAngles.z, cc.Vec3.FORWARD);
            }
        }
        else if (space == PathSpace.xz) 
        {
            var eulerAngles = cc.Vec3.ZERO;
            rot.toEuler(eulerAngles);
            if (eulerAngles.x != 0 || eulerAngles.z != 0) 
            {
                rot = Quaternion.AngleAxis(eulerAngles.y, cc.Vec3.UP);
            }
        }
    }
}