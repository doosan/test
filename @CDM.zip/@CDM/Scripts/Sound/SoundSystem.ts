import SingleObjects from "../System/SingleObjects";
import CoroutineComponent  from "../System/CoroutineComponent";
import GameObjectPool from "../ObjectPool/GameObjectPool";
import { Time } from "../Time/Time";
import { Coroutine, WaitForSeconds } from "../System/CoroutineComponent";

const { ccclass, property } = cc._decorator;

export enum SoundPlayType
{
    Once,
    Loop
}

//[Flags]
export enum SoundProofDepthType
{
    None = 0,
    Bgm = 1,
    Sfx = 2,
}

@ccclass("SoundProofDepthInfo")
export class SoundProofDepthInfo
{
    @property() value: number = 0;
    @property({ type: cc.Enum(SoundProofDepthType) }) type: SoundProofDepthType = SoundProofDepthType.None;

    public constructor(...params: any)
    {
        this.value = params[0];
        this.type = params[1];
    }
}

//[Serializable]
//@ccclass("SoundInfo")
export class SoundInfo
{
    public key: string = '';
    public timestamp: number = 0;

    // OnDestory 때 사라질 수 있는 게임 오브젝트
    public audioSource: cc.AudioSource = null;  //AudioSource 

    public play: Coroutine = null;
    public fade: Coroutine = null;
    public type: SoundPlayType = SoundPlayType.Once;

    public masterVolume: number = 1;
    public volume: number = 1;
    public volumeBegin: number = 0;
    public volumeDiff: number = 0;
    public volumeEnd: number = 0;
    public repeat: number = 1;
    public duration: number = 0;
    public fadeOut: number = 0;

    public depth: number = 0;
    public isBgm: boolean = false;
    public depthType : SoundProofDepthType = SoundProofDepthType.None;
}

@ccclass
export default class SoundSystem extends CoroutineComponent
{
    static instance: SoundSystem;

    static get Instance(): SoundSystem
    {
        if (SoundSystem.instance != null)
        {
            return SoundSystem.instance;
        }

        let newNode = new cc.Node("SoundSystem");
        SoundSystem.instance = newNode.addComponent(SoundSystem);
        cc.game.addPersistRootNode(newNode);
        newNode.setParent(SingleObjects.Instance.node);

        return SoundSystem.instance;
    }

    public get BgmVolumeLimit(): number 
    {
        return this.bgmVolumeLimit;
    }

    public set BgmVolumeLimit(value: number)
    {
        this.bgmVolumeLimit = value;
        this.BgmVolume = value;
    }

    private bgmVolumeLimit: number = 0;
    public set BgmVolume(value: number)
    {
        value = cc.misc.clampf(value, 0, this.BgmVolumeLimit);
        if (this.bgmVolume != value)
        {
            this.bgmVolume = value;
            this.ChangeMasterVolume(true, value);
        }
    }

    public get SfxVolumeLimit(): number     
    {
        return this.sfxVolumeLimit;
    }

    public set SfxVolumeLimit(value: number)     
    {
        this.sfxVolumeLimit = value;
        this.SfxVolume = value;
    }
    private sfxVolumeLimit: number;

    public set SfxVolume(value: number)
    {
        value = cc.misc.clampf(value, 0, this.SfxVolumeLimit);
        if (this.sfxVolume != value)
        {
            this.sfxVolume = value;
            this.ChangeMasterVolume(false, value);
        }
    }

    private readonly INITIAL_POOL_SIZE: number = 10;

    private bgmVolume: number = 1;
    //[SerializeField] 
    private sfxVolume: number = 1;

    private audioSourcePool: GameObjectPool<cc.AudioSource> = null;
    private poolRoot: cc.Node = null;
    private inPlaying: cc.Node = null;
    private wholeFade: Coroutine = null;
    //[SerializeField] 
    private soundsInPlay: Array<SoundInfo> = null;
    private soundsInFade: Array<SoundInfo> = null;

    //[SerializeField] 
    private soundproofDepthInfos: Array<SoundProofDepthInfo> = null;
    private fadeOutList:Array<string> = null;   //HashSet<string>

    private initialized: boolean = false;

    onLoad()
    {
        SoundSystem.instance = this;
        this.Initialize();
    }
    
    public Initialize(): void
    {
        if (this.poolRoot != null)
        {
            return;
        }

        this.poolRoot = new cc.Node("AudioSourcePool");
        this.poolRoot.setParent(this.node);

        this.inPlaying = new cc.Node("InPlaying");
        this.inPlaying.setParent(this.poolRoot);

        this.audioSourcePool = new GameObjectPool<cc.AudioSource>(
            this.poolRoot,
            this.INITIAL_POOL_SIZE,
            this.CreateAudioSource,
            true,
            true
        );

        this.soundsInPlay = new Array<SoundInfo>();
        this.soundsInFade = new Array<SoundInfo>();
        this.fadeOutList = new Array<string>();

        this.soundproofDepthInfos = [];
    }

    private CreateAudioSource(): cc.AudioSource
    {
        var container = new cc.Node("AudioSource");
        container.setParent(this.poolRoot);

        var audioSource = container.addComponent(cc.AudioSource);
        return audioSource;
    }

    public IsInPlay(key: string): boolean
    {
        return this.soundsInPlay.find((sound) => sound.key == key) != null;
    }

    public Play(key: string, audioClip: cc.AudioClip, type: SoundPlayType = SoundPlayType.Once, delay: number = 0, repeat: number = 1, fadeIn: number = 0, fadeOut: number = 0, duration: number = 0, depth: number = 0, isBgm: boolean = false, volume: number = 1, pitch: number = 1, freezing: number = 0, time: number = 0)
    {
        if (audioClip == null)
        {
            return;
        }

        // 같은 사운드가 지정한 시간 안에 여러번 플레이되는 것을 방지
        if (this.soundsInPlay.find((sound) => (sound.timestamp + freezing) >= Time.time && sound.key == key) == null)
        {
            this._Play(key, audioClip, type, delay, repeat, fadeIn, fadeOut, duration, depth, isBgm, volume, pitch, time);
        }
    }

    private _Play(key: string,
        audioClip: cc.AudioClip,
        type: SoundPlayType = SoundPlayType.Once,
        delay: number = 0,
        repeat: number = 1,
        fadeIn: number = 0,
        fadeOut: number = 0,
        duration: number = 0,
        depth: number = 0,
        isBgm: boolean = false,
        volume: number = 1,
        pitch: number = 1,
        time: number = 1): void
    {
        let audioSource: cc.AudioSource = this.audioSourcePool.Get();

        while (audioSource == null)
        {
            audioSource = this.audioSourcePool.Get();
        }
        audioSource.node.setParent(this.inPlaying);
        audioSource.setCurrentTime(time);
        audioSource.playOnLoad = false;
        audioSource.clip = audioClip;
        audioSource.name = audioClip.name;
        audioSource.loop = type == SoundPlayType.Loop || repeat > 1;
        
        //audioSource.volume.pitch = pitch;

        var sound = new SoundInfo();
        sound.key = key;
        sound.timestamp = Time.time;
        sound.type = type;
        sound.audioSource = audioSource;
        sound.volume = volume;
        sound.masterVolume = isBgm == true ? this.bgmVolume : this.sfxVolume;
        sound.repeat = repeat;
        sound.duration = duration;
        sound.depth = depth;
        sound.isBgm = isBgm;
        sound.fadeOut = fadeOut;
        sound.depthType = isBgm ? SoundProofDepthType.Bgm : SoundProofDepthType.Sfx;
        if (sound.isBgm == true)
        {
            let found: SoundInfo = this.soundsInPlay.find((finding) => finding.isBgm == true);
            if (found != null)
                this.Stop(found);
        }

        this.soundsInPlay.push(sound);

        sound.play = this.startCoroutine(this.PlayCoroutine(sound, delay, fadeIn), this);
    }

    public FadeOutWhenDestroyed(key:string):void
    {
        if (this.fadeOutList.includes(key) == false)
        {
            this.fadeOutList.push(key);
        }
    }

    public StopAll(): void
    {
        for (let i = this.soundsInPlay.length - 1; i >= 0; i--)
        {
            let sound: SoundInfo = this.soundsInPlay[i];

            if (this.fadeOutList.includes(sound.key))
            {
                this.Stop(sound.key, 0.4);
            }
            else
            {
                if (sound.play != null)
                {
                    this.stopCoroutine(sound.play);
                    sound.play = null;
                }

                this.Return(sound.audioSource);
                //this.soundsInPlay.RemoveAt(i);
                this.soundsInPlay.splice(i, 1);
            }
        }

        this.soundsInPlay.length = 0;
    }

    private Return(audioSource: cc.AudioSource): void
    {
        if (audioSource != null)
        {
            audioSource.stop();
            audioSource.node.setParent(this.poolRoot);
            audioSource.name = "AudioSource";
            this.audioSourcePool.Return(audioSource);
        }
    }

    public StopBGM(fadeOut: number = 1): void
    {
        let found: SoundInfo = this.soundsInPlay.find((finding) => finding.isBgm == true);
        if (found != null)
        {
            this.Stop(found.key, fadeOut);
        }
    }

    public Stop(key: string, fadeOut: number): void; // 같은 사운드를 모두 정지
    public Stop(sound: SoundInfo): void; // 해당 사운드만 정지
    public Stop(param1: string | SoundInfo, param2?: number): void
    {
        if (param1 instanceof SoundInfo)
        {
            let sound = param1;
            let foundIndex: number = this.soundsInPlay.indexOf(sound);
            if (foundIndex != -1)
            {
                this.soundsInPlay.splice(foundIndex, 1);

                if (sound.audioSource != null)
                {
                    // BGM이 전환될 때 FadeOut 되면서 이명같이 불편한 느낌이 들어 sound.fadeOut에서 0으로 바꿈
                    this.startCoroutine(this.StopCoroutine(sound, 0), this);
                }
            }
        }
        else
        {
            let key: string = param1;
            let fadeOut = param2 == null ? 0 : param2;

            for (let i = this.soundsInPlay.length - 1; i >= 0; i--)
            {
                let sound: SoundInfo = this.soundsInPlay[i];
                if (sound.key != key)
                    continue;

                this.soundsInPlay.splice(i, 1);

                if (sound.audioSource != null)
                {
                    this.startCoroutine(this.StopCoroutine(sound, fadeOut), this);
                }
            }
        }
    }

    public GetAudioSource(key: string): cc.AudioSource
    {
        for (let i = this.soundsInPlay.length - 1; i >= 0; i--)
        {
            let sound: SoundInfo = this.soundsInPlay[i];
            if (sound.key == key)
            {
                return sound.audioSource;
            }
        }

        return null;
    }

    *StopCoroutine(sound: SoundInfo, fadeOut: number)
    {
        sound.fade = this.startCoroutine(this.FadeVolumeCoroutine(sound.audioSource, fadeOut, this.FilterSoundproof(sound), 0), this);
        yield sound.fade;
        sound.fade = null;

        if (sound.play != null)
        {
            this.stopCoroutine(sound.play);
            sound.play = null;
        }

        this.Return(sound.audioSource);
    }

    *PlayCoroutine(sound: SoundInfo, delay: number, fadeIn: number)
    {
        if (delay > 0)
        {
            yield new WaitForSeconds(delay);
        }

        if (sound.audioSource != null)
        {
            sound.audioSource.play();
        }

        let timeBegin: number = Time.time;
        let fadeInDuration: number = fadeIn;
        if (sound.duration > 0 && fadeInDuration > sound.duration)
        {
            fadeInDuration = sound.duration;
        }
        if (fadeIn > 0)
        {
            var startTime = Time.time;
            sound.fade = this.startCoroutine(this.FadeVolumeCoroutine(sound.audioSource, fadeInDuration, 0, this.FilterSoundproof(sound)), this);
            yield sound.fade;
            sound.fade = null;
        }
        else
        {
            this.ChangeAudioVolume(sound.audioSource, this.FilterSoundproof(sound));
        }

        if (sound.type == SoundPlayType.Loop)
        {
            while (true)
            {
                let timePassed: number = Time.time - timeBegin;
                // Loop 타입이라도 정해진 duration이 있다면 딱 그 만큼만 플레이 하고 탈출
                if (sound.duration > 0 && timePassed > sound.duration)
                {
                    break;
                }

                yield;
            }
        }
        else
        {
            while (sound.repeat > 0)
            {
                let timePassed: number = Time.time - timeBegin;

                if ((sound.duration > 0 && timePassed > sound.duration) || (sound.audioSource != null && timePassed > sound.audioSource.clip.duration))
                {
                    timeBegin = Time.time;
                    sound.repeat -= 1;
                    if (sound.audioSource != null && sound.repeat > 0)
                    {
                        sound.audioSource.setCurrentTime(0);
                    }

                    yield;
                }

                yield;
            }
        }

        this.Stop(sound);
    }

    public TurnDownWholeVolume(depth: number, duration: number, turnDownVolume: number = 0.0, depthType: SoundProofDepthType = SoundProofDepthType.Bgm | SoundProofDepthType.Sfx): void
    {
        this.soundproofDepthInfos.push(new SoundProofDepthInfo(depth, depthType));
        //.OrderByDescending(i => i);
        this.soundproofDepthInfos.sort((a, b) => a.value - b.value);

        this.FadeWholeVolume(duration, 0.0, turnDownVolume, depthType);
    }

    public RestoreWholeVolume(depth: number, duration: number, delay: number, depthType: SoundProofDepthType = SoundProofDepthType.Bgm | SoundProofDepthType.Sfx): void
    {
        let index = this.soundproofDepthInfos.findIndex(x=>x.type == depthType && x.value == depth);
        
        if (index > -1) 
        {
            this.soundproofDepthInfos.splice(index, 1);
        }
        
        this.FadeWholeVolume(duration, delay, 0, depthType);
    }

    private FadeWholeVolume(duration: number, delay: number = 0, unfilteredVolume: number = 0.0, depthType: SoundProofDepthType = SoundProofDepthType.Bgm | SoundProofDepthType.Sfx): void
    {
        this.soundsInFade = [];

        for (let i = 0; i < this.soundsInPlay.length; i++)
        {
            let sound : SoundInfo = this.soundsInPlay[i];
            let volumeEnd: number = this.FilterSoundproof(this.soundsInPlay[i], unfilteredVolume);

            // 볼륨이 같으면 스킵
            if (sound.audioSource == null
                || sound.audioSource.volume == volumeEnd
                || (sound.depthType & depthType) == 0)
                {
                    //cc.log("cocnonasodnfaosndf");
                    continue;
                } 

            if (sound.fade != null)
            {
                this.stopCoroutine(sound.fade);
                sound.fade = null;
            }

            this.soundsInFade.push(sound);

            sound.volumeBegin = sound.audioSource.volume;
            sound.volumeEnd = volumeEnd;
            sound.volumeDiff = sound.volumeEnd - sound.volumeBegin;
        }

        if (this.soundsInFade.length > 0)
        {
            if (this.wholeFade != null)
            {
                this.stopCoroutine(this.wholeFade);
            }
            this.wholeFade = this.startCoroutine(this.FadeWholeVolumeCoroutine(duration, delay), this);
        }
    }

    public ChangeVolume(key: string, volume: number): void
    {
        let soundIndex: number = this.soundsInPlay.findIndex((sound: SoundInfo) => sound.key == key);
        
        if (soundIndex > -1)
        {
            let sound: SoundInfo = this.soundsInPlay[soundIndex];
            sound.volume = volume;

            this.ChangeAudioVolume(sound.audioSource, this.FilterSoundproof(sound));
        }
    }

    *FadeVolumeCoroutine(audioSource: cc.AudioSource, duration: number, valueBegin: number, valueEnd: number)
    {
        let timeBegin: number = Time.time;
        let diff: number = valueEnd - valueBegin;
        this.ChangeAudioVolume(audioSource, valueBegin);
        while (true)
        {
            var timePassed: number = Time.time - timeBegin;
            if (timePassed >= duration)
            {
                this.ChangeAudioVolume(audioSource, valueEnd);
                break;
            }

            var progress: number = timePassed / duration;
            this.ChangeAudioVolume(audioSource, valueBegin + (diff * progress));
            yield;
        }
    }

    private ChangeAudioVolume(audioSource: cc.AudioSource, value: number): void
    {
        if (audioSource != null)
        {
            audioSource.volume = value;
        }
    }

    private ChangeAudioPitch(audioSource: cc.AudioSource, value: number): void
    {
        if (audioSource != null)
        {
            //audioSource.pitch = value;
        }
    }

    *ChangePitchCoroutine(audioSource: cc.AudioSource, valueEnd: number, duration: number)
    {
        if (duration <= 0)
        {
            this.ChangeAudioPitch(audioSource, valueEnd);
            return;
        }

        let timeBegin: number = Time.time;
        
        //let valueBegin: number = audioSource.pitch;
        let valueBegin: number = audioSource.volume;
        //////////////////////////////////////////////

        let valueDiff: number = valueEnd - valueBegin;
        while (true)
        {
            let timePassed: number = Time.time - timeBegin;
            if (timePassed >= duration)
            {
                this.ChangeAudioPitch(audioSource, valueEnd);
                break;
            }

            let progress: number = timePassed / duration;
            this.ChangeAudioPitch(audioSource, valueBegin + (valueDiff * progress));
            yield;
        }
    }

    public ChangePitch(key: string, pitch: number, duration: number): void
    {
        let soundIndex: number = this.soundsInPlay.findIndex((sound: SoundInfo) => sound.key == key);
        if (soundIndex > -1)
        {
            let sound: SoundInfo = this.soundsInPlay[soundIndex];
            if (sound.audioSource != null)
            {
                this.startCoroutine(this.ChangePitchCoroutine(sound.audioSource, pitch, duration), this);
            }
        }
    }

    *FadeWholeVolumeCoroutine(duration: number, delay: number)
    {
        yield new WaitForSeconds(delay);

        let timeBegin: number = Time.time;
        while (true)
        {
            let timePassed: number = Time.time - timeBegin;
            if (timePassed >= duration)
            {
                break;
            }

            let progress: number = timePassed / duration;

            for (let i = 0; i < this.soundsInFade.length; i++)
            {
                this.ChangeAudioVolume(this.soundsInFade[i].audioSource,
                    this.soundsInFade[i].volumeBegin + (this.soundsInFade[i].volumeDiff * progress));
            }

            yield;
        }

        for (let i = 0; i < this.soundsInFade.length; i++)
        {
            this.ChangeAudioVolume(this.soundsInFade[i].audioSource, this.soundsInFade[i].volumeEnd);
        }

        this.wholeFade = null;
    }

    private ChangeMasterVolume(isBgm: boolean, value: number): void
    {
        for (let i = 0; i < this.soundsInPlay.length; i++)
        {
            if(this.soundsInPlay[i] == null) continue;

            if (this.soundsInPlay[i].isBgm != isBgm)
                continue;

            this.soundsInPlay[i].masterVolume = value;
            this.ChangeAudioVolume(this.soundsInPlay[i].audioSource, this.FilterSoundproof(this.soundsInPlay[i]));
        }
    }

    private FilterSoundproof(sound: SoundInfo, filteredVolume: number = 0.0): number
    {
        let originVolume : number = sound.volume * sound.masterVolume;
        return sound.depth >= this.GetHighestSoundproofDepth(sound) ? originVolume : Math.min(originVolume, filteredVolume);
    }

    private GetHighestSoundproofDepth(sound: SoundInfo): number
    {
        let result: number = 0;
        
        for (let i = 0; i < this.soundproofDepthInfos.length; i++)
        {
            if ((sound.depthType & this.soundproofDepthInfos[i].type) > 0) // 뎁스 타입이 겹치는 첫번째 값을 리턴
            {
                result = this.soundproofDepthInfos[i].value;
                break;
            }
        }

        return result;
    }
}