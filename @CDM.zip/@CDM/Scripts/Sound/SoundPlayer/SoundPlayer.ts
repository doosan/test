
import InstanceEvent from "../../../../@CDM/Scripts/System/InstanceEvent";
import SoundSystem, { SoundPlayType } from "../SoundSystem";

const { ccclass, property, menu } = cc._decorator;

//[Serializable]
export class AudioItem
{
    public key: string;
    public value: cc.AudioClip;
}

export enum AudioPoolType
{
    Single,
    KeyValue,
    List
}

export enum AudioTriggerType
{
    None, OnEnable, OnDisable, MouseDown
}

@ccclass
@menu("Gaga/SoundPlayer")
export default class SoundPlayer extends cc.Component             //, IPointerDownHandler
{
    public get AudioClip(): cc.AudioClip
    {
        if(null == this.audioItems || 0 == this.audioItems.length)
        {
           // cc.warn("SoundPlayer에 사운드파일 세팅이 빠져 있음 - 찾아서 꼭! 세팅을 해줘야 함. 단! 파일이 없는 예외도 있음");
            return;
        }
        
        if (this.audioItems[0] == null)
        {
            this.initialize();
        }
        return this.audioItems[0].value;
    }

    @property(cc.AudioClip)
    audioClip: cc.AudioClip = null;

    public poolType: AudioPoolType;
    public audioItems: Array<AudioItem> = new Array<AudioItem>();// { new AudioItem() }; // 기본값으로 하나 넣어준다.

    @property({ type: cc.Enum(AudioTriggerType) }) triggerType: AudioTriggerType = AudioTriggerType.None;
    @property stopWhenDisabled: boolean = false;
    @property overlap: boolean = true;
    @property overwrite: boolean = false;
    @property({ type: cc.Enum(SoundPlayType) }) playType: SoundPlayType = SoundPlayType.Once;
    @property repeat: number = 1;
    @property delay: number = 0;
    @property fadeIn: number = 0;
    @property fadeOut: number = 0;
    @property freezing: number = 0;
    @property volume: number = 1;
    @property pitch: number = 1;
    @property isBgm: boolean = false;
    @property depth: number = 0;

    private KEY: string = "";
    public get Key(): string
    {
        return this.KEY;
    }
    public set Key(value: string)
    {
        this.KEY = value;
    }

    private get OnEnabled(): InstanceEvent
    {
        if (this.onEnabled == null)
            this.onEnabled = new InstanceEvent();

        return this.onEnabled;
    }
    private onEnabled: InstanceEvent = null;

    private get OnDisabled(): InstanceEvent
    {
        if (this.onDisabled == null)
            this.onDisabled = new InstanceEvent();
        return this.onDisabled;
    }
    private onDisabled: InstanceEvent = null;

    private get OnMouseDowned(): InstanceEvent
    {
        if (this.onMouseDowned == null)
            this.onMouseDowned = new InstanceEvent();
        return this.onMouseDowned;
    }
    private onMouseDowned: InstanceEvent = null;

    private button: cc.Button = null;

    private init: boolean = false;

    //#region Unity Method
    onLoad()
    {
        this.initialize();
    }

    initialize()
    {
        if (this.init)
        {
            return;
        }

        if (this.audioClip == null)
        {
            //this.audioItems.push(new AudioItem());
            cc.warn("SoundPlayer에 사운드파일 세팅이 빠져 있음 - 찾아서 꼭! 세팅을 해줘야 함. 단! 파일이 없는 예외도 있음 :" + this.name);
        }
        else
        {
            let temp = new AudioItem();
            temp.key = this.audioClip.name;
            temp.value = this.audioClip;
            this.audioItems.push(temp);
        }

        this.Key = this.overwrite ? `sound_${this.node.name}` : `sound_${this.node.name}${this.node.uuid}`;

        this.WaitForEvent();

        this.node.on(cc.Node.EventType.TOUCH_START, () =>
        {
            if (this.button == null)
            {
                this.OnMouseDowned.Invoke();
            }
        }, this);
    }

    onEnable()
    {
        this.OnEnabled.Invoke();
    }

    onDisable()
    {
        if (this.stopWhenDisabled)
        {
            this.Stop();
        }

        this.OnDisabled.Invoke();
    }
    //#endregion

    private pauseTime : number = 0;

    //#region Custom Method
    private WaitForEvent(): void
    {
        switch (this.triggerType)
        {
            case AudioTriggerType.OnEnable:
                this.OnEnabled.AddListener(this.Play.bind(this), this);
                break;
            case AudioTriggerType.OnDisable:
                this.OnDisabled.AddListener(this.Stop.bind(this), this);
                break;
            case AudioTriggerType.MouseDown:
                this.button = this.node.getComponent(cc.Button);

                if (this.button == null)
                {
                    this.OnMouseDowned.AddListener(this.Play.bind(this), this);
                }
                else
                {
                    this.node.on('click', () =>
                    {
                        this.Play();
                    }, this);
                }
                break;
        }
    }

    public PlayWithAudioKey(audioKey: string): void
    {
        let found: AudioItem = this.audioItems.find(x => x.key == audioKey);
        if (found == null)
            return;

        this.Stop();
        this.Play(found.value);
    }

    public PlayWithDuration(duration: number): void
    {
        if (duration > 0)
        {
            this.Play(this.AudioClip, this.delay, duration, null);
        }
        else
        {
            this.Stop();
        }
    }

    public PlayWithDelay(delay: number): void
    {
        this.Play(this.AudioClip, delay, 0.0, null);
    }

    public PlayWithPitch(pitch: number): void
    {
        this.Play(this.AudioClip, this.delay, 0.0, pitch);
    }

    public Play(): void;
    public Play(audioClip: cc.AudioClip): void;
    public Play(audioClip: cc.AudioClip, delay: number, duration: number, overridePitch?: number): void;
    public Play(audioClip: cc.AudioClip, delay: number, duration: number, overridePitch?: number, time?:number): void
    public Play(param1?: cc.AudioClip, param2?: number, param3?: number, param4?: number): void
    {
        //cc.log(this.node.name);
        if (param1 == null || (false == (param1 instanceof cc.AudioClip)))
        {
            //cc.log("1. SoundPlayer:Play() : "+this.AudioClip.name);
            // Sound값이 있을때만 Play한다.
            if(null != this.AudioClip)
            {
                this.Play(this.AudioClip, this.delay, 0.0, null);
            }
        }
        else
        {
            let audioClip: cc.AudioClip = param1;
            if (param2 == null)
            {
              // cc.log("2. SoundPlayer:Play() : "+this.AudioClip.name);

                this.Play(audioClip, this.delay, 0.0, null);
            }
            else
            {
                //cc.log("3. SoundPlayer:Play() : "+this.AudioClip.name);

                let delay = param2;
                let duration = param3;
                let overridePitch = param4;

                if (this.overwrite == true && this.IsInPlay() == true)
                {
                    SoundSystem.Instance.Stop(this.Key, this.fadeOut);
                }

                if (this.overlap == true || this.IsInPlay() == false)
                {
                    SoundSystem.Instance.Play(this.Key,
                        audioClip,
                        this.playType,
                        delay,
                        this.repeat,
                        this.fadeIn,
                        this.fadeOut,
                        duration,
                        this.depth,
                        this.isBgm,
                        this.volume,
                        overridePitch == null ? this.pitch : overridePitch,
                        this.freezing);
                }
            }
        }
    }

    public Stop(): void
    {
        SoundSystem.Instance.Stop(this.Key, this.fadeOut);
    }

    public Pause() : void
    {
        let source = SoundSystem.Instance.GetAudioSource(this.Key);
        if( source != null )
        {
            this.pauseTime = source.getCurrentTime();
        }

        SoundSystem.Instance.Stop(this.Key, this.fadeOut);
    }

    public Resume() : void
    {
        this.Play(this.AudioClip, this.delay, 0.0, null, this.pauseTime);
        this.pauseTime = 0;
    }

    public ChangeVolume(value: number): void
    {
        SoundSystem.Instance.ChangeVolume(this.Key, value);
    }

    public ChangeMasterVolume(value: number): void
    {
        if (this.isBgm == true)
        {
            SoundSystem.Instance.BgmVolume = value;
        }
        else
        {
            SoundSystem.Instance.SfxVolume = value;
        }
    }

    public ChangePitch(value: number, duration: number): void
    {
        SoundSystem.Instance.ChangePitch(this.Key, value, duration);
    }

    public IsInPlay(): boolean
    {
        return SoundSystem.Instance.IsInPlay(this.Key);
    }
    //#endregion
}