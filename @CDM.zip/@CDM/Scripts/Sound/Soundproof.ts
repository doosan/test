import SoundPlayer from "./SoundPlayer/SoundPlayer";
import SoundSystem from "./SoundSystem";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("Gaga/Soundproof")
export default class Soundproof extends cc.Component
{
    //#pragma warning disable 0649
    @property(SoundPlayer) targetSound : SoundPlayer = null;
    @property depth : number = 1;
    @property({ type: cc.Float }) fadeOut : number = 0.1;
    @property({ type: cc.Float }) fadeIn : number = 0.35;
    @property({ type: cc.Float }) delayToRestore : number = 0.4;
    @property({ type: cc.Float, range: [0, 1, 0.01], slide: true, }) volume : number = 0.0;
    //#pragma warning restore 0649

    private needToRestore : boolean = false;

    onEnable()
    {
        if (this.node.parent == null)
        {
            // 부모가 없으면 막 생성된 인스턴스 이므로 작업을 수행하지 않는다. 
            // e.g. Pool에 캐싱된 팝업들
            return;
        }

        this.needToRestore = true;

        SoundSystem.Instance.TurnDownWholeVolume(this.depth, this.fadeOut, this.volume);
        if (this.targetSound != null)
        {
            this.scheduleOnce(()=>
            {
                this.onDisable()
            }, this.targetSound.AudioClip.duration);
            //Invoke("OnDisable", this.targetSound.AudioClip.duration);
        }
    }

    onDisable()
    {
        this.Restore();
    }

    public Restore():void
    {
        if (this.needToRestore == true)
        {
            this.needToRestore = false;
            SoundSystem.Instance.RestoreWholeVolume(this.depth, this.fadeIn, this.delayToRestore);
        }
    }
}