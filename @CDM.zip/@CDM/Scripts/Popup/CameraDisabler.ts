// using System.Collections;
// using System.Collections.Generic;
// using Gaga.Popup;
// using UnityEngine;

import CoroutineComponent, { Coroutine, WaitForSeconds } from "../../../@CDM/Scripts/System/CoroutineComponent";
import PopupBehaviour from "./PopupBehaviour";

// namespace Gaga.Popup
// {


const {ccclass, property, disallowMultiple, requireComponent} = cc._decorator;

export enum OnType
{
    None,
    Awake,
    Start,
    OnEnable
}

export enum OffType
{
    None,
    OnDisable
}

@ccclass
//[RequireComponent(typeof(PopupBehaviour)), DisallowMultipleComponent]
@requireComponent(PopupBehaviour)
@disallowMultiple
export default class CameraDisabler extends CoroutineComponent
{
    private static useCount:number = 0;   

    public targetLayers:cc.Mask;  //LayerMask
    public onType:OnType = OnType.OnEnable;
    public offType:OffType = OffType.OnDisable;
    //#pragma warning disable 0649
    @property([cc.Camera]) private exceptCameras:cc.Camera[] = [];
    @property() private delay:number = 0;   //float
    //#pragma warning restore 0649

    private static targetCameras:Array<cc.Camera> = new Array<cc.Camera>();

    public IsOn:boolean;//{get; private set;}

    coroutine: Coroutine;

    onLoad()
    {
        if (this.onType == OnType.Awake)
        {
            this.On();
        }
    }

    protected start(): void
    {
        if (this.onType == OnType.Start)
        {
            this.On();
        }
    }

    protected onEnable(): void
    {
        if (this.onType == OnType.OnEnable)
        {
            this.On();
        }
    }

    public onDisable(): void
    {
        super.onDisable();

        if (this.offType == OffType.OnDisable)
        {
            this.Off();
        }
    }

    public On():void
    {
        if (this.IsOn)
        {
            return;
        }

        this.IsOn = true;
        CameraDisabler.useCount++;

        if (CameraDisabler.useCount == 1)
        {
            cc.log("CameraDisabler - On!!!");
        }

        this.coroutine = this.startCoroutine(this.OnCoroutine(), this);
    }

    private *OnCoroutine()
    {
        if (this.delay > 0)
        {
            yield new WaitForSeconds(this.delay);
        }

        //복구
        // var allCams = Camera.allCameras;

        // for (let i = 0; i < allCams.Length; i++)
        // {
        //     var cam = allCams[i];

        //     if (this.exceptCameras.includes(cam) || CameraDisabler.targetCameras.includes(cam))
        //     {
        //         continue;
        //     }

        //     // 이 부분에대해서 고민해봐야 한다. - 어떻게 처리하지?
        //     if ((cam.cullingMask & this.targetLayers.value) != 0)
        //     {
        //         cam.enabled = false;
        //         CameraDisabler.targetCameras.push(cam);

        //         cc.log("CameraDisabler disable - " + cam.gameObject.name);
        //     }
        // }

        yield null;
    }

    public Off():void
    {
        if (this.IsOn == false)
        {
            return;
        }

        this.IsOn = false;
        CameraDisabler.useCount--;

        this.stopCoroutine(this.coroutine);

        if (CameraDisabler.useCount <= 0)
        {
            CameraDisabler.useCount = 0;

            cc.log("CameraDisabler - Off!!!");

            for (let i = 0; i < CameraDisabler.targetCameras.length; i++)
            {
                var cam = CameraDisabler.targetCameras[i];

                if (cam != null)
                {
                    cam.enabled = true;
                    cc.log("CameraDisabler enable - " + cam.name);
                }
            }

            CameraDisabler.targetCameras.length = 0;
        }
    }

    public static Clear():void
    {
        CameraDisabler.useCount = 0;

        cc.log("CameraDisabler - Reset!!!");

        for (let i = 0; i < CameraDisabler.targetCameras.length; i++)
        {
            var cam = CameraDisabler.targetCameras[i];
            
            if (cam != null)
            {
                cam.enabled = true;
            }
        }

        CameraDisabler.targetCameras.length = 0;
    }
}
//}