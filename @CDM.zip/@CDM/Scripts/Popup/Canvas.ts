const {ccclass, property} = cc._decorator;

@ccclass
export default class Canvas extends cc.Component {

  
}
