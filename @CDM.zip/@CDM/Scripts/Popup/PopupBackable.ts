import PopupBehaviour from "./PopupBehaviour";

const { ccclass, property } = cc._decorator;

@ccclass
export default class PopupBackable extends PopupBehaviour 
{
    protected allowBackButton : boolean = true;

    //#region implement IBackable    
    onEnable()
    {
        //BackButtonSystem.Instance.Add(this);
    }

    onDisable()
    {
        super.onDisable();
        //BackButtonSystem.Instance.Remove(this);
    }

    public CanBack() : boolean
    {
        return false;
        //return allowBackButton;
    }

    public GoBack() : void
    {
        this.Close();
    }
    //#endregion
}