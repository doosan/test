
import CoroutineComponent from "../../../@CDM/Scripts/System/CoroutineComponent";
import { Coroutine } from "../../../@CDM/Scripts/System/CoroutineComponent";
import InstanceEvent from "../../../@CDM/Scripts/System/InstanceEvent";
import { Time } from "../../../@CDM/Scripts/Time/Time";
import PopupBehaviour from "./PopupBehaviour";

const { ccclass, menu, property, requireComponent } = cc._decorator;

export enum PopupClosingType
{
    Self, External
}

@ccclass
@menu("Popup/PopupAutoCloser")
export default class PopupAutoCloser extends CoroutineComponent
{
    //#pragma warning disable 0649
    //public onTimesUp: Function;
    public onTimesUp: InstanceEvent = new InstanceEvent();
    //[SerializeField, FormerlySerializedAs("autoCloseDuration")] 
    @property duration: number = 10.0;

    @property({ type: cc.Enum(PopupClosingType) })
    type: PopupClosingType = PopupClosingType.Self;
    //#pragma warning restore 0649
    private popup: PopupBehaviour;
    private coroutine: Coroutine = null;

    onLoad()
    {
        this.popup = this.getComponent(PopupBehaviour);
    }

    onEnable()
    {
        if (this.coroutine != null)
        {
            this.stopCoroutine(this.coroutine);
        }
        this.coroutine = this.startCoroutine(this.CloseCoroutine(), this);
    }

    onDisable()
    {
        super.onDisable();
        if (this.coroutine != null)
        {
            this.stopCoroutine(this.coroutine);
        }
    }

    *CloseCoroutine()
    {
        let t: number = 0.0;

        while (t < this.duration)
        {
            t += Time.deltaTime;
            yield;
        }

        yield;

        if (this.type == PopupClosingType.Self)
        {
            this.popup.Close();
            
        }
        else
        {
            if (this.onTimesUp != null)
            {
                this.onTimesUp.Invoke();
            }
        }
    }
}


