import Animator from "../../../@CDM/Scripts/animator/Animator";
import CoroutineComponent from "../../../@CDM/Scripts/System/CoroutineComponent";
import { Coroutine, WaitForSeconds } from "../../../@CDM/Scripts/System/CoroutineComponent";
import StringUtils from "../../../@CDM/Scripts/Util/StringUtils";
import PopupBehaviour from "./PopupBehaviour";
import PopupSystem from "./PopupSystem";

const { ccclass, menu, requireComponent, property } = cc._decorator;
//namespace Gaga.Popup
//{
@ccclass
@menu("Popup/PopupAnimator")
//[DisallowMultipleComponent, RequireComponent(typeof(PopupBehaviour))]
export default class PopupAnimator extends CoroutineComponent 
{
    private readonly STATE_EMPTY: string = "";
    private readonly STATE_OPEN: string = "OpenState";
    private readonly STATE_CLOSE: string = "CloseState";

    private popup: PopupBehaviour;

    //#pragma warning disable 0649
    @property() public playOnEnable: boolean = true;

    @property(Animator) animator: Animator = null;

    @property({ displayName: "Open" }) author1 = "======== Open ========";
    @property({ displayName: "Animation Name" }) openAnimation: string = "Open";
    @property({ displayName: "Trigger (Optional)" }) openTrigger: string = "";

    @property({ displayName: "Close" }) author2 = "======== Close ========";
    @property({ displayName: "Animation Name" }) closeAnimation: string = "Close";
    @property({ displayName: "Trigger" }) closeTrigger: string = "Close";
    //#pragma warning restore 0649

    //[Space]
    @property([cc.Component.EventHandler])
    public onOpen: cc.Component.EventHandler[] = [];  //UnityEvent 

    @property([cc.Component.EventHandler])
    public onClose: cc.Component.EventHandler[] = [];  //UnityEvent 

    // public onOpen: InstanceEvent = new InstanceEvent();
    // public onClose: InstanceEvent = new InstanceEvent();

    private currentState: string = "";
    private closeAnimations: string[] = [];

    coroutine: Coroutine = null;

    onLoad()
    {
        this.popup = this.getComponent(PopupBehaviour);

        if (this.animator != null)
        {
            this.popup.closeDelegate.AddListener(this.OnClose.bind(this), this);
        }

        this.closeAnimations = this.closeAnimation.split(',');
    }

    onEnable()
    {
        this.currentState = this.STATE_EMPTY;

        if (this.playOnEnable)
        {
            this.StartState(this.STATE_OPEN);
        }
    }

    onDisable()
    {
        super.onDisable();
        this.StopState();
    }

    preState: string = "";
    private OnClose(): void
    {
        this.preState = "";
        if (this.currentState == this.STATE_CLOSE)
        {
            return;
        }

        if (this.animator != null)
        {
            this.preState = this.currentState;
            //this.Play(this.STATE_CLOSE);
            this.StartState(this.STATE_CLOSE);
        }
        else
        {
            this.DispatchClose();
        }
    }

    public Play(): void
    {
        if (this.currentState != this.STATE_EMPTY)
        {
            return;
        }

        this.StartState(this.STATE_OPEN);

        // this.Stop();

        // this.currentState = state;

        // if (this.animator != null)
        // {
        //     this.coroutine = this.startCoroutine(this[`${this.currentState}`](), this);
        //     //this[state]();
        // }
        // else
        // {
        //     this.DispatchOpen();
        // }
    }


    private StartState(state: string): void
    {
        if (this.currentState == state)
        {
            return;
        }

        this.StopState();

        this.currentState = state;

        if (this.animator != null)
        {
            //this.startCoroutine(state);
            this.startCoroutine(this[`${state}`](), this);
        }
        else
        {
            this.DispatchOpen();
        }
    }

    private StopState(): void
    {
        this.currentState = this.STATE_EMPTY;
        this.stopAllCoroutines();
        // if(this.coroutine!=null)
        // {
        //     this.stopCoroutine(this.coroutine);
        // }
    }

    *OpenState()
    {
        if (StringUtils.IsNullOrEmpty(this.openAnimation) == true)
        {
            this.DispatchOpen();
            return;
        }

        if (StringUtils.IsNullOrEmpty(this.openTrigger) == false)
        {
            this.animator.SetTrigger(this.openTrigger);
            yield new WaitForSeconds(0.0001);
        }

        while (this.IsAnimationPlay(this.openAnimation) == true && this.currentState == this.STATE_OPEN)
        {
            yield;
        }

        this.DispatchOpen();
    }

    *CloseState()
    {
        if (StringUtils.IsNullOrEmpty(this.closeAnimation) == true || StringUtils.IsNullOrEmpty(this.closeTrigger) == true)
        {
            this.DispatchClose();
            PopupSystem.Instance.Close(this.popup);
            return;
        }
        this.animator.SetTrigger(this.closeTrigger);
        while (this.IsAnimationPlays(this.closeAnimations) == true && this.currentState == this.STATE_CLOSE && this.preState != "")
        {
            yield;
        }
        this.DispatchClose();
        PopupSystem.Instance.Close(this.popup);
    }

    private IsAnimationPlays(animationNames: string[]): boolean
    {
        if (this.animator._ac == null)
        {
            return false;
        }

        if (this.animator._ac.animCompleteState == null)
        {
            return false;
        }

        let targetAnimName: string = "";

        for (let i = 0; i < animationNames.length; i++)
        {
            var animationName = animationNames[i];

            if (this.animator.curStateName == animationName)
            {
                targetAnimName = animationName;
                break;
            }
        }

        if (StringUtils.IsNullOrEmpty(targetAnimName) == false)
        {
            return this.animator._ac.animCompleteState.name != targetAnimName;
        }

        return true;
        //return this.animator.GetNextAnimatorStateInfo(0).fullPathHash != 0;
    }

    private IsAnimationPlay(animationName: string): boolean
    {
        if (this.animator._ac == null)
        {
            return true;
        }

        if (this.animator._ac.animCompleteState == null)
        {
            return true;
        }

        if (this.animator.curStateName == animationName)
        {
            return this.animator._ac.animCompleteState.name != animationName;
        }
        else
        {
            return true;
        }
    }

    private DispatchOpen(): void
    {
        if (this.onOpen != null)
        {
            //this.onOpen.Invoke();
            cc.Component.EventHandler.emitEvents(this.onOpen);
        }

        //SendMessage("OnAnimatorOpen", SendMessageOptions.DontRequireReceiver);
    }

    private DispatchClose(): void
    {
        if (this.onClose != null)
        {
            //this.onClose.Invoke();
            cc.Component.EventHandler.emitEvents(this.onClose);
        }

        //SendMessage("OnAnimatorClose", SendMessageOptions.DontRequireReceiver);
    }
}
