import CoroutineComponent from "../../../@CDM/Scripts/System/CoroutineComponent";
import InstanceEvent from "../../../@CDM/Scripts/System/InstanceEvent";
import PopupSystem from "./PopupSystem";

const { ccclass, disallowMultiple, menu, property } = cc._decorator;

export enum PopupOrientationType
{
    Universal,
    LandscapeOnly,
    PortraitOnly
}

//[DisallowMultipleComponent]
@ccclass
@menu("Popup/PopupBehaviour")
@disallowMultiple
export default class PopupBehaviour extends CoroutineComponent 
{
    public get RectTransform()
    {
        if (this.cachedRectTrasnform == null)
        {
            this.cachedRectTrasnform = this.node;
        }
        return this.cachedRectTrasnform;
    }

    @property({type:cc.Enum(PopupOrientationType)}) orientation: PopupOrientationType = PopupOrientationType.LandscapeOnly;

    private cachedRectTrasnform: cc.Node;

    public closeDelegate: InstanceEvent = new InstanceEvent();

    Close(): void
    {
        PopupSystem.Instance.StartClosing(this);

        if (!this.closeDelegate.IsEventEmpty)
        {
            this.closeDelegate.Invoke();
        }
        else
        {
            PopupSystem.Instance.Close(this);
        }
    }

    StretchToFit(): void
    {
        this.RectTransform.setAnchorPoint(0.5);
        this.RectTransform.setPosition(0, 0);
        this.RectTransform.setContentSize(0, 0);
    }
}