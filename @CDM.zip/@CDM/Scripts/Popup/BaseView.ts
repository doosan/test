import GameObjectPool from "../../../@CDM/Scripts/ObjectPool/GameObjectPool";
import Canvas from "./Canvas";


const { ccclass, property } = cc._decorator;

@ccclass
export class BaseView<T extends cc.Component> extends cc.Component// where T extends cc.Component//  abstract 
{
    protected canvasPool: GameObjectPool<Canvas> = null;
    protected parent: cc.Node = null;
    public Target: T; //= null;//{get; private set;}
    protected canvas: Canvas = null;    
    protected currentLayer : string = null;

    public constructor(...params: any)
    {        
        super();
        this.canvasPool = params[0];
        this.parent = params[1];

        if (params[2] != null)
        {
            this.UpdateView(params[2]);
        }
    }

    // public constructor(canvasPool:GameObjectPool<cc.Canvas>, parent:cc.Node)
    // {
    //     this.canvasPool = canvasPool;
    //     this.parent = parent;
    // }

    public GetTarget(): T
    {
        return this.Target;
    }

    public UpdateView(value: T, layer : string = null): void   //virtual 
    {
        if (this.Target == value || value == null)
        {
            return;
        }

        if (this.Target != null)
        {
            this.Target.destroy();
        }        

        this.Target = value;

        if (this.canvas == null)
        {
            this.canvas = this.CreateCanvas();
        }

        this.canvas.node.name = this.Target.name.replace("(Clone)", "");
        //this.UdpateLayer(layer);
        this.Target.node.setParent(this.canvas.node);//transform, false);
        this.Target.node.setPosition(cc.Vec3.ZERO);
        this.Target.node.setScale(cc.Vec3.ONE);
        this.Target.node.active = (true);
    }

    protected CreateCanvas(): Canvas   //virtual
    {
        let newCanvas: Canvas = this.canvasPool.Get();        
        newCanvas.node.setParent(this.parent);
        return newCanvas;
    }

    public SetAsLastSibling(): void
    {
        if (this.canvas.node != null)
        {
            //cc.log(this.canvas.name);
            this.canvas.node.setSiblingIndex(-1);
        }
    }

    public SetAsFirstSibling(): void
    {
        if (this.canvas.node != null)
        {
            //cc.log(this.canvas.name);
            this.canvas.node.setSiblingIndex(0);
        }
    }

    public SetSortingOrder(order: number): void
    {
        this.canvas.node.zIndex = order;
    }

    public GetSortingOrder(): number
    {
        return this.canvas.node.zIndex;
    }

    public Release(destoryTarget: boolean): void
    {
        if (destoryTarget)
        {
            if(this.Target!=null)
            {
                this.Destroy(this.Target.node);
                this.Target = null;
            }
        }

        if(this.canvas!=null)
        {
            this.canvas.name = "Canvas";
            this.canvasPool.Return(this.canvas);
            this.canvasPool = null;
            this.canvas = null;
            this.parent = null;
        }
    }

    public Destroy(target: cc.Node)
    {
        target.destroy();
    }

    public SetActive(isOn: boolean): void
    {
        this.canvas.node.active = isOn;
    }

    public ZIndex(index: number): void
    {
        this.canvas.node.zIndex = index;
    }

    public IsValid(): boolean
    {
        // cc.error(this.parent);
        // cc.error(this.canvasPool);
        // if(this.node!=null)
        // {
        //     cc.error(this.node.name);
        // }
        
        // cc.error(this.Target);
        // cc.error(this.canvas);

        // cc.error(this.canvasPool != null && this.parent != null && this.canvas != null);
        // cc.error(this.canvasPool != null);
        // cc.error(this.parent != null);
        // cc.error(this.canvas != null);

        return this.canvasPool != null && this.parent != null && this.canvas != null;
        //return this.Target != null && this.canvasPool != null && this.parent != null && this.canvas != null;
    }
}