
import InstanceEvent from "../../../@CDM/Scripts/System/InstanceEvent";
import StringUtils from "../../../@CDM/Scripts/Util/StringUtils";
import PopupBehaviour from "./PopupBehaviour";
import { PopupInfo } from "./PopupSystem";

const { ccclass, property } = cc._decorator;

@ccclass
export default class PopupObject<T extends PopupBehaviour>
{
    //#pragma warning disable 0649
    public popupInfo: PopupInfo;
    public test: T;

    public OnInitialize(onInitializeHandler: Function, type?: any): PopupObject<T> 
    {
        // cc.log(onInitializeHandler);
        let initMethodInfo: Function = onInitializeHandler == null ? null : onInitializeHandler;
        this.popupInfo.initMethodInfo = initMethodInfo;      

        return this;
    }
    
    public OnOpen(onOpen: InstanceEvent | Function, param: any = null): PopupObject<T> 
    {
        if (onOpen instanceof InstanceEvent)
        {
            this.popupInfo.openAction = onOpen;
        }
        else
        {
            if (onOpen != null)
            {
                let ievent: InstanceEvent = new InstanceEvent();
                ievent.AddListener(onOpen.bind(param), param);
                this.popupInfo.openAction = ievent;
            }
        }
        return this;
    }


    public OnStartClosing(onStartClosing: InstanceEvent | Function, param: any = null): PopupObject<T>  //Action
    {
        if (onStartClosing instanceof InstanceEvent)
        {
            this.popupInfo.startClosingAction = onStartClosing;
        }
        else
        {
            if (onStartClosing != null)
            {
                let ievent: InstanceEvent = new InstanceEvent();
                ievent.AddListener(onStartClosing.bind(param), param);
                this.popupInfo.startClosingAction = ievent;
            }
        }
        return this;
    }

    public OnClose(onClose: InstanceEvent | Function, param: any = null): PopupObject<T> 
    {
        if (onClose instanceof InstanceEvent)
        {
            this.popupInfo.closeAction = onClose;
        }
        else
        {
            if (onClose != null)
            {
                let ievent: InstanceEvent = new InstanceEvent();
                ievent.AddListener(onClose.bind(param), param);
                this.popupInfo.closeAction = ievent;
            }
        }
        return this;
    }

    public OnError(onError: InstanceEvent | Function, param: any = null): PopupObject<T> 
    {
        if (onError instanceof InstanceEvent)
        {
            this.popupInfo.errorAction = onError;
        }
        else
        {
            if (onError != null)
            {
                let ievent: InstanceEvent = new InstanceEvent();
                ievent.AddListener(onError.bind(param), param);
                this.popupInfo.errorAction = ievent;
            }
        }

        return this;
    }

    public Async(): PopupObject<T> 
    {
        this.popupInfo.useAsync = true;
        return this;
    }

    public Sequence(): PopupObject<T>;
    public Sequence(index: number): PopupObject<T>;
    public Sequence(index?: number): PopupObject<T>
    {
        if (index == null)
        {
            return this.Sequence(Number.MAX_SAFE_INTEGER);
        }
        else
        {
            this.popupInfo.SequenceIndex = index;
            return this;
        }
    }

    public SetDelay(delay: number): PopupObject<T>
    {
        this.popupInfo.delay = delay;
        return this;
    }

    public SetOrder(order: number): PopupObject<T>
    {
        this.popupInfo.order = order;
        return this;
    }

    public SetBackgroundAlpha(alpha: number, raycast: boolean = true): PopupObject<T>
    {
        this.popupInfo.bgAlpha = alpha;
        this.popupInfo.bgRaycast = raycast;
        return this;
    }

    public Cache(): PopupObject<T>
    {
        this.popupInfo.useCache = true;
        this.popupInfo.cacheID = StringUtils.IsNullOrEmpty(this.popupInfo.resourcePath) == false ? this.popupInfo.resourcePath : this.popupInfo.assetBundleObject;
        return this;
    }

    public SetIgnoreCount(value: boolean): PopupObject<T>
    {
        this.popupInfo.ignoreCount = value;
        return this;
    }

    public SetScreenMatchMode(): PopupObject<T>
    {
        //this.popupInfo.screenMatchMode = screenMatchMode;
        return this;
    }

    public SetLayer(layerName: string): PopupObject<T>
    {
        this.popupInfo.layer = layerName;
        return this;
    }

    *WaitForStartClosing()
    {
        let idDone = false;
        if (this.popupInfo.startClosingAction.IsEventEmpty)
        {
            this.popupInfo.startClosingAction.AddListener((() =>
            {
                idDone = true;
            }).bind(this), this);
        }
        else
        {
            let tempAction: InstanceEvent = this.popupInfo.startClosingAction;
            this.popupInfo.startClosingAction.AddListener((() =>
            {
                tempAction.Invoke();
                idDone = true;
            }).bind(this), this);
        }

        while (idDone == false)
        {
            yield;
        }
    }

    *WaitForClose()
    {
        let idDone: boolean = false;
        if (this.popupInfo.closeAction.IsEventEmpty)
        {
            this.popupInfo.closeAction.AddListener((() =>
            {
                idDone = true;
            }).bind(this), this);
        }
        else
        {
            let tempAction: InstanceEvent = this.popupInfo.closeAction;
            this.popupInfo.closeAction.AddListener((() =>
            {
                tempAction.Invoke();
                idDone = true;
            }).bind(this), this);
        }

        while (idDone == false)
        {
            yield null;
        }
    }

    public GetPopup(): T
    {
        if (this.popupInfo.popup.Target == null)
        {
            return null;
        }
        else
        {
            return this.popupInfo.popup.Target as T;
        }
    }
}