import { eGroup } from "../GroupEnum";
import SingleObjects from "../System/SingleObjects";
import Queue from "../DataStructure/Queue";
import CoroutineComponent from "../System/CoroutineComponent";
import GameObjectPool from "../ObjectPool/GameObjectPool";
import InstanceEvent from "../System/InstanceEvent";
import AssetBundle from "../AssetBundle/AssetBundle";
import { AssetBundleLoadType } from "../AssetBundle/AssetBundleLoadType";
import AssetBundleSystem from "../AssetBundle/AssetBundleSystem";
import BaseLoadingIndicator, { LoadingType } from "../UI/BaseLoadingIndicator";
import { BaseView } from "./BaseView";
import PopupBehaviour from "./PopupBehaviour";
import PopupObject from "./PopupObject";
import Canvas from "./Canvas";
import PopupBackable from "./PopupBackable";
import { WaitForSeconds } from "../System/CoroutineComponent";
import StringUtils from "../Util/StringUtils";
import ScreenSystem from "../System/ScreenSystem";
import ResizeSystem from "../System/ResizeSystem";

const { ccclass, property } = cc._decorator;

export class PopupView extends BaseView<PopupBehaviour>
{
    public constructor(canvasPool: GameObjectPool<Canvas>, parent: cc.Node, target?: PopupBehaviour)
    {
        super(canvasPool, parent, target)
    }

    protected override CreateCanvas(): Canvas
    {
        let canvas = super.CreateCanvas();

        return canvas;
    }
}

export class LoadingIndicatorView extends BaseView<BaseLoadingIndicator>
{
    public constructor(canvasPool: GameObjectPool<Canvas>, parent: cc.Node, target?: BaseLoadingIndicator)// : base(canvasPool, parent){}
    {
        super(canvasPool, parent, target)
    }

}

export class BackgroundView extends BaseView<cc.Sprite>
{
    //public BackgroundView(GameObjectPool<Canvas> canvasPool, Transform parent ) : base(canvasPool, parent){}
    // public constructor(canvasPool:GameObjectPool<cc.Canvas>, parent:cc.Node, target?:cc.Sprite)// : base(canvasPool, parent, target){}
    // {
    //     super(canvasPool, parent, target)
    // }
}

export class PopupInfo
{
    public readonly DEFAULT_BG_ALPHA: number = 0.5;

    public manager: PopupSystem = null;
    public resourcePath: string = '';
    public assetBundleName: string = '';
    public assetBundleURL: string = '';
    public assetBundleObject: string = '';
    public unloadAssetBundleOnClose: boolean = false;

    public get UseAssetBundle(): boolean { return StringUtils.IsNullOrEmpty(this.assetBundleName) == false; }
    public cacheID: string = '';
    public popup: PopupView = null;
    public order: number = 0;
    public bgAlpha: number = this.DEFAULT_BG_ALPHA;
    public bgRaycast: boolean = true;
    public useAsync: boolean = false;
    private UseCache: boolean = false;
    public get useCache(): boolean
    {
        return this.UseCache;
    }
    public set useCache(value: boolean) 
    {
        this.UseCache = value;
    }

    public initMethodTarget: object = null;
    public ignoreCount: boolean = false;
    public initMethodInfo: Function = null;

    public openAction: InstanceEvent = new InstanceEvent();
    public startClosingAction: InstanceEvent = new InstanceEvent();
    public closeAction: InstanceEvent = new InstanceEvent();
    public errorAction: InstanceEvent = new InstanceEvent();
    public layer: string = '';
    public delay: number = 0;
    public get UseSequence(): boolean { return this.sequenceIndex > -1; }
    private sequenceIndex: number = 0;    

    public get SequenceIndex() { return this.sequenceIndex }
    public set SequenceIndex(value: number)
    {
        this.sequenceIndex = value;
        if (this.UseSequence == true)
        {
            if (this.sequenceIndex >= this.manager.GetSequceCount())
            {
                this.manager.AddSequence(this);
            }
            else
            {
                this.manager.AddSequence(this, this.sequenceIndex);
            }
        }
    }

    constructor(manager: PopupSystem, assetBundleURL: string, assetBundleName?: string, objectName?: string, unloadAssetBundleOnClose?: boolean)
    {
        if (assetBundleName == null)
        {
            let resourcePath = assetBundleURL;
            this.manager = manager;
            this.resourcePath = resourcePath;
            this.sequenceIndex = -1;
        }
        else
        {
            this.manager = manager;
            this.assetBundleURL = assetBundleURL;
            this.assetBundleName = assetBundleName;
            this.assetBundleObject = objectName;
            this.unloadAssetBundleOnClose = unloadAssetBundleOnClose;
            this.sequenceIndex = -1;
        }

        this.popup = new PopupView(manager.canvasPool, manager.root, null);
    }
}

// 팝업 시스템 (singleton)
@ccclass
export default class PopupSystem extends CoroutineComponent
{
    static readonly DEFAULT_BG_ALPHA: number = 0.5;
    public readonly MAX_POPUP_COUNT: number = 30000;
    private readonly LOADING_INDICATOR_ORDER: number = this.MAX_POPUP_COUNT + 100;

    static instance: PopupSystem;

    static get Instance(): PopupSystem
    {
        if (PopupSystem.instance != null)
        {
            return PopupSystem.instance;
        }

        let newNode = new cc.Node("PopupSystem");

        PopupSystem.instance = newNode.addComponent(PopupSystem);
        let widget = newNode.addComponent(cc.Widget);
        widget.alignMode = cc.Widget.AlignMode.ON_WINDOW_RESIZE;
        widget.isAlignTop = true;
        widget.isAlignBottom = true;
        widget.isAlignLeft = true;
        widget.isAlignRight = true;
        widget.top = 0;
        widget.bottom = 0;
        widget.left = 0;
        widget.right = 0;

        cc.game.addPersistRootNode(newNode);
        newNode.setParent(SingleObjects.Instance.node);
        return PopupSystem.instance;
    }

    public onCountChanged: InstanceEvent = new InstanceEvent();

    public onPopupOpen: InstanceEvent = new InstanceEvent();
    public onPopupStartClosing: InstanceEvent = new InstanceEvent();
    public onPopupClose: InstanceEvent = new InstanceEvent();

    public onSequeneceAllComplete: InstanceEvent = new InstanceEvent();
    private cachedRoot: cc.Node = null; //RectTransform
    private canvasPoolRoot: cc.Node = null; //RectTransform
    private popupCount: number = 0;
    public popupLoadBuffer: Queue<PopupInfo> = null;
    public popupInfoList: Array<PopupInfo> = null;
    private sequencePopupInfoList: Array<PopupInfo> = null;
    private currentSequencePopupInfo: PopupInfo = null;
    private cachedPopupInfoDic: Map<string, PopupBehaviour> = null;
    private backgroundView: BackgroundView = null;
    private backgroundImage: cc.Sprite = null;
    private isBackgroundPanelOn: boolean = false;

    public canvasPool: GameObjectPool<Canvas> = null;

    public backgroundShowDuration: number = 0.2;
    public backgroundHideDuration: number = 0.2;
    public clearResourceOnClose: boolean = false;

    private loadingIndicator: LoadingIndicatorView = null;

    private isInit: boolean = false;
    public root: cc.Node = null; //RectTransform
    public Camera: cc.Camera = null;
    private canvas: cc.Canvas = null;
    public DefaultLayer: string = "";
    private widget : cc.Widget = null;

    async Initialize(popupLayerName: string, resolutionWidth: number, resolutionHeight: number, pixelsPerUnit: number = 100, depth: number = 0)
    {
        if (this.isInit == true)
        {
            return;
        }

        this.isInit = true;
        this.canvas = cc.director.getScene().getComponentInChildren(cc.Canvas);

        this.DefaultLayer = popupLayerName;

        this.popupInfoList = new Array<PopupInfo>();
        this.cachedPopupInfoDic = new Map<string, PopupBehaviour>();
        this.sequencePopupInfoList = new Array<PopupInfo>();
        this.popupLoadBuffer = new Queue<PopupInfo>();

        this.SetupCanvasPoolRoot();

        //        super.OnInitialize(popupLayerName, resolutionWidth, resolutionHeight, match, pixelsPerUnit, depth);

        this.SetupRoot();
        this.SetupRenderes(popupLayerName, resolutionWidth, resolutionHeight, pixelsPerUnit, depth);

        await this.SetupBackgroundPanel();
        this.SetupCachedRoot();
        this.SetupLoadingIndicator();
    }

    private SetupRoot(): void
    {
        //this.root = new GameObject("Root").AddComponent<RectTransform>();
        this.root = new cc.Node("Root");
        this.widget = this.root.addComponent(cc.Widget);
        this.widget.alignMode = cc.Widget.AlignMode.ON_WINDOW_RESIZE;
        this.widget.isAlignTop = true;
        this.widget.isAlignBottom = true;
        this.widget.isAlignLeft = true;
        this.widget.isAlignRight = true;
        this.widget.top = 0;
        this.widget.bottom = 0;
        this.widget.left = 0;
        this.widget.right = 0;
        
        ScreenSystem.Instance.AddNode(this.root);
        this.root.setParent(this.node); //false
    }

    private SetupRenderes(popupLayerName: string, resolutionWidth: number, resolutionHeight: number, pixelsPerUnit: number, depth: number)                                            
    {
        this.Camera = new cc.Node("Camera").addComponent(cc.Camera);
        this.Camera.ortho = true;

        this.Camera.cullingMask = (1 << eGroup[popupLayerName]) | (1 << eGroup.Loadingindicator) | (1 << eGroup.Tutorial);
        this.Camera.node.setParent(this.node);
        // this.Camera.clearFlags = CameraClearFlags.Depth;
        this.Camera.depth = depth;
        this.Camera.alignWithScreen = true;

        this.root.setScale(1);//.localScale = Vector3.one;

        this.canvasPool = new GameObjectPool<Canvas>(this.canvasPoolRoot
            , 1
            , () =>
            {
                let go = new cc.Node("Canvas");
                return this.CreateCanvas(go
                    , popupLayerName
                    , resolutionWidth
                    , resolutionHeight                    
                    , pixelsPerUnit);
            });
    }

    protected CreateCanvas(target: cc.Node,
        popupLayerName: string,
        resolutionWidth: number,
        resolutionHeight: number,        
        pixelsPerUnit: number)
    {
        let canvas = target.addComponent(Canvas);

        let widget = target.addComponent(cc.Widget);
        widget.alignMode = cc.Widget.AlignMode.ON_WINDOW_RESIZE;
        widget.isAlignTop = true;
        widget.isAlignBottom = true;
        widget.isAlignLeft = true;
        widget.isAlignRight = true;
        widget.top = 0;
        widget.bottom = 0;
        widget.left = 0;
        widget.right = 0;

        return canvas;
    }

    async SetupBackgroundPanel(): Promise<void>
    {
        return new Promise((resolve, reject) =>
        {
            let newPanel = new cc.Node("BackgroundPanel");

            this.backgroundImage = newPanel.addComponent(cc.Sprite);
            this.backgroundImage.node.color = new cc.Color(0, 0, 0);
            this.backgroundImage.node.opacity = 0;
            this.backgroundImage.node.active = false;
            this.backgroundImage.node.group = this.DefaultLayer;

            let button: cc.Button = this.backgroundImage.addComponent(cc.Button);

            // 직접 리소스를 로드한다.
            cc.resources.load<cc.SpriteFrame>("Back", cc.SpriteFrame, function (err, result)
            {
                if (err == null)
                {
                    PopupSystem.instance.backgroundImage.spriteFrame = result;

                    PopupSystem.instance.backgroundView = new BackgroundView(PopupSystem.instance.canvasPool, PopupSystem.instance.root, PopupSystem.instance.backgroundImage);
                    PopupSystem.instance.backgroundView.SetActive(false);
                    PopupSystem.instance.backgroundView.ZIndex(-100);
                    resolve();
                }
                else
                {

                }
            });

            let widget = newPanel.addComponent(cc.Widget);
            widget.alignMode = cc.Widget.AlignMode.ON_WINDOW_RESIZE;
            widget.isAlignTop = true;
            widget.isAlignBottom = true;
            widget.isAlignLeft = true;
            widget.isAlignRight = true;
            widget.top = 0;
            widget.bottom = 0;
            widget.left = 0;
            widget.right = 0;
        });
    }

    private SetupCachedRoot(): void
    {
        this.cachedRoot = new cc.Node("CachedRoot");
        this.cachedRoot.setParent(this.node);//, false
        this.cachedRoot.setSiblingIndex(0);
        this.cachedRoot.active = false;
    }

    private SetupCanvasPoolRoot(): void
    {
        this.canvasPoolRoot = new cc.Node("CanvasPool");//.addComponent();
        this.canvasPoolRoot.parent = this.node;
        this.canvasPoolRoot.setSiblingIndex(0);//SetAsFirstSibling();
        this.canvasPoolRoot.active = (false);
    }

    private SetupLoadingIndicator(): void
    {
        this.loadingIndicator = new LoadingIndicatorView(this.canvasPool, this.root);
    }

    onEnable()
    {
        this.StartLoadPopups();
    }

    public StartLoadPopups()
    {
        this.StopLoadPopups();
        this.startCoroutine(this.LoadPopups());
    }

    private StopLoadPopups()
    {
        this.stopAllCoroutines();
    }

    private CreatePopupObject<T extends PopupBehaviour>(info: PopupInfo): PopupObject<T>
    {
        let popupObject = new PopupObject<T>();
        popupObject.popupInfo = info;

        return popupObject;
    }

    Open<T extends PopupBehaviour>(resourcePath: string): PopupObject<T>;
    Open<T extends PopupBehaviour>(assetBundleName: string, objectName: string): PopupObject<T>;
    Open<T extends PopupBehaviour>(assetBundleURL: string, assetBundleName: string, objectName: string): PopupObject<T>;
    Open<T extends PopupBehaviour>(popupObject: T): PopupObject<T>;
    Open<T extends PopupBehaviour>(info: PopupInfo): PopupObject<T>;
    Open<T extends PopupBehaviour>(param1: any, param2?: string, param3?: string): PopupObject<T>
    {
        if (param1 instanceof String)
        {
            return;
        }
        if (param1 instanceof PopupInfo)
        {
            if (this.popupInfoList.length >= this.MAX_POPUP_COUNT)
            {
                cc.log("PopupSymstem - Popup is full.");
                return null;
            }

            let info = param1;
            let popupObject: PopupObject<T> = this.CreatePopupObject<T>(info);
            this.popupLoadBuffer.enqueue(info);
            return popupObject;
        }
        else 
        {
            if (param1 != null && param2 == null && param3 == null)
            {
                let resourcePath: string = param1.toString();
                let popupInfo: PopupInfo = new PopupInfo(this, resourcePath);
                return this.Open<T>(popupInfo);
            }
            else if (param1 != null && param2 != null && param3 == null)
            {
                let assetBundleName: string = param1.toString();
                let objectName: string = param2.toString();
                let popupInfo: PopupInfo = new PopupInfo(this, "", assetBundleName, objectName);
                return this.Open<T>(popupInfo);
            }
            else if (param1 != null && param2 != null && param3 != null)
            {
                let assetBundleURL: string = param1.toString();
                let assetBundleName: string = param2.toString();
                let objectName: string = param3.toString();
                let popupInfo: PopupInfo = new PopupInfo(this, assetBundleURL, assetBundleName, objectName);
                return this.Open<T>(popupInfo);
            }
            else
            {
                let popupObject = param1;
                let popupInfo: PopupInfo = new PopupInfo(this, "", "", "");
                popupInfo.popup.UpdateView(popupObject);
                return this.Open<T>(popupInfo);
            }
        }
    }

    public StartClosing(popup: PopupBehaviour): void
    {
        let info: PopupInfo = this.GetPopupInfo(popup);

        if (info != null)
        {
            cc.log("PopupSystem - Start Closing : " + info.assetBundleObject);
            this.DispatchPopupStartClosing(info);
        }
    }

    Close(popup: PopupBehaviour, ignoreCloseAction: boolean = false, updateBackgroundPanel: boolean = true): void
    {
        let info: PopupInfo = this.GetPopupInfo(popup);

        if (info != null)
        {
            if (info == this.currentSequencePopupInfo)
            {
                this.SequencePopupClosed();
            }

            if (ignoreCloseAction == false)
            {
                this.DispatchPopupClose(info);
            }

            if (info.useCache)
            {
                if (this.ReturnCachedPopup(info.cacheID) == false)
                {
                    info.popup.Release(true);
                }
            }
            else
            {
                info.popup.Release(true);
            }

            let index = this.popupInfoList.findIndex(x => x == info);
            if (index > -1)
            {
                this.popupInfoList.splice(index, 1);
            }

            this.UpdateCount();
        }
        else
        {
            popup.node.destroy();
        }

        if (this.clearResourceOnClose)
        {
            this.UnloadUnusedAssets();
        }

        if (updateBackgroundPanel)
        {
            this.UpdateBackgroundPanel();
        }

    }

    //internal 
    UnregisterAll(ignoreCloseAction: boolean = true): void 
    {
        while (this.popupInfoList.length > 0)
        {
            let info = this.popupInfoList[0];

            if (ignoreCloseAction == false)
            {
                this.DispatchPopupStartClosing(info);
            }

            this.Close(info.popup.Target, ignoreCloseAction, false);
        }

        this.UpdateCount();
        this.UpdateBackgroundPanel();
    }

    private SequencePopupClosed(): void
    {
        this.currentSequencePopupInfo = null;

        if (this.GetSequceCount() == 0)
        {
            if (this.onSequeneceAllComplete != null)
            {
                this.onSequeneceAllComplete.Invoke();
            }
        }
    }

    public Clear(clearSequence: boolean = true, ignoreCloseAction: boolean = true): void
    {
        if (this.popupInfoList == null)
        {
            return;
        }

        this.HideLoading();

        if (clearSequence)
        {
            this.ClearSequence();
        }

        this.popupLoadBuffer.clear();
        this.UnregisterAll(ignoreCloseAction);

        if (this.clearResourceOnClose)
        {
            this.UnloadUnusedAssets();
        }

        this.UpdateBackgroundPanel();
        this.StopLoadPopups();
        this.StartLoadPopups();
    }

    *LoadPopups()
    {
        while (true)
        {
            if (this.popupLoadBuffer != null && this.popupLoadBuffer.size() > 0)
            {
                let currentInfo: PopupInfo = this.popupLoadBuffer.dequeue();

                if (currentInfo.UseSequence)
                {
                    if (this.IsNextSequence(this.currentSequencePopupInfo, currentInfo) == true)
                    {
                        this.currentSequencePopupInfo = currentInfo;
                        this.RemoveSequence(this.currentSequencePopupInfo);
                    }
                    else
                    {
                        this.popupLoadBuffer.enqueue(currentInfo);
                        yield;
                        continue;
                    }
                }

                let popupIndex: number = this.CalcPopupOrderToIndex(currentInfo.order, this.popupInfoList);
                if (popupIndex >= this.popupInfoList.length)
                {
                    this.popupInfoList.push(currentInfo);
                }
                else
                {
                    this.popupInfoList.splice(popupIndex, 0, currentInfo);
                }

                this.UpdateCount();

                if (currentInfo.delay > 0.0)
                {
                    this.UpdateBackgroundPanel(true);
                    yield new WaitForSeconds(currentInfo.delay);
                }
                else
                {
                    this.UpdateBackgroundPanel();
                }

                let popup: PopupBehaviour = null;

                if (this.ContainsCachedPopup(currentInfo.cacheID))
                {
                    if (this.IsCachedPopupOpen(currentInfo.cacheID))
                    {
                        let cachedPopup = this.GetCachedPopup(currentInfo.cacheID);
                        if (cachedPopup != null)
                        {
                            this.Close(cachedPopup);
                        }
                    }

                    popup = this.GetCachedPopup(currentInfo.cacheID);
                }
                else
                {
                    if (currentInfo.popup.Target == null)
                    {
                        this.ShowLoading();

                        if (currentInfo.UseAssetBundle == true)
                        {
                            yield this.LoadPopupFromAssetBundle(currentInfo, popupParam =>
                            {
                                popup = popupParam;
                            });
                        }
                        else
                        {
                            yield this.LoadPopupFromResources(currentInfo, popupParam =>
                            {
                                popup = popupParam;
                            });
                        }

                        this.HideLoading();

                        if (currentInfo.useCache && popup != null)
                        {
                            this.AddCachedPopup(currentInfo.cacheID, popup);
                        }
                    }
                    else
                    {
                        popup = currentInfo.popup.Target;
                    }
                }

                if (popup != null)
                {
                    currentInfo.popup.UpdateView(popup);
                    this.DispatchPopupInitialize(currentInfo);
                    yield;

                    this.SortPopupOrder();
                    this.UpdateBackgroundPanel();

                    if (currentInfo.popup.Target != null)
                    {
                        while (!currentInfo.popup.Target.node.activeInHierarchy)
                        {
                            yield;
                        }
                    }

                    this.DispatchPopupOpen(currentInfo);
                }
                else
                {
                    //this.popupInfoList.Remove(currentInfo);
                    const index = this.popupInfoList.indexOf(currentInfo, 0);
                    if (index > -1) 
                    {
                        this.popupInfoList.splice(index, 1);
                    }

                    this.UpdateCount();
                    this.UpdateBackgroundPanel();

                    if (currentInfo.errorAction != null)
                    {
                        currentInfo.errorAction.Invoke();
                    }

                    if (currentInfo.startClosingAction != null)
                    {
                        currentInfo.startClosingAction.Invoke();
                    }

                    if (currentInfo.closeAction != null)
                    {
                        currentInfo.closeAction.Invoke();
                    }
                }
            }
            else
            {
                yield;
            }
        }
    }

    *LoadPopupFromResources(info: PopupInfo, loadComplete: Function)
    {
        let popup: PopupBehaviour = null;

        //if (info.useAsync == true)
        {
            let isDone: boolean = false;
            let reqest: cc.Prefab = null;

            cc.resources.load<cc.Prefab>(info.resourcePath, cc.Prefab, function (err, result)
            {
                if (err == null)
                {
                    isDone = true;
                    reqest = result;
                }
                else
                {

                }
            })

            while (isDone == false)
            {
                yield;
            }
            popup = cc.instantiate(reqest).getComponent(PopupBehaviour);
            loadComplete(popup);
        }
    }

    *LoadPopupFromAssetBundle(info: PopupInfo, loadComplete: Function)
    {
        let popup: PopupBehaviour = null;
        let error: boolean = false;
        let popupGo: cc.Node = null;

        let assetBundle: AssetBundle = AssetBundleSystem.Instance.GetLoadedAssetBundle(info.assetBundleName);

        if (assetBundle == null)
        {
            // 실제서버에서 Load한다.

            let isDone: boolean = false;
            //if (StringUtils.IsNullOrEmpty(info.assetBundleURL) == false)
            {
                // preload한것도 로드하지만, 다운로드 안된 데이터도 서버에서 다운로드한다.
                AssetBundleSystem.Instance.Load(
                    AssetBundleLoadType.Load
                    , info.assetBundleURL
                    , info.assetBundleName
                    , false
                    , (success, ab) =>
                    {
                        assetBundle = ab;

                        if (success == true)
                        {
                            //if (info.useAsync == true)
                            {
                                assetBundle.GetGameObject(info.assetBundleObject, true, go =>
                                {
                                    popupGo = go;
                                    isDone = true;
                                });
                            }
                        }
                        else
                        {
                            error = true;
                            isDone = true;
                        }
                    }
                );
            }

            while (isDone == false)
            {
                yield null;
            }
        }
        else
        {
            // 로컬에서 로드한다.
            let isDone: boolean = false;

            assetBundle.GetGameObject(info.assetBundleObject, true, go =>
            {
                popupGo = go;
                isDone = true;
            });

            while (isDone == false)
            {
                yield null;
            }


            if (popupGo == null)
            {
                error = true;
            }
        }

        if (error == false)
        {
            // 아직 활성화되지 않은 팝업의 OnEnable이 먼저 호출되는 문제를 막기 위함.
            let originActive: boolean = popupGo.active;
            popupGo.active = false;
            popup = cc.instantiate(popupGo).getComponent(PopupBehaviour);
            popupGo.active = originActive;
        }

        loadComplete(popup);
    }

    private DispatchPopupOpen(info: PopupInfo): void
    {
        if (info.openAction != null)
        {
            info.openAction.Invoke();
        }

        if (this.onPopupOpen != null)
        {
            this.onPopupOpen.Invoke(info.popup.Target);
        }
    }

    private DispatchPopupStartClosing(info: PopupInfo): void
    {
        if (info.startClosingAction != null)
        {
            info.startClosingAction.Invoke();
        }

        if (this.onPopupStartClosing != null)
        {
            this.onPopupStartClosing.Invoke(info.popup.Target);
        }
    }

    private DispatchPopupClose(info: PopupInfo): void
    {
        if (info.closeAction != null)
        {
            info.closeAction.Invoke();
        }

        if (this.onPopupClose != null)
        {
            this.onPopupClose.Invoke(info.popup.Target);
        }
    }

    private DispatchPopupInitialize(info: PopupInfo): void
    {
        if (info.initMethodInfo != null)
        {
            info.initMethodInfo(info.popup.Target);
        }
    }

    private SortPopupOrder(): void
    {
        for (let i = 0; i < this.popupInfoList.length; i++)
        {
            let info: PopupInfo = this.popupInfoList[i];
            if (info.popup.IsValid())
            {
                info.popup.SetSortingOrder(i);
            }
        }
    }

    private UpdateBackgroundPanel(forceClearBackgroundAlpha: boolean = false): void
    {
        if (null == this.popupInfoList)
        {
            return;
        }

        if (this.popupInfoList.length == 0)
        {
            if (this.sequencePopupInfoList.length == 0)
            {
                this.HideBackgroundPanel();
            }

            return;
        }

        let targetAlpha: number = 0.0;
        let targetRaycast: boolean = true;

        if (forceClearBackgroundAlpha == false && this.popupInfoList.length > 0)
        {
            let targetInfo = this.popupInfoList[this.popupInfoList.length - 1];
            targetAlpha = targetInfo.bgAlpha;
            targetRaycast = targetInfo.bgRaycast;
        }

        if (this.popupInfoList.length == 1 && this.isBackgroundPanelOn)
        {
            this.ShowBackgroundPanel(targetAlpha, targetRaycast);
            this.backgroundView.SetSortingOrder(-1);
            this.backgroundView.SetAsFirstSibling();
            this.LoadingAsLastSibling();
            return;
        }
        else
        {
            this.ShowBackgroundPanel(targetAlpha, targetRaycast);
        }

        let lastInfo: PopupInfo = this.popupInfoList[this.popupInfoList.length - 1];

        this.backgroundView.SetAsLastSibling();

        if (lastInfo.popup.IsValid())
        {
            let targetPopupOrder = lastInfo.popup.GetSortingOrder();

            this.backgroundView.SetSortingOrder(targetPopupOrder);
            lastInfo.popup.SetSortingOrder(targetPopupOrder + 1);
            lastInfo.popup.SetAsLastSibling();
        }

        this.LoadingAsLastSibling();
    }

    private backgroundViewTween: cc.Tween = null;

    private ShowBackgroundPanel(alpha: number, raycasat: boolean = true): void
    {
        if (this.backgroundView.Target == null) 
        {
            return;
        }

        this.isBackgroundPanelOn = true;
        this.backgroundView.SetActive(true);

        this.backgroundImage.getComponent(cc.Button).enabled = raycasat;

        alpha = alpha * 255;
        if (alpha == this.backgroundView.Target.node.opacity)
        {
            return;
        }

        if (this.backgroundViewTween != null)
        {
            this.backgroundViewTween.stop();
            this.backgroundViewTween.removeSelf();
            this.backgroundViewTween = null;
        }

        if (this.backgroundShowDuration > 0.0)
        {
            this.backgroundViewTween = cc.tween(this.backgroundView.Target.node).to(this.backgroundShowDuration, { opacity: alpha }).start();
        }
        else
        {
            let tempOpacity = this.backgroundView.Target.node.opacity;
            tempOpacity = alpha;
            this.backgroundView.Target.node.opacity = tempOpacity;
        }
    }

    public HideBackgroundPanel(): void
    {
        if (this.backgroundView == null) 
        {
            return;
        }

        this.isBackgroundPanelOn = false;

        if (this.backgroundViewTween != null)
        {
            this.backgroundViewTween.stop();
            this.backgroundViewTween.removeSelf();
            this.backgroundViewTween = null;
        }

        if (this.backgroundHideDuration > 0.0)
        {
            this.backgroundViewTween = cc.tween(this.backgroundView.Target.node).to(this.backgroundHideDuration, { opacity: 0 }).call(() =>
            {
                if (this.backgroundView.IsValid())
                {
                    this.backgroundView.SetActive(false);
                }

            }).start();
        }
        else
        {
            let tempOpacity = this.backgroundView.Target.node.opacity;
            tempOpacity = 0;
            this.backgroundView.Target.node.opacity = tempOpacity;

            if (this.backgroundView.IsValid())
            {
                this.backgroundView.SetActive(false);
            }
        }
    }

    public get Count(): number { return this.popupCount; }
    public set Count(value: number)
    {
        if (this.popupCount == value)
        {
            return;
        }
        this.popupCount = value;
    }

    private UpdateCount(): void
    {
        let count = 0;
        this.popupInfoList.forEach((info) =>
        {
            if (info.ignoreCount == false)
            {
                count++;
            }
        }, this);

        this.Count = count;

        if (this.onCountChanged != null)
        {
            this.onCountChanged.Invoke(this.Count);
        }
    }

    private CalcPopupOrderToIndex(order: number, infoList: Array<PopupInfo>): number
    {
        let orderIndex: number = infoList.length;

        for (let i = 0; i < infoList.length; i++)
        {
            let info: PopupInfo = infoList[i];

            if (order < info.order)
            {
                orderIndex = i;
                break;
            }
        }

        return orderIndex;
    }

    private GetPopupInfo(popup: PopupBehaviour): PopupInfo
    {
        if (null == this.popupInfoList)
        {
            return null;
        }

        for (let i = 0; i < this.popupInfoList.length; i++)
        {
            let info: PopupInfo = this.popupInfoList[i];

            if (info.popup.Target == popup)
            {
                return info;
            }
        }

        return null;
    }

    public AddSequence(info: PopupInfo, index?: number): void
    {
        if (index != null)
        {
            this.sequencePopupInfoList.splice(index, 0, info);
        }
        else
        {
            this.sequencePopupInfoList.push(info);
        }
    }

    private RemoveSequence(info: PopupInfo): void
    {
        //   this.sequencePopupInfoList.Remove(info);
        const index = this.sequencePopupInfoList.indexOf(info, 0);
        if (index > -1) 
        {
            this.sequencePopupInfoList.splice(index, 1);
        }
    }

    private IsNextSequence(currentSequenceInfo: PopupInfo, targetInfo: PopupInfo): boolean
    {
        let targetSequencePopupInfo = this.GetSequceCount() > 0 ? this.sequencePopupInfoList[0] : null;
        return currentSequenceInfo == null && targetSequencePopupInfo == targetInfo;
    }

    public GetSequceCount(): number
    {
        return this.sequencePopupInfoList.length;
    }

    public ClearSequence(): void
    {
        this.currentSequencePopupInfo = null;

        if (this.sequencePopupInfoList != null)
        {
            this.sequencePopupInfoList.length = 0;
        }
    }

    public IsCachedPopupOpen(objectName: string): boolean
    {
        if (this.ContainsCachedPopup(objectName))
        {
            for (let i = 0; i < this.popupInfoList.length; i++)
            {
                let tempInfo = this.popupInfoList[i];
                if (tempInfo.popup.Target != null && tempInfo.cacheID == objectName)
                {
                    return true;
                }
            }
        }

        return false;
    }

    // 팝업을 캐쉬한다.
    public AddCachedPopup(id: string, popup: PopupBehaviour): void;
    public AddCachedPopup<T extends PopupBehaviour>(info: PopupInfo, onComplete: Function): void;
    public AddCachedPopup<T extends PopupBehaviour>(resourcePath: string, onComplete?: Function): void;
    public AddCachedPopup<T extends PopupBehaviour>(assetBundleName: string, objectName: string, onComplete?: Function): void;
    public AddCachedPopup<T extends PopupBehaviour>(assetBundleURL: string, assetBundleName: string, objectName: string, onComplete?: Function): void;
    public AddCachedPopup<T extends PopupBehaviour>(assetBundle: AssetBundle, objectName: string): void;
    public AddCachedPopup<T extends PopupBehaviour>(param1: any, param2: any, param3?: any, param4?: any): void
    {
        if (param1 instanceof PopupInfo)
        {
            let info: PopupInfo = param1;
            let onComplete: Function = param2;
            let id: string = null;

            if (StringUtils.IsNullOrEmpty(info.resourcePath) == false)
            {
                id = info.resourcePath;
            }
            else if (StringUtils.IsNullOrEmpty(info.assetBundleObject) == false)
            {
                id = info.assetBundleObject;
            }
            else
            {
                cc.log("AddCachedPopup 1");

                if (onComplete != null)
                {
                    onComplete(false);
                }

                return;
            }

            if (this.ContainsCachedPopup(id) == true)
            {
                cc.log("AddCachedPopup 2");

                if (onComplete != null)
                {
                    onComplete(true);
                }

                return;
            }

            info.useCache = true;
            info.cacheID = id;

            let popup: PopupBehaviour = null;

            if (info.UseAssetBundle == true)
            {
                this.startCoroutine(this.LoadPopupFromAssetBundle(info, popupParam =>
                {
                    popup = popupParam;

                    if (popup != null)
                    {
                        this.AddCachedPopup(info.cacheID, popup);
                    }

                    cc.log("AddCachedPopup 3");

                    if (onComplete != null)
                    {
                        onComplete(popup != null);
                    }
                }), this);
            }
            else
            {
                this.startCoroutine(this.LoadPopupFromResources(info, popupParam =>
                {
                    popup = popupParam;

                    if (popup != null)
                    {
                        this.AddCachedPopup(info.cacheID, popup);
                    }

                    cc.log("AddCachedPopup 4");

                    if (onComplete != null)
                    {
                        onComplete(popup != null);
                    }
                }), this);
            }
        }
        else if (param1 instanceof AssetBundle)
        {
            cc.log("AddCachedPopup 5");

            param1.GetGameObject(param2, false, (popupGo: cc.Prefab) =>
            {
                //let originActive : boolean = popupGo..activeSelf;
                let popup: PopupBehaviour = cc.instantiate(popupGo).getComponent(PopupBehaviour);
                this.AddCachedPopup(param2, popup);
            });

            // 아직 활성화되지 않은 팝업의 OnEnable이 먼저 호출되는 문제를 막기 위함.

            // let originActive = popupGo.activeSelf;
            // popupGo.SetActive(false);
        }
        else if (param2 instanceof PopupBehaviour)
        {
            cc.log("AddCachedPopup 6");
            let id: string = param1.toString();
            let popup: PopupBehaviour = param2;
            if (this.ContainsCachedPopup(id) == true)
            {
                cc.log("AddCachedPopup 7");
                return;
            }

            this.cachedPopupInfoDic.set(id, popup);
            this.ReturnCachedPopup(id);
        }
        else if (param1 != null && (param2 == null || (param2 != null && param2 instanceof Function)))
        {
            cc.log("AddCachedPopup 8");

            let resourcePath: string = param1.toString();
            let onComplete: Function = param2;

            let popupInfo: PopupInfo = new PopupInfo(this, resourcePath);
            popupInfo.useAsync = false;
            this.AddCachedPopup<T>(popupInfo, onComplete);
        }
        else if (param1 != null && param2 != null && (param3 == null || (param3 != null && param3 instanceof Function)))
        {
            cc.log("AddCachedPopup 9");

            let assetBundleName: string = param1.toString();
            let objectName: string = param2.toString();
            let onComplete: Function = param3;

            let popupInfo: PopupInfo = new PopupInfo(this, "", assetBundleName, objectName);
            popupInfo.useAsync = false;
            this.AddCachedPopup<T>(popupInfo, onComplete);
        }
        else if (param1 != null && param2 != null && param3 != null && (param4 == null || (param4 != null && param4 instanceof Function)))
        {
            cc.log("AddCachedPopup 10");

            let assetBundleURL: string = param1.toString();
            let assetBundleName: string = param2.toString();
            let objectName: string = param3.toString();
            let onComplete: Function = param4;

            let popupInfo: PopupInfo = new PopupInfo(this, assetBundleURL, assetBundleName, objectName);
            popupInfo.useAsync = false;
            this.AddCachedPopup<T>(popupInfo, onComplete);
        }
    }

    public AddCachedPopupAsync<T extends PopupBehaviour>(assetBundleURL: string, assetBundleName: string, objectName: string, onComplete?: Function): void;
    public AddCachedPopupAsync<T extends PopupBehaviour>(assetBundleName: string, objectName: string, onComplete?: Function): void;
    public AddCachedPopupAsync<T extends PopupBehaviour>(resourcePath: string, onComplete?: Function): void;
    public AddCachedPopupAsync<T extends PopupBehaviour>(param1: string, param2?: any, param3?: any, param4?: any): void
    {
        if (param2 == null || param2 instanceof Function)
        {
            cc.log("AddCachedPopupAsync 1");
            let resourcePath: string = param1.toString();
            let onComplete: Function = param2;

            let popupInfo: PopupInfo = new PopupInfo(this, resourcePath);
            popupInfo.useAsync = true;
            this.AddCachedPopup<T>(popupInfo, onComplete);
        }
        else if (param3 == null || param3 instanceof Function)
        {
            cc.log("AddCachedPopupAsync 2");
            let assetBundleName: string = param1.toString();
            let objectName: string = param2.toString();
            let onComplete: Function = param3;

            let popupInfo: PopupInfo = new PopupInfo(this, "", assetBundleName, objectName);
            popupInfo.useAsync = true;
            this.AddCachedPopup<T>(popupInfo, onComplete);
        }
        else
        {
            cc.log("AddCachedPopupAsync 3");
            let assetBundleURL: string = param1;
            let assetBundleName: string = param2;
            let objectName: string = param3;
            let onComplete: Function = param4;
            let popupInfo: PopupInfo = new PopupInfo(this, assetBundleURL, assetBundleName, objectName);
            popupInfo.useAsync = true;
            this.AddCachedPopup<T>(popupInfo, onComplete);
        }
    }

    public RemoveCachedPopup(objectName: string): void
    {
        if (this.ContainsCachedPopup(objectName) == false)
        {
            return;
        }
        if (this.IsCachedPopupOpen(objectName) == false)
        {
            this.GetCachedPopup(objectName).node.destroy();
        }

        this.cachedPopupInfoDic.delete(objectName);
    }

    public RemoveAllCachedPopups(): void
    {
        this.cachedPopupInfoDic.forEach((value, key) =>
        {
            let id: string = key;
            if (this.IsCachedPopupOpen(id) == false)
            {
                // let cachedPopup = GetCachedPopup(id);
                //Destroy(cachedPopup.gameObject);
                this.GetCachedPopup(id).node.destroy();
            }
        }, this);
        this.cachedPopupInfoDic.clear();
    }

    public ContainsCachedPopup(id: string): boolean
    {
        return StringUtils.IsNullOrEmpty(id) ? false : this.cachedPopupInfoDic.has(id);
    }

    private GetCachedPopup(id: string): PopupBehaviour
    {
        return this.ContainsCachedPopup(id) ? this.cachedPopupInfoDic.get(id) : null;
    }

    private ReturnCachedPopup(id: string): boolean
    {
        if (this.ContainsCachedPopup(id))
        {
            let popup: PopupBehaviour = this.GetCachedPopup(id);

            let info = this.GetPopupInfo(popup);

            if (info != null)
            {
                info.popup.Release(false);
            }

            popup.node.setParent(this.cachedRoot);//, false);
            return true;
        }

        return false;
    }

    //테스트
    // success<T>(check:T|boolean, constructor:{new ():T}):boolean 
    // {
    //     return typeof check === 'boolean' ? check : check instanceof constructor;
    // }    

    public IsOpenByName(name: string): boolean
    {
        //let name = param1;
        for (let i = 0; i < this.popupInfoList.length; i++)
        {
            let info = this.popupInfoList[i];
            if (info.assetBundleObject == name)
            {
                return true;
            }
        }

        return false;
    }
    //public IsOpen(name: string): boolean;
    public IsOpen<T extends PopupBehaviour>(type: { prototype: T }): boolean
    //public IsOpen<T extends PopupBehaviour>(param1 : string | {prototype: T}): boolean
    {
        //if (param1 instanceof PopupBehaviour)
        //{
        //let type = param1;
        for (let i = 0; i < this.popupInfoList.length; i++)
        {
            let info: PopupInfo = this.popupInfoList[i];

            if (info.popup && info.popup.Target && info.popup.Target.getComponent(type))                
            {
                return true;
            }
        }
        return false;
        //}
    }

    public IsOpen2(name : string) : boolean
    {
        for (let i = 0; i < this.popupInfoList.length; i++)
        {
            var info = this.popupInfoList[i];
            if (info.assetBundleObject == name)
            {
                return true;
            }
        }

        return false;
    }

    public IsPeek<T extends PopupBackable>(type: { prototype: T }): boolean
    {
        let result = false;
        if (this.popupInfoList.length > 0)
        {
            let target = this.popupInfoList[this.popupInfoList.length - 1].popup.Target;
            result = target != null && this.popupInfoList[this.popupInfoList.length - 1].popup.Target.getComponent(type) != null;
        }
        return result;
    }

    private UnloadUnusedAssets(): void
    {
        cc.resources.releaseAll();

        //Resources.UnloadUnusedAssets();
        //GC.Collect();
    }

    public SetIndicator(obj: BaseLoadingIndicator): void
    {
        this.loadingIndicator.UpdateView(obj);
        this.loadingIndicator.Target.node.active = (false);
    }

    public ShowLoading(blocksRaycasts: boolean = true, type: LoadingType = LoadingType.None): void
    {
        if (this.loadingIndicator.IsValid() == false)
        {
            return;
        }

        this.loadingIndicator.SetActive(true);
        this.loadingIndicator.Target.Show(blocksRaycasts, type);
    }

    public HideLoading(): void
    {
        if (this.loadingIndicator.IsValid() == false)
        {
            return;
        }

        this.loadingIndicator.Target.Hide(() =>
        {
            this.loadingIndicator.SetActive(false);
        });
    }

    private LoadingAsLastSibling(): void
    {
        if (this.loadingIndicator.IsValid() == false)
        {
            return;
        }

        this.loadingIndicator.SetSortingOrder(this.LOADING_INDICATOR_ORDER);
        //this.loadingIndicator.Target.node.SetAsLastSibling();

        if (this.loadingIndicator.Target.node != null)
        {
            this.loadingIndicator.Target.node.setSiblingIndex(-1);
        }
    }

    public IsLoading(): boolean
    {
        return this.loadingIndicator.Target != null && this.loadingIndicator.Target.IsActive;
    }

    public RemovePopupInfo(bundleName: string)
    {
        const index = this.popupInfoList.findIndex(x => x.assetBundleName == bundleName);
        if (index > -1) 
        {
            this.popupInfoList.splice(index, 1);
        }

        this.UpdateCount();
        this.UpdateBackgroundPanel();
        this.HideLoading();
    }
}