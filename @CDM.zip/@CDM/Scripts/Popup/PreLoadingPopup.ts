import { Util } from "../../../@CDM/Scripts/Util/Util";
import { CanvasGroup } from "../../../@CDM/Scripts/Util/CanvasGroup";
import CameraDisabler, { OffType, OnType } from "./CameraDisabler";
import PopupAnimator from "./PopupAnimator";
import PopupBackable from "./PopupBackable";
import PopupSystem from "./PopupSystem";

const { ccclass, property } = cc._decorator;

export class PreLoadingPopupResult
{
    public isSuccess: boolean = false;
    public message: string = '';
}

@ccclass
export abstract class PreLoadingPopup extends PopupBackable
{
    @property(cc.Node) private root: cc.Node = null;
    @property(cc.Node) private block: cc.Node = null;

    public IsInLoading: boolean = false;

    protected set Interactable(value: boolean)
    {
        if (this.block != null)
        {
            this.block.active = !value;
        }
    }

    private rootCanvasGroup: CanvasGroup = null;

    private cameraDisabler: CameraDisabler = null;
    private popupAnimator: PopupAnimator = null;
    private isAnmationComplete: boolean = false;


    //cocos add
    private popupEventHandler: cc.Component.EventHandler = null;

    onLoad()
    {
        this.SetupCameraDisabler();
        this.SetupPopupAnimator();

        this.root.active = false;
    }

    private SetupCameraDisabler(): void
    {
        this.cameraDisabler = this.getComponent(CameraDisabler);

        if (this.cameraDisabler != null)
        {
            this.cameraDisabler.onType = OnType.None;
            this.cameraDisabler.offType = OffType.None;
        }
    }

    private SetupPopupAnimator(): void
    {
        this.popupAnimator = this.getComponent(PopupAnimator);

        if (this.popupAnimator != null)
        {
            this.popupAnimator.playOnEnable = false;
        }
    }

    onEnable(): void
    {
        super.onEnable();

        this.root.active = false;
    }

    onDisable(): void
    {
        super.onDisable();

        this.IsInLoading = false;
    }

    public override Close(): void //override
    {
        if (this.cameraDisabler != null)
        {
            this.cameraDisabler.Off();
        }

        super.Close();
    }

    // 팝업이 열릴 때 꼭 호출 해 줘야함.
    protected StartLoading(): void
    {
        if (this.IsInLoading)
        {
            return;
        }

        this.IsInLoading = true;

        this.startCoroutine(this.LoadingCoroutine(), this);
    }

    *LoadingCoroutine()
    {
        cc.log("PreLoadingPopup - Start Loading");

        this.root.active = false;
        PopupSystem.Instance.ShowLoading();

        let result: PreLoadingPopupResult = null;

        yield this.OnLoading(r=> result = r);

        cc.log("PreLoadingPopup - End Loading");

        PopupSystem.Instance.HideLoading();

        if (result == null
            || result.isSuccess)
        {

            this.root.active = true;

            if (this.popupAnimator != null)
            {
                this.OnLoadComplete(result);

                this.isAnmationComplete = false;

                let count: number = 0;
                //this.popupAnimator.onOpen.RemoveListener(this.OnAnimationOpenHandler);
                if (null != this.popupEventHandler)
                {
                    //this.popupAnimator.onOpen.length = 0;
                    // 1개만 저장되면 위에 방법으로 삭제하면 된다.
                    this.popupAnimator.onOpen.forEach(handleer =>
                    {
                        if (handleer == this.popupEventHandler)
                        {
                            this.popupAnimator.onOpen.splice(count, 1);
                        }
                        count++;

                    }, this);

                }

                //this.popupAnimator.onOpen.AddListener(this.OnAnimationOpenHandler);
                this.popupEventHandler = Util.makeEventHandler(this.node, this, this.OnAnimationOpenHandler, "");
                this.popupAnimator.onOpen.push(this.popupEventHandler);

                this.popupAnimator.Play();
                cc.log("PreLoadingPopup - Start Animation : Open");

                while (this.isAnmationComplete == false)
                {
                    yield null;
                }

                // 삭제
                //this.popupAnimator.onOpen.RemoveListener(this.OnAnimationOpenHandler);
                this.popupAnimator.onOpen.forEach(handleer =>
                {
                    if (handleer == this.popupEventHandler)
                    {
                        this.popupAnimator.onOpen.splice(count, 1);
                    }
                    count++;

                }, this);


                cc.log("PreLoadingPopup - End Animation : Open");
            }
            else
            {
                this.OnLoadComplete(result);
            }


            if (this.cameraDisabler != null)
            {
                this.cameraDisabler.On();
            }
        }
        else
        {
            this.OnLoadComplete(result);
        }

        this.IsInLoading = false;
    }

    private OnAnimationOpenHandler(): void
    {
        this.isAnmationComplete = true;
    }

    protected *OnLoading(onResult : Function)//IEnumerator
    {
        yield;
    }
    protected abstract OnLoadComplete(result : PreLoadingPopupResult): void;
}
//}
