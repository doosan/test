import GameObjectVisibleToggle from "../UI/GameObjectVisibleToggle";

const { ccclass, property } = cc._decorator;

@ccclass
export default class Follower extends cc.Component
{
    public spreadStartPos: cc.Vec2 = cc.Vec2.ZERO;
    public spreadEndPos: cc.Vec2 = cc.Vec2.ZERO;
    public spreadDuration: number = 0;
    public spreadDelay: number = 0;
    public currentSpreadDelay: number = 0;
    public moveDuration: number = 0;
    public currentTime: number = 0;

    public CachedTransform: cc.Node;
    public VisibleToggle : GameObjectVisibleToggle;

    public Initialize(): void
    {
        this.CachedTransform = this.node;
        this.VisibleToggle = this.getComponentInChildren(GameObjectVisibleToggle);
    }
}
