import CoroutineComponent, { Coroutine } from "../System/CoroutineComponent";
import { Time } from "../Time/Time";
import { MyMath, NodeUtil, Util } from "../Util/Util";
import MotionTrail from "./MotionTrail";

const { ccclass, menu, property } = cc._decorator;

export enum MovementType
{
    Curve   = 0,
    Linear  = 1
}

@ccclass
@menu("Effect/CurveMovement")
export default class CurveMovement extends CoroutineComponent
{
    public readonly MIN_CURVE: number = -1.0;
    public readonly MAX_CURVE: number = 1.0;

    @property duration: number = 0.6;

    @property({type:cc.Enum(MovementType)}) public movementType : MovementType = MovementType.Curve;
    @property({visible(){return this.movementType == MovementType.Curve}, type: cc.Float, range: [-1, 1, 0.1], slide: true, }) min: number = -0.5;
    @property({visible(){return this.movementType == MovementType.Curve}, type: cc.Float, range: [-1, 1, 0.1], slide: true, }) max: number = 0.5;
    @property(cc.CurveRange) animationCurve: cc.CurveRange = new cc.CurveRange;

    @property() public useScale : boolean = false;
    @property({visible(){return this.useScale}} ) public startScale : cc.Vec3 = new cc.Vec3() ;
    @property({visible(){return this.useScale}} ) public endScale : cc.Vec3 = new cc.Vec3();
    @property({visible(){return this.useScale}, type: cc.CurveRange} ) public scaleCurve = new cc.CurveRange
    @property({type:cc.Node,visible(){return this.useScale}} ) public specificTarget : cc.Node = null;
    
    @property() private useMotionTrailScale:boolean = false;
    @property({type:MotionTrail, visible(){return this.useMotionTrailScale}}) private motionTrail:MotionTrail = null;
    @property({type:cc.Float,visible(){return this.useMotionTrailScale}} ) private startMotionHeadScale : number = 0;
    @property({type:cc.Float,visible(){return this.useMotionTrailScale}} ) private endMotionHeadScale   : number = 0;


    public CachedTransfom: cc.Node = null;

    private coroutine: Coroutine = null;

    public CurrentTargetPosition : cc.Vec3 = null;
    public CurrentStartPosition  : cc.Vec3 = null;
    public IsLocalPosition : boolean = null;

    //#region 월드 좌표계용 변수
    public CurrentTargetNode : cc.Node = null;
    public CurrentStartNode  : cc.Node = null;
    //#endregion

    onLoad()
    {
        this.CachedTransfom = this.node;
    }

    public Move(position: cc.Vec3, onComplete?: Function): void;
    public Move(position: cc.Vec3, isLocalPosition: boolean, onComplete?: Function): void;
    public Move(position: cc.Vec3, param1?: any, param2?: Function): void
    {
        if (param1 == null || typeof param1 == typeof Function)
        {
            let onComplete = param1;
            this.Move(position, false, onComplete);
        }
        else
        {
            let isLocalPosition = param1;
            let onComplete = param2;
            this.Stop();
            this.coroutine = this.startCoroutine(this.UpdateCoroutine(position, isLocalPosition, onComplete), this);
        }

    }


    public LocalMove(localPosition: cc.Vec3, onComplete: Function = null): void
    {
        this.Move(localPosition, true, onComplete);
    }

    public Stop(): void
    {
        if (this.coroutine != null)
        {
            this.stopCoroutine(this.coroutine);
        }
    }

    *UpdateCoroutine(targetPosition: cc.Vec3, isLocalPosition: boolean, onComplete: Function)
    {
        let startPosition : cc.Vec3 = isLocalPosition == true ? this.node.position.clone() : NodeUtil.GetWorldPosition(this.node);
        targetPosition.z = startPosition.z;
        let currentTime: number = 0;
        
        this.IsLocalPosition = isLocalPosition;
        this.CurrentStartPosition = startPosition;
        this.CurrentTargetPosition = targetPosition;


        let min = cc.misc.clampf(this.min, this.MIN_CURVE, this.MAX_CURVE);
        let max = cc.misc.clampf(this.max, this.MIN_CURVE, this.MAX_CURVE);

        let curveValue: number = 0;

        if (max < min) 
        {
            curveValue = min;
        }
        else
        {

            curveValue = Util.getRandomFloat(min, max);
        }


        if(this.movementType == MovementType.Linear)
        {
            curveValue = 0;
        }
        else
        {
            curveValue = curveValue < 0 ? this.MIN_CURVE - curveValue : this.MAX_CURVE - curveValue;
            curveValue *= 10.0 * 100;
        }

        let center: cc.Vec3 = new cc.Vec3(startPosition.add(targetPosition.clone()).mul(0.5).x, startPosition.add(targetPosition.clone()).mul(0.5).y - curveValue, 0);
        //center.y -= curveValue;

        let riseRelCenter: cc.Vec3 = startPosition.sub(center);
        let setRelCenter: cc.Vec3 = targetPosition.clone().sub(center);

        if (this.useScale)
        {
            this.UpdateScale(0);
        }

        while (true) 
        {
            let targetTime: number = currentTime / this.duration;
            let scaleTime: number = currentTime / this.duration;
            targetTime = this.animationCurve.evaluate(targetTime);

            this.UpdateMove(targetTime, riseRelCenter, setRelCenter, center, isLocalPosition);

            if (this.useScale)
            {
                this.UpdateScale(scaleTime);
            }

            if (currentTime > this.duration) 
            {
                break;
            }

            currentTime += Time.deltaTime;
            yield null;
        }

        if (onComplete != null)
        {
            onComplete.call(this);
        }
    }


    Slerp(a : cc.Vec3, b : cc.Vec3, t : number) : cc.Vec3
    {
        let na = a.normalize();
        let nb = b.normalize();

        let theta = Math.acos(cc.Vec3.dot(na, nb));
        let sinTheta = Math.sin(theta);
        let sinThetaFrom = Math.sin((1 - t) * theta);
        let sinThetaTo = Math.sin(t * theta);

        let magnitudeLerp = cc.misc.lerp(a.mag(), b.mag(), t);
        let slerpVector = (na.mul(sinThetaFrom).add(nb.mul(sinThetaTo))).div(sinTheta);
        
        return slerpVector.mul(magnitudeLerp);
    }

    
    private UpdateMove(time:number, riseRelCenter:cc.Vec3, setRelCenter:cc.Vec3, center:cc.Vec3, isLocalPosition:boolean)
    {
        let targetTime = this.animationCurve.evaluate(time);

        let movePosition : cc.Vec3 = cc.Vec3.ZERO;

        if (this.movementType == MovementType.Linear)
        {
            movePosition = cc.Vec3.lerp(movePosition, riseRelCenter, setRelCenter, targetTime).add(center);
        }
        else
        {
            movePosition = this.Slerp(riseRelCenter, setRelCenter, targetTime).add(center);
        }

        if (isLocalPosition == true)
        {
            this.CachedTransfom.setPosition(movePosition);
        }
        else
        {
            NodeUtil.MoveToWorldPosition(this.CachedTransfom, movePosition);// .setPosition(movePosition);
        }
    }

    private UpdateScale(time:number)
    {
        let targetTime = this.scaleCurve.evaluate(time);
        let targetScale : cc.Vec3 = new cc.Vec3(0, 0, 0) ;
        targetScale = cc.Vec3.lerp(targetScale, this.startScale, this.endScale, targetTime);
        if(this.specificTarget)
        {
            this.specificTarget.setScale(targetScale.x, targetScale.y, targetScale.z);
        }
        else
        {
            this.CachedTransfom.setScale(targetScale.x, targetScale.y, targetScale.z);
        }
        if(this.useMotionTrailScale)
        {
            this.motionTrail.headWidth = MyMath.lerp(targetTime, this.startMotionHeadScale, this.endMotionHeadScale);
        }
    }
}

