import CoroutineComponent, { Coroutine } from "../System/CoroutineComponent";

const { ccclass, property } = cc._decorator;

export enum EffectCompleteType
{
    Success,
    Cancel
}

@ccclass
export default class Effect extends CoroutineComponent
{
    public onComplete: Function = null;
    public onStop: Function = null;

    coroutine: Coroutine;

    public Play(startPosition : cc.Vec2, endPosition : cc.Vec2, onComplete? : Function, onFirstItemArrived? : Function, onItemArrived? : Function) : void;
    public Play(count : number, startPosition : cc.Vec2, endPosition : cc.Vec2, onComplete? : Function, onFirstItemArrived? : Function, onItemArrived? : Function) : void;
    public Play(onComplete: Function): void;
    public Play(param1 : any, param2?: any, param3? : any, param4? : Function, param5? : Function , param6? : Function) : void
    {
        if(param1 instanceof Function)
        {
            let onComplete = param1;
            this.onComplete = onComplete;
            //this.coroutine = this.startCoroutine(this.PlayCoroutine(), this);
            this.CooutinePlay();
        }
    }

    public Stop(): void
    {
        this.stopCoroutine(this.coroutine);
        this.OnStop();

        if (this.onComplete != null)
        {
            this.onComplete(EffectCompleteType.Cancel);
        }
    }

    CooutinePlay()
    {
        
    }

    protected OnStop(): void
    {

    }
}
