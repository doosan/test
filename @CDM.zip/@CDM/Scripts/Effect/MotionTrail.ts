/*******************************************************************************
* 생성: 2023년 03월 17일
 * 지은이:수육편밥(27185709@qq.com)
 * 설명: 스포츠 테일링
 * 1.합비 지원
 *    DrawCall을 중단하지 않고 Atlas의 아틀라스 프레임을 드래그 맵으로 사용할 수 있습니다.
 * 2. 세계 좌표와 노드 좌표 지원
 *    이전 버전의 테일링은 월드 좌표만 지원하며, 게임 내에서 '맵 역방향 이동'을 사용하여 윈도우 팔로우를 구현하면 월드 좌표가 변경되지 않아 테일링 이상이 발생할 수 있습니다.
 *    새 버전의 테일링은 세계 좌표와 로컬 좌표의 두 가지 모드 전환을 지원하며, 위의 문제는 로컬 좌표를 사용하여 해결할 수 있습니다.
 * 3. 메모리 변동 방지
 *    오리지널 테일링은 그라데이션 정점을 지속적으로 생성하여 테일링 효과를 시뮬레이션합니다(입자 시스템과 유사).
      새 버전의 테일링 구현 원리는 테일링의 본질을 완전히 따르고 정점 수가 고정되어 있으며 정점 위치를 업데이트하여 꼬리 모양을 변경하면 메모리가 더 안정적입니다.
 * 4.기타 기능
 *    테일링 모양에 대한 보다 유연한 설정을 지원하고 맵에 대한 요구 사항이 거의 없으며 모든 사진이 테일링 맵으로 좋은 결과를 얻을 수 있습니다.
*******************************************************************************/
const gfx = cc['gfx'];
class TrailData {
    x: number = 0;
    y: number = 0;
    dis: number = 0;
    cos: number = 0;
    sin: number = 0;
}
const { ccclass, property, menu, playOnFocus } = cc._decorator;
@ccclass
@playOnFocus
@menu('Util/MotionTrail')
export default class MotionTrail extends cc.RenderComponent {
    @property({ type: cc.SpriteAtlas, editorOnly: true, readonly: true, displayName: CC_DEV && 'Atlas' })
    private atlas: cc.SpriteAtlas = null;
    @property
    private _spriteFrame: cc.SpriteFrame = null;
    @property({ type: cc.SpriteFrame, displayName: CC_DEV && 'SpriteFrame' })
    private get $spriteFrame() { return this._spriteFrame; }
    private set $spriteFrame(value: cc.SpriteFrame) {
        this._spriteFrame = value;
        this.$updateSpriteFrame();
    }
    @property
    private _active: boolean = true;
    @property({ displayName: CC_DEV && '활성화 여부', tooltip: CC_DEV && '꼬리가 보이도록 설정\n활성화하면 끄기 위치가 재설정됩니다' })
    get active() { return this._active; }
    set active(value: boolean) {
        this._active = value;
        this.enabled = value;
        this.$updateActive();
    }
    @property
    _isWorldXY: boolean = true;
    @property({ displayName: CC_DEV && '세계 좌표', tooltip: CC_DEV && '꼭짓점 좌표는 세계 좌표인지 로컬 좌표인지' })
    get $isWorldXY() { return this._isWorldXY; }
    set $isWorldXY(value: boolean) {
        this._isWorldXY = value;
        this.$updateXY();
    }
    @property({ displayName: CC_DEV && '편차' })
    private offset: cc.Vec2 = cc.v2(0, 0);
    @property
    private _length: number = 20;
    @property({ type: cc.Integer, displayName: CC_DEV && '꼬리 길이' })
    private get length() { return this._length; }
    private set length(value: number) {
        this._length = Math.max(value, 0);
        this.updateLength();
        this.updateWidth();
        this.$updateUV();
        this.$updateColor();
        this.resetPos();
    }
    @property
    private _headWidth: number = 100;
    @property({ displayName: CC_DEV && '머리 너비' })
    public get headWidth() { return this._headWidth; }
    public set headWidth(value: number) {
        this._headWidth = Math.max(value, 0);
        this.updateWidth();
    }
    @property
    private _tailWidth: number = 0;
    @property({ displayName: CC_DEV && '꼬리 너비' })
    private get tailWidth() { return this._tailWidth; }
    private set tailWidth(value: number) {
        this._tailWidth = Math.max(value, 0);
        this.updateWidth();
    }
    @property
    private _headOpacity: number = 255;
    @property({ type: cc.Integer, min: 0, max: 255, slide: true, displayName: CC_DEV && '머리 투명도' })
    private get headOpacity() { return this._headOpacity; }
    private set headOpacity(value: number) {
        this._headOpacity = value;
        this.$updateColor();
    }
    @property
    private _tailOpacity: number = 0;
    @property({ type: cc.Integer, min: 0, max: 255, slide: true, displayName: CC_DEV && '꼬리 투명도' })
    private get tailOpacity() { return this._tailOpacity; }
    private set tailOpacity(value: number) {
        this._tailOpacity = value;
        this.$updateColor();
    }
    private renderData = null;
    private meshID: number = 0;
    private capacity: number = 0;
    private verticesCount: number = 0;       //꼭짓점수
    private indicesCount: number = 0;        //삼각형 개수 * 3
    $flush: Function = null;                 //onFlushed에서 업데이트된 꼭짓점 데이터는 flush를 불러와야 제출할 수 있습니다
    $xyOffset: number = 1e8;                 //꼭짓점 좌표 데이터, 꼭짓점 배열의 간격띄우기
    $uvOffset: number = 1e8;                 //꼭짓점 uv 데이터, 꼭짓점 배열의 간격띄우기
    $colorOffset: number = 1e8;              //꼭짓점 색상 데이터, 꼭짓점 배열의 간격띄우기
    $step: number = 0;                       //단일 꼭짓점 데이터의 길이, 예를 들어 꼭짓점 형식 "x,y,u,v,color" step = 5
    get $vDataLength() { return this.verticesCount * this.$step; }
    get $iDataLength() { return this.indicesCount; }
    private trailData: TrailData[] = [];
    private nodeOpacity: number = 255;

    protected _resetAssembler() {
        let assembler = this['_assembler'] = new Assembler2D();
        assembler['init'](this);
        assembler['updateRenderData'] = this.$onFlushed.bind(this);
        this.$flush = this['setVertsDirty'];
        let renderData = this.renderData = new cc['RenderData']();
        renderData.init(assembler);
        this.meshID = renderData.meshCount;
        this.$init();
    }

    protected $init() {
        this.$setVFmt();
        this.updateLength();
        this.updateWidth();
        this.node.on(cc.Node.EventType.COLOR_CHANGED, this.$updateColor, this);
        this.resetPos();
    }

    protected start() {
        this.$updateSpriteFrame();
        cc.director.once(cc.Director.EVENT_AFTER_DRAW, this.$updateColor, this);
    }
    //꼭짓점 형식 설정
    protected $setVFmt(vfmt = new gfx.VertexFormat([
        { name: gfx.ATTR_POSITION, type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
        { name: gfx.ATTR_UV0, type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
        { name: gfx.ATTR_COLOR, type: gfx.ATTR_TYPE_UINT8, num: 4, normalize: true },
    ])) {
        let assembler = this['_assembler'];
        cc.sys.isNative && assembler['setVertexFormat'](vfmt);
        let fmtElement = vfmt._elements;
        for (let i = fmtElement.length - 1; i >= 0; --i) {
            this.$step += fmtElement[i].bytes >> 2;
        }
        let fmtAttr = vfmt._attr2el;
        this.$xyOffset = fmtAttr[gfx.ATTR_POSITION].offset >> 2;
        this.$uvOffset = fmtAttr[gfx.ATTR_UV0].offset >> 2;
        this.$colorOffset = fmtAttr[gfx.ATTR_COLOR].offset >> 2;
    }
    //꼭짓점 개수와 삼각형 개수 설정
    protected $createBuffer(verticesCount: number, triangleCount: number = verticesCount - 2, capacityRatio: number = 2) {
        capacityRatio = Math.max(capacityRatio, 1.5);
        let renderData = this.renderData;
        this.verticesCount = Math.max(verticesCount, 0);
        this.indicesCount = Math.max(triangleCount * 3, 0);
        let isCreate = !renderData.vDatas[this.meshID];
        if (this.verticesCount > this.capacity) {                         //꼭짓점 개수가 용량을 초과하면 capacityRatio배 용량확대
            this.capacity = ~~Math.max(this.capacity * capacityRatio, this.verticesCount);
            isCreate = true;
        } else if (this.verticesCount < this.capacity / capacityRatio) {  //꼭짓점 개수가 용량의 "1/capacityRatio"보다 작으면 capacityRatio배 감소
            this.capacity = ~~Math.max(this.capacity / capacityRatio, this.verticesCount);
            isCreate = true;
        }
        if (isCreate) {
            let vertices = new Float32Array(this.verticesCount * this.$step);
            let indices = new Uint16Array(this.indicesCount);
            renderData.updateMesh(this.meshID, vertices, indices);
        }
        this.$updateIndice();
    }
    protected $getVData = (): Float32Array => this.renderData.vDatas[this.meshID];
    protected $getUintVData = (): Uint32Array => this.renderData.uintVDatas[this.meshID];
    protected $getIData = (): Uint16Array => this.renderData.iDatas[this.meshID];
    protected update() {
        cc.sys.isNative && this.$updateColor();
        this.$flush();
    }

    protected $onFlushed() {
        if (this.active === false) return;
        if (this.$spriteFrame === null) return;
        if (this.length === 0) return;
        if (this.nodeOpacity !== this.node.opacity) {
            this.nodeOpacity = this.node.opacity;
            this.$updateColor();
        }
        let data = this.trailData;
        for (let i = this.length - 1; i > 0; --i) {
            let cur = data[i], prev = data[i - 1];
            cur.x = prev.x;
            cur.y = prev.y;
            cur.sin = prev.sin;
            cur.cos = prev.cos;
        }
        if (this.$isWorldXY) {
            let m = this.node['_worldMatrix'].m;
            this.node['_updateWorldMatrix']();
            data[0].x = this.offset.x + m[12];
            data[0].y = this.offset.y + m[13];
        } else {
            data[0].x = this.offset.x + this.node.x;
            data[0].y = this.offset.y + this.node.y;
        }
        this.$updateXY();
    }

    protected $updateActive() {
        if (this.active) {
            this.resetPos();
        }
    }

    private $updateSpriteFrame() {
        let frame = this.$spriteFrame;
        let material = this.getMaterial(0) || cc.Material.getBuiltinMaterial('2d-sprite');
        material.define("USE_TEXTURE", true);
        material.setProperty("texture", frame ? frame.getTexture() : null);
        if (CC_EDITOR) {
            if (frame && frame.isValid && frame['_atlasUuid']) {
                cc.assetManager.loadAny(frame['_atlasUuid'], (err, asset: cc.SpriteAtlas) => {
                    this.atlas = asset;
                });
            } else {
                this.atlas = null;
            }
        }
        this.$updateUV();
    }

    protected $updateXY() {
        let vData = this.$getVData();
        let a = null, b = null;
        let ax = 0, ay = 0, bx = 0, by = 0;
        let id = 0;
        let step = this.$step;
        let tx = 0, ty = 0;
        if (!this.$isWorldXY) {
            tx = this.node.x;
            ty = this.node.y;
        }
        let data = this.trailData;
        for (let i = 0, len = this.length - 1; i < len; ++i) {
            a = data[i];
            b = data[i + 1];
            ax = a.x - tx;
            ay = a.y - ty;
            bx = b.x - tx;
            by = b.y - ty;
            if (i === 0) {
                let radian = Math.atan2(by - ay, bx - ax);
                a.sin = Math.sin(radian);
                a.cos = Math.cos(radian);
            }
            vData[id] = ax + a.dis * a.sin;
            vData[id + 1] = ay - a.dis * a.cos;
            id += step;
            vData[id] = ax - a.dis * a.sin;
            vData[id + 1] = ay + a.dis * a.cos;
            id += step;
        }
        vData[id] = bx + b.dis * a.sin;
        vData[id + 1] = by - b.dis * a.cos;
        id += step;
        vData[id] = bx - b.dis * a.sin;
        vData[id + 1] = by + b.dis * a.cos;
        this.$fitXY();
    }

    private $updateUV() {
        if (this.$spriteFrame === null) return;
        let vData = this.$getVData();
        let step = this.$step;
        let uvStep = 1 / (this.trailData.length - 1);
        for (let i = this.$uvOffset, id = 0, len = this.$vDataLength; i < len; i += step, ++id) {
            vData[i] = id & 1;
            vData[i + 1] = 1 - uvStep * (id >> 1);
        }
        this.$fitUV();
    }

    protected $updateColor() {
        let uintVData = this.$getUintVData();
        let trailLen = this.length;
        let headOpa = this.headOpacity;
        let opaDelt = (headOpa - this.tailOpacity) / (trailLen - 1);
        let opaRatio = this.node.opacity / 255;
        let rgb = (this.node.color.b << 16) | (this.node.color.g << 8) | this.node.color.r;
        for (let i = 0, id = this.$colorOffset, step = this.$step; i < trailLen; ++i) {
            let color = (((headOpa - opaDelt * i) * opaRatio) << 24) | rgb;
            uintVData[id] = color;
            id += step;
            uintVData[id] = color;
            id += step;
        }
    }

    protected $updateIndice() {
        let iData = this.$getIData();
        for (let i = 0, id = 0, len = this.$iDataLength; i < len; ++id) {
            iData[i++] = id;
            iData[i++] = id + 1;
            iData[i++] = id + 2;
        }
    }

    private updateLength() {
        let trailLen = this.length;
        this.trailData = [];
        for (let i = 0; i < trailLen; ++i) {
            this.trailData[i] = new TrailData();
        }
        this.$createBuffer(trailLen << 1);
    }

    private updateWidth() {
        let data = this.trailData;
        let trailLen = this.length;
        let headHalfW = this.headWidth * 0.5;
        let disDelt = (headHalfW - this.tailWidth * 0.5) / (trailLen - 1);
        for (let i = 0; i < trailLen; ++i) {
            data[i].dis = headHalfW - disDelt * i;
        }
    }

    private resetPos() {
        let data = this.trailData;
        let tx = this.offset.x;
        let ty = this.offset.y;
        if (this.$isWorldXY) {
            let m = this.node['_worldMatrix'].m;
            this.node['_updateWorldMatrix']();
            tx += m[12];
            ty += m[13];
        } else {
            tx += this.node.x;
            ty += this.node.y;
        }
        for (let i = this.length - 1; i >= 0; --i) {
            data[i].x = tx;
            data[i].y = ty;
        }
        let vData = this.$getVData();
        let step = this.$step;
        for (let i = 0, len = this.$vDataLength; i < len; i += step) {
            vData[i] = tx;
            vData[i + 1] = ty;
        }
        this.$fitXY();
    }
    //XY 자동 적응, 꼭짓점 xy 데이터 수정 후 능동적으로 함수 호출
    protected $fitXY() {
        let vData = this.$getVData();
        if (cc.sys.isNative) {
            if (this.$isWorldXY) {
                let m = this.node['_worldMatrix'].m;
                let im = cc.Mat4.invert(new cc.Mat4(), this.node['_worldMatrix']).m;
                for (let i = this.$xyOffset, len = this.$vDataLength; i < len; i += this.$step) {
                    let wx = m[0] * vData[i] + m[4] * vData[i + 1];
                    let wy = m[1] * vData[i] + m[5] * vData[i + 1];
                    vData[i] = im[0] * wx + im[4] * wy + im[12];
                    vData[i + 1] = im[1] * wx + im[5] * wy + im[13];
                }
            }
        } else {
            let m = this.node['_worldMatrix'].m;
            let tx = this.$isWorldXY ? 0 : m[12];
            let ty = this.$isWorldXY ? 0 : m[13];
            for (let i = this.$xyOffset, len = this.$vDataLength; i < len; i += this.$step) {
                let x = vData[i], y = vData[i + 1];
                vData[i] = x * m[0] + y * m[4] + tx;
                vData[i + 1] = x * m[1] + y * m[5] + ty;
            }
        }
    }
    //UV 자동 적응, 꼭짓점 uv 데이터 수정 후 능동적으로 이 함수를 호출해야 함
    protected $fitUV() {
        if (this.$spriteFrame === null) return;
        let step = this.$step;
        let atlasW = this.$spriteFrame.getTexture().width;
        let atlasH = this.$spriteFrame.getTexture().height;
        let frameRect = this.$spriteFrame.getRect();
        let vData = this.$getVData();
        if (this.$spriteFrame['_rotated']) {
            for (let i = this.$uvOffset, id = 0, len = this.$vDataLength; i < len; i += step, ++id) {
                let tmp = vData[i];
                vData[i] = ((1 - vData[i + 1]) * frameRect.height + frameRect.x) / atlasW;
                vData[i + 1] = (tmp * frameRect.width + frameRect.y) / atlasH;
            }
        } else {
            for (let i = this.$uvOffset, id = 0, len = this.$vDataLength; i < len; i += step, ++id) {
                vData[i] = (vData[i] * frameRect.width + frameRect.x) / atlasW;
                vData[i + 1] = (vData[i + 1] * frameRect.height + frameRect.y) / atlasH;
            }
        }
    }

    protected onDestroy() {
        this.node.targetOff(this);
    }
}

class Assembler2D extends cc['Assembler'] {
    protected fillBuffers(comp) {
        let vData = comp.renderData.vDatas[comp.meshID];
        let iData = comp.renderData.iDatas[comp.meshID];
        let buffer = cc.renderer['_handle']._meshBuffer;
        let offsetInfo = buffer.request(comp.verticesCount, comp.indicesCount);
        let vertexOffset = offsetInfo.byteOffset >> 2;
        let vbuf = buffer._vData;
        if (vData.length + vertexOffset > vbuf.length) {
            vbuf.set(vData.subarray(0, vbuf.length - vertexOffset), vertexOffset);
        } else {
            vbuf.set(vData, vertexOffset);
        }
        let ibuf = buffer._iData;
        let indiceOffset = offsetInfo.indiceOffset;
        let vertexId = offsetInfo.vertexOffset;
        for (let i = 0, l = iData.length; i < l; i++) {
            ibuf[indiceOffset++] = vertexId + iData[i];
        }
    }
}