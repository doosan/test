import CoroutineComponent, { WaitForSeconds } from "../../../@CDM/Scripts/System/CoroutineComponent";
import InstanceEvent from "../../../@CDM/Scripts/System/InstanceEvent";
import { ArrayUtil, NodeUtil } from "../../../@CDM/Scripts/Util/Util";
import CurveMovement from "./CurveMovement";
import MotionTrail from "./MotionTrail";

const {ccclass, property} = cc._decorator;

export enum State
{
    StartEffect,
    Move,
    EndEffect
}

@ccclass("Preset")
export class Preset
{ 
    @property(cc.Float) public startDelay:number = 0;
    @property(cc.Node) public startEffect:cc.Node = null;
    @property() public startEffectAutoDisable:boolean = false;
    @property(cc.Float) public moveDelay:number = 0;
    @property(CurveMovement) public  movableEffect : CurveMovement = null;
    @property() public movableEffectAutoDisable:boolean = false;
    @property(cc.Float) public endDuration:number = 0;
    @property(cc.Node) public endEffect:cc.Node = null;
    @property() public isMotionTrail:boolean = false;
    @property({type:MotionTrail, visible(){return this.isMotionTrail}}) public motionTrail:MotionTrail = null;
    @property() public hasLabel:boolean = false;
    @property({type:cc.Label, visible(){return this.hasLabel}}) public label:cc.Label = null;

    public get TotalDuration() : number
    {
        return this.moveDelay + this.movableEffect.duration + this.endDuration;
    }
}

@ccclass
export default class MovableEffect extends CoroutineComponent 
{
    @property([Preset]) private presets: Preset[] = [];
    private currentPreset:Preset = null;
    private onComplete: Action0 = null;
    private onStateChange : Action0 =  null;

    onLoad()
    {
        for (let i = 0; i < this.presets.length; i++)
        {
            this.Stop(this.presets[i]);
        }
    }

    onDisable()
    {
        super.onDisable();
        this.Stop();
    }

    public AddPreset(preset:Preset)
    {
        if (this.presets.includes(preset))
        {
            return;
        }

        this.presets.push(preset);
    }

    public RemovePreset(preset:Preset)
    {
        if (this.presets.includes(preset) == false)
        {
            return;
        }

        ArrayUtil.arrayRemove(this.presets, preset);
    }
    public GetPreset():Preset;
    public GetPreset(index: number) :Preset
    public GetPreset(param1:any = null) :Preset
    {
        if(typeof param1 == typeof 1)
        {
            if (param1 >= this.presets.length)
            {
                cc.log("presetIndex가 presets 길이를 벗어남.");
                return null;
            }
    
            return this.presets[param1];
        }
        else
        {
            return this.GetPreset(0);
        }
    }

    public Play(from:cc.Vec3, to:cc.Vec3 , onComplete:Action0 , onStateChange:Action1<State>)                          : void
    public Play(to:cc.Vec3, onComplete:Action0, onStateChange:Action1<State>)                                         : void
    public Play(presetIndex:number, from:cc.Vec3, to:cc.Vec3,  onComplete:Action0, onStateChange:Action1<State>)      : void
    public Play(presetIndex:number, to:cc.Vec3, onComplete:Action0, onStateChange:Action1<State>)                     : void
    public Play(presetIndex:number, from:cc.Vec3 , to:cc.Vec3, isLocalPosition:boolean, onComplete:Action0, onStateChange:Action1<State>) : void
    public Play(param1:any, param2:any= null, param3:any= null, param4:any= null, param5:any = null)                  : void
    {
        if(param1 instanceof cc.Vec3)
        {
            if(param2 instanceof cc.Vec3)
            {
                this.Play6(0, param1, param2, false, param3, param4);
            }
            else
            {
                this.Play6(0, NodeUtil.GetWorldPosition(this.node), param1, false, param2, param3);
            }
        }
        else if(typeof param1  == typeof 1)
        {
            if(param3 instanceof cc.Vec3)
            {
                this.Play6(param1, param2, param3, false, param4, param5);
            }
            else
            {
                this.Play6(param1, NodeUtil.GetWorldPosition(this.node), param2, false, param3, param4);
            }
        }
    }

    private Play6(param1:any, param2:any= null, param3:any= null, param4:any= null, param5:any = null, param6: any = null)
    {
        if (this.currentPreset != null)
        {
            cc.log("이미 플레이 중입니다.");
            return;
        }

        let preset = this.GetPreset(param1);

        if (preset == null)
        {
            return;
        }

        this.onComplete = param5;

        this.currentPreset = preset;
        this.startCoroutine(this.PlayCoroutine(this.currentPreset, param2, param3, param4, param6));
    }
    
    public PlayLocal(from:cc.Vec3, to:cc.Vec3, onComplete:Action0, onStateChange:Action1<State>)
    public PlayLocal(to:cc.Vec3, onComplete:Action0, onStateChange:Action1<State>)
    public PlayLocal(presetIndex:number, from:cc.Vec3, to: cc.Vec3, onComplete:Action0, onStateChange:Action1<State>)
    public PlayLocal(presetIndex:number, to:cc.Vec3, onComplete:Action0, onStateChange:Action1<State>)
    public PlayLocal(param1:any, param2:any=null, param3:any=null, param4:any=null, param5:any = null) : void
    {
        if(typeof param1 == typeof cc.Vec3)
        {
            if(typeof param2 == typeof cc.Vec3)
            {
                this.Play6(0, param1, param2, true, param3.bind(this), param4.bind(this));
            }
            else
            {
                this.Play6(0, this.node.position, param1, true, param2.bind(this), param3.bind(this));
            }
        }
        else if(typeof param1 == typeof 1)
        {
            if(typeof param3 == typeof cc.Vec3)
            {
                this.Play6(param1, param2, param3, true, param4.bind(this), param5.bind(this));
            }
            else
            {
                this.Play6(param1, this.node.position, param2, true, param3.bind(this), param4.bind(this));
            }
        }
    }

    public Stop()
    public Stop(preset:Preset)    : void
    public Stop(param1:any = null) : void
    {
        if(param1 == null)
        {
            if (this.currentPreset == null)
            {
                return;
            }

            this.Stop(this.currentPreset);
            this.currentPreset = null;

            if (this.onComplete != null)
            {
                this.onComplete.call(this);
            }

            this.onComplete = null;
        }
        else
        {
            param1.movableEffect.Stop();

            this.stopAllCoroutines();

            this.SetEffectActive(param1.movableEffect.node, false);
            this.SetEffectActive(param1.startEffect, false);
            this.SetEffectActive(param1.endEffect, false);
        }
    }

    *PlayCoroutine(preset:Preset, from:cc.Vec3, to:cc.Vec3, isLocalPosition:boolean, onStateChange:Action1<State>)
    {
        this.SetEffectActive(preset.movableEffect.node, false);
        this.SetEffectActive(preset.startEffect, false);
        this.SetEffectActive(preset.endEffect, false);

        let isMoveComplete = false;

        let MoveComplete : Function = () => 
        {
            isMoveComplete = true;
        };

        yield new WaitForSeconds(preset.startDelay);

        this.DispatchStateEvent(onStateChange, State.StartEffect);

        this.SetEffectActive(preset.startEffect, true);
        this.SetEffectPosition(preset.startEffect, from, isLocalPosition);

        yield new WaitForSeconds(preset.moveDelay);

        if (preset.startEffectAutoDisable)
        {
            this.SetEffectActive(preset.startEffect, false);
        }

        this.DispatchStateEvent(onStateChange, State.Move);

        this.SetEffectActive(preset.movableEffect.node, true);
        this.SetEffectPosition(preset.movableEffect.node, from, isLocalPosition);

        if(isLocalPosition)
        {
            preset.movableEffect.LocalMove(to, MoveComplete.bind(this));
        }
        else
        {
            preset.movableEffect.Move(to, MoveComplete.bind(this));
        }
        while (isMoveComplete == false)
        {
            yield null;
        }

        if (preset.movableEffectAutoDisable)
        {
            this.SetEffectActive(preset.movableEffect.node, false);
        }

        this.DispatchStateEvent(onStateChange, State.EndEffect);

        this.SetEffectActive(preset.endEffect, true);
        this.SetEffectPosition(preset.endEffect, to, isLocalPosition);

        yield new WaitForSeconds(preset.endDuration);

        this.Stop();
    }

    private DispatchStateEvent(action:Action1<State>, state:State)
    {
        if (action != null)
        {
            action.call(this, state);
        }
    }

    private SetEffectPosition(effect:cc.Node, position:cc.Vec3, isLocalPosition:boolean)
    {
        if (effect != null)
        {
            if (isLocalPosition)
            {
                effect.setPosition(position);
            }
            else
            {
                NodeUtil.MoveToWorldPosition(effect, position);
            }
        }
    }

    private SetEffectActive(effect:cc.Node, isOn:boolean)
    {
        if (effect != null)
        {
            effect.active = (isOn);
        }
    }
}
