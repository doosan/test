import GlobalData from "../../../Scripts/GlobalData";
import GameObjectPool from "../ObjectPool/GameObjectPool";
import BezierPath, { ControlMode } from "../PathCreator/Core/Runtime/Objects/BezierPath";
import { EndOfPathInstruction } from "../PathCreator/Core/Runtime/Objects/EndOfPathInstruction";
import PathCreator from "../PathCreator/Core/Runtime/Objects/PathCreator";
import { PathSpace } from "../PathCreator/Core/Runtime/Objects/PathSpace";
import SoundPlayer, { AudioTriggerType } from "../Sound/SoundPlayer/SoundPlayer";
import { WaitForSeconds } from "../System/CoroutineComponent";
import ScreenSystem from "../System/ScreenSystem";
import { Time } from "../Time/Time";
import { Util, Quaternion, NodeUtil } from "../Util/Util";
import Effect, { EffectCompleteType } from "./Effect";
import Follower from "./Follower";

const { ccclass, property } = cc._decorator;

export enum AutoRotationType
{
    None, Path, Zero
}

@ccclass
export default class ItemGainEffect extends Effect
{
    public static readonly DEFAULT_ITEM_COUNT: number = 15;

    //#pragma warning disable 0649    
    @property(PathCreator) path: PathCreator = null;
    @property(cc.Node) refernceObject: cc.Node = null;

    //[Space]
    //[SerializeField] private AnimationCurve sizeOverLifetime = AnimationCurve.Linear(0,1,1,1);
    @property(cc.CurveRange) sizeOverLifetime: cc.CurveRange = new cc.CurveRange();
    @property moveDuration: number = 1;
    @property useSpread: boolean = true;
    @property disStrength: number = 1;
    @property(SoundPlayer) spreadSFX: SoundPlayer = null;

    @property({ type: cc.Enum(AutoRotationType) }) autoRatation: AutoRotationType = AutoRotationType.None;

    //[LabelOverride("2D Mode")] 
    @property twoDMode: boolean = true;
    @property randRot: boolean = true;

    //[Header("FirstArrive")]
    @property(cc.Node) beginningEffect: cc.Node = null;
    @property(SoundPlayer) firstArrivedSFX: SoundPlayer = null;
    @property(cc.Node) firstArrivedEffect: cc.Node = null;
    @property firstArrivedEffectDuration: number = 0;
    //#pragma warning restore 0649

    private startPosition: cc.Vec2 = cc.Vec2.ZERO;
    private endPosition: cc.Vec2 = cc.Vec2.ZERO;
    private followerList: Array<Follower> = null;
    public get FollowerList(): Array<Follower>
    {
        return this.followerList;
    }
    private onBegin: Function = null;
    private onFirstItemArrived: Function = null;
    private onItemArrived: Function = null;
    private followerPool: GameObjectPool<Follower> = null;
    private itemCount: number = 0;
    private scaleTarget: cc.Node = null;
    private canvasScale: number = 1.0;

    @property(cc.ParticleSystem3D) beginningParticle: cc.ParticleSystem3D = null;
    @property(cc.ParticleSystem3D) firstArrivedParticle: cc.ParticleSystem3D = null;

    private followerTweenList: cc.Tween[] = [];

    onLoad()
    {
        this.followerList = [];

        if (this.beginningEffect != null)
        {
            this.beginningEffect.opacity = 0;
            this.beginningParticle.stop();
            //this.beginningEffect.active = false;
        }

        if (this.firstArrivedEffect != null)
        {
            this.firstArrivedEffect.opacity = 0;
            this.firstArrivedParticle.stop();
            //this.firstArrivedEffect.active = false;
        }

        this.SetupSounds();
        this.SetupFollowerPool(ItemGainEffect.DEFAULT_ITEM_COUNT);
    }

    onDisable()
    {
        super.onDisable();
        // if(this.targetParticle != null)
        // {
        //     this.targetParticle.clear();
        //     this.targetParticle.node.opacity = 0;
        // }

        if (this.beginningEffect != null) 
        {
            this.beginningParticle.clear();
            this.beginningEffect.opacity = 0;
            //this.beginningEffect.active = false;
        }

        if (this.firstArrivedEffect != null) 
        {
            this.firstArrivedParticle.clear();
            this.firstArrivedEffect.opacity = 0;
            //this.firstArrivedEffect.active = false;
        }
    }

    private SetupSounds(): void
    {
        if (this.spreadSFX != null)
        {
            this.spreadSFX.triggerType = AudioTriggerType.None;
        }

        if (this.firstArrivedSFX != null)
        {
            this.firstArrivedSFX.triggerType = AudioTriggerType.None;
        }
    }

    private SetupFollowerPool(followerCount: number): void
    {
        let followePoolRoot = new cc.Node("FollowePoolRoot");
        followePoolRoot.setParent(this.node)//, false);

        this.followerPool = new GameObjectPool<Follower>(followePoolRoot, 10, () => 
        {
            return this.CreateFollower();
        });
    }

    private CreateFollower(): Follower
    {
        let follower: Follower = cc.instantiate(this.refernceObject).addComponent(Follower);
        follower.Initialize();

        return follower;
    }

    public Play(startPosition: cc.Vec2, endPosition: cc.Vec2, onBegin?: Function, onComplete?: Function, onFirstItemArrived?: Function, onItemArrived?: Function): void;
    public Play(count: number, startPosition: cc.Vec2, endPosition: cc.Vec2, onBegin?: Function, onComplete?: Function, onFirstItemArrived?: Function, onItemArrived?: Function): void;
    public Play(onComplete: Function): void;
    public Play(param1: any, param2?: any, param3?: any, param4?: Function, param5?: Function, param6?: Function, param7?: Function): void
    {
        if (!(param1 instanceof Function))
        {
            if (param1 instanceof cc.Vec2)
            {
                let startPosition: cc.Vec2 = param1;
                let endPosition: cc.Vec2 = param2;
                let onBegin: Function = param3;
                let onComplete: Function = param4;
                let onFirstItemArrived: Function = param5;
                let onItemArrived: Function = param6;
                this.Play(ItemGainEffect.DEFAULT_ITEM_COUNT, startPosition, endPosition, onBegin, onComplete, onFirstItemArrived, onItemArrived);
            }
            else
            {
                let count: number = param1;
                let startPosition: cc.Vec2 = param2;
                let endPosition: cc.Vec2 = param3;
                let onBegin: Function = param4;
                let onComplete: Function = param5;
                let onFirstItemArrived: Function = param6;
                let onItemArrived: Function = param7;

                this.startPosition = startPosition;
                this.endPosition = endPosition;
                this.onBegin = onBegin;
                this.onFirstItemArrived = onFirstItemArrived;
                this.onItemArrived = onItemArrived;

                if (this.scaleTarget != null && this.scaleTarget as cc.Node)
                {
                    this.canvasScale = 100;
                }

                this.itemCount = count;

                if (this.beginningEffect != null)
                {
                    this.beginningEffect.setPosition(startPosition);
                    this.beginningEffect.opacity = 255;
                    //this.beginningEffect.active = true;
                    this.beginningParticle.play();
                }

                if (this.useSpread && this.spreadSFX != null)
                {
                    this.spreadSFX.Play();
                }

                Object.setPrototypeOf(onComplete, Function);
                super.Play(onComplete);
            }
        }
    }

    *PlayCoroutine()
    {
        yield this.OnPlay();

        if (this.onComplete != null)
        {
            this.onComplete(EffectCompleteType.Success);
        }
    }

    CooutinePlay()
    {
        this.coroutine = this.startCoroutine(this.PlayCoroutine(), this);
    }

    private GetTargetScale(): cc.Vec2
    {
        if (this.scaleTarget == null)
        {
            return cc.Vec2.ONE;
        }
        else
        {
            if (this.scaleTarget.activeInHierarchy == false)
            {
                return NodeUtil.GetLossyScale(this.scaleTarget);
            }
            else
            {
                let res: cc.Vec2 = cc.Vec2.ONE;
                res = cc.Vec2.multiplyScalar(res, NodeUtil.GetLossyScale(this.scaleTarget), this.canvasScale);
                return res;
            }
        }
    }

    calculateBezierPoint(startPoint: cc.Vec2, controlPoint1: cc.Vec2, endPoint: cc.Vec2, t: number): cc.Vec2
    {
        const u = 1 - t;
        const uu = u * u;
        const tt = t * t;
        const uuu = uu * u;
        const ttt = tt * t;

        let p = startPoint.clone()
            .multiplyScalar(uuu)
            .add(controlPoint1.clone().multiplyScalar(3 * uu * t))
            .add(endPoint.clone().multiplyScalar(3 * u * tt))
            .add(endPoint.clone().multiplyScalar(ttt));

        return p;
    }

    *OnPlay()
    {
        let points: Array<cc.Vec3> = []; //new Vector2[5];

        let halfX: number = this.startPosition.x + ((this.endPosition.x - this.startPosition.x) * 0.5);
        let halfY: number = this.startPosition.y + ((this.endPosition.y - this.startPosition.y) * 0.5);

        let pos1: cc.Vec3 = cc.Vec3.ZERO;
        let pos2: cc.Vec3 = cc.Vec3.ZERO;
        let pos3: cc.Vec3 = cc.Vec3.ZERO;

        if (ScreenSystem.IsPortrait && GlobalData.IsFB_Mobile)
        {
            pos1 = new cc.Vec3(this.startPosition.x + (halfY - this.startPosition.x) * 0.5, this.startPosition.y);
            pos2 = new cc.Vec3(halfX, halfY);
            pos3 = new cc.Vec3(halfX + (this.endPosition.y - halfY) * 0.5, this.endPosition.y);
        }
        else
        {
            pos1 = new cc.Vec3(this.startPosition.x, this.startPosition.y + (halfY - this.startPosition.y) * 0.5);
            pos2 = new cc.Vec3(halfX, halfY);
            pos3 = new cc.Vec3(this.endPosition.x, halfY + (this.endPosition.y - halfY) * 0.5);
        }

        points.push(new cc.Vec3(this.startPosition.x, this.startPosition.y));
        points.push(pos1);
        points.push(pos2);
        points.push(pos3);
        points.push(new cc.Vec3(this.endPosition.x, this.endPosition.y));

        let bp: BezierPath = new BezierPath(points, false, PathSpace.xy);
        bp.ControlPointMode = ControlMode.Mirrored;
        this.path.bezierPath = bp;

        this.followerList.length = 0;

        let startScale: number = this.sizeOverLifetime.evaluate(0.0);

        for (let i = 0; i < this.followerTweenList.length; i++)
        {
            if (this.followerTweenList[i] != null)
            {
                this.followerTweenList[i].stop();
                this.followerTweenList[i].removeSelf();
                this.followerTweenList[i] = null;
            }
        }

        this.followerTweenList = [];

        for (let i = 0; i < this.itemCount; i++)
        {
            let follower = this.followerPool.Get();
            follower.CachedTransform.setParent(this.node)//, false);
            follower.CachedTransform.position = new cc.Vec3(this.startPosition.x, this.startPosition.y);

            if (this.randRot)
            {
                follower.CachedTransform.angle = Util.getRandomFloat(0.0, 360.0);
            }

            let dist = Util.getRandomFloat(140, 200) * this.GetTargetScale().x;
            let angle = Util.getRandomFloat(0.0, 360.0);

            let x = this.itemCount > 1 ? dist * Math.cos(angle * Quaternion.Deg2Rad) : 0;
            let y = this.itemCount > 1 ?dist * Math.sin(angle * Quaternion.Deg2Rad) : 0;

            follower.currentSpreadDelay = 0.0;
            follower.currentTime = 0.0;
            
            follower.spreadStartPos = new cc.Vec2(follower.CachedTransform.position.x, follower.CachedTransform.position.y);
            follower.spreadEndPos = new cc.Vec2(follower.CachedTransform.position.x + x, follower.CachedTransform.position.y + y);            

            follower.spreadDuration = 1.1;
            follower.spreadDelay = 0.13 + (i * 0.07);
            follower.moveDuration = this.moveDuration;

            follower.CachedTransform.setScale(new cc.Vec3(startScale, startScale * this.GetTargetScale().x, 1)); //local
            this.followerList.push(follower);
        }

        let isFirstItemArrived: boolean = false;
        let firstItemArrivedTime: number = Time.time;

        this.OnBegin();

        let onceTween: boolean[] = new Array(this.itemCount);

        for (let i = 0; i < this.itemCount; i++)
        {
            onceTween[i] = false;
        }

        while (true)
        {
            let deltaTime: number = Time.deltaTime;
            let isComplete: boolean = true;

            for (let i = 0; i < this.itemCount; i++)
            {
                let follower = this.followerList[i];

                if (follower == null || follower.node.activeInHierarchy == false)
                {
                    continue;
                }

                if (follower.node.getChildByName("Target") != null)
                {
                    follower.node.getChildByName("Target").opacity = 255;

                    if (follower.node.getChildByName("Target").getComponent(cc.ParticleSystem3D) != null)
                    {
                        follower.node.getChildByName("Target").getComponent(cc.ParticleSystem3D).play();
                    }
                }

                isComplete = false;

                if (this.useSpread == true && follower.currentSpreadDelay < follower.spreadDelay)
                {
                    follower.currentTime += deltaTime;

                    if (follower.currentTime >= follower.spreadDuration)
                    {
                        follower.currentTime = follower.spreadDuration;
                    }

                    let targetTime: number = follower.currentTime / follower.spreadDuration;

                    let tx: number = this.EaseOutExpo(follower.spreadStartPos.x, follower.spreadEndPos.x, targetTime);
                    let ty: number = this.EaseOutExpo(follower.spreadStartPos.y, follower.spreadEndPos.y, targetTime);
                    follower.CachedTransform.setPosition(new cc.Vec3(tx, ty));

                    follower.currentSpreadDelay += deltaTime;

                    if (follower.currentSpreadDelay >= follower.spreadDelay)
                    {
                        follower.currentTime = 0.0;
                    }
                }
                else
                {
                    // return;
                    if (follower.currentTime == follower.moveDuration)
                    {
                        if (follower.node.getChildByName("Target") != null)
                        {
                            if (follower.node.getChildByName("Target").getComponent(cc.ParticleSystem3D) != null)
                            {
                                follower.node.getChildByName("Target").getComponent(cc.ParticleSystem3D).clear();
                            }
                            follower.node.getChildByName("Target").opacity = 0;
                        }
                        this.followerPool.Return(follower);
                        this.followerList[i] = null;

                        if (isFirstItemArrived == false)
                        {
                            isFirstItemArrived = true;
                            firstItemArrivedTime = Time.time;

                            this.OnFirstArrived();
                        }

                        if (this.onItemArrived != null)
                        {
                            this.onItemArrived?.call(this);
                        }
                    }
                    else
                    {
                        follower.currentTime += deltaTime;

                        if (follower.currentTime >= follower.moveDuration)
                        {
                            follower.currentTime = follower.moveDuration;
                        }

                        let targetTime: number = follower.currentTime / follower.moveDuration;

                        let targetPos = this.path.path.GetPointAtTime(targetTime, EndOfPathInstruction.Stop);

                        if (this.autoRatation == AutoRotationType.Path)
                        {
                            let targetRot = cc.Vec3.ZERO;
                            this.path.path.GetRotation(targetTime, EndOfPathInstruction.Stop).toEuler(targetRot);

                            if (this.twoDMode == true)
                            {
                                let tz: number = targetRot.x;
                                targetRot = follower.CachedTransform.eulerAngles;
                                targetRot.z = tz;
                            }

                            follower.CachedTransform.eulerAngles = targetRot;
                        }
                        else if (this.autoRatation == AutoRotationType.Zero)
                        {
                            if (!onceTween[i])
                            {
                                let tween = cc.tween(follower.CachedTransform).to(follower.moveDuration, { angle: 0 }).start();
                                this.followerTweenList.push(tween);
                                onceTween[i] = true;
                            }
                        }

                        let tx: number = this.EaseInCirc(follower.CachedTransform.position.x, targetPos.x, targetTime);
                        let ty: number = this.EaseInCirc(follower.CachedTransform.position.y, targetPos.y, targetTime);

                        follower.CachedTransform.setPosition(new cc.Vec3(tx, ty));

                        // let nTime:number = targetTime;
                        // if(nTime >= 1)
                        //     nTime = 1-0.0001; 

                        let scale: number = this.sizeOverLifetime.evaluate(targetTime);
                        let targetScale = this.GetTargetScale();
                        follower.CachedTransform.setScale(new cc.Vec3(scale * targetScale.x, scale * targetScale.y, 1.0));
                    }
                }
            }

            yield;

            if (isComplete == true)
            {
                break;
            }
        }

        while (Time.time - firstItemArrivedTime < this.firstArrivedEffectDuration)
        {
            yield;
        }
        yield;
    }

    private EaseOutExpo(start: number, end: number, value: number): number
    {
        end -= start;
        return end * (-Math.pow(2, -10 * value) + 1) + start;
    }

    private EaseInCirc(start: number, end: number, value: number): number
    {
        end -= start;
        return -end * (Math.sqrt(1 - value * value) - 1) + start;
    }

    protected OnStop(): void
    {
        for (let i = 0; i < this.followerList.length; i++)
        {
            let follower = this.followerList[i];
            if (follower != null)
            {
                this.followerPool.Return(follower);
            }
        }
    }

    private OnFirstArrived(): void
    {
        if (this.onFirstItemArrived != null)
        {
            this.onFirstItemArrived();
        }

        if (this.firstArrivedSFX != null)
        {
            this.firstArrivedSFX.Play();
        }

        if (this.firstArrivedEffect != null)
        {
            this.firstArrivedEffect.position = new cc.Vec3(this.endPosition.x, this.endPosition.y);
            this.firstArrivedEffect.opacity = 255;
            //this.firstArrivedEffect.active = true;
            this.firstArrivedParticle.play();
        }
    }

    private OnBegin(): void
    {
        if (this.onBegin != null)
        {
            this.onBegin();
        }
    }
}
