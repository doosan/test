import CoroutineComponent from "../System/CoroutineComponent";
import { Util } from "../Util/Util";
import { AssetBundleLoadType } from "./AssetBundleLoadType";
import AssetBundleSystem from "./AssetBundleSystem";

export class AssetBundleLoaderData
{
    public isSuccess: boolean;
    public loadType: AssetBundleLoadType;
    public assetBundleName: string;
    public url: string;
    //public Hash128 hash;
    public version: number;
    public assetNames: string[];
    public enableVersionManagement: boolean;
    public assetBundle: cc.AssetManager.Bundle;

    public IsValidHash(): boolean
    {
        return this.enableVersionManagement == true; // && hash != default(Hash128);
    }

    public IsValidVersion(): boolean
    {
        return this.enableVersionManagement == true && this.version > -1;
    }
}

// AssetBundleSystem에서만 사용한다.
export default class AssetBundleLoader
{
    private owner: CoroutineComponent;
    private data: AssetBundleLoaderData = null;
    private onStart: Function = null;
    private onLoadComplete: Function = null;
    private onLoadProgress: Function = null;
    private isLoading: boolean;
    private isAbort: boolean;

    constructor(loadType: AssetBundleLoadType, owner: CoroutineComponent, url: string, assetBundleName: string, version: number = -1) //Hash128 hash = default(Hash128))
    {
        this.owner = owner;
        this.data = new AssetBundleLoaderData();
        this.data.loadType = loadType;
        this.data.assetBundleName = assetBundleName;
        this.data.url = url;
        //this.data.hash = hash;
        this.data.version = version;
        this.data.enableVersionManagement = false;
    }

    public Load(preLoad: boolean = false): AssetBundleLoader
    {
        //cc.log("AssetBundleLoader:Load() IN");

        if (this.isLoading == true)
        {
            //cc.log("[AssetBundleLoader] Already running.");
            return this;
        }

        this.isAbort = false;
        this.owner.startCoroutine(this.LoadAssetBundle(this.data, preLoad), this.owner);

        return this;
    }

    public OnStart(onLoadStart: Function): AssetBundleLoader
    {
        this.onStart = onLoadStart;
        return this;
    }

    public OnProgress(onLoadProgress: Function): AssetBundleLoader
    {
        this.onLoadProgress = onLoadProgress;
        return this;
    }

    public OnComplete(onLoadComplete: Function): AssetBundleLoader
    {
        this.onLoadComplete = onLoadComplete;
        return this;
    }

    public Abort(): AssetBundleLoader
    {
        this.isAbort = true;
        return this;
    }

    *LoadAssetBundle(loadData: AssetBundleLoaderData, preLoad: boolean = false)
    {
        //cc.log("AssetBundleLoader:LoadAssetBundle() IN");

        this.isLoading = true;
        let cached: boolean = false;

        yield this.LoadCoroutine(this.data, preLoad);     

        if (this.onStart != null)
        {
            this.onStart(loadData);
        }

        this.isLoading = false;

        if (this.onLoadProgress != null)
        {
            this.onLoadProgress(1.0);
        }

        if (this.onLoadComplete != null) 
        {
            this.onLoadComplete(this.data);
        }
    }

    *LoadCoroutine(loadData: AssetBundleLoaderData, preLoad: boolean = false)
    {
        yield Util.waitForPromise(this.GetLoadBundle(loadData, preLoad), this.owner);
    }
    
    async GetLoadBundle(loadData: AssetBundleLoaderData, preLoad: boolean = false): Promise<cc.AssetManager.Bundle>
    {
        let url = loadData.url + loadData.assetBundleName;

        //cc.log("AssetBundleLoader:GetLoadBundle() : " + url);
        
        return new Promise((resolve, reject) =>
        {
            // 에셋 번들 로드
            cc.assetManager.loadBundle(url, { version: AssetBundleSystem.Instance.GetBundleMd5(loadData.assetBundleName) }, (err, bundle) => 
            {
                //cc.log("AssetBundleLoader:GetLoadBundle() 로드완료 : " + loadData.assetBundleName);

                if (err == null)
                {
                    loadData.assetBundle = bundle;
                    loadData.isSuccess = true;                    

                    resolve(bundle);                    
                }
                else
                {
                    AssetBundleSystem.Instance.OnLoadFail?.(loadData);
                    loadData.isSuccess = false;
                    resolve(null);
                }
            });
        });
    }    
}