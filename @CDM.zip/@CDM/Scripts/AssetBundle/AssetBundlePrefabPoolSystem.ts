import GameObjectPool from "../ObjectPool/GameObjectPool";
import CoroutineComponent from "../System/CoroutineComponent";
import SingleObjects from "../System/SingleObjects";
import AssetBundle from "./AssetBundle";
import { AssetBundleLoadType } from "./AssetBundleLoadType";
import AssetBundlePrefabPoolRoot from "./AssetBundlePrefabPoolRoot";
import AssetBundleSystem from "./AssetBundleSystem";

const { ccclass, property } = cc._decorator;

@ccclass
export default class AssetBundlePrefabPoolSystem<K extends cc.Component> extends CoroutineComponent
{
    static instance: AssetBundlePrefabPoolSystem<cc.Component>;

    static Instance<K extends cc.Component>(c: { new(): K }): AssetBundlePrefabPoolSystem<cc.Component>
    {
        if (AssetBundlePrefabPoolSystem.instance != null)
        {
            return AssetBundlePrefabPoolSystem.instance;
        }

        let newNode = new cc.Node("AssetBundleSystem");
        AssetBundlePrefabPoolSystem.instance = newNode.addComponent(AssetBundlePrefabPoolSystem);
        cc.game.addPersistRootNode(newNode);
        newNode.setParent(SingleObjects.Instance.node);
        this.k = c;
        return AssetBundlePrefabPoolSystem.instance;
    }

    private static k : any = null
    private pool: GameObjectPool<K> = null;
    private poolRoot: cc.Node = null;

    public Get(parent: cc.Node = null): K
    {
        let benefitsButton = this.pool.Get();
        if (parent != null)
        {
            benefitsButton.node.setParent(parent);
        }

        return benefitsButton;
    }

    public Return(benefitsButton: K)
    {
        this.pool.Return(benefitsButton);
    }

    public LoadPool(url: string, assetBundleName: string, prefabName: string, poolCount: number, onComplete: Function, onProgress: Function)
    {
        if (this.pool == null)
        {
            AssetBundleSystem.Instance.Load(
                AssetBundleLoadType.Load,
                url,
                assetBundleName,
                false,
                (success, assetBundle) =>
                {
                    if (success)
                    {
                        this.SetupPool(assetBundle, prefabName, poolCount);
                    }

                    onComplete?.(success);
                },
                progress =>
                {
                    let progressVal = Math.trunc(progress * 100.0);
                    onProgress?.(progressVal);
                }
            );
        }
        else
        {
            onProgress?.(100);
            onComplete?.(true);
        }
    }
    preBenefitsButton: cc.Prefab;
    private SetupPool(assetBundle: AssetBundle, prefabName: string, poolCount: number)
    {
        if (this.pool == null)
        {
            return;
        }

        assetBundle.GetGameObject(prefabName, true, result =>
        {
            if (this.pool == null)
            {
                this.preBenefitsButton = result;
                this.poolRoot = new cc.Node(prefabName + "Pool");
                this.poolRoot.setParent(AssetBundlePrefabPoolRoot.Instance.node);

                //Debug.Log($"==== SetupPool 1 : {prefabName}, {typeof(K).ToString()}");

                this.pool = new GameObjectPool<K>(
                    this.poolRoot,
                    poolCount,
                    () =>
                    {
                        return cc.instantiate(this.preBenefitsButton).getComponent(AssetBundlePrefabPoolSystem.k);
                    }
                );
            }
        });
    }
}