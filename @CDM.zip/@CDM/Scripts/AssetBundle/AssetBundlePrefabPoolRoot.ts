import CoroutineComponent from "../System/CoroutineComponent";
import SingleObjects from "../System/SingleObjects";

const { ccclass, property } = cc._decorator;

@ccclass
export default class AssetBundlePrefabPoolRoot extends CoroutineComponent
{
    static instance: AssetBundlePrefabPoolRoot;

    static get Instance(): AssetBundlePrefabPoolRoot
    {
        if (AssetBundlePrefabPoolRoot.instance != null)
        {
            return AssetBundlePrefabPoolRoot.instance;
        }

        let newNode = new cc.Node("AssetBundlePrefabPoolRoot");
        AssetBundlePrefabPoolRoot.instance = newNode.addComponent(AssetBundlePrefabPoolRoot);
        cc.game.addPersistRootNode(newNode);
        newNode.setParent(SingleObjects.Instance.node);

        return AssetBundlePrefabPoolRoot.instance;
    }
}