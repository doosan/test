export enum AssetBundleLoadType
{
    Load,
    DownloadOnly
}