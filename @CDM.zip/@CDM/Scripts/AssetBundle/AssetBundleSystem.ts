import SingleObjects from "../System/SingleObjects";
import CoroutineComponent from "../System/CoroutineComponent";
import InstanceEvent from "../System/InstanceEvent";
import AssetBundle from "./AssetBundle";
import AssetBundleLoader, { AssetBundleLoaderData } from "./AssetBundleLoader";
import { AssetBundleLoadType } from "./AssetBundleLoadType";

const { ccclass, property } = cc._decorator;

export class AssetBundleInfo
{
    public name: string;
    public assetBundle: AssetBundle;
    public originalAssetBundle: cc.AssetManager.Bundle;
}

export enum VersionManagementType
{
    None,
    Hash,
    Version
}

@ccclass
export default class AssetBundleSystem extends CoroutineComponent
{
    static instance: AssetBundleSystem;

    static get Instance(): AssetBundleSystem
    {
        if (AssetBundleSystem.instance != null)
        {
            return AssetBundleSystem.instance;
        }

        let newNode = new cc.Node("AssetBundleSystem");
        AssetBundleSystem.instance = newNode.addComponent(AssetBundleSystem);
        cc.game.addPersistRootNode(newNode);
        newNode.setParent(SingleObjects.Instance.node);

        return AssetBundleSystem.instance;
    }

    public OnStart: InstanceEvent = new InstanceEvent();
    public OnSuccess: InstanceEvent = new InstanceEvent();
    public OnFail: InstanceEvent = new InstanceEvent();

    public OnVersionChanged: InstanceEvent = new InstanceEvent();
    public DevelopMode: boolean;

    private version: string = '0000000000';

    public get Version(): string
    {
        return this.version;
    }
    public set Version(value)
    {
        this.version = value;
    }
    public BundleVersion: string = '';

    private assetBundleInfos: Map<string, AssetBundleInfo>;     // 번들 로드가 완료되면 리스트에 추가한다.
    private assetBundleLoaders: Map<string, AssetBundleLoader>; // 번들 로드시에 등록하고 로드가 완료되면 리스트에서 삭제한다.

    private LoadCompleteWaitCallback: Map<string, Function>;    // 로드가 완료되면 Pass되었던 함수를 다시 호출해준다.(Wait가 안 끝날 수가 있어서...)

    public get AssetBundleInfos(): Map<string, AssetBundleInfo>
    {
        return this.assetBundleInfos;
    }

    public get AssetBundleLoaders(): Map<string, AssetBundleLoader>
    {
        return this.assetBundleLoaders;
    }

    public bundleMd5 = null;

    private initOnce: boolean = false;
    private onLoadFail: Function = null;

    public get OnLoadFail(): Function
    {
        return this.onLoadFail;
    }
    public set OnLoadFail(value)
    {
        this.onLoadFail = value;
    }

    public GetBundleMd5(str: string): string
    {
        if (this.bundleMd5 == null)
        {
            return '';
        }
        else
        {
            return this.bundleMd5[str];
        }
    }

    async Initialize(developMode: boolean, onLoadFail?: Function): Promise<void>// streamingAssetBundles : StreamingAssetBundles = null) : void
    {
        if (this.initOnce) 
        {
            return;
        }
        this.initOnce = true;
        this.OnLoadFail = onLoadFail;

        this.DevelopMode = developMode;
        this.assetBundleInfos = new Map<string, AssetBundleInfo>();
        this.assetBundleLoaders = new Map<string, AssetBundleLoader>();

        this.LoadCompleteWaitCallback = new Map<string, Function>();
    }

    // version 값이 0보다 작으면 hash로 로드함.
    Load(loadType: AssetBundleLoadType,
        //versionManagementType : VersionManagementType,
        url: string,
        assetBundleName: string,
        preLoad: boolean = false,
        onLoadComplete: Function = null,
        onLoadProgress: Function = null,
        onLoadCompleteWaitCallback: Function = null): void
    {
        // Debug.LogFormat("[AssetBundleSystem] Load. '{0}' isStreaming: '{1}' isRemote: '{2}' loadType: {3} versionMangeType: {4}\nurl: '{5}'",
        //                 assetBundleName,IsStreamingAsset(assetBundleName), IsRemoteAsset(assetBundleName), loadType, versionManagementType, url);

        // 로드 중이면 패스한다. 단, 완료시 Callback을 받고 싶으면 onLoadCompleteWaitCallback에 값을 등록한다.
        if (this.assetBundleLoaders.has(assetBundleName) == true)
        {
            // Load가 완료되면 Callback함수를 다시 호출해준다.
            if (null != onLoadCompleteWaitCallback)
            {
                this.LoadCompleteWaitCallback.set(assetBundleName, onLoadCompleteWaitCallback);
            }
            return;
        }

        // 로드한게 있으면 로드한 값을 사용한다.
        if (this.assetBundleInfos.has(assetBundleName) == true)
        {
            let info = this.assetBundleInfos.get(assetBundleName);

            onLoadComplete(true, info.assetBundle);
            return;
        }

        let loader: AssetBundleLoader = null;

        loader = new AssetBundleLoader(loadType,
            this,
            url,
            assetBundleName);


        loader
            .OnStart(data =>
            {
                if (this.OnStart != null)
                {
                    this.OnStart.Invoke(data.url, false);
                }
            })
            .OnProgress(progress =>
            {
                if (onLoadProgress != null)
                {
                    onLoadProgress(progress);
                }
            })
            .OnComplete(data =>
            {
                AssetBundleSystem.Instance.OnLoadCompleteHandler(data);

                let completeEvent = data.isSuccess ? this.OnSuccess : this.OnFail;
                if (completeEvent != null)
                {
                    completeEvent.Invoke(data.url);
                }

                let ab: AssetBundle = null;

                if (data.isSuccess)
                {
                    if (AssetBundleSystem.Instance.IsLoadComplete(assetBundleName) == true)
                    {
                        ab = AssetBundleSystem.Instance.GetLoadedAssetBundle(assetBundleName);
                    }
                }

                if (onLoadComplete != null)
                {
                    onLoadComplete(data.isSuccess, ab);
                }

            })
            .Load(preLoad);
        this.assetBundleLoaders.set(assetBundleName, loader);
    }

    public Unload(assetBundleName: string, unloadAllLoadedObjects: boolean = true): void
    {
        if (this.IsLoadComplete(assetBundleName) == false)
        {
            return;
        }

        var info = this.assetBundleInfos.get(assetBundleName);
        if (info.originalAssetBundle != null)
        {
            cc.assetManager.removeBundle(info.originalAssetBundle);
        }

        this.assetBundleInfos.delete(assetBundleName);
    }

    public OnLoadCompleteHandler(data: AssetBundleLoaderData): void
    {
        this.assetBundleLoaders.delete(data.assetBundleName);

        if (data.isSuccess)
        {
            var assetBundleInfo = this.CreateAssetBundleInfo(data);
            this.assetBundleInfos.set(data.assetBundleName, assetBundleInfo);
        }

        // 번들에 해당하는 Callback받을 함수가 있는지 체크한다.
        if (this.LoadCompleteWaitCallback.has(data.assetBundleName) == true)
        {
            let callback = this.LoadCompleteWaitCallback.get(data.assetBundleName);
            if (null != callback)
            {
                callback();
            }

            this.LoadCompleteWaitCallback.delete(data.assetBundleName);
        }
    }

    private CreateAssetBundleInfo(data: AssetBundleLoaderData): AssetBundleInfo
    {
        var bundle = new AssetBundle(this, data.assetBundleName, data.assetBundle, this.DevelopMode);

        let loadInfo: AssetBundleInfo = new AssetBundleInfo();
        loadInfo.name = data.assetBundleName;
        loadInfo.originalAssetBundle = data.assetBundle;
        //loadInfo.hash = data.hash;
        loadInfo.assetBundle = bundle;

        return loadInfo;
    }

    public IsLoadComplete(assetBundleName: string): boolean
    {
        return this.assetBundleInfos.has(assetBundleName);
    }

    public GetLoadedAssetBundle(assetBundleName: string): AssetBundle
    {
        if (this.IsLoadComplete(assetBundleName) == false)
        {
            return null;
        }

        var loadInfo = this.assetBundleInfos.get(assetBundleName);
        return loadInfo.assetBundle;
    }
}