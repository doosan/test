import GlobalData from "../../../Scripts/GlobalData";
import CoroutineComponent  from "../System/CoroutineComponent";
import { Util } from "../Util/Util";

export default class AssetBundle
{
    private readonly DIR_SEPARATOR: string = "/";

    public Name: string;   

    private assets: Map<string, string>;
    private developMode: boolean;
    public assetBundle: cc.AssetManager.Bundle; //singleton
    private owner: CoroutineComponent;

    //Hash128 hash
    constructor(owner: CoroutineComponent, name: string, assetBundle: cc.AssetManager.Bundle, developMode: boolean)
    {
        this.owner = owner;
        this.Name = name;
        this.developMode = developMode;
        this.assetBundle = assetBundle;

        this.assets = new Map<string, string>();   
    }

    // AssetBundle의 데이터를 Load해서 Callback으로 리턴해 준다.
    private GetObject<T extends cc.Asset>(assetName: string, LoadAsyncCallback: Function = null): T
    {
        let asset: T = null;
        this.owner.startCoroutine(this.LoadAsyncCoroutine<T>(this.assetBundle, assetName, LoadAsyncCallback), this.owner);

        return asset;
    }
   
    *LoadAsyncCoroutine<T extends cc.Asset>(assetBundle: cc.AssetManager.Bundle, path: string, LoadAsyncCallback: Function)
    {       
        yield Util.waitForPromise<T>(this.LoadFromBundle<T>(assetBundle, path, LoadAsyncCallback), this.owner);
    }
 
    // 번들로부터 데이터를 로드한다.
    async LoadFromBundle<T extends cc.Asset>(assetBundle: cc.AssetManager.Bundle, fileName: string, LoadAsyncCallback: Function) : Promise<T>
    {
        return new Promise((resolve, reject) =>
        {
            assetBundle.load<T>(fileName, (err, result : T) =>
            {
                if (err == null)
                {              
                    LoadAsyncCallback(result);
                    resolve(result);
                }
                else
                {
                    LoadAsyncCallback(null);
                    resolve(null);
                }
            });
        });
    }

    // 번들데이터에서 Prefab을 실제 로드한다.
    public GetGameObject(bundleName: string, instantiate?: boolean, onComplete? : Function) : void;
    public GetGameObject(bundleName: string, parent: cc.Node, onComplete? : Function) : void;
    public GetGameObject(bundleName: string, param?: any, onComplete? : Function) : void
    {
        if (param instanceof cc.Node)
        {
            this.GetObject<cc.Prefab>(bundleName, (obj)=>
            {
                if (obj == null)
                {
                    onComplete?.(null);
                }
                else
                {
                    let oj : cc.Node = cc.instantiate(obj);
                    oj.setParent(param);
                    onComplete?.(oj);
                    
                }
            });            
        }
        else 
        {
            let instantiate: boolean = true;
            if (param != null)
            {
                instantiate = param;
            }
            
            this.GetObject<cc.Prefab>(bundleName, (obj)=>
            {
                if (obj == null)
                {
                    return null;
                }
                
                onComplete?.(instantiate ? cc.instantiate(obj) : obj);
                
            });
        }
    }
    public GetSprite(atlasName : string, name : string, onComplete? : Function)
    {
        {
            this.GetObject<cc.Texture2D>(name, (obj : cc.Texture2D)=>
            {
                if (obj == null)
                {
                    return null;
                }
    
                if(onComplete!=null)
                {
                    onComplete(new cc.SpriteFrame(obj), name);
                }
            });
        }
    }

    public GetAtlas(atlasName : string, onComplete? : Function)
    {        
        this.GetObject<cc.SpriteAtlas>(atlasName, (obj : cc.SpriteAtlas)=>
        {
            if (obj == null)
            {                    
                onComplete(null);
            }
            else if(onComplete!=null)
            {                    
                onComplete(obj);
            }
        });
    }


    // 번들데이터에서 SpriteFrame를 실제 로드한다.
    public GetSpriteAsync(atlasName : string, name : string, onComplete? : Function)
    {
        if(GlobalData.IsBundle)
        {
            this.GetObject<cc.SpriteAtlas>(atlasName, (obj : cc.SpriteAtlas)=>
            {
                if (obj == null)
                {                    
                    onComplete(null);
                }
                else if(onComplete!=null)
                {                    
                    onComplete(obj.getSpriteFrame(name), name);
                }
            });
        }
        else
        {
            this.GetObject<cc.Texture2D>(name, (obj : cc.Texture2D)=>
            {
                if (obj == null)
                {
                    onComplete(null);
                }
                else if(onComplete!=null)
                {
                    onComplete(new cc.SpriteFrame(obj), name);
                }
            });
        }
    }

    public ContainsAssetName(assetName : string) : boolean
    {      
        return true;
    }
}