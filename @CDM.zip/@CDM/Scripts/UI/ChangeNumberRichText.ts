import CurrencyFormatHelper from "../Util/CurrencyFormatHelper";
import StringUtils from "../Util/StringUtils";
import ChangeNumberComponent from "./ChangeNumberComponent";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("Util/ChangeNumberRichText")
export default class ChangeNumberRichText extends ChangeNumberComponent
{
    @property(cc.RichText)
    label: cc.RichText = null;

    onLoad() 
    {
        if (null == this.label)
        {
            this.label = this.getComponent(cc.RichText);
        }

        // init logic                
        if (this.label != null && typeof this.label !== "undefined")
        {
            if (this.useKMBUnit)      
            {
                this.label.string = StringUtils.ToKMBUnit(this.currentNumber, this.kiloStartingPoint, this.maxLength);
            }
            else
            {
                if (this.useComma == false)
                {
                    this.label.string = this.currentNumber.toString();
                }
                else
                {
                    this.label.string = this.useKMB ? StringUtils.ToKMB2(this.currentNumber, this.kmbOption, this.kmbMinValue) : CurrencyFormatHelper.formatNumber(this.currentNumber);
                }
            }
        }
        this.label.string = this.prefix + this.label.string + this.suffix;
    }

    setString(str: string): void
    {
        this.label.string = str;
    }

    fixNumber(num: number)
    {
        if (this == null)
        {
            return;
        }
        if (this.node == null)
        {
            return;
        }

        if (null == this.label)
        {
            this.label = this.getComponent(cc.RichText);
        }

        // this.node.stopAllActions();
        this.currentNumber = num;

        if (this._targetNode != null)
        {
            this._targetNode.setScale(num >= this._standardNumber ? cc.v2(this._targetScale, this._targetScale) : cc.v2(1, 1));
        }

        if (this.useKMBUnit)      
        {
            this.label.string = StringUtils.ToKMBUnit(this.currentNumber, this.kiloStartingPoint, this.maxLength);
        }
        else
        {
            if (this.useComma == false)
            {
                this.label.string = this.currentNumber.toString();
            }
            else
            {
                this.label.string = this.useKMB ? StringUtils.ToKMB2(this.currentNumber, this.kmbOption, this.kmbMinValue) : CurrencyFormatHelper.formatNumber(this.currentNumber);
            }
        }
        this.label.string = this.prefix + this.label.string + this.suffix;
    }
}
