import BaseListView, { BaseListItemInfo } from "./BaseListView";


const { ccclass, property } = cc._decorator;

export namespace eListView
{
    export class ListItemInfo extends BaseListItemInfo
    {
        protected rt: cc.Node;
        public get RectTransform(): cc.Node { return this.rt; }
        public get Size(): cc.Size { return this.rt.getContentSize(); }
        public get Pivot(): cc.Vec2 { return this.rt.getAnchorPoint(); }
        public get Position(): cc.Vec3 { return this.rt.position; }
        public set Position(value) { this.rt.setPosition(value); }
        public get LocalPosition(): cc.Vec3 { return this.rt.position; }
        public set LocalPosition(value) { this.rt.setPosition(value); }

        constructor(rt: cc.Node)
        {
            super();
            this.rt = rt;
        }

        public GetActive(): boolean
        {
            return this.rt.activeInHierarchy;
        }

        public SetActive(isOn: boolean, index: number): void
        {
            this.rt.active = isOn;
        }

        public SetParent(parent: cc.Node): void
        {
            this.rt.setParent(parent); //, false);
            this.rt.setPosition(cc.Vec3.ZERO);
        }

        public SetAsFirstSibling(): void
        {
            this.rt.setSiblingIndex(0);//.SetAsFirstSibling();
        }

        public SetAsLastSibling(): void
        {
            this.rt.setSiblingIndex(0);
        }

        public SetSiblingIndex(index: number): void
        {
            this.rt.setSiblingIndex(index);
        }

        public GetSiblingIndex(): number
        {
            return this.rt.getSiblingIndex();
        }
    }
}

@ccclass
export default class ListView extends BaseListView
{
    private itemDictionary: Map<cc.Node, eListView.ListItemInfo>

    public override Initialize()
    {
        if (this.IsInitialize)
        {
            return;
        }
        this.itemDictionary = new Map<cc.Node, eListView.ListItemInfo>();
        super.Initialize();
    }

    public AddItem(item: cc.Node, index?: number): void
    {
        if (index == null)
        {
            this.AddItem(item, Number.MAX_SAFE_INTEGER);
        }
        else
        {
            if (this.itemDictionary.has(item) == true)
            {
                this.RemoveItem(item, false);
                index--;
            }

            index = cc.misc.clampf(index, 0, this.itemInfoList.length);

            let info: eListView.ListItemInfo = new eListView.ListItemInfo(item);

            info.SetParent(this.content);

            info.SetActive(false, index);

            // SetDrivenRectTransform(item, DrivenTransformProperties.AnchoredPositionX 
            //                             | DrivenTransformProperties.AnchoredPositionY 
            //                             | DrivenTransformProperties.Anchors);

            this.itemInfoList.splice(index, 0, info);
            this.itemDictionary.set(item, info);

            if (this.itemInfoList.length == 1)
            {
                this.GoToFirst();
            }
        }
    }

    public RemoveItem(item: cc.Node, destroy?: boolean): number;
    public RemoveItem(index: number, destroy?: boolean): number;
    public RemoveItem(param1: any, destroy: boolean = true): number
    {
        let result = -1;
        if (param1 instanceof cc.Node)
        {
            let item = param1;
            
            if (this.itemDictionary.has(item))
            {
                var itemInfo = this.itemDictionary.get(item);
                let itemIndex: number = this.itemInfoList.findIndex(x => x == itemInfo);
                result = itemIndex;

                for (let i = 0; i < this.activeItemIndexList.length; i++)
                {
                    var activeItemIndex = this.activeItemIndexList[i];
                    if (activeItemIndex > itemIndex)
                    {
                        activeItemIndex--;
                        this.activeItemIndexList[i] = activeItemIndex;
                    }
                }

                if (this.TargetIndex > itemIndex)
                {
                    this.TargetIndex -= 1;
                }
                if (this.TargetIndex >= this.activeItemIndexList.length)
                {
                    this.TargetIndex = this.activeItemIndexList.length - 1;
                }

                this.itemDictionary.delete(item);
                this.itemInfoList.splice(itemIndex, 1);

                if (destroy == true)
                {
                    item.destroy();
                }
            }
        }
        else
        {
            let index = param1;
            if (this.itemInfoList.length == 0)
            {
                return -1;
            }

            index = cc.misc.clampf(index, 0, this.itemInfoList.length - 1);
            var item = this.itemInfoList[index] as eListView.ListItemInfo;
            this.RemoveItem(item.RectTransform, destroy);
        }
        return result;
    }

    public RemoveAllItems(destroy: boolean = true): void
    {
        while (this.itemInfoList && this.itemInfoList.length > 0)
        {
            this.RemoveItem(0, destroy);
        }
    }

    public GetItem(index: number): cc.Node
    {
        if (index < this.itemInfoList.length && index > -1)
        {
            return (this.itemInfoList[index] as eListView.ListItemInfo).RectTransform;
        }

        return null;
    }
}