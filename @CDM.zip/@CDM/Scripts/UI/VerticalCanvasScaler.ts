import GlobalData, { ePlatformType } from "../../../Scripts/GlobalData";
import PopupSystem from "../Popup/PopupSystem";
import ResizeSystem from "../System/ResizeSystem";
import ScreenSystem from "../System/ScreenSystem";
import SingleObjects from "../System/SingleObjects";

const { ccclass, property } = cc._decorator;

@ccclass
export class VerticalCanvasScaler extends cc.Component 
{
    private widget: cc.Widget = null;
    private get Widget(): cc.Widget
    {
        if (this.widget == null)
        {
            this.widget = this.getComponent(cc.Widget);
        }
        return this.widget;
    }

    onLoad() 
    {
        ScreenSystem.Instance.SetPortrait();
        ResizeSystem.Instance.AddEvent(this.screenAdapter.bind(this), this);
        this.screenAdapter();        
    }

    onDestroy()
    {
        ResizeSystem.Instance.RemoveEvent(this.screenAdapter.bind(this), this);
    }

    screenAdapter() 
    {
        let viewSize : cc.Size = cc.view.getFrameSize();
        let screenRatio = viewSize.width / viewSize.height;       

        if(ScreenSystem.IsLandscape)
        {
            let maxSize : cc.Size = new cc.Size(1560, 960);
            let designResolution : cc.Size = new cc.Size(1280, 720);
            
            let designRatio1 = designResolution.width / designResolution.height;
            let designRatio2 = designResolution.width / maxSize.height;    
            let designRatio3 = maxSize.width / designResolution.height;
    
            if (screenRatio <= designRatio2) 
            {
                cc.view.setDesignResolutionSize(designResolution.width , maxSize.height, cc.ResolutionPolicy.SHOW_ALL);
                this.Widget.updateAlignment();
            }
            else if (screenRatio < designRatio1)
            {
                cc.view.setDesignResolutionSize(designResolution.width, viewSize.width / designResolution.width * viewSize.height, cc.ResolutionPolicy.FIXED_WIDTH);
                this.Widget.updateAlignment();
            } 
            else
            {
                if(screenRatio > designRatio3)
                {
                    cc.view.setDesignResolutionSize(maxSize.width, designResolution.height, cc.ResolutionPolicy.SHOW_ALL);
                    this.Widget.updateAlignment();
                }
                else
                {
                    cc.view.setDesignResolutionSize(viewSize.width, designResolution.height, cc.ResolutionPolicy.FIXED_HEIGHT);
                    this.Widget.updateAlignment();
                    this.setFitHeight();
                }
            }
        }
        else if (GlobalData.IsFB_Mobile  && screenRatio > 1)
        {
            let maxSize: cc.Size = new cc.Size(1560, 960);
            let designResolution: cc.Size = new cc.Size(1280, 720);
            
            let designRatio1 = designResolution.width / designResolution.height;
            let designRatio2 = designResolution.width / maxSize.height;
            let designRatio3 = maxSize.width / designResolution.height;

            if (screenRatio <= designRatio2) 
            {
                cc.view.setDesignResolutionSize(designResolution.width, maxSize.height, cc.ResolutionPolicy.SHOW_ALL);
                this.Widget.updateAlignment();
            }
            else if (screenRatio < designRatio1)
            {
                cc.view.setDesignResolutionSize(designResolution.width, viewSize.width / designResolution.width * viewSize.height, cc.ResolutionPolicy.FIXED_WIDTH);
                this.Widget.updateAlignment();
            }
            else
            {
                if (screenRatio > designRatio3)
                {
                    cc.view.setDesignResolutionSize(maxSize.width, designResolution.height, cc.ResolutionPolicy.SHOW_ALL);
                    this.Widget.updateAlignment();
                }
                else
                {
                    cc.view.setDesignResolutionSize(viewSize.width, designResolution.height, cc.ResolutionPolicy.FIXED_HEIGHT);
                    this.Widget.updateAlignment();
                    this.setFitHeight();
                }
            }
        }
        else
        {
            let maxSize: cc.Size = new cc.Size(960, 1560);
            let designResolution: cc.Size = new cc.Size(720, 1280);
            
            let designRatio1 = designResolution.width / designResolution.height;
            let designRatio2 = designResolution.width / maxSize.height;
            let designRatio3 = maxSize.width / designResolution.height;

            if (screenRatio <= designRatio2) 
            {
                cc.view.setDesignResolutionSize(designResolution.width, maxSize.height, cc.ResolutionPolicy.SHOW_ALL);
                this.Widget.updateAlignment();
            }
            else if (screenRatio < designRatio1)
            {
                cc.view.setDesignResolutionSize(designResolution.width, viewSize.width / designResolution.width * viewSize.height, cc.ResolutionPolicy.FIXED_WIDTH);
                this.Widget.updateAlignment();
            }
            else
            {
                if (screenRatio > designRatio3)
                {
                    cc.view.setDesignResolutionSize(maxSize.width, designResolution.height, cc.ResolutionPolicy.SHOW_ALL);
                    this.Widget.updateAlignment();
                }
                else
                {
                    cc.view.setDesignResolutionSize(viewSize.width, designResolution.height, cc.ResolutionPolicy.FIXED_HEIGHT);
                    this.Widget.updateAlignment();
                    this.setFitHeight();
                }
            }
        }
    }

    setFitWidth() 
    {
        cc.Canvas.instance.fitHeight = false;
        cc.Canvas.instance.fitWidth = true;
    }

    setFitHeight() 
    {
        cc.Canvas.instance.fitHeight = true;
        cc.Canvas.instance.fitWidth = false;
    }
}