import GlobalData, { ePlatformType } from "../../../Scripts/GlobalData";
import ResizeSystem from "../System/ResizeSystem";
import ScreenSystem from "../System/ScreenSystem";
import SingleObjects from "../System/SingleObjects";

const { ccclass, property } = cc._decorator;

@ccclass
export class VerticalSubCanvasScaler extends cc.Component 
{
    @property restore: boolean = true;

    onLoad()
    {
        ResizeSystem.Instance.AddSubEvent(this.screenAdapter.bind(this), this);
        SingleObjects.Instance.getComponent(cc.Widget).enabled = false;
        this.screenAdapter();
    }

    onDestroy()
    {
        if (this.restore)
        {
            ScreenSystem.Instance.SetLandscape(false);
            this.node.angle = 0;
            this.node.setContentSize(cc.Canvas.instance.node.width, cc.Canvas.instance.node.height);
            ScreenSystem.Instance.ReRotate();
            SingleObjects.Instance.node.setContentSize(cc.Canvas.instance.node.width, cc.Canvas.instance.node.height);
            SingleObjects.Instance.node.setPosition(cc.Canvas.instance.node.position);
            SingleObjects.Instance.getComponent(cc.Widget).enabled = true;
        }

        ResizeSystem.Instance.RemoveSubEvent(this.screenAdapter.bind(this), this);
    }


    width: number = 0;
    height: number = 0;

    screenAdapter() 
    {
        let change: boolean = false;

        if (this.width != cc.Canvas.instance.node.width || this.height != cc.Canvas.instance.node.height)
        {
            change = true;
        }

        this.width = cc.Canvas.instance.node.width;
        this.height = cc.Canvas.instance.node.height;

        let viewSize : cc.Size = cc.view.getFrameSize();
        let screenRatio = viewSize.width / viewSize.height;

        if (ScreenSystem.IsLandscape)
        {
            this.node.angle = 0;
            this.node.setContentSize(cc.Canvas.instance.node.width, cc.Canvas.instance.node.height);
            ScreenSystem.Instance.ReRotate();
            SingleObjects.Instance.node.setContentSize(cc.Canvas.instance.node.width, cc.Canvas.instance.node.height);
            SingleObjects.Instance.node.setPosition(cc.Canvas.instance.node.position);
        }
        else if (GlobalData.IsFB_Mobile && screenRatio > 1)
        {            
            this.node.angle = 90;
            this.node.setContentSize(cc.Canvas.instance.node.height, cc.Canvas.instance.node.width);
            ScreenSystem.Instance.Rotate();
            SingleObjects.Instance.node.setContentSize(cc.Canvas.instance.node.height, cc.Canvas.instance.node.width);
            SingleObjects.Instance.node.setPosition(cc.Canvas.instance.node.position);
        }
        else
        {
            this.node.angle = 0;
            this.node.setContentSize(cc.Canvas.instance.node.width, cc.Canvas.instance.node.height);
            ScreenSystem.Instance.ReRotate();
            SingleObjects.Instance.node.setContentSize(cc.Canvas.instance.node.width, cc.Canvas.instance.node.height);
            SingleObjects.Instance.node.setPosition(cc.Canvas.instance.node.position);
        }

        if (change)
        {
            cc.view["_resizeEvent"](true);
        }
    }
}