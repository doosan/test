import { Util } from "../Util/Util";
import BaseListView from "./BaseListView";

const { ccclass, property, menu } = cc._decorator;

export enum ButtonBehaviour
{
    Prev, // 이전 아이템으로
    Next, // 다음 아이템으로
    First, // 첫번째 아이템으로
    Last // 마지막 아이템으로
}

export enum ButtonDisableType
{
    None,
    Noninteractive, // 버튼 interactble 비활성화
    InactiveGameObject // 게임 오브젝트 비활성화
}


@ccclass("ButtonInfo")
export class ButtonInfo
{
    @property(cc.Button) button: cc.Button = null;
    @property({ type: cc.Enum(ButtonBehaviour) }) behaviour: ButtonBehaviour = ButtonBehaviour.Prev;
    @property({ type: cc.Enum(ButtonDisableType) }) disableType: ButtonDisableType = ButtonDisableType.None;

    @property() overrideMoveDuration: boolean = false;

    @property({
        visible()
        {
            return this.overrideMoveDuration;
        }
    }) public moveDuration: number = 0;
}


@ccclass
export default abstract class BaseListViewControlPanel<T extends cc.Component> extends cc.Component
{
    @property className : string = "";
    @property(BaseListView) target: BaseListView = null;
    @property defaultMoveDuration: number = 0.3;

    @property() autoPageCount: boolean = false;

    @property({
        visible()
        {
            return this.autoPageCount;
        }
    }) public autoPageCountOffset: number = 0;

    @property({
        visible()
        {
            return this.autoPageCount;
        }
    }) public pageCount: number = -1;

    @property([ButtonInfo]) buttonInfoList: ButtonInfo[] = [];

    onLoad()
    {
        if (this.PreInitialize())
        {
            this.Initialize();
        }
    }

    private PreInitialize(): boolean
    {
        if (this.buttonInfoList == null)
        {
            return false;
        }

        if (this.target == null)
        {
            this.target = Util.getComponentInParentN(this.node, this.className);

            if (this.target == null)
            {
                return false;
            }
        }

        this.buttonInfoList.forEach(info=>
        {
            if (info.button != null)
            {
                info.button.node.on('click', ()=>this.OnButtonClickHandler(info), this);
            }            
        }, this);

        return true;
    }

    // 초기화
    protected abstract Initialize(): void;

    // 버튼 클릭 시 실행할 로직 처리
    protected abstract Run(buttonBehaviour: ButtonBehaviour, duration: number): void;

    // 버튼 상태 변경
    protected abstract UpdateButtons(): void;

    private OnButtonClickHandler(buttonInfo: ButtonInfo): void
    {
        var duration = buttonInfo.overrideMoveDuration ? buttonInfo.moveDuration : this.defaultMoveDuration;
        this.Run(buttonInfo.behaviour, duration);
    }

    public GoToNext(duration: number = null): void
    {
        this.Run(ButtonBehaviour.Next, duration == null ? this.defaultMoveDuration : duration);
    }

    public GoToPrev(duration: number = null): void
    {
        this.Run(ButtonBehaviour.Prev, duration == null ? this.defaultMoveDuration : duration);
    }

    public GoToFirst(duration: number = null): void
    {
        this.Run(ButtonBehaviour.First, duration == null ? this.defaultMoveDuration : duration);
    }

    public GoToLast(duration: number = null): void
    {
        this.Run(ButtonBehaviour.Last, duration == null ? this.defaultMoveDuration : duration);
    }

    protected SetActiveButton(button: cc.Button, buttonDisableType: ButtonDisableType, isOn: boolean)
    {
        if (button == null)
        {
            return;
        }

        if (buttonDisableType == ButtonDisableType.Noninteractive)
        {
            button.interactable = isOn;
            button.node.active = true;
        }
        else if (buttonDisableType == ButtonDisableType.InactiveGameObject)
        {
            button.interactable = true;
            button.node.active = isOn;
        }
    }
}