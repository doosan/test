﻿const { ccclass } = cc._decorator;

export enum LoadingType
{
    None,
    Disable,
    Purchase,
    MarbleX,
}

@ccclass
export default class BaseLoadingIndicator extends cc.Component
{
    private cachedTransform : cc.Node;
    public get IsActive() { return this.node.activeInHierarchy;}

    onLoad()
    {
        this.cachedTransform = this.node;
    }

    //public SetParent(parent : cc.Node) : void
    public SetParent(parent : cc.Node, localPos? : cc.Vec3)
    {
        if(localPos == null)
        {
            this.cachedTransform.setParent(parent) //, false);
        }
        else
        {
            this.cachedTransform.setParent(parent)//, false);
            this.cachedTransform.setPosition(localPos); //local
        }
    }

    public SetZ(zValue : number) : BaseLoadingIndicator
    {
        let originPosition : cc.Vec3 = this.cachedTransform.position 
        this.cachedTransform.setPosition(new cc.Vec3(originPosition.x, originPosition.y, zValue)); //.localPosition
        return this;
    }

    public Show(blocksRaycast : boolean = true, type : LoadingType = LoadingType.None) : BaseLoadingIndicator
    {
        return null;
    }
    public Hide(onComplete:Function = null) : void
    {
    }
}