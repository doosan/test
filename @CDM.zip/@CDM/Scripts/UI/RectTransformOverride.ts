const {ccclass, property} = cc._decorator;

@ccclass
export default class RectTransformOverride extends cc.Component 
{
    @property(cc.Vec3) win: cc.Vec3 = cc.Vec3.ZERO;
    @property(cc.Vec3) mobile: cc.Vec3 = cc.Vec3.ZERO;

    onLoad () 
    {
        this.node.setPosition(cc.sys.isMobile ? this.mobile : this.win);
    }
}
