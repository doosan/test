using UnityEngine;

namespace Gaga.UI
{
    [ExecuteInEditMode]
    public class SafePanelHasMaxSize : MonoBehaviour
    {
        [SerializeField] private Vector2 maxSize;
        [SerializeField] private bool onBothSides = true;

        private static SafePanel.SafeMargin customSafeMargin;
        private static bool useCustomSafeArea = false;

        private Rect latestSafeArea;

        private RectTransform CachedTransform
        { 
            get
            {
                if (cachedTransform == null)
                {
                    cachedTransform = GetComponent<RectTransform>();
                }
                return cachedTransform;
            }
        }
        private RectTransform cachedTransform;

        public static void SetCustomSafeArea(SafePanel.SafeMargin safeMargin)
        {
            customSafeMargin = safeMargin;
            useCustomSafeArea = true;
        }

        private void Update()
        {
            Rect safeArea = Screen.safeArea;
            Vector2 screenSize = new Vector2(Screen.width, Screen.height);

            if (useCustomSafeArea)
            {
                // x
                safeArea.x = customSafeMargin.left;
                safeArea.width = screenSize.x - customSafeMargin.left - customSafeMargin.right;

                if (onBothSides)
                {
                    float marginX = GetLargerMarginX(safeArea, screenSize);
                    safeArea.x = marginX;
                    safeArea.width = screenSize.x - marginX * 2.0f;
                }

                // y
                safeArea.y = customSafeMargin.bottom;
                safeArea.height = screenSize.y - customSafeMargin.top - customSafeMargin.bottom;

                if (onBothSides)
                {
                    float marginY = GetLargerMarginY(safeArea, screenSize);
                    safeArea.y = marginY;
                    safeArea.height = screenSize.y - marginY * 2.0f;
                }
            }

            Rect prevSafeArea = safeArea;
            if (maxSize.x != 0
                && safeArea.width > maxSize.x)
            {
                safeArea.width = maxSize.x;
            }
            if (maxSize.y != 0
                && safeArea.height > maxSize.y)
            {
                safeArea.height = maxSize.y;
            }

            if (latestSafeArea != safeArea)
            {
                latestSafeArea = safeArea;
                CachedTransform.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, safeArea.width);
                Debug.Log($"==== Update : {prevSafeArea} -> {safeArea}");
            }
        }

        private float GetLargerMarginX(Rect safeArea, Vector2 screenSize)
        {
            var margin1 = safeArea.x;
            var margin2 = screenSize.x - (safeArea.x + safeArea.width);
            return margin1 > margin2 ? margin1 : margin2;
        }

        private float GetLargerMarginY(Rect safeArea, Vector2 screenSize)
        {
            var margin1 = safeArea.y;
            var margin2 = screenSize.y - (safeArea.y + safeArea.height);
            return margin1 > margin2 ? margin1 : margin2;
        }
    }
}