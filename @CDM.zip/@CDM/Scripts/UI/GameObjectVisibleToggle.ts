const { ccclass, property, menu, requireComponent } = cc._decorator;

export enum GameObjectVisibleToggleType
{
    Couple,
    Multiple
}

@ccclass
@menu("UI/GameObjectVisibleToggle")
export default class GameObjectVisibleToggle extends cc.Component
{
    public get IsOn() : boolean
    {
        return this.isOn;
    }
    public set IsOn(value: boolean)
    {
        this.isOn = value;

        this.UpdateVisibleInCouple();
    }

    public get ActiveName(): string
    {
        let result: string = "";
        for (let i = 0; i < this.targets.length; i++)
        {
            if (this.targets[i].activeInHierarchy)
            {
                result = this.targets[i].name;
                break;
            }
        }

        return result;
    }
    
    @property({ type: cc.Enum(GameObjectVisibleToggleType) })    type: GameObjectVisibleToggleType = GameObjectVisibleToggleType.Couple;
    @property(cc.Node) offTarget: cc.Node = null;
    @property(cc.Node) onTarget: cc.Node = null;
    @property private isOn: boolean = false;
    @property([cc.Node]) targets: cc.Node[] = [];
    @property targetName: string = "";

    public get Count(): number
    {
        return this.targets.length;
    }

    public get ActiveObject(): cc.Node
    {
        let result: cc.Node = null;

        for (let i = 0; i < this.targets.length; i++)
        {
            let target: cc.Node = this.targets[i];
            if (target.active == true)
            {
                result = target;
                break;
            }
        }

        return result;
    }

    //public GetActiveComponent<T extends cc.Component>(): cc.Component // : MonoBehaviour
    public GetActiveComponent<T extends cc.Component>(type: { prototype: T }): cc.Component // : MonoBehaviour
    {
        let activeComponent:T = null;
        let activeObject = this.ActiveObject;
        if (activeObject != null)
        {
            activeComponent = activeObject.getComponent(type);
        }

        return activeComponent;
    }

    //#if UNITY_EDITOR
    //[SerializeField, HideInInspector] private bool foldout = true;
    //#endif
    //        #pragma warning restore 0649
    //        #pragma warning disable 0414

    public UpdateVisibleInCouple(): void
    {
        if (this.onTarget != null)
        {
            this.onTarget.active = (this.isOn == true);
        }

        if (this.offTarget != null)
        {
            this.offTarget.active = (this.isOn == false);
        }
    }

    public TurnOnByIndexInMultiple(index: number): void
    {
        if (index >= this.targets.length)
        {
            return;
        }

        for (let i = 0; i < this.targets.length; i++)
        {
            let target: cc.Node = this.targets[i];
            if (target == null) 
                continue;

            target.active = (i == index);
        }
    }

    public TurnOnByNameInMultiple(name: string): void
    {
        for (let i = 0; i < this.targets.length; i++)
        {
            let target: cc.Node = this.targets[i];
            if (target == null) 
                continue;

            if (target == this.node)
            {
                cc.warn("대상에 자기 자신이 포함되어 있습니다.");
                continue;
            }

            target.active = (target.name == name);
        }
    }

    public TurnOff(): void
    {
        for (let i = 0; i < this.targets.length; i++)
        {
            let target: cc.Node = this.targets[i];
            if (target == null) 
                continue;

            target.active = (false);
        }
    }
}