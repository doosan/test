using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using DG.Tweening;

namespace Gaga.UI
{
    public class ScrollRectControlPanel : BaseListViewControlPanel<ScrollRect>
    {
        private readonly float ACTIVE_OFFSET_RATE = 0.005f;

        private int currentItemIndex;
        private HorizontalLayoutGroup horizontalLayoutGroup;
        private VerticalLayoutGroup verticalLayoutGroup;

        private class DragEventListener : MonoBehaviour, IBeginDragHandler, IEndDragHandler
        {
            public Action<bool> onDrag;
            public bool IsDrag { get; private set; }

            public void OnBeginDrag(PointerEventData eventData)
            {
                IsDrag = true;
                onDrag?.Invoke(IsDrag);
            }

            public void OnEndDrag(PointerEventData eventData)
            {
                IsDrag = false;
                onDrag?.Invoke(IsDrag);
            }
        }

        protected override void Initialize()
        {
            currentItemIndex = -1;

            horizontalLayoutGroup = target.content.GetComponent<HorizontalLayoutGroup>();
            verticalLayoutGroup = target.content.GetComponent<VerticalLayoutGroup>();

            var dragEventListener = target.gameObject.AddComponent<DragEventListener>();
            dragEventListener.onDrag = isDrag =>
            {
                Debug.Log("ScrollRectControlPanel - reset currentItemIndex");
                currentItemIndex = -1;
                target.DOKill(false);
            };
        }

        protected override void Run(ButtonBehaviour buttonBehaviour, float duration = 0.3f)
        {
            Debug.Log($"ScrollRectControlPanel - Run : {buttonBehaviour.ToString()} ({duration})");

            if (target == null
                || target.enabled == false
                || target.content.childCount == 0)
            {
                return;
            }

            if (buttonBehaviour == ButtonBehaviour.Prev || buttonBehaviour == ButtonBehaviour.Next)
            {
                var dir = buttonBehaviour == ButtonBehaviour.Prev ? -1 : 1;
                var currentPageCount = pageCount;

                if (autoPageCount)
                {
                    currentPageCount = GetActiveItemCount();
                    currentPageCount += buttonBehaviour == ButtonBehaviour.Prev ? -autoPageCountOffset : autoPageCountOffset;
                }

                if (currentPageCount < 0)
                {
                    currentPageCount = 0;
                }

                Debug.Log($"ListViewControlPanel - currentPageCount : {currentPageCount}");

                if (currentItemIndex == -1)
                {
                    var firstItemIndex = GetFirstActiveItemIndex();
                    currentItemIndex = (firstItemIndex / currentPageCount) * currentPageCount;
                }

                currentItemIndex += currentPageCount * dir;
                currentItemIndex = Mathf.Clamp(currentItemIndex, 0, target.content.childCount -1);
            }
            else if (buttonBehaviour == ButtonBehaviour.First)
            {
                currentItemIndex = 0;
            }
            else if (buttonBehaviour == ButtonBehaviour.Last)
            {
                currentItemIndex = target.content.childCount - 1;
            }

            Move(currentItemIndex, duration);

            Debug.Log($"ScrollRectControlPanel - currentItemIndex : {currentItemIndex}");
        }

        private void Move(int index, float duration)
        {
            RectTransform content = target.content;
            RectTransform viewport = target.viewport;
            RectTransform child = content.GetChild(index).GetComponent<RectTransform>();
            Vector3 childPosition = child.localPosition;

            Vector2 destinationPos;

            if (target.horizontal)
            {
                float newX = childPosition.x + child.rect.x;

                if (horizontalLayoutGroup != null)
                {
                    newX -= horizontalLayoutGroup.padding.left;
                }

                float contentWidth = content.rect.width;
                var destinationValue = Mathf.Clamp(newX / (contentWidth - viewport.rect.width), 0.0f, 1.0f);
                destinationPos = new Vector2(destinationValue, 1f);
            }
            else
            {
                float newY = child.rect.y + child.rect.y;

                if (verticalLayoutGroup != null)
                {
                    newY -= verticalLayoutGroup.padding.top;
                }

                float contentHeight = content.rect.height;
                var destinationValue = Mathf.Clamp(1f - (newY / (contentHeight - viewport.rect.height)), 0.0f, 1.0f);
                destinationPos = new Vector2(0f, destinationValue);
            }

            target.DOKill(false);
            target.DONormalizedPos(destinationPos, duration);
        }

        private int GetActiveItemCount()
        {
            var viewport = target.viewport;
            int cnt = 0;

            for (int index = 0; index < target.content.childCount; index++)
            {
                var child = target.content.GetChild(index);

                if (RectTransformUtility.RectangleContainsScreenPoint(viewport, child.position))
                {
                    cnt++;
                }
            }

            return cnt;
        }

        private int GetFirstActiveItemIndex()
        {
            var viewport = target.viewport;

            for (int index = 0; index < target.content.childCount; index++)
            {
                var child = target.content.GetChild(index);

                if (RectTransformUtility.RectangleContainsScreenPoint(viewport, child.position))
                {
                    return index;
                }
            }

            return 0;
        }

        private void Update()
        {
            UpdateButtons();
        }

        protected override void UpdateButtons()
        {
            if (target == null
                || target.content.childCount == 0
                || GetActiveItemCount() == target.content.childCount)
            {
                for (int index = 0; index < buttonInfoList.Count; index++)
                {
                    var info = buttonInfoList[index];
                    SetActiveButton(info.button, info.disableType, false);
                }

                return;
            }

            var size = target.horizontal ? target.content.rect.width : target.content.rect.height;
            var offset = (100f / size) * ACTIVE_OFFSET_RATE;

            float normalizedPositionValue = target.horizontal ? target.horizontalNormalizedPosition : target.verticalNormalizedPosition;
            bool isPrevButtonActive = normalizedPositionValue > 0.0f + offset;
            bool isNextButtonActive = normalizedPositionValue < 1.0f - offset;

            for (int index = 0; index < buttonInfoList.Count; index++)
            {
                var info = buttonInfoList[index];

                if (info.behaviour == ButtonBehaviour.First || info.behaviour == ButtonBehaviour.Prev)
                {
                    SetActiveButton(info.button, info.disableType, isPrevButtonActive);
                }
                else if (info.behaviour == ButtonBehaviour.Last || info.behaviour == ButtonBehaviour.Next)
                {
                    SetActiveButton(info.button, info.disableType, isNextButtonActive);
                }
            }
        }
    }
}