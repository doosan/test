import CurrencyFormatHelper from "../Util/CurrencyFormatHelper";
import StringUtils from "../Util/StringUtils";
import ChangeNumberComponent from "./ChangeNumberComponent";

const {ccclass, property, menu} = cc._decorator;

@ccclass
@menu("Util/ChangeNumberLabel")
export default class ChangeNumberLabel extends ChangeNumberComponent
{
    @property(cc.Label)
    label: cc.Label = null; 

    public set text(value:string )
    {
        this.setString(value);
    }

    onLoad() 
    {
        if(null == this.label)
        {
            this.label = this.getComponent(cc.Label);
        }

        if(this.isSetString)
        {
            this.isSetString = false;
            return;
        }

        //cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.OnKeyDown, this);
        // init logic                
        if (this.label != null && typeof this.label !== "undefined")
        {
            if(this.useKMBUnit)      
            {
                this.label.string = StringUtils.ToKMBUnit(this.currentNumber, this.kiloStartingPoint, this.maxLength);
            }
            else
            {
                if (this.useComma == false)
                {
                    this.label.string = this.currentNumber.toString();
                }
                else
                {                
                    this.label.string = this.useKMB ? StringUtils.ToKMB2(this.currentNumber, this.kmbOption, this.kmbMinValue) : CurrencyFormatHelper.formatNumber(this.currentNumber);
                }
            }
            this.label.string = this.prefix + this.label.string + this.suffix;
        }
    }

    setString(str : string) : void
    {
        this.isSetString = true;
        this.label.string = str;
    }

    fixNumber(num: number)
    {
        if(this == null)
        {
            return;
        }
        if(this.node == null)
        {
            return;
        }

        if(null == this.label)
        {
            this.label = this.getComponent(cc.Label);
        }
        
        // this.node.stopAllActions();
        this.currentNumber = num;

        if(this._targetNode != null)
        {
            this._targetNode.setScale(num >= this._standardNumber ? cc.v2(this._targetScale, this._targetScale) : cc.v2(1, 1));
        }

        if(this.useKMBUnit)      
        {
            this.label.string = StringUtils.ToKMBUnit(this.currentNumber, this.kiloStartingPoint, this.maxLength);
        }
        else
        {
            if (this.useComma == false)
            {
                this.label.string = num.toString();
            }
            else
            {
                this.label.string = this.useKMB ? StringUtils.ToKMB2(this.currentNumber, this.kmbOption, this.kmbMinValue) : CurrencyFormatHelper.formatNumber(num);
            }
        }

        this.label.string = this.prefix + this.label.string + this.suffix;
    }
}
