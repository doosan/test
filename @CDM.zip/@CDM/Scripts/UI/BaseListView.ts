import CoroutineComponent from "../../../@CDM/Scripts/System/CoroutineComponent";
import InstanceEvent from "../../../@CDM/Scripts/System/InstanceEvent";
import { Time } from "../../../@CDM/Scripts/Time/Time";
import EasingFunction from "../../../@CDM/Scripts/Util/EasingFunction";
import StringUtils from "../../../@CDM/Scripts/Util/StringUtils";

const { ccclass, property, requireComponent } = cc._decorator;

export namespace eBaseListView
{
    export enum Direction
    {
        Horizontal,
        Vertical
    }

    export enum Align
    {
        Default,
        Center
    }

    export enum Bounce
    {
        Clamped,
        Elastic,
        Infinity
    }

    export enum Movement
    {
        Default,
        Page
    }

    export enum SiblingOrder
    {
        None,
        First,
        Last
    }

    @ccclass("Margin")
    export class Margin
    {
        @property() up: number = 0;
        @property() down: number = 0;
        @property() left: number = 0;
        @property() right: number = 0;

        // constructor(up: number = 0, down: number = 0, left: number = 0, right: number = 0)
        // {
        //     this.up = up;
        //     this.down = down;
        //     this.left = left;
        //     this.right = right;
        // }
    }
}


@ccclass
export default abstract class BaseListView extends CoroutineComponent //UIBehaviour, IBeginDragHandler, IEndDragHandler, IDragHandler
{
    private readonly SCROLL_DELAY: number = 10;
    //private readonly DECELERATION_RATE: number = 0.3;
    private readonly ELASTIC_DECELERATION_DRAG: number = 0.55;
    private readonly ELASTIC_DECELERATION_SCROLL_OFFSET: number = 0.64;
    private readonly MAX_OFFSET_RATE: number = 0.35;

    public onTargetIndexChanged: InstanceEvent = new InstanceEvent();
    public onUpdate: InstanceEvent = new InstanceEvent();
    public onMoveItems: InstanceEvent = new InstanceEvent();
    public onDragEnd: Function = null;

    @property(cc.Camera) camera: cc.Camera = null;

    //general
    @property enableDrag: boolean = true;
    @property({ type: cc.Enum(eBaseListView.Direction) }) direction: eBaseListView.Direction = eBaseListView.Direction.Horizontal;
    @property({ type: cc.Enum(eBaseListView.Align) }) align = eBaseListView.Align.Default;
    @property(eBaseListView.Margin) margin: eBaseListView.Margin = new eBaseListView.Margin();
    @property space: number = 0.0;
    @property({ type: cc.Enum(eBaseListView.Movement) }) movement: eBaseListView.Movement = eBaseListView.Movement.Default;
    @property scrollInertia: number = 0.34;
    @property({ type: cc.Enum(eBaseListView.Bounce) }) bounce: eBaseListView.Bounce = eBaseListView.Bounce.Elastic;
    @property({ type: cc.Enum(eBaseListView.SiblingOrder) }) forceSiblingOrder: eBaseListView.SiblingOrder = eBaseListView.SiblingOrder.None;

    //bounce - elastic
    @property elasticInertia: number = 0.135;

    //movement - page
    @property pageMoveTime: number = 0.45;
    @property pageSensitivity: number = 3.0;
    protected pageScrollDir: number = 0;

    //private drivenRtTracker: DrivenRectTransformTracker;

    protected currentDirection: eBaseListView.Direction = eBaseListView.Direction.Horizontal;
    @property(cc.Node) content: cc.Node = null;
    @property(cc.Vec2) offSet: cc.Vec2 = cc.Vec2.ZERO;
    protected contentSize: cc.Vec2 = cc.Vec2.ZERO;

    @property() DECELERATION_RATE: number = 0.3;

    public get Content(): cc.Node
    {
        return this.content;
    }

    protected raycastLayer: RaycastLayer = null;

    public CachedRectTransform: cc.Node = null;
    protected itemInfoList: Array<BaseListItemInfo> = null;
    protected activeItemIndexList: Array<number> = null;

    public IsDragging: boolean = false;
    protected dragPosition: cc.Vec2 = cc.Vec2.ZERO;
    protected dragPosition2: cc.Vec2 = cc.Vec2.ZERO;
    protected dragOffset: number = 0;
    public LatestDragDirection: number = 1;

    protected scrollVelocity: number = 0;
    public scrollOffset: number = 0;

    protected moveCurrentTime: number = 0;
    protected moveTotalTime: number = 0;
    protected targetIndex: number = -1;
    static Direction: any = null;
    public get TargetIndex(): number
    {
        return this.targetIndex;
    }
    public set TargetIndex(value)
    {
        if (this.targetIndex != value)
        {
            this.targetIndex = value;
            if (this.onTargetIndexChanged != null)
            {
                this.onTargetIndexChanged.Invoke(this.targetIndex);
            }
        }
    }

    private prevMoveOffset: number = 0.0;
    private tempActiveList: Array<number>;



    public IsInitialize: boolean = false;

    onLoad()
    {
        this.Initialize();
    }

    Initialize()
    {
        //super.onLoad();
        if (this.IsInitialize)
        {
            return;
        }

        this.IsInitialize = true;

        this.LatestDragDirection = 0;

        this.currentDirection = this.direction;
        this.CachedRectTransform = this.node;

        this.itemInfoList = [];
        this.activeItemIndexList = [];

        // this.drivenRtTracker = new DrivenRectTransformTracker();
        // this.drivenRtTracker.Clear();

        this.targetIndex = -1;
        this.TargetIndex = 0;

        this.tempActiveList = [];

        this.SetupContent();
        this.SetupRaycastLayer();

        if (this.enableDrag)
        {
            this.node.on(cc.Node.EventType.TOUCH_START, this.OnBeginDrag, this, true);
            this.node.on(cc.Node.EventType.TOUCH_END, this.OnEndDrag, this, true);
            this.node.on(cc.Node.EventType.TOUCH_MOVE, this.OnDrag, this, true);
            this.node.on(cc.Node.EventType.TOUCH_CANCEL, this.OnEndDrag, this, true);
        }

        //cc.director.getPhysics3DManager().enabled = true;
        //this.LateUpdate();
    }

    onDestroy()
    {
        //super.onDestroy();        
        //this.drivenRtTracker.Clear();
    }

    private SetupContent(): void
    {
        if (this.content == null)
        {
            this.content = new cc.Node("Content");
            this.content.setParent(this.CachedRectTransform) //, false);
            this.SetDrivenRectTransform(this.content)//, DrivenTransformProperties.All);
            this.StretchToFit(this.content);
        }
    }

    private SetupRaycastLayer(): void
    {
        return;
        let raycastLayerTr = new cc.Node("RaycastLayer");
        raycastLayerTr.setParent(this.CachedRectTransform) //, false);

        //this.SetDrivenRectTransform(raycastLayerTr, DrivenTransformProperties.All);
        this.StretchToFit(raycastLayerTr);

        this.raycastLayer = raycastLayerTr.addComponent(RaycastLayer);

        //this.raycastLayer.OnDown.AddListener(this.OnRaycastLayerDown, this);

        this.RaycastLayerDescend();
    }

    private RaycastLayerAscend(): void
    {
        this.raycastLayer.node.setSiblingIndex(this.raycastLayer.node.parent.childrenCount - 1);
    }

    private RaycastLayerDescend(): void
    {
        this.raycastLayer.node.setSiblingIndex(0);
    }

    // private OnRaycastLayerDown(eventData: BaseEventData): void
    // {
    //     this.Stop();
    // }

    public Stop(): void
    {
        this.ResetValuesOfTimeForMove();

        this.scrollVelocity = 0.0;
        this.scrollOffset = 0.0;
    }

    public IsStop(): boolean
    {
        return Math.approximately(this.dragOffset, 0.0)
            && Math.approximately(this.scrollVelocity, 0.0)
            && Math.approximately(this.scrollOffset, 0.0);
    }

    public GoTo(index: number, time?: number): void
    {
        if (time == null)
        {
            this.GoTo(index, 0.0);
        }
        else
        {
            this.GoToAlign(index, this.align, time);
        }
    }

    public GoToAlign(index: number, align: eBaseListView.Align, time?: number): void
    {
        if (time == null)
        {
            this.GoToAlign(index, this.align, 0.0);
        }
        else
        {
            if (null == this.itemInfoList || this.itemInfoList.length == 0)
            {
                return;
            }

            this.Stop();

            let currentIndex: number = 0;

            if (this.bounce == eBaseListView.Bounce.Infinity)
            {
                currentIndex = this.CalculateInfinityIndex(index);
            }
            else
            {
                currentIndex = cc.misc.clampf(index, 0, this.itemInfoList.length - 1);
            }

            this.TargetIndex = currentIndex;
            this.moveTotalTime = time;
            this.moveCurrentTime = 0;

            if (time <= 0.0)
            {
                let startPosition: cc.Vec2 = cc.Vec2.ZERO;

                if (this.direction == eBaseListView.Direction.Horizontal)
                {
                    startPosition.x = this.GetStartPositionOnContent(align, this.margin);
                }
                else
                {
                    startPosition.y = this.GetStartPositionOnContent(align, this.margin);
                };

                this.RemoveAllActiveItems();
                this.SetItemsPosition(startPosition, currentIndex);

                let bounceOffset: number = this.CalculateOffsetByBounce();
                let isBounce: boolean = bounceOffset != 0.0;

                if (isBounce == true)
                {
                    this.MoveItems(bounceOffset, false, true);
                }
            }
        }
    }

    public GoToFirst(time?: number): void
    {
        if (time != null)
        {
            this.GoTo(0, time);
        }
        else
        {
            this.GoToFirst(0.0);
        }
    }

    public GoToLast(time?: number): void
    {
        if (time != null)
        {
            if (this.itemInfoList.length > 0)
            {
                this.GoTo(this.itemInfoList.length - 1, time);
            }
            else
            {
                this.GoToFirst(time);
            }
        }
        else
        {
            this.GoToLast(0.0);
        }
    }

    public GoToNextAlign(align: eBaseListView.Align, time?: number): void
    {
        if (time != null)
        {
            this.pageScrollDir = 1;
            this.GoToAlign(this.TargetIndex + 1, align, time);
        }
        else
        {
            this.GoToNextAlign(align, 0.0);
        }
    }

    public GoToNext(time?: number): void
    {
        if (time != null)
        {
            this.GoToNextAlign(this.align, time);
        }
        else
        {
            this.GoToNextAlign(this.align, 0.0);
        }
    }

    public GoToPrevAlign(align: eBaseListView.Align, time?: number): void
    {
        if (time != null)
        {
            this.pageScrollDir = -1;
            this.GoToAlign(this.TargetIndex - 1, align, time);
        }
        else
        {
            this.GoToPrevAlign(align, 0.0);
        }
    }

    public GoToPrev(time?: number): void
    {
        if (time != null)
        {
            this.GoToPrevAlign(this.align, time);
        }
        else
        {
            this.GoToPrevAlign(this.align, 0.0);
        }
    }

    protected SetDrivenRectTransform(rt: cc.Node)//, prop: DrivenTransformProperties): void
    {
        let tempWidth: number = rt.width;
        let tempHeight: number = rt.height;

        let anchor: cc.Vec2 = new cc.Vec2(0.5, 0.5);
        rt.anchorX = anchor.x;
        rt.anchorY = anchor.y;

        rt.setContentSize(tempWidth, tempHeight);

        //this.drivenRtTracker.push(this, rt, prop);
    }

    protected AddActiveItem(index: number): void
    {
        if (!this.activeItemIndexList.includes(index))
        {
            if (index < this.itemInfoList.length)
            {
                let item = this.GetItemInfo(index);
                if (item != null)
                {
                    this.activeItemIndexList.push(index);
                    item.SetActive(true, index);
                }
            }
        }
    }

    protected RemoveActiveItem(index: number): void
    {
        if (this.activeItemIndexList.includes(index))
        {
            if (index < this.itemInfoList.length)
            {
                let item = this.GetItemInfo(index);
                if (item != null)
                {
                    item.SetActive(false, index);
                }

                let ix = this.activeItemIndexList.findIndex(x => x == index);
                this.activeItemIndexList.splice(ix, 1);
            }
        }
    }

    protected RemoveAllActiveItems(): void
    {
        for (let activeIndex = 0; activeIndex < this.activeItemIndexList.length; activeIndex++)
        {
            let itemIndex: number = this.activeItemIndexList[activeIndex];
            let item = this.GetItemInfo(itemIndex);

            if (item != null)
            {
                item.SetActive(false, itemIndex);
            }
        }

        this.activeItemIndexList = [];
    }

    private RemoveAllActiveItemsAtOutsideContentBoundary(boundary: VertexPosition): void
    {
        let i: number = 0;
        while (i < this.activeItemIndexList.length)
        {
            let itemIndex: number = this.activeItemIndexList[i];
            let item = this.GetItemInfo(itemIndex);

            if (item == null)
            {
                i++;
                continue;
            }

            let itemBox: VertexPosition = new VertexPosition(item, true);

            if (this.direction == eBaseListView.Direction.Horizontal)
            {
                let spaceVector: cc.Vec2 = new cc.Vec2(this.space, 0.0);
                itemBox.rb = itemBox.rb.add(spaceVector);
                itemBox.rt = itemBox.rt.add(spaceVector);
            }
            else
            {
                let spaceVector: cc.Vec2 = new cc.Vec2(0.0, this.space);
                itemBox.lb = itemBox.lb.sub(spaceVector);
                itemBox.rb = itemBox.rb.sub(spaceVector);
            }

            if (this.AABB(itemBox, boundary) == false)
            {
                this.RemoveActiveItem(itemIndex);
            }
            else
            {
                i++;
            }
        }
    }

    public ForceUpdate()
    {
        this.lateUpdate();
    }


    lateUpdate()
    {
        if (this.currentDirection != this.direction)
        {
            this.RemoveAllActiveItems();
            this.GoToFirst();
            this.currentDirection = this.direction;
        }

        this.UpdateContentSize();

        if (this.itemInfoList.length > 0)
        {
            let boundary: VertexPosition = new VertexPosition(new cc.Vec2(this.content.position.x, this.content.position.y), this.content.getContentSize(), this.content.getAnchorPoint());
            this.RemoveAllActiveItemsAtOutsideContentBoundary(boundary);

            let bounceOffset: number = this.CalculateOffsetByBounce();
            let isBounce: boolean = bounceOffset != 0.0;

            if (this.IsEnabledMoveWithTime() == true)
            {
                this.UpdateOffsetForMoveWithTime();
            }

            if (this.IsDragging == true)
            {
                this.MoveItemsOnDragging(bounceOffset);
            }
            else if (isBounce == true && this.IsEnabledMoveWithTime() == false)
            {
                this.MoveItemsOnBounce(bounceOffset);
            }
            else
            {
                this.MoveItemsOnScrolling();

                if (this.IsEnabledMoveWithTime() == true)
                {
                    bounceOffset = this.CalculateOffsetByBounce();
                    isBounce = bounceOffset != 0.0;

                    if (isBounce == true)
                    {
                        this.Stop();
                        this.MoveItems(bounceOffset, false, true);
                    }
                }
                else
                {
                    if (this.movement == eBaseListView.Movement.Page)
                    {
                        let pageIndex: number = this.GetValidPageIndex();
                        this.GoTo(pageIndex, this.pageMoveTime);
                    }
                }

                if (this.moveCurrentTime >= this.moveTotalTime && this.moveTotalTime > 0.0)
                {
                    this.Stop();
                }
            }

            if (isBounce == false)
            {
                bounceOffset = this.CalculateOffsetByBounce();
                this.MoveItemsOnBounce(bounceOffset);
            }

            this.SetItemsPositionByFirstActiveItem();
        }

        if (this.activeItemIndexList.length == 0 && this.itemInfoList.length > 0)
        {
            this.GoToLast();
        }

        this.UpdateSiblingOrder();
        //this.UdpateLaycastLayer();
        if (this.onUpdate != null)
        {
            this.onUpdate.Invoke();
        }
    }

    public IsEnabledMoveWithTime(): boolean
    {
        return this.moveTotalTime != 0.0
            && this.moveCurrentTime < this.moveTotalTime;
    }

    private UpdateOffsetForMoveWithTime(): void
    {
        if (this.moveCurrentTime > this.moveTotalTime)
        {
            this.moveCurrentTime = this.moveTotalTime;
        }

        let startPosition: cc.Vec2 = cc.Vec2.ZERO;

        if (this.direction == eBaseListView.Direction.Horizontal)
        {
            startPosition.x = this.GetStartPositionOnContent(this.align, this.margin);
        }
        else
        {
            startPosition.y = this.GetStartPositionOnContent(this.align, this.margin);
        }

        let itemPos: number = 0.0;

        if (this.activeItemIndexList.includes(this.TargetIndex) && this.moveTotalTime > 0.0)
        {
            let itemInfo = this.GetItemInfo(this.TargetIndex);
            let itemVP: VertexPosition = new VertexPosition(itemInfo, true);

            if (this.direction == eBaseListView.Direction.Horizontal)
            {
                itemPos = itemVP.l;
            }
            else
            {
                itemPos = itemVP.t;
            }
        }
        else if (this.activeItemIndexList.length > 0)
        {
            let firstActiveIndex: number = this.activeItemIndexList[0];
            let firstActiveItemInfo = this.GetItemInfo(firstActiveIndex);
            let firstActiveItemVP = new VertexPosition(firstActiveItemInfo, true);
            let firstActiveItemSize = firstActiveItemInfo.Size;

            let indexCnt: number = 0;

            if (this.bounce == eBaseListView.Bounce.Infinity)
            {
                if (this.pageScrollDir == 1)
                {
                    if (this.targetIndex > firstActiveIndex)
                    {
                        indexCnt = Math.abs(this.targetIndex - firstActiveIndex);
                    }
                    else
                    {
                        indexCnt = Math.abs(this.itemInfoList.length - firstActiveIndex + this.targetIndex);
                    }
                }
                else if (this.pageScrollDir == -1)
                {
                    if (this.targetIndex < firstActiveIndex)
                    {
                        indexCnt = -Math.abs(this.targetIndex - firstActiveIndex);
                    }
                    else
                    {
                        indexCnt = -Math.abs(this.itemInfoList.length - this.targetIndex + firstActiveIndex);
                    }
                }
            }
            else
            {
                indexCnt = this.TargetIndex - firstActiveIndex;
            }

            if (this.direction == eBaseListView.Direction.Horizontal)
            {
                itemPos = firstActiveItemVP.l + (firstActiveItemSize.width * indexCnt);
            }
            else
            {
                itemPos = firstActiveItemVP.t - (firstActiveItemSize.width * indexCnt);
            };
        }

        this.moveCurrentTime += Time.deltaTime;

        if (this.moveCurrentTime > this.moveTotalTime)
        {
            this.moveCurrentTime = this.moveTotalTime;
        }

        let rate = this.moveCurrentTime / this.moveTotalTime;

        if (rate == 1.0)
        {
            let endPos: number = 0.0;

            if (this.direction == eBaseListView.Direction.Horizontal)
            {
                endPos = startPosition.x;
            }
            else
            {
                endPos = startPosition.y;
            }

            this.scrollOffset = endPos - itemPos;
            this.prevMoveOffset = 0.0;
        }
        else
        {
            let startPos: number = 0.0;
            let endPos: number = 0.0;

            if (this.direction == eBaseListView.Direction.Horizontal)
            {
                startPos = itemPos - this.prevMoveOffset;
                endPos = startPosition.x;
            }
            else
            {
                startPos = itemPos - this.prevMoveOffset;
                endPos = startPosition.y;
            }

            let val = EasingFunction.EaseOutQuint(startPos, endPos, rate);
            this.scrollOffset = val - (startPos + this.prevMoveOffset);
            this.prevMoveOffset += this.scrollOffset;
        }
    }

    private ResetValuesOfTimeForMove(): void
    {
        this.moveTotalTime = 0.0;
        this.moveCurrentTime = 0.0;
        this.prevMoveOffset = 0.0;
    }

    private UdpateLaycastLayer(): void
    {
        if (this.IsStop() == true)
        {
            this.RaycastLayerDescend();
        }
        else
        {
            this.RaycastLayerAscend();
        }
    }

    private UpdateSiblingOrder(): void
    {
        if (this.forceSiblingOrder != eBaseListView.SiblingOrder.None)
        {
            for (let i = 0; i < this.activeItemIndexList.length; i++)
            {
                let activeItem = this.GetItemInfo(this.activeItemIndexList[i]);

                if (this.forceSiblingOrder == eBaseListView.SiblingOrder.First)
                {
                    activeItem.SetAsFirstSibling();
                }
                else if (this.forceSiblingOrder == eBaseListView.SiblingOrder.Last)
                {
                    activeItem.SetAsLastSibling();
                }
            }
        }
    }

    private UpdateContentSize(): void
    {
        let size: cc.Vec2 = cc.Vec2.ZERO;

        let horSuccess: boolean = false;
        let verSuccess: boolean = false;

        for (let itemIndex = 0; itemIndex < this.itemInfoList.length; itemIndex++)
        {
            let item = this.GetItemInfo(itemIndex);

            if (horSuccess == false)
            {
                size.x += item.Size.width + this.space;

                if (size.x > this.content.width)
                {
                    size.x = this.content.width;
                    horSuccess = true;
                }
            }

            if (verSuccess == false)
            {
                size.y += item.Size.height + this.space;

                if (size.y > this.content.height)
                {
                    size.y = this.content.height;
                    verSuccess = true;
                }
            }

            if (horSuccess == true && verSuccess == true)
            {
                break;
            }
        }

        if (horSuccess == false)
        {
            size.x -= this.space;
        }
        if (verSuccess == false)
        {
            size.y -= this.space;
        }

        this.contentSize = size;
    }

    private MoveItemsOnDragging(bounceOffset: number): void
    {
        let isBounce: boolean = bounceOffset != 0.0;

        let offset: number = 0.0;

        if (isBounce == true)
        {
            if (this.bounce == eBaseListView.Bounce.Elastic)
            {
                let contentSize: number = 0.0;

                if (this.direction == eBaseListView.Direction.Horizontal)
                {
                    contentSize = this.content.width;
                }
                else
                {
                    contentSize = this.content.height;
                }

                offset = this.dragOffset;
                offset = 1.0 - (1.0 / ((Math.abs(offset) * this.ELASTIC_DECELERATION_DRAG / (contentSize * 1.5)) + 1.0));
                offset = offset * (contentSize * Math.sign(this.dragOffset));

                let decelerationOffset: number = offset * this.DECELERATION_RATE;
                this.dragOffset = offset - decelerationOffset;
                offset = decelerationOffset;

                this.MoveItems(offset, true, true);
            }
            else if (this.bounce == eBaseListView.Bounce.Clamped)
            {
                this.MoveItems(bounceOffset, true, true);
            }
        }
        else
        {
            offset = this.dragOffset;
            let decelerationOffset: number = offset * this.DECELERATION_RATE;
            this.dragOffset = offset - decelerationOffset;
            offset = decelerationOffset;
            this.MoveItems(offset, true, false);
        }
    }

    private MoveItemsOnBounce(bounceOffset: number): void
    {
        if (bounceOffset == 0.0)
        {
            return;
        }

        let isForward: boolean = this.direction == eBaseListView.Direction.Horizontal ? bounceOffset < 0 : bounceOffset > 0;
        let activeItemIndex: number = isForward == true ? 0 : this.activeItemIndexList.length - 1;
        let itemIndex: number = this.activeItemIndexList[activeItemIndex];
        let targetItem = this.GetItemInfo(itemIndex);

        if (targetItem.GetActive() == false)
        {
            return;
        }

        let activePos: number = 0.0;

        if (this.direction == eBaseListView.Direction.Horizontal)
        {
            activePos = targetItem.LocalPosition.x;

            if (isForward == true)
            {
                bounceOffset = this.GetStartPositionOnContent(this.align, this.margin) + this.CalculateHalfSize(targetItem, !isForward);
            }
            else
            {
                bounceOffset = this.GetEndPositionOnContent(this.align, this.margin) - this.CalculateHalfSize(targetItem, !isForward);
            }
        }
        else
        {
            activePos = targetItem.LocalPosition.y;

            if (isForward == true)
            {
                bounceOffset = this.GetStartPositionOnContent(this.align, this.margin) - this.CalculateHalfSize(targetItem, !isForward);
            }
            else
            {
                bounceOffset = this.GetEndPositionOnContent(this.align, this.margin) + this.CalculateHalfSize(targetItem, !isForward);
            }
        }

        if (this.bounce == eBaseListView.Bounce.Elastic)
        {
            activePos += this.scrollOffset;
            this.scrollOffset *= this.ELASTIC_DECELERATION_SCROLL_OFFSET;

            activePos = this.SmoothDamp(activePos, bounceOffset, this.elasticInertia, Number.POSITIVE_INFINITY, Time.deltaTime);

            if (Math.abs((Math.abs(bounceOffset) - Math.abs(activePos))) < 0.1)
            {
                activePos = bounceOffset;
                this.scrollOffset = 0.0;
                this.scrollVelocity = 0.0;
            }
        }
        else if (this.bounce == eBaseListView.Bounce.Clamped)
        {
            activePos = bounceOffset;
            this.scrollOffset = 0.0;
            this.scrollVelocity = 0.0;
        }

        this.MoveItemsByRelative(activeItemIndex, activePos);
    }

    private SmoothDamp(current: number, target: number, smoothTime: number, maxSpeed: number, deltaTime: number)
    {
        smoothTime = Math.max(0.0001, smoothTime);
        let omega: number = 2 / smoothTime;

        let x: number = omega * deltaTime;
        let exp: number = 1 / (1 + x + 0.48 * x * x + 0.235 * x * x * x);
        let change: number = current - target;
        let originalTo: number = target;

        // Clamp maximum speed
        let maxChange: number = maxSpeed * smoothTime;
        change = cc.misc.clampf(change, -maxChange, maxChange);
        target = current - change;

        let temp: number = (this.scrollVelocity + omega * change) * deltaTime;
        this.scrollVelocity = (this.scrollVelocity - omega * temp) * exp;
        let output: number = target + (change + temp) * exp;

        // Prevent overshooting
        if (originalTo - current > 0.0 == output > originalTo)
        {
            output = originalTo;
            this.scrollVelocity = (output - originalTo) / deltaTime;
        }

        return output;
    }


    private MoveItemsOnScrolling(): void
    {
        if (this.scrollOffset != 0.0)
        {
            let tempOffset: number = this.scrollOffset;

            if (Math.abs(tempOffset) < 1.5)
            {
                this.scrollVelocity = 0.0;
                this.scrollOffset = 0.0;
            }
            else
            {
                tempOffset = this.SmoothDamp(tempOffset, 0.0, this.scrollInertia, Number.POSITIVE_INFINITY, Time.deltaTime);
            }

            this.MoveItems(tempOffset, false, false);

            if (this.scrollOffset != 0.0)
            {
                this.scrollOffset = tempOffset;
            }
        }
    }

    private MoveItems(offset: number, isDragging: boolean, isBounce: boolean): void
    {
        for (let i = 0; i < this.activeItemIndexList.length; i++)
        {
            let activeIndex: number = this.activeItemIndexList[i];
            let item = this.GetItemInfo(activeIndex);

            let tempPos = item.LocalPosition;

            if (this.direction == eBaseListView.Direction.Horizontal)
            {
                tempPos.x += offset;
            }
            else
            {
                tempPos.y += offset;
            }

            item.LocalPosition = new cc.Vec3(tempPos.x, tempPos.y);
        }

        this.onMoveItems?.Invoke(offset, isDragging, isBounce);
    }

    private MoveItemsByRelative(centerActiveIndex: number, position: number): void
    {
        if (centerActiveIndex >= this.activeItemIndexList.length)
        {
            return;
        }

        let itemIndex: number = this.activeItemIndexList[centerActiveIndex];
        let centerItem = this.GetItemInfo(itemIndex);
        let centerActivePos = centerItem.LocalPosition;
        let offset: number = position;

        if (this.direction == eBaseListView.Direction.Horizontal)
        {
            offset -= centerActivePos.x;
        }
        else
        {
            offset -= centerActivePos.y;
        }

        this.MoveItems(offset, false, true);
    }

    protected SetItemsPositionByFirstActiveItem(): void
    {
        if (this.activeItemIndexList.length == 0)
        {
            return;
        }

        let firstIndex: number = this.activeItemIndexList[0];

        let firstItem = this.GetItemInfo(firstIndex);
        let firstItemVP: VertexPosition = new VertexPosition(firstItem, true);
        let firstItemPosition = firstItem.LocalPosition;

        if (this.direction == eBaseListView.Direction.Horizontal)
        {
            firstItemPosition.x = firstItemVP.l;
        }
        else
        {
            firstItemPosition.y = firstItemVP.t;
        }

        this.SetItemsPosition(firstItemPosition, firstIndex);
    }

    private SetItemsPosition(startPosition: cc.Vec2 | cc.Vec3, startItemIndex: number): void
    {
        this.tempActiveList = [];
        let boundary: VertexPosition = new VertexPosition(new cc.Vec2(this.content.position.x, this.content.position.y), this.content.getContentSize(), this.content.getAnchorPoint());

        let forceFindMode: boolean = false;

        for (let searchDirection = 1; searchDirection >= -1; searchDirection -= 2)
        {
            let itemIndex: number = searchDirection == 1 ? startItemIndex - 1 : startItemIndex;
            let nextPosition: cc.Vec2 = cc.Vec2.ZERO;
            nextPosition.x = startPosition.x;
            nextPosition.y = startPosition.y;
            let isReturn: boolean = false;

            while (true)
            {
                let isForward: boolean = searchDirection == 1;
                itemIndex += searchDirection;

                if (this.bounce == eBaseListView.Bounce.Infinity)
                {
                    let tempIndex: number = itemIndex;
                    itemIndex = this.CalculateInfinityIndex(itemIndex);

                    if (itemIndex < 0)
                    {
                        break;
                    }

                    if (this.tempActiveList.includes(itemIndex))
                    {
                        break;
                    }

                    if ((isForward && itemIndex == startItemIndex)
                        || !isForward && itemIndex == this.CalculateInfinityIndex(itemIndex - 1))
                    {
                        if (isReturn)
                        {
                            break;
                        }

                        isReturn = true;
                    }
                }
                else
                {
                    if (itemIndex < 0 || itemIndex >= this.itemInfoList.length)
                    {
                        break;
                    }
                }

                let item = this.GetItemInfo(itemIndex);
                let itemVP: VertexPosition;

                let halfSize = this.CalculateHalfSize(item, !isForward) * searchDirection - (isForward == false ? this.space : 0.0);

                if (this.direction == eBaseListView.Direction.Horizontal)
                {
                    nextPosition.x += halfSize;

                    nextPosition.y = item.Size.height * (-0.5 + item.Pivot.y);
                    item.LocalPosition = new cc.Vec3(nextPosition.x, nextPosition.y);

                    itemVP = new VertexPosition(item, true);
                    let spaceVector: cc.Vec2 = new cc.Vec2(this.space, 0.0);
                    itemVP.rb = itemVP.rb.add(spaceVector);
                    itemVP.rt = itemVP.rt.add(spaceVector);
                }
                else
                {
                    nextPosition.x = item.Size.width * (-0.5 + item.Pivot.x);
                    nextPosition.y -= halfSize;
                    item.LocalPosition = new cc.Vec3(nextPosition.x, nextPosition.y);

                    itemVP = new VertexPosition(item, true);

                    let spaceVector: cc.Vec2 = new cc.Vec2(0.0, this.space);

                    itemVP.lb = itemVP.lb.sub(spaceVector);
                    itemVP.rb = itemVP.rb.sub(spaceVector);
                }

                if (this.AABB(itemVP, boundary) == true)
                {
                    forceFindMode = false;

                    nextPosition = this.CalculateEdgePosition(itemVP, isForward);

                    this.AddActiveItem(itemIndex);

                    if (this.bounce == eBaseListView.Bounce.Infinity)
                    {
                        this.tempActiveList.push(itemIndex);
                    }
                }
                else
                {
                    if (this.activeItemIndexList.length > 0)
                    {
                        this.RemoveActiveItem(itemIndex);
                    }

                    if (itemIndex == startItemIndex)
                    {
                        forceFindMode = true;
                    }

                    if (forceFindMode)
                    {
                        nextPosition = this.CalculateEdgePosition(itemVP, isForward);
                        continue;
                    }

                    if (this.bounce == eBaseListView.Bounce.Infinity)
                    {
                        if (isForward && itemIndex == startItemIndex)
                        {
                            nextPosition = this.CalculateEdgePosition(itemVP, isForward);
                        }
                        else
                        {
                            break;
                        }
                    }
                    else
                    {
                        break;
                    }
                }
            }
        }

        // this.activeItemIndexList.sort();
        this.activeItemIndexList = this.activeItemIndexList.sort((a, b) => a - b);
    }

    private CalculateHalfSize(item: BaseListItemInfo, isForward: boolean): number
    {
        let itemSize: cc.Size = item.Size;
        let itemPivot: cc.Vec2 = item.Pivot;

        if (this.direction == eBaseListView.Direction.Horizontal)
        {
            return Math.abs(isForward == true ? itemSize.width * (1.0 - itemPivot.x) : itemSize.width * itemPivot.x);
        }
        else
        {
            return Math.abs(isForward == true ? itemSize.height * itemPivot.y : itemSize.height * (1.0 - itemPivot.y));
        }
    }

    private CalculateEdgePosition(item: VertexPosition, isForward: boolean): cc.Vec2
    {
        let pos: cc.Vec2 = cc.Vec2.ZERO;

        if (this.direction == eBaseListView.Direction.Horizontal)
        {
            pos.x = isForward == true ? item.rb.x : item.lb.x;
        }
        else
        {
            pos.y = isForward == true ? item.rb.y : item.rt.y;
        }

        return pos;
    }

    private CalculateOffsetByBounce(): number
    {
        if (this.bounce == eBaseListView.Bounce.Infinity)
        {
            return 0.0;
        }

        let offset: number = 0.0;

        if (this.activeItemIndexList.length > 0)
        {
            let startPosition: number = this.GetStartPositionOnContent(this.align, this.margin);
            let endPosition: number = this.GetEndPositionOnContent(this.align, this.margin);

            for (let forwardDirection = 1.0; forwardDirection >= -1.0; forwardDirection -= 2.0)
            {
                let isForward: boolean = forwardDirection == 1.0;
                let itemIndex: number = isForward == true ? this.activeItemIndexList[0] : this.activeItemIndexList[this.activeItemIndexList.length - 1];
                let targetItemIndex: number = isForward == true ? 0 : this.itemInfoList.length - 1;

                if (itemIndex == targetItemIndex)
                {
                    let item = this.GetItemInfo(itemIndex);
                    let itemVertexPos = new VertexPosition(item, true);

                    let targetPosition: number = isForward == true ? startPosition : endPosition;
                    let itemPos: number = 0.0;

                    itemPos = this.direction == eBaseListView.Direction.Horizontal ? (isForward == true ? itemVertexPos.l : itemVertexPos.r) :
                        (isForward == true ? itemVertexPos.t : itemVertexPos.b);

                    if (this.direction == eBaseListView.Direction.Horizontal && isForward == true
                        || this.direction == eBaseListView.Direction.Vertical && isForward == false)
                    {
                        if (targetPosition < itemPos)
                        {
                            offset = targetPosition - itemPos;
                        }
                    }
                    else
                    {
                        if (targetPosition > itemPos)
                        {
                            offset = targetPosition - itemPos;
                        }
                    }

                    if (offset != 0.0)
                    {
                        if (Math.abs(offset) <= 0.001)
                        {
                            offset = 0.0;
                        }

                        return offset;
                    }
                }
            }
        }

        return offset;
    }

    private AABB(a: VertexPosition, b: VertexPosition): boolean
    {
        return (b.l + (b.r - b.l) > a.l && a.l + (a.r - a.l) > b.l)
            && (b.b + (b.t - b.b) > a.b && a.b + (a.t - a.b) > b.b);
    }

    protected GetItemInfo(index: number): BaseListItemInfo
    {
        return this.itemInfoList[index];
    }

    protected CalculateInfinityIndex(index: number): number
    {
        let count = this.itemInfoList.length;

        if (count == 0)
        {
            return -1;
        }
        else if (count == 1)
        {
            return 0;
        }

        if (index >= count)
        {
            index = index % count;
        }
        else if (index < 0)
        {
            index = count - (Math.abs(index) % count);
        }

        return index;
    }

    protected GetFirstItem(): BaseListItemInfo
    {
        return this.GetItemInfo(0);
    }

    protected GetLastItem(): BaseListItemInfo
    {
        return this.GetItemInfo(this.itemInfoList.length - 1);
    }

    public GetCount(): number
    {
        if (null == this.itemInfoList)
        {
            return 0;
        }
        else 
        {
            return this.itemInfoList.length;
        }
    }

    public GetActiveCount(): number
    {
        return this.activeItemIndexList.length;
    }

    public GetActiveItem(index: number): cc.Node
    {
        if (this.IsItemActive(index) == false)
        {
            return null;
        }

        return this.itemInfoList[index].RectTransform;
    }

    public IsItemActive(index: number): boolean
    {
        return this.activeItemIndexList.findIndex(x => x == index) != -1;
    }

    public GetFirstActiveItemIndex(): number
    {
        if (this.activeItemIndexList.length == 0)
        {
            return -1;
        }
        else
        {
            return this.activeItemIndexList[0];
        }
    }

    public GetLastActiveItemIndex(): number
    {
        if (this.activeItemIndexList.length == 0)
        {
            return -1;
        }
        else
        {
            return this.activeItemIndexList[this.activeItemIndexList.length - 1];
        }
    }

    private GetStartPositionOnContent(align: eBaseListView.Align, margin: eBaseListView.Margin): number
    {
        let startPosition: number = 0.0;

        if (align == eBaseListView.Align.Center)
        {
            let firstItem = this.GetFirstItem();
            let firstItemWidth: number = firstItem.Size.width;
            let firstItemHeight: number = firstItem.Size.height;

            if (firstItem == null)
            {
                return 0.0;
            }
            else
            {
                startPosition = this.direction == eBaseListView.Direction.Horizontal ? firstItemWidth * -0.5
                    : firstItemHeight * 0.5;
            }
        }
        else
        {
            let contentSize: cc.Size = this.content.getContentSize();
            startPosition = this.direction == eBaseListView.Direction.Horizontal ? contentSize.width * -0.5
                : contentSize.height * 0.5;
        }

        if (this.direction == eBaseListView.Direction.Horizontal)
        {
            startPosition += margin.left;
        }
        else
        {
            startPosition -= margin.up;
        }

        return startPosition;
    }

    private GetEndPositionOnContent(align: eBaseListView.Align, margin: eBaseListView.Margin): number
    {
        let endPosition: number = 0.0;

        if (align == eBaseListView.Align.Center)
        {
            let lastItem = this.GetLastItem();

            if (lastItem == null)
            {
                return 0.0;
            }
            else
            {
                endPosition = this.direction == eBaseListView.Direction.Horizontal ? lastItem.Size.width * 0.5
                    : lastItem.Size.height * -0.5;
            }
        }
        else
        {

            let startPosition: number = this.GetStartPositionOnContent(align, new eBaseListView.Margin());
            endPosition = this.direction == eBaseListView.Direction.Horizontal ? startPosition + this.contentSize.x
                : startPosition - this.contentSize.y;
        }

        if (this.direction == eBaseListView.Direction.Horizontal)
        {
            endPosition -= margin.right;
        }
        else
        {
            endPosition += margin.down;
        }

        return endPosition;
    }

    private GetValidPageIndex(): number
    {
        if (this.activeItemIndexList.length == 0)
        {
            return -1;
        }

        let startPosition = this.GetStartPositionOnContent(this.align, this.margin);
        let firstActiveIndex: number = this.TargetIndex;
        let firstActiveItemInfo = this.GetItemInfo(firstActiveIndex);
        let firstActiveItemVP = new VertexPosition(firstActiveItemInfo, true);
        let firstActiveItemHalfSize = new cc.Size(firstActiveItemInfo.Size.width * 0.5, firstActiveItemInfo.Size.height * 0.5);

        let pageIndex: number = firstActiveIndex;
        let centerPoint = 0.0;
        let firstActiveItemStartPoint = 0.0;
        let firstActiveItemEndPoint = 0.0;

        if (this.direction == eBaseListView.Direction.Horizontal)
        {
            centerPoint = startPosition + firstActiveItemHalfSize.width;
            firstActiveItemStartPoint = firstActiveItemVP.l;
            firstActiveItemEndPoint = firstActiveItemVP.r;

            if (firstActiveItemStartPoint > centerPoint)
            {
                if (firstActiveIndex > 0)
                {
                    pageIndex--;
                }
            }
            else if (firstActiveItemEndPoint < centerPoint)
            {
                if (firstActiveIndex < this.itemInfoList.length - 1)
                {
                    pageIndex++;
                }
            }
        }
        else
        {
            centerPoint = startPosition - firstActiveItemHalfSize.height;
            firstActiveItemStartPoint = firstActiveItemVP.t;
            firstActiveItemEndPoint = firstActiveItemVP.b;

            if (firstActiveItemStartPoint < centerPoint)
            {
                if (firstActiveIndex > 0)
                {
                    pageIndex--;
                }
            }
            else if (firstActiveItemEndPoint > centerPoint)
            {
                if (firstActiveIndex < this.itemInfoList.length - 1)
                {
                    pageIndex++;
                }
            }
        }

        return pageIndex;
    }

    // private GetMousePosition(eventData: PointerEventData): cc.Vec2
    // {
    //     let localPoint: cc.Vec2;

    //     // RectTransformUtility.ScreenPointToLocalPointInRectangle(cachedRectTransform,
    //     //     Input.mousePosition,
    //     //     eventData.pressEventCamera,
    //     //     out localPoint);

    //     return localPoint;
    // }

    private StretchToFit(tr: cc.Node): void
    {
        let widget = tr.addComponent(cc.Widget);
        widget.alignMode = cc.Widget.AlignMode.ALWAYS;
        widget.isAlignTop = true;
        widget.isAlignBottom = true;
        widget.isAlignLeft = true;
        widget.isAlignRight = true;
        widget.top = 0;
        widget.bottom = 0;
        widget.left = 0;
        widget.right = 0;

        this.content.setContentSize(cc.director.getScene().getComponentInChildren(cc.Canvas).node.getContentSize());
        // tr.addComponent(cc.Widget). setAnchorPoint(0.5,0.5);
        // tr.setAnchorPoint(0);
        // tr.setContentSize(0);
    }

    update(dt: number): void 
    {
        super.update(dt);
        if (this.isBegin)
        {
            this.totalTime += Time.deltaTime;
        }
    }

    isBegin: boolean = false;
    public OnBeginDrag(event): void
    {
        if (this.enableDrag == false)
        {
            return;
        }

        this.ResetValuesOfTimeForMove();

        if (event._touches.length <= 0)
        {
            return;
        }
        // if (eventData.button != PointerEventData.InputButton.Left
        //     || this.IsActive() == false)
        // {
        //     return;
        // }


        this.dragPosition.x = event._touches[0]._point.x;
        this.dragPosition.y = event._touches[0]._point.y;

        if (this.node.is3DNode)
        {
            if (this.dragPosition.x < 0)
            {
                this.dragPosition.x = 0;
            }

            if (this.dragPosition.x > this.node.width)
            {
                this.dragPosition.x = this.node.width;
            }
        }

        this.IsDragging = true;
        this.isScroll = false;
        this.isBegin = true;
        this.totalTime = 0.3;
    }

    public OnEndDrag(event): void
    {
        if (!this.isBegin)
        {
            return;
        }
        this.isBegin = false;

        if (this.enableDrag == false)
        {
            return;
        }

        // if (eventData.button != PointerEventData.InputButton.Left)
        // {
        //     return;
        // }

        if (event._touches.length <= 0)
        {
            return;
        }

        // if (this.node.is3DNode)
        // {
        //     if (!this.isScroll && this.scrollOffset == 0)
        //     {
        //         if (this.onDragEnd?.(event, this.camera))
        //         {
        //             return;
        //         }
        //     }
        // }

        let localPoint: cc.Vec2 = cc.Vec2.ZERO;
        localPoint.x = event._touches[0]._point.x;
        localPoint.y = event._touches[0]._point.y;

        // let boundary: VertexPosition = new VertexPosition(new cc.Vec2(this.content.position.x, this.content.position.y), this.content.getContentSize(), this.content.getAnchorPoint());

        // //let temp : VertexPosition = new VertexPosition(event._touches[0]._point, new cc.Size(0,0), new cc.Vec2(0.5,0.5));

        // //if(!this.AABB(temp, boundary))
        // {
        //     if(event._touches[0]._point.x > boundary.rt.x)
        //     {
        //         localPoint.x = boundary.rt.x;
        //     }
        //     else if(event._touches[0]._point.x < boundary.lt.x)
        //     {
        //         localPoint.x = boundary.lt.x;
        //     }
        // }

        //if (this.node.is3DNode)
        {
            if (localPoint.x < 0)
            {
                localPoint.x = 0;
            }

            if (localPoint.x > this.node.width)
            {
                localPoint.x = this.node.width;
            }
        }

        if (this.movement == eBaseListView.Movement.Page)
        {
            if (this.totalTime >= 0.3)
            {
                this.dragPosition2.x = localPoint.x;
                this.dragPosition2.y = localPoint.y;
            }
        }

        // let localPoint: cc.Vec2 = event._touches[0]._point;
        let distance: cc.Vec2 = this.dragPosition.sub(localPoint);
        let distanceValue: number = this.direction == eBaseListView.Direction.Horizontal ? -distance.x : -distance.y;

        let distance2: cc.Vec2 = this.dragPosition2.sub(localPoint);
        let distanceValue2: number = this.direction == eBaseListView.Direction.Horizontal ? -distance2.x : -distance2.y;

        if (this.movement == eBaseListView.Movement.Default)
        {
            this.scrollOffset = this.dragOffset + distanceValue;
            this.scrollOffset *= this.DECELERATION_RATE;
        }
        else if (this.movement == eBaseListView.Movement.Page)
        {
            if (Math.abs(distanceValue2) >= Math.abs(this.pageSensitivity))
            {
                if (distanceValue2 < 0)
                {
                    if (this.direction == eBaseListView.Direction.Horizontal)
                    {
                        this.GoToNext(this.pageMoveTime);
                    }
                    else
                    {
                        this.GoToPrev(this.pageMoveTime);
                    }
                }
                else
                {
                    if (this.direction == eBaseListView.Direction.Horizontal)
                    {
                        this.GoToPrev(this.pageMoveTime);
                    }
                    else
                    {
                        this.GoToNext(this.pageMoveTime);
                    }
                }
            }
        }

        this.dragOffset = 0.0;
        this.IsDragging = false;
    }

    isScroll: boolean = false;
    totalTime: number = 0.3;
    totalDragTime: number = 0;
    public OnDrag(event): void
    {
        if (this.enableDrag == false)
        {
            return;
        }

        if (this.IsDragging == false)
        //  || eventData.button != PointerEventData.InputButton.Left
        //|| this.IsActive() == false)
        {
            return;
        }

        if (event._touches.length <= 0)
        {
            return;
        }

        let localPoint: cc.Vec2 = cc.Vec2.ZERO;
        localPoint.x = event._touches[0]._point.x;
        localPoint.y = event._touches[0]._point.y;

        if (localPoint.x < 0)
            {
                localPoint.x = 0;
            }

            if (localPoint.x > this.node.width)
            {
                localPoint.x = this.node.width;
            }

        // if (this.node.is3DNode)
        // {
        //     if (localPoint.x < 0)
        //     {
        //         localPoint.x = 0;
        //     }

        //     if (localPoint.x > this.node.width)
        //     {
        //         localPoint.x = this.node.width;
        //     }


        //     let screenPosition: cc.Vec2 = new cc.Vec2(localPoint.x - cc.Canvas.instance.node.width * 0.5,
        //         localPoint.y - cc.Canvas.instance.node.height * 0.5);

        //     let halfContentSize = new cc.Vec2(this.content.width * 0.5, this.content.height * 0.5);
        //     let isValidPoint: boolean = true;

        //     if (this.direction == eBaseListView.Direction.Horizontal)
        //     {
        //         isValidPoint = screenPosition.x > -halfContentSize.x + this.offSet.x && screenPosition.x < halfContentSize.x + this.offSet.x;
        //     }
        //     else
        //     {
        //         isValidPoint = screenPosition.y > -halfContentSize.y + this.offSet.y && screenPosition.y < halfContentSize.y + this.offSet.y;
        //     }

        //     if (isValidPoint == false)
        //     {
        //         this.OnEndDrag(event);
        //         //eventData.pointerDrag = null;
        //         return;
        //     }
        // }

        if (this.direction == eBaseListView.Direction.Horizontal)
        {
            if (this.dragPosition.x == event._touches[0]._point.x)
            {
                return;
            }
            else
            {

            }
        }
        else
        {
            if (this.dragPosition.y == event._touches[0]._point.y)
            {
                return;
            }
        }

        //let localPoint = event._touches[0]._point;
        //  localPoint.x = event._touches[0]._point.x;
        //  localPoint.y = event._touches[0]._point.y;



        // let boundary: VertexPosition = new VertexPosition(new cc.Vec2(this.content.position.x, this.content.position.y), this.content.getContentSize(), this.content.getAnchorPoint());

        // //let temp : VertexPosition = new VertexPosition(event._touches[0]._point, new cc.Size(0,0), new cc.Vec2(0.5,0.5));

        // //if(!this.AABB(temp, boundary))
        // {
        //     if(event._touches[0]._point.x > boundary.rt.x)
        //     {
        //         localPoint.x = boundary.rt.x;
        //     }
        //     else if(event._touches[0]._point.x < boundary.lt.x)
        //     {
        //         localPoint.x = boundary.lt.x;
        //     }
        // }        


        let distance: cc.Vec2 = this.dragPosition.sub(localPoint);

        if (!this.isScroll)
        {
            if (this.direction == eBaseListView.Direction.Horizontal)
            {
                if (Math.abs(distance.x) < this.SCROLL_DELAY)
                {
                    return;
                }
            }
            else
            {
                if (Math.abs(distance.y) < this.SCROLL_DELAY)
                {
                    return;
                }
            }
        }

        this.isScroll = true;

        if (this.movement == eBaseListView.Movement.Page)
        {
            if (this.totalTime >= 0.3)
            {
                this.totalTime -= 0.3;
                this.dragPosition2.x = localPoint.x;
                this.dragPosition2.y = localPoint.y;
            }
        }

        this.dragPosition.x = localPoint.x;
        this.dragPosition.y = localPoint.y;

        let distanceValue: number = this.direction == eBaseListView.Direction.Horizontal ? -distance.x : -distance.y;

        this.dragOffset = distanceValue + this.dragOffset;

        if (this.direction == eBaseListView.Direction.Horizontal)
        {
            this.LatestDragDirection = (this.dragOffset > 0.0) ? 1 : -1;
        }
        else
        {
            this.LatestDragDirection = (this.dragOffset < 0.0) ? 1 : -1;
        }
    }
}

export abstract class BaseListItemInfo
{
    protected rt: cc.Node;
    public get RectTransform(): cc.Node { return this.rt; }

    public abstract get Size(): cc.Size;
    public abstract get Pivot(): cc.Vec2;
    public abstract get Position(): cc.Vec3;
    public abstract set Position(value);
    public abstract get LocalPosition(): cc.Vec3;
    public abstract set LocalPosition(value);

    public abstract SetActive(isOn: boolean, index: number): void;
    public abstract GetActive(): boolean;
    public abstract SetParent(parent: cc.Node): void;
    public abstract SetAsFirstSibling(): void;
    public abstract SetAsLastSibling(): void;
    public abstract SetSiblingIndex(index: number): void;
    public abstract GetSiblingIndex(): number;
}

export class VertexPosition
{
    public lt: cc.Vec2;
    public rt: cc.Vec2;
    public lb: cc.Vec2;
    public rb: cc.Vec2;

    // public get this[int index] : cc.Vec2
    // {
    //     get
    //     {
    //         if (index == 0)
    //         {
    //             return lt;
    //         }
    //         else if (index == 1)
    //         {
    //             return rt;
    //         }
    //         else if (index == 2)
    //         {
    //             return lb;
    //         }
    //         else
    //         {
    //             return rb;
    //         }
    //     }
    //     set
    //     {
    //         if (index == 0)
    //         {
    //             lt = value;
    //         }
    //         else if (index == 1)
    //         {
    //             rt = value;
    //         }
    //         else if (index == 2)
    //         {
    //             lb = value;
    //         }
    //         else
    //         {
    //             rb = value;
    //         }
    //     }
    // }

    public get l(): number
    {
        return this.lt.x;
    }

    public get r(): number
    {
        return this.rt.x;
    }

    public get t(): number
    {
        return this.lt.y;
    }

    public get b(): number
    {
        return this.lb.y;
    }

    public constructor(position: cc.Vec2, size: cc.Size, pivot: cc.Vec2);
    public constructor(item: BaseListItemInfo, localPosition: boolean);
    public constructor(param1: any, param2: any, param3?: cc.Vec2)
    {
        if (param1 instanceof BaseListItemInfo)
        {
            let item = param1;
            let localPosition = param2;

            let position = localPosition == true ? item.LocalPosition : item.Position;
            let size: cc.Size = item.Size;

            let pivot: cc.Vec2 = item.Pivot;

            this.lt = new cc.Vec2(position.x - (size.width * pivot.x), position.y + size.height * (1.0 - pivot.y));
            this.rt = new cc.Vec2(position.x + (size.width * (1.0 - pivot.x)), position.y + size.height * (1.0 - pivot.y));
            this.lb = new cc.Vec2(position.x - (size.width * pivot.x), position.y - size.height * (1.0 - pivot.y));
            this.rb = new cc.Vec2(position.x + (size.width * (1.0 - pivot.x)), position.y - size.height * (1.0 - pivot.y));
        }
        else
        {
            let position = param1;
            let size: cc.Size = param2;
            let pivot = param3;

            this.lt = new cc.Vec2(position.x - (size.width * pivot.x), position.y + size.height * (1.0 - pivot.y));
            this.rt = new cc.Vec2(position.x + (size.width * (1.0 - pivot.x)), position.y + size.height * (1.0 - pivot.y));
            this.lb = new cc.Vec2(position.x - (size.width * pivot.x), position.y - size.height * (1.0 - pivot.y));
            this.rb = new cc.Vec2(position.x + (size.width * (1.0 - pivot.x)), position.y - size.height * (1.0 - pivot.y));
        }
    }

    public ToString(): string
    {
        return StringUtils.Format("lt : {0} , rt : {1} ,lb : {2} ,rb : {3}", this.lt, this.rt, this.lb, this.rb);
    }
}

export class RaycastLayer extends cc.Graphics //, IPointerDownHandler
{
    public OnDown: InstanceEvent = new InstanceEvent();

    public SetMaterialDirty(): void { return; }
    public SetVerticesDirty(): void { return; }

    // protected OnPopulateMesh(vh: VertexHelper): void
    // {
    //     vh.Clear();
    // }

    // public OnPointerDown(eventData: PointerEventData): void
    // {
    //     if (this.OnDown != null)
    //     {
    //         this.OnDown.Invoke(eventData);
    //     }
    // }
}