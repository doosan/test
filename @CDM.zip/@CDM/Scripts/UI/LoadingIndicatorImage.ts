const {ccclass, property} = cc._decorator;

@ccclass
export default class LoadingIndicatorImage extends cc.Component {

    @property(cc.Node) image : cc.Node = null;

    protected onEnable(): void
    {
        this.scheduleOnce(()=>
        {
            this.image.opacity = 255;
        }, 0.3);
    }

    protected onDisable(): void
    {
        this.unscheduleAllCallbacks();
        this.image.opacity = 0;
    }
}
