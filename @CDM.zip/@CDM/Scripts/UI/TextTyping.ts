import CoroutineComponent, { WaitForSeconds } from "../System/CoroutineComponent";

const {ccclass, property} = cc._decorator;

@ccclass('ImageText')
export class ImageText
{
    @property([cc.Node]) public imageNodeList : cc.Node[] = [];
    @property([cc.Integer]) public imagePutIndex : number[] = [];
    @property([cc.Integer]) public imageSpaceCount : number[] = [];
}

@ccclass
export default class TextTyping extends CoroutineComponent
{
    @property(cc.Label) private targetLabel : cc.Label = null;
    private targetString : string = "";
    private onComplete : Function = null;

    @property() private useImage : boolean = false;
    @property({type:[ImageText], visible(){return this.useImage}}) private imageTextList : ImageText[] = [];
    

    public HideAllImageNode()
    {
        this.imageTextList.forEach(t=>
            {
                t.imageNodeList.forEach(node=>
                    {
                        node.active = false;
                    });
            });
    }

    public *StartTyping(script:string, delay:number, onComplete:Function, curTalkCount = 0)
    {
        this.targetString = script;
        this.onComplete = onComplete.bind(this);
        this.targetLabel.string = "";
        
        let curImageIndex = 0;
        for(let i = 0; i < script.length; i++)
        {
            if(this.useImage)
            {
                if(this.imageTextList[curTalkCount].imageNodeList.length > 0)
                {
                    if(this.imageTextList[curTalkCount].imagePutIndex[curImageIndex] == i)
                    {
                        for(let s = 0; s < this.imageTextList[curTalkCount].imageSpaceCount[curImageIndex]; s++)
                        {
                            this.targetLabel.string += " ";
                        }
                        this.imageTextList[curTalkCount].imageNodeList[curImageIndex].active = true;
                        this.targetLabel.string += script[i + this.imageTextList[curTalkCount].imageSpaceCount[curImageIndex]];
                        i += this.imageTextList[curTalkCount].imageSpaceCount[curImageIndex];
                        curImageIndex++;
                    }
                    else
                    {
                        if(script[i] == '/')
                        {
                            this.targetLabel.string += "\n";
                        }
                        else
                        {
                            this.targetLabel.string += script[i];
                        }
                    }
                }
                else
                {
                    if(script[i] == '/')
                    {
                        this.targetLabel.string += "\n";
                    }
                    else
                    {
                        this.targetLabel.string += script[i];
                    }
                }
            }
            else
            {
                if(script[i] == '/')
                {
                    this.targetLabel.string += "\n";
                }
                else
                {
                    this.targetLabel.string += script[i];
                }
            }
            yield new WaitForSeconds(delay);
        }
        onComplete.call(this);
        
        
    }

    public SkipTyping(curTalkCount:number)
    {
        this.targetLabel.string = "";
        let spl = this.targetString.split('/');
        for(let s = 0; s < spl.length; s++)
        {
            this.targetLabel.string += spl[s];
            if(s < spl.length - 1)
            {
                this.targetLabel.string += "\n";
            }
        }

        if(this.useImage)
        {
            this.imageTextList[curTalkCount].imageNodeList.forEach(node=>
            {
                if(node != null)
                {
                    node.active = true;
                }
            });
        }
        if(this.onComplete != null)
        {
            this.onComplete.call(this);
        }
    }
}
