import CoroutineComponent, { WaitForSeconds } from "../../../@CDM/Scripts/System/CoroutineComponent";

const {ccclass, property, menu} = cc._decorator;

@ccclass
@menu("UI/TextEllipsis")
export default class TextEllipsis extends CoroutineComponent
{
    @property(cc.Label) label: cc.Label = null;
    @property width: number = 0;
    
    private str :string = '';

    SetString(str : string)
    {
        if(this.str == str)
        {            
            this.label.node.opacity = 255;
        }
        else
        {
            this.label.node.width = 0;
            this.label.node.opacity = 1;
            this.label.string = str;
            this.str = str;

            this.label["_forceUpdateRenderData"]();
            this.FixCoroutine();
        }
    }

    FixCoroutine()
    {
        let sizeOver : boolean = false;

        while(this.width < this.label.node.width)
        {
            if(this.label.string.length > 0)
            {
                sizeOver = true;
                this.label.string = this.label.string.substring(0, this.label.string.length - 1);
                this.label["_forceUpdateRenderData"]();
            }
            else
            {
                break;
            }
        }

        if(sizeOver)
        {
            this.label.string = this.label.string + "..."; 
        }

        this.label.node.opacity = 255;
    }
}