import GameObjectPool from "../ObjectPool/GameObjectPool";
import SingleObjects from "../System/SingleObjects";
import { Ease } from "../Util/EasingFunction";
import BaseLoadingIndicator, { LoadingType } from "./BaseLoadingIndicator";


const { ccclass, property } = cc._decorator;

@ccclass("Properties")
export class Properties
{
    @property() showDuration: number = 0.25;
    @property({ type: cc.Enum(Ease) }) public showEase: Ease = Ease.cubicIn;
    @property() hideDuration: number = 0.2;
    @property({ type: cc.Enum(Ease) }) public hideEase: Ease = Ease.cubicOut;
    @property() blocksRaycasts: boolean = true;
}

@ccclass
export default class LoadingIndicator extends BaseLoadingIndicator
{
    @property(cc.Node) box: cc.Node = null;
    @property(cc.Node) image: cc.Node = null;
    @property(cc.Label) message: cc.Label = null;
    //#region static
    private static readonly ROOT_NAME: string = "SingletonObjects";
    private static pool: GameObjectPool<LoadingIndicator> = null;
    private static prefab: LoadingIndicator = null;

    public static async Initialize(): Promise<boolean>
    {
        return new Promise((resolve, reject) => 
        {
            cc.resources.load<cc.Prefab>("LoadingIndicator", cc.Prefab, function (err, prefab)
            {
                if (err == null)
                {
                    LoadingIndicator.pool = new GameObjectPool<LoadingIndicator>(SingleObjects.Instance.node, 2, () =>
                    {
                        return cc.instantiate(prefab).getComponent(LoadingIndicator);
                    });

                    resolve(true);
                }
                else
                {
                    cc.error(err);
                    resolve(null);
                }
            })
        });
    }

    public static Get(parent: cc.Node = null, autoReturn: boolean = true): LoadingIndicator
    {
        let indicator: LoadingIndicator = this.pool.Get();

        if (parent != null)
        {
            indicator.SetParent(parent);
        }

        indicator.autoReturn = autoReturn;
        return indicator;
    }

    public static Return(indicator: LoadingIndicator): void
    {
        this.pool.Return(indicator);
    }
    //#endregion

    @property(cc.Node) canvasGroup: cc.Node = null;
    @property(Properties) defaultProperteis: Properties = null;
    @property() public autoReturn: boolean = true;

    private overridedProperties: Properties;
    private currentProperteis: Properties;

    private isActvie: boolean;
    public get IsActive() { return this.isActvie }

    public SetProperteis(showDuration: number = 0.25, showEase: Ease = Ease.cubicIn, hideDuration: number = 0.2, hideEase: Ease = Ease.cubicOut): void
    {
        this.overridedProperties = new Properties();

        this.overridedProperties.showDuration = showDuration;
        this.overridedProperties.showEase = showEase;
        this.overridedProperties.hideDuration = hideDuration;
        this.overridedProperties.hideEase = hideEase;
    }

    private SelectProperties(): void
    {
        this.currentProperteis = this.overridedProperties != null ? this.overridedProperties : this.defaultProperteis;
    }

    canvasTween: cc.Tween = null;

    public Show(blocksRaycast: boolean = true, type: LoadingType = LoadingType.None): BaseLoadingIndicator
    {
        this.isActvie = true;

        this.SelectProperties();

        if (type == LoadingType.None)
        {
            if (this.box != null)
            {
                this.box.active = false;
            }
            if (this.image != null)
            {
                this.image.active = true;
            }
        }
        else if (type == LoadingType.Disable)
        {
            if (this.box != null)
            {
                this.box.active = false;
            }
            if (this.image != null)
            {
                this.image.active = false;
            }
        }
        else
        {
            if (this.box != null)
            {
                this.box.active = true;
            }
            if (this.image != null)
            {
                this.image.active = false;
            }

            if (this.message != null)
            {
                if (type == LoadingType.Purchase)
                {
                    this.message.string = `Purchase in progress.​
Check the purchase page.`;
                }
                else if (type == LoadingType.MarbleX)
                {
                    this.message.string = 'Check the Marblex Wallet page.';
                }
            }
        }

        this.node.active = true;

        if (this.canvasTween != null)
        {
            this.canvasTween.stop();
            this.canvasTween.removeSelf();
            this.canvasTween = null;
        }

        // canvasGroup.blocksRaycasts = blocksRaycast;        
        this.canvasTween = cc.tween(this.canvasGroup).to(this.currentProperteis.showDuration, { opacity: 255 }, { easing: Ease[this.currentProperteis.showEase] }).start();
        // canvasGroup.DOFade(1, currentProperteis.showDuration).SetEase(currentProperteis.showEase);

        return this;
    }

    public Hide(onComplete: Function = null): void
    {
        this.isActvie = false;

        this.SelectProperties();

        if (this.canvasTween != null)
        {
            this.canvasTween.stop();
            this.canvasTween.removeSelf();
            this.canvasTween = null;
        }

        this.canvasTween = cc.tween(this.canvasGroup).to(this.currentProperteis.hideDuration, { opacity: 0 }, { easing: Ease[this.currentProperteis.hideEase] }).call(() =>
        {
            this.OnHideComplete();
            if (onComplete != null)
            {
                onComplete();
            }
        }).start();
    }

    private OnHideComplete(): void
    {
        if (this.autoReturn == true)
        {
            this.overridedProperties = null;
            LoadingIndicator.Return(this);
        }
        else
        {
            this.node.active = false;
        }
    }
}
