import BaseListView, { eBaseListView } from "./BaseListView";
import BaseListViewControlPanel, { ButtonBehaviour } from "./BaseListViewControlPanel";

const { ccclass, property, menu } = cc._decorator;

@ccclass
export default class ListViewControlPanel extends BaseListViewControlPanel<BaseListView>
{
    private readonly ACTIVE_OFFSET: number = 3.0;

    private currentItemIndex: number = 0;

    protected override Initialize()
    {
        this.currentItemIndex = -1;
        this.target.onUpdate.AddListener(this.OnListItemUpdate.bind(this), this);
    }

    protected override Run(buttonBehaviour: ButtonBehaviour, duration: number = 0.3): void
    {
        //Debug.Log($"ListViewControlPanel - Run : {buttonBehaviour.ToString()} ({duration})");

        if (this.target == null
            || this.target.IsInitialize == false
            || this.target.enabled == false
            || this.target.enableDrag == false
            || this.target.GetActiveCount() == 0)
        {
            return;
        }

        if (buttonBehaviour == ButtonBehaviour.Prev || buttonBehaviour == ButtonBehaviour.Next)
        {
            var dir = buttonBehaviour == ButtonBehaviour.Prev ? -1 : 1;
            var currentPageCount = this.pageCount;

            if (this.autoPageCount)
            {
                currentPageCount = this.target.GetActiveCount();
                currentPageCount += buttonBehaviour == ButtonBehaviour.Prev ? -this.autoPageCountOffset : this.autoPageCountOffset;
            }

            if (currentPageCount < 0)
            {
                currentPageCount = 0;
            }

            //Debug.Log($"ListViewControlPanel - currentPageCount : {currentPageCount}");

            if (this.currentItemIndex == -1)
            {
                var firstItemIndex = this.target.GetFirstActiveItemIndex();
                this.currentItemIndex = (firstItemIndex / currentPageCount) * currentPageCount;
            }

            this.currentItemIndex += currentPageCount * dir;
            this.currentItemIndex = cc.misc.clampf(this.currentItemIndex, 0, this.target.GetCount());
            this.target.GoTo(this.currentItemIndex, duration);
        }
        else if (buttonBehaviour == ButtonBehaviour.First)
        {
            this.currentItemIndex = 0;
            this.target.GoToFirst(duration);
        }
        else if (buttonBehaviour == ButtonBehaviour.Last)
        {
            this.currentItemIndex = this.target.GetCount() - 1;
            this.target.GoToLast(duration);
        }

        //Debug.Log($"ListViewControlPanel - currentItemIndex : {currentItemIndex}");
    }

    private OnListItemUpdate()
    {
        this.UpdateButtons();

        if (this.target == null)
        {
            return;
        }

        if (this.target.IsDragging)
        {
            // #if GGDEV
            //                 if (currentItemIndex != -1)
            //                 {
            //                     Debug.Log("ListViewControlPanel - reset currentItemIndex");
            //                 }
            // #endif
            this.currentItemIndex = -1;
        }
    }

    protected override UpdateButtons()
    {
        if (this.target == null
            || this.target.IsInitialize == false
            || this.target.GetCount() == 0
            || this.target.GetActiveCount() == 0
            || this.target.GetActiveCount() == this.target.GetCount())
        {
            for (let index = 0; index < this.buttonInfoList.length; index++)
            {
                let info = this.buttonInfoList[index];
                this.SetActiveButton(info.button, info.disableType, false);
            }

            return;
        }

        if (this.target.bounce == eBaseListView.Bounce.Infinity)
        {
            for (let index = 0; index < this.buttonInfoList.length; index++)
            {
                let info = this.buttonInfoList[index];
                this.SetActiveButton(info.button, info.disableType, true);
            }

            return;
        }

        let isPrevButtonActive: boolean = false;
        let isNextButtonActive: boolean = false;

        let firstItemIndex: number = 0;
        let lastItemIndex: number = this.target.GetCount() - 1;

        if (this.target.movement == eBaseListView.Movement.Page)
        {
            isPrevButtonActive = this.target.TargetIndex > firstItemIndex;
            isNextButtonActive = this.target.TargetIndex < lastItemIndex;
        }
        else
        {
            if (this.target.GetFirstActiveItemIndex() == firstItemIndex)
            {
                let firstTr = this.target.GetActiveItem(firstItemIndex);

                if (firstTr.position.x + firstTr.width * -0.5 + this.ACTIVE_OFFSET < this.target.Content.width * -0.5)
                {
                    isPrevButtonActive = true;
                }
            }
            else
            {
                isPrevButtonActive = true;
            }

            if (this.target.GetLastActiveItemIndex() == lastItemIndex)
            {
                var lastTr = this.target.GetActiveItem(lastItemIndex);

                if (lastTr.position.x - lastTr.width * -0.5 - this.ACTIVE_OFFSET > this.target.Content.width * 0.5)
                {
                    isNextButtonActive = true;
                }
            }
            else
            {
                isNextButtonActive = true;
            }

        }

        for (let index = 0; index < this.buttonInfoList.length; index++)
        {
            let info = this.buttonInfoList[index];

            if (info.behaviour == ButtonBehaviour.First || info.behaviour == ButtonBehaviour.Prev)
            {
                this.SetActiveButton(info.button, info.disableType, isPrevButtonActive);
            }
            else if (info.behaviour == ButtonBehaviour.Last || info.behaviour == ButtonBehaviour.Next)
            {
                this.SetActiveButton(info.button, info.disableType, isNextButtonActive);
            }
        }
    }
}