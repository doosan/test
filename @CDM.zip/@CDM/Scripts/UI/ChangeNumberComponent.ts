import { KMBOption } from "../Util/StringUtils";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("Util/ChangeNumberComponent")
export default abstract class ChangeNumberComponent extends cc.Component 
{
    @property changetimetick: number = 0.1;

    @property useKMBUnit: boolean = false;

    @property({
        visible()
        {
            return this.useKMBUnit;
        }
    }) public kiloStartingPoint: number = 3;

    @property({
        visible()
        {
            return this.useKMBUnit;
        }
    }) public maxLength: number = 9;


    kmbOption: KMBOption = null;

    useComma: boolean = false;
    useKMB: boolean = false;

    currentNumber: number = 0;

    _targetNode: cc.Node = null;
    _targetScale: number = 0;
    _standardNumber: number = 0;

    protected obj = { a: 0 }

    prefix: string = "";
    suffix: string = "";

    kmbMinValue: number = null;
    isSetString: boolean = false;

    @property({ displayName: "소숫점 제거", tooltip: "소숫점 제거" })
    ignorZeroDecimalPoint: boolean = true;   //// 0 소수점 제거

    nTimeOutIndex: number = -1;

    onDisable()
    {
        this.reset();
    }

    onDestroy()
    {
        this.reset();
    }

    release()
    {
        this.currentNumber = 0;
        this.obj = { a: 0 };
        this.fixNumber(0);
    }

    reset()
    {
        cc.Tween.stopAllByTarget(this.obj);

        // this.currentNumber = 0;
        // this.obj = { a: 0 };

        if (-1 != this.nTimeOutIndex)
        {
            clearTimeout(this.nTimeOutIndex);
        }
    }

    abstract setString(str: string): void;
    abstract fixNumber(num: number): void;

    setCurrentNumber(num: number)
    {
        this.currentNumber = num;
        this.fixNumber(this.currentNumber);
    }

    GetNumber(): number
    {
        return this.currentNumber;
    }

    // SetNumberFix(targetNumber : number, option : KMBOption, prefix : string, suffix : string, callback?: Function) : void;
    // SetNumberFix(targetNumber : number, useComma : boolean, prefix : string, suffix : string, callback?: Function) : void;
    // SetNumberFix(targetNumber : number, param : any, prefix : string, suffix : string, callback?: Function) : void
    // {
    //     if(param instanceof KMBOption)
    //     {
    //         let kmbOption = param;
    //         this.kmbOption = kmbOption;
    //         this.useKMB = true;
    //         this.useComma = true;
    //     }
    //     else
    //     {
    //         let useComma : boolean = param;
    //         this.useKMB = false;
    //         this.useComma = useComma;
    //     }

    //     this.prefix = prefix;
    //     this.suffix = suffix;
    //     this.Numbering(targetNumber);
    // }

    SetFix(prefix: string, suffix: string)
    {
        this.prefix = prefix == null ? "" : prefix;
        this.suffix = suffix == null ? "" : suffix;
    }

    SetNumberTM(targetNumber: number, option: KMBOption, useKMB: boolean, animateTime?: number, ease?: string, callback?: Function): void;
    SetNumberTM(targetNumber: number, useComma: boolean, useKMB: boolean, animateTime?: number, ease?: string, callback?: Function): void;
    SetNumberTM(targetNumber: number, param: any, useKMB: boolean, animateTime?: number, ease?: string, callback?: Function): void
    {
        if (param instanceof KMBOption)
        {
            let kmbOption = param;
            this.kmbOption = kmbOption;
            this.useKMB = useKMB;
            this.useComma = true;
        }
        else
        {
            let useComma: boolean = param;
            this.useKMB = false;
            this.useComma = useComma;
        }

        this.Numbering(targetNumber, animateTime, ease, callback);
    }

    SetNumber(targetNumber: number, option: KMBOption, animateTime?: number, ease?: string, callback?: Function): void;
    SetNumber(targetNumber: number, useComma: boolean, animateTime?: number, ease?: string, callback?: Function): void;
    SetNumber(targetNumber: number, param: any, animateTime?: number, ease?: string, callback?: Function): void
    {
        if (param instanceof KMBOption)
        {
            let kmbOption = param;
            this.kmbOption = kmbOption;
            this.useKMB = true;
            this.useComma = true;
        }
        else
        {
            let useComma: boolean = param;
            this.useKMB = false;
            this.useComma = useComma;
        }

        this.Numbering(targetNumber, animateTime, ease, callback);
    }

    Numbering(targetNumber: number, animateTime?: number, ease?: string, callback?: Function)
    {
        if (animateTime == null || animateTime <= 0)
        {
            this.obj.a = targetNumber;
            this.setCurrentNumber(targetNumber);
            callback?.();
        }
        else if(Math.abs(this.obj.a - targetNumber) <= 1)
        {
            this.obj.a = targetNumber;
            this.setCurrentNumber(targetNumber);
            callback?.();
        }
        else
        {
            cc.Tween.stopAllByTarget(this.obj);

            cc.tween(this.obj).to(animateTime, { a: targetNumber }, {
                easing: ease == null ? 'linear' : ease,
                onUpdate: (() =>
                {
                    if (this.ignorZeroDecimalPoint)
                    {
                        this.obj.a = Math.trunc(this.obj.a);
                    }
                    this.setCurrentNumber(this.obj.a);
                }).bind(this)
            })
            .call(() =>
            {
                this.setCurrentNumber(targetNumber);
                callback?.();
            })
            .start();
        }
    }

    public StopNumbering()
    {
        cc.tween(this.obj).removeSelf();
    }

    // SetNumber(targetNumber: number, useComma: boolean, animateTime?: number, ease?: string, callback?: Function)
    // {
    //     this.useKMB = false;
    //     this.useComma = useComma;

    //     if (animateTime == null || animateTime == 0)
    //     {
    //         this.setCurrentNumber(targetNumber);
    //     }
    //     else
    //     {
    //         cc.log(targetNumber);

    //         let startNumber: number = this.currentNumber;
    //         this.node.stopAllActions();

    //         let interval:number = animateTime / this.changetimetick;
    //         let time: number;
    //         if (animateTime == undefined)
    //         {
    //             time = this.totalchangetime;
    //         }
    //         else
    //         {

    //         }

    //         time = animateTime;

    //         let curCount: number = 0;
    //         let repeatCountFactor = time / this.changetimetick;
    //         let repeatCount: number = Math.floor(repeatCountFactor);
    //         let changeFactor = Math.abs(targetNumber - startNumber) / repeatCountFactor;
    //         this.setCurrentNumber(startNumber);

    //         let callfunc = cc.callFunc(() => 
    //         {
    //             Math.floor를 절대값으로 하지 않으면 숫자가 작아질 경우에 targetNumber보다 숫자가 작아진다.
    //             let changeNum: number = changeFactor * curCount;
    //             반복적인 패턴이 나오지않도록 랜덤화.
    //             changeNum = Math.floor(changeNum + (changeFactor * ((Math.random() * 0.9) + 0.1)));
    //             if (targetNumber < startNumber)
    //             {
    //                 changeNum *= -1;
    //             }

    //             let num: number = startNumber + changeNum;
    //             num = CurrencyFormatHelper.getDisplayJackpotMoney(this.currentNumber, num);
    //             this.setCurrentNumber(num);

    //             ++curCount;
    //         });

    //         let action: cc.ActionInterval = cc.repeat(cc.sequence(callfunc, cc.delayTime(this.changetimetick)), repeatCount)
    //         let callbackfunc = cc.callFunc(() => 
    //         {
    //             this.setCurrentNumber(targetNumber);
    //             if (callback != null)
    //             {
    //                 callback();
    //             }
    //         });
    //         this.node.runAction(cc.sequence(action, callbackfunc));
    //     }
    // }    

    SetNumberScaleTarget(targetNode: cc.Node, targetScale: number, standardNumber: number)
    {
        this.node.stopAllActions();

        this._targetNode = targetNode;
        this._targetScale = targetScale;
        this._standardNumber = standardNumber;
    }

    stopChangeNumber()
    {
        this.node.stopAllActions();
    }

    private shakePos: cc.Vec3;

    DOShakePosition(orignPos: cc.Vec3, duration: number) 
    {
        let otarget: cc.Node = this.node;

        this.shakePos = orignPos;

        cc.tween(otarget)
            .to(0.02, { position: cc.v3(orignPos.x + 5, orignPos.y + 7, 0) })
            .to(0.02, { position: cc.v3(orignPos.x - 6, orignPos.y + 7, 0) })
            .to(0.02, { position: cc.v3(orignPos.x - 13, orignPos.y + 3, 0) })
            .to(0.02, { position: cc.v3(orignPos.x + 3, orignPos.y - 6, 0) })
            .to(0.02, { position: cc.v3(orignPos.x - 5, orignPos.y + 5, 0) })
            .to(0.02, { position: cc.v3(orignPos.x + 2, orignPos.y - 8, 0) })
            .to(0.02, { position: cc.v3(orignPos.x - 8, orignPos.y - 10, 0) })
            .to(0.02, { position: cc.v3(orignPos.x + 3, orignPos.y + 10, 0) })
            .to(0.02, { position: cc.v3(orignPos.x, orignPos.y, 0) })
            .repeatForever()
            .start();

        // otarget.runAction(
        // cc.repeatForever(
        // cc.sequence(
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x + 5, orignPos.y + 7)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x - 6, orignPos.y + 7)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x - 13,orignPos.y + 3)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x + 3, orignPos.y - 6)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x - 5, orignPos.y + 5)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x + 2, orignPos.y - 8)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x - 8, orignPos.y - 10)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x + 3, orignPos.y + 10)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x, orignPos.y))
        // )
        // )
        // );

        //this.timeOut = setTimeout(() => 
        this.nTimeOutIndex = window.setTimeout(() => 
        {
            cc.tween(otarget).removeSelf();
            // otarget.stopAllActions();
            otarget.setPosition(orignPos);
            //}, duration);
        }, duration * 1000);

        // otarget.runAction(
        // cc.repeatForever(
        // cc.sequence(
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x + 5, orignPos.y + 7)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x - 6, orignPos.y + 7)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x - 13,orignPos.y + 3)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x + 3, orignPos.y - 6)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x - 5, orignPos.y + 5)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x + 2, orignPos.y - 8)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x - 8, orignPos.y - 10)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x + 3, orignPos.y + 10)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x, orignPos.y))
        // )
        // )
        // );

        // //this.timeOut = setTimeout(() => 
        // setTimeout(() => 
        // {
        //     otarget.stopAllActions();
        //     otarget.setPosition(orignPos);
        // //}, duration);
        // }, duration * 1000);        
    }

    DOShakeStop() 
    {
        let otarget: cc.Node = this.node;

        otarget.stopAllActions();

        if (null != this.shakePos)
        {
            otarget.setPosition(this.shakePos);
        }
    }
}