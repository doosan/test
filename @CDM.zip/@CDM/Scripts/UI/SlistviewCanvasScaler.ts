import GlobalData, { ePlatformType } from "../../../Scripts/GlobalData";
import PopupSystem from "../Popup/PopupSystem";
import CoroutineComponent from "../System/CoroutineComponent";
import ResizeSystem from "../System/ResizeSystem";
import ScreenSystem from "../System/ScreenSystem";
import SingleObjects from "../System/SingleObjects";

const { ccclass, property } = cc._decorator;

@ccclass
export class SlistviewCanvasScaler extends CoroutineComponent
{
    @property(cc.Node) target : cc.Node = null;
    @property usePos : boolean = false;

    onLoad() 
    {
        ResizeSystem.Instance.AddSubEvent(this.screenAdapter.bind(this), this);
        this.screenAdapter();        
    }

    protected onEnable(): void
    {
        this.startCoroutine(this.screenAdapterCoroutine());
    }

    onDestroy()
    {
        ResizeSystem.Instance.RemoveSubEvent(this.screenAdapter.bind(this), this);
    }

    screenAdapter() 
    {        
        this.startCoroutine(this.screenAdapterCoroutine());
    }

    *screenAdapterCoroutine()
    {
        yield;
        let h : cc.Size = this.target.getContentSize();
        this.node.setContentSize(h);
        if(this.usePos)
        {
            this.node.setPosition(this.node.position.x, -h.height * 0.5);
        }
    }
}