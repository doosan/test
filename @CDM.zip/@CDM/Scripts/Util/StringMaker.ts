import { StringBuilder } from "./StringUtils";

const {ccclass, property} = cc._decorator;

export class StringInfo
{
    private sb:StringBuilder = new StringBuilder();
    public Init(): StringInfo
    {
        this.sb.buffer = [];
        return this;
    }
    public Append(value:string):StringInfo
    {
        this.sb.Append(value);
        return this;
    }
    public AppendLine(value:number=null):StringInfo
    {
        this.sb.Append("\n");
        for(let s = 0; s < value - 1; s++)
        {
            this.sb.Append("\n");
        }
        return this;
    }
    // Boxing을 방지하기 위해 object 파라미터를 가진 메서드를 막습니다.
    // public StringInfo Append(object value)
    // {
    //     sb.Append(value);
    //     return this;
    // }
    public Build():string
    {
        return this.sb.ToString();
    }
}

@ccclass
export default class StringMaker
{
    private static info:StringInfo = new StringInfo();

    public static New():StringInfo
    {
        this.info.Init();
        return this.info;
    }

    public static Get():StringInfo
    {
        return this.info;
    }
}
