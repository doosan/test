import StringUtils from "./StringUtils";

export default class CurrencyFormatHelper
{
    static formatNumber(money: number, ignorZeroDecimalPoint : boolean = true): string
    {
        let result: string = "";

        if(ignorZeroDecimalPoint)
        {
            money = Math.floor(money);
            let bMinus: boolean = money < 0;
            let loc2: string = Math.abs(money).toString();
            
            let separator = 0;
            if (bMinus == true) 
            {
                result = "-";
            }
            
            for (let i=loc2.length - 1; i>= 0 ; --i)
            {
                result = loc2[i] + result;
                ++separator;
                if (separator == 3 && i != 0)
                {
                    result = "," + result;
                    separator = 0;
                }
            }
        }
        else
        {
            let moneyInt = Math.trunc(money);
            let bMinus: boolean = money < 0;
            let loc2: string = Math.abs(moneyInt).toString();
            
            let separator = 0;
            if (bMinus == true) 
            {
                result = "-";
            }
            
            for (let i=loc2.length - 1; i>= 0 ; --i)
            {
                result = loc2[i] + result;
                ++separator;
                if (separator == 3 && i != 0)
                {
                    result = "," + result;
                    separator = 0;
                }
            }

            let moneyStr = money.toString();

            if(moneyStr.includes('.'))
            {
                let fstr = moneyStr.split('.');
                
                if(fstr.length > 1)
                {
                    result = result + "." + fstr[1];
                }
            }
            
        }
        return result;
    }

    static getEllipsisCount(money: number):number
    {
        money = Math.floor(money);
        let loc2: string = Math.abs(money).toString();
        if (loc2.length > 3 && loc2.length <= 6)
        {
            return 3;
        }
        else if (loc2.length > 6 && loc2.length <= 9)
        {
            return 6;
        }
        else if (loc2.length > 9 /* && loc2.length <= 12 */)
        {
            return 9;
        }
        return 0;
    }

    static formatEllipsisNumber(money: number, ellipsisCount?: number): string
    {
        money = Math.floor(money);
        let bMinus: boolean = money < 0;
        let loc2: string = Math.abs(money).toString();

        if (ellipsisCount === undefined)
        {
            ellipsisCount = 0;
            if (loc2.length > 3 && loc2.length <= 6)
            {
                ellipsisCount = 3;
            }
            else if (loc2.length > 6 && loc2.length <= 9)
            {
                ellipsisCount = 6;
            }
            else if (loc2.length > 9 /* && loc2.length <= 12 */)
            {
                ellipsisCount = 9;
            }
        }

        let result: string = "";
        if (ellipsisCount == 3)
        {
            result = "K";
        }
        else if (ellipsisCount == 6)
        {
            result = "M";
        }
        else if (ellipsisCount == 9)
        {
            result = "B";
        }

        let countNumber: number = 0;
        for (let i=loc2.length - 1 - ellipsisCount; i>= 0 ; --i)
        {
            if (countNumber > 0 && countNumber % 3 == 0)
            {
                result = "," + result;
            }
            result = loc2[i] + result;

            ++countNumber;
        }

        if (bMinus == true) 
        {
            result = "-" + result;
        }
        return result;
    }

    // 1000M , 천단위까지 지원해줌.
    static formatEllipsisNumberVer2(money: number): string  
    {
        money = Math.floor(money);
        let bMinus: boolean = money < 0;
        let loc2: string = Math.abs(money).toString();

        let ellipsisCount = 0;
        if (loc2.length > 4 && loc2.length <= 7)
        {
            ellipsisCount = 3;
        }
        else if (loc2.length > 7 && loc2.length <= 10)
        {
            ellipsisCount = 6;
        }
        else if (loc2.length > 10 /* && loc2.length <= 12 */)
        {
            ellipsisCount = 9;
        }

        let result: string = "";
        if (ellipsisCount == 3)
        {
            result = "K";
        }
        else if (ellipsisCount == 6)
        {
            result = "M";
        }
        else if (ellipsisCount == 9)
        {
            result = "B";
        }

        let countNumber: number = 0;
        for (let i=loc2.length - 1 - ellipsisCount; i>= 0 ; --i)
        {
            if (countNumber > 0 && countNumber % 3 == 0)
            {
                result = "," + result;
            }
            result = loc2[i] + result;

            ++countNumber;
        }

        if (bMinus == true) 
        {
            result = "-" + result;
        }
        return result;
    }

    static formatEllipsisNumberToFixed(money: number, fractionDigits: number): string 
    {
        money = Math.floor(money);
        let bMinus: boolean = money < 0;
        let loc2: string = Math.abs(money).toString();

        let result: string = "";
        if (loc2.length > 9)
        {
            let ellipsisNum = money / 1000000000;
            result = StringUtils.Format("%sB", ellipsisNum.toFixed(fractionDigits));
        }
        else if (loc2.length > 6)
        {
            let ellipsisNum = money / 1000000;
            result = StringUtils.Format("%sM", ellipsisNum.toFixed(fractionDigits));
        }
        else if (loc2.length >  3)
        {
            let ellipsisNum = money / 1000;
            result = StringUtils.Format("%sK", ellipsisNum.toFixed(fractionDigits));
        }
        
        return result;
    }

    static formatEllipsisNumberUsingDot(money: number): string
    {
        money = Math.floor(money);
        let bMinus: boolean = money < 0;
        let loc2: string = Math.abs(money).toString();
        let ellipsisCount: number = 0;

        for (let i = 1; i <= loc2.length; ++i)
        {
            if (loc2[loc2.length - i] == "0")
            {
                ++ellipsisCount;
            }
            else
            {
                break;
            }
        }

        let result: string = "";
        if (loc2.length > 9)
        {
            result = "B";
        }
        else if (loc2.length > 6)
        {
            result = "M";
        }
        else if (loc2.length >  3)
        {
            result = "K";
        }

        let minimumShowingNumberCount: number = loc2.length % 3;
        if (minimumShowingNumberCount == 0)
        {
            minimumShowingNumberCount = 3;
        }
        let startIndex: number = Math.max(minimumShowingNumberCount - 1, loc2.length - 1 - ellipsisCount);

        for (let i=startIndex; i>= 0 ; --i)
        {
            result = loc2[i] + result;

            if (loc2.length % 3 == 0 && i == 3)
            {
                result = "." + result;
            }
            else if (loc2.length % 3 != 0 && loc2.length % 3 == i)
            {
                result = "." + result;
            }
        }

        if (bMinus == true) {
            result = "-" + result;
        }
        return result;
    }

    // 1st, 2nd, 3rd, ...
    static ordinalNumberPostfix = ["th","st","nd","rd"];
    static formatOrdinalNumber(num: number): string
    {
        let v=num%100;
        let postfix = CurrencyFormatHelper.ordinalNumberPostfix;
        return num+(postfix[(v-20)%10]||postfix[v]||postfix[0]);
    }

    static formatOrdinalNumberUppercase(num: number):   string
    {
        return CurrencyFormatHelper.formatOrdinalNumber(num).toUpperCase();
    }

    static getOrdinalNumberPostfix(num: number): string    
    {
        let v=num%100;
        let postfix = CurrencyFormatHelper.ordinalNumberPostfix;
        return (postfix[(v-20)%10]||postfix[v]||postfix[0]);
    }


    // prevJackpotMoney와 200이상 차이가 난다면, 뒤의 두자리는 prevJackpotMoney의 뒤 두자리에 11을 더한값으로 하자.
    // ex money = 9999, prevMoney = 8012  => money = 9923 으로 display한다.
    static getDisplayJackpotMoney(prevMoney:number, money:number) 
    {
        let gap:number = money - prevMoney;
        // Todo. gap에 따라서 변화량이 다르게 해야할듯.
        // 12222
        // 21945
        // => 23434 <== 이런식이면 어떨까??
        if (gap > 20) 
        {
            var lastNumber = Math.floor(prevMoney % 100 + 11) % 100;
            if (lastNumber == 11) 
            {
                lastNumber = 10;
            }
            money = (Math.floor(money / 100) * 100) + (lastNumber);
        }
        else if (gap > 1) 
        {
            var lastNumber = Math.floor(prevMoney % 10 + 1) % 10;
            money = (Math.floor(money / 10) * 10) + (lastNumber);
        }
        return money;
    }
}