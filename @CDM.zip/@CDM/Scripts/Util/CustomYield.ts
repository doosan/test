import { Coroutine, WaitUntil, WaitWhile } from "../System/CoroutineComponent";
import CustomYieldInstruction from "./CustomYieldInstruction";
import StringUtils from "./StringUtils";

export class WaitForComplete extends CustomYieldInstruction
{
    public OnCompleteEvent: Function = null;

    public ErrorMessage: string = '';
    public ErrorCode: number = 0;
    public get HasError(): boolean { return this.ErrorCode > 0 || StringUtils.IsNullOrEmpty(this.ErrorMessage) == false; }
    public IsCancelled: boolean
    public get IsSuccess(): boolean { return this.IsDone && !this.HasError && !this.IsCancelled; }
    public IsDone: boolean = false;

    public ccThis : any = null;

    public constructor()
    {
        super();
        this.Ready();
    }

    public Ready(cThis?): void
    {
        this.IsDone = false;

        if(cThis!=null)
        {
            this.ccThis = cThis;
            this.coroutine = this.ccThis.startCoroutine(this.ReadyCoroutine(), cThis);
        }
    }

    *ReadyCoroutine()
    {
        yield new WaitUntil(() => this.IsDone);
    }

    //public Fail(errorMessage : string) : void;
    //public Fail(errorCode : number) : void;
    public Fail(param1?: any, param2?: number): void
    {
        if (param1 == null)
        {
            this.Fail("Failed", 0);
        }
        else if (param2 != null)
        {
            this.ErrorMessage = param1;
            this.ErrorCode = param2;

            this.Done();
        }
        else if (typeof param1 === "string")
        {
            this.Fail(param1, 0);
        }
        else
        {
            this.Fail('', param2);
        }
    }

    public Done(): void
    {
        if(this.coroutine!=null && this.ccThis !=null)
        {            
            this.ccThis.stopCoroutine(this.coroutine);
        }
        this.IsDone = true;

        this.InvokeCallback();
    }

    public InvokeCallback(): void
    {
        if (this.OnCompleteEvent != null)
        {
            this.OnCompleteEvent(this);
            this.OnCompleteEvent = null;
        }
    }

    public override get keepWaiting(): boolean
    {
        return !this.IsDone;
    }

    public get progress(): number
    {
        return this.IsDone ? 1 : 0;
    }
}

export class SimpleWaitForDone extends CustomYieldInstruction
{
    public override get keepWaiting(): boolean
    {
        return this.waitForDone;
    }
    private waitForDone: boolean = false;
    public onKeepWaiting : Function = null;

    public ccThis : any = null;

    public constructor()
    {
        super();
        this.Ready();
    }

    public Ready(cThis?): void
    {
        this.waitForDone = true;

        if(cThis!=null)
        {
            this.ccThis = cThis;
            this.coroutine = this.ccThis.startCoroutine(this.ReadyCoroutine(), cThis);
            this.onKeepWaiting?.(this.waitForDone);
        }
    }

    *ReadyCoroutine()
    {
        yield new WaitWhile(() => this.waitForDone);
    }

    public Done(): void
    {
        if(this.coroutine!=null && this.ccThis !=null)
        {
            this.ccThis.stopCoroutine(this.coroutine);
            this.onKeepWaiting?.(this.waitForDone);
        }
        this.waitForDone = false;
    }


    // public Ready(cThis?): void
    // {
    //     this.waitForDone = true;

    //     if(cThis!=null)
    //     {
    //         this.coroutine = this.startCoroutine(this.ReadyCoroutine(), cThis);
    //     }
    // }

    // *ReadyCoroutine()
    // {
    //     yield new WaitWhile(() => this.waitForDone);
    // }

    // public Ready(): void
    // {
    //     this.waitForDone = true;
    // }

    // public Done(): void
    // {
    //     this.waitForDone = false;
    // }
}

export abstract class Generic<T> extends CustomYieldInstruction
{
    public OnCompleteEvent: Function;

    public ErrorMessage: string;
    public ErrorCode: number;

    public get HasError(): boolean { return this.ErrorCode > 0 || StringUtils.IsNullOrEmpty(this.ErrorMessage) == false; }
    public IsCancelled: boolean;
    public get IsSuccess(): boolean { return this.IsDone && !this.HasError && !this.IsCancelled; }
    public IsDone: boolean;

    protected constructor()
    {
        super();
        this.Ready();
    }

    public Ready(): void
    {
        this.IsDone = false;
    }

    public Fail(param1?: any, param2?: number): void
    {
        if (param1 == null)
        {
            this.Fail("Failed", 0);
        }
        else if (param2 != null)
        {
            this.ErrorMessage = param1;
            this.ErrorCode = param2;

            this.Done();
        }
        else if (typeof param1 === "string")
        {
            this.Fail(param1, 0);
        }
        else
        {
            this.Fail('', param2);
        }
    }

    public Cancel(): void
    {
        this.IsCancelled = true;

        this.Done();
    }

    public Done(): void
    {
        this.IsDone = true;

        this.InvokeCallback();
    }

    public InvokeCallback(): void
    {
        if (this.OnCompleteEvent != null)
        {
            this.OnCompleteEvent(this);
            this.OnCompleteEvent = null;
        }
    }

    public override get keepWaiting(): boolean
    {
        return this.IsDone;
    }

    public get progress(): number
    {
        return this.IsDone ? 1 : 0;
    }
}