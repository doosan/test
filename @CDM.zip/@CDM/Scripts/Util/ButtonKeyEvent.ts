import PopupSystem from "../Popup/PopupSystem";

const { ccclass, property } = cc._decorator;

export enum ekeyCode
{
    // none = 0,
    // back = 6,
    // menu = 18,
    backspace = 8,
    // tab = 9,
    // enter = 13,
    // shift = 16,
    // ctrl = 17,
    // alt = 18,
    // pause = 19,
    // capslock = 20,
    // escape = 27,
    space = 32,
    // pageup = 33,
    // pagedown = 34,
    // end = 35,
    // home = 36,
    // left = 37,
    // up = 38,
    // right = 39,
    // down = 40,
    // select = 41,
    // insert = 45,
    // Delete = 46,
}

@ccclass
export default class ButtonKeyEvent extends cc.Component 
{
    @property({ type: cc.Enum(ekeyCode) }) keyCode: ekeyCode = ekeyCode.space;
    @property isChceckPopup : boolean = false;

    private button: cc.Button = null;
    private keyDown: boolean = false;

    public isAvailable: boolean = true;

    private get Button(): cc.Button
    {
        if (this.button == null)
        {
            this.button = this.getComponent(cc.Button);
        }
        return this.button;
    }

    onLoad()
    {
        if (!cc.sys.isMobile)
        {
            cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.OnKeyDown, this);
            cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, this.OnKeyUp, this);
        }
    }

    private OnKeyDown(event : cc.Event.EventKeyboard)
    {
        if(!this.isAvailable)
        {
            return;
        }

        if(this.isChceckPopup)
        {
            if(PopupSystem.Instance.Count > 0)
            {
                return;
            }
        }

        switch (event.keyCode) 
        {
            case this.keyCode:
                if (!this.keyDown)
                {
                    if (this.Button.node.activeInHierarchy)
                    {
                        this.Button.node.dispatchEvent(new cc.Event.EventCustom(cc.Node.EventType.TOUCH_START, true));
                    }
                }
                this.keyDown = true;
                break;
        }
    }

    private OnKeyUp(event : cc.Event.EventKeyboard)
    {
        if(!this.isAvailable)
        {
            return;
        }
        
        switch (event.keyCode) 
        {
            case this.keyCode:
                if (this.keyDown)
                {
                    if (this.Button.node.activeInHierarchy)
                    {
                        this.Button.node.dispatchEvent(new cc.Event.EventCustom(cc.Node.EventType.TOUCH_END, true));
                    }
                }
                this.keyDown = false;
                break;
        }
    }
}
