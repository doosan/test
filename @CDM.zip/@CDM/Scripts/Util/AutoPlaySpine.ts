const {ccclass, property, menu} = cc._decorator;

@ccclass
@menu("Util/AutoPlaySpine")
export default class AutoPlaySpine extends cc.Component 
{
    private spine : sp.Skeleton = null;
    private onComplete : Function = null;
    public set OnComplete(value : Function)
    {
        this.onComplete = value;
    }

    private get Spine() : sp.Skeleton
    {
        if(this.spine == null)
        {
            this.spine = this.getComponent(sp.Skeleton);
        }

        return this.spine;
    }

    protected onEnable(): void
    {
        if(this.Spine == null)
        {
            cc.error(this.node.name + " : 스파인이 없습니다");
            return;
        }
        
        this.Spine.setAnimation(0, this.Spine.animation, this.Spine.loop);

        if(this.onComplete!=null)
        {
            this.Spine.setCompleteListener(()=>
            {
                this.onComplete?.();
                this.Spine.setCompleteListener(null);
            })
        }
    }
}