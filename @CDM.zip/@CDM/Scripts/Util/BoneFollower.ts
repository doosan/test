import StringUtils from "./StringUtils";

const {ccclass, property, menu, requireComponent} = cc._decorator;

@ccclass
@menu("Util/BoneFollower")
export class BoneFollower extends cc.Component 
{	
	//#region Inspector
	@property(sp.Skeleton) public skeletonRenderer:sp.Skeleton = null;
	public get SkeletonRenderer(): sp.Skeleton 
	{
		return this.skeletonRenderer; 
	}

	public set SkeletonRenderer(value:sp.Skeleton)
	{
		this.skeletonRenderer = value;
		this.Initialize();
	}		

	/// <summary>If a bone isn't set in code, boneName is used to find the bone at the beginning. For runtime switching by name, use SetBoneByName. You can also set the BoneFollower.bone field directly.</summary>
	//[SpineBone(dataField: "skeletonRenderer")]
	@property() public boneName:string = "";

	@property() public followXYPosition:boolean = true;
	@property() public followZPosition:boolean = true;
	@property() public followBoneRotation:boolean = true;

	//[Tooltip("Follows the skeleton's flip state by controlling this Transform's local scale.")]
	@property() public followSkeletonFlip:boolean = true;

	//[Tooltip("Follows the target bone's local scale. BoneFollower cannot inherit world/skewed scale because of UnityEngine.Transform property limitations.")]
	@property() public  followLocalScale:boolean = false;

	//[UnityEngine.Serialization.FormerlySerializedAs("resetOnAwake")]
	@property() public initializeOnAwake:boolean = true;
	//#endregion

	public valid:boolean = false;
	public bone:sp.spine.Bone;

	private skeletonTransform:cc.Node;
	private skeletonTransformIsParent:boolean = true;

	/// <summary>
	/// Sets the target bone by its bone name. Returns false if no bone was found. To set the bone by reference, use BoneFollower.bone directly.</summary>
	public SetBone (name:string):boolean 
	{
		this.bone = this.skeletonRenderer.findBone(name);
		
		if (this.bone == null) 
		{
			cc.error("Bone not found: " + name, this);
			return false;
		}
		this.boneName = name;
		return true;
	}

	onLoad () 
	{
		if (this.initializeOnAwake) 
		{
			this.Initialize();
		}
	}

	public HandleRebuildRenderer ( skeletonRenderer:sp.Skeleton):void
	{
		this.Initialize();
	}

	public Initialize ():void 
	{
		this.bone = null;
		this.valid = this.skeletonRenderer != null && this.skeletonRenderer.isValid;
		if (!this.valid) 
		{
			return;
		}

		this.skeletonTransform = this.skeletonRenderer.node;
		// this.skeletonRenderer.OnRebuild -= this.HandleRebuildRenderer;
		// this.skeletonRenderer.OnRebuild += this.HandleRebuildRenderer;
		// this.skeletonTransformIsParent = Transform.ReferenceEquals(skeletonTransform, transform.parent);

		if (!StringUtils.IsNullOrEmpty(this.boneName))
		{
			this.bone = this.skeletonRenderer.findBone(this.boneName);
		}

		//#if UNITY_EDITOR
		// if (Application.isEditor)
		this.lateUpdate();
		//#endif
	}

	onDestroy()
	{
		// if (this.skeletonRenderer != null)
		// {
		// 	this.skeletonRenderer.OnRebuild -= this.HandleRebuildRenderer;	
		// }
	}

	lateUpdate()
	{
		if (!this.valid) 
		{
			this.Initialize();
			return;
		}

		// #if UNITY_EDITOR
		// if (!Application.isPlaying)
		// 	skeletonTransformIsParent = Transform.ReferenceEquals(skeletonTransform, transform.parent);
		// #endif

		if (this.bone == null) 
		{
			if (StringUtils.IsNullOrEmpty(this.boneName)) 
			{
				return;
			}

			this.bone = this.skeletonRenderer.findBone(this.boneName);
			if (!this.SetBone(this.boneName)) 
			{
				return;
			}
		}

		let thisTransform:cc.Node = this.node;
		if(this.skeletonRenderer)
			if(!this.skeletonRenderer.node.active)	return;
		if (this.skeletonTransformIsParent) 
		{
			// Recommended setup: Use local transform properties if Spine GameObject is the immediate parent
			let NewPos = new cc.Vec3(this.followXYPosition ? this.bone.worldX : thisTransform.position.x,
					  							 this.followXYPosition ? this.bone.worldY : thisTransform.position.y,
												 this.followZPosition ? 0 : thisTransform.position.z);

			thisTransform.setPosition(NewPos);

			if (this.followBoneRotation) 
			{
				let halfRotation = Math.atan2(this.bone.c, this.bone.a) * 0.5;

				// Negate rotation from negative scaleX. Don't use negative determinant. local scaleY doesn't factor into used rotation.
				if (this.followLocalScale && this.bone.scaleX < 0) 
				{
					halfRotation += Math.PI * 0.5;
				}

				// let q = default(Quaternion);				
				// q.z = Math.sin(halfRotation);				
				// q.w = Math.cos(halfRotation);				
				// thisTransform.localRotation = q;
			}
		}
		// else 
		// {
		// 	// For special cases: Use transform world properties if transform relationship is complicated
		// 	let targetWorldPosition:cc.Vec3 = MathUtility.TransformPoint(this.skeletonTransform.position, new cc.Vec3(this.bone.worldX, this.bone.worldY, 0));
			
		// 	if (!this.followZPosition) 
		// 	{
		// 		targetWorldPosition.z = thisTransform.position.z;
		// 	}

		// 	if (!this.followXYPosition) 
		// 	{
		// 		targetWorldPosition.x = thisTransform.position.x;
		// 		targetWorldPosition.y = thisTransform.position.y;
		// 	}

		// 	let boneWorldRotation = this.bone.worldToLocalRotation.WorldRotationX;

		// 	let transformParent:cc.Node = thisTransform.parent;
		// 	if (transformParent != null) 
		// 	{
		// 		//let m:cc.Mat4 = transformParent.localToWorldMatrix;

		// 		let worldToNodeTransform:cc.Mat4 = new cc.Mat4(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
		// 		worldToNodeTransform = transformParent.getWorldMatrix(worldToNodeTransform);

		// 		if (worldToNodeTransform.m00 * m.m11 - m.m01 * m.m10 < 0) // Determinant2D is negative
		// 		{
		// 			boneWorldRotation = -boneWorldRotation;
		// 		}
		// 	}

		// 	if (this.followBoneRotation) 
		// 	{
		// 		let worldRotation = this.skeletonTransform.eulerAngles;//.rotation.eulerAngles;
		// 		if (this.followLocalScale && this.bone.scaleX < 0) 
		// 		{
		// 			boneWorldRotation += 180;
		// 		}
		// 		let rotA : cc.Quat = new cc.Quat();
		// 		rotA = cc.Quat.fromEuler(rotA, worldRotation.x, worldRotation.y, worldRotation.z + boneWorldRotation);

		// 		thisTransform.position = targetWorldPosition;
		// 		thisTransform.setRotation(rotA);
		// 		//thisTransform.SetPositionAndRotation(targetWorldPosition, );
		// 	} 
		// 	else 
		// 	{
		// 		thisTransform.position = targetWorldPosition;
		// 	}
		// }

		let localScale = this.followLocalScale ? new cc.Vec3(this.bone.scaleX, this.bone.scaleY, 1) : new cc.Vec3(1, 1, 1);
		
		if (this.followSkeletonFlip) 
		{
			localScale.y *= Math.sign(this.bone.skeleton.scaleX * this.bone.skeleton.scaleY);
		}

		thisTransform.setScale(localScale);
	}
}