/*
 * Created by C.J. Kimberlin
 * 
 * The MIT License (MIT)
 * 
 * Copyright (c) 2019
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * 
 * 
 * TERMS OF USE - EASING EQUATIONS
 * Open source under the BSD License.
 * Copyright (c)2001 Robert Penner
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 * Neither the name of the author nor the names of contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *
 * ============= Description =============
 *
 * Below is an example of how to use the easing functions in the file. There is a getting function that will return the function
 * from an enum. This is useful since the enum can be exposed in the editor and then the function queried during Start().
 * 
 * EasingFunction.Ease ease = EasingFunction.Ease.EaseInOutQuad;
 * EasingFunction.EasingFunc func = GetEasingFunction(ease;
 * 
 * float value = func(0, 10, 0.67f);
 * 
 * EasingFunction.EaseingFunc derivativeFunc = GetEasingFunctionDerivative(ease);
 * 
 * float derivativeValue = derivativeFunc(0, 10, 0.67f);
 */

export enum Ease
{
    Unset          ,
    linear         , 
    sineIn         ,
    sineOut        ,
    sineInOut      ,
    quadIn         ,
    quadOut        ,
    quadInOut      ,
    cubicIn        ,
    cubicOut       ,
    cubicInOut     ,
    quartIn        ,
    quartOut       ,
    quartInOut     ,
    quintIn        ,
    quintOut       ,
    quintInOut     ,
    expoIn         ,
    expoOut        ,
    expoInOut      ,
    circIn         ,
    circOut        ,
    circInOut      ,
    elasticIn      ,
    elasticOut     ,
    elasticInOut   ,
    backIn         ,
    backOut        ,
    backInOut      ,
    bounceIn       ,
    bounceOut      ,
    bounceInOut    ,

}



// export class EaseConvert
// {
//     static ConvertToCocosEnum(unityEnum:Ease) : string
//     {
//         switch(unityEnum)
//         {
//             case Ease.Unset:
//                 return "Unset";
//             case Ease.Linear:
//                 return "Linear";
//             case Ease.sineIn:
//                 return "sineIn";
//             case Ease.sineOut:
//                 return "sineOut";
//             case Ease.sineInOut:
//                 return "sineInOut";
//             case Ease.quadIn:
//                 return "quadIn";
//             case Ease.quadOut:
//                 return "quadOut";
//             case Ease.quadInOut:
//                 return "quadInOut";
//             case Ease.cubicIn:
//                 return "cubicIn";
//             case Ease.cubicOut:
//                 return "cubicOut";

//             default:
//                 break;
//         }

//         return "";
//     }
// }

export default class EasingFunction
{
    private static readonly NATURAL_LOG_OF_2: number = 0.693147181;
    static Ease: any;

    //
    // Easing functions
    //

    public static Linear(start: number, end: number, value: number): number
    {
        return cc.misc.lerp(start, end, value);
    }

    public static Spring(start: number, end: number, value: number): number
    {
        value = cc.misc.clamp01(value);
        value = (Math.sin(value * Math.PI * (0.2 + 2.5 * value * value * value)) * Math.pow(1 - value, 2.2) + value) * (1 + (1.2 * (1 - value)));
        return start + (end - start) * value;
    }

    public static EaseInQuad(start: number, end: number, value: number): number
    {
        end -= start;
        return end * value * value + start;
    }

    public static EaseOutQuad(start: number, end: number, value: number): number
    {
        end -= start;
        return -end * value * (value - 2) + start;
    }

    public static EaseInOutQuad(start: number, end: number, value: number): number
    {
        value /= .5;
        end -= start;
        if (value < 1) return end * 0.5 * value * value + start;
        value--;
        return -end * 0.5 * (value * (value - 2) - 1) + start;
    }

    public static EaseInCubic(start: number, end: number, value: number): number
    {
        end -= start;
        return end * value * value * value + start;
    }

    public static EaseOutCubic(start: number, end: number, value: number): number
    {
        value--;
        end -= start;
        return end * (value * value * value + 1) + start;
    }

    public static EaseInOutCubic(start: number, end: number, value: number): number
    {
        value /= .5;
        end -= start;
        if (value < 1) return end * 0.5 * value * value * value + start;
        value -= 2;
        return end * 0.5 * (value * value * value + 2) + start;
    }

    public static EaseInQuart(start: number, end: number, value: number): number
    {
        end -= start;
        return end * value * value * value * value + start;
    }

    public static EaseOutQuart(start: number, end: number, value: number): number
    {
        value--;
        end -= start;
        return -end * (value * value * value * value - 1) + start;
    }

    public static EaseInOutQuart(start: number, end: number, value: number): number
    {
        value /= .5;
        end -= start;
        if (value < 1) return end * 0.5 * value * value * value * value + start;
        value -= 2;
        return -end * 0.5 * (value * value * value * value - 2) + start;
    }

    public static EaseInQuint(start: number, end: number, value: number): number
    {
        end -= start;
        return end * value * value * value * value * value + start;
    }

    public static EaseOutQuint(start: number, end: number, value: number): number
    {
        value--;
        end -= start;
        return end * (value * value * value * value * value + 1) + start;
    }

    public static EaseInOutQuint(start: number, end: number, value: number): number
    {
        value /= .5;
        end -= start;
        if (value < 1) return end * 0.5 * value * value * value * value * value + start;
        value -= 2;
        return end * 0.5 * (value * value * value * value * value + 2) + start;
    }

    public static EaseInSine(start: number, end: number, value: number): number
    {
        end -= start;
        return -end * Math.cos(value * (Math.PI * 0.5)) + end + start;
    }

    public static EaseOutSine(start: number, end: number, value: number): number
    {
        end -= start;
        return end * Math.sin(value * (Math.PI * 0.5)) + start;
    }

    public static EaseInOutSine(start: number, end: number, value: number): number
    {
        end -= start;
        return -end * 0.5 * (Math.cos(Math.PI * value) - 1) + start;
    }

    public static EaseInExpo(start: number, end: number, value: number): number
    {
        end -= start;
        return end * Math.pow(2, 10 * (value - 1)) + start;
    }

    public static EaseOutExpo(start: number, end: number, value: number): number
    {
        end -= start;
        return end * (-Math.pow(2, -10 * value) + 1) + start;
    }

    public static EaseInOutExpo(start: number, end: number, value: number): number
    {
        value /= .5;
        end -= start;
        if (value < 1) return end * 0.5 * Math.pow(2, 10 * (value - 1)) + start;
        value--;
        return end * 0.5 * (-Math.pow(2, -10 * value) + 2) + start;
    }

    public static EaseInCirc(start: number, end: number, value: number): number
    {
        end -= start;
        return -end * (Math.sqrt(1 - value * value) - 1) + start;
    }

    public static EaseOutCirc(start: number, end: number, value: number): number
    {
        value--;
        end -= start;
        return end * Math.sqrt(1 - value * value) + start;
    }

    public static EaseInOutCirc(start: number, end: number, value: number): number
    {
        value /= .5;
        end -= start;
        if (value < 1) return -end * 0.5 * (Math.sqrt(1 - value * value) - 1) + start;
        value -= 2;
        return end * 0.5 * (Math.sqrt(1 - value * value) + 1) + start;
    }

    public static EaseInBounce(start: number, end: number, value: number): number
    {
        end -= start;
        let d: number = 1;
        return end - this.EaseOutBounce(0, end, d - value) + start;
    }

    public static EaseOutBounce(start: number, end: number, value: number): number
    {
        value /= 1;
        end -= start;
        if (value < (1 / 2.75))
        {
            return end * (7.5625 * value * value) + start;
        }
        else if (value < (2 / 2.75))
        {
            value -= (1.5 / 2.75);
            return end * (7.5625 * (value) * value + .75) + start;
        }
        else if (value < (2.5 / 2.75))
        {
            value -= (2.25 / 2.75);
            return end * (7.5625 * (value) * value + .9375) + start;
        }
        else
        {
            value -= (2.625 / 2.75);
            return end * (7.5625 * (value) * value + .984375) + start;
        }
    }

    public static EaseInOutBounce(start: number, end: number, value: number): number
    {
        end -= start;
        let d: number = 1;
        if (value < d * 0.5) return this.EaseInBounce(0, end, value * 2) * 0.5 + start;
        else return this.EaseOutBounce(0, end, value * 2 - d) * 0.5 + end * 0.5 + start;
    }

    public static EaseInBack(start: number, end: number, value: number): number
    {
        end -= start;
        value /= 1;
        let s: number = 1.70158;
        return end * (value) * value * ((s + 1) * value - s) + start;
    }

    public static EaseOutBack(start: number, end: number, value: number): number
    {
        let s: number = 1.70158;
        end -= start;
        value = (value) - 1;
        return end * ((value) * value * ((s + 1) * value + s) + 1) + start;
    }

    public static EaseInOutBack(start: number, end: number, value: number): number
    {
        let s: number = 1.70158;
        end -= start;
        value /= .5;
        if ((value) < 1)
        {
            s *= (1.525);
            return end * 0.5 * (value * value * (((s) + 1) * value - s)) + start;
        }
        value -= 2;
        s *= (1.525);
        return end * 0.5 * ((value) * value * (((s) + 1) * value + s) + 2) + start;
    }

    public static EaseInElastic(start: number, end: number, value: number): number
    {
        end -= start;

        let d: number = 1;
        let p: number = d * .3;
        let s: number;
        let a: number = 0;

        if (value == 0) return start;

        if ((value /= d) == 1) return start + end;

        if (a == 0 || a < Math.abs(end))
        {
            a = end;
            s = p / 4;
        }
        else
        {
            s = p / (2 * Math.PI) * Math.asin(end / a);
        }

        return -(a * Math.pow(2, 10 * (value -= 1)) * Math.sin((value * d - s) * (2 * Math.PI) / p)) + start;
    }

    public static EaseOutElastic(start: number, end: number, value: number): number
    {
        end -= start;

        let d: number = 1;
        let p: number = d * .3;
        let s: number;
        let a: number = 0;

        if (value == 0) return start;

        if ((value /= d) == 1) return start + end;

        if (a == 0 || a < Math.abs(end))
        {
            a = end;
            s = p * 0.25;
        }
        else
        {
            s = p / (2 * Math.PI) * Math.asin(end / a);
        }

        return (a * Math.pow(2, -10 * value) * Math.sin((value * d - s) * (2 * Math.PI) / p) + end + start);
    }

    public static EaseInOutElastic(start: number, end: number, value: number): number
    {
        end -= start;

        let d: number = 1;
        let p: number = d * .3;
        let s: number;
        let a: number = 0;

        if (value == 0) return start;

        if ((value /= d * 0.5) == 2) return start + end;

        if (a == 0 || a < Math.abs(end))
        {
            a = end;
            s = p / 4;
        }
        else
        {
            s = p / (2 * Math.PI) * Math.asin(end / a);
        }

        if (value < 1) return -0.5 * (a * Math.pow(2, 10 * (value -= 1)) * Math.sin((value * d - s) * (2 * Math.PI) / p)) + start;
        return a * Math.pow(2, -10 * (value -= 1)) * Math.sin((value * d - s) * (2 * Math.PI) / p) * 0.5 + end + start;
    }

    //
    // These are derived functions that the motor can use to get the speed at a specific time.
    //
    // The easing functions all work with a normalized time (0 to 1) and the returned value here
    // reflects that. Values returned here should be divided by the actual time.
    //
    // TODO: These functions have not had the testing they deserve. If there is odd behavior around
    //       dash speeds then this would be the first place I'd look.

    public static LinearD(start: number, end: number, value: number): number
    {
        return end - start;
    }

    public static EaseInQuadD(start: number, end: number, value: number): number
    {
        return 2 * (end - start) * value;
    }

    public static EaseOutQuadD(start: number, end: number, value: number): number
    {
        end -= start;
        return -end * value - end * (value - 2);
    }

    public static EaseInOutQuadD(start: number, end: number, value: number): number
    {
        value /= .5;
        end -= start;

        if (value < 1)
        {
            return end * value;
        }

        value--;

        return end * (1 - value);
    }

    public static EaseInCubicD(start: number, end: number, value: number): number
    {
        return 3 * (end - start) * value * value;
    }

    public static EaseOutCubicD(start: number, end: number, value: number): number
    {
        value--;
        end -= start;
        return 3 * end * value * value;
    }

    public static EaseInOutCubicD(start: number, end: number, value: number): number
    {
        value /= .5;
        end -= start;

        if (value < 1)
        {
            return (3 / 2) * end * value * value;
        }

        value -= 2;

        return (3 / 2) * end * value * value;
    }

    public static EaseInQuartD(start: number, end: number, value: number): number
    {
        return 4 * (end - start) * value * value * value;
    }

    public static EaseOutQuartD(start: number, end: number, value: number): number
    {
        value--;
        end -= start;
        return -4 * end * value * value * value;
    }

    public static EaseInOutQuartD(start: number, end: number, value: number): number
    {
        value /= .5;
        end -= start;

        if (value < 1)
        {
            return 2 * end * value * value * value;
        }

        value -= 2;

        return -2 * end * value * value * value;
    }

    public static EaseInQuintD(start: number, end: number, value: number): number
    {
        return 5 * (end - start) * value * value * value * value;
    }

    public static EaseOutQuintD(start: number, end: number, value: number): number
    {
        value--;
        end -= start;
        return 5 * end * value * value * value * value;
    }

    public static EaseInOutQuintD(start: number, end: number, value: number): number
    {
        value /= .5;
        end -= start;

        if (value < 1)
        {
            return (5 / 2) * end * value * value * value * value;
        }

        value -= 2;

        return (5 / 2) * end * value * value * value * value;
    }

    public static EaseInSineD(start: number, end: number, value: number): number
    {
        return (end - start) * 0.5 * Math.PI * Math.sin(0.5 * Math.PI * value);
    }

    public static EaseOutSineD(start: number, end: number, value: number): number
    {
        end -= start;
        return (Math.PI * 0.5) * end * Math.cos(value * (Math.PI * 0.5));
    }

    public static EaseInOutSineD(start: number, end: number, value: number): number
    {
        end -= start;
        return end * 0.5 * Math.PI * Math.sin(Math.PI * value);
    }
    public static EaseInExpoD(start: number, end: number, value: number): number
    {
        return (10 * this.NATURAL_LOG_OF_2 * (end - start) * Math.pow(2, 10 * (value - 1)));
    }

    public static EaseOutExpoD(start: number, end: number, value: number): number
    {
        end -= start;
        return 5 * this.NATURAL_LOG_OF_2 * end * Math.pow(2, 1 - 10 * value);
    }

    public static EaseInOutExpoD(start: number, end: number, value: number): number
    {
        value /= .5;
        end -= start;

        if (value < 1)
        {
            return 5 * this.NATURAL_LOG_OF_2 * end * Math.pow(2, 10 * (value - 1));
        }

        value--;

        return (5 * this.NATURAL_LOG_OF_2 * end) / (Math.pow(2, 10 * value));
    }

    public static EaseInCircD(start: number, end: number, value: number): number
    {
        return ((end - start) * value) / Math.sqrt(1 - value * value);
    }

    public static EaseOutCircD(start: number, end: number, value: number): number
    {
        value--;
        end -= start;
        return (-end * value) / Math.sqrt(1 - value * value);
    }

    public static EaseInOutCircD(start: number, end: number, value: number): number
    {
        value /= .5;
        end -= start;

        if (value < 1)
        {
            return (end * value) / (2 * Math.sqrt(1 - value * value));
        }

        value -= 2;

        return (-end * value) / (2 * Math.sqrt(1 - value * value));
    }

    public static EaseInBounceD(start: number, end: number, value: number): number
    {
        end -= start;
        let d: number = 1;

        return this.EaseOutBounceD(0, end, d - value);
    }

    public static EaseOutBounceD(start: number, end: number, value: number): number
    {
        value /= 1;
        end -= start;

        if (value < (1 / 2.75))
        {
            return 2 * end * 7.5625 * value;
        }
        else if (value < (2 / 2.75))
        {
            value -= (1.5 / 2.75);
            return 2 * end * 7.5625 * value;
        }
        else if (value < (2.5 / 2.75))
        {
            value -= (2.25 / 2.75);
            return 2 * end * 7.5625 * value;
        }
        else
        {
            value -= (2.625 / 2.75);
            return 2 * end * 7.5625 * value;
        }
    }

    public static EaseInOutBounceD(start: number, end: number, value: number): number
    {
        end -= start;
        let d: number = 1;

        if (value < d * 0.5)
        {
            return this.EaseInBounceD(0, end, value * 2) * 0.5;
        }
        else
        {
            return this.EaseOutBounceD(0, end, value * 2 - d) * 0.5;
        }
    }

    public static EaseInBackD(start: number, end: number, value: number): number
    {
        let s: number = 1.70158;

        return 3 * (s + 1) * (end - start) * value * value - 2 * s * (end - start) * value;
    }

    public static EaseOutBackD(start: number, end: number, value: number): number
    {
        let s: number = 1.70158;
        end -= start;
        value = (value) - 1;

        return end * ((s + 1) * value * value + 2 * value * ((s + 1) * value + s));
    }

    public static EaseInOutBackD(start: number, end: number, value: number): number
    {
        let s: number = 1.70158;
        end -= start;
        value /= .5;

        if ((value) < 1)
        {
            s *= (1.525);
            return 0.5 * end * (s + 1) * value * value + end * value * ((s + 1) * value - s);
        }

        value -= 2;
        s *= (1.525);
        return 0.5 * end * ((s + 1) * value * value + 2 * value * ((s + 1) * value + s));
    }

    public static EaseInElasticD(start: number, end: number, value: number): number
    {
        return this.EaseOutElasticD(start, end, 1 - value);
    }

    public static EaseOutElasticD(start: number, end: number, value: number): number
    {
        end -= start;

        let d: number = 1;
        let p: number = d * .3;
        let s: number;
        let a: number = 0;

        if (a == 0 || a < Math.abs(end))
        {
            a = end;
            s = p * 0.25;
        }
        else
        {
            s = p / (2 * Math.PI) * Math.asin(end / a);
        }

        return (a * Math.PI * d * Math.pow(2, 1 - 10 * value) *
            Math.cos((2 * Math.PI * (d * value - s)) / p)) / p - 5 * this.NATURAL_LOG_OF_2 * a *
            Math.pow(2, 1 - 10 * value) * Math.sin((2 * Math.PI * (d * value - s)) / p);
    }

    public static EaseInOutElasticD(start: number, end: number, value: number): number
    {
        end -= start;

        let d: number = 1;
        let p: number = d * .3;
        let s: number;
        let a: number = 0;

        if (a == 0 || a < Math.abs(end))
        {
            a = end;
            s = p / 4;
        }
        else
        {
            s = p / (2 * Math.PI) * Math.asin(end / a);
        }

        if (value < 1)
        {
            value -= 1;

            return -5 * this.NATURAL_LOG_OF_2 * a * Math.pow(2, 10 * value) * Math.sin(2 * Math.PI * (d * value - 2) / p) -
                a * Math.PI * d * Math.pow(2, 10 * value) * Math.cos(2 * Math.PI * (d * value - s) / p) / p;
        }

        value -= 1;

        return a * Math.PI * d * Math.cos(2 * Math.PI * (d * value - s) / p) / (p * Math.pow(2, 10 * value)) -
            5 * this.NATURAL_LOG_OF_2 * a * Math.sin(2 * Math.PI * (d * value - s) / p) / (Math.pow(2, 10 * value));
    }

    public static SpringD(start: number, end: number, value: number): number
    {
        value = cc.misc.clamp01(value);
        end -= start;

        // Damn... Thanks http://www.derivative-calculator.net/
        // TODO: And it's a little bit wrong
        return end * (6 * (1 - value) / 5 + 1) * (-2.2 * Math.pow(1 - value, 1.2) *
            Math.sin(Math.PI * value * (2.5 * value * value * value + 0.2)) + Math.pow(1 - value, 2.2) *
            (Math.PI * (2.5 * value * value * value + 0.2) + 7.5 * Math.PI * value * value * value) *
            Math.cos(Math.PI * value * (2.5 * value * value * value + 0.2)) + 1) -
            6 * end * (Math.pow(1 - value, 2.2) * Math.sin(Math.PI * value * (2.5 * value * value * value + 0.2)) + value
                / 5);

    }

    //public delegate float Function(float s, float e, float v);

    /// <summary>
    /// Returns the function associated to the easingFunction enum. This value returned should be cached as it allocates memory
    /// to return.
    /// </summary>
    /// <param name="easingFunction">The enum associated with the easing function.</param>
    /// <returns>The easing function</returns>
    public static GetEasingFunction(easingFunction: Ease): Function
    {
        if (easingFunction == Ease.quadIn)
        {
            return this.EaseInQuad;
        }

        if (easingFunction == Ease.quadOut)
        {
            return this.EaseOutQuad;
        }

        if (easingFunction == Ease.quadInOut)
        {
            return this.EaseInOutQuad;
        }

        if (easingFunction == Ease.cubicIn)
        {
            return this.EaseInCubic;
        }

        if (easingFunction == Ease.cubicOut)
        {
            return this.EaseOutCubic;
        }

        if (easingFunction == Ease.cubicInOut)
        {
            return this.EaseInOutCubic;
        }

        if (easingFunction == Ease.quartIn)
        {
            return this.EaseInQuart;
        }

        if (easingFunction == Ease.quartOut)
        {
            return this.EaseOutQuart;
        }

        if (easingFunction == Ease.quartInOut)
        {
            return this.EaseInOutQuart;
        }

        if (easingFunction == Ease.quintIn)
        {
            return this.EaseInQuint;
        }

        if (easingFunction == Ease.quintOut)
        {
            return this.EaseOutQuint;
        }

        if (easingFunction == Ease.quintInOut)
        {
            return this.EaseInOutQuint;
        }

        if (easingFunction == Ease.sineIn)
        {
            return this.EaseInSine;
        }

        if (easingFunction == Ease.sineOut)
        {
            return this.EaseOutSine;
        }

        if (easingFunction == Ease.sineInOut)
        {
            return this.EaseInOutSine;
        }

        if (easingFunction == Ease.expoIn)
        {
            return this.EaseInExpo;
        }

        if (easingFunction == Ease.expoOut)
        {
            return this.EaseOutExpo;
        }

        if (easingFunction == Ease.expoInOut)
        {
            return this.EaseInOutExpo;
        }

        if (easingFunction == Ease.circIn)
        {
            return this.EaseInCirc;
        }

        if (easingFunction == Ease.circOut)
        {
            return this.EaseOutCirc;
        }

        if (easingFunction == Ease.circInOut)
        {
            return this.EaseInOutCirc;
        }

        if (easingFunction == Ease.linear)
        {
            return this.Linear;
        }

        // if (easingFunction == Ease.Spring)
        // {
        //     return this.Spring;
        // }

        if (easingFunction == Ease.bounceIn)
        {
            return this.EaseInBounce;
        }

        if (easingFunction == Ease.bounceOut)
        {
            return this.EaseOutBounce;
        }

        if (easingFunction == Ease.bounceInOut)
        {
            return this.EaseInOutBounce;
        }

        if (easingFunction == Ease.backIn)
        {
            return this.EaseInBack;
        }

        if (easingFunction == Ease.backOut)
        {
            return this.EaseOutBack;
        }

        if (easingFunction == Ease.backInOut)
        {
            return this.EaseInOutBack;
        }

        if (easingFunction == Ease.elasticIn)
        {
            return this.EaseInElastic;
        }

        if (easingFunction == Ease.elasticOut)
        {
            return this.EaseOutElastic;
        }

        if (easingFunction == Ease.elasticInOut)
        {
            return this.EaseInOutElastic;
        }

        return null;
    }

    /// <summary>
    /// Gets the derivative function of the appropriate easing function. If you use an easing function for position then this
    /// function can get you the speed at a given time (normalized).
    /// </summary>
    /// <param name="easingFunction"></param>
    /// <returns>The derivative function</returns>
    public static GetEasingFunctionDerivative(easingFunction: Ease): Function
    {
        if (easingFunction == Ease.quadIn)
        {
            return this.EaseInQuadD;
        }

        if (easingFunction == Ease.quadOut)
        {
            return this.EaseOutQuadD;
        }

        if (easingFunction == Ease.quadInOut)
        {
            return this.EaseInOutQuadD;
        }

        if (easingFunction == Ease.cubicIn)
        {
            return this.EaseInCubicD;
        }

        if (easingFunction == Ease.cubicOut)
        {
            return this.EaseOutCubicD;
        }

        if (easingFunction == Ease.cubicInOut)
        {
            return this.EaseInOutCubicD;
        }

        if (easingFunction == Ease.quartIn)
        {
            return this.EaseInQuartD;
        }

        if (easingFunction == Ease.quartOut)
        {
            return this.EaseOutQuartD;
        }

        if (easingFunction == Ease.quartInOut)
        {
            return this.EaseInOutQuartD;
        }

        if (easingFunction == Ease.quintIn)
        {
            return this.EaseInQuintD;
        }

        if (easingFunction == Ease.quintOut)
        {
            return this.EaseOutQuintD;
        }

        if (easingFunction == Ease.quintInOut)
        {
            return this.EaseInOutQuintD;
        }

        if (easingFunction == Ease.sineIn)
        {
            return this.EaseInSineD;
        }

        if (easingFunction == Ease.sineOut)
        {
            return this.EaseOutSineD;
        }

        if (easingFunction == Ease.sineInOut)
        {
            return this.EaseInOutSineD;
        }

        if (easingFunction == Ease.expoIn)
        {
            return this.EaseInExpoD;
        }

        if (easingFunction == Ease.expoOut)
        {
            return this.EaseOutExpoD;
        }

        if (easingFunction == Ease.expoInOut)
        {
            return this.EaseInOutExpoD;
        }

        if (easingFunction == Ease.circIn)
        {
            return this.EaseInCircD;
        }

        if (easingFunction == Ease.circOut)
        {
            return this.EaseOutCircD;
        }

        if (easingFunction == Ease.circInOut)
        {
            return this.EaseInOutCircD;
        }

        if (easingFunction == Ease.linear)
        {
            return this.LinearD;
        }

        // if (easingFunction == Ease.Spring)
        // {
        //     return this.SpringD;
        // }

        if (easingFunction == Ease.bounceIn)
        {
            return this.EaseInBounceD;
        }

        if (easingFunction == Ease.bounceOut)
        {
            return this.EaseOutBounceD;
        }

        if (easingFunction == Ease.bounceInOut)
        {
            return this.EaseInOutBounceD;
        }

        if (easingFunction == Ease.backIn)
        {
            return this.EaseInBackD;
        }

        if (easingFunction == Ease.backOut)
        {
            return this.EaseOutBackD;
        }

        if (easingFunction == Ease.backInOut)
        {
            return this.EaseInOutBackD;
        }

        if (easingFunction == Ease.elasticIn)
        {
            return this.EaseInElasticD;
        }

        if (easingFunction == Ease.elasticOut)
        {
            return this.EaseOutElasticD;
        }

        if (easingFunction == Ease.elasticInOut)
        {
            return this.EaseInOutElasticD;
        }

        return null;
    }
}
