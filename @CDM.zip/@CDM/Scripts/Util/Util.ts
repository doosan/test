import { arrays, util } from "../DataStructure";
import CoroutineComponent, { Coroutine, WaitForSeconds } from "../System/CoroutineComponent";
import { Time } from "../Time/Time";
import { Ease } from "./EasingFunction";


type NodeColorBackupMap = { [name: string]: cc.Color }

export interface RollUpOption 
{
    decimalPoint?: number;
    easeFunc?: Func1<number, number>;
    finishCallback?: Action0;
}

export class Pair<K, V>
{
    constructor(public key: K, public value: V) { }
}

export class ShakeEffect
{
    static shakePos: cc.Vec3;

    static nTimeOutIndex: number = -1;

    static DOShakePosition(otarget: cc.Node, orignPos: cc.Vec3, duration: number) 
    {
        this.shakePos = orignPos;

        cc.tween(otarget)
            .to(0.02, { position: cc.v3(orignPos.x + 5, orignPos.y + 7, 0) })
            .to(0.02, { position: cc.v3(orignPos.x - 6, orignPos.y + 7, 0) })
            .to(0.02, { position: cc.v3(orignPos.x - 13, orignPos.y + 3, 0) })
            .to(0.02, { position: cc.v3(orignPos.x + 3, orignPos.y - 6, 0) })
            .to(0.02, { position: cc.v3(orignPos.x - 5, orignPos.y + 5, 0) })
            .to(0.02, { position: cc.v3(orignPos.x + 2, orignPos.y - 8, 0) })
            .to(0.02, { position: cc.v3(orignPos.x - 8, orignPos.y - 10, 0) })
            .to(0.02, { position: cc.v3(orignPos.x + 3, orignPos.y + 10, 0) })
            .to(0.02, { position: cc.v3(orignPos.x, orignPos.y, 0) })
            .repeatForever()
            .start();

        // otarget.runAction(
        // cc.repeatForever(
        // cc.sequence(
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x + 5, orignPos.y + 7)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x - 6, orignPos.y + 7)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x - 13,orignPos.y + 3)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x + 3, orignPos.y - 6)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x - 5, orignPos.y + 5)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x + 2, orignPos.y - 8)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x - 8, orignPos.y - 10)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x + 3, orignPos.y + 10)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x, orignPos.y))
        // )
        // )
        // );

        //this.timeOut = setTimeout(() => 

        if (-1 != this.nTimeOutIndex)
        {
            clearTimeout(this.nTimeOutIndex);
        }

        this.nTimeOutIndex = window.setTimeout(() => 
        {
            cc.tween(otarget).removeSelf();
            // otarget.stopAllActions();
            otarget.setPosition(orignPos);
            //}, duration);
        }, duration * 1000);
        // this.shakePos = orignPos;

        // otarget.runAction(
        // cc.repeatForever(
        // cc.sequence(
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x + 5, orignPos.y + 7)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x - 6, orignPos.y + 7)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x - 13,orignPos.y + 3)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x + 3, orignPos.y - 6)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x - 5, orignPos.y + 5)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x + 2, orignPos.y - 8)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x - 8, orignPos.y - 10)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x + 3, orignPos.y + 10)),
        // cc.moveTo(0.02, new cc.Vec2(orignPos.x, orignPos.y))
        // )
        // )
        // );

        // //this.timeOut = setTimeout(() => 
        // setTimeout(() => 
        // {
        //     otarget.stopAllActions();
        //     otarget.setPosition(orignPos);
        // //}, duration);
        // }, duration * 1000);        
    }

    static DOShakeStop(otarget: cc.Node) 
    {
        if (-1 != this.nTimeOutIndex)
        {
            clearTimeout(this.nTimeOutIndex);
        }

        otarget.stopAllActions();

        if (undefined != this.shakePos)
        {
            otarget.setPosition(this.shakePos);
        }
    }
}

export class MyMath 
{
    static MAX_VALUE = Number.MAX_VALUE || 9007199254740991;
    static MAX_SAFE_INTEGER = Number.MAX_SAFE_INTEGER || 9007199254740991;
    static MIN_SAFE_INTEGER = Number.MIN_SAFE_INTEGER || -9007199254740991;
    static NEGATIVE_INFINITY = Number.NEGATIVE_INFINITY || -9007199254740991;

    static clamp(value: number, min: number = 0, max: number = 1): number 
    {
        return Math.min(max, Math.max(min, value));
    }

    static lerp(ratio: number, min: number, max: number): number 
    {
        return min * (1 - ratio) + max * ratio;
    }

    // [min, max] in Z-space
    static randomRangeIntMaxInclusive(min: number, max: number): number 
    {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    // [min, max) in Z-space
    static randomRangeInt(min: number, max: number): number 
    {
        return Math.floor(Math.random() * (max - min)) + min;
    }

    // [min, max) in R-space
    static randomRange(min: number, max: number): number
    {
        return Math.random() * (max - min) + min;
    }

    static weighted_random(_weights: number[]): number 
    {
        let r = this.randomRangeInt(1, this.arrayReduceSum(_weights));
        for (let i = 0; i < _weights.length; i++) 
        {
            r -= _weights[i];
            if (r < 1) return i;
        }
    }

    static arrayReduceSum(arr: number[]) 
    {
        let sum = 0;
        arr.forEach(element => 
        {
            sum += element
        });

        return sum
    }

    public static Ceiling(value:number, until:number) : number
        {
            let digitCount = value > 0 ? Math.trunc((Math.log10(value) + 1)) : 1;

            let devider = 1;
            let dividingCount = digitCount - until;
            for (let j = 0; j < dividingCount; j++)
            {
                devider *= 10;
            }

            let quotient = value / devider;
            let ceiling = Math.ceil(quotient);
            return ceiling * devider;
            //Debug.Log($"==== Ceiling : {value}, {quotient}, {ceiling}, {ceiling * devider}, {digitCount}, {devider}");
        }
}

export class Quaternion 
{
    static readonly Deg2Rad: number = 0.0174532924;
    static readonly Rad2Deg: number = 57.29578;

    static FromToRotation(aFrom: cc.Vec3, aTo: cc.Vec3): cc.Quat
    {
        let axis: cc.Vec3 = cc.Vec3.ZERO;
        axis = cc.Vec3.cross(axis, aFrom, aTo);

        let angle: number = cc.Vec3.angle(aFrom, aTo);
        let vNormal: cc.Vec3 = cc.Vec3.ZERO;
        vNormal = axis.normalize(vNormal);
        return this.AngleAxis(angle, vNormal);
    }

    static AngleAxis(aAngle: number, aAxis: cc.Vec3): cc.Quat
    {
        aAxis.normalize();
        let rad: number = aAngle * this.Deg2Rad * 0.5;
        let nSin: number = Math.sin(rad);
        aAxis.x *= nSin;
        aAxis.y *= nSin;
        aAxis.z *= nSin;

        return new cc.Quat(aAxis.x, aAxis.y, aAxis.z, Math.cos(rad));
    }

    static Multiple(rotation: cc.Quat, point: cc.Vec3): cc.Vec3
    {
        let x: number = rotation.x * 2;
        let y: number = rotation.y * 2;
        let z: number = rotation.z * 2;
        let xx: number = rotation.x * x;
        let yy: number = rotation.y * y;
        let zz: number = rotation.z * z;
        let xy: number = rotation.x * y;
        let xz: number = rotation.x * z;
        let yz: number = rotation.y * z;
        let wx: number = rotation.w * x;
        let wy: number = rotation.w * y;
        let wz: number = rotation.w * z;

        let res: cc.Vec3 = cc.Vec3.ZERO;
        res.x = (1 - (yy + zz)) * point.x + (xy - wz) * point.y + (xz + wy) * point.z;
        res.y = (xy + wz) * point.x + (1 - (xx + zz)) * point.y + (yz - wx) * point.z;
        res.z = (xz - wy) * point.x + (yz + wx) * point.y + (1 - (xx + yy)) * point.z;
        return res;
    }

    static GetRandomQuat(): cc.Quat
    {
        return new cc.Quat(Math.randomRangeFloat(0, 1), Math.randomRangeFloat(0, 1), Math.randomRangeFloat(0, 0), 0);
    }

    static QuaternionLookRotation(forward: cc.Vec3, up: cc.Vec3): cc.Quat
    {
        //let vector = forward.normalize();
        //let vector2 = up.CrossProduct(vector).Normalize();
        //let vector3 = vector.CrossProduct(vector2);
        let vector = forward.normalize();
        let vector2 = cc.Vec3.ZERO;
        vector2 = cc.Vec3.cross(vector2, up, vector).normalize();
        let vector3 = cc.Vec3.ZERO;
        vector3 = cc.Vec3.cross(vector3, vector, vector2);
        let m00 = vector2.x;
        let m01 = vector2.y;
        let m02 = vector2.z;
        let m10 = vector3.x;
        let m11 = vector3.y;
        let m12 = vector3.z;
        let m20 = vector.x;
        let m21 = vector.y;
        let m22 = vector.z;

        let num8 = (m00 + m11) + m22;
        let quaternion = new cc.Quat;
        if (num8 > 0.0)
        {
            let num = Math.sqrt(num8 + 1.0);
            quaternion.w = num * 0.5;
            num = 0.5 / num;
            quaternion.x = (m12 - m21) * num;
            quaternion.y = (m20 - m02) * num;
            quaternion.z = (m01 - m10) * num;
            return quaternion;
        }
        if ((m00 >= m11) && (m00 >= m22))
        {
            let num7 = Math.sqrt(((1.0 + m00) - m11) - m22);
            let num4 = 0.5 / num7;
            quaternion.x = 0.5 * num7;
            quaternion.y = (m01 + m10) * num4;
            quaternion.z = (m02 + m20) * num4;
            quaternion.w = (m12 - m21) * num4;
            return quaternion;
        }
        if (m11 > m22)
        {
            let num6 = Math.sqrt(((1.0 + m11) - m00) - m22);
            let num3 = 0.5 / num6;
            quaternion.x = (m10 + m01) * num3;
            quaternion.y = 0.5 * num6;
            quaternion.z = (m21 + m12) * num3;
            quaternion.w = (m20 - m02) * num3;
            return quaternion;
        }
        let num5 = Math.sqrt(((1.0 + m22) - m00) - m11);
        let num2 = 0.5 / num5;
        quaternion.x = (m20 + m02) * num2;
        quaternion.y = (m21 + m12) * num2;
        quaternion.z = 0.5 * num5;
        quaternion.w = (m01 - m10) * num2;
        return quaternion;
    }

    static LookRotation(forward: cc.Vec3, upp: cc.Vec3): cc.Quat
    {
        forward.normalizeSelf();
        upp.normalizeSelf();
        let right: cc.Vec3 = cc.Vec3.ZERO;
        cc.Vec3.cross(right, upp, forward).normalizeSelf();
        let up: cc.Vec3 = cc.Vec3.ZERO;
        cc.Vec3.cross(up, forward, right).normalizeSelf();

        let m00: number = right.x
        let m01: number = up.x
        let m02: number = forward.x
        let m10: number = right.y
        let m11: number = up.y
        let m12: number = forward.y
        let m20: number = right.z
        let m21: number = up.z
        let m22: number = forward.z

        let ret: cc.Quat = new cc.Quat();
        ret.w = Math.sqrt(1.0 + m00 + m11 + m22) * 0.5;
        let w4_recip = 1.0 / (4.0 * ret.w);
        ret.x = (m21 - m12) * w4_recip;
        ret.y = (m02 - m20) * w4_recip;
        ret.z = (m10 - m01) * w4_recip;

        return ret;
    }

    public static Slerp(quaternion1: cc.Quat, quaternion2: cc.Quat, amount: number): cc.Quat
    {
        const epsilon: number = 1e-6;

        let t: number = amount;

        let cosOmega: number = quaternion1.x * quaternion2.x + quaternion1.y * quaternion2.y +
            quaternion1.z * quaternion2.z + quaternion1.w * quaternion2.w;

        let flip: boolean = false;

        if (cosOmega < 0.0)
        {
            flip = true;
            cosOmega = -cosOmega;
        }

        let s1: number = 0;
        let s2: number = 0;

        if (cosOmega > (1.0 - epsilon))
        {
            // Too close, do straight linear interpolation.
            s1 = 1.0 - t;
            s2 = (flip) ? -t : t;
        }
        else
        {
            let omega: number = Math.acos(cosOmega);
            let invSinOmega: number = (1 / Math.sin(omega));

            s1 = Math.sin((1.0 - t) * omega) * invSinOmega;
            s2 = (flip)
                ? -Math.sin(t * omega) * invSinOmega
                : Math.sin(t * omega) * invSinOmega;
        }

        let ans: cc.Quat = new cc.Quat();

        ans.x = s1 * quaternion1.x + s2 * quaternion2.x;
        ans.y = s1 * quaternion1.y + s2 * quaternion2.y;
        ans.z = s1 * quaternion1.z + s2 * quaternion2.z;
        ans.w = s1 * quaternion1.w + s2 * quaternion2.w;

        return ans;
    }
}






export class Util 
{
    // export enum Vehicle 
    // {
    //     Car = 'car',
    //     Bike = 'bike',    
    // }
    // export enum RewardType
    // {
    //     none = 0,    
    //     s_pickaxe = 9,
    //     g_pickaxe = 10,
    // }
    // export enum PlacementType
    // {
    //     Ocean = 1,
    //     Lobby,    
    // }

    // TEST Code
    // if (Util.existValueInEnum(PlacementType, 1) == true)
    // {            
    //     let aaa;
    // }

    // if (Util.existValueInEnum(Vehicle, "car") == true)
    // {           
    //     let baa; 
    // }
    // let aaaf = "s_pickaxe";
    // if(Util.existValueInEnum(RewardType, RewardType[aaaf]))
    // {
    //     let bcc;
    // }

    static log(msg: string|any, ...subst: any[]):void    
    {
        let d = new Date();
        if(0 != subst.length)
        {
            cc.log("["+d.toLocaleTimeString() + "." + d.getMilliseconds().toString().padStart(3, '0')+ "] "+ msg + subst);
        }
        else 
        {
            cc.log("["+d.toLocaleTimeString() + "." + d.getMilliseconds().toString().padStart(3, '0')+ "] " + msg);
        }
    }

    static existValueInEnum(type: any, Value: any): boolean 
    {
        return Object.keys(type).filter(k => isNaN(Number(k))).filter(k => type[k] === Value).length > 0;
    }


    static loadScript(url: string): Promise<void> 
    {
        return new Promise<void>((resolve: Action0, reject: Action1<string>) => 
        {
            if (cc.sys.isBrowser) 
            {
                let script = document.createElement("script") as HTMLScriptElement;
                script.type = "text/javascript";
                script.onload = () => resolve();
                script.src = url;
                script.async = true;
                document.getElementsByTagName("head")[0].appendChild(script);
            }
            else 
            {
                resolve();
            }
        });
    }

    static getParentNodeByName(me: cc.Node, parentName: string): cc.Node | undefined 
    {
        while (me && me.name !== parentName) 
        {
            me = me.parent;
        }

        return me;
    }

    static getComponentInParent<T extends cc.Component>(me: cc.Node, type: { prototype: T }): T | undefined 
    {
        while (me.parent) 
        {
            me = me.parent;
            let comp = me.getComponent(type);

            if (comp) 
            {
                return comp;
            }
        }

        return undefined;
    }

    static getComponentInParentN(me: cc.Node, name : string) : any
    {
        while (me.parent) 
        {
            me = me.parent;
            let comp = me.getComponent(name);

            if (comp) 
            {
                return comp;
            }
        }

        return undefined;
    }

    static ensurePromise<T>(promise: Promise<T>, then: Action1<T>) 
    {
        promise.then(then).catch((reason: Action1<any>) => 
        {
            //Global.onError(reason);
        });
    }

    static getPromiseForAnimationFinish(animation: cc.Animation): Promise<void> 
    {
        return new Promise<void>((resolve: Action1<void>) => 
        {
            //animation.once("finished", resolve, this, false);
        });
    }

    static getAnimationClipNameEndsWith(animation: cc.Animation, postFix: string) 
    {
        return animation.getClips().map(clip => clip.name).find(cName => cName.toLowerCase().endsWith(postFix));
    }

    //http://stackoverflow.com/questions/18082/validate-decimal-numbers-in-javascript-isnumeric
    static isNumeric(value?: any) 
    {
        return !isNaN(parseFloat(value)) && isFinite(value);
    }

    static makeEventHandler(node: cc.Node, co: cc.Component, coHandler: Function, customEventData?: any): cc.Component.EventHandler 
    {
        let eventHandler = new cc.Component.EventHandler();
        eventHandler.target = node;
        eventHandler.component = cc.js.getClassName(co);
        eventHandler.handler = coHandler.name;
        eventHandler.customEventData = customEventData ? customEventData.toString() : "";
        return eventHandler;
    }


    // like Array.map()
    static objectMap<T>(obj: any, callbackfn: (key: string, value: any) => T): T[] 
    {
        let array: T[] = [];
        for (let key in obj) 
        {
            let value = obj[key];
            array.push(callbackfn(key, value));
        }

        return array;
    }

    // like Array.forEach()
    static objectForEach<V>(obj: { [key: string]: V }, callbackfn: Action2<string | number, V>) 
    {
        for (let key in obj) 
        {
            let value = obj[key];
            callbackfn(key, value);
        }
    }


    // like Array.filter()
    static objectFilter<V>(obj: { [id: string]: V }, callbackfn: (key: string, value: V) => boolean): Pair<string, V>[] 
    {
        let array: Pair<string, V>[] = [];
        for (let key in obj) 
        {
            let value = obj[key];
            if (callbackfn(key, value)) 
            {
                array.push(new Pair(key, value));
            }
        }

        return array;
    }

    static clone<T>(originalObject: T, circular?: boolean): T 
    {
        // First create an empty object with
        // same prototype of our original source
        if (originalObject === null || originalObject === undefined) 
        {
            return originalObject;
        }

        let propertyIndex: number,
            descriptor: PropertyDescriptor,
            keys: string[],
            current: { source: any, target: any } | undefined,
            nextSource: any,
            indexOf: number,
            copies = [{
                source: originalObject,
                target: Array.isArray(originalObject) ? [] : Object.create(Object.getPrototypeOf(originalObject))
            }],
            cloneObject = copies[0].target,
            sourceReferences = [originalObject],
            targetReferences = [cloneObject];

        // First in, first out
        while (current = copies.shift()) 
        {
            keys = Object.getOwnPropertyNames(current.source);

            for (propertyIndex = 0; propertyIndex < keys.length; propertyIndex++) 
            {
                // Save the source's descriptor
                descriptor = Object.getOwnPropertyDescriptor(current.source, keys[propertyIndex])!;

                if (!descriptor.value || typeof descriptor.value !== "object") 
                {
                    Object.defineProperty(current.target, keys[propertyIndex], descriptor);
                    continue;
                }

                nextSource = descriptor.value;
                descriptor.value = Array.isArray(nextSource) ? [] : Object.create(Object.getPrototypeOf(nextSource));

                if (circular) 
                {
                    indexOf = sourceReferences.indexOf(nextSource);

                    if (indexOf !== -1) 
                    {
                        // The source is already referenced, just assign reference
                        descriptor.value = targetReferences[indexOf];
                        Object.defineProperty(current.target, keys[propertyIndex], descriptor);
                        continue;
                    }

                    sourceReferences.push(nextSource);
                    targetReferences.push(descriptor.value);
                }

                Object.defineProperty(current.target, keys[propertyIndex], descriptor);

                copies.push({ source: nextSource, target: descriptor.value });
            }
        }

        return cloneObject;
    }


    static setCascadeOpacityEnabledRecursive(node: cc.Node, cascadeOpacityEnabled: boolean) 
    {
        node.setCascadeOpacityEnabled(cascadeOpacityEnabled);
        let children = node.children;
        let cc = children.length;
        for (let i = 0; i < cc; i++) 
        {
            this.setCascadeOpacityEnabledRecursive(children[i], cascadeOpacityEnabled);
        }
    }

    static fade(type: "in" | "out", duration: number, node: cc.Node, validator: CoroutineComponent): Coroutine 
    {
        return validator.startCoroutine(this.fadeCoroutine(type, duration, node), validator);
    }

    private static *fadeCoroutine(type: "in" | "out", duration: number, node: cc.Node) 
    {
        let startA = type === "in" ? 0 : 255, endA = 255 - startA;
        yield this.rollUpNumber(null, duration, startA, endA, o => node.opacity = o);
    }

    static blinkNode(duration: number, node: cc.Node, validator: CoroutineComponent, fadeIn = true): Coroutine 
    {
        return validator.startCoroutine(this.blinkNodeCoroutine(duration, node, fadeIn), validator);
    }


    private static *blinkNodeCoroutine(duration: number, node: cc.Node, fadeIn: boolean) 
    {
        let startA = fadeIn ? 0 : 255, endA = fadeIn ? 255 : 0;
        yield this.rollUpNumber(null, duration / 2, startA, endA, (v) => { node.opacity = v; });
        yield this.rollUpNumber(null, duration / 2, endA, startA, (v) => { node.opacity = v; });
    }

    // 
    static waitForSignal(checkFunc: Func0<boolean>, executor: CoroutineComponent | null = null): Coroutine 
    {
        return executor.startCoroutine(this.waitForSignalCoroutine(checkFunc), executor);
    }

    private static *waitForSignalCoroutine<R>(checkFunc: Func0<boolean>) 
    {
        while (!checkFunc()) { yield; }
    }

    static waitForPromise<T>(promise: Promise<T>, executor: CoroutineComponent | null = null): Coroutine 
    {
        return executor.startCoroutine(this.waitForPromiseCoroutine(promise), executor);
    }

    private static *waitForPromiseCoroutine<T>(promise: Promise<T>) 
    {
        let done = false;
        let ret: T | undefined;

        this.ensurePromise(promise, (v: T) => { ret = v; done = true; });
        while (!done) { yield; }
        return ret!;
    }

    static waitForAnimation(animation: cc.Animation | cc.Node, onFinish?: Action0, executor: CoroutineComponent | null = null): Coroutine 
    {
        let _animation: cc.Animation;

        if (animation instanceof cc.Animation) 
        {
            _animation = animation;
        }
        else 
        {
            _animation = animation.getComponent(cc.Animation);

            if (!_animation) 
            {
                throw `node has not animation component. node name= ${animation.name}`;
            }
        }
        return executor.startCoroutine(this.waitForAnimationCoroutine(_animation, onFinish), executor);
    }

    private static *waitForAnimationCoroutine(animation: cc.Animation, finishCallback?: Action0) 
    {
        let promise = this.getPromiseForAnimationFinish(animation);
        yield this.waitForPromiseCoroutine(promise);

        finishCallback && finishCallback();
    }

    static waitForCoroutines(coroutines: Coroutine[], onFinish?: Action0, executor: CoroutineComponent | null = null): Coroutine 
    {
        return executor.startCoroutine(this.waitForCoroutineCoroutine(coroutines, onFinish), executor);
    }

    private static *waitForCoroutineCoroutine(coroutines: Coroutine[], finishCallback?: Action0) 
    {
        while (coroutines.find(coroutine => !coroutine.done)) 
        {
            yield;
        }

        finishCallback && finishCallback();
    }


    static delayedAction(seconds: number, action: Action0, executor: CoroutineComponent = null): Coroutine 
    {
        return executor.startCoroutine(this.delayedActionCoroutine(seconds, action), executor);
    }

    private static *delayedActionCoroutine(seconds: number, action: () => void) 
    {
        yield new WaitForSeconds(seconds);

        action();
    }

    static rollUpNumber(validator: CoroutineComponent, duration: number, start: number, end: number, applyFunc: Action1<number>, option?: RollUpOption): Coroutine 
    {
        let decimalPoint = (option && option.decimalPoint) ? option.decimalPoint : 2;
        return validator.startCoroutine(this._rollUpCoroutine(duration, start, end, (v) => 
        {
            let shifter = Math.pow(10, decimalPoint);
            v = Math.floor(v * shifter) / shifter;
            applyFunc(v);
        }, option), validator);
    }

    static rollUpVec2(validator: CoroutineComponent, duration: number, start: cc.Vec2, end: cc.Vec2, applyFunc: Action1<cc.Vec2>, option?: RollUpOption): Coroutine 
    {
        return validator.startCoroutine(this._rollUpCoroutine(duration, 0, 1, r =>
        {
            let v: cc.Vec2 = start.lerp(end, r);
            applyFunc(v);

        }, option), validator);
    }

    static *_rollUpCoroutine(duration: number, from: number, to: number, applyFunc: Action1<number>, option?: RollUpOption) 
    {
        let elapsedTime = -Time.deltaTime;

        while (elapsedTime <= duration) 
        {
            elapsedTime += Time.deltaTime;
            let ratio = duration === 0 ? 1 : MyMath.clamp(elapsedTime / duration);
            if (option && option.easeFunc) { ratio = option.easeFunc(ratio); }
            let value = MyMath.lerp(ratio, from, to);
            applyFunc(value);

            yield;
        }

        option && option.finishCallback && option.finishCallback();
    }

    static delay(ms: number) 
    {
        return new Promise(function (resolve) 
        {
            setTimeout(resolve, ms * 1000);
        });
    }




    static getFrameFactor(a): number
    {
        a /= 1 / 60;
        2 < a ? a = 2 : 0.8 > a && (a = 0.8);
        return a
    }

    static getRandomNumber(a, b): number 
    {
        return Math.floor(Math.random() * (b - a + 1) + a)
    }

    static getRandomFloat(min, max): number
    {
        return Math.random() * (max - min) + min;
    }

    static getRandomInt(min, max): number
    {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min)) + min; //최댓값은 제외, 최솟값은 포함
    }

    static shuffle(array): []
    {
        let currentIndex = array.length, temporaryValue, randomIndex;

        // While there remain elements to shuffle...
        while (0 !== currentIndex) 
        {
            // Pick a remaining element...
            randomIndex = Math.floor(Math.random() * currentIndex);
            currentIndex -= 1;

            // And swap it with the current element.
            temporaryValue = array[currentIndex];
            array[currentIndex] = array[randomIndex];
            array[randomIndex] = temporaryValue;
        }

        return array;
    }


    static getComponent_EventHandler(target, component, handler, params) 
    {
        let eventHandler = new cc.Component.EventHandler();
        eventHandler.target = target;
        eventHandler.component = component;
        eventHandler.handler = handler;
        eventHandler.customEventData = params;
        return eventHandler;
    }

    // static isFacebookWeb()
    // {
    //     return !cc.sys.isNative && Util.isFacebookInstant() == false;
    // }

    // static isFacebookInstant()
    // {
    //     if (typeof cc._FBInstantGame === 'undefined')   {
    //         return false;
    //     }
    //     return true;
    // };
    // static isMobileGame()
    // {
    //     return Util.isFacebookWeb() == false && Util.isFacebookInstant() == false;
    // }
}

export class ColorUtil 
{
    static changeColor(node: cc.Node, colorProvider: cc.Color | Func2<cc.Color, string, cc.Color>, exceptNodes: cc.Node[] | undefined = undefined, nevermind?: string) 
    {
        if (!nevermind) 
        {
            nevermind = "";
        }
        nevermind = nevermind + `/${node.name}`;

        node.color = colorProvider instanceof cc.Color ? colorProvider : colorProvider(nevermind, node.color);
        node.children.forEach((child) => 
        {
            if (exceptNodes && exceptNodes.indexOf(child) >= 0) 
            {
                return;
            }
            ColorUtil.changeColor(child, colorProvider, exceptNodes, nevermind);
        });
    }

    static colorBackup(node: cc.Node): NodeColorBackupMap;
    static colorBackup(node: cc.Node, prefix: string, map: NodeColorBackupMap): NodeColorBackupMap;
    static colorBackup(node: cc.Node, prefix?: string, map?: NodeColorBackupMap): NodeColorBackupMap 
    {
        if (!map) 
        {
            map = {};
        }
        if (!prefix)
        {
            prefix = "";
        }

        prefix = prefix + `/${node.name}`;
        map[prefix] = node.color.clone();

        node.children.forEach(child => this.colorBackup(child, prefix!, map!));

        return map;
    }

    /**
     * 
     * @param node 
     * @param map return value of ColorUtil.colorBackup
     * @param prefix not set. this is for recursive call
     */
    static colorRestore(node: cc.Node, map: NodeColorBackupMap, prefix = "") 
    {
        prefix = prefix + `/${node.name}`;
        node.color = map[prefix];

        node.children.forEach(child => this.colorRestore(child, map, prefix));
    }

    static hexToColor(hexArr: string): cc.Color 
    {
        return new cc.Color().fromHEX(hexArr);
    }

    static hexToColorArr(hexArr: string[]): cc.Color[] 
    {
        let result: cc.Color[] = [];
        for (let i = 0; i < hexArr.length; i++)
        {
            result.push(new cc.Color().fromHEX(hexArr[i]));
        }
        return result;
    }

    static rollUpColor(validator: CoroutineComponent, duration: number, start: cc.Color, to: cc.Color, applyFunc: Action1<cc.Color>, option?: RollUpOption): Coroutine 
    {
        return validator.startCoroutine(Util._rollUpCoroutine(duration, 0, 1, r => 
        {
            let c = start.lerp(to, r);
            applyFunc(c);
        }, option), validator);
    }
}

export class ArrayUtil 
{
    static isNullOrEmpty<T>(array: T[]) 
    {
        return array == null || array.length === 0;
    }

    static shuffle<T>(array: T[]) 
    {
        for (let i = 0; i < Math.floor(array.length / 2); ++i) 
        {
            let targetIndex = MyMath.randomRangeInt(0, array.length);
            let tmp: T = array[i];
            array[i] = array[targetIndex];
            array[targetIndex] = tmp;
        }

        return array;
    }
    static getFirst<T>(array: T[]): T | undefined { return this.isNullOrEmpty(array) ? undefined : array[0]; }
    static getLast<T>(array: T[]): T | undefined { return this.isNullOrEmpty(array) ? undefined : array[array.length - 1]; }

    static randomGet<T>(array: T[]) { return array[MyMath.randomRangeInt(0, array.length)]; }

    static range(start, end) 
    {
        let array = new Array();

        for (let i = start; i < end; ++i) 
        {
            array.push(i);
        }

        return array;
    }

    static checkEquals<T>(array1: T[], array2: T[]) 
    {
        if (array1.length !== array2.length) 
        {
            return false;
        }
        for (let i = 0; i < array1.length; ++i) 
        {
            if (array1[i] !== array2[i]) 
            {
                return false;
            }
        }

        return true;
    }

    static sortOnBase(data, base) 
    {
        data.sort((a, b) => 
        {
            if (a[base] > b[base]) 
            {
                return -1;
            }
            if (a[base] < b[base]) 
            {
                return 1;
            }
            return 0;
        });
    }

    /**
     * 오름차순 정렬을 위한 비교
     */
    static compareAsc(a, b) : number
    {
        if (a > b) return +1;
        if (a < b) return -1;
        return 0;
    }

    /**
     * 내림차순 정렬을 위한 비교
     */
    static compareDesc(a, b) : number
    {
        if (a > b) return -1;
        if (a < b) return +1;
        return 0;
    }

    // let result = arrayRemove(array, 6);
    // result = [1, 2, 3, 4, 5, 7, 8, 9, 0]
    static arrayRemove(arr, value) 
    {
        return arr.filter(function (ele)
        {
            return ele != value;
        });
    }

    static removeAt(arr, index) 
    {
        let i = -1;
        return arr.filter(function (ele)
        {
            i++;
            if(index != i)
            {
                return ele;
            }
        });
    }

    static insert(arr, startIndex, value) 
    {
        return arr.slice(0, startIndex).concat(value).concat(arr.slice(startIndex));
    }

    static orderBy<T>(arr, keySelector) : any
    {
        if(keySelector instanceof Array)
        {
            let resArr = new Array<T>();
            let selectedArr = new Array<T>();
            
            for(let i = 0; i < keySelector.length; i++)
            {
                for(let a = 0; a < arr.length; a++)
                {
                    if(arr[a] == keySelector[i])
                    {
                        selectedArr.push(arr[a]);
                    }
                }
            }

            arr.forEach(item=>
            {
                let isKeySelected = false;

                for(let i = 0; i < keySelector.length; i++)
                {
                    if(item == keySelector[i])
                    {
                        isKeySelected = true;
                    }
                }

                if(!isKeySelected)
                {
                    resArr.push(item);
                }

                resArr = resArr.concat(selectedArr);
            });

            return resArr;
        }
        else
        {
            return arr.filter()
        }
    }
    
    static getRange(arr, index:number, count:number)
    {
        let i = 0;
        let c = 0;

        return arr.filter(function (ele)
        {
            if(count > c && index <= i)
            {
                return ele;
            }
            
            i++
            c++;
        });
    }

    /**
     * 배열 타입 캐스팅 함수
     * @param arr 
     * @returns 
     */
    static cast<T>(arr)
    {
        let castArr = new Array<T>();

        arr.forEach(ele=>
        {
            castArr.push(<T>ele);
        });

        return castArr;
    }

    /**
     * 1차원 배열을 2차원 배열로 반환
     * sequenced 차이는 아래
     ** new int[]{1,2,3,4,5,6}.ConvertTo2D(3,true) =>
     * [
     *     [1,2]
     *     [3,4]
     *     [5,6]
     * ]
     ** new int[]{1,2,3,4,5,6}.ConvertTo2D(3,false) =>
     * [
     *     [1,4]
     *     [2,5]
     *     [3,6]
     * ]
     * @param list                      변환할 배열
     * @param targetLength              반환 될 2차원 배열의 1차원의 크기 설정. 배열 자기자신의 크기의 약수여야 한다
     * @param sequenced                 2차원 배열을 순서대로 채워나갈 것인지 여부.
     * @returns 
     */

    static ConvertTo2D<T>(list: T[], targetLength: number, sequenced: boolean = true): T[][]
    {
        let secondLength: number = list.length / targetLength;
        let ret: T[][] = Array.from(Array(targetLength), () => Array(secondLength));
        let x = 0;
        let y = 0;
        for (let i = 0; i < list.length; ++i)
        {
            ret[x][y] = list[i];
            if (sequenced)
            {
                if (++y == secondLength)
                {
                    y = 0;
                    ++x;
                }
            }
            else
            {
                if (++x == targetLength)
                {
                    x = 0;
                    ++y;
                }
            }
        }
        return ret;
    }

    /**
     * 2차원 배열의 선택한 차원의 크기 반환
     * @param list      배열
     * @param dimension 최대 1까지 설정
     * @returns 
     */
    static GetLength2D<T>(list: T[][], dimension: number): number
    {
        let length = 0;

        switch (dimension)
        {
            case 0:
                length = list.length;
                break;
            case 1:
                length = list[0].length;
                break;
            default:
                break;
        }

        return length;
    }

    /**
     * 3차원 배열의 선택한 차원의 크기 반환
     * @param list      배열
     * @param dimension 최대 2까지 설정
     * @returns 
     */
    static GetLength3D<T>(list: T[][][], dimension: number): number
    {
        let length = 0;

        switch (dimension)
        {
            case 0:
                length = list.length;
                break;
            case 1:
                length = list[0].length;
                break;
            case 1:
                length = list[0][0].length;
                break;
            default:
                break;
        }

        return length;
    }
}

export class NodeUtil
{
    private static _worldPosNode : cc.Node = null;
    public static get worldPosNode() : cc.Node
    {
        let canvas = cc.director.getScene().getChildByName("SingleObjects");

        if(this._worldPosNode == null)
        {
            let node = new cc.Node("WorldPosNode");

            this._worldPosNode = node;
    
            node.setParent(canvas);
        }
        
        if(this._worldPosNode.parent == null)
        {
            this._worldPosNode.setParent(canvas);
        }

        return this._worldPosNode;
    }

    static SetLayer(node: cc.Node, layer: string)
    {
        node.group = layer;

        for (let i = 0; i < node.childrenCount; i++)
        {
            this.SetLayer(node.children[i], layer);
        }
    }

    /**
    * 타겟 좌표로 노드를 이동
    * @param node 이동시킬 노드 : cc.Vec3 사용시 값을 제대로 못 받아오는 경우 있음 (되도록 cc.Node 사용하는게 좋음)
    * @param target 목표 node 또는 vector
    */
    static MoveToWorldPosition(node:cc.Node, target: cc.Node | cc.Vec3)
    {
        let targetVec : cc.Vec3 = null;
        
        let targetWorldPos :cc.Vec3 = null;

        if(target instanceof cc.Node )
        {
            targetVec = target.position.clone();
            targetWorldPos = target.parent.convertToWorldSpaceAR(targetVec);
            node.setPosition(node.parent.convertToNodeSpaceAR(targetWorldPos).clone());
        }
        else if (target instanceof cc.Vec3)
        {
            this.worldPosNode.setPosition(target);
            
            targetVec = this.worldPosNode.position.clone();
            targetWorldPos = this.worldPosNode.parent.convertToWorldSpaceAR(targetVec);
            node.setPosition(node.parent.convertToNodeSpaceAR(targetWorldPos).clone());
        }
    }


    /**
     * 노드의 월드 좌표계 가져오기
     * @param target
     * @returns cc.Vec3
     */
    static GetWorldPosition(target:cc.Node) : cc.Vec3
    {
        if(target instanceof cc.Node)
        {
            let targetWorldPos = target.parent.convertToWorldSpaceAR(target.position);
            return this.worldPosNode.parent.convertToNodeSpaceAR(targetWorldPos).clone();
        }
    }

    /**
     * 노드의 월드 좌표계를 스크린 좌표계로 변환
     * 
     */
    static ConvertWorldToScreen(target:cc.Node) : cc.Vec3
    {
        let w = cc.view.getFrameSize().width;
        let h = cc.view.getFrameSize().height;
        let worldPos = NodeUtil.GetWorldPosition(target);

        w = Math.abs(worldPos.x + w * 0.5);
        h = Math.abs(worldPos.y - h * 0.5);

        return new cc.Vec3(w, h, 0);
    }

    /**
    * 노드의 월드 좌표계를 스크린 좌표계로 변환
    * 
    */
    static ConvertScreenToWorld(screenPos:cc.Vec2) : cc.Vec3
    {
        let w = cc.view.getFrameSize().width;
        let h = cc.view.getFrameSize().height;
        
        w = screenPos.x - w * 0.5;
        h = screenPos.y - h * 0.5;
        h = h * -1;
    
        return new cc.Vec3(w, h, 0);
    }

    /**
     * 노드를 스크린 좌표계로 이동
     * @param node 
     * @param targetScreenPos 목표 스크린 좌표
     */
    static MoveToScreenPosition(node:cc.Node, targetScreenPos:cc.Vec2)
    {
        let worldPos = NodeUtil.ConvertScreenToWorld(targetScreenPos);
        NodeUtil.MoveToWorldPosition(node, worldPos);
    }
    /**
     * 노드를 스크린 좌표 기준 앵커 이동 (앵커 값 4개 중 1~2개 필요)
     * @param node 
     * @param left value or null
     * @param right value or null
     * @param top value or null
     * @param bottom value or null
     */
    static SetAnchorToScreen(node:cc.Node, left:number = null, right:number = null, top:number = null, bottom:number = null)
    {
        let targetScreenPos = cc.Vec2.ZERO;

        if(left != null)
        {
            targetScreenPos.x = left;
        }
        if(right != null)
        {
            targetScreenPos.x = cc.view.getFrameSize().width - right;
        }
        if(top != null)
        {
            targetScreenPos.y = top;
        }
        if(bottom != null)
        {
            targetScreenPos.y = cc.view.getFrameSize().height - bottom;
        }

        let worldPos = NodeUtil.ConvertScreenToWorld(targetScreenPos);
        NodeUtil.MoveToWorldPosition(node, worldPos);
    }

    /**
     * 노드의 Global Scale 가져오기 (씬의 Canvas 기준)
     * @param node 
     * @return lossyScale x, y 값을 cc.Vec2로 리턴
     */
    static GetLossyScale(node:cc.Node) : cc.Vec2
    {
        let canvas = cc.director.getScene().getChildByName("Canvas");
        let currentParentNode : cc.Node =  node.parent;

        let calScale : cc.Vec2 = new cc.Vec2(node.scaleX, node.scaleY);

        while(currentParentNode != canvas)
        {
            calScale = new cc.Vec2(calScale.x * currentParentNode.scaleX, calScale.y * currentParentNode.scaleY);
            currentParentNode = currentParentNode.parent;
        }

        return calScale;
    }

    static GetAllChildren(node:cc.Node) : cc.Node[]
    {
        let childList : cc.Node[] = [];
        
        childList.push(node);

        for (let i = 0; i < node.childrenCount; i++)
        {
            childList = childList.concat(this.GetAllChildren(node.children[i]));
        }

        return childList;
    }

    static SetParent(node:cc.Node, parentNode:cc.Node, worldPositionStays:boolean)
    {
        if(worldPositionStays)
        {
            let nodeWorldPos = this.GetWorldPosition(node).clone();

            node.setParent(parentNode);

            this.MoveToWorldPosition(node, nodeWorldPos);
        }
        else
        {
            node.setParent(parentNode);
        }
    }
}

/**
 * https://github.com/gre/bezier-easing
 * BezierEasing - use bezier curve for transition easing function
 * by Gaëtan Renaudeau 2014 - 2015 – MIT License
 */

// These values are established by empiricism with tests (tradeoff: performance VS precision)
let NEWTON_ITERATIONS = 4;
let NEWTON_MIN_SLOPE = 0.001;
let SUBDIVISION_PRECISION = 0.0000001;
let SUBDIVISION_MAX_ITERATIONS = 10;

let kSplineTableSize = 11;
let kSampleStepSize = 1.0 / (kSplineTableSize - 1.0);

let float32ArraySupported = typeof Float32Array === 'function';

function A(aA1, aA2) { return 1.0 - 3.0 * aA2 + 3.0 * aA1; }
function B(aA1, aA2) { return 3.0 * aA2 - 6.0 * aA1; }
function C(aA1) { return 3.0 * aA1; }

// Returns x(t) given t, x1, and x2, or y(t) given t, y1, and y2.
function calcBezier(aT, aA1, aA2) { return ((A(aA1, aA2) * aT + B(aA1, aA2)) * aT + C(aA1)) * aT; }

// Returns dx/dt given t, x1, and x2, or dy/dt given t, y1, and y2.
function getSlope(aT, aA1, aA2) { return 3.0 * A(aA1, aA2) * aT * aT + 2.0 * B(aA1, aA2) * aT + C(aA1); }

function binarySubdivide(aX, aA, aB, mX1, mX2) 
{
    let currentX, currentT, i = 0;

    do 
    {
        currentT = aA + (aB - aA) / 2.0;
        currentX = calcBezier(currentT, mX1, mX2) - aX;
        if (currentX > 0.0) 
        {
            aB = currentT;
        }
        else 
        {
            aA = currentT;
        }
    }
    while (Math.abs(currentX) > SUBDIVISION_PRECISION && ++i < SUBDIVISION_MAX_ITERATIONS);

    return currentT;
}

function newtonRaphsonIterate(aX, aGuessT, mX1, mX2) 
{
    for (let i = 0; i < NEWTON_ITERATIONS; ++i) 
    {
        let currentSlope = getSlope(aGuessT, mX1, mX2);
        if (currentSlope === 0.0) 
        {
            return aGuessT;
        }
        let currentX = calcBezier(aGuessT, mX1, mX2) - aX;
        aGuessT -= currentX / currentSlope;
    }
    return aGuessT;
}

export class EasingUtil 
{
    // https://gist.github.com/gre/1650294
    /*
    * Easing Functions - inspired from http://gizma.com/easing/
    * only considering the t value for the range [0, 1] => [0, 1]
    */

    // no easing, no acceleration
    static linear(t) { return t }

    // accelerating from zero velocity
    static easeInQuad(t) { return t * t }

    // decelerating to zero velocity
    static easeOutQuad(t) { return t * (2 - t) }

    // acceleration until halfway, then deceleration
    static easeInOutQuad(t) { return t < .5 ? 2 * t * t : -1 + (4 - 2 * t) * t }

    // accelerating from zero velocity 
    static easeInCubic(t) { return t * t * t }

    // decelerating to zero velocity 
    static easeOutCubic(t) { return (--t) * t * t + 1 }

    // acceleration until halfway, then deceleration 
    static easeInOutCubic(t) { return t < .5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1 }

    // accelerating from zero velocity 
    static easeInQuart(t) { return t * t * t * t }

    // decelerating to zero velocity 
    static easeOutQuart(t) { return 1 - (--t) * t * t * t }

    // acceleration until halfway, then deceleration
    static easeInOutQuart(t) { return t < .5 ? 8 * t * t * t * t : 1 - 8 * (--t) * t * t * t }

    // accelerating from zero velocity
    static easeInQuint(t) { return t * t * t * t * t }

    // decelerating to zero velocity
    static easeOutQuint(t) { return 1 + (--t) * t * t * t * t }

    // acceleration until halfway, then deceleration 
    static easeInOutQuint(t) { return t < .5 ? 16 * t * t * t * t * t : 1 + 16 * (--t) * t * t * t * t }

    // elastic bounce effect at the beginning
    static easeInElastic(t) { return (.04 - .04 / t) * Math.sin(25 * t) + 1 }

    // elastic bounce effect at the end
    static easeOutElastic(t) { return .04 * t / (--t) * Math.sin(25 * t) }

    // elastic bounce effect at the beginning and end
    static easeInOutElastic(t) { return (t -= .5) < 0 ? (.01 + .01 / t) * Math.sin(50 * t) : (.02 - .01 / t) * Math.sin(50 * t) + 1 }

    static easeInSin(t) { return 1 + Math.sin(Math.PI / 2 * t - Math.PI / 2); }

    static easeOutSin(t) { return Math.sin(Math.PI / 2 * t); }

    static easeInOutSin(t) { return (1 + Math.sin(Math.PI * t - Math.PI / 2)) / 2; }

    static easeBezier(mX1, mY1, mX2, mY2): Function 
    {
        if (!(0 <= mX1 && mX1 <= 1 && 0 <= mX2 && mX2 <= 1)) 
        {
            throw new Error('bezier x values must be in [0, 1] range');
        }

        // Precompute samples table
        let sampleValues = float32ArraySupported ? new Float32Array(kSplineTableSize) : new Array(kSplineTableSize);
        if (mX1 !== mY1 || mX2 !== mY2) 
        {
            for (let i = 0; i < kSplineTableSize; ++i) 
            {
                sampleValues[i] = calcBezier(i * kSampleStepSize, mX1, mX2);
            }
        }

        function getTForX(aX) 
        {
            let intervalStart = 0.0;
            let currentSample = 1;
            let lastSample = kSplineTableSize - 1;

            for (; currentSample !== lastSample && sampleValues[currentSample] <= aX; ++currentSample) 
            {
                intervalStart += kSampleStepSize;
            }
            --currentSample;

            // Interpolate to provide an initial guess for t
            let dist = (aX - sampleValues[currentSample]) / (sampleValues[currentSample + 1] - sampleValues[currentSample]);
            let guessForT = intervalStart + dist * kSampleStepSize;

            let initialSlope = getSlope(guessForT, mX1, mX2);
            if (initialSlope >= NEWTON_MIN_SLOPE) 
            {
                return newtonRaphsonIterate(aX, guessForT, mX1, mX2);
            }
            else if (initialSlope === 0.0) 
            {
                return guessForT;
            }
            else 
            {
                return binarySubdivide(aX, intervalStart, intervalStart + kSampleStepSize, mX1, mX2);
            }
        }

        return function BezierEasing(x): number 
        {
            if (mX1 === mY1 && mX2 === mY2) 
            {
                return x; // linear
            }

            // Because JavaScript number are imprecise, we should guarantee the extremes are right.
            if (x === 0) 
            {
                return 0;
            }
            if (x === 1) 
            {
                return 1;
            }
            return calcBezier(getTForX(x), mY1, mY2);
        };
    };
}


export class NetworkUtil 
{
    static httpCall(url, postData, completeFunc, timeout, header, retryCnt)
    {
        try
        {
            if (!timeout)
            {                
                if (cc.sys.isMobile == true) 
                {
                    timeout = 60000; // default 60초대기
                }
                else // debuging 환경에서는 대기시간이 길어야한다.
                 {  
                    timeout = 500000; // testdefault 500초대기
                }
                //timeout = 5000; // default 5초대기  //timeout = 500000; // test 500초대기                
            }
            //let Data = String.fromCharCode.apply(String, postData)
            let xhr = cc.loader.getXMLHttpRequest();
            let callbackCalled = false; // callback이 두번 호출되는거 방지
            xhr.onerror = function () 
            {
                cc.error("httpsCall onerror ", url);
                if (callbackCalled == false)    
                {
                    callbackCalled = true;
                    let error =
                    {
                        errorCode: 7020,
                        errorMsg: "https unknown error",
                        errorStatusCode: 1004
                    };
                    completeFunc(error, null);
                }
            };

            xhr.onreadystatechange = function ()
            {
                //if (!xhr || xhr.isAborted) 
                // readyState 
                // 0 (uninitialized) - (request가 초기화되지 않음)
                // 1 (loading) - (서버와의 연결이 성사됨)
                // 2 (loaded) - (서버가 request를 받음)
                // 3 (interactive) - (request(요청)을 처리하는 중)
                // 4 (complete) - (request에 대한 처리가 끝났으며 응답할 준비가 완료됨)
                // 예를 들어 응답 상태 코드는 404 (Not Found) 이거나
                // 혹은 500 (Internal Server Error) 이 될 수 있음
                // if (!xhr || xhr.abort()) 
                // {
                //     cc.error("[ERROR] http call fail 1. ", url);
                //     if (callbackCalled == false)    
                //     {
                //         callbackCalled = true;
                //         let error = 
                //         {
                //             errorCode: 5001,
                //             errorMsg: "invalid xhr status"
                //         };
                //         completeFunc(error);
                //     }
                //     return;
                // }

                // readyState 가 4가되어야 완료된것이다.
                if (xhr.readyState != 4) 
                {
                    return;
                }

                if (xhr.status != 200)
                {
                    cc.error("[ERROR] https call fail 3. ", url, " status ", xhr.status, "-", JSON.stringify(xhr));
                    cc.error("[ERROR] https call fail 3. " + xhr.responseText);

                    if (callbackCalled == false)
                    {
                        callbackCalled = true;
                        
                        // status코드가 0이라면 네트워크가 불안정한 상태라서 한번 더 요청한다.
                        if (xhr.status == 0 && retryCnt < 1)    
                        {
                            NetworkUtil.httpCall(url, postData, completeFunc, timeout, header, retryCnt + 1);
                            return;
                        }

                        let errObj;
                        try 
                        {
                            errObj = JSON.parse(xhr.responseText);
                            if (typeof errObj.error == 'undefined') 
                            {
                                errObj = { "error": { "code": 7002, "msg": "http status is not 200" }, "reqId": 0 };
                            }
                        }
                        catch (e)    
                        {
                            errObj = { "error": { "code": 7002, "msg": "http status is not 200" }, "reqId": 0 };
                        }
                        let error1 =
                        {
                            errorCode: errObj.error.code,
                            errorMsg: errObj.error.msg,
                            errorStatusCode: xhr.status,
                        };
                        completeFunc(error1, null);
                    }
                    return;
                }

                if (callbackCalled == false)
                {
                    callbackCalled = true;
                    let d = new Date();
                    Util.log("[RES]", xhr.responseText);
                    //Util.log("[https Response]", xhr.responseText);
                    if (xhr.responseText.length == 0)   
                    {
                        let responseURL = "empty";
                        if (typeof xhr.responseURL !== 'undefined') 
                        {
                            responseURL = xhr.responseURL;
                        }
                        let error = 
                        {
                            errorCode: 4051,
                            errorMsg: "xhr.responseText is empty",
                            errorStatusCode: xhr.status,
                            responseURL: responseURL
                        };
                        completeFunc(error, null);
                        return;
                    }
                
                    completeFunc(null, xhr.responseText);
                }
            };

            // ie에선 timeout을 send보낸후에 설정해야한다. https://github.com/stephanebachelier/superapi/issues/5
            let isIE = false;
            if (!cc.sys.isNative && cc.sys.browserType == cc.sys.BROWSER_TYPE_IE)
            {
                isIE = true;
            }

            if (!isIE)
            {
                xhr.timeout = timeout;
            }
            xhr.ontimeout = function ()
            {
                if (callbackCalled == false)
                {
                    callbackCalled = true;
                    let error =
                    {
                        errorCode: 7003,
                        errorMsg: "https timeout",
                        errorStatusCode: 0
                    };
                    completeFunc(error, null);
                }
            };

            if (postData)
            {
                // cc.log("POST call ", url);
                // cc.log("POST data ", postData);
                xhr.open("POST", url, true);
                //xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded; charset=utf-8");
                xhr.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                xhr.setRequestHeader("Cache-Control", "max-age=0, no-cache, no-store");
                xhr.setRequestHeader("Pragma", "no-cache");
                if (isIE)
                {
                    xhr.timeout = timeout;
                }
                if (header)
                {
                    cc.log("header info ", JSON.stringify(header));
                    xhr.setRequestHeader(header.key, header.value);
                    if (header.locKey)  
                    {
                        xhr.setRequestHeader(header.locKey, header.locValue);
                    }
                    xhr.setRequestHeader("Content-Type", "application/json")
                }
                xhr.send(postData);
            }
            else
            {
                cc.log("GET call ", url);
                xhr.open("GET", url, true);
                if (isIE)
                {
                    xhr.timeout = timeout;
                }
                if (header)
                {
                    cc.log("header info ", JSON.stringify(header));
                    xhr.setRequestHeader(header.key, header.value);
                    if (header.locKey)  
                    {
                        xhr.setRequestHeader(header.locKey, header.locValue);
                    }
                    xhr.setRequestHeader("Content-Type", "application/json")
                }
                xhr.send();
            }
        }
        catch (e)
        {
            cc.error("exception ", e.toString());
            if (e.stack)    
            {
                cc.error("callstack ", e.stack.toString());
            }
        }
    }
}

export class TweenUtil extends CoroutineComponent
{
    static DoMoveWorld(targetNode:cc.Node, moveTarget:cc.Node, duration:number, callBack:Function = null, ease:Ease = null)
    {
        cc.tween(targetNode).removeSelf();
        
        cc.tween(targetNode).to(duration, 
        {
            position : targetNode.parent.convertToNodeSpaceAR(NodeUtil.GetWorldPosition(moveTarget))
        }).call(
            ()=>
            {
                if(callBack!=null)
                {
                    callBack.call(targetNode);
                }
            }).start();
    }
    static *WaitForTweenMove(targetNode:cc.Node, duration:number, position:cc.Vec2, ease:Ease = null)
    {
        let origin = targetNode.getPosition();

        cc.tween(targetNode).removeSelf();

        let isTweenEnd = false;
        
        cc.tween(targetNode).to(duration, {position : new cc.Vec3(position.x, position.y, 0)
        }).call(() => isTweenEnd = true).start();

        while(!isTweenEnd)
        {
            yield null;
        }

        targetNode.setPosition(origin);
    }
    static *WaitForTweenMoveLocal(targetNode:cc.Node, duration:number, position:cc.Vec2, ease:Ease = null)
    {
        cc.tween(targetNode).removeSelf();

        let isTweenEnd = false;
        
        cc.tween(targetNode).to(duration, {position : new cc.Vec3(position.x, position.y, 0)
        }, {easing: Ease[ease]}).call(() => isTweenEnd = true).start();

        while(!isTweenEnd)
        {
            yield null;
        }
    }
    public static *DOMoveCurve(targetNode:cc.Node, targetPos: cc.Node, isLocalPosition: boolean, duration:number, curve:cc.CurveRange, delay:number)
    {
        let startPosition : cc.Vec3 = isLocalPosition == true ? targetNode.position.clone() : NodeUtil.GetWorldPosition(targetNode);
        targetPos.z = startPosition.z;
        let pos : cc.Vec3 = null;
        let currentTime: number = 0;
        
        let curveValue: number = 0;

        curveValue = curveValue < 0 ? -1.0 - curveValue : 1.0 - curveValue;
        curveValue *= 10.0 * 100;

        if(!isLocalPosition)
        {
            pos = NodeUtil.GetWorldPosition(targetPos);
        }
        else
        {
            pos = targetPos.position;
        }

        let center: cc.Vec3 = new cc.Vec3(startPosition.add(pos.clone()).mul(0.5).x, startPosition.add(pos.clone()).mul(0.5).y - curveValue, 0);
        //center.y -= curveValue;

        let riseRelCenter: cc.Vec3 = startPosition.sub(center);
        let setRelCenter: cc.Vec3 = pos.clone().sub(center);

        while (true) 
        {
            let targetTime: number = currentTime / duration;
            targetTime = curve.evaluate(targetTime);

            let movePosition : cc.Vec3 = cc.Vec3.ZERO;

            movePosition = this.Slerp(riseRelCenter, setRelCenter, targetTime).add(center);

            if (isLocalPosition == true)
            {
                targetNode.setPosition(movePosition);
            }
            else
            {
                NodeUtil.MoveToWorldPosition(targetNode, movePosition);// .setPosition(movePosition);
            }

            if (currentTime > duration) 
            {
                break;
            }

            currentTime += Time.deltaTime;
            yield null;
        }
    }
    
    protected *DOScaleCurve(target:cc.Node, scale:cc.Vec3, duration:number, curve:cc.CurveRange, delay:number)
    {
        let currentTime: number = 0;
        let startScale = new cc.Vec3(target.scaleX, target.scaleY, target.scaleZ);
        
        while (true) 
        {
            let targetTime: number = currentTime / duration;
            targetTime = curve.evaluate(targetTime);

            if (currentTime > duration) 
            {
                break;
            }
            
            let targetScale : cc.Vec3 = new cc.Vec3(0, 0, 0) ;
            targetScale = cc.Vec3.lerp(targetScale, startScale, scale, targetTime);
            target.setScale(targetScale.x, targetScale.y, targetScale.x);

            currentTime += Time.deltaTime;
            yield null;
        }
    }
    
    static Slerp(a : cc.Vec3, b : cc.Vec3, t : number) : cc.Vec3
    {
        let na = a.normalize();
        let nb = b.normalize();

        let theta = Math.acos(cc.Vec3.dot(na, nb));
        let sinTheta = Math.sin(theta);
        let sinThetaFrom = Math.sin((1 - t) * theta);
        let sinThetaTo = Math.sin(t * theta);

        let magnitudeLerp = cc.misc.lerp(a.mag(), b.mag(), t);
        let slerpVector = (na.mul(sinThetaFrom).add(nb.mul(sinThetaTo))).div(sinTheta);
        
        return slerpVector.mul(magnitudeLerp);
    }
}

export class EnumUtil 
{
    static GetValues<T>(enumType:T) : (string | T)[]
    {
        const values = Object.values(enumType);

        return values.splice(0, values.length/2);
    }
}

declare module Util 
{

}