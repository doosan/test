
// using UnityEngine;
const {ccclass, property, menu, requireComponent} = cc._decorator;

@ccclass
@menu("Util/CanvasGroup")
export class CanvasGroup extends cc.Component 
{
    @property() private Alpha:number = 0;

    public get alpha():number
    {
        return this.Alpha;
    }

    public set alpha(value:number)
    {
        this.Alpha = value;

        this.node.opacity = value;
    }

    public interactable:boolean;// { get; set; }
    public blocksRaycasts:boolean;// { get; set; } //cc.BlockInputEvents
    public ignoreParentGroups:boolean;//{ get; set; } 

    onLoad()
    {
        this.node.opacity = this.alpha;
    }
}