
import InstanceEvent from "../System/InstanceEvent";
import { MyMath } from "./Util";
import Animator from "../animator/Animator";

const {ccclass, property} = cc._decorator;

@ccclass("AnimationCustom")
export class AnimationCustom
{
    @property() public id:string = "";
    @property({type:[cc.Component.EventHandler]}) public action:cc.Component.EventHandler[] = [];
}
export enum AnimationStepType
{
    Activate,
    Animator,
    Spine
}
@ccclass("AnimationStep")
export class AnimationStep
{
    @property({type:cc.Enum(AnimationStepType)}) public type:AnimationStepType = AnimationStepType.Activate;
    @property(cc.Node) public  activeObject:cc.Node = null;
    @property() public activate:boolean = false;
    @property(Animator) public  animator:Animator = null;
    @property() public animationName:string = "";
    @property() public isUI:boolean = false;
    @property(cc.SkeletonAnimation) public  spine:cc.SkeletonAnimation = null;
    @property(cc.SkeletonAnimation) public  spineUI:cc.SkeletonAnimation = null;
    @property() public  spineAnimName:string = "";
    public get Target() : cc.Node
    {
        if (this.type == AnimationStepType.Activate)
        {
            return this.activeObject;
        }
        else if (this.type == AnimationStepType.Animator)
        {
            return this.animator != null ? this.animator.node : null;
        }
        else if (this.type == AnimationStepType.Spine && this.isUI == true)
        {
            return this.spineUI != null ? this.spineUI.node : null;
        }
        else if (this.type == AnimationStepType.Spine && this.isUI == false)
        {
            return this.spine != null ? this.spine.node : null;
        }
        else
        {
            return null;
        }
    }
}

@ccclass
export default class AnimationEventHelper extends cc.Component 
{
    @property() public activeOffWhenAwake : boolean = false;

    // [Obsolete("customEvents deprecated. Use customs instead.")]
    @property({type:[InstanceEvent]}) public customEvents : InstanceEvent[] = [];
    @property({type:[AnimationCustom]}) public customs : AnimationCustom[] = [];
    @property({type:[AnimationStep]}) public steps : AnimationStep[] = [];

    private customEventIndex : number = null;

    onLoad()
    {
        if (this.activeOffWhenAwake)
        {
            this.DeactivateAll();
        }
    }

    onEnable()
    {
        this.ResetCustomEventOrder();
    }

    public DeactivateAll()
    {
        this.steps.forEach(step=>
            {
                if (step.Target != null)
                {
                    step.Target.active = (false);
                }
            });
    }

    public DeactivateStepAt(index:number)
    {
        if (this.steps.length == 0)
        {
            return;
        }

        let step = this.steps[MyMath.clamp(index, 0, this.steps.length - 1)];
        if (step != null && step.Target != null)
        {
            step.Target.active = (false);
        }
    }

    public DeactivateSelf()
    {
        this.node.active = (false);
    }

    public ResetCustomEventOrder()
    {
        this.customEventIndex = 0;
    }

    public InvokeNextCustomEvent()
    {
        if (this.customEventIndex >= this.customs.length)
        {
            return;
        }

        this.InvokeCustomEvent(this.customEventIndex++);
    }

    public InvokeCustomEvent(index:number)
    {
        if (this.customs.length == 0)
        {
            return;
        }

        let customEvent = this.customs[MyMath.clamp(index, 0, this.customs.length - 1)];
        if (customEvent != null && customEvent.action != null)
        {
            cc.Component.EventHandler.emitEvents(customEvent.action);
        }
    }

    public InvokeCustomEventTrigger(trigger:string)
    {
        for (let i = 0; i < this.customs.length; i++)
        {
            let custom = this.customs[i];

            if (custom.id == trigger)
            {
                this.InvokeCustomEvent(i);
                return;
            }
        }
    }

    public PlayStep(index:number)
    {
        if (this.steps.length == 0)
        {
            return;
        }

        let step = this.steps[MyMath.clamp(index, 0, this.steps.length - 1)];

        if (step.Target == null)
        {
            cc.warn(index+" step not working. Target is null");
            return;
        }

        let type = step.type;
        if (step.type == AnimationStepType.Activate)
        {
            step.Target.active = (step.activate);
        }
        else if (step.type == AnimationStepType.Animator)
        {
            step.Target.active = (true);
            step.animator.play(step.animationName);
        }
        else if (step.type == AnimationStepType.Spine)
        {
            step.Target.active = (true);
            let skeletonAnim  = null;
            if (step.isUI)
            {
                skeletonAnim = step.spineUI;
                step.spineUI.clear();
            }
            else
            {
                skeletonAnim = step.spine;
                step.spine.clear();
            }

            if (skeletonAnim != null)
            {
                skeletonAnim.AnimationState.SetAnimation(0, step.spineAnimName, false);
            }
        }
    }
}
