
import CoroutineComponent  from "../System/CoroutineComponent";
import { WaitForSeconds } from "../System/CoroutineComponent";
import { Time } from "../Time/Time";
import Animator from "../animator/Animator";

// using UnityEngine;
const {ccclass, property, menu, requireComponent} = cc._decorator;

export enum AnimationDurationType
{
	ByAnimation,
	ByTime
}

@ccclass
@menu("Animator/AnimatorParser")
export class AnimatorParser extends cc.Component 
{
	@property({type:Animator})	private animator:Animator = null;
	@property({type:cc.Integer})	private animationIndex:number = 0;
	@property({type:cc.AnimationClip})	private animation:cc.AnimationClip = null;	//new AnimationClip 
	@property({type:cc.Integer})	private triggerIndex:number = 0;
	@property()	private trigger:string ="";
	
	private waitForDuration:WaitForSeconds;
	private targetDuration:number = 0;	//float

	public get Trigger():string
	{
		let result:string = "";

		if (this.animator != null && this.animation != null)
		{
			result = this.trigger;
		}

		return result;
	}

	public get Duration():number
	{
		let result:number = 0;

		if (this.animator != null)
		{
			if (this.animation != null)
			{
				result = this.animation.duration;
			}

			// 1. 애니메이터의 마지막 트랜지션이 Exit 상태로 완전히 빠져나가는 것을 기다릴 목적으로
			// 2. 지난 두 프레임의 정도의 시간을 더해줍니다.
			result += (Time.deltaTime * 2);
		}
		
		// Debug.Log("=== Duration : " + result);
		return result;
	}

	public SetTrigger():void
	public SetTrigger(trigger:string):void
	public SetTrigger(trigger:any = null):void
	{
		if(trigger == null || trigger == "")
			this.animator.SetTrigger(this.Trigger);
		else
			this.animator.SetTrigger(trigger);
	}

	public Reset(): void
	{
		this.animator.ResetAllTriggers();
	}

	public ResetState(): void
	{
		this.animator.resetState();
	}

	public WaitForDuration(offset:number = 0):WaitForSeconds	//YieldInstruction
	{
		let targetDuration:number = this.Duration + offset;
		if (targetDuration < 0)
		{
			targetDuration = 0;
		}

		if (this.targetDuration != targetDuration)
		{
			this.waitForDuration = new WaitForSeconds(targetDuration);
			this.targetDuration = targetDuration;
		}

		return this.waitForDuration;
	}

	public ContainsParameter(paramName : string) : boolean
	{
		return this.animator._ac.params.cotainKey(paramName);
		
	}
}