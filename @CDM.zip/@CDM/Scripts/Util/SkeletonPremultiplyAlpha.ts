const {ccclass, property, menu} = cc._decorator;

@ccclass
@menu("Util/SkeletonPremultiplyAlpha")
export default class SkeletonPremultiplyAlpha extends cc.Component 
{   
    // @property(sp.Skeleton)
    // sk:sp.Skeleton = null;

    onLoad() 
    {
        // if(null != this.sk && 16 == this.sk.skeletonData.textures[0].getPixelFormat())
        // {                                
        //     this.sk.skeletonData.textures[0].setPremultiplyAlpha(false);
        // }

        // return;

        // 주의사항 : 같은 Layer에 Spine이 위치해 있어야 한다.
        // pc에서 png, webp를 대상으로 setPremultiplyAlpha값을 false로 바꿨는데 문제가 발생함
        // 첫번째 호출한 Spine만 정상 출력되고 나머지 Spine은 첫번째 이미지 텍스쳐로 다 교체되어 UV가 깨지는 현상
        // 그래서, 반대로 Mobile압축텍스쳐에서 true로 변경하는 방식으로 교체함. 
        // 당연히 이것도 문제가되어야하는데 정상으로 출력이 된다.(2022.07.21 :ver2.4.9)
        // 다른 버젼에서는 이 방식이 안먹을수도 있는데... 그럼 수정이되든지해야지 대안이 없어 보인다.
        let SpineList = this.node.getComponentsInChildren(sp.Skeleton);

        if(SpineList)
        {
            SpineList.forEach(oSpine=>
            {
                if(oSpine.skeletonData && oSpine.skeletonData.textures)
                {
                    oSpine.skeletonData.textures.forEach(oTexture=>
                    {
                        if(oTexture)
                        {
                            // 16:png, webp
                            // if(16 == oTexture.getPixelFormat())
                            // {                                
                            //     oTexture.setPremultiplyAlpha(false);
                            // }

                            if(oTexture.getPixelFormat() == cc.macro.ImageFormat.ETC || oTexture.getPixelFormat() == cc.macro.ImageFormat.PVR)
                            {
                                oTexture.setPremultiplyAlpha(true);
                            }
                        }
                    }, this);
                }        
            }, this);
        }        
    }    
}
