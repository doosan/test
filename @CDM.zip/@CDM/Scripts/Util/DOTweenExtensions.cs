using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;

namespace Gaga.Util
{
    public static class DOTweenExtensions
    {
        public static Tweener DOBezierMove(this Transform tr, Vector3[] wayPoints, float duration)
        {
            return DOBezierMove(tr, wayPoints, duration, false);
        }

        public static Tweener DOBezierLocalMove(this Transform tr, Vector3[] wayPoints, float duration)
        {
            return DOBezierMove(tr, wayPoints, duration, true);
        }

        private static Tweener DOBezierMove(Transform tr, Vector3[] wayPoints, float duration, bool localPosition)
        {
            float moveRate = 0.0f;
            var startPoint = localPosition ? tr.localPosition : tr.position;

            List<Vector3> pointList = new List<Vector3>();
            List<Vector3> resultList = new List<Vector3>();
            
            var tweener = DOTween.To
            (
                ()=> moveRate // get
                , val => // set
                {
                    moveRate = val;

                    pointList.Clear();
                    pointList.Add(startPoint);
                    pointList.AddRange(wayPoints);

                    while (pointList.Count > 1)
                    {
                        resultList.Clear();

                        for( int i = 0; i < pointList.Count - 1; i++)
                        {
                            Vector3 result = Vector3.Lerp(pointList[i], pointList[i + 1], moveRate);
                            resultList.Add(result);
                        }

                        pointList.Clear();
                        pointList.AddRange(resultList);
                    }
                    
                    if (localPosition)
                    {
                        tr.localPosition = pointList[0];
                    }
                    else
                    {
                        tr.position = pointList[0];
                    }
                }
                ,1.0f //end
                ,duration
            );

            return tweener;
        }
    }
}
