const {ccclass, property, requireComponent} = cc._decorator;

@ccclass
@requireComponent(sp.Skeleton)
export default class AutoDisableSpine extends cc.Component 
{
    onLoad () 
    {
        this.getComponent(sp.Skeleton).setCompleteListener(()=>this.node.active = false);
    }
}
