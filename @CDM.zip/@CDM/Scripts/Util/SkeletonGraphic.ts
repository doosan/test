
const {ccclass, menu} = cc._decorator;

@ccclass
@menu("Util/SkeletonGraphic")
export default class SkeletonGraphic extends sp.Skeleton 
{   
    onLoad()
    {
        cc.log("SkeletonGraphic"); 
        
        // 16:png, webp
        // spine에서 png, webp이미지 사용시 이미지 테두리가 어둡게 나오는 현상 제거
        // Premultiply Alpha 옵션 Off
        if(this.skeletonData && this.skeletonData.textures)
        {
            this.skeletonData.textures.forEach(value=>
            {
                if(value)
                {                    
                    //if(16 == value.getPixelFormat())// 16:png, webp
                    if(value.getPixelFormat() == cc.macro.ImageFormat.ETC || value.getPixelFormat() == cc.macro.ImageFormat.PVR)
                    {
                        value.setPremultiplyAlpha(true);
                    }
                }
            }, this);
        }        
    }
    
    // public Initialize (overwrite:boolean) 
    // {
    //     if (this.isValid && !overwrite) return;

    //     // Make sure none of the stuff is null
    //     if (this.skeletonData == null) return;
    //     let skeletonData = this.skeletonData;
    //     if (skeletonData == null) return;

    //     if (skeletonData.atlasText.length <= 0 || skeletonDataAsset.atlasAssets[0].MaterialCount <= 0) return;

    //     this.skeleton.state = new Spine.AnimationState(skeletonDataAsset.GetAnimationStateData());
    //     if (state == null) {
    //         Clear();
    //         return;
    //     }

    //     this.skeleton = new Skeleton(skeletonData) {
    //         ScaleX = this.initialFlipX ? -1 : 1,
    //         ScaleY = this.initialFlipY ? -1 : 1
    //     };

    //     meshBuffers = new DoubleBuffered<MeshRendererBuffers.SmartMesh>();
    //     baseTexture = skeletonDataAsset.atlasAssets[0].PrimaryMaterial.mainTexture;
    //     canvasRenderer.SetTexture(this.mainTexture); // Needed for overwriting initializations.

    //     // Set the initial Skin and Animation
    //     if (!string.IsNullOrEmpty(initialSkinName))
    //         skeleton.SetSkin(initialSkinName);

    //     if (!string.IsNullOrEmpty(startingAnimation)) {
    //         var animationObject = skeletonDataAsset.GetSkeletonData(false).FindAnimation(startingAnimation);
    //         if (animationObject != null) {
    //             state.SetAnimation(0, animationObject, startingLoop);
    //             #if UNITY_EDITOR
    //             if (!Application.isPlaying)
    //                 Update(0f);
    //             #endif
    //         }
    //     }
    // }
}
