interface Math
{
    /*
    include min, exclude max
    */
    randomRangeInsideUnitCircle(): cc.Vec2;

    randomRangeInt(min: number, max:number): number;

    randomRangeFloat(min: number, max:number): number;
    
    fmod(x:number, y:number):number;

    approximately(x:number, y:number):boolean;
    LerpAngle(a : number, b : number, t : number) : number;
    Repeat(t : number, length : number) : number;
    PingPong(t : number, length : number) : number;

    InverseLerp(a : number, b : number, value : number) : number;
    DeltaAngle(current : number, target : number) : number;
}

Math.randomRangeInsideUnitCircle = function(): cc.Vec2
{
	let rand = Math.random();
    if (rand === 1) 
    {
		rand -= Number.EPSILON;
	}
	return new cc.Vec2(Math.randomRangeFloat(-1, 1), Math.randomRangeFloat(-1, 1));
}

Math.randomRangeInt = function(min: number, max:number): number 
{
	let rand = Math.random();
    if (rand === 1) 
    {
		rand -= Number.EPSILON;
	}
	return min + Math.floor(rand * (max - min));
}

Math.randomRangeFloat = function(min: number, max:number): number 
{
    return min + (Math.random() * (max - min));
}

Math.fmod = function(x:number, y:number):number
{
    let temp = Math.floor(x / y);
    return x - temp * y;
}

Math.approximately = function(x:number, y:number):boolean
{
    // If a or b is zero, compare that the other is less or equal to epsilon.
    // If neither a or b are 0, then find an epsilon that is good for
    // comparing numbers at the maximum magnitude of a and b.
    // Floating points have about 7 significant digits, so
    // 1.000001f can be represented while 1.0000001f is rounded to zero,
    // thus we could use an epsilon of 0.000001f for comparing values close to 1.
    // We multiply this epsilon by the biggest magnitude of a and b.
    let a : number = 1.401298E-45;
    return Math.abs(y - x) < Math.max(0.000001 * Math.max(Math.abs(x), Math.abs(y)), a * 8);
}

Math.LerpAngle = function(a : number, b : number, t : number) : number
{
    let delta : number = Math.Repeat((b - a), 360);
    if (delta > 180)
        delta -= 360;
    return a + delta * cc.misc.clamp01(t);
}

Math.Repeat = function(t : number, length : number) : number
{
    return cc.misc.clampf(t - Math.floor(t / length) * length, 0.0, length);
}

Math.InverseLerp = function(a : number, b : number, value : number) : number
{
    if (a != b)
        return cc.misc.clamp01((value - a) / (b - a));
    else
        return 0.0;
}

Math.PingPong = function(t : number, length : number) : number
{
    t = this.Repeat(t, length * 2);
    return length - Math.abs(t - length);
}

Math.DeltaAngle = function(current : number, target : number) : number
{
    let delta : number = Math.Repeat((target - current), 360.0);
    if (delta > 180.0)
        delta -= 360.0;
    return delta;
}