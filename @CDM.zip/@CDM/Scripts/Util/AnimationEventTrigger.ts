﻿
const { ccclass, property } = cc._decorator;

@ccclass
export default class AnimationEventTrigger extends cc.Component
{
    @property([cc.Component.EventHandler]) OnTrigger:  cc.Component.EventHandler[] = [];
    @property([cc.Component.EventHandler]) OnTrigger2: cc.Component.EventHandler[] = [];
    @property([cc.Component.EventHandler]) OnTrigger3: cc.Component.EventHandler[] = [];
    @property([cc.Component.EventHandler]) OnTrigger4: cc.Component.EventHandler[] = [];

    public Trigger(): void
    {
        if (this.OnTrigger != null)
        {
            cc.Component.EventHandler.emitEvents(this.OnTrigger);         
        }
    }

    public Trigger2(): void
    {
        if (this.OnTrigger2 != null)
        {
            cc.Component.EventHandler.emitEvents(this.OnTrigger2);
        }
    }

    public Trigger3(): void
    {
        if (this.OnTrigger3 != null)
        {
            cc.Component.EventHandler.emitEvents(this.OnTrigger3);
        }
    }

    public Trigger4(): void
    {
        if (this.OnTrigger4 != null)
        {
            cc.Component.EventHandler.emitEvents(this.OnTrigger4);
        }
    }
}