import { Coroutine } from "../System/CoroutineComponent";

export default abstract class CustomYieldInstruction// implements IEnumerator
{
    //protected constructor();

    //
    // 요약:
    //     Indicates if coroutine should be kept suspended.
    public abstract get keepWaiting() : boolean;
    public get Current() : any {return null;}

    public get MoveNext() : boolean {return false;};
    public get Reset() : boolean {return false;};
    public coroutine : Coroutine = null;
}