
const {ccclass, property, menu} = cc._decorator;

@ccclass
@menu("Particle/NewParticleSystem3D")
export default class NewParticleSystem3D extends cc.ParticleSystem3D 
{
    @property({displayName: "자동 초기화 설정"}) public isAutoReset : boolean = true;

    onEnable(): void 
    {
        if(this.isAutoReset)
        {
            this.clear();
            this.stop();
            this.play();
        }

        super.onEnable();
    }
}
