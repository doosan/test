const {ccclass, property} = cc._decorator;

@ccclass
export default class AutoDisableObject extends cc.Component 
{
    @property duration: number = 0;

    protected onEnable(): void
    {
        this.scheduleOnce(()=>this.node.active = false, this.duration);
    }

    protected onDisable(): void
    {
        this.unscheduleAllCallbacks();
        this.node.active = false;
    }
}
