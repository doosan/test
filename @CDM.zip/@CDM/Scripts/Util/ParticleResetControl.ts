//파티클 컴포넌트가 부착된 노드에 추가 (하위 자식들의 파티클 노드들이 활성화 되어있으면 자식 노드에는 추가안해도됨)

const {ccclass, property} = cc._decorator;

@ccclass
export default class ParticleResetControl extends cc.Component 
{
    private particleList : cc.ParticleSystem3D[] = [];

    onLoad()
    {
        this.FindAllParticle(this.node);
    }
    
    onEnable(): void 
    {
        this.Play();
    }

    public Play():void
    {
        this.particleList.forEach(p =>{
            if(p.node != this.node)
            {
                p.node.active = false;
                p.node.active = true;
            }
            p.clear();
            p.stop();
            p.play();
        });
    }
   
    FindAllParticle(node: cc.Node)
    {
        if(node.getComponent(cc.ParticleSystem3D) != null)
        {
            this.particleList.push(node.getComponent(cc.ParticleSystem3D));
        }        

        for (let i = 0; i < node.childrenCount; i++)
        {
            this.FindAllParticle(node.children[i]);           
        }
    }
}
