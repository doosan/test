import TimeSpan from "../Time/TimeSpan";

const { ccclass, property } = cc._decorator;

@ccclass("KBMOption")
export class KMBOption
{
    // k 유닛 시작포인트 
    // 0 이면 1000 = 1k,   10000 = 10k
    // 1 이면 1000 = 1000, 10000 = 10k
    // 2 이면 1000 = 1000, 10000 = 10000, 100000 = 100k, 
    // 3 이면 1000 = 1000, 10000 = 10000, 100000 = 100000, 1000000 = 1m
    @property() kiloStartingPoint:number = 0;

    // 숫자와 유닛 사이 띄어쓰기
    @property() space:boolean = false;

    // 소수점 아래 자릿수 포함 최소 길이
    // ignoreDecimalPointUnderKilos 가 false 인 경우
    // 1 이면 1200 = 1k
    // 2 이면 1200 = 1.2k       
    // 3 이면 1200 = 1.20k
    @property() minLength:number = 0;

    // 키로 미만 소숫점 제거 
    @property() ignoreDecimalPointUnderKilos:boolean = false;

    // 0 소수점 제거
    @property() ignorZeroDecimalPoint:boolean = false;

    // 유효 시작값 
    // 1000 이면 1000 미만 값이 들어오면 옵션 무시
    @property() startingValue:number = 0;
    @property() forceKMBUnitIndex:number = null;
}

//StringBulder 대체 클래스 
export class StringBuilder
{
    public buffer : Array<string>;

    constructor()
    {
        this.buffer = new Array<string>();
    }

    Clear()
    {
        if(null != this.buffer)
        {
            this.buffer.length = 0;
        }
    }

    Append(strValue:string | number)
    {
        this.buffer[this.buffer.length] = strValue.toString();
    }
    
    AppendFormat()
    {
        let count = arguments.length;
        
        if(count < 2) 
            return "";
        
        let strValue = arguments[0];
        
        for(let i=1; i<count;i++)
        {
            strValue = strValue.replace("{"+(i-1)+"}",arguments[i]);
        }
        
        this.buffer[this.buffer.length] = strValue;
    }

    Insert(idx:number, strValue:string)
    {
        this.buffer.splice(idx, 0, strValue);
    }
    
    Replace(from:string, to:string)
    {
        for(let i=this.buffer.length-1; i>=0; i--)
        {
            this.buffer[i] = this.buffer[i].replace(from, to);
        }
    }
    
    ToString()
    {
        return this.buffer.join("");
    }
}

export default class StringUtils
{
    private static KMB_UNIT:string[] = ["K","M","B","T"];

    private static formatKey:Map<number, string>;
    private static formatKeyCount:number = 10;
    private static stringBuilder:string;//StringBuilder;
    
    //private static culture:CultureInfo = new CultureInfo("en-US");
    private static culture:string = "en-US";

    static StringUtils()
    {
        //this.stringBuilder = new StringBuilder(64);


        
        this.formatKey = new Map<number, string>();
        for (let i:number = 0; i < this.formatKeyCount; i++)
        {
            this.stringBuilder = ""
            this.stringBuilder = "{" + i + "}";
            // stringBuilder.Length = 0;
            // stringBuilder.Append("{");
            // stringBuilder.Append(i);
            // stringBuilder.Append("}");
            this.formatKey.set(i, this.stringBuilder);
        }
    }

    static Insert(str, startIndex, value)
    {
        return [str.slice(0, startIndex), value, str.slice(startIndex)].join('');
    }

    static IsNullOrEmpty(value?: string): boolean 
    {
        return value == null || value === "" || value == undefined;
    }

    public static ToComma(value:number):string
    {     
        //Intl.NumberFormat()   
        //value.toLocaleString()
        //return value.toString("#,##0");
        let strTemp:string = value.toLocaleString();
        return strTemp;
    }

    public static ToCommaWithSign(value:number):string
    {
        let strTemp:string = "";

        if(value > 0)
        {
            strTemp = "+"+value.toLocaleString();
        }
        else 
        {
            strTemp = value.toLocaleString();
        }

        return strTemp;//value.toString("+#,##0;-#,###");
    }

    // public static ToComma(value:number):string
    // {
    //     return  value.toString("#,##0");
    // }

    // public static string ToComma(double value):string
    // {
    //     return value.ToString("#,##0");
    // }

    // public static string ToComma(decimal value)
    // {
    //     return value.ToString("#,##0");
    // }

    // public static string ToComma(float value)
    // {
    //     return value.ToString("#,##0");
    // }

    // public static string ToComma(long value)
    // {
    //     return value.ToString("#,##0");
    // }

    // Test had written in StringUtilsTest file.
    public static Merge(values:string[]):string //params 
    {
        //stringBuilder.Length = 0;
        this.stringBuilder = "";

        for (let i:number = 0; i < values.length; i++)
        {
            this.stringBuilder += values[i];
        }

        return this.stringBuilder;
    }

    // Test had written in StringUtilsTest file.
    static Format(format: string, ...args: any[]): string 
    {
        let s = format;
        for (let i = 0; i < args.length; i++) 
        {
            let reg = new RegExp("\\{" + i + "\\}", "gm");
            if (null == args[i])
            {
                cc.warn(format + "에 null 값이 있습니다. - 체크해주세요.");
                args[i] = "null값";
            }
            s = s.replace(reg, args[i].toString());
        }

        return s;
    }

    // public static InsertSpaceBeforeUppercase(str:string):string //this 
    // {   
    //     StringBuilder sb = new StringBuilder();

    //     char previousChar = char.MinValue; // Unicode '\0'
    //     foreach (char c in str) 
    //     {
    //         if (char.IsUpper(c)) 
    //         {
    //             // If not the first character and previous character is not a space, insert a space before uppercase
    //             if (sb.Length != 0 && previousChar != ' ') 
    //             {
    //                 sb.Append(' ');
    //             }           
    //         }

    //         sb.Append(c);
    //         previousChar = c;
    //     }

    //     return sb.ToString();
    // }

    public static ToGeneralKMB(value : number) : string
    {
        let kmbOption : KMBOption = this.GeneralKMBOption();
        return this.ToKMB2(value, kmbOption);
    }
    public static ToGeneralKMB_SK(value : number) : string
    {
        let kmbOption : KMBOption = this.GeneralKMBOption_SK();
        return this.ToKMB2(value, kmbOption);
    }
    public static DefaultKMBOption():KMBOption
    {
        let option = new KMBOption();
        option.kiloStartingPoint = 0;
        option.space = false;
        option.minLength = 1;
        option.ignoreDecimalPointUnderKilos = false;
        option.startingValue = 0;

        return option;
    }

    public static GeneralKMBOption(startingValue : number = 0) : KMBOption
    {
        let option = StringUtils.DefaultKMBOption();
        option.kiloStartingPoint = 0;
        option.ignorZeroDecimalPoint = true;
        option.ignoreDecimalPointUnderKilos = false;
        option.minLength = 3;
        option.startingValue = startingValue;

        return option;
    }

    public static GeneralKMBOption_SK(startingValue : number = 0) : KMBOption
    {
        let option = StringUtils.DefaultKMBOption();
        option.kiloStartingPoint = 0;
        option.ignorZeroDecimalPoint = false;
        option.ignoreDecimalPointUnderKilos = false;
        option.minLength = 3;
        option.startingValue = startingValue;

        return option;
    }

    // public static ToKMB(value:number, kiloStartingPoint:number = 0, space:boolean = false, minLength:number = 1, ignoreDecimalPointUnderKilos:boolean = true):string
    // {
    //     return ToKMB((long)value, kiloStartingPoint, space, minLength , ignoreDecimalPointUnderKilos);
    // }

    public static ToKMB(value:number, kiloStartingPoint:number = 0, space:boolean = false, minLength:number = 2, ignoreDecimalPointUnderKilos:boolean = false, ignorZeroDecimalPoint = false):string
    {
        let option = new KMBOption();
        option.kiloStartingPoint = kiloStartingPoint;
        option.space = space;
        option.minLength = minLength;
        option.ignoreDecimalPointUnderKilos = ignoreDecimalPointUnderKilos;
        option.startingValue = 0;
        option.ignorZeroDecimalPoint = ignorZeroDecimalPoint;

        return this.ToKMB2(value, option);
    }

    // public static string ToKMB(let value, KMBOption option)
    // {
    //     return ToKMB((long)value, option);
    // }

    public static ToKMB2(value:number, option:KMBOption, kmbMinValue : number = null):string
    {
        if(kmbMinValue!=null)
        {
            let kmbMinValueStr : string = kmbMinValue.toString();
            let kiloStartingPoint : number = kmbMinValueStr.length - 4; // 1000000 -> 3
            if (value >= kmbMinValue)
            {
                return this.ToKMB2(value, option);
            }
            else
            {
                return this.ToKMB(value, kiloStartingPoint);
            }
        }

        let startingValue = option.startingValue;

        if (startingValue <= value)
        {
            let kiloStartingPoint = option.kiloStartingPoint;
            let space = option.space;
            let minLength = option.minLength;
            let ignoreDecimalPointUnderKilos = option.ignoreDecimalPointUnderKilos;
            let ignorZeroDecimalPoint = option.ignorZeroDecimalPoint;
            
            let forceUnitIndex:number = option.forceKMBUnitIndex;
            if(option.forceKMBUnitIndex != null && forceUnitIndex >= StringUtils.KMB_UNIT.length)
            {
                forceUnitIndex = Math.trunc(StringUtils.KMB_UNIT.length - 1); //Math.floor(option.forceKMBUnitIndex);
            }

            let valueLength = Math.trunc(value > 0 ? Math.log10(value) + 1 : 1);

            if (kiloStartingPoint < 0)
            {
                kiloStartingPoint = 0;
            }

            this.stringBuilder = "";

            if (( valueLength < 4 + kiloStartingPoint && forceUnitIndex == null) ||
                (forceUnitIndex != null && forceUnitIndex < 0))
            {
                let valueString :string = StringUtils.ToComma(value);

                this.stringBuilder += valueString;

                if (ignoreDecimalPointUnderKilos == false)
                {
                    if (ignorZeroDecimalPoint == false)
                    {
                        let pointCount = Math.trunc(minLength) - valueString.length;
                        if (pointCount > 0)
                        {
                            this.stringBuilder = ".";
                            for (let i = 0; i < pointCount; i++)
                            {
                                this.stringBuilder += "0";
                            }
                        }
                    }
                }
            }
            else
            {
                let valueString = value.toString();

                let unitLength = 1;
                let unitIndex = 0;
                
                for (let i = 0; i < StringUtils.KMB_UNIT.length; i++)
                {
                    unitIndex = i;
                    unitLength += 3;

                    if ((unitLength + 3 + kiloStartingPoint > valueLength ) ||
                        (forceUnitIndex != null && forceUnitIndex == unitIndex))
                    {
                        break;
                    }
                }

                if( forceUnitIndex != null && forceUnitIndex >= 0)
                {
                    let forceUnitLength = Math.trunc(1 + (forceUnitIndex + 1 ) * 3);
                    unitIndex = forceUnitIndex;
                    unitLength = forceUnitLength;
                }

                let prePointCount = unitLength - valueLength;
                if( prePointCount > 0 )
                {
                    unitLength = 1;
                }
                else
                {
                    unitLength = valueLength - unitLength + 1;
                }
                
                unitLength = Math.trunc(unitLength);
                prePointCount = Math.trunc(prePointCount);

                value = +valueString.substring(0, unitLength);

                let pointValue:string = null;
                let pointCount = Math.trunc(minLength - unitLength);

                //소수점 표현 자리 수
                if (pointCount > 0 && prePointCount == 0)
                {
                    pointValue = valueString.substring(unitLength, pointCount + unitLength);

                    if (ignorZeroDecimalPoint == true)
                    {
                        if (+pointValue == 0)
                        {
                            pointValue = null;
                        }
                        else
                        {
                            let pointCnt = pointValue.length;

                            for (let i = pointValue.length - 1; i >= 0; i--)
                            {
                                let pointVal = pointValue[i];

                                if (pointVal != '0')
                                {
                                    pointCnt = i + 1;
                                    break;
                                }
                            }

                            pointValue = pointValue.substring(0, pointCnt);
                        }
                    }
                }

                if( prePointCount > 0 )
                {
                    for( let i = 0; i < prePointCount; ++i)
                    {
                        this.stringBuilder += i == 0 ? "0." : "0";
                    }
                }

                this.stringBuilder += StringUtils.ToComma(value);

                if (pointValue != null)
                {
                    this.stringBuilder += ".";
                    this.stringBuilder += pointValue;
                }

                if (space == true)
                {
                    this.stringBuilder += " ";
                }

                this.stringBuilder += StringUtils.KMB_UNIT[unitIndex];
            }

            return this.stringBuilder.toString();
        }
        else
        {
            return StringUtils.ToComma(value);
        }
    }

    public static ToKMBUnit(value:number, kiloStartingPoint : number, maxLength : number) : string
    {
        let kmbOption: KMBOption = StringUtils.DefaultKMBOption();
        kmbOption.kiloStartingPoint = kiloStartingPoint;
        //kmbOption.forceKMBUnitIndex = StringUtils.DetermineKMBUnit(value, maxLength);
        return StringUtils.ToKMB2(value, kmbOption)
    }

    public static DetermineKMBUnit(value: number, maxLength: number): number
    {
        let kmbUnitIndex: number = null;

        if (maxLength == 0)
        {
            return null;
        }

        let coinLength = value > 0 ? (Math.log10(value) + 1) : 1;

        if (coinLength <= maxLength)
        {
            return null;
        }

        let diff = coinLength - maxLength;
        kmbUnitIndex = (diff - 1) / 3;

        cc.log(kmbUnitIndex);

        return kmbUnitIndex;
    }


    public static ToCurrency(value:number):string
    {
        //return value.toString("C2", culture);

        // let number:number = 1234567;
        // // 한국 원화는 보조 통화 단위를 사용하지 않음
        // cc.log(new Intl.NumberFormat('ko-KR', { style: 'currency', currency: 'KRW' }).format(number));
        // // → ₩123,457

        // let number1:number = 2.99;
        // cc.log(new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(number1));

        let strTemp:string = new Intl.NumberFormat(this.culture, { style: 'currency', currency: 'USD' }).format(value)

        return strTemp;
    }

    // C#과는 다르게 Return으로 값을 받음
    public static SetForceUnitKMB(winCoins:number, kmbMaxLength:number, forceUnitIndex:number):KMBOption
    {
        let kmbOption:KMBOption = new KMBOption();
        let coinLength = winCoins > 0 ? (Math.log10(winCoins) + 1) : 1;
        if (coinLength >= kmbMaxLength)
        {
            var diff = Math.min(0, coinLength - kmbMaxLength);
            forceUnitIndex = Math.max(diff, forceUnitIndex);
            kmbOption.forceKMBUnitIndex = forceUnitIndex;
        }

        return kmbOption;        
    }


    public static ToSingleUnit(count:number):string
    {
        return (count < 10) ? count.toString() : "9+";
    }

    static ToDigit(time: TimeSpan): string
    {
        let str: string = '';

        str = str + ((time.days * 24 + time.hours < 10) ? '0' + time.hours.toString() : (time.days * 24 + time.hours).toString());
        str = str + ":";
        str = str + ((time.minutes < 10) ? '0' + time.minutes.toString() : time.minutes.toString());
        str = str + ":";
        str = str + ((time.seconds < 10) ? '0' + time.seconds.toString() : time.seconds.toString());

        return str;
    }

    static ToDigitHM(ts: number): string
    {   
        let str: string = '';
        if(ts <= 0)
        {
            str = str + "+";
        }
        else
        {
            str = str + "-";
        }

        let time : TimeSpan = TimeSpan.fromSeconds(Math.abs(ts));
        
        
        str = str + ((time.minutes < 10) ? '0' + time.minutes.toString() : time.minutes.toString());
        str = str + ":";
        str = str + ((time.seconds < 10) ? '0' + time.seconds.toString() : time.seconds.toString());

        return str;
    }

    private static timeSb: StringBuilder = new StringBuilder();
    private static readonly FORMAT_NDays:string = "{0}DAYS LEFT";
    private static readonly FORMAT_SUMMARYDHMS: string = "{0}:{1}:{2}";
    private static readonly FORMAT_DIGITS: string = "00";
    private static readonly FORMAT_D: string = "D";
    private static readonly TIME_SUFFIX_D_BLANK: string = "d ";
    private static readonly TIME_SUFFIX_H_BLANK: string = "h ";
    private static readonly TIME_SUFFIX_M_BLANK: string = "m ";
    private static readonly TIME_SUFFIX_S_BLANK: string = "s ";

    static ToNewsAgo(seconds: number): string
    {
        let timeSb: string = "";
        let timeSpan: TimeSpan = TimeSpan.fromSeconds(seconds);

        if (timeSpan.days > 0)
        {
            timeSb += timeSpan.days.toString();
            timeSb += "d ago";
        }
        else if (timeSpan.hours > 0)
        {
            timeSb += timeSpan.hours.toString();
            timeSb += "h ago";
        }
        else if (timeSpan.minutes > 0)
        {
            timeSb += timeSpan.minutes.toString();
            timeSb += "m ago";
        }
        else
        {
            timeSb += "recently";
        }

        return timeSb.toString();
    }

    static ToAgo(seconds: number): string
    {
        let timeSb: string = "";
        let timeSpan: TimeSpan = TimeSpan.fromSeconds(seconds);

        if (timeSpan.days == 1)
        {
            timeSb += timeSpan.days.toString();
            timeSb += "day ago";
        }
        else if (timeSpan.days > 1)
        {
            timeSb += timeSpan.days.toString();
            timeSb += "days ago";
        }
        else if (timeSpan.hours > 0)
        {
            timeSb += timeSpan.hours.toString();
            timeSb += "h ago";
        }
        else if (timeSpan.minutes > 0)
        {
            timeSb += timeSpan.minutes.toString();
            timeSb += "m ago";
        }
        else
        {
            timeSb += ("recently");
        }

        return timeSb.toString();
    }

    static ToHM(seconds: number): string
    {
        let timeSb: string = "";
        let timeSpan: TimeSpan = TimeSpan.fromSeconds(seconds);

        //timeSb = 0;
        if (timeSpan.hours > 0)
        {
            timeSb += ((timeSpan.hours + (timeSpan.days * 24)).toString());
            timeSb += ("h ");
        }
        if (timeSpan.minutes > 0)
        {
            timeSb += (timeSpan.minutes.toString());
            timeSb += ("m ");
        }

        return timeSb.toString();
    }

    static ToHMS(seconds: number): string
    {
        let timeSb: string = "";
        let timeSpan: TimeSpan = TimeSpan.fromSeconds(seconds);

        //timeSb = 0;
        if (timeSpan.hours > 0)
        {
            timeSb += ((timeSpan.hours + (timeSpan.days * 24)).toString());
            timeSb += ("h ");
        }
        if (timeSpan.minutes > 0)
        {
            timeSb += (timeSpan.minutes.toString());
            timeSb += ("m ");
        }
        if (timeSpan.seconds > 0)
        {
            timeSb += (timeSpan.seconds.toString());
            timeSb += ("s");
        }

        return timeSb.toString();
    }

    // 24시간 이상일 경우 {N}Days Left (e.g. 1Days Left)
    // 24시간 미만인 경우 hh:mm:ss (e.g. 47:02:02) 로 변환
    static ToNDaysLeft(seconds: number): string
    {
        let timeSb: string = "";
        let timeSpan = TimeSpan.fromSeconds(seconds);
        if (timeSpan.inHours >= 24)
        {
            return StringUtils.Format(StringUtils.FORMAT_NDays, Math.floor(timeSpan.inHours / 24));
        }
        else
        {
            timeSb = this.FormatDigits(Math.floor(timeSpan.inHours)) + ":" + this.FormatDigits(timeSpan.minutes) + ":" + this.FormatDigits(timeSpan.seconds);
            return timeSb;
        }
    }

    static ToSummaryDHMS(seconds: number, endMessage : string = ""): string
    {
        if (seconds < 0)
        {
            seconds = 0;
        }

        let timeSb: string = "";
        let timeSpan = TimeSpan.fromSeconds(seconds);
        
        if (timeSpan.inHours >= 48)
        {
            return this.ToSummaryDHM(seconds);
        }
        else
        {
            if (seconds == 0
                && StringUtils.IsNullOrEmpty(endMessage) == false)
            {
                timeSb = timeSb + endMessage;
            }
            else
            {
                timeSb = this.FormatDigits(Math.floor(timeSpan.inHours)) + ":" + this.FormatDigits(timeSpan.minutes) + ":" + this.FormatDigits(timeSpan.seconds);
            }
            return timeSb;
        }
    }

    static ToDHMS(seconds: number): string
    {
        let timeSb: string = "";
        let timeSpan = TimeSpan.fromSeconds(seconds);
      
        if (timeSpan.days >= 1)
        {
            timeSb += timeSpan.days.toString();
            timeSb += "d ";
        }

        timeSb = timeSb + this.FormatDigits(Math.floor(timeSpan.hours)) + ":" + this.FormatDigits(timeSpan.minutes) + ":" + this.FormatDigits(timeSpan.seconds);
        return timeSb;
        
    }

    static FormatDigits(value : number)
    {
        let base = "";
        if(value < 10)
        {
            base = "0" + value.toString();
        }
        else
        {
            base = value.toString();
        }

        return base;
    }

    static ToSummaryDHM(seconds: number): string
    {
        let timeSb: string = "";
        let timeSpan: TimeSpan = TimeSpan.fromSeconds(seconds);

        //Debug.LogFormat("   totalh: {0} totalM: {1} == {2}",timeSpan.TotalHours, timeSpan.TotalMinutes, timeSpan);

        if (timeSpan.inHours >= 48)
        {
            timeSb += timeSpan.days.toString();
            timeSb += "d ";

            timeSb += timeSpan.hours.toString();
            timeSb += "h";
        }
        else
        {
            if (timeSpan.minutes < 60 && timeSpan.hours < 1)
            {
                if (timeSpan.minutes > 1)
                {
                    timeSb += timeSpan.minutes.toString();
                    timeSb += "m ";
                }
            }
            else
            {
                timeSb += timeSpan.inHours.toString();
                timeSb += "h ";

                timeSb += timeSpan.minutes.toString();
                timeSb += "m";
            }
        }

        return timeSb;
    }


    public static ToBoosterRewardHM(minute : number) : string
    {
        let seconds : number = minute * 60;
            
        let timeSb: string = "";
        let timeSpan : TimeSpan = TimeSpan.fromSeconds(seconds);

        let hours: number = Math.floor(minute / 60);

        if(minute >= 120)
        {
            timeSb += hours.toString(); //FORMAT_D "D"
            timeSb += "h";
        }
        else
        {
            timeSb += minute.toString(); //FORMAT_D;
            timeSb += "min";
        }
        
        return timeSb;
    }

    public static PeriodFullTime(start : number, end : number) : string
    {
        return this.DateFullTime(start) + ' ~ ' +  this.DateFullTime(end);
    }

    public static PeriodWeekTime(start : number, end : number) : string
    {
        return this.DateDayTime(start) + ' ~ ' +  this.DateDayTime(end);
    }

    public static DateFullTime(dt : number)
    {
        let date: Date = new Date(dt * 1000);

        let dateStr = date.toUTCString().split(' ');

        return this.DateMonthTime(dt) + ' ' + this.OrdinalNumber(parseInt(dateStr[1]), true) + ' ' +  date.toUTCString().split(' ')[4];
    }

    public static DateDayTime(dt : number)
    {
        let date: Date = new Date(dt * 1000);

        let dateStr = date.toUTCString().split(' ');

        return this.DateMonthTime(dt) + ' ' + this.OrdinalNumber(parseInt(dateStr[1]), true);
    }

    public static DateMonthTime(dt : number)
    {
        let date: Date = new Date(dt * 1000);

        let month : Array<string> = ["January","February","March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

        return month[date.getUTCMonth()];
    }

    public static ToYMD(dt : number)
    {
        let date: Date = new Date(dt * 1000);
        
        return date.getUTCFullYear() + "-" + (date.getUTCMonth() + 1).toString() + "-" + date.getUTCDate().toString();
    }

    public static ToHMDigit(dt : number, end : boolean = false)
    {
        let date: Date = new Date(dt * 1000);
        
        let dateStr = date.toUTCString().split(' ');

        let t : string = dateStr[4].substring(0, 5);

        if(end)
        {
            if(t=="00:00")
            {
                t = "24:00";
            }
        }

        return t;
    }

    static remainTimeReadableFormat(timeSpan: TimeSpan, dictionary?: { [id: string]: string }): string 
    {
        let getWord = (key) => (dictionary && dictionary[key]) || "";
        let ret = "";

        if (timeSpan.days) 
        {
            ret = timeSpan.days.toString() + " " + (timeSpan.days === 1 ? getWord("day") : getWord("days"));

            if (timeSpan.hours) 
            {
                ret += " " + timeSpan.hours.toString() + " " + (timeSpan.hours === 1 ? getWord("hour") : getWord("hours"));
            }
        }
        else if (timeSpan.hours) 
        {
            ret = timeSpan.hours.toString() + " " + (timeSpan.hours === 1 ? getWord("hour") : getWord("hours"));

            if (timeSpan.minutes) 
            {
                ret += " " + timeSpan.minutes.toString() + " " + (timeSpan.minutes === 1 ? getWord("minute") : getWord("minutes"));
            }
        }
        else if (timeSpan.minutes) 
        {
            ret = timeSpan.minutes.toString() + " " + (timeSpan.minutes === 1 ? getWord("minute") : getWord("minutes"));

            if (timeSpan.seconds) 
            {
                ret += " " + timeSpan.seconds.toString() + " " + (timeSpan.seconds === 1 ? getWord("second") : getWord("seconds"));
            }
        }
        else 
        {
            ret = timeSpan.seconds.toString() + " " + (timeSpan.seconds === 1 ? getWord("second") : getWord("seconds"));
        }

        return ret;
    }

    static remainTimeDigitFormat(timeSpan: TimeSpan, scale: "days" | "hours" | "mininutes" | "auto" = "auto"): string 
    {
        let format = "";

        if (scale === "auto" && timeSpan.days || scale === "days") 
        {
            format = "{0} {1}:{2}:{3}";
        }
        else if (scale === "auto" && timeSpan.hours || scale === "hours") 
        {
            format = "{1}:{2}:{3}";
        }
        else
        {
            format = "{2}:{3}";
        }

        return this.Format(format, timeSpan.days, this.zeroPad(timeSpan.hours, 2), this.zeroPad(timeSpan.minutes, 2), this.zeroPad(timeSpan.seconds, 2));
    }

    static abbreviateNumber(value: number, precision = 2) 
    {
        let suffixes = ["", "K", "M", "B", "T"];
        let suffix = '';

        let newValue = value;
        for (let i = suffixes.length - 1; i > 0; i--) 
        {
            let basis = Math.pow(1000, i);
            if (value >= basis) 
            {
                newValue = value / basis;
                suffix = suffixes[i];
                break;
            }
        }

        return (newValue).toFixed(precision).replace(/([0-9]+(\.[0-9]+[1-9])?)(\.?0+$)/, '$1') + suffix;
    }

    static currencyFormat(number: number, decimalPoint = 2): string 
    {
        if (number === 0) 
        {
            return "0";
        }

        return number.toFixed(decimalPoint).replace(/(\d)(?=(\d{3})+(\.|$))/g, '$1,');
    }

    static zeroPad(number: number, size = 3): string 
    {
        let s = StringUtils.repeat("0", size) + number;
        return s.substring(s.length - size);
    }

    static zeroPadIn(str: string): number 
    {
        var r = /\d+/;
        return Number(str.match(r));
    }

    static repeat(str: string, size: number) 
    {
        let result = "";
        for (let i = 0; i < size; i++) 
        {
            result += str;
        }
        return result;
    }

    private static readonly possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    static randomString(length: number): string
    {
        let text = "";

        for (let i = 0; i < length; i++) 
        {
            text += this.possible.charAt(Math.floor(Math.random() * this.possible.length));
        }

        return text;
    }

    static getQueryString(url: string, paramName: string): string | null 
    {
        let urlTemp = url.substring(1);
        let tempArray = urlTemp.split('&');
        for (let i = 0; i < tempArray.length; ++i) 
        {
            let pair = tempArray[i].split('=');

            if (pair[0] === paramName) 
            {
                return pair[1];
            }
        }
        return null;
    }

    private static _utf8_encode(string) 
    {
        string = string.replace(/\r\n/g, "\n");
        var utftext = "";
        for (var n = 0; n < string.length; n++) 
        {
            var c = string.charCodeAt(n);
            if (c < 128) 
            {
                utftext += String.fromCharCode(c);
            }
            else if ((c > 127) && (c < 2048)) 
            {
                utftext += String.fromCharCode((c >> 6) | 192);
                utftext += String.fromCharCode((c & 63) | 128);
            }
            else 
            {
                utftext += String.fromCharCode((c >> 12) | 224);
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                utftext += String.fromCharCode((c & 63) | 128);
            }

        }
        return utftext;
    }

    static base64Encode(input: string) 
    {
        var _keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";

        var output = "";
        var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
        var i = 0;
        input = this._utf8_encode(input);
        while (i < input.length) 
        {
            chr1 = input.charCodeAt(i++);
            chr2 = input.charCodeAt(i++);
            chr3 = input.charCodeAt(i++);
            enc1 = chr1 >> 2;
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
            enc4 = chr3 & 63;
            if (isNaN(chr2)) 
            {
                enc3 = enc4 = 64;
            }
            else if (isNaN(chr3)) 
            {
                enc4 = 64;
            }
            output = output + _keyStr.charAt(enc1) + _keyStr.charAt(enc2) + _keyStr.charAt(enc3) + _keyStr.charAt(enc4);
        }
        return output;
    }

    static toSingleUnit(count: number): string
    {
        return (count < 10) ? count.toString() : "9+";
    }

    static OrdinalNumber(num : number, isAll : boolean = false ) : string
    {
        let tn : number = num % 100;
        let ttn : number = num % 10;
        let sn : string = "";

        if(tn >= 11 && tn <=13)
        {
            sn = "th";
        }
        else if(ttn == 1)
        {
            sn = "st";
        }
        else if(ttn == 2)
        {
            sn = "nd";
        }
        else if(ttn == 3)
        {
            sn = "rd";
        }
        else
        {
            sn = "th";
        }

        return isAll ? num.toString() + sn : sn;
    }

    // 국가코드및 Currency를 얻는다.
    public static GetCountryToCurrency(ContryCode:string = "") : any[] | null
    {
        let lan:string = navigator.language;
        let lans = navigator.languages; // 브라우저에 국가코드값이 안 넘어 올 수도 있다.
        let currencyCode = null;
        let locale = null;
        let list:string[] = [];

        // 외부에서 국가코드를 받는 경우
        if("" != ContryCode)
        {
            list[0] = lan.substring(0, 2);
            list[1] = ContryCode.toUpperCase();
        }   
        else 
        {
            if(!lans || !lan) 
                return null;

            if(lan.indexOf("-") < 0)
            {
                let index = lans.findIndex(x => x.includes(lan+"-"));
                if(index >= 0)
                    lan = lans[index];
                else
                    return null;
            }

            list = lan.split("-");
        }       

        // 값이 없을때는 defalut로 
        if(null == list[0] || "" == list[0])
        {
            list[0] = "en";
        }

        if(null == list[1] || "" == list[1])
        {
            list[1] = "US";
        }
        
        currencyCode = CountryCurrency[list[1].toUpperCase()];  // 국가코드를 이용해서 얻는다.
        locale = list[0] + "_" + list[1].toUpperCase();
        //IP 대역대로 얻은 국가코드여서 웹에서 얻은 값하고 다를 수 있다.
        // 그래서 조합해서나온 locale값을 LocaleCode값과 비교해서 실제 값이 있는지 체크하고 없다면 첫번째 값으로 사용하도록 한다.

        // 사용안함.
        // // Array에서 LocaleCode값을 얻는다.
        // let LocaleCodeTemp = new Map<string, any[]>();
        // LocaleCode.forEach((value)=>
        // {
        //     let codes = value.split('=');
        //     let Localename = codes[1].split(',');

        //     LocaleCodeTemp.set(codes[0], Localename);
        // }); 

        // // 국가코드가 있는지 체크한다.
        // if(LocaleCodeTemp.has(list[1]))
        // {
        //     let Locales = LocaleCodeTemp.get(list[1]);

        //     let find:boolean = false;
        //     Locales.forEach((value)=>
        //     {
        //         // 값이 있다면...
        //         if(value === locale)
        //         {
        //             find = true;
        //         }
        //     })

        //     // 매칭되는 Locale값을 얻지 못했다면 무조건 첫번째 값으로 사용을 한다.
        //     if(false == find)
        //     {
        //         locale = Locales[0];
        //     }
        // }        

        return [currencyCode, locale];
    }
}

// // 전세계 국가코드
// export let LocaleCode:string[] = 
// [
//     "AA=ar_AA",
//     "BY=be_BY",
//     "BG=bg_BG",
//     "ES=es_ES,ca_ES",    
//     "CZ=cs_CZ",
//     "DK=da_DK",
//     "CH=de_CH,fr_CH,it_CH",
//     "DE=de_DE",
//     "GR=el_GR",
//     "AU=en_AU",
//     "BE=en_BE,fr_BE,nl_BE",
//     "GB=en_GB",
//     "JP=ja_JP,en_JP",    
//     "US=en_US",
//     "ZA=en_ZA",    
//     "FI=fi_FI",    
//     "CA=fr_CA",    
//     "FR=fr_FR",
//     "HR=hr_HR",
//     "HU=hu_HU",
//     "IS=is_IS",    
//     "IT=it_IT",
//     "IL=iw_IL",    
//     "KR=ko_KR",
//     "LT=lt_LT",
//     "LV=lv_LV",
//     "MK=mk_MK",    
//     "NL=nl_NL",
//     "NO=no_NO",
//     "PL=pl_PL",
//     "BR=pt_BR",
//     "PT=pt_PT",
//     "RO=ro_RO",
//     "RU=ru_RU",
//     "SP=sh_SP",
//     "SK=sk_SK",
//     "SL=sl_SL",
//     "AL=sq_AL",
//     "SE=sv_SE",
//     "TH=th_TH",
//     "TR=tr_TR",
//     "UA=uk_UA",
//     "CN=zh_CN",
//     "TW=zh_TW"
// ]

export enum CountryCurrency
{
    AD= 'EUR',
    AE= 'AED',
    AF= 'AFN',
    AG= 'XCD',
    AI= 'XCD',
    AL= 'ALL',
    AM= 'AMD',
    AO= 'AOA',
    AR= 'ARS',
    AS= 'USD',
    AT= 'EUR',
    AU= 'AUD',
    AW= 'AWG',
    AX= 'EUR',
    AZ= 'AZN',
    BA= 'BAM',
    BB= 'BBD',
    BD= 'BDT',
    BE= 'EUR',
    BF= 'XOF',
    BG= 'BGN',
    BH= 'BHD',
    BI= 'BIF',
    BJ= 'XOF',
    BL= 'EUR',
    BM= 'BMD',
    BN= 'BND',
    BO= 'BOB',
    BQ= 'USD',
    BR= 'BRL',
    BS= 'BSD',
    BT= 'BTN',
    BV= 'NOK',
    BW= 'BWP',
    BY= 'BYN',
    BZ= 'BZD',
    CA= 'CAD',
    CC= 'AUD',
    CD= 'CDF',
    CF= 'XAF',
    CG= 'CDF',
    CH= 'CHF',
    CI= 'XOF',
    CK= 'NZD',
    CL= 'CLP',
    CM= 'XAF',
    CN= 'CNY',
    CO= 'COP',
    CR= 'CRC',
    CU= 'CUC',
    CV= 'CVE',
    CW= 'ANG',
    CX= 'AUD',
    CY= 'EUR',
    CZ= 'CZK',
    DE= 'EUR',
    DJ= 'DJF',
    DK= 'DKK',
    DM= 'DOP',
    DO= 'DOP',
    DZ= 'DZD',
    EC= 'USD',
    EE= 'EUR',
    EG= 'EGP',
    EH= 'MAD',
    ER= 'ERN',
    ES= 'EUR',
    ET= 'ETB',
    FI= 'EUR',
    FJ= 'FJD',
    FM= 'USD',
    FO= 'DKK',
    FR= 'EUR',
    GA= 'XAF',
    GB= 'GBP',
    GD= 'XCD',
    GE= 'GEL',
    GF= 'EUR',
    GG= 'GBP',
    GH= 'GHS',
    GI= 'GIP',
    GL= 'DKK',
    GM= 'GMD',
    GN= 'GNF',
    GP= 'EUR',
    GQ= 'XAF',
    GR= 'EUR',
    GT= 'GTQ',
    GU= 'USD',
    GW= 'XOF',
    GY= 'GYD',
    HK= 'HKD',
    HN= 'HNL',
    HR= 'HRK',
    HT= 'HTG',
    HU= 'HUF',
    ID= 'IDR',
    IE= 'EUR',
    IL= 'ILS',
    IM= 'GBP',
    IN= 'INR',
    IO= 'USD',
    IQ= 'IQD',
    IR= 'IRR',
    IS= 'ISK',
    IT= 'EUR',
    JE= 'GBP',
    JM= 'JMD',
    JO= 'JOD',
    JP= 'JPY',
    KE= 'KES',
    KG= 'KGS',
    KH= 'KHR',
    KI= 'AUD',
    KM= 'KMF',
    KN= 'XCD',
    KP= 'KPW',
    KR= 'KRW',
    KW= 'KWD',
    KY= 'KYD',
    KZ= 'KZT',
    LB= 'LBP',
    LC= 'XCD',
    LI= 'CHF',
    LK= 'LKR',
    LR= 'LRD',
    LS= 'LSL',
    LT= 'EUR',
    LU= 'EUR',
    LV= 'EUR',
    LY= 'LYD',
    MA= 'MAD',
    MC= 'EUR',
    MD= 'MDL',
    ME= 'EUR',
    MF= 'EUR',
    MG= 'MGA',
    MH= 'USD',
    ML= 'XOF',
    MM= 'MMK',
    MN= 'MNT',
    MO= 'MOP',
    MP= 'USD',
    MQ= 'EUR',
    MR= 'MRU',
    MS= 'XCD',
    MT= 'EUR',
    MU= 'MUR',
    MV= 'MVR',
    MW= 'MWK',
    MX= 'MXN',
    MY= 'MYR',
    MZ= 'MZN',
    NA= 'NAD',
    NC= 'XPF',
    NE= 'NGN',
    NF= 'AUD',
    NG= 'NGN',
    NI= 'NIO',
    NL= 'EUR',
    NO= 'NOK',
    NP= 'NPR',
    NR= 'AUD',
    NU= 'NZD',
    NZ= 'NZD',
    OM= 'OMR',
    PA= 'PAB',
    PE= 'PEN',
    PF= 'XPF',
    PG= 'PGK',
    PH= 'PHP',
    PK= 'PKR',
    PL= 'PLN',
    PM= 'EUR',
    PN= 'NZD',
    PR= 'USD',
    PT= 'EUR',
    PW= 'USD',
    PY= 'PYG',
    QA= 'QAR',
    RE= 'EUR',
    RO= 'RON',
    RS= 'RSD',
    RU= 'RUB',
    RW= 'RWF',
    SA= 'SAR',
    SB= 'SBD',
    SC= 'SCR',
    SD= 'SDG',
    SE= 'SEK',
    SG= 'SGD',
    SH= 'SHP',
    SI= 'EUR',
    SJ= 'NOK',
    SK= 'EUR',
    SL= 'SLL',
    SM= 'EUR',
    SN= 'XOF',
    SO= 'SOS',
    SR= 'SRD',
    SS= 'SSP',
    ST= 'STN',
    SV= 'SVC',
    SX= 'ANG',
    SY= 'SYP',
    SZ= 'SZL',
    TC= 'USD',
    TD= 'XAF',
    TF= 'EUR',
    TG= 'XOF',
    TH= 'THB',
    TJ= 'TJS',
    TK= 'NZD',
    TL= 'USD',
    TM= 'TMT',
    TN= 'TND',
    TO= 'TOP',
    TR= 'TRY',
    TT= 'TTD',
    TV= 'AUD',
    TW= 'TWD',
    TZ= 'TZS',
    UA= 'UAH',
    UG= 'UGX',
    UM= 'USD',
    US= 'USD',
    UY= 'UYI',
    UZ= 'UZS',
    VA= 'EUR',
    VC= 'XCD',
    VE= 'VES',
    VG= 'USD',
    VI= 'USD',
    VN= 'VND',
    VU= 'VUV',
    WF= 'XPF',
    WS= 'USD',
    YE= 'YER',
    YT= 'EUR',
    ZA= 'ZAR',
    ZM= 'ZMW',
    ZW= 'ZWL',
    HM= 'AUD',
    FK= 'FKP',
    GS= 'GEL',
    LA= 'LAK',
    MK= 'MKD',
    AQ= 'USD',
    PS= 'ILS'
  }