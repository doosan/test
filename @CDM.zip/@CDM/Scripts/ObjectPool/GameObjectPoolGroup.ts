import GameObjectPool from "./GameObjectPool"

export default class GameObjectPoolGroup<T extends cc.Node | cc.Component> //where T : MonoBehaviour
{
    private poolDic: Map<string, GameObjectPool<T>> = null;
    private root: cc.Node = null;

    //public GameObjectPoolGroup( root:cc.Node )
    constructor(root: cc.Node)
    {
        this.root = root;
        this.poolDic = new Map<string, GameObjectPool<T>>();
    }

    public Add(c: { new(): T }, id: string, createFunc: Function, size: number = 5, autoPooling: boolean = true)
    {
        if (this.Contains(id)) 
        {
            return;
        }

        let op: GameObjectPool<T> = new GameObjectPool<T>(this.root
            , size
            , createFunc
            , autoPooling);

        this.poolDic.set(id, op);
    }

    public AddNode(c: { new(): T }, id: string, referenceObj: cc.Node, size: number = 5, autoPooling: boolean = true): void
    {
        if (this.Contains(id)) 
        {
            return;
        }

        let op: GameObjectPool<T> = new GameObjectPool<T>(this.root, size, () => { return cc.instantiate(referenceObj).getComponent(c); }, autoPooling);

        this.poolDic.set(id, op);
    }

    public AddPrefab(id: string, referenceObj: cc.Prefab, size: number = 5, autoPooling: boolean = true): void    
    {
        if (this.Contains(id)) 
        {
            return;
        }

        let op: GameObjectPool<T> = new GameObjectPool<T>(this.root, size, () => { return cc.instantiate(referenceObj); }, autoPooling);

        this.poolDic.set(id, op);
    }

    public AddPrefabEx(id: string, referenceObj: any, size: number = 5, autoPooling: boolean = true, onComplete?: Function): void
    {
        if (this.Contains(id)) 
        {
            return;
        }

        let ob = null;

        let op: GameObjectPool<T> = new GameObjectPool<T>(this.root, size, () =>
        {
            ob = cc.instantiate(referenceObj);

            return ob;
        }, autoPooling);

        if (onComplete != null)
        {
            onComplete(ob);
        }

        this.poolDic.set(id, op);
    }

    public Remove(id: string): void
    {
        if (this.Contains(id) == false)
        {
            return;
        }

        let op: GameObjectPool<T> = this.poolDic.get(id);
        this.poolDic.delete(id);

        op.Release();
        op = null;
    }

    public Size(id: string): number
    {
        if (this.Contains(id) == false)
        {
            return 0;
        }

        return this.poolDic.get(id).Size;
    }

    public IdleCount(id: string): number
    {
        if (this.Contains(id) == false)
        {
            return 0;
        }

        return this.poolDic.get(id).IdleCount;
    }

    public Get(id: string): T
    {
        if (this.Contains(id) == false)
        {
            return null;
        }

        let op: GameObjectPool<T> = this.poolDic.get(id);
        return op.Get();
    }

    public Return(id: string, obj: T): boolean
    {
        if (this.Contains(id) == false)
        {
            return false;
        }

        let op: GameObjectPool<T> = this.poolDic.get(id);
        op.Return(obj);

        return true;
    }

    public Contains(id: string): boolean
    {
        return this.poolDic.has(id);
    }

    public Release(): void
    {
        this.poolDic.forEach((value: GameObjectPool<T>, key: string,) =>
        {
            value.Release();
        }, this);

        this.poolDic.clear();
    }
}