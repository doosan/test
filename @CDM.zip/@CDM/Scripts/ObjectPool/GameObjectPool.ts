export class GameObjectPoolExtensions
{
    //type: {prototype: T}, 
    public static CreatePool<T extends cc.Component>(type: {prototype: T}, poolRef : cc.Prefab, rootName : string, parent : cc.Node, size? : number, autoPooling? : boolean, autoActivating? : boolean) : GameObjectPool<T>;
    public static CreatePool<T extends cc.Component>(type: {prototype: T}, poolRef : cc.Node, rootName : string, parent : cc.Node, size? : number, autoPooling? : boolean, autoActivating? : boolean) : GameObjectPool<T>;
    public static CreatePool<T extends cc.Component>(type: {prototype: T}, poolRef : cc.Node | cc.Prefab, rootName : string, parent : cc.Node, size : number = 5, autoPooling : boolean = true, autoActivating : boolean = true) : GameObjectPool<T>
    {
        let poolRoot = new cc.Node(rootName);
        let poolRootTransform = poolRoot;
        poolRootTransform.setContentSize(0, 0);
        poolRootTransform.setParent(parent); //, false);

        if(poolRef instanceof cc.Node)
        {
            return new GameObjectPool<T>(poolRoot,
                size,
                () => 
                {                    
                    return cc.instantiate(poolRef).getComponent(type);
                },
                autoPooling,
                autoActivating);
        }
        else if(poolRef instanceof cc.Prefab)
        {
            return new GameObjectPool<T>(poolRoot,
                size,
                () => 
                {
                    return cc.instantiate(poolRef).getComponent(type);
                },
                autoPooling,
                autoActivating);
        }
    }

    public static CreatePoolNode(poolRef : cc.Node, rootName : string, parent : cc.Node, size? : number, autoPooling? : boolean, autoActivating? : boolean) : GameObjectPool<cc.Node>
    {
        let poolRoot = new cc.Node(rootName);
        let poolRootTransform = poolRoot;
        poolRootTransform.setContentSize(0, 0);
        poolRootTransform.setParent(parent) //, false);
        
        return new GameObjectPool(poolRoot,
            size,
            () => 
            {
                return cc.instantiate(poolRef);
            },
            autoPooling,
            autoActivating);
    }
}

export default class GameObjectPool<T extends cc.Node | cc.Component>
{
    private create: Function = null;
    private pools: Array<T> = null;
    private autoPooling: boolean = false;
    private root: cc.Node = null;
    private autoActivating: boolean = false;

    public Size: number = 0;// { get; private set; }

    public get IdleCount(): number
    {
        return this.pools.length;
    }

    public get BusyCount(): number
    {
        return this.Size - this.IdleCount;
    }

    public constructor(root: cc.Node, size: number, create: Function, autoPooling: boolean = true, autoActivating: boolean = true)
    {
        this.root = root;
        //this.Size = size;
        this.create = create;
        this.autoPooling = autoPooling;
        this.autoActivating = autoActivating;

        this.pools = new Array<T>();

        this.Allocate(size);
    }

    private Allocate(size: number): void
    {
        this.Size += size;

        for (let i = 0; i < size; ++i)
        {
            this.Return(this.create());
        }
    }

    public ToList<K extends cc.Component>(component:string) : Array<K>
    {
        let res = new Array<K>();
        this.pools.forEach(item=>
            {
                if(item.getComponent(component) != null)
                {
                    res.push(item.getComponent(component));
                }
            });
        return res;
    }

    public Get(): T
    {
        if (this.pools.length <= 0)
        {
            if (this.autoPooling == true)
            {
                this.Allocate(1);
            }
            else
            {
                return null;
            }
        }

        let obj = this.pools.pop();

        if (obj == null)
        {
            return this.Get();
        }

        if (this.autoActivating == true)
        {
            if (obj instanceof cc.Node)
            {
                obj.active = true;
            }
            else if (obj instanceof cc.Component)
            {
                obj.node.active = true;
            }
        }
        return obj;
    }

    public Return(obj: T): void
    {
        //cc.log(obj)
        if (obj instanceof cc.Node)
        {
            if (obj.parent == this.root && obj.activeInHierarchy == false)
            {
                return;
            }

            obj.setParent(this.root); //false
            if (this.autoActivating == true)
            {
                obj.active = false;
            }

        }
        else if (obj instanceof cc.Component)
        {
            if (obj.node.parent == this.root && obj.node.activeInHierarchy == false)
            {
                return;
            }

            obj.node.setParent(this.root); //false
            if (this.autoActivating == true)
            {
                obj.node.active = false;
            }
        }


        this.pools.push(obj);
    }

    public Release(): void
    {
        while (this.pools.length > 0)
        {
            let Object = this.pools.pop();
            if (Object != null)
            {
                // object already destroyed를 체크하기 위한 예외처리
                let Valid = cc.isValid(Object)
                if(Valid)
                {
                    if (Object instanceof cc.Node) 
                    {
                        Object.destroy();
                    }
                    else 
                    {
                        Object.node.destroy();
                    }
                }
            }
        }
    }
}