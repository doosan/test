export default class ObjectPool<T>
{
    public get Size(): number { return this.size; }

    public get IdleCount(): number { return this.pools.length }

    private size: number = 0;
    //public create:Function<T>;
    public create: Function = null;
    private autoPooling: boolean = false;
    private pools: Array<T> = null;

    public constructor(inputSize: number, create: Function/*create:Function<T>*/, autoPooling: boolean = true)
    {
        this.size = 0;
        this.create = create;
        this.autoPooling = autoPooling;

        this.pools = new Array<T>();

        this.Allocate(inputSize);
    }

    private Allocate(size: number): void
    {
        this.size += size;

        for (let i: number = 0; i < size; i++)
        {
            this.Return(this.create());
        }
    }

    public Return(obj: T): void
    {
        this.pools.push(obj);
    }

    public Get(): T
    {
        if (this.pools.length <= 0)
        {
            if (this.autoPooling == false)
            {
                return null;
            }

            this.Allocate(1);
        }

        return this.pools.pop();
    }
}