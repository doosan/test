
export default class AppConfig
{
    public static readonly RESOLUTION_WIDTH : number              = 1280;
    public static readonly RESOLUTION_HEIGHT : number              = 720;
    public static readonly TARGET_FRAME_GENERAL : number           = 60;
    public static readonly TARGET_FRAME_SLOT : number              = 60;
}
