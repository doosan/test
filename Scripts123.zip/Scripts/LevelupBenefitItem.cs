using SlotKingdoms.Net;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Localization.Components;
using UnityEngine.UI;

namespace SlotKingdoms.Popup
{
    public class LevelupBenefitItem : MonoBehaviour
    {
        [SerializeField] private LocalizeStringEvent title = null;
        [SerializeField] private LocalizeStringEvent levelStringEvent = null;
        [SerializeField] private LocalizationValueInt level = null;
        [SerializeField] private Image icon = null;
        [SerializeField] private TextMeshProUGUI benefitValue = null;
        [SerializeField] private TextMeshProUGUI needValue = null;

        public void SetItem(GrothInflationInfo data)
        {
            title.StringReference.TableEntryReference = $"grow_itemtitle_{((int)data.type):D2}";
            if (level != null)
            {
                level.value = data.level;
                levelStringEvent.RefreshString();
            }

            icon.sprite = AddressablesLoader.Instance.LoadAsset<Sprite>($"Icon/BenefitIcon_{((int)data.type):D2}.png");

            if (benefitValue != null)
            {
                if (data.benefitType == BenefitType.Percent)
                {
                    string bV = StringUtils.ToComma(data.benefitValue);
                    benefitValue.text = $"{bV}%";
                }
                else if (data.benefitType == BenefitType.Add)
                {
                    string bV = StringUtils.ToComma(data.benefitValue);
                    benefitValue.text = $"+{bV}";
                }
                else if (data.benefitType == BenefitType.Memory)
                {
                    benefitValue.text = $"{data.benefitValue + 1}-{data.benefitValueExt + 1}";
                }
                else
                {
                    benefitValue.text = "";
                }
            }

            if (needValue != null)
            {
                needValue.text = StringUtils.ToComma(data.unlockLevel);
            }
        }
    }
}
