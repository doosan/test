using SlotKingdoms.Net;
using SlotKingdoms.UI;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace SlotKingdoms.Popup
{
    public class LevelupPopup : PopupBehaviour
    {
        [SerializeField] private LevelupBenefitItemGroup benefitItemGroup = null;
        [SerializeField] private TextMeshProUGUI levelValue = null;
        [SerializeField] private Image currentIcon = null;
        [SerializeField] private Image nextIcon = null;

        public void Initialize(long preStar, GrothInflationData data, int index)
        {
            levelValue.SetNumber(preStar, true);
            var info = data.inflationList.Where(x => x.idx == index).FirstOrDefault();
            benefitItemGroup.SetItemGroup(info);

            currentIcon.sprite = AddressablesLoader.Instance.LoadAsset<Sprite>($"Icon/BenefitIcon_{((int)info.type):D2}.png");
            var info2 = data.nextInflationInfo;
            nextIcon.sprite = AddressablesLoader.Instance.LoadAsset<Sprite>($"Icon/BenefitIcon_{((int)info2.type):D2}.png");
        }

        public void Open(long nextStar)
        {
            StartCoroutine(NumberCoroutine(nextStar));
        }

        IEnumerator NumberCoroutine(long nextStar)
        {
            yield return new WaitForSeconds(2.07f);
            levelValue.SetNumber(nextStar, true, 0.43f);
        }
    }
}