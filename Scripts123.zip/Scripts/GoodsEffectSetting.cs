using DG.Tweening;
using PathCreation;
using SlotKingdoms.Attribute;
using UnityEngine;

namespace SlotKingdoms.Effect
{
    [CreateAssetMenu(fileName = "GoodsEffectSetting", menuName = "SlotKingdoms/Goods Effect Setting", order = 1)]

    public class GoodsEffectSetting : ScriptableObject
    {
        public enum RotationDirection
        {
            None, TowardsTarget
        }

        public enum MoveType
        {
            Linear, Jump, Path
        }

        public float fadeDuration = 0.25f;
        public float postDelay = 1f;

        [Header("Spread")]
        public float spreadDelay = 0.1f;
        public float spreadDuration = 0.5f;
        public Vector2 spreadDistance = new Vector2(0.25f, 0.75f);
        public MoveType spreadMoveType = MoveType.Linear;
        [ConditionalHide("spreadMoveType", (int)MoveType.Jump, true)]
        public float spreadJumpHeight = 1f;
        public float spreadScale = 2f;
        public Ease spreadEase = Ease.OutSine;
        public RotationDirection spreadRotationDirection;

        [Header("Move")]
        public float moveDuration = 2f;
        public MoveType moveType = MoveType.Linear;
        [ConditionalHide("moveType", (int)MoveType.Path, true)]
        public PathCreator movePathCreator;
        [ConditionalHide("moveType", (int)MoveType.Jump, true)]
        public float moveJumpHeight = 1f;
        public float moveScale = 1f;
        public Ease moveEase = Ease.OutSine;

        //public AnimationCurve sizeOverLifetime = AnimationCurve.Linear(0, 1, 1, 1);
    }
}