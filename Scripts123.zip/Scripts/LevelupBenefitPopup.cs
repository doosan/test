using SlotKingdoms.Net;
using SlotKingdoms.UI;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace SlotKingdoms.Popup
{
    public class LevelupBenefitPopup : PopupBehaviour
    {
        [Header("Gauge")]
        [SerializeField] private Slider gauge = null;
        [SerializeField] private TextMeshProUGUI gaugeValue = null;
        [SerializeField] private TextMeshProUGUI nextValue = null;

        [Header("GaugeNext")]
        [SerializeField] private RewardItemList rewardItemList = null;
        [SerializeField] private Image nextBenefitImage = null;

        [Header("ScrollView")]
        [SerializeField] private Transform levelupBenefitItemGroupPoolRoot = null;
        [SerializeField] private LevelupBenefitItemGroup benefitItemGroup = null;
        [SerializeField] private Transform openContent = null;
        [SerializeField] private Transform lockLine = null;
        [SerializeField] private Transform lockContent = null;

        private GameObjectPool<LevelupBenefitItemGroup> levelupBenefitItemGroupPool = null;
        private GrothInflationData leveupBenefitInfo = null;
        private List<LevelupBenefitItemGroup> levelupBenefitItemGroupList = new List<LevelupBenefitItemGroup>();

        private void Awake()
        {
            levelupBenefitItemGroupPool = new GameObjectPool<LevelupBenefitItemGroup>(levelupBenefitItemGroupPoolRoot.gameObject, 5, () =>
            {
                return Instantiate(benefitItemGroup);
            });
        }

        private void OnDisable()
        {
            foreach (var item in levelupBenefitItemGroupList)
            {
                levelupBenefitItemGroupPool.Return(item);
            }

            levelupBenefitItemGroupList.Clear();
        }

        public override IEnumerator Load()
        {
            yield return base.Load();
            var req = NetworkSystem.Growthinflation();
            yield return req.WaitForResponse();

            if (req.IsSuccess)
            {
                leveupBenefitInfo = req.Data.data;
                foreach (var item in leveupBenefitInfo.inflationList)
                {
                    LevelupBenefitItemGroup itemGroup = levelupBenefitItemGroupPool.Get();
                    itemGroup.transform.SetParent(item.state == InflationState.Lock ? lockContent : openContent, false);
                    itemGroup.SetItemGroup(item, OpenDetailPopup);
                    levelupBenefitItemGroupList.Add(itemGroup);
                }

                lockLine.gameObject.SetActive(lockContent.childCount != 0);
                lockContent.gameObject.SetActive(lockContent.childCount != 0);
                openContent.gameObject.SetActive(openContent.childCount != 0);

                if (leveupBenefitInfo.nextInflationReward != null)
                {
                    rewardItemList.SetRewardItemList(leveupBenefitInfo.nextInflationReward);
                }

                gaugeValue.text = StringUtils.ToComma(leveupBenefitInfo.starLevel);
                nextValue.text = StringUtils.ToComma(leveupBenefitInfo.nextInflationStarLevel);

                gauge.value = (float)(leveupBenefitInfo.starLevel - leveupBenefitInfo.prevInflationStarLevel) / (leveupBenefitInfo.nextInflationStarLevel - leveupBenefitInfo.prevInflationStarLevel);

                var data = leveupBenefitInfo.nextInflationInfo;

                nextBenefitImage.sprite = AddressablesLoader.Instance.LoadAsset<Sprite>($"Icon/BenefitIcon_{((int)data.type):D2}.png");
            }

            //leveupBenefitInfo = new GrothInflationData
            //{
            //    prevInflationStarLevel = 100,
            //    nextInflationStarLevel = 1000,
            //    starLevel = 500,
            //    inflationList = new(),
            //    nextInflationReward = new List<GoodsInfo>
            //    {
            //        new GoodsInfo(eGoodsType.money, 100),
            //        new GoodsInfo(eGoodsType.energy, 100)
            //    }
            //};

            //for (int i = 0; i < 20; i++)
            //{
            //    GrothInflationInfo data = new()
            //    {
            //        state = (InflationState)Random.Range(0, 3),
            //        type = (InflationType)Random.Range(1, 16),
            //        benefitType = (BenefitType)Random.Range(0, 3),
            //        level = Random.Range(1, 3),
            //        benefitValue = Random.Range(100, 1000),
            //        unlockLevel = Random.Range(1000, 10000)
            //    };

            //    leveupBenefitInfo.inflationList.Add(data);
            //}
        }

        public void OpenDetailPopup(GrothInflationInfo data)
        {
            StartCoroutine(OpenDetailPopupCoroutine(data));
        }

        private IEnumerator OpenDetailPopupCoroutine(GrothInflationInfo data)
        {
            if(data.state == InflationState.Unlock)
            {
                var req = NetworkSystem.Requester.GrowthInflationTypeNextInfo(data.idx);
                yield return req.WaitForResponse();
                PopupSystem.Instance.OpenPopup<LevelupBenefitItemDetailPopup>().Open(data, req.Data.data.InflationInfo.benefitValue, req.Data.data.InflationInfo.benefitValueExt);
            }
            else
            {
                PopupSystem.Instance.OpenPopup<LevelupBenefitItemDetailPopup>().Open(data);
            }
        }
    }
}