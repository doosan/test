using SlotKingdoms.Net;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Localization.Components;
using UnityEngine.UI;

namespace SlotKingdoms.Popup
{
    public class LevelupBenefitItemDetailPopup : PopupBehaviour
    {
        [SerializeField] private LevelupBenefitItemGroup levelupBenefitItemGroup = null;
        [SerializeField] private GameObject infoPanel = null;
        [SerializeField] private LocalizeStringEvent info = null;
        [SerializeField] private TextMeshProUGUI currentValue = null;
        [SerializeField] private GameObject nextValuePanel = null;
        [SerializeField] private TextMeshProUGUI nextValue = null;

        public void Open(GrothInflationInfo data, int nextBenefitValue = 0, int nextBenefitValueExt = 0)
        {
            levelupBenefitItemGroup.SetItemGroup(data);

            infoPanel.SetActive(data.state != InflationState.Lock);

            if (data.state != InflationState.Lock)
            {
                info.StringReference.TableEntryReference = $"grow_iteminfo_{((int)data.type):D2}";

                nextValuePanel.gameObject.SetActive(data.state == InflationState.Unlock);

                if (data.benefitType == BenefitType.Percent)
                {
                    string bV = StringUtils.ToComma(data.benefitValue);
                    currentValue.text = $"{bV}%";

                    string nV = StringUtils.ToComma(nextBenefitValue);
                    nextValue.text = $"{nV}%";
                }
                else if (data.benefitType == BenefitType.Add)
                {
                    string bV = StringUtils.ToComma(data.benefitValue);
                    currentValue.text = $"+{bV}";

                    string nV = StringUtils.ToComma(nextBenefitValue);
                    nextValue.text = $"+{nV}";
                }
                else if (data.benefitType == BenefitType.Memory)
                {
                    currentValue.text = $"{data.benefitValue + 1}-{data.benefitValueExt + 1}";

                    nextValue.text = $"{nextBenefitValue + 1}-{nextBenefitValueExt + 1}";
                }
                else
                {
                    currentValue.text = "";
                    nextValuePanel.gameObject.SetActive(false);
                }
            }
        }
    }
}
