using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;
using SlotKingdoms.Sound;
using static SlotKingdoms.Effect.GoodsEffectSetting;
using System;
using TMPro;
using PathCreation;

namespace SlotKingdoms.Effect
{
    public sealed class GoodsEffect : MonoBehaviour
    {
        public class GoodsEffectItem : MonoBehaviour
        {
            public Queue<TweenInfo> TweenInfoQueue
            {
                get;
                private set;
            }

            public SpriteRenderer SpriteRenderer
            {
                get
                {
                    if (spriteRenderer == null)
                    {
                        spriteRenderer = GetComponentInChildren<SpriteRenderer>();
                    }
                    return spriteRenderer;
                }
            }
            private SpriteRenderer spriteRenderer;

            public AnimatorParser AnimatorParser
            {
                get
                {
                    if (animatorParser == null)
                    {
                        animatorParser = GetComponentInChildren<AnimatorParser>();
                    }
                    return animatorParser;
                }
            }
            private AnimatorParser animatorParser;

            public Transform CachedTransform
            {
                get
                {
                    if (cachedTransform == null)
                    {
                        cachedTransform = transform;
                    }
                    return cachedTransform;
                }
            }
            private Transform cachedTransform;

            public void UpdateTweenInfoQueue(Queue<TweenInfo> tweenInfoQueue)
            {
                TweenInfoQueue = tweenInfoQueue;
            }
        }

        public enum CompleteType
        {
            Success,
            Cancel
        }

        public class TweenInfo
        {
            public Vector2 totalEndPosition;
            public Vector2 startPosition;
            public Vector2 endPosition;
            public float endScale;
            public float delay;
            public float duration;
            public Ease ease;
            public RotationDirection rotationDirection;
            public MoveType moveType;
            public float jumpHeight;
        }

        public enum GoodsEffectParitclePosition
        { 
            Start,
            End
        }

        public enum GoodsEffectParitcleSorting
        {
            Foreground,
            Background
        }

        [Serializable]
        public class GoodsEffectParitcleSetting
        {
            public GoodsEffectParitclePosition position;
            public GoodsEffectParitcleSorting sorting;
            public Transform transform;
        }

        [SerializeField] private Transform itemRef;
        [SerializeField] private List<Sprite> sprites;

        [SerializeField] private List<GoodsEffectParitcleSetting> particleSettings;

        [SerializeField] private Transform valueTextContainer;
        [SerializeField] private TextMeshPro valueText;

        [Header("Sound")]
        [SerializeField] private SoundPlayer spreadSound;
        [SerializeField] private SoundPlayer firstArrivedSound; 

        public Transform ItemRef => itemRef;
        public Transform CachedTransform
        {
            get
            {
                if (cachedTransform == null)
                {
                    cachedTransform = transform;
                }
                return cachedTransform;
            }
        }
        private Transform cachedTransform;

        private GameObjectPool<GoodsEffectItem> itemPool;
        private GoodsEffectSetting setting;
        private GoodsEffectInfo info;

        private List<GoodsEffectItem> itemList;
        private List<Vector3> pathIntervals;
        private PathCreator pathCreatorCache;

        public void Awake()
        {
            itemList = new List<GoodsEffectItem>();
            pathIntervals = new List<Vector3>();
            SetParticlesVisible(false);
            ResetSounds();
        }

        private void OnDisable()
        {
            SetParticlesVisible(false);
        }

        private void SetParticlesVisible(bool value)
        {
            foreach (GoodsEffectParitcleSetting particleSetting in particleSettings)
            {
                if (particleSetting.transform != null)
                {
                    particleSetting.transform.gameObject.SetActive(value);
                }
            }
        }

        private void SetParticlesPositionAndVisible(GoodsEffectParitclePosition positionType, Vector2 position, bool value)
        {
            foreach (GoodsEffectParitcleSetting particleSetting in particleSettings)
            {
                if (particleSetting.position == positionType
                    && particleSetting.transform != null)
                {
                    particleSetting.transform.position = position;
                    particleSetting.transform.gameObject.SetActive(value);
                }
            }
        }

        private void ResetSounds()
        {
            if (spreadSound != null)
            {
                spreadSound.triggerType = AudioTriggerType.None;
            }

            if (firstArrivedSound != null)
            {
                firstArrivedSound.triggerType = AudioTriggerType.None;
            }
        }

        public void Play(GameObjectPool<GoodsEffectItem> itemPool, GoodsEffectSetting setting, GoodsEffectInfo info)
        {
            this.info = info;
            this.setting = setting;
            this.itemPool = itemPool;

            SetParticlesPositionAndVisible(GoodsEffectParitclePosition.Start, info.startPosition, true);
            if (valueTextContainer != null)
            {
                valueTextContainer.gameObject.SetActive(info.textVisible);
                valueTextContainer.position = info.startPosition + info.textOffset;
            }

            if (spreadSound != null)
            {
                spreadSound.Play();
            }

            MakeItemList();
            StartCoroutine(PlayCoroutine());
        }

        private IEnumerator PlayCoroutine()
        {
            if (info.onBegin != null)
            {
                info.onBegin(this);
            }

            Sequence totalSequence = DOTween.Sequence();

            float beginTime = Time.time;
            for (int i = 0; i < info.count; i++)
            {
                bool isFirstItem = i == 0;
                bool isLastItem = i == info.count - 1;
                GoodsEffectItem item = itemList[i];
                if (item == null || item.gameObject.activeInHierarchy == false)
                {
                    continue;
                }

                Sequence sequence = DOTween.Sequence();
                while (item.TweenInfoQueue.Count > 0)
                {
                    TweenInfo tweenInfo = item.TweenInfoQueue.Dequeue();
                    if (tweenInfo.duration > 0f)
                    {
                        if (tweenInfo.delay > 0f)
                        {
                            sequence.AppendInterval(tweenInfo.delay);
                        }

                        // 1. Move
                        if (tweenInfo.moveType == MoveType.Path)
                        {
                            MakePathIntervals(pathCreatorCache, tweenInfo.startPosition, tweenInfo.endPosition, 30);
                            sequence.Append(item.CachedTransform.DOPath(pathIntervals.ToArray(), tweenInfo.duration, PathType.CatmullRom, PathMode.Sidescroller2D, 1, null)
                                                                .SetEase(tweenInfo.ease));
                        }
                        else if (tweenInfo.moveType == MoveType.Linear)
                        {
                            sequence.Append(item.CachedTransform.DOMove(tweenInfo.endPosition, tweenInfo.duration)
                                                                .SetEase(tweenInfo.ease));
                        }
                        else if (tweenInfo.moveType == MoveType.Jump)
                        {
                            sequence.Append(item.CachedTransform.DOJump(tweenInfo.endPosition, tweenInfo.jumpHeight, 1, tweenInfo.duration)
                                                                .SetEase(tweenInfo.ease));
                        }

                        // 2. Rotate
                        if (tweenInfo.rotationDirection == RotationDirection.TowardsTarget)
                        {
                            Vector2 targetPosition = tweenInfo.totalEndPosition; 
                            Vector2 itemPosition = item.CachedTransform.position;

                            Vector2 direction = targetPosition - itemPosition;
                        
                            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
                            sequence.Join(item.CachedTransform.DORotateQuaternion(Quaternion.Euler(new Vector3(0, 0, angle - 90)), tweenInfo.duration)
                                                              .SetEase(tweenInfo.ease));
                        }

                        // 3. Scale
                        sequence.Join(item.CachedTransform.DOScale(tweenInfo.endScale, tweenInfo.duration)
                                                          .SetEase(tweenInfo.ease));

                        // 4. Fade In
                        if (item.SpriteRenderer != null)
                        {
                            Color color = item.SpriteRenderer.color;
                            if (color.a == 0f)
                            {
                                sequence.Join(item.SpriteRenderer.DOFade(1f, setting.fadeDuration));
                            }
                        }
                    }
                    else
                    {
                        item.CachedTransform.position = tweenInfo.endPosition;
                    }
                }

                sequence.AppendCallback(() =>
                {
                    if (isFirstItem)
                    {
                        info.onFirstItemArrived?.Invoke();
                        firstArrivedSound?.Play();

                        // 첫 도착 퍼티클
                        SetParticlesPositionAndVisible(GoodsEffectParitclePosition.End, info.endPosition, true);
                        if (valueTextContainer != null)
                        {
                            valueTextContainer.gameObject.SetActive(false);
                        }
                    }

                    info.onItemArrived?.Invoke();

                    // 도착 애니메이션
                    item.AnimatorParser?.SetTrigger();
                });

                float endAnimationDuration = item.AnimatorParser != null ?
                                             item.AnimatorParser.Duration :
                                             0f;
                if (endAnimationDuration > 0f)
                {
                    sequence.AppendInterval(endAnimationDuration);
                }

                if (item.SpriteRenderer != null)
                {
                    sequence.Append(item.SpriteRenderer.DOFade(0f, setting.fadeDuration));
                }

                sequence.AppendCallback(() =>
                {
                    if (isLastItem)
                    {
                        info.onLastItemArrived?.Invoke(CompleteType.Success);
                    }
                });

                sequence.AppendInterval(setting.postDelay);
                sequence.OnComplete(() => 
                {
                    itemPool.Return(item);
                });

                totalSequence.Insert(0, sequence);
            }

            yield return totalSequence.WaitForCompletion();

            if (info.onComplete != null)
            {
                info.onComplete(CompleteType.Success);
            }
        }

        private void CachePathCreator(PathCreator prefab)
        {
#if UNITY_EDITOR
            // 프리팹 변경 사항이 바로 반영되도록 하기 위함
            if (pathCreatorCache != null)
            {
                Destroy(pathCreatorCache.gameObject);
                pathCreatorCache = null;
            }
#endif

            if (pathCreatorCache == null)
            {
                pathCreatorCache = Instantiate(prefab, transform);
            }
        }

        private void MakePathIntervals(PathCreator pathCreator, Vector3 startPosition, Vector3 endPosition, int divisions)
        {
            pathIntervals.Clear();

            pathCreator.bezierPath.MovePoint(0, startPosition);
            pathCreator.bezierPath.MovePoint(3, endPosition);

            // divisions - 1로 나누어서 0초와 1초를 포함시킵니다.
            float timeInterval = 1.0f / (divisions - 1);

            Vector3 pathInterval;
            for (int i = 0; i < divisions - 1; i++) // 마지막 값 전까지만 계산
            {
                float timeValue = i * timeInterval;
                pathInterval = pathCreator.path.GetPointAtTime(timeValue, EndOfPathInstruction.Stop);
                pathIntervals.Add(pathInterval);
            }

            pathInterval = pathCreator.path.GetPointAtTime(1f, EndOfPathInstruction.Stop); // 마지막 값은 명시적으로 1로 설정
            pathIntervals.Add(pathInterval);
        }

        private void MakeItemList()
        {
            itemList.Clear();

            //float startScale = setting.sizeOverLifetime.Evaluate(0.0f);
            foreach (GoodsEffectParitcleSetting particleSetting in particleSettings)
            {
                int sortingOrder = particleSetting.sorting == GoodsEffectParitcleSorting.Foreground ? 
                                   info.count : 
                                   -1;
                particleSetting.transform.GetComponent<ParticleSystem>()
                                         .GetComponent<ParticleSystemRenderer>()
                                         .sortingOrder = sortingOrder;
            }

            if (valueText != null
                && info.value > 0)
            {
                valueText.sortingOrder = info.count + 1;
                valueText.text = $"+{info.value}";
            }

            if (setting.moveType == MoveType.Path
                && setting.movePathCreator != null)
            {
                CachePathCreator(setting.movePathCreator);
            }

            for (int i = 0; i < info.count; i++)
            {
                GoodsEffectItem item = itemPool.Get();
                item.CachedTransform.SetParent(transform, false);

                // 시작 위치값과 회전값 세팅
                item.CachedTransform.position = info.startPosition;
                //Debug.Log($"[GoodsEffect.MakeItemList] {info.startPosition} -> {info.endPosition}");

                item.CachedTransform.eulerAngles = Vector3.zero;
                item.CachedTransform.localScale = Vector3.one;
                //Vector2 targetScale = startScale * GetTargetScale();
                //item.CachedTransform.localScale = new Vector3(targetScale.x, targetScale.y, 1.0f);

                if (item.SpriteRenderer != null)
                {
                    Color originColor = item.SpriteRenderer.color;
                    item.SpriteRenderer.color = new Color(originColor.r, originColor.g, originColor.b, 0f);
                    item.SpriteRenderer.sortingOrder = i;

                    if (sprites.Count > 0)
                    {
                        int skinIndex = info.skinIndex;
                        if (skinIndex >= sprites.Count)
                        {
                            skinIndex = sprites.Count - 1;
                        }
                        item.SpriteRenderer.sprite = sprites[skinIndex];
                    }
                }

                // 스프레드 거리와 방향
                float _spreadDistance = UnityEngine.Random.Range(setting.spreadDistance.x, setting.spreadDistance.y);
                float randomAngle = UnityEngine.Random.Range(0.0f, 360.0f);

                float spreadX = _spreadDistance * Mathf.Cos(randomAngle * Mathf.Deg2Rad);
                float spreadY = _spreadDistance * Mathf.Sin(randomAngle * Mathf.Deg2Rad);

                var tweenInfoQueue = new Queue<TweenInfo>();

                Vector2 latestEndPosition = info.startPosition;
                if (info.count > 1)
                {
                    latestEndPosition = new Vector2(info.startPosition.x + spreadX, info.startPosition.y + spreadY);

                    var spreadTweenInfo = new TweenInfo()
                    {
                        totalEndPosition = info.endPosition,
                        startPosition = info.startPosition,
                        endPosition = latestEndPosition,
                        duration = setting.spreadDuration,
                        delay = setting.spreadDelay * (i + 1),
                        ease = setting.spreadEase,
                        rotationDirection = setting.spreadRotationDirection,
                        moveType = setting.spreadMoveType,
                        jumpHeight = setting.spreadJumpHeight,
                        endScale = setting.spreadScale,
                    };
                    tweenInfoQueue.Enqueue(spreadTweenInfo);
                }
                var moveTweenInfo = new TweenInfo()
                {
                    totalEndPosition = info.endPosition,
                    startPosition = latestEndPosition,
                    endPosition = info.endPosition,
                    duration = setting.moveDuration,
                    delay = 0f,
                    ease = setting.moveEase,
                    rotationDirection = RotationDirection.None,
                    moveType = setting.moveType,
                    jumpHeight = setting.moveJumpHeight,
                    endScale = setting.moveScale,
                };
                tweenInfoQueue.Enqueue(moveTweenInfo);

                item.UpdateTweenInfoQueue(tweenInfoQueue);
                
                itemList.Add(item);
            }
        }

        public void Stop()
        {
            StopAllCoroutines();

            for (int i = 0; i < itemList.Count; i++)
            {
                GoodsEffectItem item = itemList[i];
                if (item != null)
                {
                    itemPool.Return(item);
                }
            }

            info.onLastItemArrived?.Invoke(CompleteType.Cancel);
            info.onComplete?.Invoke(CompleteType.Cancel);
        }
    }
}