using SlotKingdoms.Net;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace SlotKingdoms.Popup
{
    public class LevelupBenefitItemGroup : MonoBehaviour
    {
        [SerializeField] private List<LevelupBenefitItem> levelupBenefitItemList = null;
        [SerializeField] private Button button = null;

        private GrothInflationInfo data = null;
        private Action<GrothInflationInfo> onClick = null;

        public void SetItemGroup(GrothInflationInfo data, Action<GrothInflationInfo> click = null)
        {
            this.data = data;
            onClick = click;

            if (button != null)
            {
                button.interactable = click != null;
            }

            for (int i = 0; i < levelupBenefitItemList.Count; i++)
            {
                if (levelupBenefitItemList[i] != null)
                {
                    if (i == (int)data.state)
                    {
                        //levelupBenefitItem = levelupBenefitItemList[i];
                        levelupBenefitItemList[i].gameObject.SetActive(true);
                        levelupBenefitItemList[i].SetItem(data);
                    }
                    else
                    {
                        levelupBenefitItemList[i].gameObject.SetActive(false);
                    }
                }
            }
        }

        public void ClickButton()
        {
            onClick?.Invoke(data);
        }
    }
}