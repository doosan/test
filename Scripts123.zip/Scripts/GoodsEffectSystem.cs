using System;
using System.Collections.Generic;
using UnityEngine;
using static SlotKingdoms.Effect.GoodsEffect;

namespace SlotKingdoms.Effect
{
    public class GoodsEffectInfo
    {
        public int skinIndex;
        public int count;
        public long value;
        public Vector2 startPosition; 
        public Vector2 endPosition;
        public bool textVisible;
        public Vector2 textOffset;
        public float endScale;
        public Action<GoodsEffect> onBegin = null;
        public Action<CompleteType> onComplete = null; 
        public Action onFirstItemArrived = null;
        public Action<CompleteType> onLastItemArrived = null;
        public Action onItemArrived = null;
    }

    public sealed class GoodsEffectSystem : GameObjectSingleton<GoodsEffectSystem>
    {
        private const string GoodsEffectSettingCommon = "GoodsEffectSettingCommon";
        private const string GoodsEffectSettingShield = "GoodsEffectSettingShield";
        private const string GoodsEffectSettingEnergy = "GoodsEffectSettingEnergy";
        private const int MaxItemCount = 15;

        private bool isInit;
        private RectTransform root;
        private GameObject poolRoot;
        private List<GoodsEffect> effectList;

        private Dictionary<string, GameObjectPool<GoodsEffect>> goodsEffectPoolDict;
        private Dictionary<string, GameObjectPool<GoodsEffectItem>> goodsEffectItemPoolDict;

        public void Initialize(string popupLayerName, int resolutionWidth, int resolutionHeight, int depth = 0)
        {
            if (isInit == true)
            {
                return;
            }

            isInit = true;

            effectList = new List<GoodsEffect>();

            goodsEffectPoolDict = new Dictionary<string, GameObjectPool<GoodsEffect>>();
            goodsEffectItemPoolDict = new Dictionary<string, GameObjectPool<GoodsEffectItem>>();

            SetupRoot();
            SetupCamera(popupLayerName, resolutionWidth, resolutionHeight, depth);
        }

        private void SetupRoot()
        {
            root = new GameObject("Root").AddComponent<RectTransform>();
            root.SetParent(transform, false);

            poolRoot = new GameObject("PoolRoot");
            poolRoot.transform.SetParent(transform, false);
        }

        private void SetupCamera(string popupLayerName, int resolutionWidth, int resolutionHeight, int depth = 0)
        {
            Camera cam = new GameObject("Camera").AddComponent<Camera>();
            cam.orthographic = true;
            cam.cullingMask = 1 << LayerMask.NameToLayer(popupLayerName);
            cam.transform.SetParent(transform, false);
            cam.clearFlags = CameraClearFlags.Depth;
            cam.depth = depth;
            cam.transform.localPosition = new Vector3(0.0f, 0.0f, -100.0f);
            cam.orthographicSize = resolutionHeight * (1f / 100.0f) * 0.5f;
        }

        public void Clear()
        {
            for (int i = 0; i < effectList.Count; i++)
            {
                GoodsEffect effect = effectList[i];
                effect.Stop();
            }

            effectList.Clear();
        }

        private void AddEffect(GoodsEffect effect)
        {
            if (effectList.Contains(effect) == true)
            {
                return;
            }

            effectList.Add(effect);
        }

        private void RemoveEffect(GoodsEffect effect)
        {
            if (effectList.Contains(effect) == false)
            {
                return;
            }

            effectList.Remove(effect);
        }

        public void Star(int count,
                         Vector2 startPosition, 
                         Vector2 endPosition,
                         bool textVisible = false,
                         Vector2 textOffset = default,
                         Action<GoodsEffect> onBegin = null,
                         Action<GoodsEffect.CompleteType> onComplete = null, 
                         Action onFirstItemArrived = null, 
                         Action onItemArrived = null)
        {
            string goodsEffectKey = "StarEffect";
            AddGoodsEffectPool(goodsEffectKey);

            GoodsEffectSetting setting = AddressablesLoader.Instance.LoadAsset<GoodsEffectSetting>(GoodsEffectSettingCommon);
            int clampedCount = Mathf.Clamp(count, 1, MaxItemCount);

            GoodsEffect(goodsEffectKey, setting, 0, clampedCount, count, startPosition, endPosition, textVisible, textOffset, onBegin, null, onFirstItemArrived, onItemArrived, onLastItemArrived: onComplete);
        }

        public void Shield(int skinIndex,
                           int count,
                           Vector2 startPosition,
                           Vector2 endPosition,
                           bool textVisible = false,
                           Vector2 textOffset = default,
                           Action<GoodsEffect> onBegin = null,
                           Action<GoodsEffect.CompleteType> onComplete = null,
                           Action onFirstItemArrived = null,
                           Action onItemArrived = null)
        {
            string goodsEffectKey = "ShieldEffect";
            AddGoodsEffectPool(goodsEffectKey);

            GoodsEffectSetting setting = AddressablesLoader.Instance.LoadAsset<GoodsEffectSetting>(GoodsEffectSettingShield);
            int clampedCount = Mathf.Clamp(count, 1, MaxItemCount);

            GoodsEffect(goodsEffectKey, setting, skinIndex, clampedCount, count, startPosition, endPosition, textVisible, textOffset, onBegin, null, onFirstItemArrived, onItemArrived, onLastItemArrived: onComplete);
        }

        public void Energy(int count,
                           Vector2 startPosition,
                           Vector2 endPosition,
                           bool textVisible = false,
                           Vector2 textOffset = default,
                           Action<GoodsEffect> onBegin = null,
                           Action<GoodsEffect.CompleteType> onComplete = null,
                           Action onFirstItemArrived = null,
                           Action onItemArrived = null)
        {
            string goodsEffectKey = "EnergyEffect";
            AddGoodsEffectPool(goodsEffectKey);

            Vector2 direction = endPosition - startPosition;
            string settingPostFix = direction.y > 0 ? "ToUp" : "ToDown";
            string settingFileName = $"{GoodsEffectSettingEnergy}{settingPostFix}";
            //Debug.Log($"[GoodsEffectSystem.Energy] : {settingFileName}");
            GoodsEffectSetting setting = AddressablesLoader.Instance.LoadAsset<GoodsEffectSetting>(settingFileName);
            int clampedCount = Mathf.Clamp(count, 1, MaxItemCount);

            GoodsEffect(goodsEffectKey, setting, 0, clampedCount, count, startPosition, endPosition, textVisible, textOffset, onBegin, null, onFirstItemArrived, onItemArrived, onLastItemArrived: onComplete);
        }

        public void Hammer(int count,
                           Vector2 startPosition,
                           Vector2 endPosition,
                           bool textVisible = false,
                           Vector2 textOffset = default,
                           Action<GoodsEffect> onBegin = null,
                           Action<GoodsEffect.CompleteType> onComplete = null,
                           Action onFirstItemArrived = null,
                           Action onItemArrived = null)
        {
            string goodsEffectKey = "HammerEffect";
            AddGoodsEffectPool(goodsEffectKey);

            GoodsEffectSetting setting = AddressablesLoader.Instance.LoadAsset<GoodsEffectSetting>(GoodsEffectSettingCommon);
            int clampedCount = Mathf.Clamp(count, 1, MaxItemCount);

            GoodsEffect(goodsEffectKey, setting, 0, clampedCount, count, startPosition, endPosition, textVisible, textOffset,onBegin, null, onFirstItemArrived, onItemArrived, onLastItemArrived: onComplete);
        }

        public void Coin(int count,
                         Vector2 startPosition,
                         Vector2 endPosition,
                         bool textVisible = false,
                         Vector2 textOffset = default,
                         Action<GoodsEffect> onBegin = null,
                         Action<GoodsEffect.CompleteType> onComplete = null,
                         Action onFirstItemArrived = null,
                         Action onItemArrived = null)
        {
            string goodsEffectKey = "CoinEffect";
            AddGoodsEffectPool(goodsEffectKey);

            GoodsEffectSetting setting = AddressablesLoader.Instance.LoadAsset<GoodsEffectSetting>(GoodsEffectSettingCommon);
            int clampedCount = Mathf.Clamp(count, 1, MaxItemCount);

            GoodsEffect(goodsEffectKey, setting, 0, clampedCount, count, startPosition, endPosition, textVisible, textOffset, onBegin, null, onFirstItemArrived, onItemArrived, onLastItemArrived: onComplete);
        }

        public void Light(int count,
                          Vector2 startPosition,
                          Vector2 endPosition,
                          bool textVisible = false,
                          Vector2 textOffset = default,
                          Action<GoodsEffect> onBegin = null,
                          Action<GoodsEffect.CompleteType> onComplete = null,
                          Action onFirstItemArrived = null,
                          Action onItemArrived = null)
        {
            string goodsEffectKey = "LightEffect";
            AddGoodsEffectPool(goodsEffectKey);

            GoodsEffectSetting setting = AddressablesLoader.Instance.LoadAsset<GoodsEffectSetting>(GoodsEffectSettingCommon);
            int clampedCount = Mathf.Clamp(count, 1, MaxItemCount);

            GoodsEffect(goodsEffectKey, setting, 0, clampedCount, count, startPosition, endPosition, textVisible, textOffset, onBegin, null, onFirstItemArrived, onItemArrived, onLastItemArrived: onComplete);
        }

        private void AddGoodsEffectPool(string effectKey)
        {
            if (goodsEffectPoolDict.ContainsKey(effectKey) == false)
            {
                var goodsEffectPrefab = AddressablesLoader.Instance.LoadComponent<GoodsEffect>(effectKey, false);
                foreach (Transform child in goodsEffectPrefab.CachedTransform)
                {
                    child.gameObject.SetActive(false);
                }

                var goodsEffectPool = new GameObjectPool<GoodsEffect>(
                    root: poolRoot,
                    size: 1,
                    create: () => GameObject.Instantiate(goodsEffectPrefab)
                );
                goodsEffectPoolDict.Add(effectKey, goodsEffectPool);

                var goodsEffectItemPool = new GameObjectPool<GoodsEffectItem>(
                    root: poolRoot,
                    size: MaxItemCount,
                    create: () => GameObject.Instantiate(goodsEffectPrefab.ItemRef).AddComponent<GoodsEffectItem>()
                );
                goodsEffectItemPoolDict.Add(effectKey, goodsEffectItemPool);
            }
        }

        private void GoodsEffect(string key,
                                 GoodsEffectSetting setting,
                                 int skinIndex,
                                 int count,
                                 long value,
                                 Vector2 startPosition,
                                 Vector2 endPosition,
                                 bool textVisible = false,
                                 Vector2 textOffset = default,
                                 Action<GoodsEffect> onBegin = null,
                                 Action<GoodsEffect.CompleteType> onComplete = null,
                                 Action onFirstItemArrived = null,
                                 Action onItemArrived = null,
                                 Action<GoodsEffect.CompleteType> onLastItemArrived = null)
        {
            if (textOffset == default)
            {
                textOffset = new Vector2(0.5f, -0.5f);
            }

            GameObjectPool<GoodsEffect> pool = goodsEffectPoolDict[key];
            GameObjectPool<GoodsEffectItem> itemPool = goodsEffectItemPoolDict[key];

            if (pool != null
                && count > 0)
            {
                GoodsEffect effect = pool.Get();
                effect.transform.SetParent(root, false);
                effect.transform.position = Vector3.zero;
                effect.Play(itemPool, setting, new GoodsEffectInfo()
                {
                    skinIndex = skinIndex,
                    count = count,
                    value = value,
                    startPosition = startPosition,
                    endPosition = endPosition,
                    textVisible = textVisible,
                    textOffset = textOffset,
                    onBegin = onBegin,
                    onComplete = completeType =>
                    {
                        RemoveEffect(effect);
                        pool.Return(effect);

                        onComplete?.Invoke(completeType);
                    },
                    onFirstItemArrived = onFirstItemArrived,
                    onItemArrived = onItemArrived,
                    onLastItemArrived = onLastItemArrived
                });

                AddEffect(effect);
            }
        }

    }
}