using System;
using System.Collections.Generic;
using Gaga.AssetBundle;
using Gaga.System;
using UnityEngine;

namespace Underc.Effect
{
    public sealed class EffectSystem : GameObjectSingleton<EffectSystem>
    {
        public enum EffectName
        {
            MissionPassPoint,
            DailyMissionPoint,
            BlitzPoint
        }

        private bool isInit;
        private RectTransform root;
        private GameObject poolRoot;
        private List<Effect> effectList;

        private GameObjectPool<ItemGainEffect> coinEffectPool;
        private GameObjectPool<ItemGainEffect> pearlEffectPool;
        private GameObjectPool<ItemGainEffect> ticketEffectPool;
        private GameObjectPool<ItemGainEffect> goldPickaxEffectPool;
        private GameObjectPool<ItemGainEffect> silverPickaxEffectPool;
        private GameObjectPool<ItemGainEffect> fishEffectPool;
        private GameObjectPool<ItemGainEffect> happyEffectPool;
        private GameObjectPool<ItemGainEffect> lightEffectPool;
        private GameObjectPool<ItemGainEffect> vipClassEffectPool;
        private Dictionary<EffectName, GameObjectPool<ItemGainEffect>> effectPoolDict;

        public void Initialize(string popupLayerName, int resolutionWidth, int resolutionHeight, int depth = 0)
        {
            if (isInit == true)
            {
                return;
            }

            isInit = true;

            effectList = new List<Effect>();
            effectPoolDict = new Dictionary<EffectName, GameObjectPool<ItemGainEffect>>();

            SetupRoot();
            SetupCamera(popupLayerName, resolutionWidth, resolutionHeight, depth);
        }

        private void SetupRoot()
        {
            root = new GameObject("Root").AddComponent<RectTransform>();
            root.SetParent(transform, false);

            poolRoot = new GameObject("PoolRoot");
            poolRoot.transform.SetParent(transform, false);
        }

        private void SetupCamera(string popupLayerName, int resolutionWidth, int resolutionHeight, int depth = 0)
        {
            Camera cam = new GameObject("Camera").AddComponent<Camera>();
            cam.orthographic = true;
            cam.cullingMask = (1 << LayerMask.NameToLayer(popupLayerName));
            cam.transform.SetParent(transform, false);
            cam.clearFlags = CameraClearFlags.Depth;
            cam.depth = depth;
            cam.transform.localPosition = new Vector3(0.0f, 0.0f, -100.0f);
            cam.orthographicSize = (resolutionHeight * (1f / 100.0f)) * 0.5f;;
        }

        public void Clear()
        {
            for (int i = 0; i < effectList.Count; i++)
            {
                var effect = effectList[i];
                effect.Stop();
            }

            effectList.Clear();
        }

        private void AddEffect(Effect effect)
        {
            if (effectList.Contains(effect) == true)
            {
                return;
            }

            effectList.Add(effect);
        }

        private void RemoveEffect(Effect effect)
        {
            if (effectList.Contains(effect) == false)
            {
                return;
            }

            effectList.Remove(effect);
        }

        private ItemGainEffect GainEffect(GameObjectPool<ItemGainEffect> pool,
                                          int count, 
                                          Vector2 startPosition, 
                                          Vector2 endPosition, 
                                          Transform scaleTarget,
                                          Action<ItemGainEffect> onBegin = null,
                                          Action<Effect.CompleteType> onComplete = null, 
                                          Action onFirstArrived = null, 
                                          Action onArrived = null)
        {
            if (pool == null)
            {
                return null;
            }

            if (count <= 0)
            {
                return null;
            }

            var effect = pool.Get();
            effect.transform.SetParent(root, false);
            effect.transform.position = Vector3.zero;
            effect.Play(count
                        ,startPosition
                        ,endPosition
                        ,scaleTarget
                        ,onBegin
                        ,completeType=>
                        {
                            RemoveEffect(effect);
                            pool.Return(effect);

                            if (onComplete != null)
                            {
                                onComplete(completeType);
                            }
                        }
                        ,onFirstArrived
                        ,onArrived);

            AddEffect(effect);
            return effect;
        }

        public void Coin(int count, 
                         Vector2 startPosition, 
                         Vector2 endPosition, 
                         Transform scaleTarget,
                         Action<ItemGainEffect> onBegin = null,
                         Action<Effect.CompleteType> onComplete = null, 
                         Action onFirstCoinArrived = null, 
                         Action onCoinArrived = null)
        {
            if (coinEffectPool == null)
            {
                coinEffectPool = new GameObjectPool<ItemGainEffect>(poolRoot
                , 1
                , () =>
                {
                    var effectAB = AssetBundleSystem.Instance.GetLoadedAssetBundle("effect");
                    return effectAB.GetGameObject("CoinEffect").GetComponent<ItemGainEffect>();
                }
                , true);
            }

            count = Mathf.Clamp(count, 1, ItemGainEffect.DEFAULT_ITEM_COUNT);
            GainEffect(coinEffectPool, count, startPosition, endPosition, scaleTarget, onBegin, onComplete, onFirstCoinArrived, onCoinArrived);
        }

        public void Coin(int count, 
                         Vector2 startPosition, 
                         Vector2 endPosition, 
                         Action<ItemGainEffect> onBegin = null,
                         Action<Effect.CompleteType> onComplete = null, 
                         Action onFirstCoinArrived = null, 
                         Action onCoinArrived = null)
        {
            Coin(count ,startPosition, endPosition, null, onBegin, onComplete, onFirstCoinArrived, onCoinArrived);
        }
        
        public void Coin(Vector2 startPosition, 
                         Vector2 endPosition,
                         Transform scaleTarget,
                         Action<ItemGainEffect>onBegin = null,
                         Action<Effect.CompleteType> onComplete = null, 
                         Action onFirstArrived = null, 
                         Action onArrived = null)
        {
            Coin(ItemGainEffect.DEFAULT_ITEM_COUNT ,startPosition, endPosition, scaleTarget, onBegin, onComplete, onFirstArrived, onArrived);
        }

        public void Coin(Vector2 startPosition, 
                         Vector2 endPosition,
                         Action<ItemGainEffect>onBegin = null,
                         Action<Effect.CompleteType> onComplete = null, 
                         Action onFirstArrived = null, 
                         Action onArrived = null)
        {
            Coin(ItemGainEffect.DEFAULT_ITEM_COUNT ,startPosition, endPosition, onBegin, onComplete, onFirstArrived, onArrived);
        }

        public void Pearl(int count,
                         Vector2 startPosition,
                         Vector2 endPosition,
                         Transform scaleTarget,
                         Action<ItemGainEffect> onBegin = null,
                         Action<Effect.CompleteType> onComplete = null,
                         Action onFirstArrived = null,
                         Action onArrived = null)
        {
            if (pearlEffectPool == null)
            {
                pearlEffectPool = new GameObjectPool<ItemGainEffect>(poolRoot
                ,1
                ,()=>
                {
                    var effectAB = AssetBundleSystem.Instance.GetLoadedAssetBundle("effect");
                    return effectAB.GetGameObject("PearlEffect").GetComponent<ItemGainEffect>();
                }
                ,true);
            }

            count = Mathf.Clamp(count, 1, ItemGainEffect.DEFAULT_ITEM_COUNT);
            GainEffect(pearlEffectPool, count, startPosition, endPosition, scaleTarget, onBegin, onComplete, onFirstArrived, onArrived);
        }

        public void Pearl(int count,
                         Vector2 startPosition,
                         Vector2 endPosition,
                         Action<ItemGainEffect> onBegin = null,
                         Action<Effect.CompleteType> onComplete = null,
                         Action onFirstArrived = null,
                         Action onArrived = null)
        {
            Pearl(count , startPosition, endPosition, null, onBegin, onComplete, onFirstArrived, onArrived);
        }

         public void Pearl(Vector2 startPosition,
                          Vector2 endPosition,
                          Transform scaleTarget,
                          Action<ItemGainEffect> onBegin = null,
                          Action<Effect.CompleteType> onComplete = null,
                          Action onFirstArrived = null,
                          Action onArrived = null)
        {
            Pearl(ItemGainEffect.DEFAULT_ITEM_COUNT , startPosition, endPosition, scaleTarget, onBegin, onComplete, onFirstArrived, onArrived);
        }

        public void Pearl(Vector2 startPosition,
                          Vector2 endPosition,
                          Action<ItemGainEffect> onBegin = null,
                          Action<Effect.CompleteType> onComplete = null,
                          Action onFirstArrived = null,
                          Action onArrived = null)
        {
            Pearl(ItemGainEffect.DEFAULT_ITEM_COUNT , startPosition, endPosition, onBegin, onComplete, onFirstArrived, onArrived);
        }

        public void Ticket(int count,
                           Vector2 startPosition,
                           Vector2 endPosition,
                           Transform scaleTarget,
                           Action<ItemGainEffect> onBegin = null,
                           Action<Effect.CompleteType> onComplete = null,
                           Action onFirstArrived = null,
                           Action onArrived = null)
        {
            if (ticketEffectPool == null)
            {
                ticketEffectPool = new GameObjectPool<ItemGainEffect>(
                    poolRoot
                    ,1
                    ,()=>
                    {
                        var effectAB = AssetBundleSystem.Instance.GetLoadedAssetBundle("effect");
                        return effectAB.GetGameObject("TicketEffect").GetComponent<ItemGainEffect>();
                    }
                    ,true
                );
            }

            count = Mathf.Clamp(count, 1, ItemGainEffect.DEFAULT_ITEM_COUNT);
            GainEffect(ticketEffectPool, count, startPosition, endPosition, scaleTarget, onBegin, onComplete, onFirstArrived, onArrived);
        }
        
        public void Ticket(int count,
                           Vector2 startPosition,
                           Vector2 endPosition,
                           Action<ItemGainEffect> onBegin = null,
                           Action<Effect.CompleteType> onComplete = null,
                           Action onFirstArrived = null,
                           Action onArrived = null)
        {
            Ticket(count , startPosition, endPosition, null, onBegin, onComplete, onFirstArrived, onArrived);
        }

        public void Ticket(Vector2 startPosition,
                           Vector2 endPosition,
                           Transform scaleTarget,
                           Action<ItemGainEffect> onBegin = null,
                           Action<Effect.CompleteType> onComplete = null,
                           Action onFirstArrived = null,
                           Action onArrived = null)
        {
            Ticket(ItemGainEffect.DEFAULT_ITEM_COUNT , startPosition, endPosition, scaleTarget, onBegin, onComplete, onFirstArrived, onArrived);
        }

        public void Ticket(Vector2 startPosition,
                           Vector2 endPosition,
                           Action<ItemGainEffect> onBegin = null,
                           Action<Effect.CompleteType> onComplete = null,
                           Action onFirstArrived = null,
                           Action onArrived = null)
        {
            Ticket(ItemGainEffect.DEFAULT_ITEM_COUNT , startPosition, endPosition, onBegin, onComplete, onFirstArrived, onArrived);
        }

        public void MissionPassPoint(int count, 
                                     Vector2 startPosition, 
                                     Vector2 endPosition, 
                                     Transform scaleTarget,
                                     Action<ItemGainEffect> onBegin = null, 
                                     Action<Effect.CompleteType> onComplete = null, 
                                     Action onFirstArrived = null, 
                                     Action onArrived = null)
        {
            Gaining(EffectName.MissionPassPoint,
                    count,
                    startPosition,
                    endPosition,
                    scaleTarget,
                    onBegin,
                    onComplete,
                    onFirstArrived,
                    onArrived);
        }

        public void MissionPassPoint(int count, 
                                     Vector2 startPosition, 
                                     Vector2 endPosition, 
                                     Action<ItemGainEffect> onBegin = null, 
                                     Action<Effect.CompleteType> onComplete = null, 
                                     Action onFirstArrived = null, 
                                     Action onArrived = null)
        {
            MissionPassPoint(count,
                            startPosition,
                            endPosition,
                            null,
                            onBegin,
                            onComplete,
                            onFirstArrived,
                            onArrived);
        }

        public void DailyMissionPoint(int count,
                                      Vector2 startPosition,
                                      Vector2 endPosition,
                                      Transform scaleTarget,
                                      Action<ItemGainEffect> onBegin = null,
                                      Action<Effect.CompleteType> onComplete = null,
                                      Action onFirstArrived = null,
                                      Action onArrived = null)
        {
            Gaining(EffectName.DailyMissionPoint,
                    count,
                    startPosition,
                    endPosition,
                    scaleTarget,
                    onBegin,
                    onComplete,
                    onFirstArrived,
                    onArrived);
        }

        public void DailyMissionPoint(int count,
                                      Vector2 startPosition,
                                      Vector2 endPosition,
                                      Action<ItemGainEffect> onBegin = null,
                                      Action<Effect.CompleteType> onComplete = null,
                                      Action onFirstArrived = null,
                                      Action onArrived = null)
        {
            DailyMissionPoint(count,
                                startPosition,
                                endPosition,
                                null,
                                onBegin,
                                onComplete,
                                onFirstArrived,
                                onArrived);
        }

        public void BlitzPoint(int count,
                               Vector2 startPosition,
                               Vector2 endPosition,
                               Transform scaleTarget,
                               Action<ItemGainEffect> onBegin = null,
                               Action<Effect.CompleteType> onComplete = null,
                               Action onFirstArrived = null,
                               Action onArrived = null)
        {
            Gaining(EffectName.BlitzPoint,
                    count,
                    startPosition,
                    endPosition,
                    scaleTarget,
                    onBegin,
                    onComplete,
                    onFirstArrived,
                    onArrived);
        }

        public void BlitzPoint(int count,
                               Vector2 startPosition,
                               Vector2 endPosition,
                               Action<ItemGainEffect> onBegin = null,
                               Action<Effect.CompleteType> onComplete = null,
                               Action onFirstArrived = null,
                               Action onArrived = null)
        {
            BlitzPoint(count,
                        startPosition,
                        endPosition,
                        null,
                        onBegin,
                        onComplete,
                        onFirstArrived,
                        onArrived);
        }

        private void Gaining(EffectName effectName,
                            int count,
                            Vector2 startPosition,
                            Vector2 endPosition,
                            Transform scaleTarget,
                            Action<ItemGainEffect> onBegin = null,
                            Action<Effect.CompleteType> onComplete = null,
                            Action onFirstArrived = null,
                            Action onArrived = null)
        {
            if (effectPoolDict.ContainsKey(effectName) == false)
            {
                var pool = new GameObjectPool<ItemGainEffect>(
                    root: poolRoot,
                    size: 1,
                    create: () => {
                        var effectAB = AssetBundleSystem.Instance.GetLoadedAssetBundle("effect");
                        return effectAB.GetGameObject($"{effectName}Effect").GetComponent<ItemGainEffect>();
                    },
                    autoPooling: true
                );
                effectPoolDict.Add(effectName, pool);
            }

            GameObjectPool<ItemGainEffect> targetPool = effectPoolDict[effectName];
            count = Mathf.Clamp(count, 1, ItemGainEffect.DEFAULT_ITEM_COUNT);
            GainEffect(targetPool, count, startPosition, endPosition, scaleTarget, onBegin, onComplete, onFirstArrived, onArrived);
        }

        public void Pickax(string pickaxType, int count, Vector2 startPosition, Vector2 endPosition, Action<ItemGainEffect> onBegin = null, Action<Effect.CompleteType> onComplete = null, Action onFirstArrived = null, Action onArrived = null)
        {
            if (pickaxType == "s_pickaxe")
            {
                SilverPickax(count, startPosition, endPosition, onBegin, onComplete, onFirstArrived, onArrived);
            }
            else if (pickaxType == "g_pickaxe")
            {
                GoldPickax(count, startPosition, endPosition, onBegin, onComplete, onFirstArrived, onArrived);
            }
        }

        public void VipClass(string vipClass,
                             int count, 
                             Vector2 startPosition, 
                             Vector2 endPosition,
                             Transform scaleTarget,
                             Action<Effect.CompleteType> onComplete = null ,
                             Action onFirstArrived = null, 
                             Action onArrived = null)
        {
            if (vipClassEffectPool == null)
            {
                vipClassEffectPool = new GameObjectPool<ItemGainEffect>(
                    root: poolRoot,
                    size: 1,
                    create: () =>
                    {
                        var effectAB = AssetBundleSystem.Instance.GetLoadedAssetBundle("effect");
                        return effectAB.GetGameObject("VipClassEffect").GetComponent<ItemGainEffect>();
                    },
                    autoPooling: true
                );
            }

            count = Mathf.Clamp(count, 1, ItemGainEffect.DEFAULT_ITEM_COUNT);
            GainEffect(
                vipClassEffectPool, 
                count, 
                startPosition, 
                endPosition, 
                scaleTarget,
                onBegin : (ItemGainEffect effect) =>
                {
                    if (effect != null)
                    {
                        foreach (ItemGainEffect.Follower follower in effect.FollowerList)
                        {
                            follower.VisibleToggle.TurnOnByNameInMultiple(vipClass);
                        }
                    }
                }, 
                onComplete, 
                onFirstArrived, 
                onArrived
            );
        }

        public void VipClass(string vipClass,
                             int count, 
                             Vector2 startPosition, 
                             Vector2 endPosition,
                             Action<Effect.CompleteType> onComplete = null ,
                             Action onFirstArrived = null, 
                             Action onArrived = null)
        {
            VipClass(vipClass,
                    count, 
                    startPosition, 
                    endPosition, 
                    null, 
                    onComplete, 
                    onFirstArrived, 
                    onArrived
            );
        }

        public void GoldPickax(int count,
                               Vector2 startPosition,
                               Vector2 endPosition,
                               Transform scaleTarget,
                               Action<ItemGainEffect> onBegin = null,
                               Action<Effect.CompleteType> onComplete = null,
                               Action onFirstArrived = null,
                               Action onArrived = null)
        {
            if (goldPickaxEffectPool == null)
            {
                goldPickaxEffectPool = new GameObjectPool<ItemGainEffect>(
                    root: poolRoot,
                    size: 1,
                    create: () => {
                        var effectAB = AssetBundleSystem.Instance.GetLoadedAssetBundle("effect");
                        return effectAB.GetGameObject("GoldPickaxEffect").GetComponent<ItemGainEffect>();
                    },
                    autoPooling: true
                );
            }

            count = Mathf.Clamp(count, 1, ItemGainEffect.DEFAULT_ITEM_COUNT);
            GainEffect(goldPickaxEffectPool, count, startPosition, endPosition, scaleTarget, onBegin, onComplete, onFirstArrived, onArrived);
        }

        public void GoldPickax(int count,
                               Vector2 startPosition,
                               Vector2 endPosition,
                               Action<ItemGainEffect> onBegin = null,
                               Action<Effect.CompleteType> onComplete = null,
                               Action onFirstArrived = null,
                               Action onArrived = null)
        {
            GoldPickax(count, startPosition, endPosition, null, onBegin, onComplete, onFirstArrived, onArrived);
        }

        public void SilverPickax(int count,
                                 Vector2 startPosition,
                                 Vector2 endPosition,
                                 Transform scaleTarget,
                                 Action<ItemGainEffect> onBegin = null,
                                 Action<Effect.CompleteType> onComplete = null,
                                 Action onFirstArrived = null,
                                 Action onArrived = null)
        {
            if (silverPickaxEffectPool == null)
            {
                silverPickaxEffectPool = new GameObjectPool<ItemGainEffect>(
                    root: poolRoot, 
                    size: 1, 
                    create: () => {
                        var effectAB = AssetBundleSystem.Instance.GetLoadedAssetBundle("effect");
                        return effectAB.GetGameObject("SilverPickaxEffect").GetComponent<ItemGainEffect>();
                    }, 
                    autoPooling: true
                );
            }

            count = Mathf.Clamp(count, 1, ItemGainEffect.DEFAULT_ITEM_COUNT);
            GainEffect(silverPickaxEffectPool, count, startPosition, endPosition, scaleTarget, onBegin, onComplete, onFirstArrived, onArrived);
        }

        public void SilverPickax(int count,
                                 Vector2 startPosition,
                                 Vector2 endPosition,
                                 Action<ItemGainEffect> onBegin = null,
                                 Action<Effect.CompleteType> onComplete = null,
                                 Action onFirstArrived = null,
                                 Action onArrived = null)
        {
            SilverPickax(count, startPosition, endPosition, null, onBegin, onComplete, onFirstArrived, onArrived);
        }

        public void Fish(int count, Vector2 startPosition, Vector2 endPosition, Action<ItemGainEffect> onBegin = null, Action<Effect.CompleteType> onComplete = null, Action onFirstArrived = null, Action onArrived = null)
        {
            if (fishEffectPool == null)
            {
                fishEffectPool = new GameObjectPool<ItemGainEffect>(poolRoot
                ,1
                ,()=>
                {
                    var effectAB = AssetBundleSystem.Instance.GetLoadedAssetBundle("effect");
                    return effectAB.GetGameObject("FishEffect").GetComponent<ItemGainEffect>();
                }
                ,true);
            }

            GainEffect(fishEffectPool, count, startPosition, endPosition, null, onBegin, onComplete, onFirstArrived, onArrived);
        }

        public void Happy(Vector2 startPosition, Vector2 endPosition, Action<ItemGainEffect> onBegin = null, Action<Effect.CompleteType> onComplete = null, Action onFirstArrived = null, Action onArrived = null)
        {
            Happy(ItemGainEffect.DEFAULT_ITEM_COUNT, startPosition, endPosition, onBegin, onComplete, onFirstArrived, onArrived);
        }

        public void Happy(int count, Vector2 startPosition, Vector2 endPosition, Action<ItemGainEffect> onBegin = null, Action<Effect.CompleteType> onComplete = null, Action onFirstArrived = null, Action onArrived = null)
        {
            if (happyEffectPool == null)
            {
                happyEffectPool = new GameObjectPool<ItemGainEffect>(
                poolRoot,
                1,
                () =>
                {
                    var effectAB = AssetBundleSystem.Instance.GetLoadedAssetBundle("effect");
                    return effectAB.GetGameObject("HappyEffect").GetComponent<ItemGainEffect>();
                },
                true);
            }

            GainEffect(happyEffectPool, count, startPosition, endPosition, null, onBegin, onComplete, onFirstArrived, onArrived);
        }

        public void Light(int count,
                          Vector2 startPosition,
                          Vector2 endPosition,
                          Transform scaleTarget,
                          Action<ItemGainEffect> onBegin = null,
                          Action<Effect.CompleteType> onComplete = null,
                          Action onFirstArrived = null,
                          Action onArrived = null)
        {
            if (lightEffectPool == null)
            {
                lightEffectPool = new GameObjectPool<ItemGainEffect>(
                poolRoot,
                1,
                () =>
                {
                    var effectAB = AssetBundleSystem.Instance.GetLoadedAssetBundle("effect");
                    return effectAB.GetGameObject("LightEffect").GetComponent<ItemGainEffect>();
                },
                true);
            }

            GainEffect(lightEffectPool, count, startPosition, endPosition, scaleTarget, onBegin, onComplete, onFirstArrived, onArrived);
        }

        public void Light(int count,
                          Vector2 startPosition,
                          Vector2 endPosition,
                          Action<ItemGainEffect> onBegin = null,
                          Action<Effect.CompleteType> onComplete = null,
                          Action onFirstArrived = null,
                          Action onArrived = null)
        {
            Light(ItemGainEffect.DEFAULT_ITEM_COUNT, startPosition, endPosition, null, onBegin, onComplete, onFirstArrived, onArrived);
        }

        public void Light(Vector2 startPosition,
                          Vector2 endPosition,
                          Action<ItemGainEffect> onBegin = null,
                          Action<Effect.CompleteType> onComplete = null,
                          Action onFirstArrived = null,
                          Action onArrived = null)
        {
            Light(ItemGainEffect.DEFAULT_ITEM_COUNT, startPosition, endPosition, onBegin, onComplete, onFirstArrived, onArrived);
        }
    }
}