using UnityEngine;
using System.Collections;
using System;

namespace Underc.Effect
{
    public abstract class Effect : MonoBehaviour
    {
        public enum CompleteType
        {
            Success,
            Cancel
        }

        public Action<CompleteType> onComplete;
        public Action onStop;

        public void Play(Action<CompleteType> onComplete)
        {
            this.onComplete = onComplete;
            StartCoroutine("PlayCoroutine");
        }

        public void Stop()
        {
            StopAllCoroutines();
            OnStop();

            if (onComplete != null)
            {
                onComplete(CompleteType.Cancel);
            }
        }

        protected IEnumerator PlayCoroutine()
        {
            yield return OnPlay();

            if (onComplete != null)
            {
                onComplete(CompleteType.Success);
            }
        }

        protected abstract IEnumerator OnPlay();
        protected abstract void OnStop();
    }
}