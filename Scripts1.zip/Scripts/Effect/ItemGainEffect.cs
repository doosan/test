using System;
using System.Collections;
using System.Collections.Generic;
using Gaga.System;
using Gaga.Attribute;
using PathCreation;
using UnityEngine;
using Gaga.Sound;
using DG.Tweening;
using Gaga;

namespace Underc.Effect
{
    public sealed class ItemGainEffect : Effect
    {
        public const int DEFAULT_ITEM_COUNT = 15;

        public class Follower : MonoBehaviour
        {
            public Vector2 spreadStartPos;
            public Vector2 spreadEndPos;
            public float spreadDuration;
            public float spreadDelay;
            public float currentSpreadDelay;
            public float moveDuration;
            public float currentTime;

            public Transform CachedTransform
            {
                get; 
                private set;
            }
            public GameObjectVisibleToggle VisibleToggle
            {
                get;
                private set;
            }

            public void Initialize()
            {
                CachedTransform = GetComponent<Transform>();
                VisibleToggle = GetComponentInChildren<GameObjectVisibleToggle>();
            }
        }

        public enum AutoRotationType
        {
            None, Path, Zero
        }

#pragma warning disable 0649
        [SerializeField] private PathCreator path;
        [SerializeField] private Transform refernceObject;

        [Space]
        [SerializeField] private AnimationCurve sizeOverLifetime = AnimationCurve.Linear(0,1,1,1);
        [SerializeField] private float moveDuration = 1f;
        [SerializeField] private bool useSpread = true;
        [SerializeField] private SoundPlayer spreadSFX; 

        public AutoRotationType autoRatation;

        [LabelOverride("2D Mode")] public bool twoDMode = true;

        [Header("FirstArrive")]
        [SerializeField] private Transform beginningEffect;
        [SerializeField] private SoundPlayer firstArrivedSFX; 
        [SerializeField] private Transform firstArrivedEffect;
        [SerializeField] private float firstArrivedEffectDuration;
#pragma warning restore 0649

        public IEnumerable FollowerList
        {
            get => followerList;
        }

        private Vector2 startPosition;
        private Vector2 endPosition;
        private List<Follower> followerList;
        private Action<ItemGainEffect> onBegin;
        private Action onFirstItemArrived;
        private Action onItemArrived;
        private GameObjectPool<Follower> followerPool;
        private int itemCount;
        private Transform scaleTarget;
        private float canvasScale;

        public void Awake()
        {
            followerList = new List<Follower>();
            if (beginningEffect != null) beginningEffect.gameObject.SetActive(false);
            if (firstArrivedEffect != null) firstArrivedEffect.gameObject.SetActive(false);

            SetupSounds();
            SetupFollowerPool(DEFAULT_ITEM_COUNT);
        }

        private void OnDisable()
        {
            if (beginningEffect != null) beginningEffect.gameObject.SetActive(false);
             if (firstArrivedEffect != null) firstArrivedEffect.gameObject.SetActive(false);
        }

        private void SetupSounds()
        {
            if (spreadSFX != null)
            {
                spreadSFX.triggerType = AudioTriggerType.None;
            }

            if (firstArrivedSFX != null)
            {
                firstArrivedSFX.triggerType = AudioTriggerType.None;
            }
        }

        private void SetupFollowerPool(int followerCount)
        {
            var followePoolRoot = new GameObject("FollowePoolRoot");
            followePoolRoot.transform.SetParent(transform, false);

            followerPool = new GameObjectPool<Follower>(followePoolRoot
                                                    ,10
                                                    ,() => 
                                                    {
                                                        return CreateFollower();
                                                    });
        }

        private Follower CreateFollower()
        {
            Follower follower = GameObject.Instantiate(refernceObject).gameObject.AddComponent<Follower>();
            follower.Initialize();

            return follower;
        }

        public void Play(Vector2 startPosition, 
                         Vector2 endPosition, 
                         Action<ItemGainEffect> onBegin = null, 
                         Action<CompleteType> onComplete = null, 
                         Action onFirstItemArrived = null, 
                         Action onItemArrived = null)
        {
            Play(DEFAULT_ITEM_COUNT, startPosition, endPosition, onBegin, onComplete, onFirstItemArrived, onItemArrived);
        }

        public void Play(int count, 
                         Vector2 startPosition, 
                         Vector2 endPosition, 
                         Action<ItemGainEffect> onBegin = null, 
                         Action<CompleteType> onComplete = null, 
                         Action onFirstItemArrived = null, 
                         Action onItemArrived = null)
        {
            Play(count, startPosition, endPosition, null, onBegin, onComplete, onFirstItemArrived, onItemArrived);
        }

        public void Play(int count, 
                         Vector2 startPosition, 
                         Vector2 endPosition, 
                         Transform scaleTarget,
                         Action<ItemGainEffect> onBegin = null, 
                         Action<CompleteType> onComplete = null, 
                         Action onFirstItemArrived = null, 
                         Action onItemArrived = null)
        {
            this.startPosition = startPosition;
            this.endPosition = endPosition;
            this.onBegin = onBegin;
            this.onFirstItemArrived = onFirstItemArrived;
            this.onItemArrived = onItemArrived;
            this.scaleTarget = scaleTarget;

            canvasScale = 1.0f;

            if (scaleTarget != null && scaleTarget as RectTransform)
            {
                canvasScale = 100.0f;
            }

            itemCount = count;

            if (beginningEffect != null)
            {
                beginningEffect.position = startPosition;
                beginningEffect.gameObject.SetActive(true);
            }

            if (useSpread && spreadSFX != null)
            {
                spreadSFX.Play();
            }

            base.Play(onComplete);
        }

        private Vector2 GetTargetScale()
        {
            if (scaleTarget == null)
            {
                return Vector2.one;
            }
            else
            {
                if (scaleTarget.gameObject.activeInHierarchy == false)
                {
                    return (Vector2)scaleTarget.lossyScale;
                }
                else
                {
                    return (Vector2)scaleTarget.lossyScale * canvasScale;
                }
            }
        }

        protected override IEnumerator OnPlay()
        {
            Vector2[] points = new Vector2[5];

            float halfX = startPosition.x + ((endPosition.x - startPosition.x) * 0.5f);
            float halfY = startPosition.y + ((endPosition.y - startPosition.y) * 0.5f);

            Vector2 pos1 = new Vector2(startPosition.x, startPosition.y + (halfY - startPosition.y) * 0.5f);
            Vector2 pos2 = new Vector2(halfX, halfY);
            Vector2 pos3 = new Vector2(endPosition.x, halfY + (endPosition.y - halfY) * 0.5f);

            points[0] = startPosition;
            points[1] = pos1;
            points[2] = pos2;
            points[3] = pos3;
            points[4] = endPosition;

            BezierPath bp = new BezierPath(points, false, PathSpace.xy);
            bp.ControlPointMode = BezierPath.ControlMode.Mirrored;
            path.bezierPath = bp;

            followerList.Clear();

            float startScale = sizeOverLifetime.Evaluate(0.0f);
            for (int i = 0; i < itemCount; i++)
            {
                var follower = followerPool.Get();
                follower.CachedTransform.SetParent(transform, false);
                follower.CachedTransform.position = startPosition;
                follower.CachedTransform.eulerAngles = new Vector3(0.0f, 0.0f, UnityEngine.Random.Range(0.0f, 360.0f));

                var dist = UnityEngine.Random.Range(1.4f,2.0f) *  GetTargetScale().x;
                var angle = UnityEngine.Random.Range(0.0f, 360.0f);

                var x = dist * Mathf.Cos(angle * Mathf.Deg2Rad);
                var y = dist * Mathf.Sin(angle * Mathf.Deg2Rad);

                follower.currentSpreadDelay = 0.0f;
                follower.currentTime = 0.0f;
                follower.spreadStartPos = follower.CachedTransform.position;
                follower.spreadEndPos = new Vector2(follower.CachedTransform.position.x + x, follower.CachedTransform.position.y + y);
                follower.spreadDuration = 1.1f;
                follower.spreadDelay = 0.13f + (i * 0.07f);
                follower.moveDuration = moveDuration;

                Vector2 targetScale = startScale * GetTargetScale();
                follower.CachedTransform.localScale = new Vector3(targetScale.x, targetScale.y, 1.0f);

                followerList.Add(follower);
            }

            bool isFirstItemArrived = false;
            float firstItemArrivedTime = Time.time;

            OnBegin();

            while (true)
            {
                float deltaTime = Time.deltaTime;
                bool isComplete = true;

                for (int i = 0; i < itemCount; i++)
                {
                    var follower = followerList[i];

                    if (follower == null || follower.gameObject.activeInHierarchy == false)
                    {
                        continue;
                    }

                    isComplete = false;

                    if ( useSpread == true && follower.currentSpreadDelay < follower.spreadDelay)
                    {
                        follower.currentTime += deltaTime;

                        if (follower.currentTime >= follower.spreadDuration)
                        {
                            follower.currentTime = follower.spreadDuration;
                        }

                        float targetTime = follower.currentTime / follower.spreadDuration;

                        float tx = EaseOutExpo(follower.spreadStartPos.x, follower.spreadEndPos.x, targetTime);
                        float ty = EaseOutExpo(follower.spreadStartPos.y, follower.spreadEndPos.y, targetTime);
                        follower.CachedTransform.position = new Vector2(tx, ty);

                        follower.currentSpreadDelay += deltaTime;

                        if (follower.currentSpreadDelay >= follower.spreadDelay)
                        {
                            follower.currentTime = 0.0f;
                        }
                    }
                    else
                    {
                        if (follower.currentTime == follower.moveDuration)
                        {
                            followerPool.Return(follower);
                            followerList[i] = null;

                            if (isFirstItemArrived == false)
                            {
                                isFirstItemArrived = true;
                                firstItemArrivedTime = Time.time;

                                OnFirstArrived();
                            }

                            if (onItemArrived != null)
                            {
                                onItemArrived();
                            }
                        }
                        else
                        {
                            follower.currentTime += deltaTime;
                
                            if (follower.currentTime >= follower.moveDuration)
                            {
                                follower.currentTime = follower.moveDuration;
                            }

                            float targetTime = follower.currentTime / follower.moveDuration;
                            var targetPos = path.path.GetPointAtTime(targetTime, EndOfPathInstruction.Stop);

                            if (autoRatation == AutoRotationType.Path)
                            {
                                var targetRot = path.path.GetRotation(targetTime, EndOfPathInstruction.Stop).eulerAngles;

                                if (twoDMode == true)
                                {
                                    float tz = targetRot.x;
                                    targetRot = follower.CachedTransform.eulerAngles;
                                    targetRot.z = tz;
                                }

                                follower.CachedTransform.eulerAngles = targetRot;
                            }
                            else if (autoRatation == AutoRotationType.Zero)
                            {
                                follower.CachedTransform.DORotate(Vector3.zero, follower.moveDuration);
                            }
                            
                            float tx = EaseInCirc(follower.CachedTransform.position.x, targetPos.x, targetTime);
                            float ty = EaseInCirc(follower.CachedTransform.position.y, targetPos.y, targetTime);

                            follower.CachedTransform.position = new Vector2(tx, ty);

                            float scale = sizeOverLifetime.Evaluate(targetTime);
                            var targetScale = GetTargetScale();
                            follower.CachedTransform.localScale = new Vector3(scale * targetScale.x, scale * targetScale.y, 1.0f);
                        } 
                    }
                }

                yield return null;

                if (isComplete == true)
                {
                    break;
                }
            }

            while( Time.time - firstItemArrivedTime < firstArrivedEffectDuration )
            {
                yield return null;
            }
        }  

        private float EaseOutExpo(float start, float end, float value)
        {
            end -= start;
            return end * (-Mathf.Pow(2, -10 * value) + 1) + start;
        }

        private float EaseInCirc(float start, float end, float value)
        {
            end -= start;
            return -end * (Mathf.Sqrt(1 - value * value) - 1) + start;
        }

        protected override void OnStop()
        {
            for (int i = 0; i < followerList.Count; i++)
            {
                var follower = followerList[i];
                if (follower != null)
                {
                    followerPool.Return(follower);
                }
            }
        }

        private void OnFirstArrived()
        {
            if (onFirstItemArrived != null)
            {
                onFirstItemArrived();
            }

            if( firstArrivedSFX != null )
            {
                firstArrivedSFX.Play();
            }

            if ( firstArrivedEffect != null )
            {
                firstArrivedEffect.position = endPosition;
                firstArrivedEffect.gameObject.SetActive(true);
            }
        }

        private void OnBegin()
        {
            if (onBegin != null)
            {
                onBegin(this);
            }
        }
    }
}