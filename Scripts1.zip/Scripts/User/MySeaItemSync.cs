using Gaga.Util;
using System.Collections.Generic;

namespace Underc.User
{
    public class MySeaItemSync
    {
        // 물고기 개수 변경 이후 데이터 업데이트 전일 때 개수를 정확하게 표기하기 위한 용도
        private Dictionary<string, SeaItemInfo> syncs = new Dictionary<string, SeaItemInfo>();

        public bool HasSync
        {
            get => syncs.Count > 0;
        }

        // 변경된 물고기 데이터가 있을 때만 item_list 패킷을 호출하기 위함.
        // 1-1.
        public bool Consume()
        {
            bool result = syncs.Count > 0;
            syncs.Clear();

            return result;
        }

        // 1-2.
        public bool Exists(SeaItemType type, int id)
        {
            return syncs.ContainsKey(ItemKey(type, id));
        }

        // 1-3.
        public void Add(SeaItemType type, int id, int count)
        {
            string itemKey = ItemKey(type, id);
            if (syncs.ContainsKey(itemKey) == false)
            {
                syncs.Add(itemKey, new SeaItemInfo(type, id, 0, 0));
            }

            syncs[itemKey].AddCount(count);
        }

        // 1-4.
        public void Clear()
        {
            syncs.Clear();
        }

        private string ItemKey(SeaItemType type, int id)
        {
            // 예시 : t1, f20, s3, ...
            return StringMaker.New()
                              .Append(type.ToString())
                              .Append(id.ToString())
                              .Build();
        }

        public int Count(SeaItemType type, int id)
        {
            int result = 0;
            string itemKey = ItemKey(type, id);
            if (syncs.ContainsKey(itemKey) == true)
            {
                result = syncs[itemKey].Count;
            }
            return result;
        }
    }
}