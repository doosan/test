using NUnit.Framework;
using System.Collections.Generic;
using Underc;
using Underc.Lobby;
using Underc.User;
using UnityEngine;

namespace Tests
{
    public class TestMyOcean
    {
        private MyOcean myOcean;
        private List<SeaData> seaDataList;
        private LobbyManager lobbyManager;

        [OneTimeSetUp]
        public void Setup()
        {
            myOcean = new MyOcean();
            seaDataList = new List<SeaData>();

            var gameObject = new GameObject();
            lobbyManager = gameObject.AddComponent<LobbyManager>();
        }

        [Test]
        public void TestNextSeaID_1()
        {
            /// 1. Arrange
            SeaData[] seaDatas = MakeSeaDatas(currentSea: 2, currentSeaStep: 10);

            /// 2. Act
            myOcean.UpdateSeaList(seaDatas);

            /// 3. Assert
            Assert.AreEqual(myOcean.PresecuredSeaID, 2);
        }

        [Test]
        public void TestNextSeaID_2()
        {
            /// 1. Arrange
            SeaData[] seaDatas = MakeSeaDatas(currentSea: 2, currentSeaStep: 12);

            /// 2. Act
            myOcean.UpdateSeaList(seaDatas);

            /// 3. Assert
            Assert.AreEqual(myOcean.PresecuredSeaID, 3);
        }

        private SeaData[] MakeSeaDatas(int currentSea, int currentSeaStep)
        {
            seaDataList.Clear();
            for (int i = 1; i <= 9; i++)
            {
                int sea = i;
                int step = (sea < currentSea) ? 12 :
                           (sea == currentSea) ? currentSeaStep :
                           0;
                
                int unlockLevel = i * 50;
                seaDataList.Add(MakeSeaData(sea, step, unlockLevel));
            }
            return seaDataList.ToArray();
        }

        private SeaData MakeSeaData(int sea, int step, int unlockLevel)
        {
            var seaData = new SeaData();
            seaData.sea = sea;
            seaData.step = step;
            seaData.unlock_level = unlockLevel;
            return seaData;
        }
    }
}
