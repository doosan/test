using Gaga.System;
using System;

namespace Underc.User
{
    public enum RewardType
    {
        none = 0,
        coin = 1,
        pearl = 2,
        ticket = 3,
        golden = 4,
        obsidian = 5,
        xp_booster = 6,
        pearl_booster = 7,
        fish = 8,
        s_pickaxe = 9,
        g_pickaxe = 10,
        weekly_point = 11,
        coin_g_pickaxe = 12,
        coin_s_pickaxe = 13,
        mp_point = 14,
        blitz_point = 15,
        vip_point = 16,
        rand = 100
    }

    // 위 RewardType 과 네이밍이 같아야 함
    public enum RewardOrder
    {
        none = 0,
        coin_g_pickaxe = 1, // 남은 곡괭이 코인 (클램 하베스트 팝업에서 보상을 받을 때 가장 먼저 노출하기 위해)
        coin_s_pickaxe = 2, 
        coin = 3,           // 기본 재화 (유저에게 가장 중요한 재화는 코인이 아닐지?)
        pearl = 4,
        ticket = 5,
        obsidian = 6,       // 상자
        golden = 7,
        fish = 8,           // 물고기
        xp_booster = 9,     // 부스터
        pearl_booster = 10, 
        mp_point = 11,      // 미션 패스 포인트
        weekly_point = 12,  // 데일리 미션 포인트 (데일리 퀘스트 리워드 팝업에서 후순위로 노출하기 위해)
        blitz_point = 13,   // 아쿠아 블리츠 포인트
        g_pickaxe = 14,     // 곡괭이 (데일리 퀘스트 리워드 팝업에서 맨 마지막에 노출하기 위해)
        s_pickaxe = 15,
        vip_point = 16,
    }

    public enum RewardValueIconType
    {
        None,
        Coin,
        Star
    }

    public class RewardInfo : IEquatable<RewardInfo>
    {
        private static ObjectPool<RewardInfo> pool = new ObjectPool<RewardInfo>(10, ()=> new RewardInfo());

        public RewardType type;
        public long value;
        public long additionalValue;
        public bool skipEffect;
        public int skinIndex;

        public RewardInfo(){}

        public RewardInfo(RewardType type, long value, long additionalValue = 0, bool skipEffect = false, int skinIndex = 0)
        {
            Set(type, value, additionalValue, skipEffect, skinIndex);
        }

        public static RewardInfo New(RewardType type, 
                                     long value, 
                                     long additionalValue = 0, 
                                     bool skipEffect = false, 
                                     int skinIndex = 0)
        {
            var item = pool.Get();
            item.Set(type, value, additionalValue, skipEffect, skinIndex);

            return item;
        }

        public RewardInfo Clone()
        {
            return New(type, value, additionalValue, skipEffect, skinIndex);
        }

        public void Release()
        {
            pool.Return(this);
        }

        private void Set(RewardType type, 
                         long value, 
                         long additionalValue = 0, 
                         bool skipEffect = false, 
                         int skinIndex = 0,
                         bool visible = true)
        {
            this.type = type;
            this.value = value;
            this.additionalValue = additionalValue;
            this.skipEffect = skipEffect;
            this.skinIndex = skinIndex;
        }

        public bool IsCoinType()
        {
            return type == RewardType.coin
                    || type == RewardType.coin_g_pickaxe
                    || type == RewardType.coin_s_pickaxe;
        }

        public bool IsValid()
        {
            return type != RewardType.none && value > 0;
        }

        public override string ToString()
        {
            return string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0}:{1}", type, value);
        }

        public RewardData ToRewardData()
        {
            var rewardData = new RewardData(type.ToString(), value);
            return rewardData;
        }

        bool IEquatable<RewardInfo>.Equals(RewardInfo other)
        {
            return Equals(this, other);
        }

        public bool Equals(RewardInfo other)
        {
            return Equals(this, other);
        }

        public static bool Equals(RewardInfo x, RewardInfo y)
        {
            bool isXnull = ReferenceEquals(x, null);
            bool isYnull = ReferenceEquals(y, null);

            return (isXnull && isYnull)
                   || (isXnull == false
                      && isYnull == false
                      && x.type == y.type
                      && x.value == y.value
                      && x.additionalValue == y.additionalValue);
        }
    }
}