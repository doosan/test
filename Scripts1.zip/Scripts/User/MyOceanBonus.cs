using Gaga;
using System;

namespace Underc.User
{
    public class MyOceanBonus : IDisposable
    {
        public long Clean { get; private set; }
        private long cleanTs = -1;

        public long CleanRemainingSec
        {
            get
            {
                if (feedTs > 0)
                {
                    return globalTime.SecondDiff(cleanTs);
                }

                return 0;
            }
        }

        public long Welcome { get; private set; }

        public event Action<bool> OnFeedReady;
        private bool feedReady;
        public bool IsFeedReady
        {
            get
            {
                return feedReady;
            }
            set
            {
                if (feedReady == value)
                {
                    return;
                }

                feedReady = value;
                OnFeedReady?.Invoke(feedReady);
            }
        }
        public long Feed { get; private set; }
        public long FeedMax { get; private set; }
        public long FeedClaimed { get; private set; }
        public long FeedRemainingSec { get; private set; } = -1;
        private long feedTs = -1;

        private GlobalTime globalTime;

        public MyOceanBonus()
        {
            globalTime = GlobalTime.Instance;
            globalTime.onUpdate += UpdateRemainingSec;
        }

        public void Dispose()
        {
            globalTime.onUpdate -= UpdateRemainingSec;
        }

        private void UpdateRemainingSec(long serverTs)
        {
            if (feedTs > 0)
            {
                FeedRemainingSec = globalTime.SecondDiff(feedTs);
                IsFeedReady = FeedRemainingSec == 0;
            }
        }

        public void Update(OceanBonusData data)
        {
            Clean = data.clean;

            FeedMax = data.max_feed;
            Feed = data.feed;
            IsFeedReady = Feed > 0;
            feedTs = data.feed_ts;

            UpdateRemainingSec(globalTime.GetTimeStamp());
        }

        public void Update(OceanBonusClaimData data)
        {
            FeedClaimed = data.bonus;
        }
    }
}