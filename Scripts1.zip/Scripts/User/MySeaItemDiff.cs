using System;
using System.Collections.Generic;

namespace Underc.User
{
    public class MySeaItemDiff
    {
        public event Action OnUpdate;

        public List<SeaItemDifference> Diffs
        {
            get; 
            private set;
        } = new List<SeaItemDifference>(); 

        // 물고기 개수 변경 이후 데이터 업데이트를 한꺼번에 하기 위한 용도
        private Dictionary<string, SeaItemInfo> cachedInfos = new Dictionary<string, SeaItemInfo>();
        private Object mainHost;

        public void Begin(Object host)
        {
            if (mainHost == host 
                || mainHost == null)
            {
                mainHost = host;

                cachedInfos.Clear();
                MySea mySea = MyInfo.Ocean.GetCurrentSea();

                foreach (KeyValuePair<string, SeaItemInfo> pair in mySea.ItemInfoDict)
                {
                    cachedInfos.Add(pair.Key, pair.Value);
                }
            }
        }

        public void End(Object host)
        {
            if (mainHost == host)
            {
                mainHost = null;

                Diffs.Clear();
                MySea mySea = MyInfo.Ocean.GetCurrentSea();

                // 빠진 카운트를 먼저 기록하고
                foreach (KeyValuePair<string, SeaItemInfo> pair in cachedInfos)
                {
                    SeaItemInfo cacheInfo = pair.Value;
                    SeaItemInfo currentInfo;

                    int countDiff;
                    if (mySea.ItemInfoDict.TryGetValue(pair.Key, out currentInfo))
                    {
                        countDiff = currentInfo.Count - cacheInfo.Count;
                    }
                    else
                    {
                        countDiff = -cacheInfo.Count;
                    }

                    if (countDiff != 0)
                    {
                        Diffs.Add(new SeaItemDifference(cacheInfo.Type,
                                                        cacheInfo.ID,
                                                        countDiff));
                    }
                }

                // 후에 더해진 카운트를 기록합니다.
                foreach (KeyValuePair<string, SeaItemInfo> pair in mySea.ItemInfoDict)
                {
                    SeaItemInfo currentInfo = pair.Value;

                    if (cachedInfos.ContainsKey(pair.Key) == false)
                    {
                        Diffs.Add(new SeaItemDifference(currentInfo.Type,
                                                        currentInfo.ID,
                                                        currentInfo.Count));
                    }
                }

                Debug.Log(" === Sea Item Differences === ");
                foreach (SeaItemDifference diff in Diffs)
                {
                    Debug.Log(" === id : " + diff.id + ", type : " + diff.type + ", count : " + diff.count);
                }

                if (Diffs.Count > 0)
                {
                    OnUpdate?.Invoke();
                }
            }
        }

        public bool Contains(SeaItemType seaItemType)
        {
            if (Diffs.Count == 0)
            {
                return false;
            }

            foreach (SeaItemDifference diff in Diffs)
            {
                if( diff.type == seaItemType )
                {
                    return true;
                }
            }

            return false;
        }
    }
}
