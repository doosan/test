using System;
using Gaga;

namespace Underc.User
{
    public sealed class MyShop : IDisposable
    {
        public MyShopCoin Coin
        {
            get; private set;
        }

        public MyShopCoinSale CoinSale
        {
            get; private set;
        }

        public MyShopCoinCoupon CoinCoupon
        {
            get; private set;
        }

        private GlobalTime globalTime;

        public MyShop()
        {
            Coin = new MyShopCoin();
            CoinSale = new MyShopCoinSale();
            CoinCoupon = new MyShopCoinCoupon();

            globalTime = GlobalTime.Instance;
            globalTime.onUpdate += UpdateRemaningSec;
        }

        public void Dispose()
        {
            Coin.Dispose();
            CoinSale.Dispose();
            CoinCoupon.Dispose();

            globalTime.onUpdate -= UpdateRemaningSec;
        }

        private void UpdateRemaningSec(long serverTs)
        {
            CoinSale.UpdateRemainingSec();
            CoinCoupon.UpdateRemainingSec();
        }
    }
}