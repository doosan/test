using Gaga;
using System;
using UnityEngine.Events;

namespace Underc.User
{
    public sealed class MyShopCoinSale : IDisposable
    {
        public UnityEvent onTimeUpdate = new UnityEvent();
        public UnityEvent onTimesUp = new UnityEvent();

        public double Multiple
        {
            get; private set;
        }
        public long EndTs
        {
            get; private set;
        }

        public long RemainingSec
        {
            get; private set;
        }
        
        public bool HasSale
        {
            get
            {
                return RemainingSec != -1;
            }
        }

        public void Update(ShopSaleData data)
        {
            Reset();
            if (data != null)
            {
                Multiple = data.sale;
                EndTs = data.end_dt;
                UpdateRemainingSec();
            }
        }

        public void UpdateRemainingSec()
        {
            if (EndTs != -1)
            {
                RemainingSec = GlobalTime.Instance.SecondDiff(EndTs);

                if (RemainingSec == 0)
                {
                    Reset();
                    onTimesUp?.Invoke();
                }

                onTimeUpdate?.Invoke();
            }
        }

        private void Reset()
        {
            Multiple = 1;
            EndTs = -1;
            RemainingSec = -1;
        }

        public void Dispose()
        {

        }
    }
}