
using Gaga;
using System;
using System.Collections.Generic;
using UnityEngine.Events;

namespace Underc.User
{
    public class MyShopCoinCoupon : IDisposable
    {
        public int InfoCount
        {
            get
            {
                return couponItemInfosDict.Count;
            }
        }

        public int CurrInfoIndex 
        { 
            get
            {
                return currInfoIndex;
            }
            set
            {
                currInfoIndex = value;
                onInfoIndexChange?.Invoke();
            }
        }
        private int currInfoIndex;

        public bool RunAsFake
        {
            private get;
            set;
        }

        public UnityEvent onInfoIndexChange = new UnityEvent();
        public UnityEvent onTimeUpdate = new UnityEvent();
        public UnityEvent onTimesUp = new UnityEvent();

        private const int TOTAL_PRESET_COUNT = 2;

        private Dictionary<int, List<CouponItemInfo>> couponItemInfosDict;
        private List<int> removingInfos;
        private Dictionary<int, CouponMergeInfo> couponMergeInfos;

        public MyShopCoinCoupon()
        {
            couponItemInfosDict = new Dictionary<int, List<CouponItemInfo>>();
            removingInfos = new List<int>();
            couponMergeInfos = new Dictionary<int, CouponMergeInfo>();
        }

        public void Dispose()
        {
            
        }

        public void Merge(int index, CouponItemInfo couponItemInfo)
        {
            couponItemInfo.index = index;
            if (couponMergeInfos.ContainsKey(index) == false)
            {
                couponMergeInfos.Add(index, new CouponMergeInfo(couponItemInfo));
            }
        }

        public bool CanMerge(CouponInfo info)
        {
            bool result = true;

            PrepareMerge();
            foreach (CouponItemInfo itemInfo in info.itemInfos)
            {
                int presetIndex = GetMergeIndex(target: itemInfo.target,
                                                bonusRate: itemInfo.bonusRate);
                if (presetIndex < TOTAL_PRESET_COUNT)
                {
                    Merge(presetIndex, itemInfo);
                }
                else
                {
                    result = false;
                    break;
                }
            }

            return result;
        }

        public void PrepareMerge()
        {
            couponMergeInfos.Clear();
            foreach (KeyValuePair<int, List<CouponItemInfo>> pair in couponItemInfosDict)
            {
                couponMergeInfos.Add(pair.Key, new CouponMergeInfo(pair.Value[0]));
            }
        }

        public int GetMergeIndex(string target, int bonusRate)
        {
            int result = -1;

            /// 1. 먼저 infos 에서 같은 타입을 찾는다.
            foreach (CouponMergeInfo mergeInfo in couponMergeInfos.Values)
            {
                if (target == mergeInfo.target
                    && bonusRate == mergeInfo.bonusRate)
                {
                    result = mergeInfo.index;
                }
            }

            /// 2. 없으면 빈 자리를 찾는다.
            if (result == -1)
            {
                int index = 0;
                while (true)
                {
                    if (ContainsMergeInfos(index) == false)
                    {
                        result = index;
                        break;
                    }

                    index += 1;
                }
            }

            return result;
        }

        public bool ContainsMergeInfos(int infoIndex)
        {
            return couponMergeInfos.ContainsKey(infoIndex);
        }

        public bool ContainsInfos(int infoIndex)
        {
            return couponItemInfosDict.ContainsKey(infoIndex);
        }

        public List<CouponItemInfo> GetInfos(int infoIndex)
        {
            List<CouponItemInfo> result = null;
            if (couponItemInfosDict.ContainsKey(infoIndex) == true)
            {
                result = couponItemInfosDict[infoIndex];
            }
            
            return result;
        }

        public void UpdateRemainingSec()
        {
            if (couponItemInfosDict != null
                && couponItemInfosDict.Count > 0)
            {
                foreach (List<CouponItemInfo> infos in couponItemInfosDict.Values)
                {
                    CouponItemInfo info = infos[0];
                    info.remainingSec = GlobalTime.Instance.SecondDiff(info.expireTime);
                    if (info.remainingSec == 0)
                    {
                        removingInfos.Add(info.index);
                    }
                }

                if (removingInfos.Count > 0)
                {
                    foreach (int infosIndex in removingInfos)
                    {
                        couponItemInfosDict.Remove(infosIndex);
                    }
                    removingInfos.Clear();

                    ///
                    onTimesUp?.Invoke();
                }
                
                onTimeUpdate?.Invoke();
            }
        }

        private bool initDummyOnce;
        public void Update(ShopCouponItemData[] datas)
        {
            couponItemInfosDict.Clear();
            if (datas != null)
            {
                foreach (ShopCouponItemData data in datas)
                {
                    int couponID = data.coupon_id;
                    int index = data.index;
                    int bonusRate = data.bonus_rate;
                    string couponTarget = data.coupon_target;
                    long expireTime = data.expire_time;
                    int count = data.cnt;

                    List<CouponItemInfo> couponItemInfos;
                    if (couponItemInfosDict.ContainsKey(index) == false)
                    {
                        couponItemInfos = new List<CouponItemInfo>();
                        couponItemInfosDict.Add(index, couponItemInfos);
                    }

                    couponItemInfos = couponItemInfosDict[index];
                    couponItemInfos.Add(new CouponItemInfo(couponID,
                                                           index,
                                                           bonusRate,
                                                           couponTarget,
                                                           expireTime,
                                                           count));
                }
                UpdateRemainingSec();
            }
        }
    }
}