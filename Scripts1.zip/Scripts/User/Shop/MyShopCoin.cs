using Gaga.Util;
using System;
using System.Collections.Generic;

namespace Underc.User
{
    public enum ShopCoinTagType
    {
        None,
        BestValue,
        MostPopular
    }

    public class ShopCoinItemInfo
    {
        public int itemIndex;
        public string itemID;
        public long coin;
        public long vipBonus;
        public long vipPoint;
        public float price;
        public ShopCoinTagType tagType;

        public string priceCurrency;

        public long cachedCoin;

        public ShopCoinItemInfo(int itemIndex,
                                string itemID, 
                                long coinVipBonusAdded,
                                long vipBonus,
                                long vipPoint,
                                float price,
                                ShopCoinTagType tagType)
        {
            this.itemIndex = itemIndex;
            this.itemID = itemID;
            this.coin = coinVipBonusAdded - vipBonus;
            this.vipBonus = vipBonus;
            this.vipPoint = vipPoint;
            this.price = price;
            this.tagType = tagType;

            priceCurrency = StringUtils.ToCurrency(price);
        }
    }

    public sealed class MyShopCoin : IDisposable
    {
        public int ItemCount
        {
            get => itemInfoList.Count;
        }

        private List<ShopCoinItemInfo> itemInfoList;
        private Dictionary<string, ShopCoinItemInfo> itemInfoDict;

        public MyShopCoin()
        {
            itemInfoList = new List<ShopCoinItemInfo>();
            itemInfoDict = new Dictionary<string, ShopCoinItemInfo>();
        }

        public void Update(ShopCoinData[] datas, int bestIndex, int mostIndex)
        {
            itemInfoList.Clear();
            itemInfoDict.Clear();
            for (int dataIndex = 0; dataIndex < datas.Length; dataIndex++)
            {
                ShopCoinData data = datas[dataIndex];
                string itemID = data.itemid;
                ShopCoinTagType tagType = dataIndex == bestIndex ? ShopCoinTagType.BestValue :
                                          dataIndex == mostIndex ? ShopCoinTagType.MostPopular :
                                          ShopCoinTagType.None;
                var info = new ShopCoinItemInfo(itemIndex: dataIndex,
                                                itemID: itemID,
                                                coinVipBonusAdded: data.coin,
                                                vipBonus: data.vip_bonus,
                                                vipPoint: data.vip_point,
                                                price: data.price,
                                                tagType: tagType);
                itemInfoList.Add(info);
                itemInfoDict.Add(info.itemID, info);
            }
        }

        public ShopCoinItemInfo GetItemInfo(int index)
        {
            return itemInfoList[index];
        }

        public ShopCoinItemInfo GetItemInfo(string itemID)
        {
            ShopCoinItemInfo result;
            itemInfoDict.TryGetValue(itemID, out result);
            return result;
        }

        public void Dispose()
        {

        }
    }
}