using Gaga.Util;
using System;

namespace Underc.User
{
    public class MissionFormatInfo
    {
        public long Value
        {
            get => value;
        }
        public long Requirement
        {
            get => requirement;
        }
        public string Mission
        {
            get => mission;
        }

        private MissionFormatType type;
        private string mission;
        private long value;
        private long requirement;
        private string missionFormat;
        private bool hasRequirement;
        private bool hasLinebreak;

        public MissionFormatInfo(string mission, long value, long requirement)
        {
            Enum.TryParse(mission, out type);
            this.mission = mission;
            this.value = value;
            this.requirement = requirement;
            missionFormat = "";
            hasRequirement = false;
            hasLinebreak = false;

            UpdateFormat();
        }

        public override string ToString()
        {
            return StringMaker.New()
                              .Append("mission : " + mission)
                              .Append(", value : " + value)
                              .Append(", requirement : " + requirement)
                              .Build();
        }

        public string GetFormat(MissionFormatColor missionFormatColor, string prefix = "", string linebreak = " ")
        {
            string valueColor = missionFormatColor == MissionFormatColor.White ? "#FFFFFF" :// white
                                missionFormatColor == MissionFormatColor.Brown ? "#A5310C" :// brown
                                missionFormatColor == MissionFormatColor.Pink ? "#ff00ff" : // pink
                                "#ffff00";                                                  // yellow

            string result = "";
            if (hasRequirement)
            {
                result = hasLinebreak ?
                         string.Format(System.Globalization.CultureInfo.InvariantCulture, missionFormat, valueColor, value, StringUtils.ToGeneralKMB(requirement), prefix, linebreak) :
                         string.Format(System.Globalization.CultureInfo.InvariantCulture, missionFormat, valueColor, value, StringUtils.ToGeneralKMB(requirement), prefix);
            }
            else
            {
                result = hasLinebreak ?
                         string.Format(System.Globalization.CultureInfo.InvariantCulture, missionFormat, valueColor, StringUtils.ToGeneralKMB(value), prefix, linebreak) :
                         string.Format(System.Globalization.CultureInfo.InvariantCulture, missionFormat, valueColor, StringUtils.ToGeneralKMB(value), prefix);
            }

            return result;
        }

        private void UpdateFormat()
        {
            missionFormat = mission;

            hasRequirement = false;
            hasLinebreak = false;

            switch (type)
            {
                case MissionFormatType.spin:
                    missionFormat = "{2}Make <color={0}>{1}</color> normal spins.";
                    break;

                case MissionFormatType.time:
                    missionFormat = "{2}Collect lobby coins{3}bonus <color={0}>{1}</color> times.";
                    hasLinebreak = true;
                    break;

                case MissionFormatType.bettotal:
                    missionFormat = "{2}Bet <color={0}>{1}</color> coins.";
                    break;

                case MissionFormatType.wintotal:
                    missionFormat = "{2}Win <color={0}>{1}</color> coins.";
                    break;

                case MissionFormatType.paywin:
                    missionFormat = "{3}Win <color={0}>{2}</color> coins in{4}one spin <color={0}>{1}</color> times.";
                    hasRequirement = true;
                    hasLinebreak = true;
                    break;

                case MissionFormatType.paybet:
                    missionFormat = "{3}Spin <color={0}>{1}</color> times with{4}min bet of <color={0}>{2}</color>.";
                    hasRequirement = true;
                    hasLinebreak = true;
                    break;

                case MissionFormatType.lvup:
                    missionFormat = "{2}Level up <color={0}>{1}</color> times.";
                    break;

                case MissionFormatType.big:
                    missionFormat = "{2}Get big win <color={0}>{1}</color> times.";
                    break;

                case MissionFormatType.huge:
                    missionFormat = "{2}Get huge win <color={0}>{1}</color> times.";
                    break;

                case MissionFormatType.mega:
                    missionFormat = "{2}Get mega win <color={0}>{1}</color> times.";
                    break;

                case MissionFormatType.epic:
                    missionFormat = "{2}Get epic win <color={0}>{1}</color> times.";
                    break;

                case MissionFormatType.free:
                    missionFormat = "{2}Trigger free spins{3}<color={0}>{1}</color> times.";
                    hasLinebreak = true;
                    break;

                case MissionFormatType.golden:
                    missionFormat = "{2}Collect <color={0}>{1}</color> golden chests.";
                    break;

                case MissionFormatType.fish:
                    missionFormat = "{2}Get <color={0}>{1}</color> fish.";
                    break;
            }
        }
    }
}