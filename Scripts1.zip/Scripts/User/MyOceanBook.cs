using System;
using System.Collections.Generic;
using Underc.Ocean;
using UnityEngine;

namespace Underc.User
{
    public enum SeaItemType
    {
        n, // None
        f, // Fish
        s, // Swimmer
    }

    public sealed class MyOceanBook
    {
        private Dictionary<SeaItemType, Dictionary<int, BaseBookInfo>> books = new Dictionary<SeaItemType, Dictionary<int, BaseBookInfo>>();

        private Dictionary<int, BaseBookInfo> fishBookDict = new Dictionary<int, BaseBookInfo>();
        private List<BaseBookInfo> fishBookList = new List<BaseBookInfo>();
        private long fishBookUpdateTs;
        
        private Dictionary<int, BaseBookInfo> swimmerBookDict = new Dictionary<int, BaseBookInfo>();
        private List<BaseBookInfo> swimmerBookList = new List<BaseBookInfo>();
        private long swimmerBookUpdateTs;

        public MyOceanBook()
        {
            books.Add(SeaItemType.f, fishBookDict);
            books.Add(SeaItemType.s, swimmerBookDict);
        }

        public BookInfoProvider CreateFishBookInfoProvider()
        {
            return new BookInfoProvider(fishBookList);
        }

        public BookInfoProvider CreateSwimmerBookInfoProvider()
        {
            return new BookInfoProvider(swimmerBookList);
        }

        public Dictionary<int, BaseBookInfo> GetBook(SeaItemType type)
        {
            return books[type];
        }

        public BaseBookInfo GetBookInfo(SeaItemType type, int id)
        {
            BaseBookInfo bookInfo = null;
            if (books[type].TryGetValue(id, out bookInfo) == false)
            {
                Debug.LogWarning("그런 BookInfo는 없습니다 : " + type + ", " + id);
            }

            return bookInfo;
        }

        private List<BaseBookInfo> GetBookInfoList(SeaItemType type)
        {
            List<BaseBookInfo> bookInfoList = null;
            if (type == SeaItemType.f)
            {
                bookInfoList = fishBookList;
            }
            if (type == SeaItemType.s)
            {
                bookInfoList = swimmerBookList;
            }

            return bookInfoList;
        } 

        public BaseBookInfo GetBookInfoAtIndex(SeaItemType type, int index)
        {
            List<BaseBookInfo> bookInfoList = GetBookInfoList(type);

            if (index < 0 || index >= bookInfoList.Count)
            {
                return null;
            }

            return bookInfoList[index];
        }

        public int GetBookInfoCount(SeaItemType type)
        {
            List<BaseBookInfo> bookInfoList = GetBookInfoList(type);
            return bookInfoList.Count;
        }

        public BaseBookInfo GetFreeBookInfo(SeaItemType type)
        {
            List<BaseBookInfo> bookInfoList = GetBookInfoList(type);

            for (int i = 0; i < bookInfoList.Count; i++)
            {
                var book = bookInfoList[i];
                if (book.IsFree)
                {
                    return book;
                }
            }

            return null;
        }

        public void UpdateFishBookList(FishBookListData data)
        {
            //
            if (fishBookUpdateTs != data.update_ts)
            {
                fishBookDict.Clear();
                fishBookList.Clear();
                
                FishBookList fishes = data.fishes;
                for (int i = 0; i < fishes.ids.Length; i++)
                {
                    int id = fishes.ids[i];
                    bool isFree = id == data.free_id && data.free_state == 0;

                    FishBookInfo info = new FishBookInfo(id, 
                                                         fishes.min_levels[i], 
                                                         fishes.pearls[i], 
                                                         fishes.coins[i], 
                                                         fishes.points[i],
                                                         isFree);

                    fishBookDict.Add(id, info);
                    fishBookList.Add(info);
                }
            }
        }

        public void UpdateSwimmerBookList(SwimmerBookListData data)
        {
            if (swimmerBookUpdateTs != data.update_ts)
            {
                swimmerBookDict.Clear();
                swimmerBookList.Clear();
                
                SwimmerBookList swimmer = data.swimmers;
                for (int i = 0; i < swimmer.ids.Length; i++)
                {
                    int id = swimmer.ids[i];
                    bool isFree = id == data.free_id && data.free_state == 0;

                    SwimmerBookInfo info = new SwimmerBookInfo(swimmer.ids[i], 
                                                               swimmer.min_levels[i], 
                                                               swimmer.pearls[i], 
                                                               swimmer.tickets[i], 
                                                               swimmer.points[i],
                                                               isFree);

                    swimmerBookDict.Add(id, info);
                    swimmerBookList.Add(info);
                }
            }
        }
    }

    public class BookInfoProvider
    {
        public int ItemCount
        {
            get
            {
                return infos.Count;
            }
        } 

        public SeaItemType ItemType{get; private set;}

        private List<BaseBookInfo> infos;
        
        public BookInfoProvider(List<BaseBookInfo> infos)
        {
            this.infos = infos;
            ItemType = infos.Count > 0 ? infos[0].Type : SeaItemType.n;
        }

        public BaseBookInfo GetBookInfo(int index)
        {
            return infos[index];
        }
    }

    public abstract class BaseBookInfo
    {
        public abstract string Title { get; }
        public abstract string Story { get; }
        public abstract Sprite Icon { get; }
        public abstract SeaItemType Type { get; }
        public abstract int SizeGrade { get; }
        public abstract bool IsLocked { get; }

        public abstract Func<SeaItemType, int, bool, GameObject> GetModel { get; }
        
        public virtual bool IsOwned
        {
            get => MyInfo.Ocean.GetCurrentSea().Exists(Type, ID);
        }

        public virtual int CountInThisSea
        {
            get => MyInfo.Ocean.GetCurrentSea().GetManageableItemCount(Type, ID)
                   + MyInfo.Ocean.SeaItemSync.Count(Type, ID);
        }

        public int ID { get; protected set; }

        // Lock
        public int MinLevel { get; protected set; }
        public int Star { get; protected set;  }

        // Cost
        public long Coin { get; protected set;  }
        public int Pearl { get; protected set;  }
        public int Ticket { get; protected set;  }
        public bool IsFree { get; protected set;  }
        
        // Reward
        public int Point { get; protected set;  }
    }

    public class FishBookInfo : BaseBookInfo
    {
        public override string Title
        {
            get { return FishSystem.Instance.GetFishPreset(Type, ID).book.titleName; }
        }
        public override string Story
        {
            get { return FishSystem.Instance.GetFishPreset(Type, ID).book.story; }
        }
        public override Sprite Icon 
        {
            get { return FishIconSystem.Instance.GetFishIcon(Type, ID); }
        }
        public override SeaItemType Type 
        { 
            get { return SeaItemType.f; }
        }
        public override int SizeGrade
        {
            get { return FishSystem.Instance.GetFishPreset(Type, ID).ui.sizeGrade; }
        }
        public override bool IsLocked
        {
            get { return MyInfo.Level < MinLevel; }
        }

        public override Func<SeaItemType, int, bool/* SetUiTransform */, GameObject/* Return */> GetModel 
        {
            get { return FishSystem.Instance.GetFish; }
        }
        
        public FishBookInfo(int id, int minLevel, int pearl, long coin, int happiness, bool isFree = false)
        {
            ID = id;
            MinLevel = minLevel;
            Pearl = pearl;
            Coin = coin;
            Point = happiness;
            IsFree = isFree;
        }
    }

    public class SwimmerBookInfo : BaseBookInfo
    {
        public override string Title
        {
            get { return FishSystem.Instance.GetFishPreset(Type, ID).book.titleName; }
        }
        public override string Story
        {
            get { return FishSystem.Instance.GetFishPreset(Type, ID).book.story; }
        }
        public override Sprite Icon 
        { 
            get { return FishIconSystem.Instance.GetFishIcon(Type, ID); }
        }        
        public override SeaItemType Type 
        { 
            get { return SeaItemType.s; }
        }
        public override int SizeGrade
        {
            get { return FishSystem.Instance.GetFishPreset(Type, ID).ui.sizeGrade; }
        }
        public override bool IsLocked
        {
            get { return MyInfo.Level < MinLevel; }
        }
        public override Func<SeaItemType, int, bool, GameObject> GetModel 
        {
            get { return FishSystem.Instance.GetFish; }
        }
        public override bool IsOwned
        {
            get 
            { 
                return MyInfo.Ocean.SeaItemSync.Exists(Type, ID) == true 
                       || MyInfo.Ocean.GetCurrentSea().Exists(Type, ID) == true;
            }
        }
        
        public SwimmerBookInfo(int id, int minLevel, int pearl, int ticket, int happiness, bool isFree = false)
        {
            ID = id;
            MinLevel = minLevel;
            Pearl = pearl;
            Ticket = ticket;
            Point = happiness;
            IsFree = isFree;
        }
    }
}