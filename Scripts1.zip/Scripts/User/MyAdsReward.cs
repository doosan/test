using System;
using System.Collections.Generic;

namespace Underc.User
{
    public class MyAdsReward : IDisposable
    {
        //public int DailyCount { get; private set; }
        public bool Available { get; private set;  }

        public long Reward { get; private set; }
        public long Coin { get; private set; }

        private List<long> wheelValues;

        public MyAdsReward()
        {
            wheelValues = new List<long>();
        }

        public void Dispose()
        {

        }

        public void Update(UnityAdsCheckData data)
        {
            //DailyCount = data.dailycnt;
            Available = data.avail;
        }

        public void Update(UnityAdsNextData data)
        {
            //DailyCount = data.dailycnt;
            wheelValues.Clear();
            if (data.wheel != null)
            {
                wheelValues.AddRange(data.wheel);
            }

            Available = wheelValues.Count > 0;
        }

        public void Update(UnityAdsClaimData data)
        {
            Reward = data.reward;
            Coin = data.coin;
        }
    }
}