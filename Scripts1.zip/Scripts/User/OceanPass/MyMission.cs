using System;

namespace Underc.User
{
    public class MyMission : IDisposable
    {
        public void Update(MissionData data)
        {
            
        }

        public void Dispose()
        {
            
        }
    }
}