using System;
using System.Collections.Generic;

namespace Underc.User
{
    public sealed class MyChallenge : IDisposable
    {
        public enum ChallengeType
        {
            None,
            Booster,
            Broadcast,
            Sea
        }

        public enum State
        {
            Completed       = 0,
            Disable         = 1,
            Enable          = 2,
            CompleteNow     = 3,
            CompleteEnd     = 100
        }

        private class ChallengeInfo
        {
            public State state = State.Disable;
            public int level;
        }

        public delegate void ChangeDelegate(ChallengeType challengeType, State state);
        public event ChangeDelegate onChange;

        private Dictionary<ChallengeType, ChallengeInfo> challengeDic;

        public long RewardCoin { get; private set; }

        public MyChallenge()
        {
            challengeDic = new Dictionary<ChallengeType, ChallengeInfo>(new MyEnumComparer());
        }

        public void Dispose(){}
        
        public void Update(ChallengeData challengeData)
        {
            RewardCoin = challengeData.reward_coin;

            SetLevel(ChallengeType.Booster, challengeData.pearl_booster_level);
            SetLevel(ChallengeType.Broadcast, challengeData.noti_level);
            SetLevel(ChallengeType.Sea, challengeData.sea_level);
            
            SetState(ChallengeType.Booster, challengeData.pearl_booster);
            SetState(ChallengeType.Broadcast, challengeData.noti);
            SetState(ChallengeType.Sea, challengeData.sea);
        }

        private ChallengeInfo GetInfo(ChallengeType challengeType)
        {
            if (challengeDic.ContainsKey(challengeType) == false)
            {
               ChallengeInfo newInfo = new ChallengeInfo();
               challengeDic.Add(challengeType, newInfo);
            }

            return challengeDic[challengeType];
        }

        private void SetLevel(ChallengeType challengeType, int value)
        {
            if (value <= 0)
            {
                return;
            }

            GetInfo(challengeType).level = value;
        }

        public int GetLevel(ChallengeType challengeType)
        {
            return GetInfo(challengeType).level;
        }

        private void SetState(ChallengeType challengeType, int value)
        {
            SetState(challengeType, (State)value);
        }

        public void SetState(ChallengeType challengeType, State state)
        {
            var info = GetInfo(challengeType);

            if (info.state == state)
            {
                return;
            }

            info.state = state;

            if (onChange != null)
            {
                onChange(challengeType, state);
            }
        }

        public State GetState(ChallengeType challengeType)
        {
            return GetInfo(challengeType).state;
        }

        public ChallengeType GetCurrentChallenge()
        {
            foreach(ChallengeType enumItem in Enum.GetValues(typeof(ChallengeType)))
            {
                if (GetState(enumItem) != State.Disable && GetState(enumItem) != State.Completed)
                {
                    return enumItem;
                }
            }

            return ChallengeType.None;
        }

        private struct MyEnumComparer : IEqualityComparer<ChallengeType>
        {
            public bool Equals(ChallengeType x, ChallengeType y)
            {
                return x == y;
            }

            public int GetHashCode(ChallengeType obj)
            {
                return (int)obj;
            }
        }
    }   
}