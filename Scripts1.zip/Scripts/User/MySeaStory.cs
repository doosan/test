using System;
using System.Collections.Generic;

namespace Underc.User
{
    public sealed class MySeaStory
    {
        public event Action<int> onChangedCollectionCount;

        public const int CHAPTER_COUNT = 3;
        public const int STEP_COUNT = 4;

        public sealed class ChapterInfo
        {
            public List<StepInfo> stepInfoList;
        }

        public sealed class StepInfo
        {
            public long point;
            public long reward;
        }

        public sealed class CollectionInfo
        {
            public struct Item
            {
                public SeaItemType itemType;
                public int id;
                public int count;
                public bool isNew;
            }

            public long point;
            public List<Item> items;
            public int totalItemCount;
            public long prize;
            public bool hasNewFish;

            public CollectionInfo Clone()
            {
                var newInfo = new CollectionInfo();
                newInfo.point = point;
                newInfo.items = new List<Item>(items);
                newInfo.totalItemCount = totalItemCount;
                newInfo.prize = prize;
                newInfo.hasNewFish = hasNewFish;

                return newInfo;
            }
        } 

        private List<ChapterInfo> chapterInfoList;

        private CollectionInfo collection;
        public bool HasCollection
        {
            get => collection.point > 0;
        }

        public long Point
        {
            get; 
            private set;
        }
        public long guidePoint;
        private int newSeaID;
        
        public MySeaStory()
        {
            InitChapters();
            InitCollection();
        }

        private void InitChapters()
        {
            chapterInfoList = new List<ChapterInfo>();
            for (int chapterIndex = 0; chapterIndex < CHAPTER_COUNT; chapterIndex++)
            {
                var chapterInfo = new ChapterInfo();
                chapterInfo.stepInfoList = new List<StepInfo>();

                for (int stepIndex = 0; stepIndex < STEP_COUNT; stepIndex++)
                {
                    var stepInfo = new StepInfo();
                    chapterInfo.stepInfoList.Add(stepInfo);
                }

                chapterInfoList.Add(chapterInfo);
            }
        }

        private void InitCollection()
        {
            collection = new CollectionInfo();
            collection.items = new List<CollectionInfo.Item>();
        }

        private void ResetCollection()
        {
            collection.point = 0;
            collection.totalItemCount = 0;
            collection.items.Clear();
        }

        public void Update(SeaStoryData data)
        {
            newSeaID = data.new_sea;

            int dataIndex = 0;
            for (int chapterIndex = 0; chapterIndex < CHAPTER_COUNT; chapterIndex++)
            {
                var chapterInfo = chapterInfoList[chapterIndex];

                for (int stepIndex = 0; stepIndex < STEP_COUNT; stepIndex++)
                {
                    var stepInfo = chapterInfo.stepInfoList[stepIndex];
                    if (dataIndex < data.points.Length)
                    {
                        stepInfo.point = data.points[dataIndex];
                    }
                    if (dataIndex < data.rewards.Length)
                    {
                        stepInfo.reward = data.rewards[dataIndex];
                    }

                    dataIndex++;
                }
            }

            Point = data.point;

            if (data.collected != null && data.collected.point > 0)
            {
                var tempCollectionCount = collection.totalItemCount;

                collection.point = data.collected.point;
                collection.items.Clear();
                collection.totalItemCount = 0;
                collection.prize = data.prize;
                collection.hasNewFish = data.collected.HasNewFish();

                for (int i = 0; i < data.collected.types.Length; i++)
                {
                    var itemType = data.collected.types[i] == 1 ? SeaItemType.f : SeaItemType.s;
                    var id = data.collected.ids[i];
                    var cnt = data.collected.cnts[i];
                    var isNew = data.collected.news != null && data.collected.news[i] == 1;

                    var item = new CollectionInfo.Item();
                    item.itemType = itemType;
                    item.id = id;
                    item.count = cnt;
                    item.isNew = isNew;

                    collection.totalItemCount += cnt;

                    collection.items.Add(item);
                }

                if (tempCollectionCount != collection.totalItemCount)
                {
                    onChangedCollectionCount?.Invoke(collection.totalItemCount);
                }
            }
            else if (data.not_claimed_point > 0)
            {
                collection.point = data.not_claimed_point;
                collection.items.Clear();
                collection.totalItemCount = 0;

                onChangedCollectionCount?.Invoke(0);
            }
            else
            {
                ResetCollection();

                onChangedCollectionCount?.Invoke(0);
            }
        }

        public int ConsumeNewSeaID()
        {
            int result = newSeaID;
            newSeaID = 0;
            return result;
        }

        public void Update(SeaStoryClaimData data)
        {
            if (data == null)
            {
                return;
            }

            Point = data.point;
            ResetCollection();
            collection.point = data.not_claimed_point;
        }

        public void UpdatePoint(long point)
        {
            Point = point;
        }

        public void AppendPoint(long point)
        {
            Point += point;
        }

        public long GetPoint(int chapter, int step)
        {
            var chapterInfo = chapterInfoList[chapter];
            var stepInfo = chapterInfo.stepInfoList[step];

            return stepInfo.point;
        }

        public long GetTotalPoint()
        {
            return GetPoint(CHAPTER_COUNT - 1, STEP_COUNT - 1);
        }

        public long GetReward(int chapter, int step)
        {
            var chapterInfo = chapterInfoList[chapter];
            var stepInfo = chapterInfo.stepInfoList[step];

            return stepInfo.reward;
        }

        public long GetAllRewards()
        {
            long value = 0;

            for (int chapter = 0; chapter < chapterInfoList.Count; chapter++)
            {
                var chapterInfo = chapterInfoList[chapter];

                for (int step = 0; step < chapterInfo.stepInfoList.Count; step++)
                {
                    var stepInfo = chapterInfo.stepInfoList[step];
                    value += stepInfo.reward;
                }
            }

            return value;
        }

        public CollectionInfo GetCollection()
        {
            if (HasCollection == false)
            {
                return null;
            }

            return collection;
        }

        public CollectionInfo CloneCollection()
        {
            if (HasCollection == false)
            {
                return null;
            }

            return collection.Clone();
        }

        public bool ConsumeCollection()
        {
            if (HasCollection == false)
            {
                return false;
            }

            ResetCollection();

            onChangedCollectionCount?.Invoke(0);

            return true;
        }
    }
}