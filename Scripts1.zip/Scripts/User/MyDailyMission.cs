using Gaga;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine.Events;

namespace Underc.User
{
    public enum FeatureDisplayUnlockState
    {
        Lock = 0,
        JustUnlock = 1,
        Unlock = 2
    }

    public enum DailyMissionPointState
    {
        InProgress = 0,
        Collect = 1,
        Complete = 2
    }

    public enum MissionFormatType
    {
        none,
        spin,
        time,
        bettotal,
        wintotal,
        paywin,
        paybet,
        lvup,
        big,
        huge,
        mega,
        epic,
        free,
        golden,
        fish
    }

    public enum MissionFormatColor
    {
        Pink,
        Yellow,
        Brown,
        White
    }

    public struct DailyMissionDisplayInfoCache
    {
        public int step;
        public long curr;
        public DailyMissionPointState pointState;

        public DailyMissionDisplayInfoCache(int step, 
                                            long curr,
                                            DailyMissionPointState pointState)
        {
            this.step = step;
            this.curr = curr;
            this.pointState = pointState;
        }

        public override string ToString()
        {
            return $"pointState: {pointState}" +
                   $", step : {step}" +
                   $", curr : {curr}";
        }
    }

    public class DailyMissionDisplayInfo
    {
        public bool RewardInProgress
        {
            get;
            private set;
        }

        public float Progress
        {
            get
            {
                return all > 0 ?
                       curr / (float)all :
                       0f;
            }
        }
        public int BadgeCount
        {
            get => PointState == DailyMissionPointState.Collect ?
                   1 :
                   0;
        }
        public int StepChange
        {
            get;
            private set;
        }
        public long CurrChange
        {
            get;
            private set;
        }
        public FeatureDisplayUnlockState unlockState;
        public int unlockLevel;
        public int step;
        public long curr;
        public long all;
        public MissionFormatInfo missionFormatInfo;
        public DailyMissionPointState PointState
        {
            get;
            private set;
        }
        public DailyMissionDisplayInfoCache prevCache;
        public DailyMissionDisplayInfoCache nextCache;
        
        private bool initOnce;

        public void Update(FeatureDisplayUnlockState unlockState,
                           int unlockLevel,
                           int step,
                           string mission,
                           long curr,
                           long all,
                           long requirement,
                           DailyMissionPointState pointState)
        {
            // 데이터를 저장하기 전에 먼저 수행
            SaveCache(step, curr, pointState);

            if (this.unlockState == FeatureDisplayUnlockState.Lock)
            {
                this.unlockState = unlockState; 
            }
            if (unlockLevel > 0)
            {
                this.unlockLevel = unlockLevel;
            }
            this.step = step;
            this.curr = curr;
            this.all = all;
            if (string.IsNullOrEmpty(mission) == false)
            { 
                this.missionFormatInfo = new MissionFormatInfo(mission, all, requirement);
                //Debug.Log($"==== missionItemInfo : {this.missionItemInfo}");
            }
            this.PointState = pointState;

            if (initOnce == false)
            {
                initOnce = true;

                // A-1. 데이터가 변경된 이후 어떤 시점에 이전 데이터에서 바뀌는 연출을 다시 보여주기 위한 용도
                // A-2. 가장 처음 생성된 데이터는 변경된 데이터로 인식하지 않게끔 캐시를 한 번 더 채워줌
                SaveCache(step, curr, pointState);
                StepChange = 0;
                CurrChange = 0;
            }
        }

        private void SaveCache(int nextStep, 
                               long nextCurr,
                               DailyMissionPointState nextPointState)
        {
            prevCache = new DailyMissionDisplayInfoCache(this.step, this.curr, this.PointState);
            nextCache = new DailyMissionDisplayInfoCache(nextStep, nextCurr, nextPointState);
            //Debug.Log("==== SaveCache : " + StepChange + " : " + this.step + " -> " + nextStep );

            if (StepChange == 0)
            {
                StepChange = nextStep - this.step;
            }
            if (CurrChange == 0)
            {
                CurrChange = nextCurr - this.curr;
            }
        }

        public void LoadPrevCache()
        {
            PointState = prevCache.pointState;
            step = prevCache.step;
            curr = prevCache.curr;
        }

        public void LoadNextCache()
        {
            PointState = nextCache.pointState;
            step = nextCache.step;
            curr = nextCache.curr;
        }

        public long ConsumeCurrChange()
        {
            long result = CurrChange;
            CurrChange = 0;
            return result;
        }

        public int ConsumeStepChange()
        {
            int result = StepChange;
            StepChange = 0;
            return result;
        }

        public bool ConsumeJustUnlockState()
        {
            bool result = false;
            if (unlockState == FeatureDisplayUnlockState.JustUnlock)
            {
                result = true;
                unlockState = FeatureDisplayUnlockState.Unlock;
            }

            return result;
        }

        public void Update(bool rewardInProgress)
        {
            RewardInProgress = rewardInProgress;
        }

        public bool ConsumeRewardInProgress()
        {
            bool result = RewardInProgress;
            RewardInProgress = false;
            return result;
        }

        public override string ToString()
        {
            return $"unlockState : {unlockState}" + 
                   $", unlockLevel : {unlockLevel}" + 
                   $", step : {step}" + 
                   $", curr : {curr}" + 
                   $", all : {all}" + 
                   $", missionFormatInfo : {missionFormatInfo}" + 
                   $", dailyMissionPointState : {PointState}";
        }
    }

    public class DailyMissionInfo
    {
        public int step;
        public long curr;
        public long all;
        public List<RewardInfo> rewardInfos;
        public MissionFormatInfo missionFormatInfo;

        public DailyMissionInfo(int step, long curr, long all, long require, string mission, List<RewardInfo> rewardInfos)
        {
            this.step = step;
            this.curr = curr;
            this.all = all;
            this.rewardInfos = rewardInfos;
            if (string.IsNullOrEmpty(mission) == false)
            {
                missionFormatInfo = new MissionFormatInfo(mission, all, require);
            }
        }
    }

    public struct DailyMissionPointInfoCache
    {
        public long curr;
        public long all;

        public DailyMissionPointInfoCache(long curr, long all)
        {
            this.curr = curr;
            this.all = all;
        }

        public override string ToString()
        {
            return $"curr : {curr}, all : {all}";
        }
    }

    public class DailyMissionPointInfo
    {
        public long curr;
        public long all;
        public DailyMissionPointState state;
        public DailyMissionPointInfoCache prevCache;
        public DailyMissionPointInfoCache nextCache;

        private bool initOnce;

        public void Update(long curr, long all, DailyMissionPointState state)
        {
            // 데이터를 저장하기 전에 먼저 수행
            SaveCache(curr, all);

            this.curr = curr;
            this.all = all;
            this.state = state;

            if (initOnce == false)
            {
                initOnce = true;

                // A-1. 데이터가 변경된 이후 어떤 시점에 이전 데이터에서 바뀌는 연출을 다시 보여주기 위한 용도
                // A-2. 가장 처음 생성된 데이터는 변경된 데이터로 인식하지 않게끔 캐시를 한 번 더 채워줌
                SaveCache(curr, all);
            }
        }

        private void SaveCache(long nextCurr, long nextAll)
        {
            prevCache = new DailyMissionPointInfoCache(this.curr, this.all);
            nextCache = new DailyMissionPointInfoCache(nextCurr, nextAll);

            //Debug.Log($"==== SaveCache : {prevCache} -> {nextCache}");
        }

        public void LoadPrevCache()
        {
            curr = prevCache.curr;
            all = prevCache.all;
            //Debug.Log($"==== LoadPrevCache : {curr} / {all}");
        }

        public void LoadNextCache()
        {
            curr = nextCache.curr;
            all = nextCache.all;
            //Debug.Log($"==== LoadNextCache : {curr} / {all}");
        }
    }

    public enum DailyMissionRemainingTime
    { 
        Mission,
        Point
    }

    public class DailyMissionRemainingTimeEvent : UnityEvent<DailyMissionRemainingTime> { }

    public class MyDailyMission : IDisposable
    {
        public UnityEvent onDisplayInfoUpdate = new UnityEvent();
        public DailyMissionRemainingTimeEvent onTimeUpdate = new DailyMissionRemainingTimeEvent();
        public DailyMissionRemainingTimeEvent onTimesUp = new DailyMissionRemainingTimeEvent();

        public DailyMissionInfo Info
        {
            get;
            private set;
        }

        public DailyMissionDisplayInfo DisplayInfo
        {
            private set;
            get;
        }

        public DailyMissionPointInfo PointInfo
        {
            get;
            private set;
        }

        public int PrevStep
        {
            get;
            private set;
        }

        public long MissionEndRemainingSec
        {
            get;
            private set;
        } = -1;
        private long missionEndTs;

        public long PointEndRemainingSec
        {
            get;
            private set;
        } = -1;
        private long pointEndTs;

        private List<RewardInfo> missionRewardInfos;
        private List<RewardInfo> pointRewardInfos;
        private List<RewardInfo> tempRewardInfos;

        private GlobalTime globalTime;
        private long updateTs;

        public MyDailyMission()
        {
            globalTime = GlobalTime.Instance;
            globalTime.onUpdate += UpdateRemainingSec;

            missionRewardInfos = new List<RewardInfo>();
            tempRewardInfos = new List<RewardInfo>();
        }

        public void Dispose()
        {
            globalTime.onUpdate -= UpdateRemainingSec;
        }

        private List<RewardInfo> UpdateRewardInfos(RewardType rewardType, long[] rewardValues)
        {
            // B-1 GameSpeicial, GameChoice 등의 응답에는 data.mp_point 값이 포함되어 있지 않다.
            // B-2 그래서 값이 존재할 때만 Info 를 업데이트 해주고 있음
            if (rewardValues != null && rewardValues.Length > 0)
            {
                tempRewardInfos.Clear();
                foreach (long rewardValue in rewardValues)
                {
                    tempRewardInfos.Add(new RewardInfo(rewardType, rewardValue));
                }
            }
            return tempRewardInfos.ToList();
        }

        private List<RewardInfo> UpdateRewardInfos(CommonRewardData[] rewardDatas, Func<RewardType, bool> CheckToSkip = null)
        {
            tempRewardInfos.Clear();
            if (rewardDatas != null)
            {
                foreach (CommonRewardData rewardData in rewardDatas)
                {
                    if (Enum.TryParse(rewardData.rwd, out RewardType type))
                    {
                        if (CheckToSkip != null
                            && CheckToSkip?.Invoke(type) == true)
                        {
                            continue;
                        }

                        tempRewardInfos.Add(new RewardInfo(type, rewardData.val));
                    }
                }
            }

            return tempRewardInfos.ToList();
        }

        public void Update(DailyMissionPointClaimData data)
        {
            pointRewardInfos = null;
            if (data.reward != null)
            {
                pointRewardInfos = UpdateRewardInfos(data.reward);
            }
        }

        public List<RewardInfo> ConsumePointRewardInfos()
        {
            List<RewardInfo> result = pointRewardInfos;
            pointRewardInfos = null;
            return result;
        }

        public void Update(long updateTs, CommonRewardData[] reward, DailyMissionData data)
        {
            DailyMissionPointState prevDailyMissionPointState = DisplayInfo.PointState;

            PrevStep = data.prev_step;
            Update(updateTs, data);

            missionRewardInfos = null;
            if (reward != null)
            {
                missionRewardInfos = UpdateRewardInfos(
                    rewardDatas: reward, 
                    CheckToSkip: rewardType => rewardType == RewardType.weekly_point
                                               && prevDailyMissionPointState == DailyMissionPointState.Complete
                );
            }
        }

        public void Update(int prevStep)
        {
            PrevStep = prevStep;
        }

        public List<RewardInfo> ConsumeMissionRewardInfos()
        {
            List<RewardInfo> result = missionRewardInfos;
            missionRewardInfos = null;
            return result;
        }

        public void Update(long updateTs, DailyMissionData data)
        {
            //Debug.Log($"==== Update : {updateTs} > {this.updateTs} = {updateTs > this.updateTs}");
            if (data != null
                && updateTs > this.updateTs)
            {
                this.updateTs = updateTs; // 현재 값보다 이전의 값은 무시

                UpdateMissionInfo(
                    step: data.step,
                    curr: data.curr,
                    all: data.all,
                    require: data.require,
                    mission: data.mission,
                    missionEndTs: data.daily_end_ts,
                    missionRewardInfos: data.mp_point != null ? 
                                        UpdateRewardInfos(RewardType.mp_point, data.mp_point) :
                                        null
                );

                UpdatePointInfo(
                    curr: data.weekly_curr,
                    all: data.weekly_all,
                    pointEndTs: data.weekly_end_ts,
                    pointState: (DailyMissionPointState)data.n
                );

                UpdateRemainingSec(globalTime.GetTimeStamp());

                UpdateDisplayInfo(
                    unlockState: (FeatureDisplayUnlockState)data.is_unlock,
                    unlockLevel: data.unlock,
                    step: data.step,
                    mission: data.mission,
                    curr: data.curr,
                    all: data.all,
                    require: data.require,
                    pointState: (DailyMissionPointState)data.n
                );
            }
        }

        private void UpdateDisplayInfo(FeatureDisplayUnlockState unlockState,
                                       int unlockLevel, 
                                       int step,
                                       string mission,
                                       long curr,
                                       long all,
                                       long require,
                                       DailyMissionPointState pointState)
        {
            if (DisplayInfo == null)
            {
                DisplayInfo = new DailyMissionDisplayInfo();
            }
            DisplayInfo.Update(unlockState: unlockState,
                               unlockLevel: unlockLevel,
                               step: step,
                               mission: mission,
                               curr: curr,
                               all: all,
                               requirement: require,
                               pointState: pointState);
            //Debug.Log($"==== DailyMissionDisplayInfo : {DisplayInfo}");

            onDisplayInfoUpdate?.Invoke();
        }
        
        private void UpdateMissionInfo(int step,
                                       long curr,
                                       long all,
                                       long require,
                                       string mission,
                                       long missionEndTs,
                                       List<RewardInfo> missionRewardInfos)
        {
            Info = new DailyMissionInfo(
                step: step,
                curr: curr,
                all: all,
                require: require,
                mission: mission,
                // B-1 spin.daily_quest.mp_point 와
                // B-2 enter.daily_quest.mp_point 는 비어있어 기존 보상 값을 유지
                rewardInfos: missionRewardInfos != null ? missionRewardInfos :
                             Info != null ? Info.rewardInfos :
                             null
            );
            this.missionEndTs = missionEndTs;
        }

        public void UpdatePointInfo(long curr,
                                    long all,
                                    long pointEndTs,
                                    DailyMissionPointState pointState)
        {
            if (PointInfo == null)
            {
                PointInfo = new DailyMissionPointInfo();
            }
            PointInfo.Update(curr: curr,
                             all: all,
                             state: pointState);
            this.pointEndTs = pointEndTs;
        }

        public void UpdateRemainingSec(long serverTs)
        {
            if (missionEndTs > 0)
            {
                MissionEndRemainingSec = globalTime.SecondDiff(missionEndTs);
                onTimeUpdate?.Invoke(DailyMissionRemainingTime.Mission);

                if (MissionEndRemainingSec == 0)
                {
                    onTimesUp?.Invoke(DailyMissionRemainingTime.Mission);
                }
            }

            if (pointEndTs > 0)
            {
                PointEndRemainingSec = globalTime.SecondDiff(pointEndTs);
                onTimeUpdate?.Invoke(DailyMissionRemainingTime.Point);

                if (PointEndRemainingSec == 0)
                {
                    onTimesUp?.Invoke(DailyMissionRemainingTime.Point);
                }
            }
        }
    }
}