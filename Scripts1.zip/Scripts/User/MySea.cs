using System;
using System.Collections.Generic;
using Gaga.Util;

namespace Underc.User
{
    public enum SeaUnlockState
    { 
        Lock = 0,
        Unlockable = 1,
        Unlock = 2
    }

    public class SeaPresecuredInfo
    {
        public float prevValue = -1;
        public float currValue = -1;
        public bool isValueChanged;

        public void Update(float currValue)
        {
            this.prevValue = this.currValue;
            this.currValue = currValue;
            if (prevValue == -1)
            {
                prevValue = currValue;
            }
            isValueChanged = prevValue != currValue;
        }
    }

    public sealed class MySea
    {
        public delegate void HappinessDelegate(long current, long full);
        
        public HappinessDelegate OnHappinessChanged;

        public int ID { get; private set; }
        public string Name { get; private set; }
        public int Star
        { 
            get
            {
                var star = 0;

                for (int i = 1; i <= MySeaStory.CHAPTER_COUNT; i++ )
                {
                    if (step >= MySeaStory.STEP_COUNT * i)
                    {
                        star = i;
                    }
                }

                return star;
            }
        }
        private int step;
        public int UnlockLevel 
        { 
            get; 
            private set;
        }
        public bool IsInProgress
        {
            get;
            private set;
        }
        public bool IsInLevelLock
        {
            get;
            private set;
        }
        public long Bonus
        {
            get;
            private set;
        }
        public long Curr
        {
            get;
            private set;
        }
        public long All
        {
            get;
            private set;
        }
        public SeaUnlockState UnlockState
        {
            get;
            private set;
        }
            
        /// 
        public long MaxCapacity { get; private set; }
        public int ManageableItemInfoCount
        {
            get => manageableItemInfoList.Count;
        }
        public int ManageableItemCount 
        { 
            get; 
            private set; 
        }
        public int SwimmerItemCount 
        { 
            get; 
            private set; 
        }
        public float CurrPresecured
        {
            get;
            private set;
        } = -1;
        public float PrevPresecured
        {
            get;
            private set;
        } = -1;
        public SeaPresecuredInfo PresecuredInfo
        {
            get;
            private set;
        }
        public Dictionary<string, SeaItemInfo> ItemInfoDict 
        { 
            get; 
            private set; 
        }

        private List<SeaItemInfo> manageableItemInfoList;

        public MySea()
        {
            ItemInfoDict = new Dictionary<string, SeaItemInfo>();
            manageableItemInfoList = new List<SeaItemInfo>();
            PresecuredInfo = new SeaPresecuredInfo();
        }

        public void Update(SeaData seaData)
        {
            ID = seaData.sea;
            Name = string.Format(System.Globalization.CultureInfo.InvariantCulture, "SEA STORY {0}", ID.ToString());
            step = seaData.step;
            UnlockLevel = seaData.unlock_level;
            Curr = seaData.curr;
            All = seaData.all;
            Bonus = seaData.bonus;
            UnlockState = (SeaUnlockState)seaData.status;
            
            int MAX_STEP_COUNT = MySeaStory.CHAPTER_COUNT * MySeaStory.STEP_COUNT;
            IsInProgress = step < MAX_STEP_COUNT;
            IsInLevelLock = MyInfo.Level < UnlockLevel; 
            if (IsInLevelLock)
            {
                IsInLevelLock = UnlockState == SeaUnlockState.Lock;
            }

            PresecuredInfo.Update(Curr / (float)All * 100);
        }

        public void UpdateStep(int step)
        {
            this.step = step;
        }

        public bool Exists(SeaItemType type, int id)
        {
            return ItemInfoDict.ContainsKey(GetItemKey(type, id));
        }

        public void UpdateItems(SeaItemListSeaData seaData, SeaItemListItemsData itemsData, MyOceanBook oceanBook)
        {
            manageableItemInfoList.Clear();
            ItemInfoDict.Clear();
            ManageableItemCount = 0;
            SwimmerItemCount = 0;
            for (int i = 0; i < itemsData.ids.Length; i++)
            {
                SeaItemType type;
                Enum.TryParse(itemsData.types[i], out type);
                int id = itemsData.ids[i];
                int count = itemsData.cnts[i];
                int happiness = oceanBook.GetBookInfo(type, id).Point;
                SeaItemInfo info = new SeaItemInfo(type, id, count, happiness);
                manageableItemInfoList.Add(info);
                ItemInfoDict.Add(GetItemKey(type, id), info);

                ManageableItemCount += count;
                if (type == SeaItemType.s)
                {
                    SwimmerItemCount += count;
                }
            }

            MaxCapacity = seaData.capa;
        }

        private string GetItemKey(SeaItemType type, int id)
        {
            // 예시 : t1, f20, s3, ...
            return StringMaker.New()
                              .Append(type.ToString())
                              .Append(id.ToString())
                              .Build();
        }

        public SeaItemInfo GetManageableItemInfo(int index)
        {
            if (index < 0 || index >= manageableItemInfoList.Count)
            {
                return null;
            }

            return manageableItemInfoList[index];
        }

        public int GetManageableItemCount(SeaItemType type, int id)
        {
            int result = 0;
            string itemKey = GetItemKey(type, id);
            if (ItemInfoDict.ContainsKey(itemKey) == true)
            {
                result = ItemInfoDict[itemKey].Count;
            }
            return result;
        }
    }

    public struct SeaItemDifference
    {
        public SeaItemType type;
        public int id;
        public int count;

        public SeaItemDifference(SeaItemType type, int id, int count)
        {
            this.type = type;
            this.id = id;
            this.count = count;
        }
    }

    public class SeaItemInfo
    {
        public SeaItemType Type { get; private set; }
        public int ID { get; private set; }
        public int Count { get; private set; }
        public int Happiness { get; private set; }
        public bool IsNew { get; private set; }

        public SeaItemInfo(SeaItemType type, int id, int count, int happiness, bool isNew = false)
        {
            Type = type;
            ID = id;
            Count = count;
            Happiness = happiness;
            IsNew = isNew;
        }

        public void AddCount(int value)
        {
            Count += value;
        }

        public void UpdateNew(bool isNew)
        {
            IsNew = isNew;
        }
    }
}