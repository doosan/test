using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Underc.User
{
    public enum PopupInPending
    {
        None,
        GrowFish,
        GrowSwimmer,
        Manage,
        Bonus
    }

    public sealed class MyOcean : IDisposable
    {
        public delegate void SeaDelegate(int id, string seaName, int star);
        public delegate void SeaUnlockDelegate(int id);
        public delegate void SeaStarDeleate(int star, long current);

        public event SeaDelegate OnCurrentSeaChanged;
        public event SeaStarDeleate OnSeaStarChanged;

        public static readonly int MAX_STARS                                    = 3;

        private const string KEY_VISIT                                          = "sea_visit";
        private const string KEY_LATEST_UNLOCKED_SEA                            = "k_lul_sea";

        // 현재 선택된 바다 ID
        public int CurrentSeaID { get; private set; }
        public string CurrentSeaName { get; private set; }
        public int CurrentStar
        {
            get => GetCurrentSea().Star;
        }
        public long CurrentFishCount 
        { 
            get; 
            private set; 
        }

        /// 스토리가 완료되지 않은 첫번째 바다
        public int LatestSeaID 
        {
            get; 
            private set;
        }
        /// 레벨락이 걸려 있는 첫번째 바다
        public int PresecuredSeaID
        { 
            get; 
            private set; 
        }
        public long MaxCapacity { get; private set; }
        public int SeaUnlockLevel{ get; private set;}
        public bool IsSeaUnlocked => SeaUnlockLevel <= MyInfo.Level;
        public MyOceanBook Book { get; }

        public MySeaStory CurrentSeaStory{get; private set;}

        private PopupInPending popupInPending;

        public bool IsFirstVisitToCurrentSea
        {
            get
            {
                return !GetVisitSeaList().Contains(CurrentSeaID);
            }
            set
            {
                var visitList = GetVisitSeaList();
                if (visitList.Contains(CurrentSeaID))
                {
                    if (value)
                    {
                        visitList.Remove(CurrentSeaID);
                    }
                    else
                    {
                        return;
                    }
                }
                else
                {
                    if (!value)
                    {
                        visitList.Add(CurrentSeaID);
                    }
                    else
                    {
                        return;
                    }
                }

                var values = string.Join(",", visitList);
                UndercPrefs.SetRemoteValue(key: KEY_VISIT, value: values, allowEmptyValue: true);
            }
        }
 
        public MySea LatestComingSea
        {
            get;
            private set;
        }

        public MyInventory Inventory { get; private set; }

        private List<MySea> seaList;
        private Dictionary<string, List<FlockLocationInfo>> latestFlockLocations;

        /// 물고기 개수 변화량 체크
        public MySeaItemDiff SeaItemDiff;
        public MySeaItemSync SeaItemSync;

        public MyOcean()
        {
            Inventory = new MyInventory();
            seaList = new List<MySea>();
            Book = new MyOceanBook();

            SeaItemDiff = new MySeaItemDiff();
            SeaItemSync = new MySeaItemSync();

            CurrentSeaStory = new MySeaStory();
        }

        public void ClearSeaVisit()
        {
            UndercPrefs.SetRemoteValue(key: KEY_VISIT, value: "", allowEmptyValue: true);
        }

        public void Dispose()
        {

        }

        public void SetPopupInPending(PopupInPending popupInPending)
        {
            this.popupInPending = popupInPending;
        }

        public PopupInPending ConsumePopupInPending()
        {
            PopupInPending result = popupInPending;
            popupInPending = PopupInPending.None;
            return result;
        }

        private List<int> GetVisitSeaList()
        {
            var values = UndercPrefs.GetRemoteValue(KEY_VISIT, null);
            List<int> visitList = new List<int>();

            if (!string.IsNullOrEmpty(values))
            {
                visitList.AddRange(values.Split(',').Select(Int32.Parse).ToList());
            }

            return visitList;
        }

        public bool ContainsVisitSea(int id)
        {
            return GetVisitSeaList().Contains(id);
        }

        public int GetSeaCount()
        {
            return seaList.Count;
        }

        public MySea GetCurrentSea()
        {
            return GetSea(CurrentSeaID);
        }
        public MySea GetLatestSea()
        {
            MySea sea = GetSea(LatestSeaID);
            if (sea == null
                && LatestSeaID == LatestComingSea.ID)
            {
                sea = LatestComingSea;
            }

            return sea;
        }

        public MySea GetSea(int id)
        {
            for (int i = 0; i < seaList.Count; i++)
            {
                MySea sea = seaList[i];
                if (sea.ID == id)
                {
                    return sea;
                }
            }

            return null;
        }

        public void SaveFlockLocations(Dictionary<string, List<FlockLocationInfo>> flockLocationsByID)
        {
            this.latestFlockLocations = flockLocationsByID;
        }

        public Dictionary<string, List<FlockLocationInfo>> ComsumeFlockLocations()
        {
            var result = latestFlockLocations;
            latestFlockLocations = null;
            return result;
        }

        public MySea GetSeaAtIndex(int index)
        {
            if (index >= seaList.Count && index < 0)
            {
                return null;
            }

            return seaList[index];
        }

        public int GetAllStars()
        {
            int stars = 0;

            for (int i = 0; i < seaList.Count; i++)
            {
                var sea = seaList[i];
                stars += sea.Star;
            }

            return stars;
        }
        
        public void WriteLatestUnlockedSeaID(int seaID)
        {
            UndercPrefs.SetRemoteValue(KEY_LATEST_UNLOCKED_SEA, seaID.ToString());
        }

        public int ReadLatestUnlockedSeaID()
        {
            return int.Parse(UndercPrefs.GetRemoteValue(KEY_LATEST_UNLOCKED_SEA, "0"));
        }

        public void UpdateSeaID(int seaID)
        {
            CurrentSeaID = seaID;
        }

        public void UpdateSeaItemList(int seaID, SeaItemListData data)
        {
            GetSea(seaID).UpdateItems(data.sea, data.placed, Book);
            if (data.unplaced.ids != null)
            {
                Inventory.UpdateSeaItems(data.unplaced, Book);
            }

            var sea = GetSea(CurrentSeaID);
            if (sea != null)
            {
                CurrentFishCount = sea.ManageableItemCount;
                MaxCapacity = sea.MaxCapacity;
            }
        }

        public void UpdateSeaMine(SeaMineData data)
        {
            CurrentSeaID = data.sea;
            CurrentSeaName = String.Format(System.Globalization.CultureInfo.InvariantCulture, "SEA STORY {0}", CurrentSeaID.ToString());
            CurrentFishCount = data.item_cnt;
            MaxCapacity = data.capa;
            SeaUnlockLevel = data.unlock;

            DispatchCurrentSea();
        }

        public void UpdateCapacityOffset(long currentOffset, long maxOffset)
        {
            CurrentFishCount += currentOffset;
            MaxCapacity += maxOffset;
        }

        public void UpdateSeaList(SeaData[] datas)
        {
            LatestSeaID = -1;
            PresecuredSeaID = -1;

            for (int i = 0; i < datas.Length; i++)
            {
                SeaData data = datas[i];
                MySea sea = GetSea(data.sea);
                if (sea == null)
                {
                    sea = new MySea();
                    seaList.Add(sea);
                }

                sea.Update(data);

                if (LatestSeaID == -1
                    && sea.IsInProgress)
                {
                    LatestSeaID = sea.ID;
                }
                
                if (PresecuredSeaID == -1
                    && sea.IsInLevelLock)
                {
                    PresecuredSeaID = sea.ID;
                }
            }

            if (LatestComingSea != null)
            {
                if (LatestSeaID == -1)
                {
                    LatestSeaID = LatestComingSea.ID;
                }

                if (PresecuredSeaID == -1)
                {
                    PresecuredSeaID = LatestComingSea.ID;
                }
            }

            Debug.Log("==== LatestSeaID : " + LatestSeaID + ", " + PresecuredSeaID);
        }

        public void UpdateCapacity(long capacity, long maxCapacity)
        {
            UpdateCapacityOffset(capacity - CurrentFishCount, maxCapacity - MaxCapacity);
        }

        public int CanEnterThisSea(int seaID)
        {
            int refusalType = 0;

            int  seaCount = GetSeaCount();
            for (int i = 0; i < seaCount; i++)
            {
                var sea = MyInfo.Ocean.GetSeaAtIndex(i);
                if (sea.ID <= seaID)        /// 1-1. 현재 바다 ID 이하 모든 바다를 체크
                {
                    if (sea.IsInLevelLock)  /// 1-2. 레벨이 잠겨 있는지
                    {
                        refusalType = 1;
                        break;
                    }
                }
                else
                {
                    break;
                }
            }

            if (refusalType == 0)
            {
                for (int i = 0; i < seaCount; i++)
                {
                    var sea = MyInfo.Ocean.GetSeaAtIndex(i);
                    if (sea.ID < seaID)         /// 2-1. 현재 바다 ID 미만 모든 바다를 체크
                    {
                        if (sea.IsInProgress)   /// 2-2. 하나라도 스토리가 진행 중이면 실패
                        {
                            refusalType = 2;
                            break;
                        }
                    }
                    else
                    {
                        break;
                    }
                }
            }

            return refusalType;
        }

        public void UpdateSeaComing(SeaData data)
        {
            if (LatestComingSea == null)
            {
                LatestComingSea = new MySea();
            }
            LatestComingSea.Update(data);
        }

        private void DispatchCurrentSea()
        {
            if (OnCurrentSeaChanged != null)
            {
                OnCurrentSeaChanged.Invoke(CurrentSeaID, CurrentSeaName, CurrentStar);
            }
        }
    }

    public class FlockLocationInfo
    {
        public Vector3 position;
        public Quaternion rotation;

        public FlockLocationInfo(Vector3 position, Quaternion rotation)
        {
            this.position = position;
            this.rotation = rotation;
        }
    }
}