using System;
using System.Collections.Generic;
using System.Linq;

namespace Underc.User
{
    public sealed class MyInventory
    {
        public int ManageableItemInfoCount 
        {
            get => manageableItemInfos.Count;
        }
        public long ManageableItemCount
        {
            get; 
            private set;
        }
        public int SwimmerItemCount 
        { 
            get; 
            private set; 
        }

        public bool HasRecentlyBought
        {
            get
            {
                bool result = hasRecentlyBought;
                hasRecentlyBought = false;
                return result;
            }
            set
            {
                hasRecentlyBought = value;
            }
        }
        private bool hasRecentlyBought;

        private SeaItemInfo emptyInfo = new SeaItemInfo(type: SeaItemType.n, 
                                                        id: -1, 
                                                        count: 0,
                                                        happiness: 0);
        private List<SeaItemInfo> manageableItemInfos = new List<SeaItemInfo>();

        public SeaItemInfo GetItemInfo(int index)
        {
            if (index < 0 || index >= manageableItemInfos.Count)
            {
                return null;
            }

            return manageableItemInfos[index];
        }

        public SeaItemInfo GetSeaItemInfoByID(int id)
        {
            SeaItemInfo found = emptyInfo;
            for (int i = 0; i < manageableItemInfos.Count; i++)
            {
                SeaItemInfo finding = manageableItemInfos[i];
                if (finding.ID == id)
                {
                    found = finding;
                    break;
                }
            }

            return found;
        }

        public void UpdateSeaItems(SeaItemListItemsData items, MyOceanBook oceanBook)
        {
            manageableItemInfos.Clear();
            ManageableItemCount = 0;
            SwimmerItemCount = 0;
            for (int i = 0; i < items.ids.Length; i++)
            {
                SeaItemType type;
                Enum.TryParse(items.types[i], out type);
                int id = items.ids[i];
                int count = items.cnts[i];
                bool isNew = items.news[i] == 1;
                int happiness = oceanBook.GetBookInfo(type, id).Point;
                manageableItemInfos.Add(new SeaItemInfo(type, id, count, happiness, isNew));

                ManageableItemCount += count;
                if (type == SeaItemType.s)
                {
                    SwimmerItemCount += count;
                }
            }
        }

        public void ConsumeSeaItemNews()
        {
            for (int i = 0; i < manageableItemInfos.Count; i++)
            {
                SeaItemInfo target = manageableItemInfos[i];
                target.UpdateNew(false);
            }
        }
    }
}
