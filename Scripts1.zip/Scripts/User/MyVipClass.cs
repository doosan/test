using Gaga;
using Gaga.Util;
using System;
using System.Collections.Generic;
using System.Globalization;

namespace Underc.User
{
    public enum VipClassType
    {
        none,
        bronze = 1,
        silver = 2,
        gold = 3,
        platinum = 4,
        diamond = 5,
        purple_diamond = 6,
        black_diamond = 7,
    }

    public enum VipBenefitTableItem
    {
        CoinPackages,
        VipPoints,
        DailyBonus,
        HugeBonus,
        DailyQuest,
        Harvest,
        MissionPass,
        Chest,
        Sea,
        SharePostGift,
        FanPageGift,
    }

    public enum VipBenefitTableItemType
    {
        none,
        mul,
        per,
    }

    public struct VipBenefitTableItemInfo
    {
        public float bonusRate;
        public VipBenefitTableItemType type;

        public VipBenefitTableItemInfo(float bonusRate, string typeData)
        {
            Enum.TryParse(typeData, out type);
            this.bonusRate = bonusRate;
        }

        public override string ToString()
        {
            string result;
            if (type == VipBenefitTableItemType.mul)
            {
                result = StringMaker.New()
                                    .Append("X")
                                    .Append(bonusRate.ToString())
                                    .Build();
            }
            else
            {
                result = StringMaker.New()
                                    .Append("+")
                                    .Append((Convert.ToInt32(100 * bonusRate) - 100).ToString())
                                    .Append("%")
                                    .Build();
            }

            return result;
        }
    }

    public class VipResetInfo
    {
        public int rangeIndex;
        public float coe;
        public int beginMonth;
        public int endMonth;
        public long point;

        public void Update(VipResetData data)
        {
            rangeIndex = data.range_index;
            coe = data.coe;
            beginMonth = data.begin_month;
            endMonth = data.end_month;
            point = data.point;
        }
    }

    public class VipBenefitTableInfo
    {
        public int vipClass;
        public VipBenefitTableItemInfo coinPackages;
        public VipBenefitTableItemInfo vipPoints;
        public VipBenefitTableItemInfo dailyBonus;
        public VipBenefitTableItemInfo hugeBonus;
        public VipBenefitTableItemInfo dailyQuest;
        public VipBenefitTableItemInfo harvest;
        public VipBenefitTableItemInfo missionPass;
        public VipBenefitTableItemInfo chest;
        public VipBenefitTableItemInfo sea;
        public VipBenefitTableItemInfo sharePostGift;
        public VipBenefitTableItemInfo fanPageGift;
        public bool vipSupport;

        public Dictionary<VipBenefitTableItem, VipBenefitTableItemInfo> tableInfoDict;

        public VipBenefitTableItemInfo GetItemInfo(VipBenefitTableItem item)
        {
            return tableInfoDict[item];
        }

        public void SetItemInfo(VipBenefitTableItem item, VipBenefitTableItemInfo tableItemInfo)
        {
            tableInfoDict[item] = tableItemInfo;
        }
        
        public void Update(VipBenefitTableData tableData, VipBenefitTableTypeData tableTypeData)
        {
            vipClass = tableData.vip_class;
            coinPackages = new VipBenefitTableItemInfo(tableData.coin_packages, tableTypeData.shop_type);
            vipPoints = new VipBenefitTableItemInfo(tableData.vip_points, tableTypeData.vip_type);
            dailyBonus = new VipBenefitTableItemInfo(tableData.daily_bonus, tableTypeData.daily_type);
            hugeBonus = new VipBenefitTableItemInfo(tableData.huge_bonus, tableTypeData.congrats_type);
            dailyQuest = new VipBenefitTableItemInfo(tableData.daily_quest, tableTypeData.daily_quest_type);
            harvest = new VipBenefitTableItemInfo(tableData.harvest, tableTypeData.harvest_type);
            missionPass = new VipBenefitTableItemInfo(tableData.mission_pass, tableTypeData.mission_pass_type);
            chest = new VipBenefitTableItemInfo(tableData.chest, tableTypeData.chest_type);
            sea = new VipBenefitTableItemInfo(tableData.sea, tableTypeData.sea_type);
            sharePostGift = new VipBenefitTableItemInfo(tableData.share_post_gift, tableTypeData.share_post_type);
            fanPageGift = new VipBenefitTableItemInfo(tableData.fan_page_gift, tableTypeData.fan_page_type);
            vipSupport = tableData.vip_support;

            if (tableInfoDict == null)
            {
                tableInfoDict = new Dictionary<VipBenefitTableItem, VipBenefitTableItemInfo>();
            }
            tableInfoDict.Clear();
            tableInfoDict.Add(VipBenefitTableItem.CoinPackages, coinPackages);
            tableInfoDict.Add(VipBenefitTableItem.VipPoints, vipPoints);
            tableInfoDict.Add(VipBenefitTableItem.DailyBonus, dailyBonus);
            tableInfoDict.Add(VipBenefitTableItem.HugeBonus, hugeBonus);
            tableInfoDict.Add(VipBenefitTableItem.DailyQuest, dailyQuest);
            tableInfoDict.Add(VipBenefitTableItem.Harvest, harvest);
            tableInfoDict.Add(VipBenefitTableItem.MissionPass, missionPass);
            tableInfoDict.Add(VipBenefitTableItem.Chest, chest);
            tableInfoDict.Add(VipBenefitTableItem.Sea, sea);
            tableInfoDict.Add(VipBenefitTableItem.SharePostGift, sharePostGift);
            tableInfoDict.Add(VipBenefitTableItem.FanPageGift, fanPageGift);
        }
    }

    public class MyVipClass : IDisposable
    {
        public DateTime Now
        { 
            get
            {
                DateTime cstTime = AppService.NowDate(GlobalTime.Instance.GetTimeStamp());
                if (TestConfig.NowMonthOffset > 0)
                {
                    cstTime = cstTime.AddMonths(TestConfig.NowMonthOffset);
                }
                if (TestConfig.NowDayOffset > 0)
                {
                    cstTime = cstTime.AddDays(TestConfig.NowDayOffset);
                }

                return cstTime;
            }
        }
        
        public int Index
        {
            get;
            private set;
        }

        public VipClassType Type
        {
            get;
            private set;
        }
        public VipClassType TypeBefore
        {
            get;
            private set;
        }
        private bool isLevelUp;

        public string Name
        {
            get;
            private set;
        }

        public long Xp
        {
            get;
            private set;
        }

        public long NextXp
        {
            get;
            private set;
        }

        public int VipBenefitTableInfoCount
        {
            get => vipBenefitTableInfos.Count;
        }
        private List<VipBenefitTableInfo> vipBenefitTableInfos;

        private List<VipResetInfo> vipResetInfos;

        public long ResetTimeStamp
        {
            get;
            private set;
        }

        private bool isReseted;

        public MyVipClass()
        {
            vipBenefitTableInfos = new List<VipBenefitTableInfo>();
            vipResetInfos = new List<VipResetInfo>();
        }

        public void Dispose()
        {

        }

        public VipBenefitTableItemInfo GetCurrent_VipBenefitTableItemInfo(VipBenefitTableItem item)
        {
            VipBenefitTableInfo currentVipBenefitInfo = GetVipBenefitTableInfo(Index);
            return currentVipBenefitInfo.GetItemInfo(item);
        }

        public VipBenefitTableInfo GetVipBenefitTableInfo(int index)
        {
            VipBenefitTableInfo result = null;
            if (index < vipBenefitTableInfos.Count)
            {
                result = vipBenefitTableInfos[index];
            }
            return result;
        }

        public VipResetInfo GetVipResetInfo(int index)
        {
            VipResetInfo result = null;
            if (index < vipResetInfos.Count)
            {
                result = vipResetInfos[index];
            }
            return result;
        }

        public bool ConsumeLevelUp()
        {
            bool result = isLevelUp;
            isLevelUp = false;
            return result;
        }

        public void Update(int vipClass)
        {
            if (vipClass > 0)
            {
                Index = vipClass - 1;
                TypeBefore = Type;
                Type = (VipClassType)vipClass;
                if (TypeBefore == VipClassType.none
                    || TypeBefore > Type)
                {
                    TypeBefore = Type;
                }
                if (isLevelUp == false)
                {
                    isLevelUp = TypeBefore != VipClassType.none
                                && (int)TypeBefore < (int)Type;
                }

                string[] names = Type.ToString().Split('_');
                for (int i = 0; i < names.Length; i++)
                {
                    names[i] = CultureInfo.InvariantCulture.TextInfo.ToTitleCase(names[i]);
                }

                Name = string.Join(" ", names);
            }
        }

        public void Update(int vipClass, long vipPoint)
        {
            Update(vipClass);
            Xp = vipPoint;
        }

        public void Update(VipBenefitTableItem tableItem, VipBenefitTableItemData tableItemData)
        {
            VipBenefitTableInfo tableInfo = GetVipBenefitTableInfo(Index);
            tableInfo.SetItemInfo(tableItem, new VipBenefitTableItemInfo(tableItemData.bonus_rate, tableItemData.vip_rate_type));
        }

        public void UpdateResetTimeStamp(long value)
        {
            ResetTimeStamp = value;
        }

        public void UpdateIsReseted(bool value)
        {
            isReseted = value;
        }

        public bool ConsumeIsReseted()
        {
            bool result = isReseted;
            isReseted = false;
            return result;
        }

        public void Update(VipData vipData, VipResetData[] vipResetData)
        {
            Update(vipData.vip_class);
            Xp = vipData.xp;
            NextXp = vipData.next_xp;

            if (vipResetData != null
                && vipResetData.Length > 0)
            {
                vipResetInfos.Clear();
                foreach (VipResetData data in vipResetData)
                {
                    var info = new VipResetInfo();
                    info.Update(data);

                    vipResetInfos.Add(info);
                }
            }
        }

        public void Update(VipData vipData,
                           VipResetData[] vipResetData,
                           VipBenefitTableData[] vipBenefitTableData, 
                           VipBenefitTableTypeData tableTypeData)
        {
            Update(vipData, vipResetData);

            vipBenefitTableInfos.Clear();
            if (vipBenefitTableData != null)
            {
                foreach (VipBenefitTableData tableData in vipBenefitTableData)
                {
                    var info = new VipBenefitTableInfo();
                    info.Update(tableData, tableTypeData);

                    vipBenefitTableInfos.Add(info);
                }
            }
        }
    }
}