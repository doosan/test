using System;
using System.Collections.Generic;
using System.Linq;

namespace Underc.User
{
    public static class RewardInfoOrder
    {
        public static void SortByRewardOrder(this List<RewardInfo> rewardInfos)
        {
            rewardInfos.Sort((RewardInfo a, RewardInfo b) =>
            {
                int result = 0;
                // A-1. 첫 번째 조건 skinIndex
                int aOrderValue = a.skinIndex;
                int bOrderValue = b.skinIndex;
                result = aOrderValue == bOrderValue ? 0 :
                         aOrderValue > bOrderValue ? -1 :
                         1; // A-2. 큰 값이 왼쪽으로

                if (result == 0)
                {
                    // B-1. 두 번째 조건: RewardOrder
                    string aName = a.type.ToString();
                    Enum.TryParse(aName, out RewardOrder aOrder);
                    aOrderValue = (int)aOrder;

                    string bName = b.type.ToString();
                    Enum.TryParse(bName, out RewardOrder bOrder);
                    bOrderValue = (int)bOrder;

                    result = aOrderValue == bOrderValue ? 0 :
                             aOrderValue > bOrderValue ? 1 :
                             -1; // B-2. 큰 값이 오른쪽으로
                }

                return result;
            });
        }
    }
}