using Gaga;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Underc.User
{
    public class MyCasinoBonus : IDisposable
    {
        public int Pickax
        {
            get;
            private set;
        }

        #region 황금 상자
        public event Action<bool> OnGoldenChestReady;
        public bool IsGoldenChestReady
        {
            get
            {
                return isGoldenChestReady;
            }
            set
            {
                if (isGoldenChestReady != value)
                {
                    isGoldenChestReady = value;
                    OnGoldenChestReady?.Invoke(isGoldenChestReady);
                }
            }
        }
        private bool isGoldenChestReady;
        /// 
        public long GoldenFreeRemainingSec 
        { 
            get; 
            private set; 
        } = -1;
        private long goldenFreeTs;
        /// 
        public long GoldenKey 
        { 
            get; 
            private set; 
        }
        /// 
        public int GoldenUnlock 
        { 
            get; 
            set; 
        }
        #endregion

        #region 흑요석 상자
        public event Action<bool> OnObsidianChestReady;
        public bool IsObsidianChestReady
        {
            get
            {
                return isObsidianChestReady;
            }
            set
            {
                if (isObsidianChestReady != value)
                {
                    isObsidianChestReady = value;
                    OnObsidianChestReady?.Invoke(isObsidianChestReady);
                }
            }
        }
        private bool isObsidianChestReady;
        /// 
        public long ObsidianFreeRemainingSec 
        { 
            get; 
            private set; 
        } = -1;
        private long obsidianFreeTs;
        /// 
        public long ObsidianKey 
        { 
            get; 
            private set; 
        }
        /// 
        public int ObsidianBigTimes 
        { 
            get; 
            private set; 
        }
        /// 
        public int ObsidianUnlock 
        { 
            get; 
            set; 
        }
        #endregion

        public int FishReward 
        { 
            get; 
            private set; 
        }

        public event Action<bool> OnDailyBonusReady;
        public bool IsDailyBonusReady
        {
            get
            {
                return dailyBonusReady;
            }
            set
            {
                if (dailyBonusReady == value)
                {
                    return;
                }

                dailyBonusReady = value;
                OnDailyBonusReady?.Invoke(dailyBonusReady);
            }
        }
        private bool dailyBonusReady;
        public long DailyBonusRemainingSec { get; private set; } = -1;
        public bool dailyBonusAvailable;
        private long dailyBonusTs = -1;

        public event Action<bool> OnFreeBonusReady;
        public bool IsFreeBonusReady
        {
            get
            {
                return freeBonusReady;
            }
            set
            {
                if (freeBonusReady != value)
                {
                    freeBonusReady = value;
                    OnFreeBonusReady?.Invoke(freeBonusReady);
                }
            }
        }

        private bool freeBonusReady;
        public long FreeBonusRemainingSec { get; private set; } = -1;
        public long FreeBonusTotalSec { get; private set;}
        public long FreeBonusStartTimeStamp { get; private set;}
        private long freeBonusTs = -1;
        public int FreeBonusIndex{get; private set;}
        public long FreeBonusCoin{get; private set;}

        public bool HasWelcomeBackPush
        { 
            get
            {
                return welcomeBackPushes.Count > 0;
            }
        }
        private HashSet<int> timeUpdateWaiters;
        private List<RewardInfo> welcomeBackPushes;
        private GlobalTime globalTime;

        public MyCasinoBonus()
        {
            globalTime = GlobalTime.Instance;
            globalTime.onUpdate += UpdateRemainingSec;

            timeUpdateWaiters = new HashSet<int>();
            welcomeBackPushes = new List<RewardInfo>();
        }

        public void Dispose()
        {
            globalTime.onUpdate -= UpdateRemainingSec;
        }

        public List<RewardInfo> ConsumeWelcomeBackPushes()
        {
            List<RewardInfo> result = welcomeBackPushes;
            welcomeBackPushes = new List<RewardInfo>();
            return result;
        }

        public IEnumerator WaitForTimeUpdate(MonoBehaviour host)
        {
            int instanceID = host.GetInstanceID();
            if (timeUpdateWaiters.Contains(instanceID) == false)
            {
                timeUpdateWaiters.Add(instanceID);
            }

            while (timeUpdateWaiters.Contains(instanceID) == true)
            {
                yield return null;
            }
        }

        private void UpdateRemainingSec(long serverTs)
        {
            if (goldenFreeTs > 0)
            {
                GoldenFreeRemainingSec = globalTime.SecondDiff(goldenFreeTs);
                CheckGoldenChestReady();
            }

            if (obsidianFreeTs > 0)
            {
                ObsidianFreeRemainingSec = globalTime.SecondDiff(obsidianFreeTs);
                CheckObsidianChestReady();
            }

            if (dailyBonusTs > 0)
            {
                DailyBonusRemainingSec = globalTime.SecondDiff(dailyBonusTs);
                CheckDailyBonusReady();
            }

            if (freeBonusTs > 0)
            {
                FreeBonusRemainingSec = globalTime.SecondDiff(freeBonusTs);
                CheckFreeBonusReady();
            }

            timeUpdateWaiters.Clear();
        }

        public void Update(CasinoBonusData data)
        {
            if (data.golden != null)
            {
                goldenFreeTs = data.golden.free_ts;
                GoldenKey = data.golden.key;
                GoldenUnlock = data.golden.unlock;
            }

            if (data.obsidian != null)
            {
                obsidianFreeTs = data.obsidian.free_ts;
                ObsidianBigTimes = data.obsidian.times;
                ObsidianKey = data.obsidian.key;
                ObsidianUnlock = data.obsidian.unlock;
            }

            if (data.daily != null)
            {
                dailyBonusAvailable = data.daily.available == 1;
                dailyBonusTs = data.daily.claim_ts;
            }

            if (data.free != null)
            {
                freeBonusTs = data.free.end_ts;
                FreeBonusStartTimeStamp = data.free.start_ts;
                FreeBonusTotalSec = data.free.end_ts - data.free.start_ts;
                FreeBonusIndex = data.free.index;
                FreeBonusCoin = data.free.coin;
            }

            UpdateRemainingSec(globalTime.GetTimeStamp());
        }

#if GGDEV
        private List<Func<RewardInfo>> dummyPushMakers;
        private List<RewardInfo> dummyWelcomeBackPushes;
        private List<RewardInfo> DummyWelcomeBackPushes
        {
            get 
            { 
                if (dummyWelcomeBackPushes == null)
                {
                    dummyWelcomeBackPushes = new List<RewardInfo>();
                }
                return dummyWelcomeBackPushes;
            }
        }

        public void SetDummyWelcomeBackPushes(int count)
        {
            if (dummyPushMakers == null)
            {
                dummyPushMakers = new List<Func<RewardInfo>>();
                dummyPushMakers.Add(() => new RewardInfo(RewardType.coin, UnityEngine.Random.Range(10000, 1000001)));
                dummyPushMakers.Add(() => new RewardInfo(RewardType.pearl, UnityEngine.Random.Range(10000, 1000001)));
                dummyPushMakers.Add(() => new RewardInfo(RewardType.ticket, UnityEngine.Random.Range(10000, 1000001)));
                dummyPushMakers.Add(() => new RewardInfo(RewardType.golden, UnityEngine.Random.Range(1, 4)));
                dummyPushMakers.Add(() => new RewardInfo(RewardType.obsidian, UnityEngine.Random.Range(1, 4)));
                dummyPushMakers.Add(() => new RewardInfo(RewardType.xp_booster, UnityEngine.Random.Range(60, 2401)));
                dummyPushMakers.Add(() => new RewardInfo(RewardType.pearl_booster, UnityEngine.Random.Range(60, 2401)));
            }

            DummyWelcomeBackPushes.Clear();
            for (int i = 0; i < count; i++)
            {
                RewardInfo dummyPush = dummyPushMakers[UnityEngine.Random.Range(0, dummyPushMakers.Count)]();
                DummyWelcomeBackPushes.Add(dummyPush);
            }
        }
#endif

        public void Update(int[] welcomeBackPushType, long[] welcomeBackPushValue)
        {
            welcomeBackPushes.Clear();

#if GGDEV
            if (DummyWelcomeBackPushes.Count > 0)
            {
                welcomeBackPushes.AddRange(DummyWelcomeBackPushes);
            }
#endif

            if (welcomeBackPushType != null
                && welcomeBackPushValue != null)
            {
                for (int typeIndex = 0; typeIndex < welcomeBackPushType.Length; typeIndex++)
                {
                    int type = welcomeBackPushType[typeIndex];
                    long value = 0;
                    if (typeIndex < welcomeBackPushValue.Length)
                    {
                        if (Enum.IsDefined(typeof(RewardType), type))
                        {
                            RewardType rewardType = (RewardType)type;
                            value = welcomeBackPushValue[typeIndex];

                            welcomeBackPushes.Add(new RewardInfo(rewardType, value));
                        }
                        else
                        {
                            Debug.LogWarning("==== RewardType 에 정의되어 있지 않습니다 : " + type);
                        }
                    }
                }
            }
        }

        private void CheckGoldenChestReady()
        {
            IsGoldenChestReady = GoldenKey > 0 || GoldenFreeRemainingSec == 0;
        }

        private void CheckObsidianChestReady()
        {
            IsObsidianChestReady = ObsidianKey > 0 || ObsidianFreeRemainingSec == 0;
        }

        private void CheckFreeBonusReady()
        {
            IsFreeBonusReady = FreeBonusRemainingSec == 0;
        }

        private void CheckDailyBonusReady()
        {
            IsDailyBonusReady = DailyBonusRemainingSec == 0 && dailyBonusAvailable;
        }

        public void UpdateGoldenKey(long value)
        {
            GoldenKey = value;
            CheckGoldenChestReady();
        }

        public void UpdateObsidianKey(long value)
        {
            ObsidianKey = value;
            CheckObsidianChestReady();
        }

        public void Update(GoldenRewardData rewardData)
        {
            FishReward = rewardData.fish;
            goldenFreeTs = rewardData.free_ts;
            GoldenKey = rewardData.key;
            CheckGoldenChestReady();

            UpdateRemainingSec(globalTime.GetTimeStamp());
        }

        public void Update(ObsidianRewardData rewardData)
        {
            FishReward = rewardData.fish;
            obsidianFreeTs = rewardData.free_ts;
            ObsidianBigTimes = rewardData.times;
            ObsidianKey = rewardData.key;
            CheckObsidianChestReady();

            UpdateRemainingSec(globalTime.GetTimeStamp());
        }

        public void Update(FreeBonusData data)
        {
            freeBonusTs = data.end_ts;
            FreeBonusStartTimeStamp = data.start_ts;
            FreeBonusTotalSec = data.end_ts - data.start_ts;
            FreeBonusIndex = data.index;
            FreeBonusCoin = data.coin;
            CheckFreeBonusReady();

            UpdateRemainingSec(globalTime.GetTimeStamp());
        }
    }
}