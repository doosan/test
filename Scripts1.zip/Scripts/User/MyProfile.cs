using System;
using Underc.Platform;

namespace Underc.User
{
    public class FacebookProfileInfo
    {
        public string nick;
        public string picUrl;

        public FacebookProfileInfo(string nick, string picUrl)
        {
            this.nick = nick;
            this.picUrl = picUrl;
        }

        public override string ToString()
        {
            return nick + ", " + picUrl;
        }
    }

    public class FacebookStateInfo
    {
        public bool isLoggedIn;
        public FBUser fbUser;

        public FacebookStateInfo()
        {
            Update(isLoggedIn: false, fbUser: null);
        }

        public void Update(bool isLoggedIn = false, FBUser fbUser = null)
        {
            Debug.Log($"==== FacebookStateInfo : {isLoggedIn}, {fbUser?.name}, {fbUser?.pic_url}");
            this.isLoggedIn = isLoggedIn;
            this.fbUser = fbUser;
        }
    }

    public sealed class MyProfile : IDisposable
    {
        private const string KEY_PIC_NUM = "k_pic_num";

        public event Action OnPicUpdated;

        public string Nick { get; private set; }
        public int PicNum { get; private set; }
        public string PicUrl { get; private set; }
        public int Level { get; private set; }
        public int Seas;
        public long MaxWin;
        public long TotWin;
        public long ClapSent;

        public string NickInSave { get; private set; }
        public int PicNumInSave { get; private set; }
        public string PicUrlInSave { get; private set; }
        public FacebookProfileInfo FacebookProfileInfoCache 
        { 
            get; 
            private set; 
        }
        public FacebookStateInfo FacebookStateInfo
        {
            get;
            private set;
        } = new FacebookStateInfo();

        public MyProfile() { }
        public void Dispose() { }

        public void Update(ProfileData data)
        {
            Nick = data.nick;
            PicNum = data.pic_num;
            PicUrl = data.pic_url;
            Level = data.level;
            Seas = data.seas;
            MaxWin = data.max_win;
            TotWin = data.tot_win;
            ClapSent = data.clap_sent;
        }

        public void Update(string nick, int picNum, string picUrl)
        {
            Nick = nick;
            PicNum = picNum;
            PicUrl = picUrl;

            SavePicNum(PicNum);

            OnPicUpdated?.Invoke();
        }

        
        public void CacheFacebookProfileInfo(FBUser fbUser)
        {
            FacebookProfileInfoCache = new FacebookProfileInfo(fbUser.name, fbUser.pic_url);
        }

        public FacebookProfileInfo ConsumeFacebookProfileInfo()
        {
            FacebookProfileInfo result = FacebookProfileInfoCache;
            FacebookProfileInfoCache = null;
            return result;
        }

        public void Save(string nick, int picNum, string picUrl)
        {
            NickInSave = nick;
            PicNumInSave = picNum;
            PicUrlInSave = picUrl;

            SavePicNum(PicNumInSave);
        }

        public void SavePicNum(int picNum)
        {
            if (picNum > 0)
            {
                UndercPrefs.SetRemoteValue(KEY_PIC_NUM, picNum.ToString());
            }
        }

        public int LoadPicNum()
        {
            int picNum = PicNum;
            if (picNum <= 0)
            {
                picNum = int.Parse(UndercPrefs.GetRemoteValue(KEY_PIC_NUM, "0"));
            }
            if (picNum <= 0)
            {
                picNum = UnityEngine.Random.Range(1, ProfileIconSystem.Instance.AssetCount + 1);
            }

            return picNum;
        }
    }
}