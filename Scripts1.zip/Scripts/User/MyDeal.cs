﻿using System;
using System.Collections;
using System.Collections.Generic;
using Gaga;
using UnityEngine;

namespace Underc.User
{
    public class MyDeal : IDisposable
    {
        public event Action<MyDeal> onChange;
        public OfferInfo CurrentDeal { get; private set; }
        public bool HasDeal
        {
            get
            {
                return CurrentDeal != null;
            }
        }

        public long RemainingSec
        {
            get; private set;
        }

        public MyDeal()
        {
            GlobalTime.Instance.onUpdate += OnGlobalTimeUpdate;
        }

        public void Dispose()
        {
            GlobalTime.Instance.onUpdate -= OnGlobalTimeUpdate;
        }

        public void Update(OfferData data)
        {
            OfferInfo newInfo = null;

            if (data != null && data.IsValid)
            {
                newInfo = new OfferInfo(data);
            }

            if (CurrentDeal == newInfo)
            {
                return;
            }

            CurrentDeal = newInfo;

            if (HasDeal == false)
            {
                RemainingSec = 0;
            }
            else
            {
                RemainingSec = GlobalTime.Instance.SecondDiff(CurrentDeal.EndTs);
            }

            if (onChange != null)
            {
                onChange(this);
            }
        }

        private void OnGlobalTimeUpdate(long serverTs)
        {
            if (HasDeal == false)
            {
                return;
            }

            if (RemainingSec == 0)
            {
                Update(null);
                return;
            }

            RemainingSec = GlobalTime.Instance.SecondDiff(CurrentDeal.EndTs);
            if (onChange != null)
            {
                onChange(this);
            }
        }
    }
}