﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Underc.User
{
    public class MySpinQuest : IDisposable
    {
        public enum MissionType
        {
            None,
            Spins
        }

        public MissionType CurrentMission { get; private set; }

        public int Step { get; private set; }
        public long Current { get; private set; }
        public long Max { get; private set; }

        //rewards
        public long Coin { get; private set; }
        public long Pearl { get; private set; }
        public long Ticket { get; private set; }

        public long RewardCoin { get; private set; }
        public long RewardPearl { get; private set; }
        public long RewardTicket { get; private set; }

        public MissionType NextMission { get; private set; }
        public int NextStep { get; private set; }
        public long NextCoin { get; private set; }
        public long NextPearl { get; private set; }
        public long NextTicket { get; private set; }
        public long NextMax { get; private set; }

        public bool IsCompelte { get; private set; }

        public void Dispose() { }

        public bool HasQuest()
        {
            return CurrentMission != MissionType.None && Step > 0;
        }

        public void Update(SpinQuestData data)
        {
            if (data == null)
            {
                CurrentMission = MissionType.None;
            }
            else
            {
                CurrentMission = GetMissionType(data.mission);
                Current = data.curr;
                Max = data.goal;
                IsCompelte = Max > 0 ? Current == Max : false;
                Coin = data.reward_coin;
                Pearl = data.reward_pearl;
                Ticket = data.reward_ticket;
                Step = data.step;
            }
        }

        public void Update(SpinQuestCollectData data)
        {
            RewardCoin = data.reward_coin;
            RewardPearl = data.reward_pearl;
            RewardTicket = data.reward_ticket;

            CurrentMission = GetMissionType(data.next_mission);
            Current = 0;
            Max = data.next_goal;
            IsCompelte = false;
            Step = data.next_step;
            Coin = data.next_reward_coin;
            Pearl = data.next_reward_pearl;
            Ticket = data.next_reward_ticket;
        }

        public MissionType GetMissionType(string mission)
        {
            MissionType missionType = MissionType.None;

            if (mission == "spins")
            {
                missionType = MissionType.Spins;
            }

            return missionType;
        }

        public string GetMissionName(MissionType mission)
        {
            string rv = string.Empty;

            if (mission == MissionType.Spins)
            {
                rv = "SPINS";
            }
            else
            {
                rv = mission.ToString();
            }

            return rv;
        }

        public string GetToolTipText(MissionType mission)
        {
            string rv = string.Empty;

            if (mission == MissionType.Spins)
            {
                rv = "Spin <color=#ffff00>{0}</color> times\n& get rewards.";
            }
            else
            {
                rv = mission.ToString();
            }

            return rv;
        }
    }
}