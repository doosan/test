using Gaga.Util;
using System;
using System.Collections.Generic;

namespace Underc.User
{
    public sealed class MyAlarms : IDisposable
    {
        public event Action OnInventoryNewFishes;
        public event Action OnBookNewFishes;
        public HashSet<int> BookNewFishes
        {
            get;
            private set;
        } = new HashSet<int>();
        public HashSet<int> BookNewSwimmers
        {
            get;
            private set;
        } = new HashSet<int>();

        public HashSet<string> InventoryNewFishes
        {
            get;
            private set;
        } = new HashSet<string>();

        public event Action OnInboxChanged;
        public long InboxCount { get; private set; }

        public void Dispose() { }

        public void Update(UserData data)
        {
            if (data.alarms == null)
            {
                return;
            }

            UpdateInbox(data.alarms.inbox);
        }

        public void UpdateInbox(long count)
        {
            if (InboxCount == count)
            {
                return;
            }

            InboxCount = count;
            if (OnInboxChanged != null)
            {
                OnInboxChanged.Invoke();
            }
        }

        public void UpdateInventoryNewFishes(SeaItemListItemsData items)
        {
            if (items.ids != null)
            {
                int countBefore = InventoryNewFishes.Count;

                InventoryNewFishes.Clear();
                for (int i = 0; i < items.ids.Length; i++)
                {
                    SeaItemType type;
                    Enum.TryParse(items.types[i], out type);
                    int id = items.ids[i];
                    bool isNew = items.news[i] == 1;
                    if (isNew)
                    {
                        InventoryNewFishes.Add(MakeKeyOfNewFish(type, id));
                    }
                }

                if (countBefore != InventoryNewFishes.Count)
                {
                    OnInventoryNewFishes?.Invoke();
                }
            }
        }

        public void UpdateBookNewSwimmers(SwimmerBookListData data)
        {
            if (data.new_fishes != null)
            {
                int countBefore = BookNewSwimmers.Count;

                BookNewSwimmers.Clear();
                for (int i = 0; i < data.new_fishes.Length; i++)
                {
                    BookNewSwimmers.Add(data.new_fishes[i]);
                }
            
                if (countBefore != BookNewSwimmers.Count)
                {
                    OnBookNewFishes?.Invoke();
                }
            }
        }

        public void UpdateBookNewFishes(FishBookListData data)
        {
            if (data.new_fishes != null)
            {
                int countBefore = BookNewFishes.Count;

                BookNewFishes.Clear();
                for (int i = 0; i < data.new_fishes.Length; i++)
                {
                    BookNewFishes.Add(data.new_fishes[i]);
                }

                if (countBefore != BookNewFishes.Count)
                {
                    OnBookNewFishes?.Invoke();
                }
            }
        }

        public bool ConsumeInventoryNewFishes()
        {
            bool result = false;
            if (InventoryNewFishes.Count > 0)
            {
                result = true;

                InventoryNewFishes.Clear();

                OnInventoryNewFishes?.Invoke();
            }

            return result;
        }

        public bool ConsumeBookNewFishes()
        {
            bool result = false;
            if (BookNewFishes.Count > 0
                || BookNewSwimmers.Count > 0)
            {
                result = true;

                BookNewFishes.Clear();
                BookNewSwimmers.Clear();

                OnBookNewFishes?.Invoke();
            }

            return result;
        }

        public string MakeKeyOfNewFish(SeaItemType type, int id)
        {
            return StringMaker.New()
                              .Append(type.ToString())
                              .Append("_")
                              .Append(id.ToString())
                              .Build();
        }
    }
}
