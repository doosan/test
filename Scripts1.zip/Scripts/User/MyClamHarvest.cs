using Gaga;
using Gaga.Util;
using System;
using System.Collections.Generic;
using UnityEngine.Events;

namespace Underc.User
{
    public enum ClamHarvestClamType
    { 
        gold,
        silver
    }

    public enum ClamHarvestTimeState
    {
        None,
        Wait,
        InProgress,
        TimesUp
    }

    public class ClamHarvestClamInfo
    {
        public ClamHarvestClamType clamType;
        public int allClamIndex;
        public int pickax;
        public int maxPickax;
        public List<RewardInfo> rewardableInfos;
        public List<RewardInfo> rewardedInfos;
        public List<ClamHarvestPurchaseItemInfo> purchaseItemInfos;

        public int progressivePickax;    // 보상을 받았을 때 piackax 값이 0 이 되므로 연출 진행을 위한 용도
        public int progressiveClamIndex; // 보상을 받았을 때 allClamIndex 값이 모두 열린 상태가 되므로 연출 진행을 위한 용도

        public int useablePickaxe;

        public bool IsAllClamsPicked
        {
            get;
            private set;
        }
        private int pickedClamIndex;


        public ClamHarvestClamInfo(ClamHarvestClamType clamType,
                                   int pickax, 
                                   int maxPickax, 
                                   int allClamIndex, 
                                   List<RewardInfo> rewardableInfos,
                                   List<ClamHarvestPurchaseItemInfo> purchaseItemInfos)
        {
            this.clamType = clamType;
            this.pickax = pickax;
            this.maxPickax = maxPickax;
            this.allClamIndex = allClamIndex;
            UpdateIfAllClamsPicked();
            UpdateUseablePickaxe();

            this.rewardableInfos = rewardableInfos;
            rewardedInfos = null;
            this.purchaseItemInfos = purchaseItemInfos;

            progressivePickax = pickax;
            progressiveClamIndex = allClamIndex;
        }

        private void UpdateIfAllClamsPicked()
        {
            IsAllClamsPicked = allClamIndex == (1 << 7) - 1;
        }

        private void UpdateUseablePickaxe()
        {
            useablePickaxe = IsAllClamsPicked == false ?
                             pickax : 
                             0;
        }

        public void Update(int pickax, 
                           int allClamIndex, 
                           int pickedClamIndex, 
                           List<RewardInfo> rewardedInfos, 
                           List<ClamHarvestPurchaseItemInfo> purchaseItemInfos)
        {
            this.pickax = pickax;
            this.allClamIndex = allClamIndex;
            this.pickedClamIndex = pickedClamIndex;
            UpdateIfAllClamsPicked();
            UpdateUseablePickaxe();

            this.rewardedInfos = rewardedInfos;
            this.purchaseItemInfos = purchaseItemInfos;

            progressivePickax -= 1;
            progressiveClamIndex |= pickedClamIndex; 
        }

        public int ConsumePickedClamIndex()
        {
            int result = pickedClamIndex;
            pickedClamIndex = 0;
            return result;
        }
    }

    public class ClamHarvestPurchaseItemInfo
    {
        public RewardType rewardType;
        public int val;
        public float price;
        public string itemID;

        public string priceCurrency;

        public ClamHarvestPurchaseItemInfo(RewardType rewardType, int val, float price, string itemID)
        {
            this.rewardType = rewardType;
            this.val = val;
            this.price = price;
            this.itemID = itemID;

            priceCurrency = StringUtils.ToCurrency(price);
        }

        public override string ToString()
        {
            return StringMaker.New()
                              .Append("rewardType : " + rewardType)
                              .Append(", val : " + val)
                              .Append(", price : " + price)
                              .Append(", itemID : " + itemID)
                              .Append(", priceCurrency : " + priceCurrency)
                              .Build();
        }
    }

    public class ClamHarvestDisplayInfo
    {
        public int pickax;

        public void Update(int pickax)
        {
            this.pickax = pickax;
        }

        public override string ToString()
        {
            return $"pickax : {pickax}";
        }
    }

    public class MyClamHarvest : IDisposable
    {
        public UnityEvent onDisplayInfoUpdate = new UnityEvent();
        public UnityEvent onTimeUpdate = new UnityEvent();

        public ClamHarvestDisplayInfo DisplayInfo
        {
            private set;
            get;
        }

        public ClamHarvestClamInfo SilverClamInfo
        {
            get;
            private set;
        }

        public ClamHarvestClamInfo GoldClamInfo
        {
            get;
            private set;
        }

        public long StartRemainingSec
        {
            get;
            private set;
        } = -1;
        private long startTs;

        public long EndRemainingSec
        {
            get;
            private set;
        } = -1;
        private long endTs;

        public bool RunAsFake
        {
            private get;
            set;
        }

        public ClamHarvestClamInfo SelectedClamInfo
        {
            get
            {
                return selectedClamType == ClamHarvestClamType.gold ?
                       GoldClamInfo :
                       SilverClamInfo;
            }
        }
        private ClamHarvestClamType selectedClamType;
        public int SelectedClamIndex
        {
            get;
            private set;
        }

        private GlobalTime globalTime;

        public MyClamHarvest()
        {
            globalTime = GlobalTime.Instance;
            globalTime.onUpdate += UpdateRemainingSec;
        }

        public void Dispose()
        {
            globalTime.onUpdate -= UpdateRemainingSec;
        }

        private long RemainingSeconds(long remainingSeconds)
        {
            DateTime now = DateTime.Now.ToLocalTime();
            TimeSpan span = (now - new DateTime(1970, 1, 1, 0, 0, 0, 0).ToLocalTime());
            long nowSeconds = (long)span.TotalSeconds;

            return nowSeconds + remainingSeconds;
        }

        public void UpdateClamHarvestDisplayInfo()
        {
            UpdateClamHarvestDisplayInfo(SilverClamInfo.useablePickaxe + GoldClamInfo.useablePickaxe);
        }

        public void UpdateClamHarvestDisplayInfo(int pickax)
        {
            if (DisplayInfo == null)
            {
                DisplayInfo = new ClamHarvestDisplayInfo();
            }

            DisplayInfo.Update(pickax);

            onDisplayInfoUpdate?.Invoke();
        }

        public void Update(ClamHarvestData data, PickaxPurchaseItemData[] purchaseItems)
        {
            SilverClamInfo = ParseClamInfo(ClamHarvestClamType.silver, 
                                           data.silver, 
                                           purchaseItems, 
                                           RewardType.s_pickaxe);
            GoldClamInfo = ParseClamInfo(ClamHarvestClamType.gold, 
                                         data.gold, 
                                         purchaseItems, 
                                         RewardType.g_pickaxe);

            if (RunAsFake == false)
            {
                startTs = data.start_ts;
                startTs = 0;
                endTs = data.end_ts;
            }
            else
            {
                startTs = RemainingSeconds(-15);
                endTs = RemainingSeconds(-15) + 60 * 60;
            }

            UpdateRemainingSec(globalTime.GetTimeStamp());

            UpdateClamHarvestDisplayInfo();
        }

        public void Update(HarvestData data)
        {
            bool isGoldClam = data.type == ClamHarvestClamType.gold.ToString();
            ClamHarvestClamInfo clamInfo = isGoldClam ?
                                           GoldClamInfo :
                                           SilverClamInfo;

            List<RewardInfo> rewardedInfos = null;
            if (data.reward != null)
            {
                rewardedInfos = new List<RewardInfo>();
                if (data.remaining_bonus > 0)
                {
                    RewardType coinPickaxType = isGoldClam ?
                                                RewardType.coin_g_pickaxe :
                                                RewardType.coin_s_pickaxe;
                    rewardedInfos.Add(new RewardInfo(coinPickaxType, data.remaining_bonus, data.use_pickaxe, true));
                }

                foreach (CommonRewardData rewardData in data.reward)
                {
                    RewardType type = RewardType.none;
                    if (Enum.TryParse(rewardData.rwd, out type))
                    {
                        rewardedInfos.Add(new RewardInfo(type: type,
                                                         value: rewardData.val,
                                                         additionalValue: 0,
                                                         skipEffect: type == RewardType.coin));
                    }
                }
            }

            ///
            List<ClamHarvestPurchaseItemInfo> purchaseItemInfos = null;
            if (data.item != null)
            {
                purchaseItemInfos = new List<ClamHarvestPurchaseItemInfo>();
                foreach (PickaxPurchaseItemData purchaseItem in data.item)
                {
                    RewardType rewardType = RewardType.none;
                    if (Enum.TryParse(purchaseItem.rwd, out rewardType))
                    {
                        purchaseItemInfos.Add(new ClamHarvestPurchaseItemInfo(rewardType,
                                                                              purchaseItem.val,
                                                                              purchaseItem.price,
                                                                              purchaseItem.itemid));
                    }
                }
            }

            clamInfo.Update(data.pickaxe, data.clam_index, 1 << SelectedClamIndex, rewardedInfos, purchaseItemInfos);
        }

        public void UpdateSelectedClamInfo(ClamHarvestClamType clamType)
        {
            selectedClamType = clamType;
        }

        public void UpdateSelectedClamIndex(int clamIndex)
        {
            SelectedClamIndex = clamIndex;
        }

        public ClamHarvestTimeState ReadDayState()
        {
            return (StartRemainingSec > 0) ? ClamHarvestTimeState.Wait :
                   (EndRemainingSec > 0) ? ClamHarvestTimeState.InProgress :
                   ClamHarvestTimeState.TimesUp;
        }

        private ClamHarvestClamInfo ParseClamInfo(ClamHarvestClamType clamType, 
                                                  ClamHarvestClamData clamData, 
                                                  PickaxPurchaseItemData[] purchaseItems, 
                                                  RewardType purchaseRewardType)
        {
            List<RewardInfo> rewardableInfos = new List<RewardInfo>();
            if (clamData.reward != null)
            {
                foreach (CommonRewardData reward in clamData.reward)
                {
                    RewardType type = RewardType.none;
                    if (Enum.TryParse(reward.rwd, out type) == true)
                    {
                        var rewardInfo = new RewardInfo(type, reward.val);
                        rewardableInfos.Add(rewardInfo);
                    }
                }
            }
            rewardableInfos.SortByRewardOrder();

            List<ClamHarvestPurchaseItemInfo> purchaseItemInfos = null;
            if (purchaseItems != null)
            {
                purchaseItemInfos = new List<ClamHarvestPurchaseItemInfo>();
                foreach (PickaxPurchaseItemData purchaseItem in purchaseItems)
                {
                    RewardType rewardType = RewardType.none;
                    if (Enum.TryParse(purchaseItem.rwd, out rewardType)
                        && rewardType == purchaseRewardType)
                    {
                        purchaseItemInfos.Add(new ClamHarvestPurchaseItemInfo(rewardType,
                                                                              purchaseItem.val,
                                                                              purchaseItem.price,
                                                                              purchaseItem.itemid));
                    }
                }
            }

            var clamInfo = new ClamHarvestClamInfo(clamType,
                                                   clamData.pickaxe,
                                                   clamData.max_pickaxe,
                                                   clamData.clam_index,
                                                   rewardableInfos,
                                                   purchaseItemInfos);
            return clamInfo;
        }

        private void UpdateRemainingSec(long serverTs)
        {
            bool isTimeUpdated = false;

            if (startTs > 0)
            {
                isTimeUpdated = true;
                StartRemainingSec = globalTime.SecondDiff(startTs);
            }

            if (endTs > 0)
            {
                isTimeUpdated = true;
                EndRemainingSec = globalTime.SecondDiff(endTs);
            }

            if (isTimeUpdated == true)
            {
                onTimeUpdate?.Invoke();
            }
        }
    }
}