using System;
using System.Collections.Generic;
using Gaga;
using UnityEngine;

namespace Underc.User
{
    public struct MissionPassPurchaseInfo
    {
        public string itemID;
        public long vipPoint;
        public float price;
        public float salePrice;
        public int uptoValue;
    }

    public enum MissionPassLevelType
    {
        LevelText,
        MissionVault,
        SuperVault,
    }

    public sealed class MyMissionPass : IDisposable
    {
        private readonly string KEY_POPUP_FIRST_OPEN = "mpp_first";

        public enum Status
        {
            Idle        = 0,          
            Reward      = 1,       
            Complete    = 2        
        }

        public struct ItemInfo
        {
            public RewardType type;
            public long value;
            public long extraValue;
            public Status status;
            public Status prevStatus;
        }

        public delegate void RemainSecDelegate(long remain);
        public event RemainSecDelegate onEndRemainSeconds;

        public event Action onDisplayInfoUpdate;

        private long endTimeStamp;
        public long EndRemainingSec { get; private set; }
        public int Season {get; private set;}

        // 마지막으로 클리어 한 Step
        public int ClearedStep {get; private set;} 

         // 현재 진행 중인 Step
        public int CurrentStep
        {
            get
            {
                int result = ClearedStep + 1;
                
                if (result > MaxStep)
                {
                    result = MaxStep;
                }

                return result;
            }
        }

        private int MaxStep
        { 
            get => bonusItemTypeList.Count - 1;
        }

        public bool AllCleared { get; private set; }
        public bool CollectEnabled { get; private set; }
        public bool CollectFreeEnabled { get; private set; }
        public bool CollectBonusEnabled { get; private set; }

        public long CurrentMissionValue { get; private set; }
        public long GoalMissionValue { get; private set; }
        public bool EnabledBonus { get; private set; }
        public bool IsChestComplete { get; private set; }

        public bool IsStepUpInProgress { get; private set; }

        public bool IsMissionPassPopupFirstOpen
        {
            get
            {
                return UndercPrefs.GetRemoteValue(KEY_POPUP_FIRST_OPEN, "1") == "1";
            }
            set
            {
                UndercPrefs.SetRemoteValue(KEY_POPUP_FIRST_OPEN, value ? "1" : "0");
            }
        }

        public int TotalRewardCount
        {
            get
            {
                int result = GetRewardCount(freeItemStatusList, ignoreLastIndex: true);
                if (EnabledBonus)
                {
                    result += GetRewardCount(bonusItemStatusList);
                }
                return result;
            }
        }

        private List<string> freeItemTypeList;
        private List<long> freeItemValueList;
        private List<Status> freeItemStatusList;
        private List<Status> prevFreeItemStatusList;

        private List<string> bonusItemTypeList;
        private List<long> bonusItemValueList;
        private List<Status> bonusItemStatusList;
        private List<Status> prevBonusItemStatusList;

        private Dictionary<RewardType, ItemInfo> mergeGeneralInfoDic;
        private Dictionary<long, ItemInfo> mergeFishInfoDic;

        private MissionPassPurchaseInfo purchaseInfo;

        public MyMissionPass()
        {
            freeItemTypeList = new List<string>();
            freeItemValueList = new List<long>();
            freeItemStatusList = new List<Status>();
            prevFreeItemStatusList = new List<Status>();

            bonusItemTypeList = new List<string>();
            bonusItemValueList = new List<long>();
            bonusItemStatusList = new List<Status>();
            prevBonusItemStatusList = new List<Status>();

            purchaseInfo = new MissionPassPurchaseInfo();

            mergeGeneralInfoDic = new Dictionary<RewardType, ItemInfo>();
            mergeFishInfoDic = new Dictionary<long, ItemInfo>();

            GlobalTime.Instance.onUpdate += OnServerTimeStampUpdate;
        }
      
        public void Dispose()
        {
            GlobalTime.Instance.onUpdate -= OnServerTimeStampUpdate;
        }

        public void Update(MissionPassData data)
        {
            endTimeStamp = data.end_ts;
            Season = data.season;
            ClearedStep = data.step;
            GoalMissionValue = data.all;
            CurrentMissionValue = data.curr;
            if (CurrentMissionValue > GoalMissionValue)
            {
                CurrentMissionValue = GoalMissionValue;
            }
            AllCleared = CurrentStep == data.free.types.Length;

            purchaseInfo.itemID = data.buy.itemid;
            purchaseInfo.vipPoint = data.buy.vip_point;
            purchaseInfo.price = data.buy.price;
            purchaseInfo.salePrice = data.buy.sale_price;
            purchaseInfo.uptoValue = (int)(1000f / purchaseInfo.price);

            EnabledBonus = data.buy.bonus;
            IsChestComplete = data.buy.mission_box;

            CollectFreeEnabled = GetCollectEnabled(data.free.status);
            CollectBonusEnabled = GetCollectEnabled(data.buy.status);
            CollectEnabled = CollectFreeEnabled || CollectBonusEnabled;

            UpdateItems(data.free, freeItemTypeList, freeItemValueList, freeItemStatusList, prevFreeItemStatusList);
            UpdateItems(data.buy, bonusItemTypeList, bonusItemValueList, bonusItemStatusList, prevBonusItemStatusList);

            OnServerTimeStampUpdate(GlobalTime.Instance.GetTimeStamp());

            onDisplayInfoUpdate?.Invoke();
        }

        public void UpdateCurr(long nextCurr)
        {
            CurrentMissionValue = nextCurr;
            IsStepUpInProgress = CurrentMissionValue >= GoalMissionValue;
        }

        public void UpdateStep(int nextStep)
        {
            ClearedStep = nextStep;
        }

        public bool ConsumeStepUpInProgress()
        {
            bool result = IsStepUpInProgress;
            IsStepUpInProgress = false;
            return result;
        }

        private bool GetCollectEnabled(int[] status)
        {
            return false;
            for (int i = 0; i < status.Length; i++)
            {
                if (status[i] == 1)
                {
                    return true;
                }
            }

            return false;
        }

        private int GetRewardCount(List<Status> statusList, bool ignoreLastIndex = false)
        {
            int count = 0;
            int lastIndex = statusList.Count - 1;
            for (int i = 0; i < statusList.Count; i++)
            {
                if (ignoreLastIndex == true && i == lastIndex)
                {
                    continue;
                }

                if (statusList[i] == Status.Reward)
                {
                    count += 1;
                }
            }

            return count;
        }

        private void UpdateItems(MissionPassItemData data, List<string> typeList, List<long> valueList, List<Status> statusList, List<Status> prevStatusList)
        {
            typeList.Clear();
            typeList.AddRange(data.types);

            valueList.Clear();
            valueList.AddRange(data.values);

            prevStatusList.Clear();
            prevStatusList.AddRange(statusList);

            statusList.Clear();


            //for (int i = 0; i < data.status.Length; i++)
            //{
            //    var statusVal = data.status[i];
            //    var status = (Status)statusVal;
            //    statusList.Add(status);
            //}
        }

        private void OnServerTimeStampUpdate(long ts)
        {
            EndRemainingSec = endTimeStamp - ts;

            if (EndRemainingSec < 0)
            {
                EndRemainingSec = 0;
            }

            if (onEndRemainSeconds != null)
            {
                onEndRemainSeconds(EndRemainingSec);
            }
        }

        public ItemInfo GetFreeInfo(int index)
        {
            return CreateInfo(index, freeItemTypeList, freeItemValueList, freeItemStatusList, prevFreeItemStatusList);
        }

        public ItemInfo GetBonusInfo(int index)
        {
            return CreateInfo(index, bonusItemTypeList, bonusItemValueList, bonusItemStatusList, prevBonusItemStatusList);
        }

        private ItemInfo CreateInfo(int index, List<string> typeList, List<long> valueList, List<Status> statusList, List<Status> prevStatusList)
        {
            ItemInfo item = new ItemInfo();

            item.type = string.IsNullOrEmpty(typeList[index]) ? RewardType.none : (RewardType)Enum.Parse(typeof(RewardType), typeList[index]);
            item.value = valueList[index];
            item.status = statusList[index];
            if (prevStatusList.Count > 0
                && index < prevStatusList.Count)
            { 
                item.prevStatus = prevStatusList[index];
            }
            else
            {
                Debug.LogWarning($"==== CreateInfo : {prevStatusList.Count}, {index}");
            }
            return item;
        }

        public int GetItemCount()
        {
            var count = Mathf.Max(freeItemTypeList.Count, bonusItemTypeList.Count);
            return count;
        }

        public MissionPassPurchaseInfo GetPurchaseInfo()
        {
            return purchaseInfo;
        }

        // 같은 type에 아이템 value를 하나로 합침.
        public List<ItemInfo> MergeItemInfo(List<ItemInfo> infoList)
        {
            mergeGeneralInfoDic.Clear();
            mergeFishInfoDic.Clear();

            for (int i = 0; i < infoList.Count; i++)
            {
                var info = infoList[i];

                if (info.type == RewardType.fish)
                {  
                    if (mergeFishInfoDic.ContainsKey(info.value))
                    {
                        var cachedInfo = mergeFishInfoDic[info.value];
                        cachedInfo.extraValue ++;
                        mergeFishInfoDic[info.value] = cachedInfo;
                    }
                    else
                    {
                        info.status = Status.Idle;
                        info.extraValue = 1;
                        mergeFishInfoDic.Add(info.value, info);
                    }
                }
                else
                {
                    if (mergeGeneralInfoDic.ContainsKey(info.type))
                    {
                        var cachedInfo = mergeGeneralInfoDic[info.type];
                        cachedInfo.value += info.value;
                        mergeGeneralInfoDic[info.type] = cachedInfo;
                    }
                    else
                    {
                        info.status = Status.Idle;
                        mergeGeneralInfoDic.Add(info.type, info);
                    }
                }
            }

            infoList.Clear();

            foreach (var item in mergeGeneralInfoDic)
            {
                infoList.Add(item.Value);
            }

            foreach (var item in mergeFishInfoDic)
            {
                infoList.Add(item.Value);
            }

            return infoList;
        }

        public MissionPassLevelType GetLevelType(int level)
        {
            return level == MaxStep ?
                   MissionPassLevelType.MissionVault :
                   MissionPassLevelType.LevelText;
        }
    }
}