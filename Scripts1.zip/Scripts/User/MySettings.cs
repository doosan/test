using System;

namespace Underc.User
{
    public sealed class MySettings : IDisposable
    {
        public delegate void BoolDelegate(bool isOn);
        public event BoolDelegate onAutoFreeGameAndFeature;

        public delegate void FloatDelegate(float value);
        public event FloatDelegate onBgmVolume;
        public event FloatDelegate onSoundVolume;

        public event BoolDelegate onVibrate;
        public event BoolDelegate onAlwaysScreenOn;
        public event BoolDelegate onPlayersMessage;
        public event BoolDelegate onBroadcastAlarm;

        private readonly string KEY_BGM_VOLUME                  = "k_b_volume";
        private readonly string KEY_SOUND_VOLUME                = "k_s_volume";
        private readonly string KEY_VIBRATE                     = "k_vibrate";
        private readonly string KEY_ALWAYS_SCREEN_ON            = "k_a_s_on";
        private readonly string KEY_PLAYERS_MESSAGE             = "k_p_message";
        private readonly string KEY_BROADCAST_ALARM             = "k_b_alarm";

        private readonly float VALUE_DEFAULT_BGM_VOLUME = 1f;
        private readonly float VALUE_DEFAULT_SOUND_VOLUME = 1f;
        private readonly int VALUE_DEFAULT_VIBRATE = 0;
        private readonly int VALUE_DEFAULT_ALWAYS_SCREEN_ON = 1;
        private readonly int VALUE_DEFAULT_PLAYERS_MESSAGE = 1;
        private readonly int VALUE_DEFAULT_BROADCAST_ALARM = 1;

        public void Dispose(){}

        public float BgmVolume
        {
            get
            {
                return UndercPrefs.GetLocalValue(KEY_BGM_VOLUME, VALUE_DEFAULT_BGM_VOLUME);
            }
            set
            {
                UndercPrefs.SetLocalValue(KEY_BGM_VOLUME, value);
                onBgmVolume?.Invoke(value);
            }
        }

        public float SoundVolume
        {
            get
            {
                return UndercPrefs.GetLocalValue(KEY_SOUND_VOLUME, VALUE_DEFAULT_SOUND_VOLUME);
            }
            set
            {
                UndercPrefs.SetLocalValue(KEY_SOUND_VOLUME, value);
                onSoundVolume?.Invoke(value);
            }
        }

        public bool Vibrate
        {
            get
            {
                return UndercPrefs.GetLocalValue(KEY_VIBRATE, VALUE_DEFAULT_VIBRATE) > 0;
            }
            set
            {
                UndercPrefs.SetLocalValue(KEY_VIBRATE, value == true ? 1 : 0);
                onVibrate?.Invoke(value);
            }
        }
        
        public bool AlwaysScreenOn
        {
            get
            {
                return UndercPrefs.GetLocalValue(KEY_ALWAYS_SCREEN_ON, VALUE_DEFAULT_ALWAYS_SCREEN_ON) > 0;
            }
            set
            {
                UndercPrefs.SetLocalValue(KEY_ALWAYS_SCREEN_ON, value == true ? 1 : 0);
                onAlwaysScreenOn?.Invoke(value);
            }
        }

        public bool BroadcastAlarm
        {
            get
            {
                return UndercPrefs.GetLocalValue(KEY_BROADCAST_ALARM, VALUE_DEFAULT_BROADCAST_ALARM) > 0;
            }
            set
            {
                UndercPrefs.SetLocalValue(KEY_BROADCAST_ALARM, value == true ? 1 : 0);
                onBroadcastAlarm?.Invoke(value);
            }
        }

    }
}