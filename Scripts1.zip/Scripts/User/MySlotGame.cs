using System;
using System.Collections.Generic;
using Gaga.Skin;
using SlotGame;
using Underc.Lobby;
using UnityEngine;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace Underc.User
{
    public sealed class MySlotGame : IDisposable
    {
        private readonly string KEY_NEW_SLOT_INFO_LIST = "new_slot_info_list";
        public readonly string DEFAULT_ORDER = "default";

        [Serializable]
        public sealed class NewSlotInfo
        {
            public string slotID;
            public int popupID = -1; // -1 = null;
            public int posterViewCount; // 로비에서 포스터를 본 횟수
            public int popupViewCount; // slotID가 포함 된 해당 공지 팝업을 본 횟수
            public bool isEnter; // 슬롯 진입 여부

            public bool IsValidPopupID
            {
                get
                {
                    return popupID >= 0;
                }
            }
        }

        [Serializable]
        public sealed class NewSlotInfoList
        {
            public List<NewSlotInfo> datas;
        }

        public struct SlotPlayInfo
        {
            public string slotID;
            public long totalBet;
            public int autoSpinCount; //-1 무한

            public bool IsValid => !string.IsNullOrEmpty(slotID);
        }

        public string latestSort;
        public string currentSlotID;

        private SlotPresetList slotPresetList;
        public SlotPresetList SlotPresetList
        {
            get
            {
                if (slotPresetList == null)
                {
                    slotPresetList = Resources.Load("SlotPresetList") as SlotPresetList;
                }

                return slotPresetList;
            }
        }

        // 슬롯 입장 벳 리스트
        private Dictionary<string, CheckBetData> checkBetList;
        private Dictionary<string, SlotData> slotDataList;
        private Dictionary<string, List<string>> orderList;

        // public SlotData LatestPlayedSlot{get; private set;}

        private SlotPlayInfo savedSlotPlayInfo;
        private NewSlotInfoList newSlotInfoList;

        public MySlotGame()
        {
            latestSort = DEFAULT_ORDER;
            
            orderList = new Dictionary<string, List<string>>();
            checkBetList = new Dictionary<string, CheckBetData>();
            slotDataList = new Dictionary<string, SlotData>();

            LoadNewSlotInfoList();
        }

        public void Dispose(){}

        public void Update(string order, SlotListData data)
        {
            latestSort = order;

            SlotData lastSlot = data.last;
            List<SlotData> slotDatas = new List<SlotData>(data.list);

            Version myVersion = new Version(Application.version);

            List<string> slotIdList = null;

            if (orderList.ContainsKey(order))
            {
                slotIdList = orderList[order];
            }
            else
            {
                slotIdList = new List<string>();
                orderList.Add(order, slotIdList);
            }

            slotIdList.Clear();

            if (lastSlot != null && string.IsNullOrEmpty(lastSlot.ver) == false)
            {
                slotDatas.Insert(0, lastSlot);
            }

            for (int i = 0; i < slotDatas.Count; i++)
            {
                var slotData = slotDatas[i];

                if (string.IsNullOrEmpty(slotData.ver))
                {
                    continue;
                }

                Version slotVersion = new Version(slotData.ver);

                if (slotVersion > myVersion)
                {
                    continue;
                }

                slotData.IsPlayed = lastSlot.slotid == slotData.slotid;
                
                if (slotDataList.ContainsKey(slotData.slotid))
                {
                    slotDataList[slotData.slotid] = slotData;
                }
                else
                {
                    slotDataList.Add(slotData.slotid, slotData);
                }

                slotIdList.Add(slotData.slotid);
            }
        }

        public string GetRandomSlotID()
        {
            int randomSlotID = 0; /// 0 이면 Play Any Game

            int randomIndex = UnityEngine.Random.Range(0, SlotPresetList.Items.Count);
            SlotPosterItem randomItem = SlotPresetList.Items[randomIndex];
            if (SlotPresetList.IsSlotInDev(randomItem.id) == false)
            {
                randomSlotID = randomItem.id;
            }

            return randomSlotID.ToString();
        }

        public SlotData GetSlotData(string slotID)
        {
            if (slotDataList.ContainsKey(slotID))
            {
                return slotDataList[slotID];
            }

            return null;
        }

        public SlotCardInfo CreateSlotCardInfo(SlotData slotData)
        {
            if (slotData == null)
            {
                return null;
            }

            SlotPosterItem posterItem = MyInfo.SlotGame.SlotPresetList.Find(int.Parse(slotData.slotid));

            if (posterItem == null)
            {
                return null;
            }

#if !DEV
            if (posterItem.show == false)
            {
                return null;
            }
#endif

            var slotInfo = new SlotCardInfo();
            slotInfo.slotData = slotData;
            slotInfo.posterItem = posterItem;

            slotInfo.isPlayed = slotData.IsPlayed;
            slotInfo.isNew = slotData.IsNew;
            slotInfo.isFeatured = slotData.IsFeatured;
            slotInfo.unlockLevel = slotData.unlock_level;
            slotInfo.isLock = MyInfo.Level < slotData.unlock_level && !slotInfo.isNew && !slotInfo.isFeatured;
            slotInfo.skin = Skin.ConvertToSkinType(slotData.Skin);

            if (slotData.progs != null && slotData.progs.Length > 0)
            {
                slotInfo.jackpotProgs = (long[])slotData.progs.Clone();
            }

            return slotInfo;
        }

        public SlotData[] GetSlotDatas(string order)
        {
            if (orderList.ContainsKey(order))
            {
                List<string> slotIdList =  orderList[order];
                List<SlotData> slotDatas = new List<SlotData>();

                for (int i = 0; i < slotIdList.Count; i++)
                {
                    var slotID = slotIdList[i];
                    var slotData = GetSlotData(slotID);

                    if (slotData != null)
                    {
                        slotDatas.Add(slotData);
                    }
                }

                return slotDatas.ToArray();
            }
            else
            {
                Debug.Log("저장된 order가 없어서 모든 리스트를 반환 합니다.");

                SlotData[] slotDatas = new SlotData[slotDataList.Count];

                int index = 0;

                foreach (var item in slotDataList)
                {
                    slotDatas[index] = item.Value;
                    index++;
                }

                return slotDatas;
            }
        }

        public bool ContainsCheckBet(string slotID)
        {
            return checkBetList.ContainsKey(slotID);
        }

        public CheckBetData GetCheckBet(string slotID)
        {
            if (ContainsCheckBet(slotID))
            {
                return checkBetList[slotID];
            }

            return default(CheckBetData);
        }

        public void SetCheckBet(string slotID, CheckBetData  data)
        {
            if (ContainsCheckBet(slotID))
            {
                checkBetList[slotID] = data;
            }
            else
            {
                checkBetList.Add(slotID, data);
            }
        }

        public void SetSlotPlayInfo(string slotID, long totalbet, int autoSpinCount)
        {
            savedSlotPlayInfo.slotID = slotID;
            savedSlotPlayInfo.totalBet = totalbet;
            savedSlotPlayInfo.autoSpinCount = autoSpinCount;
        }

        public SlotPlayInfo GetSlotPlayInfo()
        {
            return savedSlotPlayInfo;
        }

        public void ClearSlotPlayInfo()
        {
            SetSlotPlayInfo(null, 0, 0);
        }

        public bool ContainsSkin(SkinType skinType)
        {
            foreach (var slotData in slotDataList)
            {
                var slotSkin = Skin.ConvertToSkinType(slotData.Value.Skin);

                if (slotSkin == skinType)
                {
                    return true;
                }
            }

            return false;
        }

        private void LoadNewSlotInfoList()
        {
            Debug.Log("Load NewSlotInfoList! - start");
            var newGameInfoListStr = UndercPrefs.GetLocalValue(KEY_NEW_SLOT_INFO_LIST);

            if (string.IsNullOrEmpty(newGameInfoListStr))
            {
                newSlotInfoList = new NewSlotInfoList();
                newSlotInfoList.datas = new List<NewSlotInfo>();

                SaveNewSlotInfoList();

                Debug.Log("Load NewSlotInfoList! - Create new info");
            }
            else
            {
                BinaryFormatter bf = new BinaryFormatter();
                MemoryStream ms = new MemoryStream(Convert.FromBase64String(newGameInfoListStr));
                newSlotInfoList = (NewSlotInfoList)bf.Deserialize(ms);

                Debug.Log("Load NewSlotInfoList! - Load from local storage");
            }

            Debug.Log("Load NewSlotInfoList! - done");
        }

        public void SaveNewSlotInfoList()
        {
            if (newSlotInfoList == null)
            {
                return;
            }

            Debug.Log("Save NewSlotInfoList! - start");

            BinaryFormatter bf = new BinaryFormatter();
            MemoryStream ms = new MemoryStream();
            bf.Serialize(ms, newSlotInfoList);

            string result = Convert.ToBase64String(ms.GetBuffer());
            UndercPrefs.SetLocalValue(KEY_NEW_SLOT_INFO_LIST, result);

            Debug.Log("Save NewSlotInfoList! - done");
        }

        public void RemoveOldNewGameInfoList()
        {
            List<string> currentNewSlotIdList = new List<string>();

            foreach (var item in slotDataList)
            {
                var slotData = item.Value;

                if (slotData.IsNew)
                {
                    currentNewSlotIdList.Add(slotData.slotid);
                }
            }

            List<NewSlotInfo> tempList = new List<NewSlotInfo>();

            for (int i = 0; i < newSlotInfoList.datas.Count; i++)
            {
                var info = newSlotInfoList.datas[i];

                if (currentNewSlotIdList.Contains(info.slotID) == false)
                {
                    tempList.Add(info);
                }
            }

            while (tempList.Count > 0)
            {
                var removeInfo = tempList[0];
                Debug.Log("RemoveOldNewGameInfoList - id : " + removeInfo.slotID);
                newSlotInfoList.datas.Remove(removeInfo);
                tempList.RemoveAt(0);
            }

            SaveNewSlotInfoList();
        }

        public bool CheckAndCreateNewSlotInfo(int popupID, string slotID)
        {
            if (string.IsNullOrEmpty(slotID))
            {
                return false;
            }

            var slotData = GetSlotData(slotID);

            if (slotData == null || slotData.IsNew == false)
            {
                return false;
            }

            if (ContainsNewGameInfo(popupID) == false)
            {
                var newInfo = new NewSlotInfo(){slotID = slotID, popupID = popupID};
                newSlotInfoList.datas.Add(newInfo);
            }

            return true;
        }

        private bool CheckAndCreateNewSlotInfo(string slotID)
        {
            if (string.IsNullOrEmpty(slotID))
            {
                return false;
            }

            var slotData = GetSlotData(slotID);

            if (slotData == null || slotData.IsNew == false)
            {
                return false;
            }

            if (ContainsNewGameInfo(slotID) == false)
            {
                var newInfo = new NewSlotInfo(){slotID = slotID};
                newSlotInfoList.datas.Add(newInfo);
            }

            return true;
        } 

        public void IncreaseNewSlotPopupViewCount(int popupId, string slotID)
        {
            if (CheckAndCreateNewSlotInfo(popupId, slotID) == false)
            {
                return;
            }

            for (int i = 0; i < newSlotInfoList.datas.Count; i++)
            {
                var info = newSlotInfoList.datas[i];

                if (info.slotID == slotID && info.popupID == popupId)
                {
                    info.popupViewCount ++;
                    Debug.LogFormat("IncreaseNewSlotPopupViewCount - slotID : {0} , popupID : {1} , count : {2}", info.slotID, info.popupID, info.popupViewCount);
                }
            }
        }

        public void IncreaseNewSlotPosterViewCount(string slotID)
        {
            if (CheckAndCreateNewSlotInfo(slotID) == false)
            {
                return;
            }

            for (int i = 0; i < newSlotInfoList.datas.Count; i++)
            {
                var info = newSlotInfoList.datas[i];

                if (info.slotID == slotID)
                {
                    info.posterViewCount ++;
                    Debug.LogFormat("IncreaseNewSlotPosterViewCount - slotID : {0} , popupID : {1} , count : {2}", info.slotID, info.popupID, info.posterViewCount);
                }
            }
        }

        public void SetNewSlotEnter(string slotID)
        {
            if (string.IsNullOrEmpty(slotID))
            {
                return;
            }

            if (ContainsNewGameInfo(slotID) == false)
            {
                return;
            }

            for (int i = 0; i < newSlotInfoList.datas.Count; i++)
            {
                var info = newSlotInfoList.datas[i];

                if (info.slotID == slotID)
                {
                    info.isEnter = true;
                    Debug.LogFormat("SetNewSlotEnter - slotID : {0} , popupID : {1}", info.slotID, info.popupID);
                }
            }
        }

        public bool GetNewSlotEnter(string slotID)
        {
            if (string.IsNullOrEmpty(slotID))
            {
                return true;
            }

            if (ContainsNewGameInfo(slotID) == false)
            {
                return true;
            }

            for (int i = 0; i < newSlotInfoList.datas.Count; i++)
            {
                var info = newSlotInfoList.datas[i];

                if (info.slotID == slotID)
                {
                    return info.isEnter;
                }
            }

            return true;
        }

        public bool ContainsNewGameInfo(string slotID)
        {
            return GetNewSlotInfo(slotID) != null;
        }

        public bool ContainsNewGameInfo(int popupID)
        {
            return GetNewSlotInfo(popupID) != null;
        }

        // slotID를 갖고 있는 첫번째 newGameInfo 를 리턴 함.
        public NewSlotInfo GetNewSlotInfo(string slotID)
        {
            for (int i = 0; i < newSlotInfoList.datas.Count; i++)
            {
                if (newSlotInfoList.datas[i].slotID == slotID)
                {
                    return newSlotInfoList.datas[i];
                }
            }

            return null;
        }

        public NewSlotInfo GetNewSlotInfo(int popupID)
        {
            for (int i = 0; i < newSlotInfoList.datas.Count; i++)
            {
                if (newSlotInfoList.datas[i].popupID == popupID)
                {
                    return newSlotInfoList.datas[i];
                }
            }

            return null;
        }

        public List<NewSlotInfo> GetNewSlotInfoListForValidPopupID(string slotID)
        {
            List<NewSlotInfo> infos = new List<NewSlotInfo>();

            for (int i = 0; i < newSlotInfoList.datas.Count; i++)
            {
                var info = newSlotInfoList.datas[i];

                if (info.slotID == slotID && info.popupID > -1)
                {
                    infos.Add(info);
                }
            }

            return infos;
        }
    }
}