﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Underc.User
{

    public class MyQuestClam : IDisposable
    {
        public enum MissionType
        {
            None,
            Spins,
            Wins,
            Freespins,
            BigWins,
            BetTotal,
            WinTotal
        }

        public MissionType CurrentMission{get; private set;}

        public long UnlockLevel{get; private set;}
        public long Current{get; private set;}
        public long Max{get; private set;}

        public long Coin{get; private set;}
        public long Pearl{get; private set;}
        public long Ticket{get; private set;}

        public long RewardCoin { get; private set; }
        public long RewardPearl { get; private set; }
        public long RewardTicket { get; private set; }

        public MissionType NextMission{get; private set;}

        public bool IsCompelte{get; private set;}

        public void Dispose() { }

        public bool HasQuest()
        {
            return CurrentMission != MissionType.None;
        }

        public void Update(QuestClamData data)
        {
            if (data == null)
            {
                CurrentMission = MissionType.None;
            }
            else
            {
                CurrentMission = GetMissionType(data.mission);
                Current = data.curr;
                Max = data.goal;
                IsCompelte = Max > 0 ? Current == Max : false;
                Coin = data.reward_coin;
                Pearl = data.reward_pearl;
                Ticket = data.reward_ticket;
                UnlockLevel = data.unlock;
            }
        }

        public void Update(QuestClamCollectData data)
        {
            RewardCoin = data.reward_coin;
            RewardPearl = data.reward_pearl;
            RewardTicket = data.reward_ticket;

            CurrentMission = GetMissionType(data.next_mission);
            Current = 0;
            Max = data.next_goal;
            IsCompelte = false;
        }

        public string GetMissionName(MissionType mission)
        {
            string rv = "";

            if (mission == MissionType.Spins)
            {
                rv = "SPINS";
            }
            else if (mission == MissionType.Wins)
            {
                rv = "WINS";
            }
            else if (mission == MissionType.Freespins)
            {
                rv = "FREE SPINS";
            }
            else if (mission == MissionType.BigWins)
            {
                rv = "BIG WINS";
            } 
            else if (mission == MissionType.BetTotal)
            {
                rv = "BET TOTAL";
            }
            else if (mission == MissionType.WinTotal)
            {
                rv = "WIN TOTAL";
            }
            else
            {
                rv = mission.ToString();
            }

            return rv;  
        }

        public string GetToolTipText(MissionType mission)
        {
            string rv = "";

            if (mission == MissionType.Spins)
            {
                rv = "Spin <color=#ffff00>{0}</color> times\n& get rewards.";
            }
            else if (mission == MissionType.Wins)
            {
                rv = "Win <color=#ffff00>{0}</color> times\n& get rewards.";
            }
            else if (mission == MissionType.Freespins)
            {
                rv = "Spin <color=#ffff00>{0}</color> times\nduring Free Spin\n& get rewards.";
            }
            else if (mission == MissionType.BigWins)
            {
                rv = "Big Win <color=#ffff00>{0}</color> times\n& get rewards.";
            } 
            else if (mission == MissionType.BetTotal)
            {
                rv = "Bet total of <color=#ffff00>{0}</color> coins \n& get rewards.";
            }
            else if (mission == MissionType.WinTotal)
            {
                rv = "Win total of <color=#ffff00>{0}</color> coins \n& get rewards.";
            }
            else
            {
                rv = mission.ToString();
            }

            return rv;  
        }
        
        public MissionType GetMissionType(string mission)
        {
            MissionType missionType = MissionType.None;

            if (mission == "spins")
            {
                missionType = MissionType.Spins;
            }
            else if (mission == "wins")
            {
                missionType = MissionType.Wins;
            }
            else if (mission == "freespins")
            {
                missionType = MissionType.Freespins;
            }
            else if (mission == "bigwins")
            {
                missionType = MissionType.BigWins;
            } 
            else if (mission == "bettotal")
            {
                missionType = MissionType.BetTotal;
            }
            else if (mission == "wintotal")
            {
                missionType = MissionType.WinTotal;
            }    

            return missionType;
        }
    }
}
