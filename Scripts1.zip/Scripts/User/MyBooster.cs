using System;
using Gaga;

namespace Underc.User
{
    public sealed class MyBooster : IDisposable
    {
        public delegate void RemainSecDelegate(long remain);
        public event RemainSecDelegate onXpRemainSeconds;
        public event RemainSecDelegate onSecondaryCurrenciesRemainSeconds;
        public event RemainSecDelegate onSecondaryCurrenciesAddedRemainSeconds;

        private long xpTimestamp;
        private long secondaryCurrenciesTimeStamp;
        private long secondaryCurrenciesAddedTimeStamp;
        public long SecondaryCurrenciesAddedSec 
        { 
            get; 
            set; 
        }

        public long XPRemainSec 
        { 
            get; 
            private set; 
        }
        public long SecondaryCurrenciesRemainSec 
        { 
            get; 
            private set; 
        }
        public long SecondaryCurrenciesAddedRemainSec 
        { 
            get; 
            private set; 
        }

        public MyBooster()
        {
            GlobalTime.Instance.onUpdate += OnServerTimeStampUpdate;
        }

        public void Dispose()
        {
            GlobalTime.Instance.onUpdate -= OnServerTimeStampUpdate;
        }

        public void Update(UserData data)
        {
            if (data.level != null)
            {
                xpTimestamp = data.level.booster_end_ts;
            }
            secondaryCurrenciesTimeStamp = data.pearl_booster_end_ts;

            OnServerTimeStampUpdate(GlobalTime.Instance.GetTimeStamp());
        }

        public void UpdateSecondaryCurrenciesAddedTimeStamp(long endTs, 
                                                            long addedSec)
        {
            secondaryCurrenciesAddedTimeStamp = 0;
            if (addedSec > 0)
            {
                long originEndTs = endTs - addedSec;
                long originRemainSec = GlobalTime.Instance.SecondDiff(originEndTs);
                long addedEndTs = endTs - originRemainSec;
                secondaryCurrenciesAddedTimeStamp = addedEndTs;
            }
        }

        /// 14레벨 달성 펄&티켓 부스터 보너스 받은 이후 
        /// 다음날부터 Enter 때 n시간씩 받음
        public void ConsumeSecondaryCurrenciesAddedSec()
        {
            if (SecondaryCurrenciesAddedSec > 0)
            {
                UpdateSecondaryCurrenciesAddedTimeStamp(secondaryCurrenciesTimeStamp,
                                                        SecondaryCurrenciesAddedSec);

                SecondaryCurrenciesAddedSec = 0;
            }
        }

        private void OnServerTimeStampUpdate(long ts)
        {
            XPRemainSec = CalcRemainSec(xpTimestamp, ts);
            if (onXpRemainSeconds != null)
            {
                onXpRemainSeconds(XPRemainSec);
            }

            SecondaryCurrenciesRemainSec = CalcRemainSec(secondaryCurrenciesTimeStamp, ts);
            if (onSecondaryCurrenciesRemainSeconds != null)
            {
                onSecondaryCurrenciesRemainSeconds(SecondaryCurrenciesRemainSec);
            }

            SecondaryCurrenciesAddedRemainSec = CalcRemainSec(secondaryCurrenciesAddedTimeStamp, ts);
            if (onSecondaryCurrenciesAddedRemainSeconds != null)
            {
                onSecondaryCurrenciesAddedRemainSeconds(SecondaryCurrenciesAddedRemainSec);
            }
        }

        private long CalcRemainSec(long targetTs, long serverTs)
        {
            long sec = targetTs - serverTs;
            if (sec < 0)
            {
                sec = 0;
            }

            return sec;
        }
    }
}