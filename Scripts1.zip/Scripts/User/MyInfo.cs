using System;
using System.Collections.Generic;
using Underc.Lobby;
using Gaga;
using UnityEngine;
using UnityEngine.CrashReportHandler;

namespace Underc.User
{
    public class PlatformDevice
    {
        private static string uuid;
        public static bool IsUuidEmpty
        {
            get;
            private set;
        }

        public static string GetUuid()
        {
            if (string.IsNullOrEmpty(uuid))
            {
                uuid = SecretManager.Get("UUID");
                IsUuidEmpty = string.IsNullOrEmpty(uuid);

                if (IsUuidEmpty)
                {
                    uuid = SystemInfo.deviceUniqueIdentifier;
                    SecretManager.Put("UUID", uuid);
                }
            }

            return uuid;
        }
    }

    public static class MyInfo
    {
        public const int POSITION_LOBBY_OCEAN = 1;
        public const int POSITION_LOBBY_SLOT = 2;

        public delegate void NumericLongDelegate(long value);
        public delegate void BooleanDelegate(bool value);

        public static event NumericLongDelegate OnCoinsChanged;
        public static event NumericLongDelegate OnPearlsChanged;
        public static event NumericLongDelegate OnTicketsChanged;
        public static event NumericLongDelegate OnLevelChanged;

        private static List<IDisposable> subInfoList = new List<IDisposable>();

        private static bool initOnce;

        public static void Initialize()
        {
            if (initOnce == false)
            {
                initOnce = true;

                for (int i = 0; i < subInfoList.Count; i++)
                {
                    subInfoList[i].Dispose();
                }

                position = POSITION_LOBBY_OCEAN;

                MyInfo.SpinQuest = CreateSubItem<MySpinQuest>();
                MyInfo.QuestClam = CreateSubItem<MyQuestClam>();
                MyInfo.Ocean = CreateSubItem<MyOcean>();
                MyInfo.OceanBonus = CreateSubItem<MyOceanBonus>();
                MyInfo.CasinoBonus = CreateSubItem<MyCasinoBonus>();
                MyInfo.Tutorial = CreateSubItem<MyTutorial>();
                MyInfo.Settings = CreateSubItem<MySettings>();
                MyInfo.Challenge = CreateSubItem<MyChallenge>();
                MyInfo.Booster = CreateSubItem<MyBooster>();
                MyInfo.Profile = CreateSubItem<MyProfile>();
                MyInfo.Shop = CreateSubItem<MyShop>();
                MyInfo.Alarms = CreateSubItem<MyAlarms>();
                MyInfo.AdsReward = CreateSubItem<MyAdsReward>();
                MyInfo.SlotGame = CreateSubItem<MySlotGame>();
                MyInfo.Deal = CreateSubItem<MyDeal>();
                MyInfo.DailyMission = CreateSubItem<MyDailyMission>();
                MyInfo.ClamHarvest = CreateSubItem<MyClamHarvest>();
                MyInfo.VipClass = CreateSubItem<MyVipClass>();
                MyInfo.AquaBlitz = CreateSubItem<MyAquaBlitz>();
                MyInfo.MissionPass = CreateSubItem<MyMissionPass>();
            }
            else
            {
                Debug.LogWarning("MyInfo 클래스는 이미 초기화 되었습니다.");
            }
        }

        private static T CreateSubItem<T>() where T : IDisposable, new()
        {
            var newItem = new T();
            subInfoList.Add(newItem);
            return newItem;
        }

        public static MySpinQuest SpinQuest { get; private set; }
        public static MyQuestClam QuestClam { get; private set; }
        public static MyOcean Ocean { get; private set; }
        public static MyOceanBonus OceanBonus { get; private set; }
        public static MyCasinoBonus CasinoBonus { get; private set; }
        public static MyAdsReward AdsReward { get; private set; }
        public static MyTutorial Tutorial { get; private set; }
        public static MySettings Settings { get; private set; }
        public static MyChallenge Challenge { get; private set; }
        public static MyBooster Booster { get; private set; }
        public static MyProfile Profile { get; private set; }
        public static MyShop Shop { get; private set; }
        public static MyAlarms Alarms { get; private set; }
        public static MySlotGame SlotGame { get; private set; }
        public static MyDeal Deal { get; private set; }
        public static MyDailyMission DailyMission { get; private set; }
        public static MyClamHarvest ClamHarvest { get; private set; }
        public static MyAquaBlitz AquaBlitz { get; private set; }
        public static MyVipClass VipClass { get; private set; }
        public static MyMission Mission { get; private set; }
        public static MyMissionPass MissionPass {get; private set;}

        public static string UUID
        {
            get
            {
#if UNITY_IOS
                return PlatformDevice.GetUuid(); 
#else
                return "5729572727156437a";
                return Device.GetUUID();
#endif
            }
        }

        public static bool IsReinstalledUser
        {
            get;
            private set;
        }

        public static string ID;
        public static float broadcastPollingTime;
        public static float notiCheckPollingTime;
        public static long myWinNotiTimeStamp;
        public static long registedTimeStmap;

        public static int PlayDays
        {
            get
            {
                var regDate = AppService.ToCST(new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc).AddSeconds(registedTimeStmap));
                regDate = regDate.AddHours(-regDate.Hour);
                regDate = regDate.AddMinutes(-regDate.Minute);
                regDate = regDate.AddSeconds(-regDate.Second);

                var nowDate = AppService.ToCST(new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc).AddSeconds(GlobalTime.Instance.GetTimeStamp()));

                return (nowDate - regDate).Days;
            }
        }

        // 1:바다로비, 2:슬롯로비, slotID:인게임
        private static int position;
        public static int Position
        {
            get => position;
            set
            {
                position = value;
                CrashReportHandler.SetUserMetadata("user_pos", position.ToString());
            }
        }

        private static long coin;
        public static long Coin
        {
            get { return coin; }
            set
            {
                if (coin != value)
                {
                    coin = value;
                    if (OnCoinsChanged != null)
                    {
                        OnCoinsChanged(coin);
                    }
                }
            }
        }

        private static long pearl;
        public static long Pearl
        {
            get { return pearl; }
            set
            {
                if (pearl != value)
                {
                    pearl = value;
                    if (OnPearlsChanged != null)
                    {
                        OnPearlsChanged(pearl);
                    }
                }
            }
        }

        private static long ticket;
        public static long Ticket
        {
            get { return ticket; }
            set
            {
                if (ticket != value)
                {
                    ticket = value;
                    if (OnTicketsChanged != null)
                    {
                        OnTicketsChanged(ticket);
                    }
                }
            }
        }

        private static long level;
        public static long Level
        {
            get { return level; }
            set
            {
                if (level != value)
                {
                    level = value;
                    if (OnLevelChanged != null)
                    {
                        OnLevelChanged(level);
                    }
                }
            }
        }

        public static float CurrentXP{get; private set;}
        public static float BaseXP{get; private set;}
        public static float NextXP{get; private set;}

        public static long spins;

        public static string AssetBundleFileName{get; private set;}
     
        public static void Update(UserData data)
        {
            Coin = data.coin;
            Pearl = data.pearl;
            Ticket = data.ticket;
            spins = data.spins;

            Update(data.level);
            Booster.Update(data);
            Alarms.Update(data);
            VipClass.Update(data.vip_class);
            VipClass.UpdateResetTimeStamp(data.vip_reset_ts);
        }

        public static void Update(SellFishData data)
        {
            Coin = data.coin;
        }

        public static void Update(LevelData data)
        {
            if (data != null)
            {
                Level = data.current;
                CurrentXP = data.xp;
                BaseXP = data.xp_base;
                NextXP = data.next_xp;

                /// 레벨 데이터에 포함된 부스터 정보 업데이트
                long pearlBoosterEndTs = data.pearl_booster_end_ts;
                long pearlBoosterAddedSec = data.pearl_booster_add_sec;
                if (pearlBoosterAddedSec > 0)
                {
                    Booster.UpdateSecondaryCurrenciesAddedTimeStamp(pearlBoosterEndTs, pearlBoosterAddedSec);
                }
            }
        }

        public static void Update(GetAssetFileData data)
        {
            AssetBundleFileName = data.asset_file;
        }

        public static void Update(SlotListData data, string order)
        {
            SlotGame.Update(order, data);
        }

        public static void Update(TutorialSlotData data)
        {
            if (string.IsNullOrEmpty(data.slotid) || data.slotid == "0")
            {
                Tutorial.tutorialSlotID = Tutorial.DEFAULT_TUTORIAL_SLOT_ID;
            }
            else
            {
                Tutorial.tutorialSlotID = data.slotid;
            }

            Tutorial.backToSlotAfterSwimmerTuto = data.back_to_slot_after_swimmer_tuto == 1;
        }

        public static void CheckIfReinstalledUser()
        {
#if UNITY_IOS
            PlatformDevice.GetUuid();
            if (PlatformDevice.IsUuidEmpty == false)
            {
                IsReinstalledUser = true;
            }
#endif
            Debug.Log("==== CheckIfReinstalledUser : " + IsReinstalledUser);
        }
    }
}