using System;
using System.Collections.Generic;
using System.Linq;
using Underc.Ocean;
using Underc.Tutorial;

namespace Underc.User
{
    public sealed class MyTutorial : IDisposable
    {
        // 튜토리얼 완료 체크 
        // 대부분 튜토리얼은 서버에 값을 저장해 완료 처리를 하지만
        // 특정 튜토리얼은 계속 반복되는 튜토리얼로써 서버에 값을 저장하지않고 클라이언트가
        // 상황 판단으로 완료 처리를 함. (ex : NewSea)
        private enum CompleteCheck
        {
            Self, // 스스로 판단.
            Server // 서버에 저장된 값으로 판단.
        }

        private readonly string KEY_TUTORIAL                = "tutorial";
        public readonly string DEFAULT_TUTORIAL_SLOT_ID     = "1020";

        private string completeListOriginValue;
        private List<int> completeList;

        public string tutorialSlotID = "";
        public bool backToSlotAfterSwimmerTuto;

        public MyTutorial()
        {
            tutorialSlotID = DEFAULT_TUTORIAL_SLOT_ID;
            completeList = new List<int>();
            TutorialSystem.Instance.onComplete += OnCompleteHandler;
        }

        public void Dispose()
        {
            TutorialSystem.Instance.onComplete -= OnCompleteHandler;
        }

        private void SetTutorial(TutorialChapter chapter, bool isComplete)
        {
            var completeList = GetCompleteList();
            int chapterValue = (int)chapter;

            if (isComplete)
            {
                if (!completeList.Contains(chapterValue))
                {
                    completeList.Add(chapterValue);
                }
                else
                {
                    return;
                }
            }
            else
            {
                if (completeList.Contains(chapterValue))
                {
                    completeList.Remove(chapterValue);
                }
                else
                {
                    return;
                }
            }

            var values = string.Join(",",completeList);
            UndercPrefs.SetRemoteValue(KEY_TUTORIAL, values);
        }

        private List<int> GetCompleteList()
        {
            var values = UndercPrefs.GetRemoteValue(KEY_TUTORIAL, null);

            if (completeListOriginValue == values)
            {
                return completeList;
            }

            completeListOriginValue = values;
            completeList.Clear();

            if (!string.IsNullOrEmpty(values))
            {
                completeList.AddRange(values.Split(',').Select(Int32.Parse).ToList());
            }

            return completeList;
        }

        private void OnCompleteHandler(TutorialChapter chapter)
        {
            SetTutorial(chapter, true);
        }

        // 튜토리얼 완료 여부
        public bool IsComplete(TutorialChapter chapter)
        {
            var saveType = GetCompleteCheck(chapter);

            if (saveType == CompleteCheck.Self)
            {
                if (chapter == TutorialChapter.NewSea)
                {
                    var nextSeaID = MyInfo.Ocean.CurrentSeaID + 1;
                    var isValidNextSea = SeaSystem.Instance.IsValidSea(nextSeaID);
                    var isVisitedNextSea = MyInfo.Ocean.ContainsVisitSea(nextSeaID);
                    var isClearCurrentSea = MyInfo.Ocean.CurrentStar == 3;

                    if (isClearCurrentSea)
                    {
                        if (isValidNextSea == false)
                        {
                            return true;
                        }

                        if (isVisitedNextSea)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                    else
                    {
                        return true;
                    }
                }
                else if (chapter == TutorialChapter.FirstVisitToSea)
                {
                    return true;
                }
            }
            else if (saveType == CompleteCheck.Server)
            {
                var isComplete = GetCompleteList().Contains((int)chapter);
                return isComplete;
            }

            return false;
        }

        //튜토리얼을 진행해야 하는지 여부. 
        public bool IsReady(TutorialChapter chapter)
        {
            var isValid = IsComplete(chapter) == false;
            
            if (isValid == false)
            {
                return false;
            }

            if (chapter == TutorialChapter.Welcome)
            {
                isValid = MyInfo.CurrentXP == 0 && MyInfo.Coin == 0;
            }
            else if (chapter == TutorialChapter.PlaySlot)
            {
                isValid = MyInfo.spins <= PlaySlotTutorial.VALID_SPINS;
            }
            else if (chapter == TutorialChapter.UnlockSea)
            {
                isValid = MyInfo.Level >= MyInfo.Ocean.SeaUnlockLevel && MyInfo.Ocean.Book.GetFreeBookInfo(SeaItemType.f) != null;
            }
            else if (chapter == TutorialChapter.NewSea)
            {
                var nextSeaID = MyInfo.Ocean.CurrentSeaID + 1;
                var isValidNextSea = SeaSystem.Instance.IsValidSea(nextSeaID);
                var isVisitedNextSea = MyInfo.Ocean.ContainsVisitSea(nextSeaID);
                var isClearCurrentSea = MyInfo.Ocean.CurrentStar == 3;
                MySea nextSea = MyInfo.Ocean.GetSea(nextSeaID);
                bool isInLevelLock = true;
                if (nextSea != null)
                {
                    isInLevelLock = nextSea.IsInLevelLock;
                }

                isValid = isValidNextSea 
                          && isVisitedNextSea == false 
                          && isClearCurrentSea
                          && isInLevelLock == false;
            }
            else if (chapter == TutorialChapter.MissionPass)
            {
                isValid = MyInfo.MissionPass.IsMissionPassPopupFirstOpen;
            }

            return isValid;
        }

        public void SyncAll()
        {
            foreach (TutorialChapter item in Enum.GetValues(typeof(TutorialChapter)))
            {
                SyncComplete(item);
            }
        }

        // 튜토리얼 완료 처리 싱크
        // 싱크 조건에 해당되면 완료처리 함.
        private void SyncComplete(TutorialChapter chapter)
        {
            if (IsComplete(chapter) == true)
            {
                return;
            }

            if (IsReady(chapter) == true)
            {
                return;
            }

            bool needComplete = true;

            if (chapter == TutorialChapter.Welcome)
            {
                needComplete = MyInfo.Coin > 0;
            }
            else if (chapter == TutorialChapter.PlaySlot)
            {
                needComplete = MyInfo.spins > PlaySlotTutorial.VALID_SPINS;
            }
            else if (chapter == TutorialChapter.UnlockSea)
            {
                needComplete = MyInfo.Level > MyInfo.Ocean.SeaUnlockLevel && MyInfo.Ocean.Book.GetFreeBookInfo(SeaItemType.f) == null;
            }
            else if (chapter == TutorialChapter.NewSea)
            {
                needComplete = false;
            }
            else if (chapter == TutorialChapter.MissionPass)
            {
                needComplete = MyInfo.MissionPass.IsMissionPassPopupFirstOpen == false;
            }

            if (needComplete == true)
            {
                SetTutorial(chapter, true);
            }
        }

        private CompleteCheck GetCompleteCheck(TutorialChapter chapter)
        {
            if (chapter == TutorialChapter.NewSea
                || chapter == TutorialChapter.FirstVisitToSea)
            {
                return CompleteCheck.Self;
            }
            else
            {
                return CompleteCheck.Server;
            }
        }
    }
}