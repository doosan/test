using Gaga;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine.Events;

namespace Underc.User
{
    public enum AquaBlitzPointRewardStatus
    {
        None = -1,
        InProgress = 0,
        Done = 1,
        Collected = 2
    }

    public enum AquaBlitzRemainingTime
    {
        Point,
        Mission
    }

    public class AquaBlitzPointRewardInfo : RewardInfo
    {
        public AquaBlitzPointRewardStatus status;
        public bool isBigIndex;

        public AquaBlitzPointRewardInfo(RewardType type, 
                                        long value, 
                                        long additionalValue = 0,
                                        bool skipEffect = false,
                                        AquaBlitzPointRewardStatus status = AquaBlitzPointRewardStatus.None,
                                        bool isBigIndex = false) : base(type, value, additionalValue, skipEffect)
        {
            this.status = status;
            this.isBigIndex = isBigIndex;
        }
    }

    public class AquaBlitzMissionInfo : IEquatable<AquaBlitzMissionInfo>
    {
        public int slotID;
        public string mission;
        public long curr;
        public long all;
        public long requirement;
        public int status;
        public MissionFormatInfo missionFormatInfo;
        public List<RewardInfo> rewardInfos;

        public int RewardInfoCount
        {
            get => rewardInfos.Count;
        }

        public AquaBlitzMissionInfo(int slotID, string mission, long curr, long all, long requirement, int status, List<RewardInfo> rewardInfos)
        {
            this.slotID = slotID;
            this.mission = mission;
            if (curr > all)
            {
                curr = all;
            }
            this.curr = curr;
            this.all = all;
            this.requirement = requirement;
            this.status = status;
            if (string.IsNullOrEmpty(mission) == false)
            {
                this.missionFormatInfo = new MissionFormatInfo(mission, all, requirement);
            }
            this.rewardInfos = rewardInfos;
        }

        public RewardInfo GetRewardInfo(int index)
        {
            return rewardInfos[index];
        }

        public AquaBlitzMissionInfo Clone()
        {
            return new AquaBlitzMissionInfo(slotID, mission, curr, all, requirement, status, rewardInfos.Select(rewardInfo => rewardInfo).ToList());
        }

        bool IEquatable<AquaBlitzMissionInfo>.Equals(AquaBlitzMissionInfo other)
        {
            return Equals(this, other);
        }

        public bool Equals(AquaBlitzMissionInfo other)
        {
            return Equals(this, other);
        }

        public static bool Equals(AquaBlitzMissionInfo x, AquaBlitzMissionInfo y)
        {
            bool isXnull = ReferenceEquals(x, null);
            bool isYnull = ReferenceEquals(y, null);

            bool isRewardsEqual = false;
            if (isXnull == false
                && isYnull == false
                && x.rewardInfos != null
                && y.rewardInfos != null
                && x.rewardInfos.Count == y.rewardInfos.Count)
            {
                isRewardsEqual = true;
                for (int i = 0; i < x.rewardInfos.Count; i++)
                {
                    RewardInfo xRewardInfo = x.rewardInfos[i];
                    RewardInfo yRewardInfo = y.rewardInfos[i];
                    isRewardsEqual &= xRewardInfo.Equals(yRewardInfo);
                }
            }

            return (isXnull && isYnull)
                   || (isXnull == false
                       && isYnull == false
                       && x.slotID == y.slotID
                       && x.mission == y.mission
                       && x.curr >= y.curr // A-1. 새로운 값(x)이 이전 값(y) 이상일 때만 같다고 인식하기
                                           // A-2. 새로운 값이 이전 값보다 작다면 새로 갱신된 데이터일 것임
                       && x.all == y.all
                       && isRewardsEqual == true);
        }

        public override string ToString()
        {
            return $"slotID : {slotID}, " +
                   $"mission : {mission}, " +
                   $"curr : {curr}, " +
                   $"all : {all}";
        }
    }

    public class MyAquaBlitz : IDisposable
    {
        public UnityEvent onDisplayInfoUpdate = new UnityEvent();
        public UnityEvent onTimeUpdate = new UnityEvent();

        public int Season
        {
            get;
            private set;
        }
        public int Step
        {
            get;
            private set;
        }
        public int StepIndex
        {
            get;
            private set;
        }
        public long Curr
        {
            get;
            private set;
        }
        public long All
        {
            get;
            private set;
        }
        public long PointEndRemainingSec
        {
            get;
            private set;
        } = -1;
        private long pointEndTs;

        public long MissionEndRemainingSec
        {
            get;
            private set;
        } = -1;
        private long missionEndTs;

        public int TotalRewardCount
        {
            get
            {
                int result = PointRewardCount;

                // 미션 리워드 카운트
                foreach (AquaBlitzMissionInfo missionInfo in missionInfos)
                {
                    if (missionInfo.all > 0
                        && missionInfo.curr == missionInfo.all)
                    {
                        result += 1;
                    }
                }
                return result;
            }
        }

        public int PointRewardCount
        { 
            get
            {
                int endRewardIndex = Step - 1;
                int startRewardIndex = MyInfo.AquaBlitz.GetNextPointRewardIndex();
                int result = endRewardIndex - startRewardIndex;
                //Debug.Log($"==== PointRewardCount : {endRewardIndex} - {startRewardIndex} = {result}");
                return result;
            }
        }

        public int PointRewardInfoCount
        {
            get => pointRewardInfos.Count;
        }
        private List<AquaBlitzPointRewardInfo> pointRewardInfos;

        public int MissionInfoCount
        {
            get => missionInfos.Count;
        }
        private List<AquaBlitzMissionInfo> missionInfos;
        private Dictionary<string, AquaBlitzMissionInfo> missionInfoDict;

        public int LatestMissionSpinIndex
        {
            get;
            private set;
        }

        private bool isMissionClicked;
        private bool isStepUpInProgress;
        private bool isPointRewardOpened;

        private GlobalTime globalTime;
        private long missionUpdateTs;

        public MyAquaBlitz()
        {
            globalTime = GlobalTime.Instance;
            globalTime.onUpdate += UpdateRemainingSec;

            pointRewardInfos = new List<AquaBlitzPointRewardInfo>();
            missionInfos = new List<AquaBlitzMissionInfo>();
            missionInfoDict = new Dictionary<string, AquaBlitzMissionInfo>();
        }

        public void Dispose()
        {
            globalTime.onUpdate -= UpdateRemainingSec;
        }

        public AquaBlitzPointRewardInfo GetPointRewardInfo(int index)
        {
            return pointRewardInfos[index];
        }

        public int GetNextPointRewardIndex()
        {
            int rewardIndex = -1;
            for (int i = 0; i < pointRewardInfos.Count; i++)
            {
                if (pointRewardInfos[i].status == AquaBlitzPointRewardStatus.Done)
                {
                    rewardIndex = i;
                    break;
                }
            }

            if (rewardIndex == -1)
            {
                for (int i = 0; i < pointRewardInfos.Count; i++)
                {
                    if (pointRewardInfos[i].status == AquaBlitzPointRewardStatus.InProgress)
                    {
                        rewardIndex = i;
                        break;
                    }
                }
            }

            if (rewardIndex == -1)
            {
                rewardIndex = 0;
            }

            //if (pointRewardInfos != null 
            //    && rewardIndex < pointRewardInfos.Count)
            //{
                //Debug.Log($"==== GetNextPointRewardIndex : {rewardIndex}, {pointRewardInfos[rewardIndex].status}");
            //}
            return rewardIndex;
        }

        public int GetCollectedPointRewardIndex()
        {
            int result = -1;

            int count = pointRewardInfos.Count - 1;
            for (int i = count; i >= 0; i--)
            {
                if (pointRewardInfos[i].status == AquaBlitzPointRewardStatus.Collected)
                {
                    result = i;
                    break;
                }
            }

            return result;
        }

        public AquaBlitzMissionInfo GetCurrentMissionInfo()
        {
            AquaBlitzMissionInfo result = null;
            if (LatestMissionSpinIndex != -1)
            {
                result = missionInfos[LatestMissionSpinIndex];
            }
            return result;
        }

        public AquaBlitzMissionInfo GetMissionInfo(int index)
        {
            return missionInfos[index];
        }

        public List<RewardInfo> AsRewardInfos(CommonRewardData[] rewardData)
        {
            List<RewardInfo> rewardInfos = new List<RewardInfo>();
            foreach (CommonRewardData data in rewardData)
            {
                Enum.TryParse(data.rwd, out RewardType rewardType);
                rewardInfos.Add(new RewardInfo(rewardType, data.val));
            }
            return rewardInfos;
        }

        public void UpdateCurr(long nextCurr)
        {
            Curr = nextCurr;
            isStepUpInProgress = Curr >= All;
        }

        public void UpdateStepAndCurr(int nextStep, long nextCurr)
        {
            Step = nextStep;
            Curr = nextCurr;
        }

        public void UpdateMissionClicked(bool value)
        {
            isMissionClicked = value;
        }

        public bool ConsumeMissionClicked()
        {
            bool result = isMissionClicked;
            isMissionClicked = false;

            return result;
        }

        public bool ConsumeStepUpInProgress()
        {
            bool result = isStepUpInProgress;
            isStepUpInProgress = false;

            return result;
        }

        public void UpdatePointRewardOpened(bool value)
        {
            isPointRewardOpened = value;
        }

        public bool ConsumePointRewardOpened()
        {
            bool result = isPointRewardOpened;
            isPointRewardOpened = false;

            return result;
        }

        public void Update(bool checkUpdateTs, long spinUpdateTs, AquaBlitzMissionSpinData missionSpinData)
        {
            if (missionSpinData != null)
            {
                int index = missionSpinData.index;
                long all = missionSpinData.all;
                LatestMissionSpinIndex = (all > 0) ? index : -1;
            
                if (checkUpdateTs == false
                    || (checkUpdateTs == true && spinUpdateTs > this.missionUpdateTs))
                {
                    if (missionSpinData != null && missionSpinData.all > 0)
                    {
                        long curr = missionSpinData.curr;
                        missionInfos[index].curr = curr;
                        onDisplayInfoUpdate?.Invoke();
                    }
                }
                //Debug.Log($"==== Update() : {checkUpdateTs}, {spinUpdateTs}, {missionUpdateTs}, {LatestMissionSpinIndex}");
            }
        }

        public void FindLatestMissionSpinIndex()
        {
            int.TryParse(MyInfo.SlotGame.currentSlotID, out int slotID);

            LatestMissionSpinIndex = -1;
            for (int i = 0; i < missionInfos.Count; i++)
            {
                AquaBlitzMissionInfo missionInfo = missionInfos[i];
                if (missionInfo.slotID == slotID)
                {
                    LatestMissionSpinIndex = i;
                    break;
                }
            }
        }

        public void UpdateLatestMissionSpinIndex(int index)
        {
            LatestMissionSpinIndex = index;
        }

        public void Update(long missionUpdateTs, AquaBlitzData data)
        {
            if (data != null
                && missionUpdateTs > this.missionUpdateTs)
            {
                this.missionUpdateTs = missionUpdateTs; // 현재 값보다 이전의 값은 무시

                isStepUpInProgress = false;
                Season = data.season;
                Step = data.step;
                StepIndex = data.step - 1;
                pointEndTs = data.end_ts;
                missionEndTs = data.mission_end_ts;
                Curr = data.curr;
                All = data.all;

                pointRewardInfos.Clear();
                for (int i = 0; i < data.types.Length; i++)
                {
                    string type = data.types[i];
                    long value = data.values[i];
                    int status = data.status[i];
                    bool isBigIndex = false;
                    if (data.big != null)
                    {
                        foreach (int bigIndex in data.big)
                        {
                            isBigIndex |= (bigIndex == i);
                        }
                    }

                    if (type == "")
                    {
                        type = RewardType.none.ToString();
                    }
                    RewardType rewardType;
                    if (Enum.TryParse(type, out rewardType) == true)
                    {
                        pointRewardInfos.Add(new AquaBlitzPointRewardInfo(rewardType, 
                                                                          value, 
                                                                          status: (AquaBlitzPointRewardStatus)status, 
                                                                          isBigIndex: isBigIndex));
                    }
                    else
                    {
                        Debug.LogWarning($"==== 존재하지 않는 리워드 타입입니다 : {type}");
                    }
                }

                missionInfos.Clear();
                missionInfoDict.Clear();
                for (int i = 0; i < data.mission.Length; i++)
                {
                    AquaBlitzMissionData missionData = data.mission[i];
                    int slotID = missionData.slotid;
                    string mission = missionData.mission;
                    long curr = missionData.curr;
                    long all = missionData.all;
                    long requirement = missionData.requirement;
                    int status = missionData.status;

                    List <RewardInfo> missionRewardInfos = null;
                    AquaBlitzMissionRewardData[] missionRewardDatas = missionData.reward;
                    if (missionRewardDatas != null)
                    {
                        missionRewardInfos = new List<RewardInfo>();
                        for (int j = 0; j < missionRewardDatas.Length; j++)
                        {
                            AquaBlitzMissionRewardData missionRewardData = missionRewardDatas[j];
                            string reward = missionRewardData.rwd;
                            long value = missionRewardData.val;

                            RewardType rewardType = RewardType.none;
                            if (Enum.TryParse(reward, out rewardType) == true)
                            {
                                missionRewardInfos.Add(new RewardInfo(rewardType, value));
                            }
                            else
                            {
                                Debug.LogWarning($"==== 존재하지 않는 리워드 타입입니다 : {reward}");
                            }
                        }
                    }
                    var missionInfo = new AquaBlitzMissionInfo(slotID, mission, curr, all, requirement, status, missionRewardInfos);
                    missionInfos.Add(missionInfo);
                    //Debug.Log($"==== Update.missionInfo : {missionInfo}");

                    string slotIdStr = slotID.ToString();
                    if (missionInfoDict.ContainsKey(slotIdStr) == false)
                    {
                        missionInfoDict.Add(slotIdStr, missionInfo);
                    }
                }

                UpdateRemainingSec(globalTime.GetTimeStamp());
                onDisplayInfoUpdate?.Invoke();
            }
        }

        private void UpdateRemainingSec(long serverTs)
        {
            bool isTimeUpdated = false;

            if (pointEndTs > 0)
            {
                isTimeUpdated = true;
                PointEndRemainingSec = globalTime.SecondDiff(pointEndTs);
            }

            if (missionEndTs > 0)
            {
                isTimeUpdated = true; 
                MissionEndRemainingSec = globalTime.SecondDiff(missionEndTs);
            }

            if (isTimeUpdated)
            {
                onTimeUpdate?.Invoke();
            }
        }
    }
}