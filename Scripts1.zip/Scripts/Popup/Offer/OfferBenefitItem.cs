using UnityEngine;
using TMPro;
using Gaga.Util;
using Gaga;
using Underc.User;

namespace Underc.Popup
{
    public class OfferBenefitItem : MonoBehaviour
    {
        [SerializeField] private GameObjectVisibleToggle classVisibleToggle = null;
        [SerializeField] private TextMeshProUGUI valueText = null;

        public void SetValue(string rwd, long value, string additionalInfo = "")
        {
            if (rwd == RewardData.FISH)
            {
                valueText.text = "1";
            }
            else if (rwd == RewardData.PEARL_TICKET_BOOSTER ||
                     rwd == RewardData.XP_BOOSTER)
            {
                valueText.text = value.ToBoosterRewardHM();
            }
            else if (rwd == RewardData.VIP_POINT)
            {
                classVisibleToggle.TurnOnByNameInMultiple(additionalInfo);
                valueText.text = StringUtils.ToKMB(value, 0);
            }
            else
            {
                valueText.text = StringUtils.ToKMB(value, 0);
            }
        }
    }
}