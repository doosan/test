using Gaga;
using Gaga.Popup;
using System;
using System.Collections;
using System.Collections.Generic;
using Underc;
using Underc.LoadingScreen;
using Underc.Net;
using Underc.Net.Client;
using Underc.Popup;
using UnityEngine;

public class TestSalePopups : TestSceneScaffold
{
    [Serializable]
    public class OfferBenefitInfo
    {
        public OfferBenefitType type;
        public long value;
    }

    public enum OfferBenefitType
    {
        pearl,
        ticket,
        golden,
        obsidian,
        xp_booster,
        pearl_ticket_booster,
        vip_point,
    }

    [Header("Offer Popup")]
    [SerializeField] private int endsInSeconds = 20;
    [SerializeField] private float priceWas = 49.9f;
    [SerializeField] private float price = 4.99f;
    [SerializeField] private long coin = 987654321;
    [SerializeField] private long offerVipPoint = 56700;
    [SerializeField] private OfferBenefitInfo benefitInfo1;
    [SerializeField] private OfferBenefitInfo benefitInfo2;
    [SerializeField] private OfferBenefitInfo benefitInfo3;
    [Space]
    [SerializeField] private string allInUrl = "https://aquuua-real.azureedge.net/popup/qa/38.png";
    [SerializeField] private string starterUrl = "https://aquuua-real.azureedge.net/popup/qa/42.png";
    [SerializeField] private string eventUrl = "https://aquuua-real.azureedge.net/popup/qa/53.png";
    [SerializeField] private string bigwinUrl = "https://aquuua-real.azureedge.net/popup/qa/44.png";
    [SerializeField] private string oceanUrl = "https://aquuua-real.azureedge.net/popup/qa/45.png";
    [SerializeField] private string swimmerUrl = "https://aquuua-real.azureedge.net/popup/qa/46.png";

    [Header("Mission Pass Popup")]
    [SerializeField] private TextAsset missionPassJson;
    [SerializeField] private long passVipPoint = 200000L;

    private Dictionary<string, Func<OfferData>> offerDataMakers;
    private List<string> offerTypes;
    private List<OfferData> offerDataList;
    private List<OfferBenefitData> benefitDataList;
    private Dictionary<OfferBenefitType, Func<long, OfferBenefitData>> benefitDataMakers;

    private IEnumerator Start()
    {
        Init();

        yield return SetupAndLoad(new BaseLoadingItem[]
        {
            new LoginLoadingItem(),
            new HTTPLoadingItem<ProfileResponse>(
                () => NetworkSystem.HTTPRequester.Profile(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new TopUILoadingItem(),
            new RewardBonusUILoadingItem(),
            new ABLoadingItem(Underc.Util.AssetBundleName.EFFECT),
        });
    }

    private void Init()
    {
        offerDataList = new List<OfferData>();
        benefitDataList = new List<OfferBenefitData>();
        SetupOfferDataMakers();
        SetupBenefitDataMakers();

        OfferSystem.Instance.Initialize();
        OfferSystem.Instance.RunAsFake = true;
    }

    #region OfferPopup
    private void SetupOfferDataMakers()
    {
        offerDataMakers = new Dictionary<string, Func<OfferData>>();
        offerDataMakers.Add(
            OfferSystem.CATEGORY_ALLIN, 
            () => MakeOfferData(OfferSystem.CATEGORY_ALLIN, allInUrl)
        );
        offerDataMakers.Add(
            OfferSystem.CATEGORY_STARTER,
            () => MakeOfferData(OfferSystem.CATEGORY_STARTER, starterUrl)
        );
        offerDataMakers.Add(
            OfferSystem.CATEGORY_EVENT,
            () => MakeOfferData(OfferSystem.CATEGORY_EVENT, eventUrl)
        );
        offerDataMakers.Add(
            OfferSystem.CATEGORY_BIGWIN,
            () => MakeOfferData(OfferSystem.CATEGORY_BIGWIN, bigwinUrl)
        );
        offerDataMakers.Add(
            OfferSystem.CATEGORY_OCEAN,
            () => MakeOfferData(OfferSystem.CATEGORY_OCEAN, oceanUrl)
        );
        offerDataMakers.Add(
            OfferSystem.CATEGORY_SWIMMER,
            () => MakeOfferData(OfferSystem.CATEGORY_SWIMMER, swimmerUrl)
        );

        offerTypes = new List<string>();
        foreach (string offerType in offerDataMakers.Keys)
        {
            offerTypes.Add(offerType);
        }
    }

    private void SetupBenefitDataMakers()
    {
        benefitDataMakers = new Dictionary<OfferBenefitType, Func<long, OfferBenefitData>>();
        benefitDataMakers.Add(
            OfferBenefitType.pearl,
            (value) => MakeBenefitData(RewardData.PEARL, value)
        );
        benefitDataMakers.Add(
            OfferBenefitType.ticket,
            (value) => MakeBenefitData(RewardData.TICKET, value)
        );
        benefitDataMakers.Add(
            OfferBenefitType.golden,
            (value) => MakeBenefitData(RewardData.GOLDEN, value)
        );
        benefitDataMakers.Add(
            OfferBenefitType.obsidian,
            (value) => MakeBenefitData(RewardData.OBSIDIAN, value)
        );
        benefitDataMakers.Add(
            OfferBenefitType.xp_booster,
            (value) => MakeBenefitData(RewardData.XP_BOOSTER, value)
        );
        benefitDataMakers.Add(
            OfferBenefitType.pearl_ticket_booster,
            (value) => MakeBenefitData(RewardData.PEARL_TICKET_BOOSTER, value)
        );
    }

    private OfferBenefitData MakeBenefitData(string rwd, long value)
    {
        var benefitData = new OfferBenefitData();
        benefitData.rwd = rwd;
        benefitData.val = value;
        return benefitData;
    }

    private void SetupOfferResponse(params OfferData[] offerDataArray)
    {
        offerDataList.Clear();
        offerDataList.AddRange(offerDataArray);

        var offerResponse = new OfferResponse();
        offerResponse.offer = offerDataList.ToArray();

        FakeHttpRequester.Instance.LoadedOfferResponse = offerResponse;

        FakeHttpRequester.Instance.LoadedPurchaseOfferResponse = (OfferInfo offerInfo) =>
        {
            var purchaseResponse = new PurchaseResponse();
            purchaseResponse.coin = offerInfo.Coins;
            purchaseResponse.vip_point = offerInfo.VipPoint;

            for (int i = 0; i < offerInfo.BenefitCount; i++)
            {
                OfferBenefitData benefitData = offerInfo.GetBenefit(i);
                string reward = benefitData.rwd;
                long value = benefitData.val;
                switch (reward)
                {
                    case RewardData.GOLDEN:
                        purchaseResponse.golden = value;
                        break;

                    case RewardData.OBSIDIAN:
                        purchaseResponse.obsidian = value;
                        break;

                    case RewardData.PEARL:
                        purchaseResponse.pearl = value;
                        break;

                    case RewardData.TICKET:
                        purchaseResponse.ticket = value;
                        break;

                    case RewardData.XP_BOOSTER:
                        purchaseResponse.xp_booster = value;
                        break;

                    case RewardData.PEARL_TICKET_BOOSTER:
                        purchaseResponse.pearl_booster = value;
                        break;
                }
            }
            return purchaseResponse;
        };
    }

    public void AllIn()
    {
        SetupOfferResponse(offerDataMakers[OfferSystem.CATEGORY_ALLIN]());
        StartCoroutine(OfferSystem.Instance.OpenAllin());
    }

    public void Starter()
    {
        SetupOfferResponse(offerDataMakers[OfferSystem.CATEGORY_STARTER]());
        StartCoroutine(OfferSystem.Instance.OpenGameLobby());
    }

    public void Event()
    {
        SetupOfferResponse(offerDataMakers[OfferSystem.CATEGORY_EVENT]());
        StartCoroutine(OfferSystem.Instance.OpenGameLobby());
    }

    public void BigWin()
    {
        SetupOfferResponse(offerDataMakers[OfferSystem.CATEGORY_BIGWIN]());
        StartCoroutine(OfferSystem.Instance.OpenBigwin(1));
    }

    public void Ocean()
    {
        SetupOfferResponse(offerDataMakers[OfferSystem.CATEGORY_OCEAN]());
        StartCoroutine(OfferSystem.Instance.OpenNewOcean());
    }

    public void Swimmier()
    {
        SetupOfferResponse(offerDataMakers[OfferSystem.CATEGORY_SWIMMER]());
        StartCoroutine(OfferSystem.Instance.OpenUniqueSwimmer());
    }

    public void Multiple()
    {
        int randomCount = UnityEngine.Random.Range(2, 4);
        OfferData[] offerDataArray = new OfferData[randomCount];
        for (int i = 0; i < randomCount; i++)
        {
            offerDataArray[i] = MakeOfferDataRandomly();
        }
        SetupOfferResponse(offerDataArray);
        StartCoroutine(OfferSystem.Instance.OpenGameLobby());
    }

    private OfferData MakeOfferDataRandomly()
    {
        int randomIndex = UnityEngine.Random.Range(0, offerDataMakers.Count);
        return offerDataMakers[offerTypes[randomIndex]]();
    }

    private OfferData MakeOfferData(string type, string imagePath)
    {
        OfferData data = new OfferData()
        {
            type = type,
            offer_id = UnityEngine.Random.Range(1, int.MaxValue),
            img_path = imagePath,
            item_id = "dummy_product_id",
            vip_point = offerVipPoint,
            price_was = priceWas,
            price = price,
            coin = coin,
            more = "100%",
            //end_ts = GetRandomTimeStamp(),
            end_ts = GetRandomTimeStamp(0, 0, 0, endsInSeconds),
            benefit = MakeDummyBenefits()
        };

        return data;
    }

    private T GetRandom<T>(T[] arr)
    {
        int randomIndex = UnityEngine.Random.Range(0, arr.Length);
        return arr[randomIndex];
    }

    private OfferBenefitData[] MakeDummyBenefits()
    {
        benefitDataList.Clear();
        benefitDataList.Add(benefitDataMakers[benefitInfo1.type](benefitInfo1.value));
        benefitDataList.Add(benefitDataMakers[benefitInfo2.type](benefitInfo2.value));
        benefitDataList.Add(benefitDataMakers[benefitInfo3.type](benefitInfo3.value));

        return benefitDataList.ToArray();
    }

    private static long GetRandomTimeStamp(int days = -1, int hours = -1, int min = -1, int sec = -1)
    {
        long nowTS = GlobalTime.Instance.GetTimeStamp();

        int d = days >= 0 ? days : UnityEngine.Random.Range(0, 30);
        int h = hours >= 0 ? hours : UnityEngine.Random.Range(0, 24);
        int m = min >= 0 ? min : UnityEngine.Random.Range(0, 60);
        int s = sec >= 0 ? sec : UnityEngine.Random.Range(0, 60);

        long randomTS = nowTS + (long)(new TimeSpan(d, h, m, s).TotalSeconds);
        return randomTS;
    }
    #endregion

    #region MissionPassPopup
    public void MissionPass()
    {
        OceansPassResponse response = JsonUtility.FromJson<OceansPassResponse>(missionPassJson.text);
        response.pass.buy.vip_point = passVipPoint;
        FakeHttpRequester.Instance.LoadedOceanPassResponse = () =>
        {
            return response;
        };

        PopupObject<MissionPassPopup> popupObject = null;
        popupObject = Popups.MissionPass(syncData: true,  
                                         onInit: () =>
                                         {
                                             if (popupObject != null)
                                             {
                                                 popupObject.GetPopup().RunAsFake = true;
                                             }
                                         })
                            .Async()
                            .Cache();
    }
    #endregion
}
