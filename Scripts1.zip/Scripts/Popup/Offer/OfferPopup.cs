using System;
using System.Collections;
using System.Collections.Generic;
using Gaga;
using Gaga.Attribute;
using Gaga.Popup;
using Gaga.Sound;
using Gaga.UI;
using Gaga.Util;
using TMPro;
using Underc.Net;
using Underc.Net.Client;
using Underc.UI;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Popup
{
    public class OfferPopup : PopupBackable
    {
        private readonly int ANIM_OPEN = Animator.StringToHash("Open");
        private readonly int ANIM_CLOSE = Animator.StringToHash("Close");

#pragma warning disable 0649
        [SerializeField] private float closeDuration = 14f/60f;
        [SerializeField] private ImageLoader loader;
        [SerializeField] private TextMeshProUGUI coinText;
        [SerializeField] private TextMeshProUGUI buyButtonText;
        [SerializeField] private SoundPlayer openSFX;
        [SerializeField] private Animator animator;
        [SerializeField] private Button buyButton;

        [Separator("Optional")]
        [Header("Price")]
        [SerializeField] private TextMeshProUGUI wasPriceText;
        [SerializeField] private TextMeshProUGUI priceText;
        [SerializeField] private TextMeshProUGUI moreText;

        [Header("Deal")]
        [SerializeField] private TextMeshProUGUI remainTimeText;

        [Header("Benefit")]
        [SerializeField] private RectTransform benefitContainer;

        [Header("BenefitPrefabs")]
        [SerializeField] private OfferBenefitItem itemGolden;
        [SerializeField] private OfferBenefitItem itemObsidian;
        [SerializeField] private OfferBenefitItem itemPearl;
        [SerializeField] private OfferBenefitItem itemPearlBooster;
        [SerializeField] private OfferBenefitItem itemTicket;
        [SerializeField] private OfferBenefitItem itemTicketBooster;
        [SerializeField] private OfferBenefitItem itemXPBooster;
        [SerializeField] private OfferBenefitItem itemVipPoint;

#pragma warning restore 0649

        public bool RunAsFake
        {
            set;
            private get;
        }

        private Action onPurchase;
        private OfferInfo info;
        private List<OfferBenefitItem> benefitItems;
        private long? offerRemainSec;

        protected override void Awake()
        {
            base.Awake();
            benefitItems = new List<OfferBenefitItem>();
        }

        protected override void OnDisable()
        {
            base.OnDisable();

            loader.sprite = null;
            GlobalTime.Instance.onUpdate -= OnGlobalTimeUpdate;
        }

        public void Open(OfferInfo info, Action onPurchase)
        {
            this.info = info;
            this.onPurchase = onPurchase;

            UndercGameLog.Fobis.PopupOffer(info.OfferType, info.OfferID, info.More, info.ProductID);

            Reset();

            StartCoroutine(OpenCoroutine());
        }

        private void Reset()
        {
            ClearBenefits();
            loader.color = new Color(1, 1, 1, 0);
            BuyButtonInteractable(true);
        }

        private void ClearBenefits()
        {
            for (int i = 0; i < benefitItems.Count; ++i)
            {
                OfferBenefitItem item = benefitItems[i];
                if (item != null)
                {
                    Destroy(item.gameObject);
                }
            }

            benefitItems.Clear();
        }

        private void BuyButtonInteractable(bool value)
        {
            buyButton.interactable = value;
        }

        private IEnumerator OpenCoroutine()
        {
            coinText.SetNumber(info.Coins, true);
            buyButtonText.text = string.Format(System.Globalization.CultureInfo.InvariantCulture, "${0}", info.Price);

            //optional
            UpdateWasPrice();
            UpdatePrice();
            UpdateMore();
            UpdateRemainTime();
            UpdateBenefits();

            //만약 구매제한시간이 있는 오퍼인 경우
            //통신 응답 시점에서는 비록 남은 시간이 있었더라도 팝업을 열려고 하는 타이밍에서 제한시간이 지났다면 팝업을 바로 닫는다
            //예외 적으로 1초라도 남은 경우는 팝업을 닫지 않으며 이후 시간이 흘러 0초가 된 경우 이미 열린 팝업은 닫지않는다 (기획팀 요청)
            if (offerRemainSec != null && offerRemainSec.Value == 0)
            {
                Close();
                yield break;
            }

            Popups.ShowLoading();
            loader.LoadFromRemote(info.ImagePath, OnLoadComplete);

            yield return new WaitWhile(() => loader.IsLoading);

            Popups.HideLoading();

            animator.SetTrigger(ANIM_OPEN);
            if (openSFX != null)
            {
                openSFX.Play();
            }

            yield break;
        }

        private void UpdateWasPrice()
        {
            if (wasPriceText != null)
            {
                if (info.WasPrice > 0f)
                {
                    wasPriceText.gameObject.SetActive(true);
                    wasPriceText.text = string.Format(System.Globalization.CultureInfo.InvariantCulture, "${0}", info.WasPrice);
                }
                else
                {
                    wasPriceText.gameObject.SetActive(false);
                }
            }
        }

        private void UpdatePrice()
        {
            if (priceText != null)
            {
                if (info.WasPrice > 0f)
                {
                    priceText.gameObject.SetActive(true);
                    priceText.text = string.Format(System.Globalization.CultureInfo.InvariantCulture, "${0}", info.Price);
                }
                else
                {
                    priceText.gameObject.SetActive(false);
                }
            }
        }

        private void UpdateMore()
        {
            if (moreText != null)
            {
                if (string.IsNullOrEmpty(info.More) == false)
                {
                    moreText.gameObject.SetActive(true);
                    moreText.text = info.More;
                }
                else
                {
                    moreText.gameObject.SetActive(false);
                }
            }
        }

        private void UpdateBenefits()
        {
            if (benefitContainer == null)
            {
                return;
            }

            //
            if (info.BenefitCount == 0)
            {
                benefitContainer.gameObject.SetActive(false);
            }
            else
            {
                benefitContainer.gameObject.SetActive(true);

                for (int i = 0; i < info.BenefitCount; i++)
                {
                    OfferBenefitData benefitData = info.GetBenefit(i);
                    Debug.LogFormat("UpdateBenefits. index: {0}, rwd: {1} val: {2}", i, benefitData.rwd, benefitData.val);

                    AddBenefitItem(benefitData.rwd, benefitData.val);
                }

            }

            //
            if (info.VipPoint > 0)
            {
                benefitContainer.gameObject.SetActive(true);

                AddBenefitItem(RewardData.VIP_POINT, info.VipPoint, MyInfo.VipClass.Type.ToString());
            }
        }

        private void AddBenefitItem(string rwd, long val, string additionalInfo = "")
        {
            OfferBenefitItem[] prefabs = GetBenefitItemPrefab(rwd);
            if (prefabs == null)
            {
                Debug.LogWarningFormat("{0} is invalid benefit reward", rwd);
                return;
            }

            foreach (var prefab in prefabs)
            {
                OfferBenefitItem item = Instantiate(prefab, benefitContainer);
                item.SetValue(rwd, val, additionalInfo);
                benefitItems.Add(item);
            }
        }

        private bool TryGetBenefitValue(string rwd, out long value)
        {
            OfferBenefitData found = null;
            for (int i = 0; i < info.BenefitCount; i++)
            {
                OfferBenefitData benefitData = info.GetBenefit(i);
                if (benefitData.rwd == rwd)
                {
                    found = benefitData;
                    break;
                }
            }

            if (found == null)
            {
                value = 0L;
                return false;
            }
            else
            {
                value = found.val;
                return true;
            }
        }

        //사업 요청으로 PEARL_TICKET_BOOSTER 는 보상이 많아 보이도록 2개로 나눠서 표시
        private OfferBenefitItem[] GetBenefitItemPrefab(string rwd)
        {
            if (rwd == RewardData.GOLDEN) return new OfferBenefitItem[] { itemGolden };
            else if (rwd == RewardData.OBSIDIAN) return new OfferBenefitItem[] { itemObsidian };
            else if (rwd == RewardData.PEARL) return new OfferBenefitItem[] { itemPearl };
            else if (rwd == RewardData.TICKET) return new OfferBenefitItem[] { itemTicket };
            else if (rwd == RewardData.XP_BOOSTER) return new OfferBenefitItem[] { itemXPBooster };
            else if (rwd == RewardData.PEARL_TICKET_BOOSTER) return new OfferBenefitItem[] { itemPearlBooster, itemTicketBooster };
            else if (rwd == RewardData.VIP_POINT) return new OfferBenefitItem[] { itemVipPoint };
            return null;
        }

        private void UpdateRemainTime()
        {
            if (remainTimeText != null)
            {
                if (info.EndTs > 0)
                {
                    remainTimeText.gameObject.SetActive(true);
                    offerRemainSec = GlobalTime.Instance.SecondDiff(info.EndTs);
                    remainTimeText.text = offerRemainSec.Value.ToSummaryDHMS();

                    if (offerRemainSec.Value > 0)
                    {
                        GlobalTime.Instance.onUpdate += OnGlobalTimeUpdate;
                    }
                }
                else
                {
                    remainTimeText.gameObject.SetActive(false);
                }
            }
        }

        private void OnGlobalTimeUpdate(long serverTs)
        {
            offerRemainSec = GlobalTime.Instance.SecondDiff(info.EndTs);
            remainTimeText.text = offerRemainSec.Value.ToSummaryDHMS();
            if (offerRemainSec.Value == 0)
            {
                GlobalTime.Instance.onUpdate -= OnGlobalTimeUpdate;
            }
        }

        private void OnLoadComplete(ImageLoader loader)
        {
            if (loader.sprite != null)
            {
                loader.Image.color = new Color(1, 1, 1, 1);
                // loader.Image.color = new Color(1, 1, 1, 0);
                // loader.Image.DOFade(1f, 0.2f);
            }
            else
            {
                loader.Image.color = new Color(1, 1, 1, 0);
            }
        }

        public void OnBuyClick()
        {
            BuyButtonInteractable(false);

            StartCoroutine(BuyCoroutine());
        }

        private IEnumerator BuyCoroutine()
        {
            Popups.ShowLoading();
            IRequest<OfferResponse> offerBuyReq;
            if (RunAsFake == false)
            {
                offerBuyReq = NetworkSystem.HTTPRequester.OfferBuy(info.OfferID);
            }
            else
            {
                offerBuyReq = FakeHttpRequester.Instance.OfferBuy();
            }
            yield return offerBuyReq.WaitForResponse();
            Popups.HideLoading();

            bool offerAuthorized = offerBuyReq.isSuccess;
            if (offerAuthorized == false)
            {
                CloseByError(offerBuyReq.data.error);
                yield break;
            }

            if (RunAsFake == false)
            {
                yield return PurchaseSystem.Instance.Purchase(itemID: info.ProductID,
                                                              offerID: info.OfferID,
                                                              showReward: true);
            }
            else
            {
                Popups.ShowLoading();
                var req = FakeHttpRequester.Instance.PurchaseOffer(info);
                yield return req.WaitForResponse();
                Popups.HideLoading();

                PurchaseSystem purchaseSystem = PurchaseSystem.Instance;
                purchaseSystem.ShowReward = true;
                purchaseSystem.ExtractRewardDatas(req.data);
                yield return purchaseSystem.Reward();
            }

            // 스토어 결제 모듈이 올라온 상태에서 결제 취소 했을 때는 팝업을 유지해 줌
            if (PurchaseSystem.Instance.IsFailed == false)
            {
                if (MyInfo.VipClass.ConsumeLevelUp())
                {
                    animator.SetTrigger(ANIM_CLOSE);
                    yield return new WaitForSeconds(closeDuration);
                    yield return Popups.VipLevelUpCoroutine();
                }

                if (onPurchase != null)
                {
                    onPurchase.Invoke();
                }

                Close();
            }
            else
            {
                BuyButtonInteractable(true);
            }
        }

        private void CloseByError(string errorMessage)
        {
            Popups.Warning(message: errorMessage,
                           actionType: WarningPopup.ActionType.None,
                           titleType: WarningPopup.TitleType.Network,
                           useCloseButton: false,
                           onOK: () =>
                           {
                               Close();
                           });
        }
    }
}