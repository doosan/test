using Gaga.Popup;
using System;
using System.Collections;
using TMPro;
using Underc.Net;
using Underc.Popup;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace Underc
{
    public enum TargetToMove
    {
        None = 0,
        Shop = 10,
        Grow = 11,
        Inbox = 12,
        Url = 13,
        OceanStory = 100,
        Slot = 1000,
    }

    public abstract class BaseAdminPopup : PopupBackable
    {
        private readonly int TRIGGER_OPEN = Animator.StringToHash("Open");

        [SerializeField] protected Image imageLoader = null;
        [FormerlySerializedAs("buttonName")]
        [SerializeField] protected TextMeshProUGUI buttonNameText = null;
        [FormerlySerializedAs("anim")]
        [SerializeField] protected Animator animator = null;
        [SerializeField] protected Toggle dontShowToggle = null;
        [SerializeField] protected bool useCache = true;

        private bool initOnce;
        private Version currentVersion;

        private string requiredVersionStr;
        private string buttonName;
        private string imageUrl;
        private Action<bool> onExecute;
        private Action<bool> onComplete;

        private DownloadSystem.ID downloadID;
        private bool needToUpdate;

        protected virtual void Init()
        {
            if (initOnce == false)
            {
                initOnce = true;

                currentVersion = Version.Parse(Application.version);
            }
        }

        public void Open(string requiredVersionStr,
                         string buttonName,
                         string imageUrl,
                         Action<bool> onExecute = null,
                         Action<bool> onComplete = null)
        {
            this.requiredVersionStr = requiredVersionStr;
            this.buttonName = buttonName;
            this.imageUrl = imageUrl;
            this.onExecute = onExecute;
            this.onComplete = onComplete;

            Init();
            Reset();
            UpdateContent();

            StartCoroutine(LoadCoroutine());
        }

        protected virtual void Reset()
        {
            dontShowToggle.isOn = false;
            imageLoader.enabled = false;
        }

        protected virtual void UpdateContent()
        {
            Version requiredVersion;
            needToUpdate = string.IsNullOrEmpty(requiredVersionStr) == false
                           && Version.TryParse(requiredVersionStr, out requiredVersion) == true
                           && currentVersion < requiredVersion;

            buttonNameText.text = needToUpdate == true ?
                                  "UPDATE" :
                                  buttonName;
        }

        private IEnumerator LoadCoroutine()
        {
            yield return LoadImage();

            animator.SetTrigger(TRIGGER_OPEN);
            yield break;
        }

        private IEnumerator LoadImage()
        {
            Popups.ShowLoading();

            bool waitForDone = false;
            Sprite loadedSprite = null;
            downloadID = DownloadSystem.Instance.GetSprite(
                url: imageUrl,
                onComplete: sprite =>
                {
                    waitForDone = true;
                    loadedSprite = sprite;
                },
                useCache
            );

            yield return new WaitUntil(() => waitForDone);

            if (loadedSprite != null)
            {
                imageLoader.sprite = loadedSprite;
                imageLoader.enabled = true;
                imageLoader.SetNativeSize();
            }
            else
            {
                imageLoader.sprite = null;
            }

            downloadID.value = null;

            Popups.HideLoading();
            yield break;
        }

        public virtual void Execute()
        {
            onExecute?.Invoke(needToUpdate);
            Close();
        }

        private void OnAnimatorClose()
        {
            onComplete?.Invoke(dontShowToggle.isOn);

            imageLoader.sprite = null;
            if (downloadID.value != null)
            {
                DownloadSystem.Instance.Abort(downloadID);
            }
        }

        public override bool CanBack()
        {
            return Popups.IsLoading() == false && base.CanBack();
        }
    }
}
