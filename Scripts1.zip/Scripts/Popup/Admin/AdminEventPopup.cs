using Gaga;
using Gaga.Util;
using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Popup
{
    public enum BigwinType
    {
        none,
        epic = 100,
        mega = 50,
        huge = 30,
        big = 10,
    }

    public class AdminEventPopup : BaseAdminPopup
    {
        [SerializeField] private GameObjectVisibleToggle challengeTypeVisibleToggle;
        [SerializeField] private GameObjectVisibleToggle winTypeVisibleToggle;
        [SerializeField] private TextMeshProUGUI winCountText;
        [SerializeField] private Slider winCountSlider;
        [SerializeField] private TextMeshProUGUI currText;
        [SerializeField] private TextMeshProUGUI rewardText;
        [SerializeField] private TextMeshProUGUI rewardShadowText;
        [SerializeField] private GameObject timeIcon;
        [SerializeField] private TextMeshProUGUI remainingTimeText;

        private BigwinType bigwinType;
        private long winCount;
        private long curr;
        private long reward;
        private long endTime;
        private AdminEventData adminEventData;

        public void Open(AdminEventData data,
                         Action<bool> onExecute = null, 
                         Action<bool> onComplete = null)
        {
            adminEventData = data;

            Debug.Log($"==== AdminEventPopup.Open : {data.ver}, {data.btn}, {data.img}, {data.win_type}, {data.win_count}, {data.cur}");

            this.bigwinType = BigwinType.none;
            Enum.TryParse(data.win_type, out bigwinType);
            this.winCount = data.win_count;
            this.curr = Math.Min(data.cur, winCount);
            this.reward = data.reward;
            this.endTime = (long)data.end_ts;

            base.Open(data.ver,
                      data.btn,
                      data.img,
                      onExecute,
                      onComplete);
        }

        protected override void Reset()
        {
            base.Reset();
            
        }

        protected override void OnDisable()
        {
            base.OnDisable();

            GlobalTime.Instance.onUpdate -= OnGlobalTimeUpdate;
        }

        protected override void UpdateContent()
        {
            base.UpdateContent();

            challengeTypeVisibleToggle.TurnOnByNameInMultiple(bigwinType.ToString());
            winTypeVisibleToggle.TurnOnByNameInMultiple(bigwinType.ToString());

            string winCountStr = winCount.ToString();
            winCountText.text = winCountStr;
            currText.text = $"{curr} / {winCountStr}";

            float progress = curr / (float)winCount;
            winCountSlider.value = progress;

            string rewardStr = $"WIN {StringUtils.ToComma(reward)}";
            rewardText.text = rewardStr;
            rewardShadowText.text = rewardStr;

            GlobalTime.Instance.onUpdate += OnGlobalTimeUpdate;
            UpdateRemainingTime();
        }

        private void UpdateRemainingTime()
        {
            long remainingSec = GlobalTime.Instance.SecondDiff(endTime);
            if (remainingSec > 0)
            {
                timeIcon.SetActive(true);
                remainingTimeText.text = remainingSec.ToSummaryDHMS();
            }
            else
            {
                timeIcon.SetActive(false);
                remainingTimeText.text = "EVENT FINISHED";
                GlobalTime.Instance.onUpdate -= OnGlobalTimeUpdate;
            }
        }

        private void OnGlobalTimeUpdate(long serverTs)
        {
            UpdateRemainingTime();
        }

        public override void Execute()
        {
            SendLog(1);
            base.Execute();
        }

        public void OnCloseButtonClicked()
        {
            SendLog(2);
            Close();
        }

        public override void GoBack()
        {
            SendLog(2);
            base.GoBack();
        }

         // buttonType - 1 : 팝업 하단 버튼, 2 : 닫기 버튼
        private void SendLog(int buttonType)
        {
            UndercGameLog.Fobis.EventButton(buttonType, adminEventData.id, adminEventData.target1, adminEventData.target2, adminEventData.win_type, adminEventData.win_count);
        }
    }
}