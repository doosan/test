using System;
using Underc.User;

namespace Underc.Popup
{
    public class AdminNoticePopup : BaseAdminPopup
    {
        private AdminNoticeData adminNoticeData;

        public void Open(AdminNoticeData data,
                         Action<bool> onExecute = null,
                         Action<bool> onComplete = null)
        {
            adminNoticeData = data;

            Open(data.ver, data.btn, data.img, onExecute, onComplete);

            Debug.Log("AdminNoticePopup Open - " + adminNoticeData.ToString());

            if (IsSlotType())
            {
                var popupID = (int)data.id;
                var slotID = data.target2.ToString();

                MyInfo.SlotGame.IncreaseNewSlotPopupViewCount(popupID, slotID); 
                CheckAndSendFirstOpenLog(popupID, slotID);
            }
        }

        public override void Execute()
        {
            SendButtonLog(1);

            if (IsSlotType())
            {
                string slotID = adminNoticeData.target2.ToString();
                SendNewSlotEnterLog(slotID);
            }

            base.Execute();
        }

        public void OnCloseButtonClicked()
        {
            SendButtonLog(2);
            Close();
        }

        public override void GoBack()
        {
            SendButtonLog(2);
            base.GoBack();
        }

        private bool IsSlotType()
        {
            return adminNoticeData != null && adminNoticeData.target1 == (int)TargetToMove.Slot;
        }

         // buttonType - 1 : 팝업 하단 버튼, 2 : 닫기 버튼
        private void SendButtonLog(int buttonType)
        {
            UndercGameLog.Fobis.NoticeButton(buttonType, adminNoticeData.id, adminNoticeData.target1, adminNoticeData.target2);
        }

        private void SendNewSlotEnterLog(string slotID)
        {
            var newSlotInfos = MyInfo.SlotGame.GetNewSlotInfoListForValidPopupID(slotID);

            // 엔터 시 모든 팝업 아이디에 해당하는 로그를 보내야함.
            for (int i = 0; i < newSlotInfos.Count; i++)
            {
                var info = newSlotInfos[i];

                if (info.isEnter)
                {
                    continue;
                }

                UndercGameLog.Fobis.NewSlotFirstEnter(info.slotID, 1, info.popupID, info.popupViewCount, info.posterViewCount);
            }

            MyInfo.SlotGame.SetNewSlotEnter(slotID);
            MyInfo.SlotGame.SaveNewSlotInfoList();
        }

        private void CheckAndSendFirstOpenLog(int popupID, string slotID)
        {
            var newSlotInfo = MyInfo.SlotGame.GetNewSlotInfo(popupID);

            // 신규 슬롯 팝업이 처음 노출 됐을 때 로그를 보냄
            if (newSlotInfo != null && newSlotInfo.popupViewCount == 1)
            {
                UndercGameLog.Fobis.NewSlotPopupFirstView(newSlotInfo.popupID, newSlotInfo.slotID);
                MyInfo.SlotGame.SaveNewSlotInfoList();
            }
        }
    }
}
