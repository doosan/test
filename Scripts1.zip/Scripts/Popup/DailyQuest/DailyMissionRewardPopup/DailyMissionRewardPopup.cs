using Gaga.Popup;
using Gaga.Sound;
using Gaga.System;
using System.Collections;
using System.Collections.Generic;
using Underc.Net;
using Underc.Net.Client;
using Underc.UI;
using Underc.User;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace Underc.Popup
{
    public enum DailyMissionRewardPopupState
    {
        None,
        OpenReward,
        OpenNext,
        OpenMissionPass,
        LoadItemClaim,
        SetItemRewardPanel,
        UpdateContent,
        Collect,
        CheckNext,
        LoadPointClaim,
        MoveToNextMission,
        SetPointRewardPanel,
        WaitForAutoProgress,
        Release
    }

    public class DailyMissionRewardPopup : HighlightPopup
    {
        [SerializeField] private SoundPlayer rewardOpenSound;
        [SerializeField] private float itemOpenInterval = 1f;
        [SerializeField] private float autoProgressDelay = 10f;
        [FormerlySerializedAs("itemRewardLayer")]
        [SerializeField] private DailyMissionItemRewardPanel itemRewardPanel;
        [FormerlySerializedAs("pointRewardLayer")]
        [SerializeField] private DailyMissionPointRewardPanel pointRewardPanel;
        [SerializeField] private RectTransform uiRoot;

        public List<SimpleRewardItemCollector> RewardItemCollectors
        {
            get
            {
                if (rewardItemCollectors == null)
                {
                    rewardItemCollectors = new List<SimpleRewardItemCollector>();
                    rewardItemCollectors.Add(itemRewardPanel.ItemCollector);
                    rewardItemCollectors.Add(pointRewardPanel.ItemCollector);
                }
                return rewardItemCollectors;
            }
        }
        private List<SimpleRewardItemCollector> rewardItemCollectors;

        public bool RunAsFake
        {
            set;
            private get;
        }

        public bool IsPointRewarded
        {
            get;
            private set;
        }

        public MissionPassPopup MissionPassPopup
        {
            get;
            private set;
        }
        private PopupObject<MissionPassPopup> missionPassPopupObject;

        private StateQueue<DailyMissionRewardPopupState> stateQueue;
        private bool initOnce;

        private List<BaseDailyMissionRewardPanel> panels;
        private BaseDailyMissionRewardPanel currentPanel;

        private DailyMissionDisplay clonedDisplay;
        public DailyMissionPointGauge OriginPointGauge
        {
            get;
            private set;
        }
        private DailyMissionPointGauge clonedPointGauge;
        private bool autoContinueEnabled;

        private HighlightObjectInfo dailyMissionGaugeInfo;
        private HighlightObjectInfo dailyMissionDisplayInfo;

        private HighlightObjectInfo missionPassTabInfo;

        protected override void OnEnable()
        {
            base.OnEnable();

            Init();
            Reset();
        }

        private void Init()
        {
            if (initOnce == false)
            {
                initOnce = true;

                panels = new List<BaseDailyMissionRewardPanel>()
                {
                    itemRewardPanel, pointRewardPanel
                };
                foreach (BaseDailyMissionRewardPanel panel in panels)
                {
                    panel.Init();
                }

                stateQueue = new StateQueue<DailyMissionRewardPopupState>(host: this);
            }
        }

        public bool ConsumePointRewarded()
        {
            bool result = IsPointRewarded;
            IsPointRewarded = false;

            return result;
        }

        private void SetPanelOn(BaseDailyMissionRewardPanel panel)
        {
            currentPanel = panel;
            currentPanel.gameObject.SetActive(true);
        }

        private void SetPanelOff(BaseDailyMissionRewardPanel panel)
        {
            panel.gameObject.SetActive(false);
        }

        public void Open(DailyMissionDisplay originDisplay, bool autoContinueEnabled)
        {
            this.autoContinueEnabled = autoContinueEnabled;

            dailyMissionDisplayInfo = new HighlightObjectInfo(
                originTransform: originDisplay.CachedTransform,
                visibleType: HighlightVisibleType.Alpha,
                initialActive: true
            );
            base.Register(dailyMissionDisplayInfo);
            clonedDisplay = dailyMissionDisplayInfo.clonedTransform.GetComponent<DailyMissionDisplay>();

            stateQueue.Reset();
            stateQueue.Add(DailyMissionRewardPopupState.OpenMissionPass);
            stateQueue.Add(DailyMissionRewardPopupState.LoadItemClaim);
        }

        private IEnumerator OpenMissionPassCoroutine()
        {
            bool waitForOpen = true;

            missionPassPopupObject = null;
            MissionPassPopup = null;
            missionPassPopupObject = Popups.MissionPass(tab: MissionPassPopupTab.DailyMission,
                                                        syncData: false,
                                                        interactable: false,
                                                        onInit: () =>
                                                        {
                                                            waitForOpen = false;

                                                            MissionPassPopup = missionPassPopupObject.GetPopup();
                                                            MissionPassPopup.RunAsFake = RunAsFake;
                                                        })
                                           .Async()
                                           .Cache()
                                           .SetOrder(-1);
            while (waitForOpen == true)
            {
                yield return null;
            }

            // A-1 미션 팝업이 열린 후 미션 패스 탭 복제
            missionPassTabInfo = new HighlightObjectInfo(
                originTransform: MissionPassPopup.TabTransformInfo.TabTransform(MissionPassPopupTab.MissionPass),
                visibleType: HighlightVisibleType.Alpha,
                initialActive: false
            );
            base.Register(missionPassTabInfo);

            // A-2 복제품은 연출 용도이므로 ToggleGroup 및 이벤트 리스너를 제거한다
            Toggle missionPassToggle = missionPassTabInfo.clonedTransform.GetComponent<Toggle>();
            missionPassToggle.onValueChanged.RemoveAllListeners();
            missionPassToggle.group = null;
            missionPassToggle.isOn = true;

            // B-1 미션 팝업이 열린 후 데일리 미션 게이지 복제
            RectTransform pointGaugeTransform = MissionPassPopup.GetPointGaugeTransform(MissionPassPopupTab.DailyMission);
            OriginPointGauge = pointGaugeTransform.GetComponent<DailyMissionPointGauge>();

            dailyMissionGaugeInfo = new HighlightObjectInfo(
                originTransform: pointGaugeTransform,
                visibleType: HighlightVisibleType.Alpha,
                initialActive: false
            );
            base.Register(dailyMissionGaugeInfo);

            // B-2 복제품은 연출 용도이므로 Animator 를 비활성화 한다.
            Animator dailyMissionGaugeAnimator = dailyMissionGaugeInfo.clonedTransform.GetComponent<Animator>();
            dailyMissionGaugeAnimator.enabled = false;

            clonedPointGauge = dailyMissionGaugeInfo.clonedTransform.GetComponent<DailyMissionPointGauge>();

            if (missionPassPopupObject.GetPopup().IsInLoading == true)
            {
                yield return null;
            }
        }

        private IEnumerator LoadItemClaimCoroutine()
        {
            Popups.ShowLoading();
            IRequest<DailyMissionItemClaimResponse> req;
            if (RunAsFake == false)
            {
                req = NetworkSystem.HTTPRequester.DailyMissionItemClaim();
            }
            else
            {
                req = FakeHttpRequester.Instance.DailyMissionItemClaim();
            }
            yield return req.WaitForResponse();
            Popups.HideLoading();

            if (req.isSuccess)
            {
                MyInfo.DailyMission.Update(updateTs: req.data.ts,
                                           reward: req.data.reward,
                                           data: req.data.daily_quest);
                MyInfo.MissionPass.UpdateStep(req.data.mission_pass_step);
            }
            else
            {
                OpenErrorPopup(req.data.error);
            }

            int prevStep = MyInfo.DailyMission.PrevStep;
            DailyMissionInfo nextQuestInfo = MyInfo.DailyMission.Info;
            List<RewardInfo> rewardInfos = MyInfo.DailyMission.ConsumeMissionRewardInfos();
            if (rewardInfos.Count > 0)
            {
                itemRewardPanel.Setup(prevStep,
                                      nextQuestInfo,
                                      rewardInfos,
                                      OnAnimationEvent);
                stateQueue.Add(DailyMissionRewardPopupState.SetItemRewardPanel);
                stateQueue.Add(DailyMissionRewardPopupState.UpdateContent);
            }
            else
            {
                stateQueue.Add(DailyMissionRewardPopupState.Release);
            }
        }

        private IEnumerator SetItemRewardPanelCoroutine()
        {
            yield return clonedDisplay.Full();
            SetPanelOn(itemRewardPanel);
        }

        private void OnAnimationEvent(string name)
        {
            if (name == "rewardOpen")
            {
                rewardOpenSound?.Play();
            }
            else if (name == "reward")
            {
                stateQueue.Add(DailyMissionRewardPopupState.OpenReward);
                
                if (autoContinueEnabled == true)
                {
                    stateQueue.Add(DailyMissionRewardPopupState.WaitForAutoProgress);
                    stateQueue.Add(DailyMissionRewardPopupState.Collect);
                    stateQueue.Add(DailyMissionRewardPopupState.CheckNext);
                }
            }
            else if (name == "next")
            {
                stateQueue.Add(DailyMissionRewardPopupState.OpenNext);

                if (autoContinueEnabled == true)
                {
                    stateQueue.Add(DailyMissionRewardPopupState.WaitForAutoProgress);
                    stateQueue.Add(DailyMissionRewardPopupState.Release);
                }
            }
        }

        private IEnumerator OpenRewardCoroutine()
        {
            if (currentPanel.ItemCollector.CanOpen == true)
            {
                yield return currentPanel.ItemCollector.OpenCoroutine(GetInterval);
                currentPanel.OpenButton("reward");
            }

            yield break; 
        }

        private IEnumerator OpenNextCoroutine()
        {
            currentPanel.OpenButton("next");
            yield break; 
        }

        private float GetInterval(RewardInfo rewardInfo)
        {
            return itemOpenInterval;
        }

        private void Reset()
        {
            IsPointRewarded = false;

            foreach (BaseDailyMissionRewardPanel panel in panels)
            {
                panel.Reset();
                panel.gameObject.SetActive(false);
            }
        }

        private IEnumerator UpdateContentCoroutine()
        {
            yield return currentPanel.UpdateContent();
        }

        public void Collect()
        {
            stateQueue.Reset();
            stateQueue.Add(DailyMissionRewardPopupState.Collect);
            stateQueue.Add(DailyMissionRewardPopupState.CheckNext);
        }

        private IEnumerator CollectCoroutine()
        {
            uiRoot.SetAsLastSibling();

            int currentPanelIndex = panels.FindIndex(_panel => _panel == currentPanel);
            SimpleRewardItemCollector rewardItemCollector = RewardItemCollectors[currentPanelIndex];

            var missionPassPointTransition = MissionPassPointTransition.GetOrAdd(gameObject);
            missionPassPointTransition.Setup(rewardItemCollector, missionPassTabInfo);

            // 미션 패스 팝업의 게임 오브젝트에 타겟팅
            rewardItemCollector.RegisterEndPosition(RewardType.g_pickaxe, MissionPassPopup.TabTransformInfo.TabPosition(MissionPassPopupTab.ClamHarvest));
            rewardItemCollector.RegisterEndPosition(RewardType.weekly_point, MissionPassPopup.GetPointGuagePosition(MissionPassPopupTab.DailyMission));
            rewardItemCollector.OnEffectShow.AddListener((RewardType rewardType) =>
            {
                if (rewardType == RewardType.weekly_point)
                {
                    dailyMissionGaugeInfo.SetCloneActive(true);
                    clonedPointGauge.UpdateContent(isProgressive: false, isPointRefreshed: false);
                }
            });
            rewardItemCollector.OnEffectFirstArrived.AddListener((RewardType rewardType) =>
            {
                if (rewardType == RewardType.weekly_point)
                {
                    // B-3 Animator 를 사용하기 위해 다시 활성화
                    clonedPointGauge.GetComponent<Animator>().enabled = true;
                    clonedPointGauge.Grow();
                    clonedPointGauge.UpdateContent(isProgressive: true, isPointRefreshed: false);
                    OriginPointGauge.UpdateContent(isProgressive: true, isPointRefreshed: false);

                    MissionPassPopup.UpdateProgressiveContent(MissionPassPopupTab.DailyMission, UpdateSpecificContentType.Point);
                }
            });

            bool waitForComplete = true;
            rewardItemCollector.OnEffectComplete.AddListener(() =>
            {
                waitForComplete = false;
            });

            yield return currentPanel.Collect();

            while (waitForComplete)
            {
                yield return null;
            }

            dailyMissionGaugeInfo.SetCloneActive(isOn: false, keepFade: true);
            yield return new WaitForSeconds(.3f);

            yield return missionPassPointTransition.WaitForDone();
        }

        private IEnumerator CheckNextCoroutine()
        {
            DailyMissionPointInfo pointInfo = MyInfo.DailyMission.PointInfo;
            if (currentPanel is DailyMissionItemRewardPanel
                && pointInfo.state != DailyMissionPointState.Complete
                && pointInfo.curr >= pointInfo.all)             // A-1. 포인트 보상 획득
            {
                stateQueue.Add(DailyMissionRewardPopupState.LoadPointClaim);
            }
            else if (itemRewardPanel.NextQuestInfo.step == 0)   // A-2. 데일리 미션 전체 완료
            {
                SetPanelOff(pointRewardPanel);
                SetPanelOn(itemRewardPanel);
                yield return itemRewardPanel.Next();            // A-3. 이후 이벤트에 의해 OnAnimationEvent() 로직이 수행됨
            }
            else if (itemRewardPanel.NextQuestInfo.step > 0)
            {
                stateQueue.Add(DailyMissionRewardPopupState.Release);
            }

            yield break;
        }

        private IEnumerator LoadPointClaimCoroutine()
        {
            Popups.ShowLoading();
            IRequest<DailyMissionPointClaimResponse> req;
            if (RunAsFake == false)
            {
                req = NetworkSystem.HTTPRequester.DailyMissionPointClaim();
            }
            else
            {
                req = FakeHttpRequester.Instance.DailyMissionPointClaim();
            }
            yield return req.WaitForResponse();
            Popups.HideLoading();

            if (req.isSuccess)
            {
                NetworkSystem.HTTPHandler.Do(req.data);
            }
            else
            {
                OpenErrorPopup(req.data.error);
            }

            List<RewardInfo> rewardInfos = MyInfo.DailyMission.ConsumePointRewardInfos();
            if (rewardInfos.Count > 0)
            {
                IsPointRewarded = true;
                pointRewardPanel.Setup(rewardInfos: rewardInfos,
                                       onAnimationEvent: OnAnimationEvent);
                stateQueue.Add(DailyMissionRewardPopupState.SetPointRewardPanel);
                stateQueue.Add(DailyMissionRewardPopupState.UpdateContent);
            }
            else
            {
                stateQueue.Add(DailyMissionRewardPopupState.Release);
            }
        }

        private IEnumerator SetPointRewardPanelCoroutine()
        {
            dailyMissionGaugeInfo.SetCloneActive(true);
            yield return new WaitForSeconds(.4f);

            yield return clonedPointGauge.Full();
            SetPanelOn(pointRewardPanel);
            yield break;
        }

        private void OpenErrorPopup(string message)
        {
            Popups.Error(message)
                  .Async()
                  .OnClose(Close);

            // 다음 스텝을 연출하기 위해 stateQueue.Reset() 은 호출하지 않음
        }

        private IEnumerator WaitForAutoProgressCoroutine()
        {
            yield return new WaitForSeconds(autoProgressDelay);
        }

        private IEnumerator ReleaseCoroutine()
        {
            if (currentPanel != null)
            {
                yield return currentPanel.Release();
            }

            base.Close();
            yield break;
        }

        public override void GoBack()
        {
            currentPanel.GoBack();
        }

        public override bool CanBack()
        {
            bool result = Popups.IsLoading() == false
                          && currentPanel != null
                          && currentPanel.CanBack();

            return result;
        }

        public override void Close()
        {
            stateQueue.Reset();
            stateQueue.Add(DailyMissionRewardPopupState.Release);
        }
    }
}