using System.Collections;
using UnityEngine;

namespace Underc.Popup
{
    public class BaseDailyMissionRewardPanel : MonoBehaviour
    {
        [SerializeField] protected float buttonFadeTime = .2f;
        [SerializeField] protected SimpleRewardItemCollector itemCollector;

        public SimpleRewardItemCollector ItemCollector
        {
            get => itemCollector;
        }

        public virtual void Init()
        {

        }

        public virtual void Reset()
        {

        }

        public virtual bool CanBack()
        {
            return true;
        }

        public virtual void GoBack()
        {
            
        }

        public virtual IEnumerator UpdateContent()
        {
            yield break;
        }

        public virtual void OpenButton(string name)
        {
        }

        public virtual IEnumerator Collect()
        {
            yield break;
        }

        public virtual IEnumerator Release()
        {
            yield break;
        }
    }
}