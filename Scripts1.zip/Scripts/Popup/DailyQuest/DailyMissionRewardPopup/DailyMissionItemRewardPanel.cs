using DG.Tweening;
using Gaga;
using Gaga.Util;
using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Popup
{
    public enum DailyMissionItemRewardPanelState
    {
        None,
        UpdateContent,
        WaitForAutoCollect,
        Collect,
        WaitForAutoRelease,
        Release
    }

    public class DailyMissionItemRewardPanel : BaseDailyMissionRewardPanel
    {
        [SerializeField] private Text stepText;

        [Header("Collect")]
        [SerializeField] private Button collectButton = null;
        [SerializeField] private CanvasGroup collectButtonGroup;
        [SerializeField] private AnimatorParser collectAnimation;
        [SerializeField] private AnimatorParser nextAnimation;

        [Header("Next")]
        [SerializeField] private GameObjectVisibleToggle nextTitleVisibleToggle;
        [SerializeField] private TextMeshProUGUI nextMissionText;
        [SerializeField] private TextMeshProUGUI continueText;
        [SerializeField] private Button continueButton;
        [SerializeField] private CanvasGroup continueButtonGroup;
        [SerializeField] private AnimatorParser continueAnimation;

        private int INDEX_NEXT_STEP_EXISTS = 0;
        private int INDEX_NEXT_STEP_IS_EMPTY = 1;

        private int prevStep;
        private List<RewardInfo> rewardInfos;
        public DailyMissionInfo NextQuestInfo
        {
            get;
            private set;
        }
        private Action<string> onAnimationEvent;
        private object buttonFadeDuration;

        public override void Init()
        {
            itemCollector.Init();
        }

        public override void Reset()
        {
            itemCollector.Reset();

            stepText.text = "";

            collectButton.interactable = false;
            collectButton.gameObject.SetActive(false);
            collectButtonGroup.alpha = 0;

            nextTitleVisibleToggle.TurnOff();
            nextMissionText.text = "";
            continueButton.interactable = false;
            continueButton.gameObject.SetActive(false);
            continueButtonGroup.alpha = 0;
        }

        public void Setup(int prevStep,
                          DailyMissionInfo nextQuestInfo,
                          List<RewardInfo> rewardInfos,
                          Action<string> onAnimationEvent)
        {
            this.prevStep = prevStep;
            this.NextQuestInfo = nextQuestInfo;
            this.rewardInfos = rewardInfos;
            this.onAnimationEvent = onAnimationEvent;
        }

        public override IEnumerator UpdateContent()
        {
            stepText.text = prevStep.ToString();
            itemCollector.Setup(rewardInfos, SimpleRewardItemValueType.Simple);
            yield break;
        }

        public void OnAnimationEvent(string name)
        {
            onAnimationEvent?.Invoke(name);
        }

        public override void OpenButton(string name)
        {
            if (name == "reward")
            {
                /// 아이템이 모두 나타난 이후 활성화 해주기
                collectButton.interactable = true;
                collectButton.gameObject.SetActive(true);
                collectButtonGroup.DOFade(1f, buttonFadeTime);
            }
            else if (name == "next")
            {
                /// 아이템이 모두 나타난 이후 활성화 해주기
                continueButton.interactable = true;
                continueButton.gameObject.SetActive(true);
                continueButtonGroup.DOFade(1f, buttonFadeTime);
            }
        }

        public override IEnumerator Collect()
        {
            /// 보상 획득 연출
            collectButton.interactable = false;
            collectButton.gameObject.SetActive(true);
            collectButtonGroup.DOFade(0f, buttonFadeTime);

            collectAnimation.SetTrigger();
            yield return itemCollector.CollectCoroutine();
        }

        public IEnumerator Next()
        {
            /// 다음 미션 메시지
            if (NextQuestInfo.step > 0)
            {
                nextTitleVisibleToggle.TurnOnByIndexInMultiple(INDEX_NEXT_STEP_EXISTS);
                nextMissionText.text = NextQuestInfo.missionFormatInfo.GetFormat(missionFormatColor: MissionFormatColor.Pink);
                continueText.text = "CONTINUE";
            }
            else
            {
                nextTitleVisibleToggle.TurnOnByIndexInMultiple(INDEX_NEXT_STEP_IS_EMPTY);
                nextMissionText.text = "You finished all quests for today.";
                continueText.text = "OK";
            }

            nextAnimation.SetTrigger();
            yield return nextAnimation.WaitForDuration();
        }

        public override IEnumerator Release()
        {
            continueButton.interactable = false;
            continueButton.gameObject.SetActive(true);
            continueButtonGroup.DOFade(0f, buttonFadeTime);

            continueAnimation.SetTrigger();
            yield return continueAnimation.WaitForDuration();

            yield break;
        }

        public override bool CanBack()
        {
            return Popups.IsLoading() == false
                   && (collectButton.interactable == true || continueButton.interactable == true)
                   && base.CanBack();
        }

        public override void GoBack()
        {
            if (collectButton.interactable)
            {
                collectButton.onClick.Invoke();
            }
            else if (continueButton.interactable)
            {
                continueButton.onClick.Invoke();
            }
        }
    }
}
