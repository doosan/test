using DG.Tweening;
using Gaga.Util;
using System;
using System.Collections;
using System.Collections.Generic;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Popup
{
    public enum DailyMissionPointRewardPanelState
    {
        None,
        UpdateContent,
        WaitForAutoCollect,
        Collect,
        Release
    }

    public class DailyMissionPointRewardPanel : BaseDailyMissionRewardPanel
    {
        [SerializeField] private Button collectButton = null;
        [SerializeField] private CanvasGroup collectButtonGroup;
        [SerializeField] private AnimatorParser collectAnimation;

        private List<RewardInfo> rewardInfos;
        private Action<string> onAnimationEvent;

        public override void Init()
        {
            itemCollector.Init();
        }

        public override void Reset()
        {
            itemCollector.Reset();

            collectButton.interactable = false;
            collectButton.gameObject.SetActive(false);
            collectButtonGroup.alpha = 0;
        }

        public void Setup(List<RewardInfo> rewardInfos, Action<string> onAnimationEvent)
        {
            this.rewardInfos = rewardInfos;
            this.onAnimationEvent = onAnimationEvent;
        }

        public override IEnumerator UpdateContent()
        {
            itemCollector.Setup(rewardInfos, SimpleRewardItemValueType.Simple);
            yield break;
        }

        public void OnAnimationEvent(string name)
        {
            onAnimationEvent?.Invoke(name);
        }

        public override void OpenButton(string name)
        {
            if (name == "reward")
            {
                /// 아이템이 모두 나타난 이후 활성화 해주기
                collectButton.interactable = true;
                collectButton.gameObject.SetActive(true);
                collectButtonGroup.DOFade(1f, buttonFadeTime);
            }
        }

        public override IEnumerator Collect()
        {
            collectButton.interactable = false;
            collectButton.gameObject.SetActive(true);
            collectButtonGroup.DOFade(0f, buttonFadeTime);

            collectAnimation.SetTrigger();
            yield return itemCollector.CollectCoroutine();
        }

        public override IEnumerator Release()
        {
            yield break;
        }

        public override bool CanBack()
        {
            return Popups.IsLoading() == false
                   && collectButton.interactable == true
                   && base.CanBack();
        }

        public override void GoBack()
        {
            if (collectButton.interactable)
            {
                collectButton.onClick.Invoke();
            }
        }
    }
}