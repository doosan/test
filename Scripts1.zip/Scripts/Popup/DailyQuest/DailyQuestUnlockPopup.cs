using Gaga.Popup;

namespace Underc.Popup
{
    public class DailyQuestUnlockPopup : PopupBackable
    {
        public void Open()
        {

        }

        public override bool CanBack()
        {
            return Popups.IsLoading() == false;
        }
    }
}