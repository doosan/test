using Gaga;
using Gaga.Util;
using System.Collections;
using TMPro;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Popup
{
    public enum DailyMissionItemState
    {
        None,
        Complete,
        InProgress,
        Lock
    }

    public class DailyMissionItem : MonoBehaviour
    {
        [SerializeField] private Animator animator;

        [Header("Lock")]
        [SerializeField] private TextMeshProUGUI missionText_lock;
        [SerializeField] private TextMeshProUGUI rewardText_lock;

        [Header("InProgress")]
        [SerializeField] private TextMeshProUGUI missionText_inProgress;
        [SerializeField] private Slider progressSlider_inProgress;
        [SerializeField] private TextMeshProUGUI progressText_inProgress;
        [SerializeField] private TextMeshProUGUI rewardText_inProgress;
        [SerializeField] private GameObjectVisibleToggle iconVisibleToggle_inProgress;

        [Header("Animation")]
        [SerializeField] private AnimatorParser toCompleteAnimation;
        [SerializeField] private AnimatorParser toInProgressAnimation;
        [SerializeField] private AnimatorParser refreshAnimation;

        private bool isMissionRefreshed;
        private DailyMissionInfo info;
        private int rewardIndex;
        private DailyMissionItemState state;

        public void Init()
        { 
        }

        public void Reset()
        {
            missionText_lock.text = "";
            rewardText_lock.text = "";

            missionText_inProgress.text = "";
            progressSlider_inProgress.normalizedValue = 0;
            progressText_inProgress.text = "";
            rewardText_inProgress.text = "";
        }

        public void ToComplete()
        {
            toCompleteAnimation.SetTrigger();
        }

        public IEnumerator ToInProgress()
        {
            toInProgressAnimation.SetTrigger();
            yield return toInProgressAnimation.WaitForDuration();
        }

        public void Refresh()
        {
            refreshAnimation.SetTrigger();
        }

        public void UpdateContent(bool isMissionRefreshed, 
                                  DailyMissionInfo info,
                                  int rewardIndex,
                                  DailyMissionItemState state)
        {
            this.isMissionRefreshed = isMissionRefreshed;
            this.info = info;
            this.rewardIndex = rewardIndex;
            this.state = state;

            if (info != null)
            {
                if (info.missionFormatInfo != null)
                {
                    string missionText = info.missionFormatInfo.GetFormat(missionFormatColor: MissionFormatColor.White);
                    missionText_lock.text = missionText;
                    missionText_inProgress.text = missionText;

                    string mission = info.missionFormatInfo.Mission;
                    iconVisibleToggle_inProgress.TurnOnByNameInMultiple(mission);
                }

                float progress = info.curr / (float)info.all;
                progressSlider_inProgress.normalizedValue = progress;

                progressText_inProgress.text = $"{StringUtils.ToGeneralKMB(info.curr)}/{StringUtils.ToGeneralKMB(info.all)}";

                if (info.rewardInfos != null
                    && rewardIndex < info.rewardInfos.Count)
                {
                    RewardInfo rewardInfo = info.rewardInfos[rewardIndex];
                    long rewardValue = rewardInfo.value;
                    StringUtils.KMBOption kmbOption = StringUtils.GeneralKMBOption();
                    string rewardStr = StringUtils.ToKMB(rewardValue, kmbOption);
                    rewardText_lock.text = rewardStr;
                    rewardText_inProgress.text = rewardStr;
                }

                bool endEffectVisible = progress != 0 && progress != 1;
            }

            if (state != DailyMissionItemState.None)
            {
                animator.SetTrigger(state.ToString());
            }
        }
    }
}