using Gaga.Popup;
using Underc.UI;

namespace Underc.Popup
{
    public class HighlightPopup : PopupBackable
    {
        private HighlightPanel highlightPanel;
        
        public virtual void Register(HighlightObjectInfo info)
        {
            if (highlightPanel == null)
            {
                highlightPanel = gameObject.AddComponent<HighlightPanel>();
            }
            highlightPanel.Register(info);
        }

        public override void Close()
        {
            StopAllCoroutines();
            if (highlightPanel != null)
            {
                highlightPanel.Dispose();
            }

            base.Close();
        }
    }
}