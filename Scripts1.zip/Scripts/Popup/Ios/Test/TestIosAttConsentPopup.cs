using System.Collections;
using Underc.LoadingScreen;
using Underc.Popup;
using Underc.User;

public class TestIosAttConsentPopup : TestSceneScaffold
{
    private IEnumerator Start()
    {
        yield return SetupAndLoad(new BaseLoadingItem[]
        {
            new LoginLoadingItem(),
        });
    }

    public void OpenIosAttConsentPopup()
    {
        Popups.IosAttConsent();
    }
}
