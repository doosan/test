using System;
using Gaga.Popup;
using Underc.User;
#if UNITY_IOS
using Underc.Notification;
#endif

namespace Underc.Popup
{
    public class IosNotiConsentPopup : PopupBackable
    {
#if UNITY_EDITOR
        private static readonly string KEY_iOS_NOTI_CONSENT = "k_underc_ios_pushconsent";
        public static bool EditorDetermined
        {
            get => UndercPrefs.GetLocalValue(KEY_iOS_NOTI_CONSENT, 0) == 1;
            set => UndercPrefs.SetLocalValue(KEY_iOS_NOTI_CONSENT, value ? 1 : 0);
        }
#endif

        public static bool CanOpen
        {
            get => MyInfo.Level >= 8 && Determined == false;
        }

        public static bool Determined
        {
            get
            {
#if UNITY_EDITOR
                return EditorDetermined; //에디터 테스트를 위해 PlayerPrefs 이용
#elif UNITY_ANDROID
                return true; //android 는 팝업 나오지 않음
#elif UNITY_IOS
                return NotificationSystem.Instance.Determined; //결정한 경우 나오지 않음
#endif
            }
        }

        public static void Reset()
        {
#if UNITY_EDITOR
            EditorDetermined = false;
#endif
        }

        private Action onComplete;
        public void Open(Action onCompelte = null)
        {
            this.onComplete = onCompelte;
        }

        public void Later()
        {
            UndercGameLog.Fobis.PopupAllowPush(1);
            Close();
        }

        public void Allow()
        {
            UndercGameLog.Fobis.PopupAllowPush(2);

#if UNITY_EDITOR
            EditorDetermined = true;
#elif UNITY_IOS
            NotificationSystem.Instance.SetEnable(true);
#endif

            Close();
        }

        public override void Close()
        {
            if (onComplete != null)
            {
                onComplete.Invoke();
                onComplete = null;
            }

            base.Close();
        }

    }
}
