using Gaga.Popup;
using System;

namespace Underc.Popup
{
    public class IosAttConsentPopup : PopupBackable
    {
        private const string KEY_ATT_CONSENT_OPENED = "key_att_consent_opened";

        public static bool IsOpened
        {
            get => UndercPrefs.GetLocalValue(KEY_ATT_CONSENT_OPENED, 0) == 1;
            set => UndercPrefs.SetLocalValue(KEY_ATT_CONSENT_OPENED, value ? 1 : 0);
        }

        public void Open()
        {
        }

        public void OnPrivacyNoticeClick()
        {
            AppService.OpenPrivacyPolicy();
        }
    }
}