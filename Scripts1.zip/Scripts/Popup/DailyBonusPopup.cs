using System;
using System.Collections;
using Gaga.Popup;
using Gaga.Util;
using Gaga.UI;
using UnityEngine;
using UnityEngine.UI;
using Underc.User;
using Underc.UI;
using Underc.Effect;
using Underc.Net;
using Gaga;
using TMPro;
using Underc.Net.Client;
using System.Collections.Generic;
using UnityEngine.Serialization;
using static Gaga.Util.CustomYield;
using Gaga.Sound;

namespace Underc.Popup
{
    public class DailyBonusPopup : PopupBackable
    {
        [Serializable]
        public class StreakItem
        {
            public GameObject go = null;
            public Text streakDayText = null;
            public TextMeshProUGUI rewardText = null;
            public GameObject max = null;
            public GameObject check = null;
        }

        private readonly int ANIM_NEXT = Animator.StringToHash("Next");

        [SerializeField] private Button nextButton = null;
        [SerializeField] private Button collectButton = null;
        [SerializeField] private Animator animator = null;
        [SerializeField] private float nextDelay = 0.5f;

        [Header("DailyGift")]
        [SerializeField] private SetNumberPlayerTM dailyGiftRewardText = null;
        [SerializeField] private GameObjectVisibleToggle dailyGiftAdditionalRewardToggle = null;
        [SerializeField] private SetNumberPlayerTM dailyGiftAdditionalRewardText = null;

        [Header("StrealBonus")]
        [SerializeField] private StreakItem[] streakItems = null;

        [Header("FishBonus")]
        [SerializeField] private SetNumberPlayerTM fishStartingText = null;
        [SerializeField] private SetNumberPlayerTM fishTotalCountText = null;
        [SerializeField] private SetNumberPlayerTM fishMaxCountText = null;
        [SerializeField] private GameObject fishMaxIndicator = null;

        [Header("Total")]
        [SerializeField] private SetNumberPlayerTM totalDaily = null;
        [SerializeField] private GameObjectVisibleToggle totalDailyAdditionalRewardToggle = null;
        [SerializeField] private SetNumberPlayerTM totalDailyAdditionalRewardText = null;
        [SerializeField] private SetNumberPlayerTM totalStreak = null;
        [SerializeField] private SetNumberPlayerTM totalFish = null;
        [SerializeField] private SetNumberPlayerTM totalBonus = null;
        [SerializeField] private GameObjectVisibleToggle totalBonusAdditionalRewardToggle = null;
        [SerializeField] private SetNumberPlayerTM totalBonusAdditionalRewardText = null;

        [Header("Vip Bonus Badge")]
        [FormerlySerializedAs("vipBonusBadgeContainer")]
        [SerializeField] private RectTransform vipBonusBadgePosition;

        [Header("Collect")]
        [SerializeField] private AnimatorParser collectButtonShowAnimation;
        [SerializeField] private float collectTextDuration = 0.4f;
        [SerializeField] private EasingFunction.Ease collectEase = EasingFunction.Ease.Linear;

        [Header("Sum")]
        [SerializeField] private float sumTextDuration = 0.35f;
        [SerializeField] private EasingFunction.Ease sumEase = EasingFunction.Ease.Linear;

        [Header("Sound")]
        [SerializeField] private SoundPlayer pickaxSound;

        public bool RunAsFake
        {
            private get;
            set;
        }

        private float lastNextTime;

        private Coroutine coroutine;
        private TopUI topUI;
        private long dailyBonusTotal1;
        private long dailyBonusTotal2;
        private long dailyBonusTotal3;
        private long dailyBonusTotal4;
        private int addCount;

        private List<RewardInfo> additionalRewardInfos;
        private RewardBonusUI bonusUI;
        private VipBonusBadge vipBonusBadge;

        private DailyBonusClaimResponse claimData;
        private SimpleWaitForDone waitForOpen;

        protected override void Awake()
        {
            base.Awake();

            nextButton.onClick.AddListener(Next);
            collectButton.onClick.AddListener(Collect);

            additionalRewardInfos = new List<RewardInfo>();
        }

        protected override void OnEnable()
        {
            base.OnEnable();

            waitForOpen = new SimpleWaitForDone();
        }

        private void SetupNumberPlayers()
        {
            /// 물고기 관련된 텍스트 빼고 전부 다
            SetKMBOption(dailyGiftRewardText);
            SetKMBOption(dailyGiftAdditionalRewardText);

            SetKMBOption(totalDaily);
            SetKMBOption(totalDailyAdditionalRewardText);
            SetKMBOption(totalStreak);
            SetKMBOption(totalBonus);
            SetKMBOption(totalBonusAdditionalRewardText);
        }

        private void SetKMBOption(SetNumberPlayerTM numberPlayer)
        {
            numberPlayer.useKMB = true;
            numberPlayer.kmbOption = StringUtils.GeneralKMBOption(1000000);
        }

        private void SetupTopUI()
        {
            topUI = TopUISystem.Instance.Get(transform);

            topUI.Use(TopUiItem.Coin);
            topUI.Reset();
            topUI.Show(false);
        }

        private void SetupBottomUI()
        {
            bonusUI = RewardBonusUISystem.Instance.Get(transform);
            bonusUI.Reset();
        }

        private void Reset()
        {
            animator.ResetAllTriggers();
            lastNextTime = Time.time;
            collectButton.interactable = false;
            nextButton.interactable = true;
            addCount = 0;

            SetupNumberPlayers();
            SetupTopUI();
            SetupBottomUI();
            vipBonusBadge = VipBonusBadgeSystem.Instance.Get(vipBonusBadgePosition);
        }

        public void Open()
        {
            Reset();
            StartCoroutine(OpenCoroutine());
        }

        private IEnumerator LoadDailyBonusClaim()
        {
            claimData = null;
            Popups.ShowLoading();
            IRequest<DailyBonusClaimResponse> claimReq;
            if (RunAsFake == false)
            {
                claimReq = NetworkSystem.HTTPRequester.DailyBonusClaim();
            }
            else
            {
                claimReq = FakeHttpRequester.Instance.DailyBonusClaim();
            }
            yield return claimReq.WaitForResponse();
            Popups.HideLoading();

            ///
            if (claimReq.isSuccess == false)
            {
                CloseByError(claimReq.data.error);
                yield break;
            }
            else
            {
                claimData = claimReq.data;
            }
        }

        private IEnumerator OpenCoroutine()
        {
            yield return LoadDailyBonusClaim();

            ParseAdditionalRewardInfos(claimData);

            //daily
            dailyGiftRewardText.startValue = 0L;
            dailyGiftRewardText.endValue = claimData.daily_bonus;
            
            UpdateAdditionalReward(dailyGiftAdditionalRewardToggle, dailyGiftAdditionalRewardText);

            //streak
            StreakItem yesterDay = streakItems[0];
            StreakItem today = streakItems[1];
            StreakItem tomorrow = streakItems[2];
            long dayCount = claimData.streak_day;
            long dayMax = claimData.streak_max;
            long coinPerDay = claimData.coin_per_streak;
            bool isOverStreak = dayCount > dayMax;
            long vipBonus = claimData.vip_bonus;
            VipBenefitTableItemInfo tableItemInfo = new VipBenefitTableItemInfo(claimData.vip_rate, claimData.vip_rate_type);
            vipBonusBadge.Setup(targetTransform: totalBonus.GetComponent<RectTransform>(),
                                vipBonus: vipBonus,
                                tableItemInfo: tableItemInfo);

            SetStreakValue(streakItems[0], dayMax, coinPerDay, dayCount - 1, true, dayCount > 1);
            SetStreakValue(streakItems[1], dayMax, coinPerDay, dayCount, true, true);
            SetStreakValue(streakItems[2], dayMax, coinPerDay, dayCount + 1, false, dayCount <= dayMax);

            //fish
            fishStartingText.startValue = 0L;
            fishStartingText.endValue = claimData.starting_coin;

            fishTotalCountText.startValue = 0L;
            fishTotalCountText.endValue = claimData.fish_cnt;

            fishMaxCountText.startValue = 0L;
            fishMaxCountText.endValue = claimData.limit_fish_cnt;

            if (fishMaxIndicator != null)
            {
                fishMaxIndicator.SetActive(claimData.fish_cnt >= claimData.limit_fish_cnt);
            }

            //total
            dailyBonusTotal1 = claimData.daily_bonus;
            dailyBonusTotal2 = dailyBonusTotal1 + claimData.streak_bonus;
            dailyBonusTotal3 = dailyBonusTotal2 + claimData.fish_bonus;
            dailyBonusTotal4 = dailyBonusTotal3 + claimData.vip_bonus;

            totalDaily.startValue = 0L;
            totalDaily.endValue = claimData.daily_bonus;
            UpdateAdditionalReward(totalDailyAdditionalRewardToggle, totalDailyAdditionalRewardText);

            totalStreak.startValue = 0L;
            totalStreak.endValue = claimData.streak_bonus;

            totalFish.startValue = 0L;
            totalFish.endValue = claimData.fish_bonus;

            totalBonus.startValue = 0L;
            totalBonus.endValue = dailyBonusTotal4;
            totalBonus.Stop(true);

            UpdateAdditionalReward(totalBonusAdditionalRewardToggle, totalBonusAdditionalRewardText);
            totalBonusAdditionalRewardText.Stop(true);

            yield return waitForOpen;
            Next();
            pickaxSound.Play();
        }

        public void OnOpenAnimationEnd()
        {
            waitForOpen.Done();
        }
        
        private void ParseAdditionalRewardInfos(DailyBonusClaimResponse data)
        {
            additionalRewardInfos.Clear();
            if (data.reward != null && data.reward.Length > 0)
            {
                foreach (DailyBonusRewardData reward in data.reward)
                {
                    RewardType rewardType;
                    if (Enum.TryParse(reward.rwd, out rewardType))
                    {
                        long rewardValue = reward.val;
                        if (rewardValue == 0) continue;

                        additionalRewardInfos.Add(new RewardInfo(rewardType, rewardValue));
                    }
                }
            }
        }

        private RewardInfo GetFirstReward()
        {
            RewardInfo firstReward = null;
            if (additionalRewardInfos.Count > 0)
            {
                firstReward = additionalRewardInfos[0];
            }

            return firstReward;
        }

        // 아직은 곡괭이밖에 없음
        private void UpdateAdditionalReward(GameObjectVisibleToggle rewardVisibleToggle, 
                                            SetNumberPlayerTM rewardText)
        {
            RewardInfo reward = GetFirstReward();
            bool hasReward = reward != null;
            rewardVisibleToggle.gameObject.SetActive(hasReward);
            if (hasReward == true)
            {
                rewardVisibleToggle.TurnOnByNameInMultiple(reward.type.ToString());
                rewardText.startValue = 0L;
                rewardText.endValue = reward.value;
                rewardText.prefix = "x";
            }
        }

        private void SetStreakValue(StreakItem item, long daymax, long coinPerDay, long day, bool collected, bool active)
        {
            if (active == false)
            {
                item.go.SetActive(false);
                return;
            }

            item.go.SetActive(true);

            long tempDay = day;
            bool isMax = day >= daymax;
            bool isOverMax = day > daymax;
            if (isOverMax == true)
            {
                day = daymax;
            }
            long bonus = day * coinPerDay;

            if (isOverMax == true)
            {
                item.streakDayText.text = day.ToString() + "+";
            }
            else
            {
                item.streakDayText.text = day.ToString();
            }

            item.rewardText.SetNumber(value: bonus, kMBOption: StringUtils.GeneralKMBOption());
            item.check.SetActive(collected);
            item.max.SetActive(isMax);
        }

        public void TotalAnimBegin()
        {
            nextButton.interactable = false;
        }
        
        public void ShowVipBonusBadge()
        {
            // 1-1 : VIP 보너스 배지 등장
            if (vipBonusBadge.CanOpen)
            {
                vipBonusBadge.Show(addingDoneDuration: sumTextDuration,
                                   onVipBonusAdding: AddReward,              // 1-2 : 애니에 맞춰 보너스 값 적용
                                   onVipBonusAddingDone: ShowCollectButton); // 1-3 : 콜렉트 버튼 등장
            }
            else
            {
                ShowCollectButton();
            }
        }

        private void ShowCollectButton()
        {
            collectButton.interactable = true;
            collectButtonShowAnimation.SetTrigger();
        }

        public void AddReward()
        {
            if (addCount >= 4)
            {
                return;
            }

            addCount++;
            if (addCount == 1)
            {
                totalBonus.Play(0L, dailyBonusTotal1, sumTextDuration, sumEase);
                totalBonusAdditionalRewardText.Play();
            }
            else if (addCount == 2)
            {
                totalBonus.Play(dailyBonusTotal1, dailyBonusTotal2, sumTextDuration, sumEase);
            }
            else if (addCount == 3)
            {
                totalBonus.Play(dailyBonusTotal2, dailyBonusTotal3, sumTextDuration, sumEase);
            }
            else if (addCount == 4)
            {
                totalBonus.Play(dailyBonusTotal3, dailyBonusTotal4, sumTextDuration, sumEase);
            }
        }

        private void CloseByError(string errorMessage)
        {
            Debug.LogFormat("close by error: {0}", errorMessage);

            Popups.Warning(message: errorMessage,
                           actionType: WarningPopup.ActionType.None,
                           titleType: WarningPopup.TitleType.Network,
                           useCloseButton: false,
                           onOK: Close);
        }

        private void Next()
        {
            if (Time.time - lastNextTime < nextDelay)
            {
                return;
            }

            animator.SetTrigger(ANIM_NEXT);
            lastNextTime = Time.time;
        }

        private void Collect()
        {
            if (coroutine == null)
            {
                coroutine = StartCoroutine(CollectCoroutine());
            }
        }

        private IEnumerator CollectCoroutine()
        {
            var loadCasinoBonus = NetworkSystem.HTTPRequester.CasinoBonus();

            collectButton.interactable = false;

            totalDaily.Stop();
            totalStreak.Stop();
            totalFish.Stop();
            totalBonus.Stop();
            totalBonusAdditionalRewardText.Stop();

            Next();
            CollectAllTexts();
            vipBonusBadge.Hide();

            /// edgeUI
            bonusUI.Setup(additionalRewardInfos);
            if (bonusUI.IsActive)
            {
                bonusUI.Show();
                yield return new WaitForSeconds(0.3f);

                foreach (RewardInfo rewardInfo in additionalRewardInfos)
                {
                    long rewardValue = rewardInfo.value;
                    if (rewardInfo.type == RewardType.s_pickaxe)
                    {
                        EffectSystem.Instance.Pickax(
                            pickaxType: rewardInfo.type.ToString(),
                            count: (int)rewardInfo.value,
                            startPosition: totalBonusAdditionalRewardText.transform.position,
                            endPosition: bonusUI.BottomUI.MissionIconManager.CachedTransform.position,
                            onFirstArrived: () =>
                            {
                                int nextPickax = MyInfo.ClamHarvest.DisplayInfo.pickax + (int)rewardValue;
                                MyInfo.ClamHarvest.UpdateClamHarvestDisplayInfo(nextPickax);
                                bonusUI.BottomUI
                                       .MissionIconManager
                                       .GetIcon(MissionIconType.ClamHarvest)
                                       .UpdateInfo(isProgressive: false);
                            }
                        );
                    }
                }
            }

            /// TopUI
            var waitForComplete = true;
            EffectSystem.Instance.Coin(count: 20,
                                       startPosition: totalBonus.transform.position,
                                       endPosition: topUI.GetCoinIconPosition(),
                                       scaleTarget: topUI.GetCoinIcon(),
                                       onComplete: completeType => waitForComplete = false,
                                       onFirstCoinArrived: () => MyInfo.Coin += dailyBonusTotal4,
                                       onCoinArrived: () => topUI.CoinIconAnimation());

            yield return new WaitWhile(() => waitForComplete);

            coroutine = null;

            if (loadCasinoBonus.isDone == false)
            {
                Popups.ShowLoading();
                yield return loadCasinoBonus.WaitForResponse();
                Popups.HideLoading();
            }

            if (loadCasinoBonus.isSuccess == true)
            {
                NetworkSystem.HTTPHandler.Do(loadCasinoBonus.data);
            }

            Close();
            yield break;
        }

        private void CollectAllTexts()
        {
            totalDaily.Play(totalDaily.endValue, 0L, collectTextDuration, collectEase);
            totalStreak.Play(totalStreak.endValue, 0L, collectTextDuration, collectEase);
            totalFish.Play(totalFish.endValue, 0L, collectTextDuration, collectEase);
            totalBonus.Play(totalBonus.endValue, 0L, collectTextDuration, collectEase);
            totalBonusAdditionalRewardText.Play(totalBonusAdditionalRewardText.endValue, 0L, collectTextDuration, collectEase, "x");
        }

        public override void GoBack()
        {
            if (collectButton.interactable == true)
            {
                Collect();
            }
            else if (nextButton.interactable == true)
            {
                Next();
            }
        }

        public override bool CanBack()
        {
            return (nextButton.interactable == true || collectButton.interactable == true)
                   && base.CanBack();
        }

        public override void Close()
        {
            if (topUI != null)
            {
                TopUISystem.Instance.Return(topUI);
                topUI = null;
            }

            if (bonusUI != null)
            {
                RewardBonusUISystem.Instance.Return(bonusUI);
                bonusUI = null;
            }

            if (vipBonusBadge != null)
            {
                VipBonusBadgeSystem.Instance.Return(vipBonusBadge);
                vipBonusBadge = null;
            }

            base.Close();
        }
    }
}