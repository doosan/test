using Gaga.Popup;
using Underc.Scene;
using UnityEngine;
using TMPro;
using Gaga;
using System;

namespace Underc.Popup
{
    public sealed class WarningPopup : PopupBackable
    {
        public enum TitleType
        {
            None,
            Network,
            Basic
        }

        public enum ActionType
        {
            None,
            Lobby,
            Intro
        }

#pragma warning disable 0649
        [SerializeField] private TextMeshProUGUI messageText;
        [SerializeField] private TextMeshProUGUI buttonText;
        [SerializeField] private TextMeshProUGUI positivieText;
        [SerializeField] private TextMeshProUGUI negativeText;

        [SerializeField] private GameObjectVisibleToggle titleToggle;
        [SerializeField] private TextMeshProUGUI titleText;
        [SerializeField] private GameObject closeButton;
        [SerializeField] private GameObject singelButton;
        [SerializeField] private GameObject confirmButtons;
#pragma warning restore 0649

        private ActionType actionType;
        private TitleType titleType;
        private string titleMessage;
        private Action onOK;
        private Action onNO;
        private Action onClose;
        private string okText;
        private string noText;

        public void Alert(string message,
                               ActionType actionType,
                               TitleType titleType = TitleType.None,
                               string titleMessage = "",
                               bool useCloseButton = true,
                               Action onOK = null,
                               Action onClose = null,
                               string okText = "OK")
        {
            this.actionType = actionType;
            this.titleType = titleType;
            this.titleMessage = titleMessage;
            this.onOK = onOK;
            this.onNO = null;
            this.onClose = onClose;
            this.okText = okText;
            this.noText = string.Empty;

            singelButton.SetActive(true);
            confirmButtons.SetActive(false);

            allowBackButton = useCloseButton;
            closeButton.SetActive(useCloseButton);
            messageText.text = message;

            SetButton();
            SetTitle();
        }

        public void Confirm(string message,
                            string titleMessage = "",
                            bool useCloseButton = true,
                            Action onOK = null,
                            Action onNO = null,
                            Action onClose = null,
                            string okText = "YES",
                            string noText = "NO")
        {
            this.actionType = ActionType.None;
            this.titleType = string.IsNullOrEmpty(titleMessage) ? TitleType.None : TitleType.Basic;
            this.titleMessage = titleMessage;
            this.onOK = onOK;
            this.onNO = onNO;
            this.onClose = onClose;
            this.okText = okText;
            this.noText = noText;

            singelButton.SetActive(false);
            confirmButtons.SetActive(true);

            allowBackButton = true;
            closeButton.SetActive(useCloseButton);
            messageText.text = message;

            SetButton();
            SetTitle();
        }

        private void SetButton()
        {
            if (actionType == ActionType.Lobby)
            {
                positivieText.text = buttonText.text = "TO LOBBY";
            }
            else if (actionType == ActionType.Intro)
            {
                positivieText.text = buttonText.text = "RELOAD";
            }
            else
            {
                positivieText.text = buttonText.text = okText;
            }

            if (string.IsNullOrEmpty(noText) == true)
            {
                negativeText.text = "";
            }
            else
            {
                negativeText.text = noText;
            }
        }

        private void SetTitle()
        {
            if (titleType == TitleType.Network)
            {
                titleToggle.TurnOnByNameInMultiple("Title_Network");
                titleText.text = "";
            }
            else if (titleType == TitleType.Basic)
            {
                titleToggle.TurnOnByNameInMultiple("Title_Basic");
                titleText.text = titleMessage;
            }
            else
            {
                titleToggle.TurnOff();
            }
        }
        public override void GoBack()
        {
            if( confirmButtons.activeSelf == true && closeButton.activeSelf == false)
            {
                NO();
            }
            else
            {
                Close();
            }
        }

        public override void Close()
        {
            base.Close();

            onClose?.Invoke();
        }

        public void OK()
        {
            Close();

            onOK?.Invoke();
            ExecuteAction(actionType);
        }

        public void NO()
        {
            Close();

            onNO?.Invoke();
        }

        private void ExecuteAction(ActionType actionType)
        {
            if (actionType == ActionType.Lobby)
            {
                SceneSystem.LoadLobby();
            }
            else if (actionType == ActionType.Intro)
            {
                SceneSystem.LoadIntro();
            }
        }
    }
}