using System.Collections;
using UnityEngine.UI;
using UnityEngine;
using TMPro;
using System;
using Underc.Net;
using DG.Tweening;
using Gaga;
using Gaga.Util;
using Underc.User;

namespace Underc.Popup
{
    public class InboxPopupItem : MonoBehaviour
    {
        public enum InboxItemRewardType
        {
            Common,
            MissionPass,
            FacebookLogin
        }

        public enum InboxIconType
        {
            Mask,
            FB,
            App,
            MissionPass
        }

        private readonly string EXPIRE_IN = "<color=#ffb93e>Expires in</color> {0}";
        private readonly string EXPIRED = "<color=#ffb93e>Expired</color>";
        private readonly int TRIGGER_OPEN = Animator.StringToHash("Open");
        private readonly int TRIGGER_EXPIRED = Animator.StringToHash("Expired");


        public event Action<InboxPopupItem> OnExecute;
        public event Action<InboxPopupItem> OnDelete;

        [SerializeField] private CanvasGroup group = null;
        [SerializeField] private RectTransform cachedTransform = null;
        [SerializeField] private RectTransform rewardStartPos = null;

        [Header("Icon")]
        [SerializeField] private GameObjectVisibleToggle iconVisibleToggle = null;
        [SerializeField] private Image maskedIconImage = null;

        [Header("Labels")]
        [SerializeField] private GameObject labelHolder = null;
        [SerializeField] private TextMeshProUGUI labelSendGift = null;
        [SerializeField] private TextMeshProUGUI labelInviteFriends = null;

        [Header("BG")]
        [SerializeField] private RectTransform bgFBLogin = null;
        [SerializeField] private RectTransform bgSeason = null;
        [SerializeField] private RectTransform bgCS = null;
        [SerializeField] private RectTransform bgGift = null;
        [SerializeField] private RectTransform bgSend = null;
        [SerializeField] private RectTransform bgOceanPass = null;

        [Header("Reward")]
        [SerializeField] private GameObjectVisibleToggle rewardItemVisibleToggle;
        [SerializeField] private GameObject rewardItemCoinM = null;
        [SerializeField] private GameObject rewardItemCoinS = null;

        [Header("MysteryBox")]
        [SerializeField] private Animator mysteryBox = null;
        [SerializeField] private float mysteryBoxDuration = 1f;

        [Header("Messsage")]
        [SerializeField] private TextMeshProUGUI message = null;
        [SerializeField] private TextMeshProUGUI messageOceanPass = null;

        [Header("Expire")]
        [SerializeField] private GameObject expireObject = null;
        [SerializeField] private TextMeshProUGUI expireText = null;

        [Header("Buttons")]
        [SerializeField] private Button loginButton = null;
        [SerializeField] private Button collectButton = null;
        [SerializeField] private Button sendButton = null;
        [SerializeField] private Button sentButton = null;
        [SerializeField] private Button expiredButton = null;
        [SerializeField] private Button deleteButton = null;

        public int ItemIndex { get; set; }

        public InboxItemData Data { get; private set; }
        public string RewardType { get; private set; }
        public InboxItemType ItemType { get; private set; }

        private VipClassType vipClassType;
        private Vector2 originSize;
        private Tween tween;
        private Image targetIcon;
        private DownloadSystem.ID downloadID;

        private Button[] executeButtons;
        private RectTransform[] bgs;
        private TextMeshProUGUI[] labels;
        private GameObject[] rewardIcons;
        private Coroutine expireCoroutine;

        private void OnDisable()
        {
            Clear();
        }

        private void Clear()
        {
            Data = null;

            if (tween != null)
            {
                tween.Kill();
                tween = null;
            }

            cachedTransform.sizeDelta = originSize;

            if (string.IsNullOrEmpty(downloadID.value) == false)
            {
                DownloadSystem.Instance.Abort(downloadID);
                downloadID.value = null;
            }

            mysteryBox.ResetTrigger(TRIGGER_OPEN);
            mysteryBox.ResetTrigger(TRIGGER_EXPIRED);

            rewardItemCoinM.SetActive(false);
            rewardItemCoinS.SetActive(false);

            StopExipreCoroutine();
        }

        //Instantiate 된 이후 실행됨
        public void Init()
        {
            originSize = cachedTransform.sizeDelta;

            executeButtons = new Button[] { loginButton, collectButton, sendButton, sentButton, expiredButton };
            bgs = new RectTransform[] { bgFBLogin, bgSeason, bgCS, bgGift, bgSend, bgOceanPass };
            labels = new TextMeshProUGUI[] { labelSendGift, labelInviteFriends };

            deleteButton.onClick.AddListener(DeleteItem);
        }

        public Vector2 GetRewardStartPos()
        {
            return rewardStartPos.position;
        }

        public YieldInstruction Hide()
        {
            StopExipreCoroutine();

            SetInteraction(false);
            var sequence = DOTween.Sequence();
            sequence.Append(cachedTransform.DOSizeDelta(new Vector2(originSize.x, 0f), 0.3f).SetEase(Ease.InOutCirc));
            sequence.Insert(0, group.DOFade(0f, 0.3f).SetEase(Ease.OutExpo));
            tween = sequence;

            return tween.WaitForCompletion();
        }

        public void SetUp(InboxItemData data, VipClassType vipClassType)
        {
            Clear();

            this.Data = data;
            this.ItemType = (InboxItemType)data.type;
            this.RewardType = data.rwd;
            this.vipClassType = vipClassType;
            this.group.alpha = 1f;

            SetInteraction(true);
            UpdateBG();
            UpdateIcon();
            UpdateLables();
            UpdateMessage();
            UpdateRewardIcon();
            UpdateButtons();
            UpdateExpire();
        }

        private void UpdateBG()
        {
            RectTransform selectedBG = null;
            switch (ItemType)
            {
                case InboxItemType.FacebookLogin:
                case InboxItemType.FacebookLoginBonus:
                    selectedBG = bgFBLogin;
                    break;

                case InboxItemType.SeasonGift:
                    selectedBG = bgSeason;
                    break;

                case InboxItemType.WelcomBonus:
                case InboxItemType.CSReward:
                case InboxItemType.AppUpdateReward:
                    selectedBG = bgCS;
                    break;

                case InboxItemType.OceanPassReward:
                    selectedBG = bgOceanPass;
                    break;

                case InboxItemType.CollectGift:
                case InboxItemType.InviteReward:
                    selectedBG = bgGift;
                    break;

                case InboxItemType.SendGift1Week:
                case InboxItemType.SendGift2Week:
                case InboxItemType.InviteFriends:
                    selectedBG = bgSend;
                    break;

                default:
                    selectedBG = bgCS;
                    break;
            }

            SetRectHeight(cachedTransform, selectedBG.rect.height);

            foreach (var bg in bgs)
            {
                bg.gameObject.SetActive(selectedBG == bg);
            }
        }

        private void UpdateIcon()
        {
            InboxIconType iconType = InboxIconType.App;
            if (string.IsNullOrEmpty(Data.pic) == false)
            {
                iconType = InboxIconType.Mask;
                downloadID = DownloadSystem.Instance.GetSprite(Data.pic, SetMaskedIcon);
            }
            else if (Data.picn > 0)
            {
                iconType = InboxIconType.Mask;
                SetMaskedIcon(ProfileIconSystem.Instance.Get(Data.picn));
            }
            else if (ItemType == InboxItemType.InviteFriends)
            {
                iconType = InboxIconType.FB;
            }
            else if (ItemType == InboxItemType.OceanPassReward)
            {
                iconType = InboxIconType.MissionPass;
            }

            iconVisibleToggle.TurnOnByNameInMultiple(iconType.ToString());
        }

        private void SetMaskedIcon(Sprite sprite)
        {
            maskedIconImage.sprite = sprite;
            if (sprite == null)
            {
                maskedIconImage.color = new Color(1, 1, 1, 0);
            }
            else
            {
                maskedIconImage.color = Color.white;
            }
        }

        private void UpdateLables()
        {
            TextMeshProUGUI selectedLabel = null;
            switch (ItemType)
            {
                case InboxItemType.SendGift1Week:
                case InboxItemType.SendGift2Week:
                    selectedLabel = labelSendGift;
                    break;
                case InboxItemType.InviteFriends:
                    selectedLabel = labelInviteFriends;
                    break;
            }

            if (selectedLabel == null)
            {
                labelHolder.SetActive(false);
            }
            else
            {
                labelHolder.SetActive(true);
                foreach (var label in labels)
                {
                    label.gameObject.SetActive(label == selectedLabel);
                }
            }
        }

        private void UpdateExpire()
        {
            if (Data.xpr <= 0)
            {
                expireObject.SetActive(false);
                StopExipreCoroutine();
                return;
            }

            if (GetExpireRemainSec() <= 0)
            {
                Expired();
                return;
            }

            if (expireCoroutine == null)
            {
                expireCoroutine = StartCoroutine(UpdateExpireTime());
            }
        }

        private void StopExipreCoroutine()
        {
            if (expireCoroutine != null)
            {
                StopCoroutine(expireCoroutine);
                expireCoroutine = null;
            }
        }

        private IEnumerator UpdateExpireTime()
        {
            var waitSeconds = new WaitForSecondsRealtime(1);
            expireObject.SetActive(true);

            long remainSec = GetExpireRemainSec();
            while (remainSec > 0)
            {
                expireText.text = string.Format(System.Globalization.CultureInfo.InvariantCulture, EXPIRE_IN, remainSec.ToSummaryDHMS());
                yield return waitSeconds;

                remainSec = GetExpireRemainSec();
            }

            Expired();

            yield break;
        }

        private void Expired()
        {
            expireObject.SetActive(true);
            expireText.text = EXPIRED;

            if (mysteryBox.gameObject.activeInHierarchy == true)
            {
                mysteryBox.SetTrigger(TRIGGER_EXPIRED);
            }

            UpdateButtons();
            StopExipreCoroutine();
        }

        private long GetExpireRemainSec()
        {
            return Data.xpr - GlobalTime.Instance.GetTimeStamp();
        }

        private void UpdateRewardIcon()
        {
            if (ItemType == InboxItemType.FacebookLogin || ItemType == InboxItemType.FacebookLoginBonus)
            {
                //페이스북 로그인의 경우 서버의 리워드타입과 상관없이 고정
                rewardItemVisibleToggle.TurnOnByNameInMultiple(InboxItemRewardType.FacebookLogin.ToString());
            }
            else
            {
                rewardItemVisibleToggle.TurnOnByNameInMultiple(InboxItemRewardType.Common.ToString());
                InboxRewardItem rewardItem = rewardItemVisibleToggle.GetActiveComponent<InboxRewardItem>();

                string rewardType = Data.rwd;
                long rewardValue = Data.val;
                rewardItem.Setup(rewardType, rewardValue, vipClassType);
                rewardItem.SetBGEnable(string.IsNullOrEmpty(rewardType) == false
                                       && rewardValue >= 0);

                //서버측에선 동일한 코인 보상이라더라도 디자인에 맞춰 코인 하나, 소량의 코인더미, 다량의 코인더미로 구분하여 보여주자.
                if (rewardType == RewardData.COIN)
                {
                    rewardItem.HideAllRewardIcon();

                    if (ItemType == InboxItemType.CSReward)
                    {
                        rewardItemCoinM.SetActive(true);
                    }
                    else
                    {
                        rewardItemCoinS.SetActive(true);
                    }
                }
            }
        }

        private void UpdateMessage()
        {
            var targetText = ItemType == InboxItemType.OceanPassReward ? messageOceanPass : message;

            message.gameObject.SetActive(message == targetText);
            messageOceanPass.gameObject.SetActive(messageOceanPass == targetText);

            targetText.text = Data.msg;
        }

        private void UpdateButtons()
        {
            Button activeButton = null;
            if (Data.xpr > 0 && GetExpireRemainSec() <= 0)
            {
                activeButton = expiredButton;
            }
            else if (ItemType == InboxItemType.FacebookLogin)
            {
                activeButton = loginButton;
            }
            else if (InboxItemData.IsCollectableItem(ItemType))
            {
                activeButton = collectButton;
            }
            else
            {
                activeButton = sendButton;
            }

            foreach (var button in executeButtons)
            {
                button.gameObject.SetActive(button == activeButton);
            }

            deleteButton.gameObject.SetActive(InboxItemData.IsDeletableItem(ItemType));
        }

        public void SetInteraction(bool isOn)
        {
            group.interactable = isOn;
        }

        public void Sent()
        {
            foreach (var button in executeButtons)
            {
                button.gameObject.SetActive(button == sentButton);
            }
        }

        public void ExecucteItem()
        {
            if (OnExecute != null)
            {
                OnExecute.Invoke(this);
            }

            StopExipreCoroutine();
        }

        public IEnumerator PlayAnim()
        {
            if (ItemType == InboxItemType.SeasonGift
                && RewardType == RewardData.RANDOM
                && mysteryBox != null
                && mysteryBox.gameObject.activeInHierarchy)
            {
                mysteryBox.SetTrigger(TRIGGER_OPEN);
                yield return new WaitForSecondsRealtime(mysteryBoxDuration);
            }
            yield break;
        }

        public void DeleteItem()
        {
            if (OnDelete != null)
            {
                OnDelete.Invoke(this);
            }
        }

        private void SetSizeDelta(RectTransform g, Vector2 newSize)
        {
            Vector2 oldSize = g.rect.size;
            Vector2 deltaSize = newSize - oldSize;
            g.offsetMin = g.offsetMin - new Vector2(deltaSize.x * g.pivot.x, deltaSize.y * g.pivot.y);
            g.offsetMax = g.offsetMax + new Vector2(deltaSize.x * (1f - g.pivot.x), deltaSize.y * (1f - g.pivot.y));
        }

        private void SetRectHeight(RectTransform tg, float newSize)
        {
            SetSizeDelta(tg, new Vector2(tg.rect.size.x, newSize));
        }
    }
}
