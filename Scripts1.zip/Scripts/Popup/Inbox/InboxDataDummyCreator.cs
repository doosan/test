using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Gaga;
using Underc.Auth;
using UnityEngine;

namespace Underc.Popup
{
    public class InboxDataDummyCreator
    {
        public static InboxItemRewardData CreateDummyReward(string rewardType, long rewardValue)
        {
            InboxItemRewardData data = new InboxItemRewardData();

            if (rewardType == RewardData.RANDOM)
            {
                var randomTypes = new string[]
                {
                    RewardData.COIN,
                    RewardData.PEARL,
                    RewardData.TICKET,
                    RewardData.GOLDEN,
                    RewardData.OBSIDIAN,
                    RewardData.XP_BOOSTER,
                    RewardData.FISH
                };

                var selectedType = randomTypes[UnityEngine.Random.Range(0, randomTypes.Length)];

                data.rwd = selectedType;

                if (selectedType == RewardData.FISH)
                {
                    rewardValue = GetRandomFishID();
                }
            }
            else
            {
                data.rwd = rewardType;
            }

            data.val = rewardValue;
            if (data.val == 0L)
            {
                data.val = UnityEngine.Random.Range(1, 999);
            }

            return data;
        }

        private static DateTime GetDateTimeromTS(long ts)
        {
            DateTime zero = new DateTime(1970, 1, 1, 0, 0, 0, 0);
            return zero.AddSeconds(ts);
        }

        private static long GetTestTimeStamp(long nowts, TimeSpan ts)
        {
            return nowts + (long)ts.TotalSeconds;
        }

        private static long GetRandomTimeStamp(int days = -1, int hours = -1, int min = -1, int sec = -1)
        {
            long nowTS = GlobalTime.Instance.GetTimeStamp();

            int d = days >= 0 ? days : UnityEngine.Random.Range(0, 30);
            int h = hours >= 0 ? hours : UnityEngine.Random.Range(0, 24);
            int m = min >= 0 ? min : UnityEngine.Random.Range(0, 60);
            int s = sec >= 0 ? sec : UnityEngine.Random.Range(0, 60);

            long randomTS = GetTestTimeStamp(nowTS, new TimeSpan(d, h, m, s));

            // Debug.LogFormat("now: {0} test: {1}", GetDateTimeromTS(nowTS), GetDateTimeromTS(randomTS));

            return randomTS;
        }

        public static InboxItemData[] AddDummyItems(InboxItemData[] originData)
        {
            if (originData == null)
            {
                originData = new InboxItemData[] { };
            }

            long nowTS = GlobalTime.Instance.GetTimeStamp();
            // long randomTS = GetRandomTimeStamp();
            GetRandomTimeStamp(0, 0, 0, 1);
            GetRandomTimeStamp(0, 0, 1, 0);
            GetRandomTimeStamp(0, 1, 0, 0);
            GetRandomTimeStamp(1, 0, 0, 0);

            var dummyList = new List<InboxItemData>();


            dummyList.Add(new InboxItemData()
            {
                type = (int)InboxItemType.FacebookLogin,
                msg = "Login with facebook and collect <color=#fff600>1M COIN BONUS.</color>"
            });

            dummyList.Add(new InboxItemData()
            {
                type = (int)InboxItemType.FacebookLoginBonus,
                msg = "Facebook connected.<br>Collect <color=#fff600>1M COIN BONUS!</color>"
            });

            dummyList.Add(new InboxItemData()
            {
                type = (int)InboxItemType.WelcomBonus,
                msg = "WELCOME BONUS<br>Get <color=#fff600>1M coins.</color>"
            });

            dummyList.Add(new InboxItemData()
            {
                id = 15154,
                type = (int)InboxItemType.OceanPassReward,
                rwd = "vip_point",
                val = 3,
                msg = "hank you for update! Maintenance has been finished well! Here is Huge Bonus! Let's Spin & Enjoy Aquuua Casino!",
                xpr = 1659798000,
            });

            dummyList.Add(new InboxItemData()
            {
                type = (int)InboxItemType.SeasonGift,
                rwd = RewardData.RANDOM,
                msg = "<color=#fff600>X-MAS GIFT!</color><br>Check it out tomorrow<br>too, for more Gifts.",
                xpr = GetRandomTimeStamp(0, 0, 0, 14)
            });

            dummyList.Add(new InboxItemData()
            {
                type = (int)InboxItemType.AppUpdateReward,
                rwd = RewardData.COIN,
                msg = "Successful update to<br>the latest version.<br>Here is reward of <color=#ffdd00>200K coins.</color>",
                xpr = GetRandomTimeStamp(0, 0, 0, 9)
            });

            dummyList.Add(new InboxItemData()
            {
                type = (int)InboxItemType.CSReward,
                rwd = RewardData.PEARL_TICKET_BOOSTER,
                msg = "pearl & ticket booster test",
                xpr = GetRandomTimeStamp(0, 0, 50, -1)
            });

            dummyList.Add(new InboxItemData()
            {
                type = (int)InboxItemType.InviteReward,
                rwd = RewardData.COIN,
                picn = UnityEngine.Random.Range(0, 12) + 1,
                msg = "<color=#ff0000>INVITATION SUCCESSFUL</color><br>Get <color=#ffDD00>300K coins.</color>",
                xpr = GetRandomTimeStamp(0, 10, 0, 0)
            });

            dummyList.Add(new InboxItemData()
            {
                type = (int)InboxItemType.CollectGift,
                rwd = RewardData.COIN,
                pic = "https://scontent-ssn1-1.xx.fbcdn.net/v/t1.0-9/73116002_683108865518357_2514480443005337600_n.jpg?_nc_cat=101&_nc_sid=09cbfe&_nc_eui2=AeEbD4_JiRtEebwhwB3_v9mL7FNXvoXS0FPsU1e-hdLQUyHDyNwNIsX7RQEPSR3tFI9hj94czkkDGkQVrIrvkw68&_nc_ohc=JErn1-eJDZYAX8T-6vI&_nc_ht=scontent-ssn1-1.xx&oh=84d5084f06ba54f69045ef1c74170b72&oe=5F62D434",
                msg = "<color=#00ffff>Donald J. Trump<br>HAS SENT YOU A GIFT!</color><br>Get <color=#ffDD00>100K coins.</color>",
                xpr = GetRandomTimeStamp(20, 5, 0, 0)
            });

            dummyList.Add(new InboxItemData()
            {
                type = (int)InboxItemType.SendGift1Week,
                picn = UnityEngine.Random.Range(0, 12) + 1,
                msg = "<br>Brad Pitt will appreciate<br>your gift of <color=#ffDD00>100K COIN BONUS.</color>"
            });

            dummyList.Add(new InboxItemData()
            {
                type = (int)InboxItemType.SendGift2Week,
                pic = "https://scontent-ssn1-1.xx.fbcdn.net/v/t1.0-9/12508932_793369927455403_953661770252157023_n.jpg?_nc_cat=103&_nc_sid=09cbfe&_nc_eui2=AeEHUjjzLgzAjGnE6q3SYTD6xpKahpa9wyjGkpqGlr3DKPqdnA8ghIjXcRS8gQGxEfzTinOntQlhAGRq9BogDKme&_nc_ohc=deIMAgfpCQ4AX-xlJ3l&_nc_ht=scontent-ssn1-1.xx&oh=c9c01ae7aac89f6e8153242eaaa88391&oe=5F64E751",
                msg = "<br>An kisuk will appreciate<br>your gift of <color=#ffDD00>50K COIN BONUS.</color>"
            });

            dummyList.Add(new InboxItemData()
            {
                type = (int)InboxItemType.InviteFriends,
                msg = "<br>Your friends will like your<br>inviation and <color=#ffDD00>COIN BONUS.</color>"
            });


            //오션패스 남은 보상
            var oceanRewardTypes = new string[]
            {
                RewardData.COIN,
                RewardData.PEARL,
                RewardData.TICKET,
                RewardData.GOLDEN,
                RewardData.OBSIDIAN,
                RewardData.XP_BOOSTER,
                RewardData.FISH
            };

            for (int i = 0; i < oceanRewardTypes.Length; ++i)
            {
                var rewardyType = oceanRewardTypes[i];
                long rewardValue = 0;
                if (rewardyType == RewardData.FISH)
                {
                    rewardValue = GetRandomFishID();
                }
                else
                {
                    rewardValue = UnityEngine.Random.Range(100000, 10000000);
                }

                dummyList.Add(new InboxItemData()
                {
                    type = (int)InboxItemType.OceanPassReward,
                    rwd = rewardyType,
                    val = rewardValue,
                    msg = "<color=#362020>Looks like you forgot to<br>claim this in the previous<br>season's Ocean Pass! </color>",
                    xpr = GetRandomTimeStamp()
                });
            }

            dummyList.Sort((a, b) =>
            {
                if (a.type < b.type) return -1;
                else if (a.type > b.type) return 1;
                else return 0;
            });

            for (int i = 0; i < dummyList.Count; ++i)
            {
                dummyList[i].id = 0;
            }

            var originList = originData.ToList();
            originData = originList.Concat(dummyList).ToArray();
            return originData;
        }

        private static long GetRandomFishID()
        {
            long[] randomFishIds = new long[] { 5, 4, 20, 29, 39, 53, 7, 10, 24, 34, 41, 65, 18 };
            return randomFishIds[UnityEngine.Random.Range(0, randomFishIds.Length)];
        }
    }
}