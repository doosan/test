using NUnit.Framework;
using System;
using Underc.User;

public class TestTryParse
{
    [Test]
    public void TestTryParse1()
    {
        // 1. Arrage
        RewardType rewardType = RewardType.none;

        // 2. Act
        Enum.TryParse("", out rewardType);

        // 3. Assert
        Assert.AreEqual(RewardType.none, rewardType);
    }

    [Test]
    public void TestTryParse2()
    {
        // 1. Arrage
        RewardType rewardType = RewardType.none;

        // 2. Act
        Enum.TryParse("Fail", out rewardType);

        // 3. Assert
        Assert.AreEqual(RewardType.none, rewardType);
    }


    [Test]
    public void TestTryParse3()
    {
        // 1. Arrage
        RewardType rewardType = RewardType.none;

        // 2. Act
        Enum.TryParse("vip_point", out rewardType);

        // 3. Assert
        Assert.AreEqual(RewardType.vip_point, rewardType);
    }
}
