using UnityEngine;
using UnityEngine.UI;
using System;
using Underc.User;
using Gaga.Util;
using Gaga;

namespace Underc
{
    public sealed class InboxRewardItem : MonoBehaviour
    {
#pragma warning disable 0649
        [SerializeField] private Text valueText;

        [Header("Rewards")]
        [SerializeField] private GameObject randomReward;
        [SerializeField] private GameObject coinReward;
        [SerializeField] private GameObject pearlReward;
        [SerializeField] private GameObject ticketReward;
        [SerializeField] private GameObject goldenReward;
        [SerializeField] private GameObject obsidianReward;
        [SerializeField] private GameObject xpBoosterReward;
        [SerializeField] private GameObject pearlTicketBoosterReward;
        [SerializeField] private GameObject fishReward;
        [SerializeField] private Image fishRewardImage;
        [SerializeField] private GameObject silverPickaxeReward;
        [SerializeField] private GameObject goldPickaxeReward;
        [SerializeField] private GameObject vipClass;
        [SerializeField] private GameObjectVisibleToggle vipClassVisibleToggle;

        [Header("Frame")]
        [SerializeField] private GameObject rewardBG;
#pragma warning restore 0649

        private RewardType rewardType;
        private long rewardValue;
        private VipClassType vipClassType;

        public void Setup(string reward, long rewardValue = 0, VipClassType vipClassType = VipClassType.none)
        {
            rewardType = RewardType.none;
            Enum.TryParse(reward, out rewardType);
            this.rewardValue = rewardValue;
            this.vipClassType = vipClassType;

            UpdateRewardIcon();
            UpdateFishImage();
            UpdateValueText();
        }

        private void UpdateRewardIcon()
        {
            if (randomReward != null) randomReward.SetActive(rewardType == RewardType.rand);
            if (coinReward != null) coinReward.SetActive(rewardType == RewardType.coin);
            if (pearlReward != null) pearlReward.SetActive(rewardType == RewardType.pearl);
            if (ticketReward != null) ticketReward.SetActive(rewardType == RewardType.ticket);
            if (goldenReward != null) goldenReward.SetActive(rewardType == RewardType.golden);
            if (obsidianReward != null) obsidianReward.SetActive(rewardType == RewardType.obsidian);
            if (xpBoosterReward != null) xpBoosterReward.SetActive(rewardType == RewardType.xp_booster);
            if (pearlTicketBoosterReward != null) pearlTicketBoosterReward.SetActive(rewardType == RewardType.pearl_booster);
            if (silverPickaxeReward != null) silverPickaxeReward.SetActive(rewardType == RewardType.s_pickaxe);
            if (goldPickaxeReward != null) goldPickaxeReward.SetActive(rewardType == RewardType.g_pickaxe);
            if (fishReward != null) fishReward.gameObject.SetActive(rewardType == RewardType.fish);
            if (vipClass != null)
            {
                bool isVipClassVisible = rewardType == RewardType.vip_point;
                vipClass.SetActive(isVipClassVisible);
                if (isVipClassVisible)
                {
                    vipClassVisibleToggle.TurnOnByNameInMultiple(vipClassType.ToString());
                }
            }
        }

        private void UpdateFishImage()
        {
            Sprite fishSprite = null;
            if (rewardType == RewardType.fish)
            {
                int fishID = (int)rewardValue;
                var bookInfo = MyInfo.Ocean.Book.GetBookInfo(SeaItemType.f, fishID);
                fishSprite = bookInfo == null ? null : bookInfo.Icon;
            }

            SetFishImage(fishSprite);
        }

        public void SetFishImage(Sprite sprite)
        {
            if (fishRewardImage != null)
            {
                fishRewardImage.sprite = sprite;
                fishRewardImage.preserveAspect = true;
                fishRewardImage.gameObject.SetActive(sprite != null);
            }
        }

        public void HideAllRewardIcon()
        {
            if (randomReward != null) randomReward.SetActive(false);
            if (coinReward != null) coinReward.SetActive(false);
            if (pearlReward != null) pearlReward.SetActive(false);
            if (ticketReward != null) ticketReward.SetActive(false);
            if (goldenReward != null) goldenReward.SetActive(false);
            if (obsidianReward != null) obsidianReward.SetActive(false);
            if (xpBoosterReward != null) xpBoosterReward.SetActive(false);
            if (pearlTicketBoosterReward != null) pearlTicketBoosterReward.SetActive(false);
            if (fishRewardImage != null) fishRewardImage.gameObject.SetActive(false);
            if (silverPickaxeReward != null) silverPickaxeReward.SetActive(false);
            if (goldPickaxeReward != null) goldPickaxeReward.SetActive(false);
            if (vipClass != null) vipClass.SetActive(false);
        }

        public void SetBGEnable(bool enable)
        {
            if (rewardBG == null)
            {
                return;
            }

            rewardBG.SetActive(enable);
        }

        private void UpdateValueText()
        {
            if (valueText == null)
            {
                return;
            }

            if (rewardType == RewardType.none)
            {
                valueText.text = string.Empty;
            }
            else if (rewardType == RewardType.fish
                     || rewardType == RewardType.rand)
            {
                valueText.text = "1";
            }
            else if (rewardType == RewardType.pearl_booster
                     || rewardType == RewardType.xp_booster)
            {
                valueText.text = rewardValue.ToBoosterRewardHM();
            }
            else
            {
                StringUtils.KMBOption option = StringUtils.GeneralKMBOption();
                valueText.text = StringUtils.ToKMB(rewardValue, option);
            }
        }

        private void OnDisable()
        {
            SetFishImage(null);
        }
    }
}