﻿using System;
using System.Collections;
using System.Collections.Generic;
using Gaga.Popup;
using UnityEngine;
using TMPro;
using Gaga;
using Gaga.Util;
using Underc.Scene;

namespace Underc.Popup
{
    public class MaintenancePopup : PopupBehaviour
    {
        public enum MaintenanceType
        {
            None,
            BeforeApp,
            BeforeSlot,
            App,
            Slot,
        }

        private readonly string FORMAT_APP = @"Maintenance for better game experience is undergoing.
        We will endeavor to complete it as quickly as possible.
        Thank you for understanding and patience.

        <color=#ffff00><size=28>Maintenance is scheduled to end in
        {0}</color></size>";

        private readonly string FORMAT_BEFORE_APP = @"Maintenance break for better game experience will start soon.
        Please, exit the game now and return after the break.
        We apologize for any inconveniences this might cause you.

        <color=#ffff00><size=28>Remaining time until the maintenance starts in
        {0}</color></size>";

        private readonly string FORMAT_BEFORE_SLOT = @"This slot is about to undergo maintenance.
        Please, spin other slots that are available at the lobby.
        We apologize for any inconveniences this might cause you.
        
        <color=#ffff00><size=28>You will be automatically moved to the lobby in
        {0}</color></size>";

        [SerializeField] private TextMeshProUGUI message = null;

        private string B_APP = "";
        private string BEFORE_APP = "";

        private MaintenanceType type;
        private MaintenanceData currentData;
        private long remainSeconds;
        private Coroutine waitCoroutine;
        private Action onComplete;

        public void Open(MaintenanceData data, Action onComplete = null)
        {
            message.text = string.Empty;
            this.onComplete = onComplete;

            UpdateData(data);

            waitCoroutine = StartCoroutine(WaitRemainTime());
        }

        public void UpdateData(MaintenanceData data)
        {
            currentData = data;

            if( currentData == null )
            {
                type = MaintenanceType.None;
                return;
            }

            long now = GlobalTime.Instance.GetTimeStamp();
            bool isBefore = now < currentData.start;
            bool isApp = currentData.id == MaintenanceData.ID_APP;

            if (isApp)
            {
                type = isBefore ? MaintenanceType.BeforeApp : MaintenanceType.App;
            }
            else
            {
                type = isBefore ? MaintenanceType.BeforeSlot : MaintenanceType.Slot;
            }

            Debug.LogFormat("MaintenanceType: {0}, now: {1}\nitem: {2}", type, now, currentData);
        }

        private IEnumerator WaitRemainTime()
        {
            WaitForSeconds wait = new WaitForSeconds(1f);

            do
            {
                UpdateRemainTime();

                if (remainSeconds >= 0)
                {
                    DisplayMessage();
                    yield return wait;
                }

            } while (remainSeconds >= 0);

            Close();
        }

        private void UpdateRemainTime()
        {
            switch (type)
            {
                case MaintenanceType.None:
                    //10분이 남았다고 점검 팝업이 열려있는 도중이라도 점검이 취소되거나 조기 종료 된 경우 즉시 닫아야 한다.
                    remainSeconds = -1;
                    break;

                case MaintenanceType.BeforeApp:
                case MaintenanceType.BeforeSlot:
                    remainSeconds = currentData.start - GlobalTime.Instance.GetTimeStamp();
                    break;

                case MaintenanceType.App:
                    remainSeconds = currentData.end - GlobalTime.Instance.GetTimeStamp();
                    break;

                case MaintenanceType.Slot:
                    //슬롯이 점검이 시작된 이후 슬롯에 접속 했을 때는 화면에 남은 시간을 표시하지 않고 바로 닫아야 한다
                    remainSeconds = -1;
                    break;
            }
        }

        private string GetMessage()
        {
            // string time = remainSeconds.ToSummaryDHMS();
            string time = remainSeconds.ToHMS();
            string formatString = string.Empty;
            switch (type)
            {
                case MaintenanceType.BeforeApp:
                    formatString = FORMAT_BEFORE_APP;
                    break;
                case MaintenanceType.BeforeSlot:
                    formatString = FORMAT_BEFORE_SLOT;
                    break;
                case MaintenanceType.App:
                    formatString = FORMAT_APP;
                    break;
            }

            if (string.IsNullOrEmpty(formatString))
            {
                return time;
            }
            else
            {
                return string.Format(System.Globalization.CultureInfo.InvariantCulture, formatString, time);
            }
        }

        private void DisplayMessage()
        {
            message.text = GetMessage();
        }

        private void CloseAction()
        {
            if (waitCoroutine != null)
            {
                StopCoroutine(waitCoroutine);
                waitCoroutine = null;
            }

            if( onComplete != null )
            {
                onComplete();
                onComplete = null;
            }

            switch (type)
            {
                case MaintenanceType.BeforeApp:
                    Scene.SceneSystem.LoadIntro();
                    break;
                case MaintenanceType.BeforeSlot:
                    Scene.SceneSystem.LoadLobby(SceneSystem.LOBBY_STATE_INDEX_GAME);
                    break;
                case MaintenanceType.App:
                    //최초 인트로 로딩 시 보여지게 된다. 점검 시간이 끝나면 팝업이 끝나고 자연스럽게 인트로 로딩이 진행됨
                    break;
                case MaintenanceType.Slot:
                    Scene.SceneSystem.LoadLobby(SceneSystem.LOBBY_STATE_INDEX_GAME);
                    break;
            }
        }

        public override void Close()
        {
            base.Close();

            CloseAction();
            currentData = null;
        }
    }
}