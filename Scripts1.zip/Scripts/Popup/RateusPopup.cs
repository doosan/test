using System;
using Gaga.Popup;
using Underc.User;


namespace Underc.Popup
{
    public class RateusPopup : PopupBackable
    {
        private static readonly string KEY_HAS_REVIEWED = "k_underc_hasreviewed";
        private static readonly string KEY_LATER_REVIEW = "k_underc_later_review";

        public static readonly string KEY_OPEN_COUNT = "rate_open_cnt";

        private static bool HasReviewed
        {
            get => UndercPrefs.GetLocalValue(KEY_HAS_REVIEWED, 0) == 1;
            set => UndercPrefs.SetLocalValue(KEY_HAS_REVIEWED, value ? 1 : 0);
        }

        public static bool CanReviewed
        {
            get
            {
                int lastLaterTimeSec = UndercPrefs.GetLocalValue(KEY_LATER_REVIEW, 0);
                DateTime lastLaterTime = new DateTime(1970, 1, 1, 0, 0, 0).AddSeconds(lastLaterTimeSec);
                DateTime now = DateTime.UtcNow;
                TimeSpan elapsedTime = now - lastLaterTime;

#if DEV
                return elapsedTime.TotalMinutes >= 3;
#else
                return elapsedTime.TotalDays >= 3;
#endif
            }
        }

        public static bool CanOpen
        {
            get => MyInfo.Level >= 9 && HasReviewed == false && CanReviewed == true;
        }

        public static void Reset()
        {
            UndercPrefs.DeleteLocalValue(KEY_HAS_REVIEWED);
            UndercPrefs.DeleteLocalValue(KEY_LATER_REVIEW);
        }

        private void WriteLaterTime()
        {
            long utcSec = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            UndercPrefs.SetLocalValue(KEY_LATER_REVIEW, (int)utcSec);
        }

        private Action onComplete;

        public void Open(Action onCompelte = null)
        {
            this.onComplete = onCompelte;

            int cnt = int.Parse(UndercPrefs.GetRemoteValue(KEY_OPEN_COUNT, "0"));
            cnt++;

            UndercPrefs.SetRemoteValue(KEY_OPEN_COUNT, cnt.ToString());
        }

        public void Later()
        {
            UndercGameLog.Fobis.PopupStar(1);

            WriteLaterTime();
            Close();
        }

        public void Review()
        {
            UndercGameLog.Fobis.PopupStar(2);

            HasReviewed = true;
            AppService.OpenStore();
            Close();
        }

        public override void Close()
        {
            if (onComplete != null)
            {
                onComplete.Invoke();
                onComplete = null;
            }

            base.Close();
        }
    }
}
