﻿using System.Collections;
using System.Collections.Generic;
using Underc.Lobby;
using UnityEngine;

namespace Underc
{
    public class SocialPopupTestButton : MonoBehaviour
    {
        public float openDelay = 0.2f;
        private Coroutine coroutine;

        public void TestSocialPopup()
        {
#if UNITY_EDITOR || SOCIAL
            if( coroutine != null ) StopCoroutine(coroutine);
            coroutine = StartCoroutine(OpenSocialPopupCoroutine());
#endif
        }

        private IEnumerator OpenSocialPopupCoroutine()
        {
            yield return new WaitForSeconds(openDelay);
            
            var oceanLobby = GameObject.FindObjectOfType<OceanLobby>();
            oceanLobby.OpenSocial();

            yield break;
        }
    }
}
