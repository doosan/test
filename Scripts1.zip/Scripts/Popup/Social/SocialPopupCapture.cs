﻿using System.Collections;
using System.Collections.Generic;
using Gaga.Util;
using Underc.Lobby;
using Underc.Util;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using Underc.Net;
using System.IO;
using Underc.User;
using static Underc.Popup.WarningPopup;
using System;
using DG.Tweening;
using Gaga.UI;
using Gaga.Popup;
using Gaga.Interaction;

namespace Underc.Popup
{
    public class SocialPopupCapture : MonoBehaviour
    {
        private readonly string UNTITLED = "UNTITLED";
        private readonly int JPG_QUALITY = 75;//1~100
        private readonly string WARNING_MSG = @"This Sea Aquaruim has been already
        submitted to contest for this week.
        
        Do you wish to cancel submitted
        screenshot and replace to new one?";


#pragma warning disable 0649
        [SerializeField] private GameObject captureScreen;
        [SerializeField] private GameObject submitContainer;

        [Header("Edit")]
        [SerializeField] private UIDragableObject dragObject = null;
        [SerializeField] private GestureScale gesture;
        [SerializeField] private float minScale;
        [SerializeField] private float maxScale;


        [Header("Submit")]
        [SerializeField] private RectTransform seaImageRect;
        [SerializeField] private Image seaImage;
        [SerializeField] private AspectRatioFitter frameRatioFitter;
        [SerializeField] private AspectRatioFitter screenShotRatioFitter;
        [SerializeField] private Ease sizeTweenEase = Ease.Linear;
        [SerializeField] private float sizeTweenDuration = 0.5f;
        [SerializeField] private float sizeTweeStartDelay = 0.1f;

        [SerializeField] private bool saveFile = false;

        [Header("Frame")]
        [SerializeField] private GameObject frameCanvas = null;
        [SerializeField] private RectTransform frameTL = null;
        [SerializeField] private RectTransform frameBR = null;

        [Header("Bottom")]
        [SerializeField] private RectTransform bottom;
        [SerializeField] private float bottomHideY;
        [SerializeField] private float bottomTweenDelay = 0.3f;
        [SerializeField] private Ease bottomTweenEase = Ease.Linear;
        [SerializeField] private GameObject submitUI;
        [SerializeField] private GameObject submitComplete;
        [SerializeField] private TMP_InputField inputText;

        [Header("Upload")]
        [SerializeField] private TextMeshProUGUI uploadTitleText;
        [SerializeField] private float uploadCompleteDelay = 1.5f;
#pragma warning restore 0649

        public SocialPopup Parent { get; set; }
        private Texture2D screenShot;
        private Texture2D uploadScreenShot;

        private RectTransform submitContainerRect;
        private RectTransform ratioFitterRect;
        private RectTransform screenShotFitterRect;

        private Coroutine editCoroutine;

        public bool IsEditMode { get; private set; }
        private float cachedBottomY;


        private void Awake()
        {
            submitContainerRect = submitContainer.GetComponent<RectTransform>();
            ratioFitterRect = frameRatioFitter.GetComponent<RectTransform>();
            screenShotFitterRect = screenShotRatioFitter.GetComponent<RectTransform>();

            seaImage.color = new Color(1, 1, 1, 1);

            cachedBottomY = bottom.anchoredPosition.y;
            dragObject.enabled = false;

            gesture.OnInit += OnGestureScaleInit;
            gesture.OnMove += OnMove;
            gesture.OnEnd += OnEnd;
            gesture.enabled = false;

#if !DEV || !UNITY_EDITOR
            saveFile = false;
#endif
        }

        public void CaptureMode()
        {
            IsEditMode = false;

            dragObject.SetRootCanvas(PopupSystem.Instance.Canvas);
            dragObject.enabled = false;
            gesture.enabled = false;

            gameObject.SetActive(true);

            if (editCoroutine != null)
            {
                StopCoroutine(editCoroutine);
                editCoroutine = null;
            }

            Parent.HideBG();
            Parent.HideLobbyUI();

            bottom.DOKill();
            bottom.anchoredPosition = new Vector2(bottom.anchoredPosition.x, cachedBottomY - bottomHideY);

            seaImageRect.localScale = Vector3.one;
            seaImageRect.FullArea();

            captureScreen.SetActive(true);
            submitContainer.SetActive(false);

            ClearScreenShot();
        }


        public void Capture()
        {
            captureScreen.SetActive(false);

            Parent.HideCloseButton();

            ScreenshotSystem.Instance.Take((texture) =>
            {
                editCoroutine = StartCoroutine(EditMode(texture));
            });
        }

        private IEnumerator EditMode(Texture2D texture)
        {
            Parent.ShowCloseButton();

            screenShot = texture;
            uploadScreenShot = screenShot;

            IsEditMode = true;

            Parent.ShowBG();
            submitContainer.SetActive(true);
            seaImage.sprite = ConvertToSprite(screenShot);

            // ratioFitter.aspectRatio = (float)Screen.width / (float)Screen.height;
            frameRatioFitter.aspectRatio = Parent.thumnailSize.x / Parent.thumnailSize.y;
            screenShotRatioFitter.aspectRatio = (float)Screen.width / (float)Screen.height;

            yield return new WaitForEndOfFrame();
            yield return new WaitForSeconds(sizeTweeStartDelay);

            ShowSubmitUI();

            yield return TweenScreenShotSize();
            dragObject.enabled = true;
            gesture.enabled = true;

            yield break;
        }

        private YieldInstruction TweenScreenShotSize()
        {
            var fitterSize = new Vector2(screenShotFitterRect.GetWidth(), screenShotFitterRect.GetHeight());

            DOTween.To(GetSeaMaskSize, SetSeaMaskSize, fitterSize, sizeTweenDuration).SetEase(sizeTweenEase);
            var tween = seaImageRect.DOMove(screenShotFitterRect.position, sizeTweenDuration).SetEase(sizeTweenEase);
            return tween.WaitForCompletion();
        }

        private Vector2 GetSeaMaskSize()
        {
            return new Vector2(seaImageRect.GetWidth(), seaImageRect.GetHeight());
        }

        public void SetSeaMaskSize(Vector2 size)
        {
            seaImageRect.SetSizeDelta(size);
        }

        private void ShowSubmitUI()
        {
            submitUI.SetActive(true);
            submitComplete.SetActive(false);
            inputText.text = string.Empty;

            bottom.DOAnchorPosY(cachedBottomY, sizeTweenDuration).SetDelay(bottomTweenDelay).SetEase(bottomTweenEase);
        }


        private void CheckSea(Action callback)
        {
            int seaID = MyInfo.Ocean.CurrentSeaID;
            Debug.LogFormat("CheckSea: {0}", seaID);
            if (Parent.IsUploadedSea(seaID) == false)
            {
                callback.Invoke();
                return;
            }

            Popups.Warning(message: WARNING_MSG,
                           actionType: WarningPopup.ActionType.None,
                           titleType: WarningPopup.TitleType.Basic,
                           onOK: () => callback.Invoke());
        }

        public void SubmitWithoutTitle()
        {
            dragObject.enabled = false;
            CheckSea(() =>
            {
                StartCoroutine(SubmitCoroutine(UNTITLED));
            });
        }

        public void Submit()
        {
            dragObject.enabled = false;
            CheckSea(() =>
            {
                StartCoroutine(SubmitCoroutine(inputText.text));
            });
        }

        private IEnumerator SubmitCoroutine(string title)
        {
            var sendTime = Time.time;

            frameCanvas.SetActive(false);
            submitUI.SetActive(false);
            Parent.HideCloseButton();

            yield return new WaitForEndOfFrame();

            uploadScreenShot = GetCroppedScreenShot();

            if (string.IsNullOrEmpty(title) == true)
            {
                title = UNTITLED;
            }

            int seaID = MyInfo.Ocean.CurrentSeaID;
            byte[] bytes = uploadScreenShot.EncodeToJPG(JPG_QUALITY);

            if (saveFile == true)
            {
                Save(bytes, string.Format(System.Globalization.CultureInfo.InvariantCulture, "MySea_{0}.jpg", MyInfo.Ocean.CurrentSeaID));
            }

            uploadTitleText.text = title;
            submitComplete.SetActive(true);
            frameCanvas.SetActive(true);

            Debug.LogFormat("sea: {0} title: {1} qual: {2} bytes:{3}", seaID, title, JPG_QUALITY, bytes.Length);

            Popups.ShowLoading();
            var req = NetworkSystem.HTTPRequester.VoteCapture(seaID, title, bytes);
            yield return req.WaitForResponse();

            if (req.isSuccess == false)
            {
                Popups.HideLoading();
                submitUI.SetActive(true);
                Parent.ShowCloseButton();

                Parent.ErrorPopup(req.data.error, false);
                yield break;
            }

            while (Time.time - sendTime < uploadCompleteDelay)
            {
                yield return null;
            }

            Popups.HideLoading();

            IsEditMode = false;
            Parent.Close();

            yield break;
        }

        private Texture2D GetCroppedScreenShot()
        {
            var popupCam = PopupSystem.Instance.Canvas.worldCamera;
            Vector2 tlScreenPos = popupCam.WorldToScreenPoint(frameTL.position);
            Vector2 brScreenPos = popupCam.WorldToScreenPoint(frameBR.position);

            float x = tlScreenPos.x;
            float y = brScreenPos.y;
            int w = (int)(brScreenPos.x - tlScreenPos.x);
            int h = (int)(tlScreenPos.y - brScreenPos.y);

            var rect = new Rect(x, y, w, h);

            return ScreenshotSystem.Instance.GetScreenShot(w, h, rect);
        }

        public void Clear()
        {
            if (gameObject.activeSelf == true)
            {
                IsEditMode = false;

                gameObject.SetActive(false);

                Parent.ShowBG();
                Parent.ShowLobbyUI();

                ClearScreenShot();

                dragObject.enabled = false;
                gesture.enabled = false;
            }
        }

        private void ClearScreenShot()
        {
            if (screenShot != null)
            {
                Texture2D.DestroyImmediate(screenShot);
                GameObject.Destroy(screenShot);
                screenShot = null;
            }

            if (uploadScreenShot != null)
            {
                Texture2D.DestroyImmediate(uploadScreenShot);
                GameObject.Destroy(uploadScreenShot);
                uploadScreenShot = null;
            }

            seaImage.sprite = null;
        }


        private void OnGestureScaleInit(TouchInfo t1, TouchInfo t2)
        {
            dragObject.Lock = true;
            dragObject.StopDrag();
        }

        private void OnMove(TouchInfo t1, TouchInfo t2)
        {
            Vector3 scale = new Vector3
            (
                (seaImageRect.localScale.x * gesture.ScaleMultiplier),
                (seaImageRect.localScale.y * gesture.ScaleMultiplier),
                (seaImageRect.localScale.z * gesture.ScaleMultiplier)
            );

            if (minScale > 0.0f || maxScale > 0.0f)
            {
                scale.x = Mathf.Clamp(scale.x, minScale, maxScale);
                scale.y = Mathf.Clamp(scale.y, minScale, maxScale);
            }

            scale.z = seaImageRect.localScale.z;
            seaImageRect.localScale = scale;
        }

        private void OnEnd()
        {
            dragObject.Lock = false;
        }

        private void Save(byte[] bytes, string filename)
        {
            string filePath = Path.Combine(Application.temporaryCachePath,
                                           StringMaker.New()
                                                      .Append(filename)
                                                      .Build());

            Debug.LogFormat("Save screenShot. {0}", filePath);

            File.WriteAllBytes(filePath, bytes);
        }

        private Sprite ConvertToSprite(Texture2D texture, float pivotX = 0.5f, float pivotY = 0.5f)
        {
            return Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), new Vector2(pivotX, pivotY));
        }
    }
}
