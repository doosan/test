﻿using System.Collections;
using Underc.Net;
using Underc.Net.Client;
using UnityEngine;
using UnityEngine.UI;
using Gaga.UI;

namespace Underc.Popup
{
    public partial class SocialPopupContent
    {

        public class MyScoreData
        {
            public string url;
            public string title;
            public int score;
        }

#pragma warning disable 0649

        [Header("Score")]
        [SerializeField] private GameObject contentScore;
        [SerializeField] private SocalPopupScoreItem itemTemplate;
        [SerializeField] private ListView listView;
        [SerializeField] private RectTransform listViewRect;
        [SerializeField] private Button prevButton;
        [SerializeField] private Button nextButton;
        [SerializeField] private float moveDuration = 0.2f;

#pragma warning restore 0649

        private int currentPageIndex;
        private int maxPageCount;

        private void InitScore()
        {
            listView.onTargetIndexChanged += OnPageIndexChanged;
            prevButton.onClick.AddListener(Prev);
            nextButton.onClick.AddListener(Next);
        }

        private IEnumerator ShowScore()
        {
            Popups.ShowLoading();
            var req = NetworkSystem.HTTPRequester.VoteScore();
            yield return req.WaitForResponse();

            if (req.isSuccess == false)
            {
                Popups.HideLoading();
                Parent.ErrorPopup(req.data.error);
                yield break;
            }

            Popups.HideLoading();

            VoteScoreResponse resp = req.data;
            Parent.SetExistSea(resp.exist_sea);


            currentContent.SetActive(true);

            maxPageCount = resp.sea_score.Length;

            for (int i = 0; i < maxPageCount; ++i)
            {
                var data = new MyScoreData()
                {
                    title = resp.pic_title[i],
                    url = resp.pic_url[i],
                    score = resp.sea_score[i]
                };

                var item = Instantiate(itemTemplate);
                item.UpdateItem(data);
                item.gameObject.SetActive(true);
                var rect = item.GetComponent<RectTransform>();
                rect.sizeDelta = listViewRect.sizeDelta;
                listView.AddItem(rect);
            }

            GoTo(0);

            yield break;
        }

        public void GoTo(int page, float moveTime = 0)
        {
            OnPageIndexChanged(page);
            listView.GoTo(currentPageIndex, moveTime);
        }

        private void Next()
        {
            GoTo(currentPageIndex + 1, moveDuration);
        }

        private void Prev()
        {
            GoTo(currentPageIndex - 1, moveDuration);
        }

        private void OnPageIndexChanged(int index)
        {
            currentPageIndex = index;
            currentPageIndex = Mathf.Clamp(currentPageIndex, 0, maxPageCount - 1);

            prevButton.interactable = currentPageIndex > 0;
            nextButton.interactable = currentPageIndex < maxPageCount - 1;
        }
    }
}