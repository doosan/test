﻿using System.Collections;
using System.Collections.Generic;
using Gaga.Util;
using Underc.Net;
using Underc.Net.Client;
using UnityEngine;
using TMPro;
using Underc.UI;
using Underc.Effect;

namespace Underc.Popup
{
    public partial class SocialPopupContent
    {

        private readonly int ANIM_REWARD = Animator.StringToHash("Reward");
        private readonly int ANIM_COMPLETE = Animator.StringToHash("Complete");

        private readonly float DOWNLOAD_LIMIT_SEC = 20f;

        [Header("Vote")]
        [SerializeField] private GameObject contentVote;
        [SerializeField] private Animator rewardAnim;
        [SerializeField] private TextMeshProUGUI rewardText;
        [SerializeField] private SocialPopupSeaLoader left;
        [SerializeField] private TextMeshProUGUI leftTitle;
        [SerializeField] private SocialPopupSeaLoader right;
        [SerializeField] private TextMeshProUGUI rightTitle;
        [SerializeField] private TextMeshProUGUI dailyCountText;
        [SerializeField] private float showUserDration = 1f;
        [SerializeField] private RectTransform coinStartPos;
        private int dailyCount;
        private int totalCount;
        private long rewardValue;
        private long receivedRewardValue;
        private VoteData[] nominatedDatas;
        private bool voted;
        private float voteTime;
        private VoteResponse voteResp;
        private List<string> seaUrlList;
        private bool seaDownloadFailed;

        private void InitVote()
        {
            if (seaUrlList == null) seaUrlList = new List<string>();
            else seaUrlList.Clear();

            left.OnVote += OnVote;
            right.OnVote += OnVote;
        }

        private IEnumerator ShowVote()
        {
            Debug.LogFormat("ShowVote");
            Popups.ShowLoading();
            var req = NetworkSystem.HTTPRequester.VoteOpen();
            yield return req.WaitForResponse();

            if (req.isSuccess == false)
            {
                Popups.HideLoading();
                Parent.ErrorPopup(req.data.error);
                yield break;
            }

            dailyCount = req.data.dailycnt;
            rewardValue = req.data.reward;
            nominatedDatas = req.data.data;
            totalCount = nominatedDatas.Length / 2;
            receivedRewardValue = 0L;

            if (dailyCount > totalCount)
            {
                dailyCount = totalCount;
            }

            if (IsVaildVoteData() == false)
            {
                Popups.HideLoading();
                Parent.ErrorPopup("invalid vote data. len: " + nominatedDatas.Length);
                yield break;
            }

            //앞으로 보여줘야할 모든 이미지들의 로드를 미리 시도한다.
            for (int i = GetLeftIndex(); i < nominatedDatas.Length; ++i)
            {
                VoteData data = nominatedDatas[i];
                string seaURL = data.sea_url;
                string picURL = data.pic_url;

                if (seaUrlList.Contains(seaURL) == false && string.IsNullOrEmpty(seaURL) == false)
                {
                    seaUrlList.Add(seaURL);
                }
            }

            Debug.LogFormat("vote > load url list\n{0}", seaUrlList.ToEachString(",\n"));
            DownloadSystem.Instance.LoadSprites(seaUrlList);

            yield return WaitNextVoteSprites();

            Popups.HideLoading();

            if (seaDownloadFailed == true)
            {
                Parent.ErrorPopup("seaDownload failed");
                yield break;
            }

            Parent.SetExistSea(req.data.exist_sea);
            rewardAnim.ResetTrigger(ANIM_REWARD);
            rewardAnim.ResetTrigger(ANIM_COMPLETE);
            rewardText.text = string.Format(System.Globalization.CultureInfo.InvariantCulture, "REWARD\n{0}", StringUtils.ToKMB(rewardValue));

            currentContent.SetActive(true);

            while (currentContent.activeInHierarchy && dailyCount < totalCount)
            {
                voted = false;
                voteResp = null;

                Debug.LogFormat("wait vote: {0} / {1}", dailyCount, totalCount);
                UpdateLeftAndRight();

                //유저가 바다를 터치할 때까지 기다림
                yield return new WaitUntil(() => voted);

                //각 바다의 유저를 보여주자
                left.ShowUser();
                right.ShowUser();

                //vote 통신을 기다림. 만약 응답이 빨리와도 각 바다의 유저를 보여줄 최소한의 시간만큼은 기다림
                yield return WaitVoteReseponse();
                yield return WaitNextVoteSprites();

                if (voteResp.isSuccess == false)
                {
                    break;
                }
            }

            //투표 응답이 잘못된 것이 있는 경우 팝업 닫음
            if (voteResp != null && voteResp.isSuccess == false)
            {
                Parent.ErrorPopup(voteResp.error);
                yield break;
            }

            if (seaDownloadFailed == true)
            {
                Parent.ErrorPopup("seaDownload failed");
                yield break;
            }

            //모든 투표가 완료됨
            UpdateLeftAndRight();

            left.Rewarded();
            right.Rewarded();

            //만약 아직 보상을 받지 않았다면 보상 연출
            if (receivedRewardValue > 0L)
            {
                rewardAnim.SetTrigger(ANIM_REWARD);

                var startPos = coinStartPos.position;
                yield return Parent.CollectCoin(rewardValue, startPos);
            }
            rewardAnim.SetTrigger(ANIM_COMPLETE);
            yield break;
        }

        private IEnumerator WaitNextVoteSprites()
        {
            seaDownloadFailed = false;

            string leftURL = GetLeftData().sea_url;
            string rightURL = GetRightData().sea_url;

            Debug.LogFormat("WaitNextVoteSprites dailyCount: {0}\n{1}\n{2}", dailyCount, leftURL, rightURL);

            var waitStartTime = Time.time;
            var waitLimitTime = waitStartTime + DOWNLOAD_LIMIT_SEC;

            while (DownloadSystem.Instance.GetCachedSprite(leftURL) == null ||
                   DownloadSystem.Instance.GetCachedSprite(rightURL) == null)
            {
                if (Time.time > waitLimitTime)
                {
                    seaDownloadFailed = true;
                    break;
                }

                yield return null;
            }

            Debug.LogFormat("NetVoteSprite Load Complte!");

            yield break;
        }

        private bool IsVaildVoteData()
        {
            return nominatedDatas != null && nominatedDatas.Length > 0 && nominatedDatas.Length % 2 == 0;
        }

        private int GetLeftIndex()
        {
            var leftIndex = dailyCount * 2;
            if (dailyCount == totalCount)
            {
                leftIndex -= 2;
            }

            return leftIndex;
        }

        private VoteData GetLeftData()
        {
            return nominatedDatas[GetLeftIndex()];
        }

        private VoteData GetRightData()
        {
            return nominatedDatas[GetLeftIndex() + 1];
        }

        private void UpdateLeftAndRight()
        {
            VoteData leftData = GetLeftData();
            if (left.GetID() != leftData.id)
            {
                left.ResetData();
                left.SetID(leftData.id);
                left.AddUser(leftData.nick, leftData.pic_url, leftData.pic_num);
                left.LoadSea(leftData.sea_url);
                leftTitle.text = leftData.pic_title;
            }

            VoteData rightData = GetRightData();
            if (right.GetID() != rightData.id)
            {
                right.ResetData();
                right.SetID(rightData.id);
                right.AddUser(rightData.nick, rightData.pic_url, rightData.pic_num);
                right.LoadSea(rightData.sea_url);
                rightTitle.text = rightData.pic_title;
            }

            UpdateVoteCount();
        }

        private void UpdateVoteCount()
        {
            dailyCountText.text = string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0} / {1}", dailyCount, totalCount);
        }

        private void OnVote(SocialPopupSeaLoader loader)
        {
            voted = true;
            voteTime = Time.time;

            dailyCount++;

            NetworkSystem.HTTPRequester.Vote(loader.GetID(), (resp) =>
            {
                voteResp = resp;
                receivedRewardValue = voteResp.reward;
            });
        }

        private IEnumerator WaitVoteReseponse()
        {
            while (voteResp == null || Time.time - voteTime < showUserDration)
            {
                yield return null;
            }

            yield break;
        }

        private void ClearVote()
        {
            for (int i = 0; i < seaUrlList.Count; ++i)
            {
                var url = seaUrlList[i];
                var id = DownloadSystem.Instance.GetDownloadID(url);
                DownloadSystem.Instance.Abort(id);
                DownloadSystem.Instance.RemoveCachedSprite(url);
            }

            left.ResetData();
            right.ResetData();

            seaUrlList.Clear();
        }
    }
}