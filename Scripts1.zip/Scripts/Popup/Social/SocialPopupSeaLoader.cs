using System;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using Underc.UI;
using Underc.Net;
using DG.Tweening;

namespace Underc.Popup
{
    public class SocialPopupSeaLoader : MonoBehaviour
    {
        private readonly int ANIM_USER = Animator.StringToHash("User");
        private readonly int ANIM_VOTED = Animator.StringToHash("Voted");
        private readonly int ANIM_COMPLETE = Animator.StringToHash("Complete");

        public event Action<SocialPopupSeaLoader> OnVote;

#pragma warning disable 0649
        [SerializeField] private Button button;
        [SerializeField] private Animator anim;
        [SerializeField] private ImageLoader loader;
        [SerializeField] private AspectRatioFitter seaRatioFitter;
        [SerializeField] private ImageLoader iconLoader;
        [SerializeField] private TextMeshProUGUI nickText;
        [SerializeField] private LoadingIndicator loading;
        [SerializeField] private float fadeInDuration = 0.3f;

#pragma warning restore 0649

        private string id;

        public bool Interactable
        {
            set
            {
                if (button != null)
                {
                    button.interactable = value;
                }
            }
        }

        private void Awake()
        {
            if (button != null)
            {
                button.onClick.AddListener(OnClick);
            }
        }

        private void OnClick()
        {
            if (loading != null && loading.IsActive == true)
            {
                return;
            }

            anim.SetBool(ANIM_VOTED, true);

            if (OnVote != null)
            {
                OnVote.Invoke(this);
            }
        }

        public void ResetData()
        {
            id = string.Empty;

            Interactable = true;

            nickText.text = string.Empty;

            iconLoader.sprite = null;
            iconLoader.color = new Color(1, 1, 1, 0);
            iconLoader.Image.DOKill();
            iconLoader.Clear();

            loader.sprite = null;
            loader.color = new Color(1, 1, 1, 0);
            loader.Image.DOKill();
            loader.Clear();

            anim.SetBool(ANIM_USER, false);
            anim.SetBool(ANIM_VOTED, false);
            anim.SetBool(ANIM_COMPLETE, false);

            HideLoading();
        }

        public void SetID(string id)
        {
            this.id = id;
        }

        public string GetID()
        {
            return id;
        }

        public void AddUser(string nick, string picURL, int picNum)
        {
            nickText.text = nick;

            if (string.IsNullOrEmpty(picURL) == false)
            {
                iconLoader.LoadFromRemote(picURL);
            }
            else
            {
                ProfileIconSystem.Instance.GetAsync(picNum, (sp) => iconLoader.SetSprite(sp));
            }
        }

        public void LoadSea(string seaURL)
        {
            loader.LoadFromRemote(seaURL,UpdateSea);
        }

        
        private void UpdateSea(ImageLoader loader)
        {
            if (loader.sprite != null)
            {
                loader.Image.color = new Color(1, 1, 1, 0);
                loader.Image.DOFade(1f, fadeInDuration);
            }
            else
            {
                loader.Image.color = new Color(1, 1, 1, 0);
            }
        }

        public void ShowUser()
        {
            Interactable = false;
            anim.SetBool(ANIM_USER, true);
        }

        public void Rewarded()
        {
            anim.SetBool(ANIM_COMPLETE, true);
        }

        private void ShowLoading()
        {
            if (loading != null) loading.Show();
        }

        private void HideLoading()
        {
            if (loading != null) loading.Hide();
        }
    }
}
