﻿using System.Collections;
using System.Collections.Generic;
using Gaga.Util;
using Underc.Net;
using Underc.Net.Client;
using UnityEngine;
using TMPro;
using Underc.UI;
using Underc.Effect;

namespace Underc.Popup
{
    public partial class SocialPopupContent
    {
#pragma warning disable 0649

        [Header("Rank")]
        [SerializeField] private GameObject contentRank;
#pragma warning restore 0649

        private IEnumerator ShowRank()
        {
            //랭크 기능은 추후 업데이트 때 구현
            currentContent.SetActive(true);
            yield break;
        }
    }
}