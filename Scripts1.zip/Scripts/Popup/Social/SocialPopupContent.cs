﻿using System.Collections;
using UnityEngine;

namespace Underc.Popup
{
    public partial class SocialPopupContent : MonoBehaviour
    {
        public enum Tab
        {
            None = 0,
            VOTE,
            MYSCORE,
            RANK
        }

        public SocialPopup Parent { get; set; }
        private GameObject currentContent;
        private Tab currentTap;
        private Coroutine coroutine;

        private void Awake()
        {
            contentVote.SetActive(false);
            contentScore.SetActive(false);
            contentRank.SetActive(false);

            InitVote();
            InitScore();
        }

        public void Open(Tab tab = Tab.VOTE)
        {
            gameObject.SetActive(true);
            SelectTap(tab);
        }

        public void Close()
        {
            gameObject.SetActive(false);
            dailyCount = 0;

            if (coroutine != null)
            {
                StopCoroutine(coroutine);
                coroutine = null;
            }
        }

        public void OpenVote()
        {
            SelectTap(Tab.VOTE);
        }
        public void OpenScore()
        {
            SelectTap(Tab.MYSCORE);
        }
        public void OpenRank()
        {
            SelectTap(Tab.RANK);
        }

        private void SelectTap(Tab tab)
        {
            if (tab == Tab.None || currentTap == tab)
            {
                return;
            }

            currentTap = tab;

            ResetContent();

            IEnumerator routine = null;
            switch (currentTap)
            {
                case Tab.VOTE:
                    currentContent = contentVote;
                    routine = ShowVote();
                    break;
                case Tab.MYSCORE:
                    currentContent = contentScore;
                    routine = ShowScore();
                    break;
                case Tab.RANK:
                    currentContent = contentRank;
                    routine = ShowRank();
                    break;
            }

            coroutine = StartCoroutine(routine);
        }

        private void ResetContent()
        {
            if (currentContent != null)
            {
                currentContent.SetActive(false);
                currentContent = null;
            }

            if (coroutine != null)
            {
                StopCoroutine(coroutine);
                coroutine = null;
            }
        }

        public void Clear()
        {
            currentTap = Tab.None;

            ResetContent();

            ClearVote();
        }
    }
}