﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using Underc.Net;
using DG.Tweening;
using Underc.UI;

namespace Underc.Popup
{
    public class SocalPopupScoreItem : MonoBehaviour
    {
        [SerializeField] private TextMeshProUGUI title;
        [SerializeField] private TextMeshProUGUI like;
        [SerializeField] private ImageLoader loader;

        private void Awake()
        {
            loader.sprite = null;
            loader.color = new Color(1, 1, 1, 0);
        }

        public void UpdateItem(SocialPopupContent.MyScoreData data)
        {
            title.text = data.title;
            like.text = data.score.ToString();

            loader.Clear();
            loader.LoadFromRemote(data.url, OnLoadComplete);
        }

        private void OnLoadComplete(ImageLoader loader)
        {
            if (loader.sprite != null)
            {
                loader.Image.color = new Color(1, 1, 1, 0);
                loader.Image.DOFade(1f, 0.2f);
            }
            else
            {
                loader.Image.color = new Color(1, 1, 1, 0);
            }
        }

        private void OnDestroy()
        {
            if (loader != null)
            {
                loader.Clear();
            }
        }
    }
}
