using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Gaga.Popup;
using Gaga.Util;
using Underc.UI;
using Underc.Effect;
using Underc.User;
using Underc.Lobby;

namespace Underc.Popup
{
    public class SocialPopup : PopupBackable
    {
        public Vector2 thumnailSize = new Vector2(485f, 320f);
#pragma warning disable 0649
        [SerializeField] private GameObject popupbg;
        [SerializeField] private Button closeButton;
        [SerializeField] private SocialPopupContent content;
        [SerializeField] private SocialPopupCapture capture;
#pragma warning restore 0649

        private TopUI topUI;
        private LobbyManager lobbyManager;
        private int[] exsitSeaIDs;

        protected override void Awake()
        {
            base.Awake();

            content.Parent = this;
            content.gameObject.SetActive(false);

            capture.Parent = this;
            capture.gameObject.SetActive(false);
        }

        public void Open()
        {
            exsitSeaIDs = null;

            InitTopUI();
            InitLobbyManager();
            ShowCloseButton();

            content.Open();
        }

        private void InitTopUI()
        {
            if (topUI == null)
            {
                topUI = TopUISystem.Instance.Get(transform);
                topUI.Use(TopUiItem.Coin,
                          TopUiItem.PearlAndTicket,
                          TopUiItem.Level);
                topUI.OrderAsDefault();
                topUI.Reset();
                topUI.Hide(false);
            }
        }

        private void InitLobbyManager()
        {
            if (lobbyManager == null)
            {
                lobbyManager = GameObject.FindObjectOfType<LobbyManager>();
            }
        }

        public void ErrorPopup(string errorMessage, bool close = true)
        {
            Debug.LogFormat("close by error: {0}", errorMessage);

            // useCloseButton

            Popups.Warning(message: errorMessage,
                           actionType: WarningPopup.ActionType.None,
                           titleType: WarningPopup.TitleType.Network,
                           useCloseButton: false,
                           onOK: () =>
                           {
                               if (close == true)
                               {
                                   base.Close();
                               }
                           });
        }

        public IEnumerator CollectCoin(long coin, Vector3 startPos)
        {
            topUI.Show(true);
            yield return new WaitForSeconds(0.3f);//ui 가 나오는 트윈 시간

            bool done = false;
            var endPos = topUI.GetCoinIconPosition();
            EffectSystem.Instance.Coin(
                15, 
                startPos, 
                endPos, 
                null,
                etype => done = true, 
                () => MyInfo.Coin += coin, 
                () => topUI.CoinIconAnimation()
            );

            yield return new WaitUntil(() => done);

            topUI.Hide(true);
        }

        public void ShowBG()
        {
            popupbg.SetActive(true);
        }

        public void HideBG()
        {
            popupbg.SetActive(false);
        }

        public void HideLobbyUI()
        {
            lobbyManager.TopUI.Hide(false);
            lobbyManager.OceanLobby.HideBottomUI(false);
            lobbyManager.OceanLobby.HideLeftUI(false);
            lobbyManager.OceanLobby.HideBannerUI(false);
        }

        public void ShowLobbyUI()
        {
            lobbyManager.TopUI.Show(true);
            lobbyManager.OceanLobby.ShowBottomUI(true);
            lobbyManager.OceanLobby.ShowLeftUI(true);
            lobbyManager.OceanLobby.ShowBannerUI(true);
        }

        public void HideCloseButton()
        {
            closeButton.gameObject.SetActive(false);
        }

        public void ShowCloseButton()
        {
            closeButton.gameObject.SetActive(true);
        }

        public void SetExistSea(int[] seaIDs)
        {
            exsitSeaIDs = seaIDs;
        }

        public bool IsUploadedSea(int seaID)
        {
            if (exsitSeaIDs == null || exsitSeaIDs.Length == 0) return false;
            else return exsitSeaIDs.Contains(seaID);
        }

        public override void Close()
        {
            if (content.isActiveAndEnabled == true)
            {
                content.Close();
                capture.CaptureMode();
                return;
            }
            else if (capture.isActiveAndEnabled == true && capture.IsEditMode)
            {
                capture.CaptureMode();
                return;
            }

            Clear();
            base.Close();
        }

        private void Clear()
        {
            content.Clear();
            capture.Clear();

            TopUISystem.Instance.Return(topUI);
            topUI = null;
            lobbyManager = null;
        }
    }
}
