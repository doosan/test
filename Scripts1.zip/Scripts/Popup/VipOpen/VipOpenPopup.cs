using Gaga.Popup;
using System;

namespace Underc.Popup
{
    public class VipOpenPopup : PopupBackable
    {
        private const string KEY_IS_VIP_OPENED = "k_is_vip_opened";

        public static bool IsOpened
        {
            get => UndercPrefs.GetRemoteValue(KEY_IS_VIP_OPENED, "0") == "1";
            set => UndercPrefs.SetRemoteValue(KEY_IS_VIP_OPENED, value ? "1" : "0");
        }

        private Action onGoToCheck;

        public void Open(Action onGoToCheck)
        {
            this.onGoToCheck = onGoToCheck;

            IsOpened = true;
        }

        public void GoToCheck()
        {
            onGoToCheck?.Invoke();
            Close();
        }
    }
}
