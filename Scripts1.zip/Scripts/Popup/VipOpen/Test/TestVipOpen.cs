using System.Collections;
using Underc.LoadingScreen;
using Underc.Popup;
using Underc.User;

public class TestVipOpen : TestSceneScaffold
{
    private IEnumerator Start()
    {
        yield return SetupAndLoad(new BaseLoadingItem[]
        {
            new LoginLoadingItem(),
            new SettingsLoadingItem(),
        });
    }

    public void OpenVipOpenPopup()
    {
        VipOpenPopup.IsOpened = false;
        if (VipOpenPopup.IsOpened == false)
        {
            StartCoroutine(Popups.VipOpenCoroutine());
        }
    }
}
