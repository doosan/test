 using Gaga.Popup;
 using Underc.Scene;
 using UnityEngine;
 using TMPro;
using System;

namespace Underc.Popup
{
    public sealed class ErrorPopup : PopupBehaviour
    {
        public enum ActionType
        {
            None,
            Lobby,
            Intro,
            Exit
        }

#pragma warning disable 0649
        [SerializeField] private TextMeshProUGUI messageText;
        [SerializeField] private TextMeshProUGUI buttonText;
#pragma warning restore 0649

        private ActionType actionType;
        private Action onClose;

        public void Initialize(string message, ActionType actionType, Action onClose = null)
        {
            this.actionType = actionType;
            this.onClose = onClose;
            messageText.text = message;

            if (actionType == ActionType.Lobby)
            {
                buttonText.text = "TO LOBBY";
            }
            else if (actionType == ActionType.Intro)
            {
                buttonText.text = "RELOAD";
            }
            else if (actionType == ActionType.Exit)
            {
                buttonText.text = "EXIT";
            }
            else
            {
                buttonText.text = "OK";
            }
        }

        public override void Close()
        {
            base.Close();

            onClose?.Invoke();

            ExecuteAction(actionType);
        }

        private void ExecuteAction(ActionType actionType)
        {
            if (actionType == ActionType.Lobby)
            {
                SceneSystem.LoadLobby();
            }
            else if (actionType == ActionType.Intro)
            {
                SceneSystem.LoadIntro();
            }
        }
    }
}