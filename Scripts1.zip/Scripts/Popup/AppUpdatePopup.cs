﻿using System;
using System.Collections;
using System.Collections.Generic;
using Gaga.Popup;
using UnityEngine;
using UnityEngine.UI;
using Underc.UI;
using TMPro;
using DG.Tweening;
using Underc.Net;

namespace Underc.Popup
{
    public class AppUpdatePopup : PopupBehaviour
    {
        private readonly int TRIGGER_OPEN = Animator.StringToHash("Open");

        [SerializeField] private Image imageLoader = null;
        [SerializeField] private Animator anim = null;
        [SerializeField] private GameObject laterButton = null;

        private Action onLater;
        private string imgURL;

        public void Open(bool force, string img, Action onLater = null)
        {
            imgURL = img;
            this.onLater = onLater;

            laterButton.SetActive(!force);

            StartCoroutine(OpenCoroutine());
        }

        private IEnumerator OpenCoroutine()
        {
            yield return LoadImage();

            anim.SetTrigger(TRIGGER_OPEN);
            yield break;
        }

        private IEnumerator LoadImage()
        {
            Popups.ShowLoading();

            imageLoader.enabled = false;

            bool downloadComplete = false;
            Sprite loadedSprite = null;

            DownloadSystem.Instance.GetSprite(imgURL, (sprite) =>
            {
                downloadComplete = true;
                loadedSprite = sprite;
            });

            yield return new WaitUntil(() => downloadComplete);

            if (loadedSprite != null)
            {
                imageLoader.sprite = loadedSprite;
                imageLoader.enabled = true;
                imageLoader.SetNativeSize();
            }
            else
            {
                imageLoader.sprite = null;
            }

            Popups.HideLoading();
            yield break;
        }

        public void Later()
        {
            Debug.LogFormat("later");
            onLater?.Invoke();

            Close();
        }

        public void UpdateNow()
        {
            Debug.LogFormat("UpdateNow");

            AppService.OpenStore();
        }
    }
}
