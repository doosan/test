using System.Collections;
using System.Collections.Generic;
using Gaga.Popup;
using UnityEngine;
using TMPro;
using Underc.User;
using Gaga.System;
using Gaga.Util;

namespace Underc.Popup
{
    public class BlockedUserPopup : PopupBackable
    {
        [SerializeField] private TextMeshProUGUI textVersion = null;
        [SerializeField] private TextMeshProUGUI textUserID = null;

        public void Initialize()
        {
            textVersion.text = string.Format(System.Globalization.CultureInfo.InvariantCulture, "VERSION: {0}", AppService.GetAppVersion());
            textUserID.text = string.Format(System.Globalization.CultureInfo.InvariantCulture, "USER ID: {0}", MyInfo.ID);
        }

        public void CopyUserID()
        {
            MyInfo.ID.CopyToClipboard();
        }

        public void SendEmailOpenURL()
        {
            AppService.SendEmailToSupport();
        }

        public override bool CanBack()
        {
            return base.CanBack();
        }

        public override void GoBack()
        {
            Popups.ExitApp();
        }

        private void Update()
        {
#if UNITY_EDITOR
            if (Input.GetKeyDown(KeyCode.LeftArrow) && Input.GetKey(KeyCode.LeftShift))
            {
                BackButtonSystem.Instance.Back();
            }
            else if (Input.GetKeyDown(KeyCode.UpArrow) && Input.GetKey(KeyCode.LeftShift))
            {
                if (BackButtonSystem.Instance.Count > 0)
                {
                    foreach (var item in BackButtonSystem.Instance.GetEnumerable())
                    {
                        Debug.LogFormat("BackableItem {0}", item.name);
                    }
                }

            }
#elif UNITY_ANDROID
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                BackButtonSystem.Instance.Back();
            }
#endif
        }
    }

}

