using Gaga.Popup;
using Underc.Lobby;
using UnityEngine;
using System;
using System.Collections.Generic;
using System.Text;
using Underc.User;
using Underc.Scene;
using TMPro;
using UnityEngine.SceneManagement;

namespace Underc.Popup
{
    public sealed class NeedMorePopup : PopupBackable
    {
        [Flags]
        public enum ResourceType
        {
            None        = 0,
            Coin        = 1 << 0,
            Pearl       = 1 << 1,
            Ticket      = 1 << 2
        }

        [Serializable]
        public class ViewInfo
        {
            public GameObject button;
            public string description;
        }

        [Serializable]
        public class IconInfo
        {
            public GameObject icon;
            public string name;
        }

        #pragma warning disable 0649
        [SerializeField] private TextMeshProUGUI titleText;
        [SerializeField] private TextMeshProUGUI descriptionText;
        [SerializeField] private string title;

        [Header("Icons")]
        [SerializeField] private IconInfo coinIcon;
        [SerializeField] private IconInfo pearlIcon;
        [SerializeField] private IconInfo ticketIcon;

        [Header("Buttons")]
        [SerializeField] private ViewInfo buyCoinsView;
        [SerializeField] private ViewInfo enlargeView;
        [SerializeField] private ViewInfo playSlotView;

        #pragma warning restore 0649

        private Dictionary<ResourceType, IconInfo> iconDic;
        private List<ViewInfo> viewList;

        private Action letParentClose;

        public void Initialize(ResourceType resourceType, Action letParentClose)
        {
            this.letParentClose = letParentClose;

            if (iconDic == null)
            {
                iconDic = new Dictionary<ResourceType, IconInfo>();
                iconDic.Add(ResourceType.Coin, coinIcon);
                iconDic.Add(ResourceType.Pearl, pearlIcon);
                iconDic.Add(ResourceType.Ticket, ticketIcon);
            }

            if (viewList == null)
            {
                viewList = new List<ViewInfo>();
                viewList.Add(buyCoinsView);
                viewList.Add(enlargeView);
                viewList.Add(playSlotView);
            }

            if (resourceType == ResourceType.None)
            {
                Close();
                return;
            }
           
            SetupTitle(resourceType);
            SetupIcons(resourceType);
            SetupView(resourceType);
        }

        private void SetupIcons(ResourceType resourceType)
        {
            foreach (var item in iconDic)
            {
                var iconType = item.Key;
                var info = item.Value;
                info.icon.SetActive((resourceType & iconType) != 0);
            }
        }

        private void SetupTitle(ResourceType resourceType)
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Length = 0;
            stringBuilder.Append(title);

            foreach (var item in iconDic)
            {
                var iconType = item.Key;
                var info = item.Value;

                if ((resourceType & iconType) != 0)
                {
                    stringBuilder.Append(" ");
                    stringBuilder.Append(info.name);
                    stringBuilder.Append(" &");
                }
            }

            var titleStr = stringBuilder.ToString();
            if (titleStr[titleStr.Length-1] == '&')
            {
                titleStr = titleStr.Substring(0, titleStr.Length-2);
            }

            titleText.text = titleStr;
        }

        private void SetupView(ResourceType resourceType)
        {
            ViewInfo target = null;

            if ((resourceType & ResourceType.Coin) != 0)
            {
                target = buyCoinsView;
            }
            else
            {
                target = playSlotView;
            }

            for (int i = 0; i < viewList.Count; i++)
            {
                var info = viewList[i];

                if (info == target)
                {
                    info.button.SetActive(true);
                    descriptionText.text = info.description;
                }
                else
                {
                    info.button.SetActive(false);
                }
            }
        }

        public void BuyCoins()
        {
            Popups.Shop()
                  .Async()
                  .Cache();

            Close();
        }

        public void PlaySlot()
        {
            var lobbyMainView = GameObject.FindObjectOfType<OceanLobby>();
            if (lobbyMainView != null)
            {
                lobbyMainView.OpenGame();
            }

            Close();
            letParentClose?.Invoke();
        }
    }
}