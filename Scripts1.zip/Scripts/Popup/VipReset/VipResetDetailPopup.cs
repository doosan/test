using Gaga;
using Gaga.Popup;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Popup
{
    public class VipResetDetailPopup : PopupBackable
    {
        [SerializeField] private Text yearText;

        [SerializeField] private VipPointGauge vipPointGauge;

        [TextArea]
        [SerializeField] private string contentValue0 = "{coe}% OF VIP POINTS\nRECEIVED FROM {begin_month}\nTO {end_month} {last_year}";

        [TextArea]
        [SerializeField] private string contentValue1 = "{coe}% OF VIP POINTS\nYOU EARN IN\n{begin_month} {last_year}";

        [TextArea]
        [SerializeField] private string contentValue2 = "{this_year} KICKOFF\nVIP POINTS";
        
        [SerializeField] private List<VipResetDetailItem> vipResetDetailItems;

        public static DateTimeInfo FakeNow;
        private static DateTime ReadNow()
        {
            return FakeNow != null ? FakeNow.dateTime : MyInfo.VipClass.Now;
        }

        private MyVipClass vipClass;

        private void Reset()
        {
            vipClass = MyInfo.VipClass;

            yearText.text = "";
            vipPointGauge.Reset();
            foreach (VipResetDetailItem item in vipResetDetailItems)
            {
                item.Reset();
            }
        }

        public void Open()
        {
            Reset();

            int thisYear = ReadNow().Year;
            int lastYear = thisYear - 1;

            //
            yearText.text = thisYear.ToString();

            //
            VipPointGaugeType gaugeType = vipClass.Type == VipClassType.black_diamond ?
                                          VipPointGaugeType.Single :
                                          VipPointGaugeType.Double;
            vipPointGauge.UpdateContent(gaugeType);

            //
            StringBuilder contentSb = new StringBuilder();
            DateTimeFormatInfo dateTimeFormat = CultureInfo.InvariantCulture.DateTimeFormat;

            VipResetInfo vipResetInfo0 = MyInfo.VipClass.GetVipResetInfo(0);
            if (vipResetInfo0 != null)
            { 
                VipResetDetailItem detailItem0 = vipResetDetailItems[0];
                string coeStr = ((int)(vipResetInfo0.coe * 100)).ToString();
                string lastYearStr = lastYear.ToString();
                detailItem0.UpdateContent(new string[] { coeStr, lastYearStr }, vipResetInfo0.point);
            }

            VipResetInfo vipResetInfo1 = MyInfo.VipClass.GetVipResetInfo(1);
            if (vipResetInfo1 != null)
            {
                VipResetDetailItem detailItem1 = vipResetDetailItems[1];
                string coeStr = ((int)(vipResetInfo1.coe * 100)).ToString();
                string lastYearStr = lastYear.ToString();
                contentSb.Length = 0;
                detailItem1.UpdateContent(new string[] { coeStr, lastYearStr }, vipResetInfo1.point);
            }

            if (vipResetInfo0 != null
                && vipResetInfo1 != null)
            {
                VipResetDetailItem detailItem2 = vipResetDetailItems[2];
                string thisYearStr = thisYear.ToString();
                detailItem2.UpdateContent(new string[] { thisYearStr } , (vipResetInfo0.point + vipResetInfo1.point));
            }
        }

        public void GoToCheck()
        {
            Close();
        }
    }
}
