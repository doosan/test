using Gaga;
using Gaga.Popup;
using Gaga.Util;
using System;
using System.Globalization;
using System.Text;
using TMPro;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Popup
{
    public class VipResetKickOffPopup : PopupBackable
    {
        [Header("Content")]
        [TextArea]
        [SerializeField] private string topContentValue = 
            "Here is a perfect opportunity for you to get ahead if\n"
            + "others on VIP Points at the beginning of {next_year}!";

        [TextArea]
        [SerializeField] private string middleContentValue0 = 
            "{coe}% of the total VIP Points received from {begin_month} {this_year} to {end_month} {this_year}";

        [SerializeField] private string middleContentValuePlus = "+";

        [TextArea]
        [SerializeField] private string middleContentValue1 = 
            "{coe}% of VIP Points you earn in {begin_month} {this_year} X Multiplier(based on your VIP Level)";

        [TextArea]
        [SerializeField] private string bottomContentValue = 
            "{this_year} VIP Points will reset on January 1st, {next_year}.\n"
            + "However your VIP Status is GUARANTEED to remain the same!\n"
            + "(WITH THE EXCEPTION OF BLACK DIAMOND, WHICH IS A SPECIAL, ANUUAL STATUS LEVEL.)";

        [Header("Text")]
        [SerializeField] private Text titleYearText;
        [SerializeField] private TextMeshProUGUI topContentText;
        [SerializeField] private TextMeshProUGUI middleContentText;
        [SerializeField] private TextMeshProUGUI bottomContentText;

        public static bool IsOpened
        {
            get
            {
                bool result = true;
                DateTime now = ReadNow();
                int month = now.Month;
                int day = now.Day;
                string key = StringMaker.New()
                                        .Append(month.ToString())
                                        .Append(day.ToString())
                                        .Build();
                if (month == 12
                    && day >= 1 
                    && day <= 5)
                {
                    string keys = UndercPrefs.GetRemoteValue(IsOpenedKey, "0");
                    //Debug.Log($"==== {key} in {keys}");
                    result = keys.Contains(key) == true;
                }
                return result;
            }
            set
            {
                DateTime now = ReadNow();
                int month = now.Month;
                int day = now.Day;
                string key = StringMaker.New()
                                        .Append(month.ToString())
                                        .Append(day.ToString())
                                        .Build();
                string keys = UndercPrefs.GetRemoteValue(IsOpenedKey, "0");
                if (value == true)
                {
                    if (keys.Contains(key) == false)
                    {
                        keys = key;
                    }
                }
                else
                {
                    keys = "0";
                }

                //Debug.Log($"==== {key} in {keys}");
                UndercPrefs.SetRemoteValue(IsOpenedKey, keys);
            }
        }

        private static string IsOpenedKey
        {
            get
            {
                var now = ReadNow();
                string result = StringMaker.New()
                                           .Append(KEY_IS_VIP_RESET_KICKOFF_OPENED)
                                           .Append("_")
                                           .Append(now.Year.ToString())
                                           .Build();
                return result;
            }
        }
        private const string KEY_IS_VIP_RESET_KICKOFF_OPENED = "k_vr_kickoff";

        public static DateTimeInfo FakeNow;
        private static DateTime ReadNow()
        {
            return FakeNow != null ? FakeNow.dateTime : MyInfo.VipClass.Now;
        }

        public void Open()
        {
            IsOpened = true;

            int thisYear = ReadNow().Year;
            int nextYear = thisYear + 1;

            //
            titleYearText.text = nextYear.ToString();

            //
            StringBuilder contentSb = new StringBuilder();
            contentSb.Length = 0;
            contentSb.Append(topContentValue);
            contentSb.Replace("{next_year}", nextYear.ToString());
            topContentText.text = contentSb.ToString();

            VipResetInfo vipResetInfo0 = MyInfo.VipClass.GetVipResetInfo(0);
            VipResetInfo vipResetInfo1 = MyInfo.VipClass.GetVipResetInfo(1);

            StringBuilder middleContentSb = new StringBuilder();
            DateTimeFormatInfo dateTimeFormat = CultureInfo.InvariantCulture.DateTimeFormat;
            if (vipResetInfo0 != null)
            {

                //
                contentSb.Length = 0;
                contentSb.Append(middleContentValue0);
                contentSb.Replace("{coe}", ((int)(vipResetInfo0.coe * 100)).ToString());
                contentSb.Replace("{begin_month}", dateTimeFormat.GetAbbreviatedMonthName(vipResetInfo0.beginMonth).ToUpperInvariant());
                contentSb.Replace("{end_month}", dateTimeFormat.GetAbbreviatedMonthName(vipResetInfo0.endMonth).ToUpperInvariant());
                contentSb.Replace("{this_year}", thisYear.ToString());

                //
                middleContentSb.Append(contentSb.ToString());
                middleContentSb.AppendLine();
                middleContentSb.Append(middleContentValuePlus);
                middleContentSb.AppendLine();
            }

            if (vipResetInfo1 != null)
            {
                contentSb.Length = 0;
                contentSb.Append(middleContentValue1);
                contentSb.Replace("{coe}", ((int)(vipResetInfo1.coe * 100)).ToString());
                contentSb.Replace("{begin_month}", dateTimeFormat.GetAbbreviatedMonthName(vipResetInfo1.beginMonth).ToUpperInvariant());
                contentSb.Replace("{end_month}", dateTimeFormat.GetAbbreviatedMonthName(vipResetInfo1.endMonth).ToUpperInvariant());
                contentSb.Replace("{this_year}", thisYear.ToString());
                middleContentSb.Append(contentSb.ToString());
            }
            middleContentText.text = middleContentSb.ToString();

            contentSb.Length = 0;
            contentSb.Append(bottomContentValue);
            contentSb.Replace("{this_year}", thisYear.ToString());
            contentSb.Replace("{next_year}", nextYear.ToString());
            bottomContentText.text = contentSb.ToString();
        }
    }
}
