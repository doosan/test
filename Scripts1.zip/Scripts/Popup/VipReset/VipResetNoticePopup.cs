using Gaga;
using Gaga.Popup;
using Gaga.Util;
using System;
using System.Collections.Generic;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Popup
{
    public class VipResetNoticePopup : PopupBackable
    {
        [SerializeField] private List<Text> yearTexts;

        public static bool IsOpened
        {
            get
            {
                bool result = UndercPrefs.GetRemoteValue(IsOpenedKey, "0") == "1";
                //Debug.Log($"==== GetIsOpened : {IsOpenedKey}, {result}");
                return result;
            }
            set
            {
                UndercPrefs.SetRemoteValue(IsOpenedKey, value ? "1" : "0");
                //Debug.Log($"==== SetIsOpened : {IsOpenedKey}, {value}");
            }
        }

        private static string IsOpenedKey
        {
            get
            {
                var now = ReadNow();
                string result = StringMaker.New()
                                           .Append(KEY_IS_VIP_RESET_NOTICE_OPENED)
                                           .Append("_")
                                           .Append(now.Year.ToString())
                                           .Build();
                return result;
            }
        }
        private const string KEY_IS_VIP_RESET_NOTICE_OPENED = "k_vr_notice";

        public static DateTimeInfo FakeNow;
        private static DateTime ReadNow()
        {
            return FakeNow != null ? FakeNow.dateTime : MyInfo.VipClass.Now;
        }

        private Action onGoToCheck;

        public void Open(Action onGoToCheck)
        {
            this.onGoToCheck = onGoToCheck;

            IsOpened = true;

            int thisYear = ReadNow().Year;
            foreach (Text yearText in yearTexts)
            {
                yearText.text = thisYear.ToString();
            }
        }

        public void GoToCheck()
        {
            onGoToCheck?.Invoke();
            Close();
        }
    }
}
