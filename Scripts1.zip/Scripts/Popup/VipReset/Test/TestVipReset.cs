using Gaga;
using Gaga.Popup;
using System;
using System.Collections;
using System.Collections.Generic;
using Underc;
using Underc.LoadingScreen;
using Underc.Net;
using Underc.Net.Client;
using Underc.Popup;
using Underc.User;
using Underc.Util;
using UnityEngine;
using UnityEngine.UI;

public class TestVipReset : TestSceneScaffold
{
    [SerializeField] private long xp;
    [SerializeField] private long nextXp;
    [SerializeField] private VipClassType vipClass;

    [Header("Reset")]
    [SerializeField] private bool useFakeNow;
    [SerializeField] private int year = 2022;
    [SerializeField] private int month = 11;
    [SerializeField] private int day = 30;
    [SerializeField] private List<VipResetData> vipResetDatas;
    [SerializeField] private Text yearText;
    [SerializeField] private Text monthText;
    [SerializeField] private Text dayText;

    private int initialYear;
    private int initialMonth;
    private int initialDay;

    private ProfileData cachedProfileData;

    private IEnumerator Start()
    {
        yield return SetupAndLoad(new BaseLoadingItem[]
        {
            new LoginLoadingItem(),
            new SettingsLoadingItem(),
            new HTTPLoadingItem<UserCoreResponse>(
                () => NetworkSystem.HTTPRequester.UserCoreWithAlarms(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<SeaListResponse>(
                () => NetworkSystem.HTTPRequester.SeaList(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<FishBookListResponse>(
                () => NetworkSystem.HTTPRequester.FishBookList(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<SwimmerBookListResponse>(
                () => NetworkSystem.HTTPRequester.SwimmerBookList(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<VipResetResponse>(
                () => NetworkSystem.HTTPRequester.VipReset(), 
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<ProfileResponse>(
                () => NetworkSystem.HTTPRequester.Profile(),
                resp =>
                {
                    NetworkSystem.HTTPHandler.Do(resp);
                    cachedProfileData = resp.data;
                }
            ),
        });

        Init();

        yield return JustLoad(new BaseLoadingItem[]
        {
            new HTTPLoadingItem<ProfileResponse>(
                () => FakeHttpRequester.Instance.Profile(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new ProfileIconLoadingItem(),
            new ABLoadingItem(AssetBundleName.EFFECT),
            new TopUILoadingItem(),
            new RewardBonusUILoadingItem(),
            new ProfileFirstPicLoadingItem()
        });

        Init2();
    }

    private void Init()
    {
        var fakeVipDataLoader = FakeVipDataLoader.Instance;
        fakeVipDataLoader.SetupProfileResponse(
            cachedProfileData,
            xp, 
            nextXp, 
            vipClass, 
            vipResetDatas.ToArray()
        );

        var vipData = new VipData();
        vipData.vip_class = (int)vipClass;
        vipData.xp = xp;
        vipData.next_xp = nextXp;

        var response = new VipResetResponse();
        response.vip = vipData;
        response.vip_reset = vipResetDatas.ToArray();
        FakeHttpRequester.Instance.LoadedVipReset = response;
    }

    private void Init2()
    {
        initialYear = year;
        initialMonth = month;
        initialDay = day;

        ResetIsOpened();
        UpdateDateTime();

        MyInfo.VipClass.UpdateResetTimeStamp(GlobalTime.Instance.GetTimeStamp() + 3);
        VipResetNoticeSystem.Instance.Initialize("", AppConfig.RESOLUTION_WIDTH, AppConfig.RESOLUTION_HEIGHT, Gaga.System.ScreenMatchMode.Expand, 100, 120);
        VipResetNoticeSystem.Instance.StartWatch();
        VipResetNoticeSystem.Instance.RunAsFake = true;
    }

    private void UpdateDateTime()
    {
        if (useFakeNow)
        {
            var now = new DateTime(year, month, day);
            VipResetKickOffPopup.FakeNow = new DateTimeInfo(now);
            VipBenefitPopup.FakeNow = new DateTimeInfo(now);
            VipResetNoticePopup.FakeNow = new DateTimeInfo(now);
            VipResetDetailPopup.FakeNow = new DateTimeInfo(now);
        }

        yearText.text = year.ToString();
        monthText.text = month.ToString();
        dayText.text = day.ToString();
    }

    public void Day()
    {
        day += 1;
        if (day > 30)
        {
            month += 1;
            day = 1;
        }

        UpdateDateTime();
    }

    public void Year()
    {
        year += 1;

        UpdateDateTime();
    }

    public void OpenVipResetKickOffPopup()
    {
        if (VipResetKickOffPopup.IsOpened == false)
        {
            Popups.VipResetKickOff();
        }
    }

    public void OpenVipBenefitPopup()
    {
        PopupObject<VipBenefitPopup> popupObject = null;
        popupObject = Popups.VipBenefit(onOpen: () => popupObject.GetPopup().RunAsFake = true)
                            .Async();
    }

    public void OpenVipResetNoticePopup()
    {
        if (VipResetNoticePopup.IsOpened == false)
        {
            StartCoroutine(Popups.VipResetNoticeCoroutine());
        }
    }

    public void OpenVipResetDetailPopup()
    {
        Popups.VipResetDetail()
              .Async();
    }

    public void OpenShopPopup()
    {
        Popups.Shop()
              .Async();
    }

    public void OpenGameProfilePopup()
    {
        PopupObject<GameProfilePopup> popupObject = null;
        popupObject = Popups.GameProfile(onOpen: () => popupObject.GetPopup().RunAsFake = true)
                            .Async();
    }

    public void Reset()
    {
        year = initialYear;
        month = initialMonth;
        day = initialDay;

        ResetIsOpened();
        UpdateDateTime();
    }
    
    private void ResetIsOpened()
    {
        VipResetKickOffPopup.IsOpened = false;
        VipResetNoticePopup.IsOpened = false;
    }
}
