using TMPro;
using UnityEngine;

namespace Underc
{
    public class VipResetTimeViewer : MonoBehaviour
    {
        [SerializeField] private TextMeshProUGUI timeText;

        public void UpdateTimeText(string value)
        {
            timeText.text = value;
        }
    }
}