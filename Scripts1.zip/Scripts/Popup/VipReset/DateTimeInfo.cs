using System;

namespace Underc.Popup
{
    public class DateTimeInfo
    {
        public DateTime dateTime;

        public DateTimeInfo(DateTime dateTime)
        {
            this.dateTime = dateTime;
        }
    }
}