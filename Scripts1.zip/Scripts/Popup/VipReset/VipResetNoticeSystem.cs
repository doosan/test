using Gaga;
using Gaga.Popup;
using Gaga.System;
using Gaga.Util;
using SlotGame.Machine;
using System;
using System.Collections;
using Underc.Net;
using Underc.Net.Client;
using Underc.Popup;
using Underc.Scene;
using Underc.Tutorial;
using Underc.User;
using UnityEngine;

namespace Underc
{
    public class VipResetNoticeSystem : CanvasSingleton<VipResetNoticeSystem>
    {
        public bool RunAsFake
        {
            set;
            private get;
        }
        private VipResetTimeViewer timeViewer;
        private Coroutine checkCoroutine;

        public override void Initialize(string popupLayerName,
                                        int resolutionWidth,
                                        int resolutionHeight,
                                        ScreenMatchMode match = ScreenMatchMode.Expand,
                                        int pixelsPerUnit = 100,
                                        int depth = 0)
        {
            base.Initialize(popupLayerName,
                            resolutionWidth,
                            resolutionHeight,
                            match,
                            pixelsPerUnit,
                            depth);

            UnityEngine.SceneManagement.SceneManager.sceneLoaded += OnSceneLoaded;
            UnityEngine.SceneManagement.SceneManager.sceneUnloaded += OnSceneUnloaded;
        }

        public void ShowVipResetTime()
        {
            timeViewer = Instantiate(Resources.Load("VipResetTimeViewer") as GameObject).GetComponent<VipResetTimeViewer>();
            timeViewer.transform.SetParent(transform.Find("Root"), false);
        }

        private void OnSceneLoaded(UnityEngine.SceneManagement.Scene scene, UnityEngine.SceneManagement.LoadSceneMode mode)
        {
            if (scene.name == SceneSystem.LobbyScene || scene.name == SceneSystem.GameScene || scene.name == SceneSystem.GameScenePortrait)
            {
                StartWatch();
            }
        }

        private void OnSceneUnloaded(UnityEngine.SceneManagement.Scene scene)
        {
            if (scene.name == SceneSystem.LobbyScene || scene.name == SceneSystem.GameScene || scene.name == SceneSystem.GameScenePortrait)
            {
                StopWatch();
            }
        }

        private IEnumerator WatchCoroutine()
        {
            yield break;
        }

        public void StartWatch()
        {
            GlobalTime.Instance.onUpdate += OnServerTimeStampUpdate;
        }

        private void StopWatch()
        {
            GlobalTime.Instance.onUpdate -= OnServerTimeStampUpdate;
        }

        private void OnServerTimeStampUpdate(long timeStamp)
        {
            long remainingTime = GlobalTime.Instance.SecondDiff(MyInfo.VipClass.ResetTimeStamp);

            if (timeViewer != null)
            {
                bool isOpened = VipResetNoticePopup.IsOpened;
                string valueColor = isOpened ? "red" : "green";
                string timeText = StringMaker.New()
                                             .Append("IsOpened : ")
                                             .Append("<color=")
                                             .Append(valueColor)
                                             .Append(">")
                                             .Append(isOpened.ToString())
                                             .Append("</color>")
                                             .AppendLine()
                                             .Append("Now: ")
                                             .Append(MyInfo.VipClass.Now.ToString())
                                             .AppendLine()
                                             .Append("RemainingTime: ")
                                             .Append(remainingTime.ToSummaryDHMS())
                                             .Build();
                timeViewer.UpdateTimeText(timeText);
            }

            //Debug.Log($"==== remainingTime : {tryCount}, {remainingTime}");
            if (VipResetNoticePopup.IsOpened == false 
                && remainingTime <= 0
                && checkCoroutine == null)
            {
                checkCoroutine = StartCoroutine(CheckVipResetNotice());
            }
        }

        private IEnumerator CheckVipResetNotice()
        {
            IRequest<VipResetResponse> req;
            if (RunAsFake == false)
            {
                req = NetworkSystem.HTTPRequester.VipReset();
            }
            else
            {
                req = FakeHttpRequester.Instance.VipReset();
            }

            yield return req.WaitForResponse();
            if (req.isSuccess)
            {
                NetworkSystem.HTTPHandler.Do(req.data);
                if (MyInfo.VipClass.ConsumeIsReseted())
                {
                    yield return ShowVipResetNotice();
                }
            }

            checkCoroutine = null;
        }

        public IEnumerator ShowVipResetNotice()
        {
            while (PopupSystem.Instance.Count > 0
                   || TutorialSystem.Instance.IsInPlay == true)
            {
                yield return null;
            }

            var slotMachine = FindObjectOfType<SlotMachine>();
            slotMachine?.Pause();

            if (VipResetNoticePopup.IsOpened == false)
            {
                yield return Popups.VipResetNoticeCoroutine();
            }

            slotMachine?.Resume();
        }
    }
}