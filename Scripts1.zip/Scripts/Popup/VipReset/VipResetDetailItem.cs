using Gaga.Util;
using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Popup
{
    [Serializable]
    public class VipResetDetailItem : MonoBehaviour
    {
        [SerializeField] private List<Text> contentTexts;
        [SerializeField] private TextMeshProUGUI valueText;

        public void Reset()
        {
            foreach (Text contentText in contentTexts)
            {
                contentText.text = "";
            }
            valueText.text = "";
        }

        public void UpdateContent(string[] contents, long value)
        {
            for (int i = 0; i < contents.Length; i++)
            {
                string content = contents[i];
                if (i < contentTexts.Count)
                {
                    Text contentText = contentTexts[i];
                    contentText.text = content;
                }
            }
            valueText.text = StringUtils.ToComma(value);
        }
    }
}