using Gaga.Popup;
using Gaga.Sound;
using Gaga.System;
using System.Collections;
using System.Collections.Generic;
using Underc.Net;
using Underc.UI;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Popup
{
    public enum CouponPopupState
    {
        Reset,
        Setup,
        LoadImage,
        Redeem,
        Release,
        None,
    }

    public class CouponPopup : PopupBackable
    {
        [SerializeField] private ImageLoader imageLoader;
        [SerializeField] private List<CouponPreset> couponPresets;
        [SerializeField] private Button redeemButton;
        [SerializeField] private Animator animator;
        [SerializeField] private SoundPlayer openSFX;

        private MyShopCoinCoupon ShopCoinCoupon
        {
            get
            {
                if (shopCoinCoupon == null)
                {
                    shopCoinCoupon = MyInfo.Shop.CoinCoupon;
                }
                return shopCoinCoupon;
            }
        }
        private MyShopCoinCoupon shopCoinCoupon;

        private bool initOnce;
        private StateQueue<CouponPopupState> stateQueue;
        
        private CouponInfo info;

        private void Init()
        {
            if (initOnce == false)
            {
                initOnce = true;

                stateQueue = new StateQueue<CouponPopupState>(host: this);
            }
        }

        public void Open(CouponInfo info)
        {
            this.info = info;

            Init();

            stateQueue.Reset();
            stateQueue.Add(CouponPopupState.Reset);
            stateQueue.Add(CouponPopupState.Setup);
            stateQueue.Add(CouponPopupState.LoadImage);
        }

        public void Redeem()
        {
            stateQueue.Add(CouponPopupState.Redeem);
            stateQueue.Add(CouponPopupState.Release);
        }

        public override void Close()
        {
            stateQueue.Add(CouponPopupState.Release);
        }

        public override bool CanBack()
        {
            return Popups.IsLoading() == false;
        }

        private void OpenErrorPopup(string message)
        {
            stateQueue.Reset();

            Popups.Error(message)
                  .Async()
                  .OnClose(Close);
        }

        private IEnumerator RedeemCoroutine()
        {
            redeemButton.interactable = false;

            Popups.ShowLoading();
            var req = NetworkSystem.HTTPRequester.CouponClaim(info.id);
            yield return req.WaitForResponse();
            Popups.HideLoading();

            if (req.isSuccess == true)
            {

            }
            else
            {
                OpenErrorPopup(req.data.error);
            }
        }

        private IEnumerator ReleaseCoroutine()
        {
            base.Close();
            yield break;
        }

        private IEnumerator ResetCoroutine()
        {
            redeemButton.interactable = true;

            imageLoader.sprite = null;
            imageLoader.color = new Color(1, 1, 1, 0);

            for (int presetIndex = 0; presetIndex < couponPresets.Count; presetIndex++)
            {
                CouponPreset preset = couponPresets[presetIndex];
                preset.gameObject.SetActive(false);
            }
            yield break;
        }

        private IEnumerator SetupCoroutine()
        {
            ShopCoinCoupon.PrepareMerge();
            for (int infoIndex = 0; infoIndex < info.itemInfos.Count; infoIndex++)
            {
                CouponItemInfo couponItemInfo = info.itemInfos[infoIndex];

                int couponPresetIndex = ShopCoinCoupon.GetMergeIndex(target: couponItemInfo.target, 
                                                                     bonusRate: couponItemInfo.bonusRate);
                if (couponPresetIndex < couponPresets.Count)
                {
                    ShopCoinCoupon.Merge(couponPresetIndex, couponItemInfo);
                    CouponPreset preset = couponPresets[couponPresetIndex];

                    preset.gameObject.SetActive(true);
                    preset.Setup(index: couponPresetIndex,
                                 target: couponItemInfo.target,
                                 targetValueCurrency: couponItemInfo.targetValueCurrency,
                                 bonus: couponItemInfo.bonusRate, 
                                 count: couponItemInfo.count,
                                 onClick: null);
                }
                else
                {
                    Debug.LogWarning("==== 지정한 프리셋 인덱스가 준비된 프리셋 개수보다 많습니다 : "
                                     + infoIndex + ","
                                     + couponPresetIndex + ", "
                                     + couponPresets.Count);
                }
            }

            yield break;
        }

        private IEnumerator LoadImageCoroutine()
        {
            Popups.ShowLoading();
            imageLoader.LoadFromRemote(info.imgUrl);
            yield return new WaitWhile(() => imageLoader.IsLoading);
            Popups.HideLoading();

            imageLoader.Image.color = (imageLoader.sprite != null) ?
                                      new Color(1, 1, 1, 1) :
                                      new Color(1, 1, 1, 0);

            animator.SetTrigger("Open");
            if (openSFX != null)
            {
                openSFX.Play();
            }
            yield break;
        }
    }
}