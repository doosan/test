using Gaga.Util;
using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Popup
{
    public enum CouponPresetState
    {
        On, Off, Empty
    }

    public class CouponPreset : MonoBehaviour
    {
        [SerializeField] private Animator animator;
        [SerializeField] private Button button;

        [SerializeField] private TextMeshProUGUI targetAllText;
        [SerializeField] private TextMeshProUGUI targetAboveText;
        [SerializeField] private Text bonusText;
        [SerializeField] private GameObject countContainer;
        [SerializeField] private TextMeshProUGUI countText;
        [SerializeField] private TextMeshProUGUI timeText;

        public CouponPresetState State
        {
            get; 
            private set;
        }

        public int index
        {
            get;
            private set;
        }
        private Action<int/* index */> onClick;

        private string TARGET_MESSAGE_ALL = "FOR ANY PURCHASE";
        private string TARGET_MESSAGE_ABOVE = "FOR {0} OR ABOVE";

        public void SetState(CouponPresetState state)
        {
            State = state;

            animator.ResetAllTriggers();
            animator.SetTrigger(state.ToString());

            countContainer.SetActive(state != CouponPresetState.Empty);
        }

        public void UpdateTime(long remainingSec)
        {
            if (remainingSec > 0)
            {
                timeText.text = remainingSec.ToSummaryDHMS();
            }
            else
            {
                timeText.text = "TIME'S UP";
            }
        }

        public void Setup(int index, 
                          string target, 
                          string targetValueCurrency, 
                          int bonus, 
                          int count, 
                          Action<int> onClick)
        {
            this.index = index;
            this.onClick = onClick;

            if (button != null)
            {
                button.onClick.RemoveListener(OnClick);
                button.onClick.AddListener(OnClick);
            }

            targetAllText.text = "";
            targetAboveText.text = "";

            if (target == "all")
            {
                targetAllText.text = TARGET_MESSAGE_ALL;
                targetAllText.gameObject.SetActive(true);
            }
            else if (target.StartsWith("above") == true)
            {
                targetAboveText.text = string.Format(System.Globalization.CultureInfo.InvariantCulture, TARGET_MESSAGE_ABOVE, targetValueCurrency);
                targetAboveText.gameObject.SetActive(true);
            }

            bonusText.text = StringMaker.New()
                                        .Append(bonus.ToString())
                                        .Append("%")
                                        .Build();

            countContainer.SetActive(count > 1);
            countText.text = StringMaker.New()
                                        .Append("x")
                                        .Append(count.ToString())
                                        .Build();
        }

        private void OnClick()
        {
            onClick?.Invoke(index);
        }
    }
}