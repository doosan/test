using System;
using System.Collections;
using Gaga.Popup;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Popup
{
    public class InstantMessagePopup : PopupBackable
    {
        #pragma warning disable 0649
        [SerializeField] private float duration = 4f;
        [SerializeField] private TextMeshProUGUI messageText;
        [SerializeField] protected Button okButton;
        #pragma warning restore 0649

        private Action onOK;
        private bool callOkLater;
        private PopupAnimator popupAnimator;

        public virtual void Open(string message = "", Action onOK = null)
        {
            this.onOK = onOK;
            callOkLater = false;

            popupAnimator = GetComponent<PopupAnimator>();
            
            if (okButton != null)
            {
                okButton.onClick.AddListener(OnOkButtonClick);
            }

            if (messageText != null)
            {
                messageText.text = message;
            }

            if (duration > 0)
            {
                StartCoroutine(WaitToCloseCoroutine());
            }
        }

        private void OnOkButtonClick()
        {
            // Popup Animator가 종료되는 것을 기다렸다가 OK Callback을 호출해 줌.
            if (popupAnimator != null)
            {
                callOkLater = true;
            }
            else
            {
                DispatchOk();
            }

            Close();     
        }

        private void OnAnimatorClose()
        {
            if (callOkLater == true)
            {
                DispatchOk();
            }
        }

        private void DispatchOk()
        {
            if (onOK != null)
            {
                onOK.Invoke();
            }
        }

        public override void Close()
        {
            if (okButton != null)
            {
                okButton.onClick.RemoveListener(OnOkButtonClick);
            }
            StopAllCoroutines();
            
            base.Close();
        }

        private IEnumerator WaitToCloseCoroutine()
        {
            yield return new WaitForSeconds(duration);

            Close();
        }

        public override void GoBack()
        {
            if (okButton != null)
            {
                OnOkButtonClick();
            }
        }
    }
}
