using Gaga.Sound;
using Gaga.System;
using Gaga.Util;
using System;
using System.Collections;
using System.Collections.Generic;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Popup
{
    public enum ShopCoinMultipleType
    {
        None,
        SaleTag,
        CashRed,
        CashPurple
    }

    public struct ShopCoinMultipleInfo
    {
        public ShopCoinMultipleType type;
        public double value;
        public string name;

        public ShopCoinMultipleInfo(ShopCoinMultipleType type, double value, string name)
        {
            this.type = type;
            this.value = value;
            this.name = name;
        }
    }

    public struct ShopCoinVipInfo
    {
        public VipClassType type;
        public double bonusRate;

        public ShopCoinVipInfo(VipClassType type, double bonusRate)
        {
            this.type = type;
            this.bonusRate = bonusRate;
        }
    }

    public class ShopPopupCoin : BaseShopPopupLayer
    {
#pragma warning disable 0649
        [SerializeField] private ShopPopupCoinItem coinItemRef;
        [SerializeField] private Transform itemPoolRoot;
        [SerializeField] private RectTransform contentRoot;
        [SerializeField] private ScrollRect scrollRect;
        [SerializeField] private SoundPlayer multipleSound;
#pragma warning restore 0649

        private GameObjectPool<ShopPopupCoinItem> coinItemPool;
        private List<ShopPopupCoinItem> coinItems;

        public ShopCoinItemInfo ClickedCoinItemInfo
        {
            get; 
            private set;
        }
        public int ClickedCouponIndex
        {
            get;
            private set;
        }
        public RectTransform ClickedVipClassTransform
        {
            get;
            private set;
        }

        public Action OnCoinItemClick
        {
            private get;
            set;
        }

        private ShopCoinMultipleInfo multipleInfo;
        public ShopCoinVipInfo VipInfo
        {
            get => vipInfo;
        }
        private ShopCoinVipInfo vipInfo;

        private MyShopCoin myShopCoin;
        private MyShopCoinSale myShopCoinSale;
        private MyShopCoinCoupon myShopCoinCoupon;
        private MyVipClass myVipClass;

        private bool scrollToTopOnce;
        private float couponTargetValue;

        public override void Init()
        {
            itemPoolRoot.gameObject.SetActive(false);
            coinItemPool = coinItemRef.CreatePool
            (
                rootName: "ItemPool",
                parent: itemPoolRoot,
                size: 6
            );
            coinItems = new List<ShopPopupCoinItem>();

            vipInfo = new ShopCoinVipInfo(VipClassType.none, 1d);
            multipleInfo = new ShopCoinMultipleInfo(ShopCoinMultipleType.None, 1d, "");

            myShopCoin = MyInfo.Shop.Coin;
            myShopCoinSale = MyInfo.Shop.CoinSale;
            myShopCoinCoupon = MyInfo.Shop.CoinCoupon;
            myVipClass = MyInfo.VipClass;
        }

        public override void Reset()
        {
            // VIP 레벨업 직후에만 해줘야 함
            RemoveListeners();

            couponTargetValue = 0f;
            _UpdateVipInfo(MyInfo.VipClass.Type, 1d);
            _UpdateMultipleInfo(ShopCoinMultipleType.None, 1d, "");
            ResetCoinItems();
            UpdateCoinItems(false, "RESET");
        }

        private void OnDisable()
        {
            RemoveListeners();
        }

        private void RemoveListeners()
        {
            myShopCoinSale.onTimesUp.RemoveListener(OnUpdateCoinItems);
            myShopCoinCoupon.onInfoIndexChange.RemoveListener(OnUpdateCoinItems);
        }

        private void AddListeners()
        {
            myShopCoinSale.onTimesUp.AddListener(OnUpdateCoinItems);
            myShopCoinCoupon.onInfoIndexChange.AddListener(OnUpdateCoinItems);
        }

        private void OnUpdateCoinItems()
        {
            UpdateMultipleInfo();
            UpdateCoinItems(true, "COUPON UPDATED");
        }

        public override IEnumerator UpdateContent()
        {
            RemoveListeners();
            AddListeners();
            yield break;
        }

        private IEnumerator ScrollToTopCoroutine()
        {
            yield return new WaitForEndOfFrame();
            scrollRect.verticalNormalizedPosition = 1f;
        }

        public void UpdateVipInfo()
        {
            if (myVipClass.Type != VipClassType.none)
            {
                VipBenefitTableItemInfo tableItemInfo = myVipClass.GetCurrent_VipBenefitTableItemInfo(VipBenefitTableItem.CoinPackages);
                double multipleValue = tableItemInfo.bonusRate;
                _UpdateVipInfo(myVipClass.Type, multipleValue);
            }
            else
            {
                _UpdateVipInfo(VipClassType.none, 1d);
            }
        }

        public void UpdateMultipleInfo()
        {
            couponTargetValue = 0f;

            // 세일 기간이면
            if (myShopCoinSale.RemainingSec > 0)
            {
                ShopCoinMultipleType multipleType = ShopCoinMultipleType.SaleTag;
                double multipleValue = myShopCoinSale.Multiple;
                string multipleName = StringMaker.New()
                                                 .Append(multipleValue.ToString())
                                                 .Append("X")
                                                 .Build();
                _UpdateMultipleInfo(multipleType, multipleValue, multipleName);
            }
            // 쿠폰이 있으면
            else if (myShopCoinCoupon.CurrInfoIndex != -1
                     && myShopCoinCoupon.ContainsInfos(myShopCoinCoupon.CurrInfoIndex) == true)
            {
                List<CouponItemInfo> infos = myShopCoinCoupon.GetInfos(myShopCoinCoupon.CurrInfoIndex);
                CouponItemInfo firstInfo = infos[0];
                couponTargetValue = firstInfo.targetValue;

                ShopCoinMultipleType multipleType = firstInfo.index == 0 ?
                                                    ShopCoinMultipleType.CashRed :
                                                    ShopCoinMultipleType.CashPurple;
                int bonusRate = firstInfo.bonusRate;
                double multipleValue = (bonusRate + 100) / 100d;
                string multipleName = StringMaker.New()
                                                 .Append(bonusRate.ToString())
                                                 .Append("%")
                                                 .Build();
                _UpdateMultipleInfo(multipleType, multipleValue, multipleName);
            }
            else
            {
                _UpdateMultipleInfo(ShopCoinMultipleType.None, 1d, "");
            }
        }

        private void _UpdateVipInfo(VipClassType type, double bonusRate)
        {
            vipInfo.type = type;
            vipInfo.bonusRate = bonusRate;
        }

        private void _UpdateMultipleInfo(ShopCoinMultipleType type, double value, string name)
        {
            multipleInfo.type = type;
            multipleInfo.value = value;
            multipleInfo.name = name;
        }

        private void ResetCoinItems()
        {
            foreach (ShopPopupCoinItem coinItem in coinItems)
            {
                coinItemPool.Return(coinItem);
            }
            coinItems.Clear();

            for (int itemIndex = 0; itemIndex < myShopCoin.ItemCount; itemIndex++)
            {
                ShopPopupCoinItem coinItem = coinItemPool.Get();
                coinItems.Add(coinItem);
            }
        }

        public void UpdateCoinItems(bool useAnimation, string purpose = "")
        {
            bool hasMultipleSound = false;
            for (int itemIndex = 0; itemIndex < coinItems.Count; itemIndex++)
            {
                if (hasMultipleSound == false
                    && multipleInfo.value > 1)
                {
                    hasMultipleSound = true;
                }

                ShopCoinItemInfo itemInfo = myShopCoin.GetItemInfo(itemIndex);
                if (couponTargetValue > 0)
                {
                    float priceValue = itemInfo.price;
                    if (priceValue < couponTargetValue)
                    {
                        // 쿠폰 적용 대상이 아니면 멀티플을 원래 값으로 되돌림
                        _UpdateMultipleInfo(ShopCoinMultipleType.None, 1f, "");
                    }
                }

                ShopPopupCoinItem coinItem = coinItems[itemIndex];
                coinItem.transform.SetParent(contentRoot, false);
                coinItem.UpdateContent(itemIndex: itemIndex,
                                       itemInfo: itemInfo,
                                       vipInfo: vipInfo,
                                       multipleInfo: multipleInfo,
                                       onClick: _OnCoinItemClick,
                                       useAnimation: useAnimation);

                //if (itemIndex == 0)
                //{
                //    Debug.Log("==== UpdateContent : " + purpose + ", " + itemInfo.coinValue + ", " + VipInfo.value + ", " + MultipleInfo.value + ", " + useAnimation);
                //}
            }

            if (hasMultipleSound)
            {
                multipleSound.Play();
            }

            if (scrollToTopOnce == false)
            {
                scrollToTopOnce = true;
                StartCoroutine(ScrollToTopCoroutine());
            }
        }

        private void _OnCoinItemClick(ShopCoinItemInfo itemInfo, ShopCoinMultipleInfo multipleInfo, RectTransform itemTransform)
        {
            ClickedCoinItemInfo = itemInfo;

            ClickedCouponIndex = (multipleInfo.type == ShopCoinMultipleType.CashRed 
                                 || multipleInfo.type == ShopCoinMultipleType.CashPurple) ? 
                                 myShopCoinCoupon.CurrInfoIndex : 
                                 -1;

            ClickedVipClassTransform = itemTransform;

            OnCoinItemClick?.Invoke();
        }
    }
}