using Gaga;
using Gaga.UI;
using Gaga.Util;
using System;
using TMPro;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Popup
{
    public enum LayoutMode
    {
        Normal,
        MiddleTagOnTop
    }

    public class ShopPopupCoinItem : MonoBehaviour
    {
        [Serializable]
        public sealed class LayoutTransform
        {
            public float height;
            public float offsetY;
        }

#pragma warning disable 0649
        [SerializeField] private RectTransform containerTransform;
        [SerializeField] private LayoutElement layoutElement;

        [Space]
        [SerializeField] private GameObjectVisibleToggle bgVisibleToggle;
        [SerializeField] private GameObjectVisibleToggle coinVisibleToggle;
        [SerializeField] private GameObjectVisibleToggle leftTagVisibleToggle;
        [SerializeField] private GameObjectVisibleToggle middleTagVisibleToggle;
        [SerializeField] private TextMeshProUGUI coinText;
        [SerializeField] private float coinCountingDuration = 0.3f;
        [SerializeField] private TextMeshProUGUI coinWasText;
        [SerializeField] private GameObjectVisibleToggle classIconVisibleToggle;
        [SerializeField] private TextMeshProUGUI vipPointText;
        [SerializeField] private Button buyButton;
        [SerializeField] private TextMeshProUGUI priceText;

        [Space]
        [SerializeField] private Animator vipEffectAnimator;
        [SerializeField] private LayoutTransform normalLayoutTransform;
        [SerializeField] private LayoutTransform middleTagTransform;
#pragma warning restore 0649

        // private const float HEIGHT_NORMAL = 82f;
        // private const float HEIGHT_MIDDLE_TAG_ON_TOP = 95f;
        // private const float Y_OFFSET_MIDDLE_TAG_ON_TOP = -6.5f;

        public RectTransform RectTransform
        {
            get
            {
                if (rectTransform == null)
                {
                    rectTransform = GetComponent<RectTransform>();
                }
                return rectTransform;
            }
        }
        private RectTransform rectTransform;

        public float AnimationTime
        {
            get;
            private set;
        }

        private int itemIndex;
        private ShopCoinItemInfo itemInfo;
        private ShopCoinVipInfo vipInfo;
        private ShopCoinMultipleInfo multipleInfo;
        private Action<ShopCoinItemInfo, ShopCoinMultipleInfo, RectTransform> onClick;

        public void UpdateContent(int itemIndex,
                                  ShopCoinItemInfo itemInfo, 
                                  ShopCoinVipInfo vipInfo,
                                  ShopCoinMultipleInfo multipleInfo,
                                  Action<ShopCoinItemInfo, ShopCoinMultipleInfo, RectTransform> onClick,
                                  bool useAnimation)
        {
            this.itemIndex = itemIndex;
            this.itemInfo = itemInfo;
            this.vipInfo = vipInfo;
            this.multipleInfo = multipleInfo;
            this.onClick = onClick;

            AnimationTime = useAnimation ?
                            coinCountingDuration :
                            0f;

            UpdateCoinValue();

            vipEffectAnimator.SetBool("Show", (vipInfo.type != VipClassType.bronze));

            classIconVisibleToggle.TurnOnByNameInMultiple(vipInfo.type.ToString());
            vipPointText.text = StringMaker.New()
                                           .Append("+")
                                           .Append(StringUtils.ToComma(itemInfo.vipPoint))
                                           .Build();

            priceText.text = itemInfo.priceCurrency;

            // Button
            buyButton.onClick.RemoveListener(OnClick);
            buyButton.onClick.AddListener(OnClick);
        }

        public void UpdateCoinValue()
        {
            ShopCoinMultipleType multipleType = multipleInfo.type;
            double multipleValue = multipleInfo.value;
            string multipleName = multipleInfo.name;

            long vipBonus = vipInfo.bonusRate > 1 ?
                            itemInfo.vipBonus :
                            0;
            long coinVipBonusAdded = itemInfo.coin + vipBonus;
            ShopCoinTagType tagType = itemInfo.tagType;

            int bgIndex = tagType == ShopCoinTagType.None ? 0 : 1;
            int coinIndex = (coinVisibleToggle.Count - 1) - itemInfo.itemIndex;

            ///
            bgVisibleToggle.TurnOnByIndexInMultiple(bgIndex);

            ///
            leftTagVisibleToggle.gameObject.SetActive(false);
            leftTagVisibleToggle.gameObject.SetActive(true);
            leftTagVisibleToggle.TurnOnByNameInMultiple(multipleType.ToString());

            ///
            coinVisibleToggle.TurnOnByIndexInMultiple(coinIndex);

            ///
            if (multipleType != ShopCoinMultipleType.None)
            {
                GameObject activeObject = leftTagVisibleToggle.ActiveObject;
                if (activeObject != null)
                {
                    TextMeshProUGUI leftTagChildText = activeObject.transform
                                                                   .GetChild(0)
                                                                   .GetComponent<TextMeshProUGUI>();
                    leftTagChildText.text = multipleName;
                }
                
                coinWasText.gameObject.SetActive(true);
                coinWasText.SetNumber(value: coinVipBonusAdded,
                                      useComma: true,
                                      animationTime: 0f);
            }
            else
            {
                coinWasText.gameObject.SetActive(false);
            }

            ///
            middleTagVisibleToggle.TurnOnByNameInMultiple(tagType.ToString());
            SetLayoutMode(this.itemIndex == 0 && middleTagVisibleToggle.ActiveObject != null ?
                          LayoutMode.MiddleTagOnTop :
                          LayoutMode.Normal);

            ///
            var currentCoin = Convert.ToInt64(coinVipBonusAdded * multipleValue);
            //Transform parent = transform.parent;
            //bool isLastItem = parent.childCount >= 6
            //                  && parent.GetChild(5) == transform;
            //if (isLastItem)
            //{
            //    Debug.Log("==== " + AnimationTime + ", " + itemInfo.cachedCoin + " -> " + currentCoin);
            //}
            coinText.SetNumber(itemInfo.cachedCoin, true);
            //if (isLastItem)
            //{
            //    Debug.Log("==== SetText : " + coinText.text);
            //}
            coinText.SetNumber(value: currentCoin,
                               useComma: true,
                               animationTime: AnimationTime);

            itemInfo.cachedCoin = currentCoin;
        }

        private void SetLayoutMode(LayoutMode layoutMode)
        {
            if (layoutMode == LayoutMode.MiddleTagOnTop)
            {
                containerTransform.anchoredPosition = new Vector2(0, middleTagTransform.offsetY);
                layoutElement.preferredHeight = middleTagTransform.height;
            }
            else
            {
                containerTransform.anchoredPosition = new Vector2(0, normalLayoutTransform.offsetY);
                layoutElement.preferredHeight = normalLayoutTransform.height;
            }
            
        }

        private void OnClick()
        {
            //Debug.Log("==== OnClick : " + itemIndex + ", " + itemInfo.coin + ", " + multipleInfo.value);
            onClick?.Invoke(itemInfo, multipleInfo, classIconVisibleToggle.GetComponent<RectTransform>());
        }
    }
}
