using Gaga;
using Gaga.Util;
using System.Collections;
using TMPro;
using Underc.User;
using UnityEngine;

namespace Underc.Popup
{
    public class ShopPopupVip : BaseShopPopupLayer
    {
        [SerializeField] private GameObjectVisibleToggle classVisibleToggle;
        [SerializeField] private TextMeshProUGUI bonusRateText;
        [SerializeField] private TextMeshProUGUI classNameText;
        [SerializeField] private AnimatorParser vipOnAnimation;
        [SerializeField] private AnimatorParser vipOffAnimation;

        public RectTransform VipClassTransform
        { 
            get
            {
                if (vipClassTransform == null)
                {
                    vipClassTransform = classVisibleToggle.GetComponent<RectTransform>();
                }
                return vipClassTransform;
            }
        }
        private RectTransform vipClassTransform;

        public AnimatorParser VipOnAnimation
        {
            get => vipOnAnimation;
        }

        private MyVipClass vipClass;

        public override void Init()
        {
            vipClass = MyInfo.VipClass;
        }

        public override void Reset()
        {
            vipOffAnimation.SetTrigger();
        }

        public override IEnumerator UpdateContent()
        {
            if (vipClass.Type != VipClassType.none)
            {
                classVisibleToggle.TurnOnByNameInMultiple(vipClass.Type.ToString());
                VipBenefitTableItemInfo tableItemInfo = vipClass.GetCurrent_VipBenefitTableItemInfo(VipBenefitTableItem.CoinPackages);
                bonusRateText.text = tableItemInfo.ToString();
                classNameText.text = vipClass.Name.ToUpperInvariant();
            }
            yield break;
        }
    }
}
