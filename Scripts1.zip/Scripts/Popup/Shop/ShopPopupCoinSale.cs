using Gaga.Util;
using System.Collections;
using TMPro;
using Underc.User;
using UnityEngine;

namespace Underc.Popup
{
    public class ShopPopupCoinSale : BaseShopPopupLayer
    {
#pragma warning disable 
        [SerializeField] private TextMeshProUGUI remainingText;
#pragma warning restore

        private MyShopCoinSale coinSale;

        public override void Init()
        {
            coinSale = MyInfo.Shop.CoinSale;
        }

        public override void Reset()
        {
            gameObject.SetActive(false);
        }

        private void OnDisable()
        {
            coinSale.onTimeUpdate.RemoveListener(UpdateTime);
        }

        public override IEnumerator UpdateContent()
        {
            if (coinSale.RemainingSec > 0)
            {
                gameObject.SetActive(true);
                coinSale.onTimeUpdate.RemoveListener(UpdateTime);
                coinSale.onTimeUpdate.AddListener(UpdateTime);
                UpdateTime();
            }
            yield break;
        }

        private void UpdateTime()
        {
            if (coinSale.RemainingSec > 0)
            {
                remainingText.text = coinSale.RemainingSec.ToSummaryDHMS();
            }
            else
            {
                remainingText.text = "TIME'S UP";
            }
        }
    }
}