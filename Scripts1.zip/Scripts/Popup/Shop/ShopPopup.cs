

using System.Collections;
using Gaga.Popup;
using Underc.Net;
using UnityEngine;
using Underc.UI;
using Gaga.System;
using Underc.Net.Client;
using System.Collections.Generic;
using Underc.User;
using Gaga.Sound;

namespace Underc.Popup
{
    public enum ShopPopupState
    {
        CheckIfStoreInit,
        LoadShop,

        Reset,

        ShowTopUI,
        UpdateContent,
        MultiplyCoinItem,
        SelectCurrentCoupon,

        TryPurchase,
        CheckVipLevelUp,
        OpenVipBenefitPopup,

        Release,
        None, 
    }

    public class ShopPopup : PopupBackable
    {
#pragma warning disable 0649
        [SerializeField] private RectTransform safePanel;

        [SerializeField] private float vipApplyingDelay = 2f;
        [SerializeField] private float vipApplyingDuration = .5f;

        [SerializeField] private ShopPopupCoin coin;
        [SerializeField] private ShopPopupCoinSale coinSale;
        [SerializeField] private ShopPopupCoinCoupon coinCoupon;
        [SerializeField] private ShopPopupVip vip;

        [Header("Sound")]
        [SerializeField] private SoundPlayer showSound;
        [SerializeField] private SoundPlayer addSound;
#pragma warning restore 0649

        public bool RunAsFake
        {
            private get;
            set;
        }

        private bool initOnce;

        private TopUI topUI;

        private StateQueue<ShopPopupState> stateQueue;
        private List<BaseShopPopupLayer> layers;

        protected override void OnEnable()
        {
            base.OnEnable();

            Init();
            Reset();
            ResetTopUI();
        }

        private void Init()
        {
            if (initOnce == false)
            {
                initOnce = true;

                stateQueue = new StateQueue<ShopPopupState>(host: this);

                layers = new List<BaseShopPopupLayer>()
                {
                    coinSale,
                    coinCoupon,
                    vip,
                    coin, 
                };
                foreach (BaseShopPopupLayer layer in layers)
                {
                    layer.Init();
                }

                coin.OnCoinItemClick = () =>
                {
                    if (stateQueue.Contains(ShopPopupState.CheckVipLevelUp) == false
                        && stateQueue.Contains(ShopPopupState.MultiplyCoinItem) == false)
                    {
                        stateQueue.Add(ShopPopupState.TryPurchase);
                        stateQueue.Add(ShopPopupState.CheckVipLevelUp);
                    }
                };
            }
        }

        private void Reset()
        {
            foreach (BaseShopPopupLayer layer in layers)
            {
                layer.Reset();
            }
        }

        private void SetupTopUI()
        {
            if (topUI == null)
            {
                topUI = TopUISystem.Instance.Get(safePanel, ScreenSystem.IsLandscape);
                ResetTopUI();
            }
        }

        private void ResetTopUI()
        {
            if (topUI != null)
            {
                topUI.Use(TopUiItem.Coin,
                          TopUiItem.Level);
                topUI.OrderAsDefault();
                topUI.Reset();
                topUI.Hide(false);
            }
        }

        public void Open()
        {
            stateQueue.Reset();
            stateQueue.Add(ShopPopupState.CheckIfStoreInit);
            stateQueue.Add(ShopPopupState.LoadShop);
            stateQueue.Add(ShopPopupState.ShowTopUI);
            stateQueue.Add(ShopPopupState.UpdateContent);
            stateQueue.Add(ShopPopupState.MultiplyCoinItem);
        }

        private IEnumerator ResetCoroutine()
        {
            Reset();
            yield break;
        }

        public void OpenVipBenefitPopup()
        {
            if (stateQueue.Contains(ShopPopupState.OpenVipBenefitPopup) == false)
            {
                stateQueue.Add(ShopPopupState.OpenVipBenefitPopup);
            }
        }

        private IEnumerator OpenVipBenefitPopupCoroutine()
        {
            PopupObject<VipBenefitPopup> popupObject = null;
            popupObject = Popups.VipBenefit(onOpen: () =>
                                            {
                                                if (popupObject != null)
                                                {
                                                    popupObject.GetPopup().RunAsFake = RunAsFake;
                                                }
                                            })
                                .Async()
                                .Cache();
            yield return popupObject.WaitForClose();
        }

        private IEnumerator ShowTopUICoroutine()
        {
            SetupTopUI();
            topUI.Show(true);
            yield break;
        }

        private IEnumerator UpdateContentCoroutine()
        {
            foreach (BaseShopPopupLayer layer in layers)
            {
                layer.Reset();
                yield return layer.UpdateContent();
            }
            yield break;
        }

        private IEnumerator MultiplyCoinItemCoroutine()
        {
            // VIP 연출
            coin.UpdateVipInfo();
            
            vip.VipOnAnimation.SetTrigger();
            showSound.Play();
            yield return new WaitForSeconds(vipApplyingDelay);

            bool needVipApplying = coin.VipInfo.bonusRate > 1d;
            bool needSaleOrCouponApplying = MyInfo.Shop.CoinCoupon.InfoCount > 0
                                            || MyInfo.Shop.CoinSale.HasSale == true;
            if (needVipApplying)
            {
                addSound.Play();
                coin.UpdateCoinItems(true, "VIP TRANSITION");
            }

            if (needSaleOrCouponApplying)
            {
                if (needVipApplying)
                {
                    yield return new WaitForSeconds(vipApplyingDuration);
                }

                // 세일 또는 쿠폰 연출
                coinCoupon.SelectHighestCoupon();
            }
            yield break;
        }

        private IEnumerator SelectCurrentCouponCoroutine()
        {
            coinCoupon.SelectCurrentCoupon();
            yield break;
        }

        private IEnumerator LoadShopCoroutine()
        {
            Popups.ShowLoading();
            IRequest<ShopResponse> req;
            if (RunAsFake == false)
            {
                req = NetworkSystem.HTTPRequester.Shop();
            }
            else
            {
                req = FakeHttpRequester.Instance.Shop();
            }
            yield return req.WaitForResponse();
            Popups.HideLoading();

            if (req.isSuccess)
            {
                NetworkSystem.HTTPHandler.Do(req.data);
            }
            else
            {
                OpenErrorPopup(req.data.error);
            }
        }

        private void OpenErrorPopup(string message)
        {
            stateQueue.Reset();

            Popups.Error(message)
                  .Async()
                  .OnClose(Close);
        }

        private void OnPurchaseFail()
        {
            stateQueue.Reset();
        }

        private IEnumerator CheckIfStoreInitCoroutine()
        {
            yield return PurchaseSystem.Instance.CheckIfStoreInit(
                onFail: (string message) => OpenErrorPopup(message)
            );
        }

        private IEnumerator TryPurchaseCoroutine()
        {
            // Shop 팝업의 Pack 상품 또는 코인 상품 구매
            if (RunAsFake == false)
            {
                yield return PurchaseSystem.Instance.Purchase(itemID: coin.ClickedCoinItemInfo.itemID,
                                                              couponIndex: coin.ClickedCouponIndex,
                                                              onFail: OnPurchaseFail,
                                                              showReward: true);
            }
            else
            {
                Popups.ShowLoading();
                var req = FakeHttpRequester.Instance.PurchaseCoin(itemID: coin.ClickedCoinItemInfo.itemID,
                                                                  couponIndex: coin.ClickedCouponIndex);
                yield return req.WaitForResponse();
                Popups.HideLoading();

                MyInfo.VipClass.Update(req.data.vip_class, req.data.vip_point);

                PurchaseSystem purchaseSystem = PurchaseSystem.Instance;
                purchaseSystem.ExtractRewardDatas(req.data);
                purchaseSystem.ShowReward = true;
                yield return purchaseSystem.Reward();
            }
        }

        private IEnumerator CheckVipLevelUpCoroutine()
        {
            bool isLevelUp = MyInfo.VipClass.ConsumeLevelUp();
            if (isLevelUp == true)
            {
                yield return Popups.VipLevelUpCoroutine(RunAsFake);
                stateQueue.Add(ShopPopupState.LoadShop);
                stateQueue.Add(ShopPopupState.Reset);
                stateQueue.Add(ShopPopupState.UpdateContent);
                stateQueue.Add(ShopPopupState.MultiplyCoinItem);
            }
            else
            {
                stateQueue.Add(ShopPopupState.LoadShop);
                stateQueue.Add(ShopPopupState.SelectCurrentCoupon);
            }

            yield break;
        }

        private IEnumerator ReleaseCoroutine()
        {
            if (topUI != null)
            {
                TopUISystem.Instance.Return(topUI);
                topUI = null;
            }

            base.Close();
            yield break;
        }

        public override void Close()
        {
            stateQueue.Reset();
            stateQueue.Add(ShopPopupState.Release);
        }
       
        public override bool CanBack()
        {
            return Popups.IsLoading() == false;
        }
    }
}
