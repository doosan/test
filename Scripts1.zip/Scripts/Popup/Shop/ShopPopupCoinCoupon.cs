
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Gaga.Sound;
using Underc.User;
using UnityEngine;

namespace Underc.Popup
{
    public class ShopPopupCoinCoupon : BaseShopPopupLayer
    {
        [SerializeField] private List<CouponPreset> couponPresets;
        [Header("Sounds")]
        [SerializeField] private SoundPlayer couponOffSFX;

        private MyShopCoinSale coinSale;
        private MyShopCoinCoupon coinCoupon;
        private int highestIndex;
        private int previousIndex;

        public override void Init()
        {
            coinSale = MyInfo.Shop.CoinSale;
            coinCoupon = MyInfo.Shop.CoinCoupon;

            coinCoupon.CurrInfoIndex = -1;
            foreach (CouponPreset preset in couponPresets)
            {
                preset.SetState(CouponPresetState.Empty);
            }
        }

        public override void Reset()
        {
            UpdateCoupon();
        }

        private void OnDisable()
        {
            RemoveListeners();
        }

        private void RemoveListeners()
        {
            coinCoupon.onTimeUpdate.RemoveListener(UpdateTime);
            coinCoupon.onTimesUp.RemoveListener(SelectCurrentCoupon);
        }

        private void AddListeners()
        {
            coinCoupon.onTimeUpdate.AddListener(UpdateTime);
            coinCoupon.onTimesUp.AddListener(SelectCurrentCoupon);
        }

        public override IEnumerator UpdateContent()
        {
            RemoveListeners();
            AddListeners();
            
            UpdateTime();
            yield break;
        }

        private void UpdateCoupon()
        {
            /// coinCoupon.CurrInfoIndex 의 Info 가 비었을 때는 previousIndex 를 -1 로?
            previousIndex = coinCoupon.CurrInfoIndex;
            coinCoupon.CurrInfoIndex = -1;

            highestIndex = -1;
            int highestBonus = 0;

            for (int presetIndex = 0; presetIndex < couponPresets.Count; presetIndex++)
            {
                List<CouponItemInfo> infos = coinCoupon.GetInfos(presetIndex);
                CouponPreset preset = couponPresets[presetIndex];
                if (infos != null)
                {
                    CouponItemInfo firstInfo = infos[0];
                    int id = firstInfo.id;
                    int infoIndex = firstInfo.index;
                    string target = firstInfo.target;
                    string targetValueCurrency = firstInfo.targetValueCurrency;
                    int bonus = firstInfo.bonusRate;
                    int count = infos.Sum(info => info.count);
                    long expireTime = firstInfo.expireTime;

                    if (bonus > highestBonus)
                    {
                        highestBonus = bonus;
                        highestIndex = infoIndex;
                    }

                    preset.Setup(presetIndex, target, targetValueCurrency, bonus, count, SelectCoupon);
                    preset.SetState(CouponPresetState.Off);
                }
                else
                {
                    preset.SetState(CouponPresetState.Empty);
                }
            }
        }

        public void SelectHighestCoupon()
        {
            UpdateCoupon();
            if (previousIndex != -1)
            {
                CouponPreset preset = couponPresets[previousIndex];
                if (preset.State != CouponPresetState.Empty)
                {
                    SelectCoupon(previousIndex);
                }
            }
            else if (highestIndex != -1)
            {
                SelectCoupon(highestIndex);
            }
        }

        public void SelectCurrentCoupon()
        {
            UpdateCoupon();
            if (previousIndex != -1)
            {
                CouponPreset preset = couponPresets[previousIndex];
                if (preset.State != CouponPresetState.Empty)
                {
                    SelectCoupon(previousIndex);
                }
            }
        }

        private void SelectCoupon(int targetIndex)
        {
            if (coinSale.RemainingSec <= 0)
            {
                coinCoupon.CurrInfoIndex = coinCoupon.CurrInfoIndex != targetIndex ?
                                           targetIndex :
                                           -1;

                CouponPreset activatedCoupon = null;

                for (int presetIndex = 0; presetIndex < couponPresets.Count; presetIndex++)
                {
                    CouponPreset preset = couponPresets[presetIndex];
                    if (preset.State == CouponPresetState.Empty)
                    {
                        continue;
                    }

                    if (preset.index == coinCoupon.CurrInfoIndex)
                    {
                        preset.SetState(CouponPresetState.On);
                        activatedCoupon = preset;
                    }
                    else
                    {
                        preset.SetState(CouponPresetState.Off);
                    }
                }

                if (activatedCoupon == null)
                {
                    couponOffSFX.Play();
                }
            }
        }

        private void UpdateTime()
        {
            for (int presetIndex = 0; presetIndex < couponPresets.Count; presetIndex++)
            {
                List<CouponItemInfo> infos = coinCoupon.GetInfos(presetIndex);
                if (infos != null)
                {
                    CouponPreset preset = couponPresets[presetIndex];
                    preset.UpdateTime(infos[0].remainingSec);
                }
            }
        }
    }
}