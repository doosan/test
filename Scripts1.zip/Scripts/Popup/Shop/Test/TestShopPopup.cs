using Gaga.Popup;
using System.Collections;
using Underc.LoadingScreen;
using Underc.Net;
using Underc.Net.Client;
using Underc.Popup;
using Underc.User;
using Underc.Util;
using UnityEngine;

public class TestShopPopup : TestSceneScaffold
{
    [SerializeField] private VipClassType beginningVipClass = VipClassType.bronze;

    private FakeVipDataLoader fakeVipDataLoader;

    private IEnumerator Start()
    {
        yield return SetupAndLoad(new BaseLoadingItem[]
        {
            new LoginLoadingItem(),
            new PurchaseInitLoadingItem(),
            new HTTPLoadingItem<UserCoreResponse>(
                () => NetworkSystem.HTTPRequester.UserCoreWithAlarms(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<ProfileResponse>(
                () => NetworkSystem.HTTPRequester.Profile(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new ABLoadingItem(AssetBundleName.EFFECT),
            new TopUILoadingItem(),
            new RewardBonusUILoadingItem()
        });
    }

    public void OpenShopPopup()
    {
        fakeVipDataLoader = FakeVipDataLoader.Instance;
        fakeVipDataLoader.SetupProfileResponse(100, 500, beginningVipClass);

        fakeVipDataLoader.ResetShopMultipleDatas();
        fakeVipDataLoader.MakeShopCoinDatas();
        fakeVipDataLoader.SetupShopResponse();

        StartCoroutine(OpenShopPopupCoroutine());
    }

    public void OpenShopPopup_Coupon_Sale()
    {
        fakeVipDataLoader = FakeVipDataLoader.Instance;
        fakeVipDataLoader.SetupProfileResponse(100, 500, beginningVipClass);

        fakeVipDataLoader.ResetShopMultipleDatas();
        fakeVipDataLoader.MakeShopCoinDatas();
        fakeVipDataLoader.MakeShopCouponDatas();
        fakeVipDataLoader.MakeShopSaleData();
        fakeVipDataLoader.SetupShopResponse();

        StartCoroutine(OpenShopPopupCoroutine());
    }

    public void OpenShopPopup_Coupon()
    {
        fakeVipDataLoader = FakeVipDataLoader.Instance;
        fakeVipDataLoader.SetupProfileResponse(100, 500, beginningVipClass);

        fakeVipDataLoader.ResetShopMultipleDatas();
        fakeVipDataLoader.MakeShopCoinDatas();
        fakeVipDataLoader.MakeShopCouponDatas();
        fakeVipDataLoader.SetupShopResponse();

        StartCoroutine(OpenShopPopupCoroutine());
    }

    public void OpenShopPopup_Sale()
    {
        fakeVipDataLoader = FakeVipDataLoader.Instance;
        fakeVipDataLoader.SetupProfileResponse(100, 500, beginningVipClass);

        fakeVipDataLoader.ResetShopMultipleDatas();
        fakeVipDataLoader.MakeShopCoinDatas();
        fakeVipDataLoader.MakeShopSaleData();
        fakeVipDataLoader.SetupShopResponse();

        StartCoroutine(OpenShopPopupCoroutine());
    }

    private IEnumerator OpenShopPopupCoroutine()
    {
        yield return fakeVipDataLoader.LoadProfile();

        PopupObject<ShopPopup> popupObject = null;
        popupObject = Popups.Shop(onOpen: () =>
                             {
                                 if (popupObject != null)
                                 {
                                     popupObject.GetPopup().RunAsFake = true;
                                 }
                             })
                            .Async()
                            .Cache();
    }
}
