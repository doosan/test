using System.Collections;
using UnityEngine;

namespace Underc.Popup
{
    public class BaseShopPopupLayer : MonoBehaviour
    {
        public virtual bool CanBack()
        {
            return true;
        }

        public virtual void Init()
        {

        }

        public virtual void Reset()
        {

        }

        public virtual IEnumerator UpdateContent()
        {
            yield break;
        }
    }
}