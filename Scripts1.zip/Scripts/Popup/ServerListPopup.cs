using System;
using UnityEngine;
using UnityEngine.UI;
using Gaga.Popup;
using Underc.Net;
using Underc.Scene;

namespace Underc.Popup
{
    public class ServerListPopup : PopupBehaviour
    {
#if DEV
        private readonly string KEY_FORMAT = "serverlist_{0}";
#endif

        [Serializable]
        public class ConnectionItem
        {
            public InputField ipInputField;
            public InputField portInputField;
            public Button goButton;
        }

        #pragma warning disable 0649
        [SerializeField] private ConnectionItem devItem;
        [SerializeField] private ConnectionItem[] connectionItems;
        #pragma warning restore 0649

        public void Initialize()
        {
#if DEV
            devItem.ipInputField.text = "dev.aquuuacasino.com";
            devItem.portInputField.text = "443";

            devItem.goButton.onClick.RemoveAllListeners();
            devItem.goButton.onClick.AddListener(()=>
            {
                OnGoButtonClick(-1, devItem.ipInputField.text, devItem.portInputField.text);
            });

            for (int i = 0; i < connectionItems.Length; i++)
            {
                var item = connectionItems[i];
                int index = i;

                string key = string.Format(KEY_FORMAT, index);
                if (PlayerPrefs.HasKey(key))
                {
                    var val = PlayerPrefs.GetString(key);
                    var valArr = val.Split(':');
                    var ip = valArr[0];
                    var port = valArr[1];
                    item.ipInputField.text = ip;
                    item.portInputField.text = port;
                }
                else
                {
                    item.ipInputField.text = "";
                    item.portInputField.text = "";
                }
                
                item.goButton.onClick.RemoveAllListeners();
                item.goButton.onClick.AddListener(()=>
                {
                    OnGoButtonClick(index, item.ipInputField.text, item.portInputField.text);
                });
            }
#endif
        }

        private void OnGoButtonClick(int index, string ip, string port)
        {
#if DEV
            if (index < 0)
            {
                Address.UseCustomURI = false;
                SceneSystem.LoadIntro();
                return;
            }

            if (string.IsNullOrEmpty(ip)
                || string.IsNullOrEmpty(port)
                || ip.Contains(":")
                || port.Contains(":"))
            {
                return;
            }

            if (ip.Contains("https://"))
            {
                ip = ip.Replace("https://", "");
            }
            else if (ip.Contains("http://"))
            {
                ip = ip.Replace("http://", "");
            }

            var saveVal = ip + ":" + port;
            string key = string.Format(KEY_FORMAT, index);
            PlayerPrefs.SetString(key, saveVal);
            PlayerPrefs.Save();


            Address.UseCustomURI = true;
            Address.CustomIP = ip;
            Address.CustomPort = port;

            SceneSystem.LoadIntro();
#endif
        }
    }
}