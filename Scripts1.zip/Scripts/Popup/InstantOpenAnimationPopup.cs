using Gaga.Util;
using System;
using System.Collections;
using UnityEngine;

namespace Underc.Popup
{ 
    public class InstantOpenAnimationPopup : InstantMessagePopup
    {
        [Header("Open Animation")]
        [SerializeField] private AnimatorParser openAnimation;

        public override void Open(string message = "", Action onOK = null)
        {
            base.Open(message, onOK);

            if (openAnimation != null)
            {
                StartCoroutine(OpenCoroutine());
            }
        }

        private IEnumerator OpenCoroutine()
        {
            Interactable(false);
            yield return openAnimation.WaitForDuration();
            Interactable(true);
        }

        private void Interactable(bool value)
        {
            allowBackButton = value;
            if (okButton != null)
            {
                okButton.interactable = value;
            }
        }
    }
}

