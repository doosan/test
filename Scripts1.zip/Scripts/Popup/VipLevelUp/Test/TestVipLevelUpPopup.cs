using Gaga.Popup;
using Gaga.System;
using System.Collections;
using Underc.LoadingScreen;
using Underc.Net;
using Underc.Net.Client;
using Underc.Popup;
using Underc.User;
using Underc.Util;
using UnityEngine;

public class TestVipLevelUpPopup : TestSceneScaffold
{
    [SerializeField] private long beginningXp = 100;
    [SerializeField] private long beginningNextXp = 500;
    [SerializeField] private VipClassType beginningVipClass = VipClassType.bronze;

    private FakeVipDataLoader fakeVipDataLoader;

    private IEnumerator Start()
    {
        Init();

        yield return SetupAndLoad(new BaseLoadingItem[]
        {
            new LoginLoadingItem(),
            new PurchaseInitLoadingItem(),
            new HTTPLoadingItem<UserCoreResponse>(
                () => NetworkSystem.HTTPRequester.UserCoreWithAlarms(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<ProfileResponse>(
                () => NetworkSystem.HTTPRequester.Profile(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new ABLoadingItem(AssetBundleName.EFFECT),
            new TopUILoadingItem(),
            new RewardBonusUILoadingItem(),
        });
    }

    private void Init()
    {
        fakeVipDataLoader = FakeVipDataLoader.Instance;
    }

    public void VipLevelUpPopup()
    {
        StartCoroutine(Popups.VipLevelUpCoroutine());
    }

    public void PurchaseToVipLevelUpPopup()
    {
        var fakeVipDataLoader = FakeVipDataLoader.Instance;
        fakeVipDataLoader.SetupProfileResponse(beginningXp, beginningNextXp, beginningVipClass);

        fakeVipDataLoader.ResetShopMultipleDatas();
        fakeVipDataLoader.MakeShopCoinDatas();
        fakeVipDataLoader.MakeShopCouponDatas();
        fakeVipDataLoader.SetupShopResponse();

        int nextVipClass = (int)beginningVipClass;
        FakeHttpRequester.Instance.LoadedPurchaseCoinResponse = (string itemID, int couponIndex) =>
        {
            ShopCoinItemInfo coinItemInfo = MyInfo.Shop.Coin.GetItemInfo(itemID);
            nextVipClass += 1;
            if (nextVipClass > (int)VipClassType.black_diamond)
            {
                nextVipClass = (int)VipClassType.black_diamond;
            }

            long coinOrigin = coinItemInfo.coin;
            VipBenefitTableItemInfo tableItemInfo = MyInfo.VipClass.GetCurrent_VipBenefitTableItemInfo(VipBenefitTableItem.DailyBonus);
            long vipBonus = (long)(coinOrigin * tableItemInfo.bonusRate) - coinOrigin;

            var purchaseResponse = new PurchaseResponse();
            purchaseResponse.coin = coinOrigin + vipBonus;
            purchaseResponse.vip_class = nextVipClass;
            purchaseResponse.vip_point = coinItemInfo.vipPoint;

            fakeVipDataLoader.SetupProfileResponse(beginningXp, beginningNextXp, (VipClassType)nextVipClass);
            return purchaseResponse;
        };

        Coroutines.Create(this,
                          fakeVipDataLoader.LoadProfile,
                          OpenShopPopup)
                  .Sequence();
    }

    private IEnumerator OpenShopPopup()
    {
        PopupObject<ShopPopup> popupObject = null;
        popupObject = Popups.Shop(onOpen: () =>
                                  {
                                      if (popupObject != null)
                                      {
                                          popupObject.GetPopup().RunAsFake = true;
                                      }
                                  })
                            .Async()
                            .Cache();
        yield break;
    }

    public void OpenVipBenefitPopup(int vipClass)
    {
        MyInfo.VipClass.Update(vipClass);

        PopupObject<VipBenefitPopup> popupObject = null;
        popupObject = Popups.VipBenefit(onOpen: () =>
                                        {
                                            if (popupObject != null)
                                            {
                                                popupObject.GetPopup().RunAsFake = true;
                                            }
                                        })
                            .Async()
                            .Cache();
    }
}
