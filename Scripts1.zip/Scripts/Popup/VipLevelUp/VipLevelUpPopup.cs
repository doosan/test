using Gaga;
using Gaga.Popup;
using Gaga.System;
using System;
using System.Collections;
using TMPro;
using Underc.User;
using UnityEngine;

namespace Underc.Popup
{
    public enum VipLevelUpPopupState
    { 
        None,
        UpdateContent,
        OpenVipBenefitPopup,
        LoadProfile,
        Release
    }

    public class VipLevelUpPopup : InstantOpenAnimationPopup
    {
        [Header("Vip Level Up")]
        [SerializeField] private TextMeshProUGUI vipClassText;
        [SerializeField] private GameObjectVisibleToggle vipClassVisibleToggle;

        private bool initOnce;
        private MyVipClass vipClass;
        private Action onCheckTheBenefit;

        protected override void OnEnable()
        {
            base.OnEnable();

            Init();
            Reset();
        }

        private void Init()
        {
            if (initOnce == false)
            {
                initOnce = true;

                vipClass = MyInfo.VipClass;
            }
        }

        private void Reset()
        {

        }

        public void Open(Action onCheckTheBenefit)
        {
            base.Open("", onCheckTheBenefit);

            vipClassText.text = vipClass.Name.ToUpperInvariant();
            vipClassVisibleToggle.TurnOnByNameInMultiple(vipClass.Type.ToString());
        }
    }
}