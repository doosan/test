using Gaga.Popup;
using System;
using UnityEngine;

namespace Underc.Popup
{
    public class RestoreAccountPopup : PopupBackable
    {
        private Action onRestoreClick;

        public void Open(Action onRestoreClick)
        {
            this.onRestoreClick = onRestoreClick;
        }

        public void Restore()
        {
            Close();
            onRestoreClick?.Invoke();
        }

        public void Cancel()
        {
            Close();
            Application.Quit();
        }
    }
}
