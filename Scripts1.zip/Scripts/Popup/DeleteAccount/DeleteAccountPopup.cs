using Gaga.Popup;
using System.Collections;
using Underc.Auth;
using Underc.Net;
using Underc.Net.Client;
using Underc.Platform;
using UnityEngine;

namespace Underc.Popup
{ 
    public class DeleteAccountPopup : PopupBackable
    {
        public void Open()
        {

        }

        public void Delete()
        {
            StartCoroutine(DeleteCoroutine());
        }

        private IEnumerator DeleteCoroutine()
        {
            // deletion 요청
            IRequest<UserDeleteResponse> req = NetworkSystem.HTTPRequester.UserDelete(
                appleToken: AppleLogin.Instance.IdentityToken,
                appleCode: AppleLogin.Instance.AuthorizationCode
            );
            yield return req.WaitForResponse();

            bool isSuccess = req.isSuccess;
            if (isSuccess)
            {
                // Facebook 제외하고 로그아웃
                AccountSystem.LogoutPlatformLogin(exceptType: PlatformLoginType.Facebook);
                while (AccountSystem.IsAnyPlatformLoggedIn(PlatformLoginType.Facebook))
                {
                    yield return null;
                }
            }

            Close();
            if (isSuccess)
            {
                Application.Quit();
            }

            yield break;
        }
    }
}