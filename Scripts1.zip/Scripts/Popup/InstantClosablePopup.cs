namespace Underc.Popup
{ 
    public class InstantClosablePopup : InstantMessagePopup
    {
        public override void GoBack()
        {
            Close();
        }
    }
}
