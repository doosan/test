using System.Collections.Generic;
using TMPro;
using Underc.User;
using UnityEngine;

namespace Underc.Popup
{
    public class VipBenefitPopupColumn : MonoBehaviour
    {
        [SerializeField] private List<TextMeshProUGUI> infoTexts;

        public void Reset()
        {
            infoTexts[0].text = "";
            infoTexts[1].text = "";
            infoTexts[2].text = "";
            infoTexts[3].text = "";
            infoTexts[4].text = "";
            infoTexts[5].text = "";
            infoTexts[6].text = "";
            infoTexts[7].text = "";
            infoTexts[8].text = "";
            infoTexts[9].text = "";
            infoTexts[10].text = "";
            infoTexts[11].text = "";
        }

        public void UpdateContent(VipBenefitTableInfo info)
        {
            infoTexts[0].text = info.coinPackages.ToString();
            infoTexts[1].text = info.vipPoints.ToString();
            infoTexts[2].text = info.dailyBonus.ToString();
            infoTexts[3].text = info.hugeBonus.ToString();
            infoTexts[4].text = info.dailyQuest.ToString();
            infoTexts[5].text = info.harvest.ToString();
            infoTexts[6].text = info.missionPass.ToString();
            infoTexts[7].text = info.chest.ToString();
            infoTexts[8].text = info.sea.ToString();
            infoTexts[9].text = info.sharePostGift.ToString();
            infoTexts[10].text = info.fanPageGift.ToString();
            infoTexts[11].text = info.vipSupport == true ? "O" : "X";
        }
    }
}