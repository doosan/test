using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace Underc.Popup
{
    public enum WidthChangeFallBackItemType
    {
        RectTransform,
        LayoutElement,
        ParticleSystem
    }

    [Serializable]
    public class WidthChangeFallBackItem
    {
        public string name;
        public WidthChangeFallBackItemType type;
        public RectTransform rectTransform;
        public LayoutElement layoutElement;
        public ParticleSystem particleSystem;
        public float widthLow;
        public float widthHigh;
        public float width;
    }

    [ExecuteInEditMode]
    public class WidthChangeFallback : MonoBehaviour
    {
        [Header("Space")]
        [SerializeField] private RectTransform referenceTransform;
        [SerializeField] private float referenceWidthLow;
        [SerializeField] private float referenceWidthHigh;
        
        [FormerlySerializedAs("items")]
        [SerializeField] private List<WidthChangeFallBackItem> items1;
        [SerializeField] private List<WidthChangeFallBackItem> items2;

        private float prevWidth;  

        private void Update()
        {
            float currentHeight = referenceTransform.rect.height;
            float currentWidth = referenceTransform.rect.width;
            float referenceHeight = 720;
            float referenceWidth = Mathf.Ceil(currentWidth * (referenceHeight / currentHeight));
            referenceWidth = Mathf.Max(referenceWidth, referenceWidthLow);

            if (prevWidth != referenceWidth)
            {
                prevWidth = referenceWidth;

                float referenceWidthGap = referenceWidthHigh - referenceWidthLow;
                float currentWidthGap = referenceWidth - referenceWidthLow;
                float currentWidthRatio = currentWidthGap / referenceWidthGap;

                foreach (WidthChangeFallBackItem item in items1)
                {
                    Do(item, currentWidthRatio);
                }

                foreach (WidthChangeFallBackItem item in items2)
                {
                    Do(item, currentWidthRatio);
                }
            }
        }

        private void Do(WidthChangeFallBackItem item, float currentWidthRatio)
        {
            float itemWidthGap = item.widthHigh - item.widthLow;
            item.width = item.widthLow + itemWidthGap * currentWidthRatio;

            switch (item.type)
            {
                case WidthChangeFallBackItemType.RectTransform:
                    RectTransform rectTransform = item.rectTransform;
                    if (rectTransform != null)
                    {
                        Vector2 originSize = rectTransform.sizeDelta;
                        rectTransform.sizeDelta = new Vector2(item.width, originSize.y);
                    }
                    break;

                case WidthChangeFallBackItemType.LayoutElement:
                    LayoutElement layoutElement = item.layoutElement;
                    if (layoutElement != null)
                    {
                        layoutElement.preferredWidth = item.width;
                    }
                    break;

                case WidthChangeFallBackItemType.ParticleSystem:
                    ParticleSystem particleSystem = item.particleSystem;
                    if (particleSystem != null)
                    {
                        ParticleSystem.ShapeModule shapeModule = particleSystem.shape;
                        shapeModule.scale = new Vector3(item.width, 1f, 1f);
                    }
                    break;
            }
        }
    }
}