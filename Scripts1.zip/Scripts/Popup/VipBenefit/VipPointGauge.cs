using Gaga;
using Gaga.Util;
using System;
using TMPro;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Popup
{
    public enum VipPointGaugeType
    {
        Single,
        Double
    }

    public class VipPointGauge : MonoBehaviour
    {
        [SerializeField] private GameObjectVisibleToggle xpStatusVisibleToggle;

        [Header("Single")]
        [SerializeField] private TextMeshProUGUI pointText;

        [Header("Double")]
        [SerializeField] private GameObjectVisibleToggle currVipClassToggle;
        [SerializeField] private GameObjectVisibleToggle nextVipClassToggle;
        [SerializeField] private Slider xpGauge;
        [SerializeField] private TextMeshProUGUI xpText;

        public static DateTimeInfo FakeNow;
        private static DateTime ReadNow()
        {
            return FakeNow != null ? FakeNow.dateTime : DateTime.Now;
        }

        private MyVipClass vipClass;

        public void Reset()
        {
            vipClass = MyInfo.VipClass;

            xpStatusVisibleToggle.TurnOff();
        }

        public void UpdateContent(VipPointGaugeType gaugeType)
        {
            xpStatusVisibleToggle.TurnOnByNameInMultiple(gaugeType.ToString());

            if (gaugeType == VipPointGaugeType.Single)
            {
                pointText.text = StringMaker.New()
                                            .Append("(+")
                                            .Append(StringUtils.ToComma(vipClass.Xp))
                                            .Append(")")
                                            .Build();
            }
            else
            {
                currVipClassToggle.TurnOnByNameInMultiple(vipClass.Type.ToString());

                int nextIndex = (int)vipClass.Type + 1;
                if (Enum.IsDefined(typeof(VipClassType), nextIndex))
                {
                    VipClassType nextType = (VipClassType)nextIndex;
                    nextVipClassToggle.TurnOnByNameInMultiple(nextType.ToString());
                }

                // xp 
                float progress = vipClass.Xp / (float)vipClass.NextXp;
                xpGauge.value = progress;

                int percent = (int)(progress * 100);
                xpText.text = StringMaker.New()
                                         .Append(percent.ToString())
                                         .Append("% (")
                                         .Append(StringUtils.ToComma(vipClass.Xp))
                                         .Append("/")
                                         .Append(StringUtils.ToComma(vipClass.NextXp))
                                         .Append(")")
                                         .Build();
            }
        }
    }
}
