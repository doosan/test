using Gaga;
using Gaga.Popup;
using Gaga.System;
using Gaga.UI;
using System;
using System.Collections;
using System.Collections.Generic;
using Underc.Net;
using Underc.Net.Client;
using Underc.User;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace Underc.Popup
{
    public class VipBenefitPopup : PopupBackable
    {
        private enum VipBenefitPopupState
        {
            None,
            LoadProfile,
            UpdateContent
        }

        [SerializeField] private VipPointGauge vipPointGauge;
        [SerializeField] private Button vipResetKickOffButton;
        [SerializeField] private Text yearText;
        [SerializeField] private List<PageView> pageViews;
        [SerializeField] private GameObject blackDiamondInfoPanel;

        [FormerlySerializedAs("vipBenefitInfoColumns")]
        [SerializeField] private List<VipBenefitPopupColumn> vipBenefitPopupColumns;
        [SerializeField] private GameObjectVisibleToggle highlightVisibleToggle;

        public static DateTimeInfo FakeNow;
        private static DateTime ReadNow()
        {
            return FakeNow != null ? FakeNow.dateTime : MyInfo.VipClass.Now;
        }

        public bool RunAsFake
        {
            private get;
            set;
        }

        private MyVipClass vipClass;
        private StateQueue<VipBenefitPopupState> stateQueue;
        private bool initOnce;

        protected override void OnEnable()
        {
            base.OnEnable();

            Init();
            Reset();
        }

        protected override void OnDisable()
        {
            base.OnDisable();

            pageViews[0].onMove.RemoveListener(UpdateHighlightVisible);
        }

        private void Init()
        {
            if (initOnce == false)
            {
                initOnce = true;

                stateQueue = new StateQueue<VipBenefitPopupState>(this);
            }
        }

        private void Reset()
        {
            vipClass = MyInfo.VipClass;

            vipPointGauge.Reset();

            DateTime dateTime = ReadNow();
            int thisMonth = dateTime.Month;
            int nextYear = dateTime.Year + 1;

            vipResetKickOffButton.gameObject.SetActive(thisMonth == 12);
            yearText.text = nextYear.ToString();

            pageViews[0]?.onMove.AddListener(UpdateHighlightVisible);

            // table
            for (int i = 0; i < vipClass.VipBenefitTableInfoCount; i++)
            {
                if (i < vipBenefitPopupColumns.Count)
                {
                    VipBenefitPopupColumn column = vipBenefitPopupColumns[i];
                    column.Reset();
                }
            }

            highlightVisibleToggle.TurnOff();
        }

        private void UpdateHighlightVisible()
        {
            int highlightPageIndex = (int)(vipClass.Index / 4);
            int pageIndex = pageViews[0] != null ? 
                            pageViews[0].PageIndex : 
                            -1;

            if (highlightPageIndex == pageIndex)
            {
                highlightVisibleToggle.TurnOnByIndexInMultiple(vipClass.Index);
            }
            else
            {
                highlightVisibleToggle.TurnOff();
            }
        }

        public void VipResetKickOffPopup()
        {
            Popups.VipResetKickOff()
                  .Async();
        }

        public void Open()
        {
            stateQueue.Reset();
            stateQueue.Add(VipBenefitPopupState.LoadProfile);
            stateQueue.Add(VipBenefitPopupState.UpdateContent);
        }

        private IEnumerator LoadProfileCoroutine()
        {
            Popups.ShowLoading();
            IRequest<ProfileResponse> req = null;
            if (RunAsFake == false)
            {
                req = NetworkSystem.HTTPRequester.Profile();
                yield return req.WaitForResponse();
            }
            else
            {
                req = FakeHttpRequester.Instance.Profile();
                yield return req.WaitForResponse();
            }
            Popups.HideLoading();

            if (req.isSuccess)
            {
                NetworkSystem.HTTPHandler.Do(req.data);
            }
            else
            {
                OpenErrorPopup(req.data.error);
            }
        }

        private void OpenErrorPopup(string message)
        {
            stateQueue.Reset();
            Popups.Error(message)
                  .Async()
                  .OnClose(Close);
        }

        private IEnumerator UpdateContentCoroutine()
        {
            VipPointGaugeType gaugeType = vipClass.Type == VipClassType.black_diamond ?
                                          VipPointGaugeType.Single :
                                          VipPointGaugeType.Double;
            vipPointGauge.UpdateContent(gaugeType);

            if (blackDiamondInfoPanel != null)
            {
                blackDiamondInfoPanel.SetActive(gaugeType == VipPointGaugeType.Double);
            }

            // table
            for (int i = 0; i < vipClass.VipBenefitTableInfoCount; i++)
            {
                VipBenefitTableInfo vipBenefitInfo = vipClass.GetVipBenefitTableInfo(i);
                if (i < vipBenefitPopupColumns.Count)
                {
                    VipBenefitPopupColumn column = vipBenefitPopupColumns[i];
                    column.UpdateContent(vipBenefitInfo);
                }
            }

            highlightVisibleToggle.TurnOnByIndexInMultiple(vipClass.Index);
            int pageIndex = (int)(vipClass.Index / 4);
            foreach (PageView pageView in pageViews)
            {
                pageView.GoTo(pageIndex);
            }
            yield break;
        }
    }
}