using Gaga;
using Gaga.Popup;
using Gaga.System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using Underc.Platform;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Popup
{
    public enum GameSettingPopupState
    {
        None,
        Release,
        TogglePlatformLogin,
        UpdateContent
    }

    public sealed class GameSettingPopup : PopupBackable
    {
        [SerializeField] private List<Toggle> tabToggles;
        [SerializeField] private List<GameObjectVisibleToggle> tabVisibleToggles;
        [SerializeField] private GameObjectVisibleToggle layerVisibleToggle;

        [SerializeField] private GameSettingPopupSystem system;
        [SerializeField] private GameSettingPopupHelp help;

        [SerializeField] private TextMeshProUGUI licenseText;

        public bool RunAsFake
        {
            set
            {
                foreach (BaseGameSettingPopupLayer layer in layers)
                {
                    layer.RunAsFake = value;
                }
                runAsFake = value;
            }
            private get
            {
                return runAsFake;
            }
        }
        private bool runAsFake;

        public GameSettingPopupSystem System
        {
            get => system;
        }

        private bool initOnce;

        private int tabIndex;
        private StateQueue<GameSettingPopupState> stateQueue;
        private List<BaseGameSettingPopupLayer> layers;

        protected override void OnEnable()
        {
            base.OnEnable();

            Init();
            ResetOnce();
            UpdateTab();
        }

        public void Init()
        {
            if (initOnce == false)
            {
                initOnce = true;

                stateQueue = new StateQueue<GameSettingPopupState>(host: this);
                layers = new List<BaseGameSettingPopupLayer>()
                {
                    system, help
                };
                foreach (BaseGameSettingPopupLayer layer in layers)
                {
                    layer.Init();
                    layer.RootTransform = transform;
                }

                // Tab
                for (int i = 0; i < tabToggles.Count; i++)
                {
                    int toggleIndex = i;
                    tabToggles[i].onValueChanged.AddListener((bool value) =>
                    {
                        if (value == false
                            || tabIndex == toggleIndex)
                        {
                            return;
                        }

                        tabIndex = toggleIndex;

                        UpdateTab();
                        UpdateContent();
                    });
                }

                system.OnPlatformLoginToggled = (PlatformLoginType type, bool isOn) =>
                {
                    stateQueue.Add(GameSettingPopupState.TogglePlatformLogin, new TogglePlatformInfo(type, isOn));
                    stateQueue.Add(GameSettingPopupState.UpdateContent);
                };

                help.OnLicenseClick = OpenLicensePage;
            }
        }

        private IEnumerator TogglePlatformLoginCoroutine(object param)
        {
            yield return PlatformLoginSystem.Instance.TogglePlatformLogin((TogglePlatformInfo)param);
        }

        private void ResetOnce()
        {
            foreach (BaseGameSettingPopupLayer layer in layers)
            {
                layer.ResetOnce();
                layer.Reset();
            }
        }

        private void UpdateTab()
        {
            foreach (GameObjectVisibleToggle tabVisibleToggle in tabVisibleToggles)
            {
                tabVisibleToggle.IsOn = false;
            }
            tabVisibleToggles[tabIndex].IsOn = true;

            layerVisibleToggle.TurnOnByIndexInMultiple(tabIndex);

            //
            //BaseGameProfilePopupLayer layer = layers[tabIndex];
            //bool commonProfileVisible = layer is GameProfilePopupProfile
            //                            || layer is GameProfilePopupRecord;
            //commonProfile.gameObject.SetActive(commonProfileVisible);
        }


        public void Open(int tabIndex)
        {
            if (tabIndex != -1)
            {
                this.tabIndex = tabIndex;
            }

            UpdateTab();

            stateQueue.Reset();
            UpdateContent();
        }

        private void UpdateContent()
        {
            stateQueue.Add(GameSettingPopupState.UpdateContent);
        }

        private void OpenLicensePage(string message)
        {
            layerVisibleToggle.TurnOnByNameInMultiple("License");

            bool needToUpdate = licenseText.text != message;
            if (needToUpdate)
            {
                licenseText.text = message;
                licenseText.GetComponent<RectTransform>().anchoredPosition = new Vector2(0, 0);
            }
        }

        private IEnumerator UpdateContentCoroutine()
        {
            BaseGameSettingPopupLayer layer = layers[tabIndex];
            layer.Reset();
            yield return layer.UpdateContent();
        }

        private IEnumerator ReleaseCoroutine()
        {
            foreach (BaseGameSettingPopupLayer layer in layers)
            {
                yield return layer.Unload();
            }

            base.Close();
        }

        public override bool CanBack()
        {
            bool result = Popups.IsLoading() == false;
            foreach (BaseGameSettingPopupLayer layer in layers)
            {
                if (layer.gameObject.activeInHierarchy)
                {
                    result &= layer.CanBack(); // 모두 통과되어야 함
                }
            }

            return result;
        }

        public override void GoBack()
        {
            base.GoBack();
        }

        public override void Close()
        {
            if (layerVisibleToggle.ActiveObject.name == "License")
            {
                layerVisibleToggle.TurnOnByNameInMultiple("Help");
            }
            else
            {
                UndercGameLog.Fobis.SystemOption();

                stateQueue.Add(GameSettingPopupState.Release);
            }
        }
    }
}
