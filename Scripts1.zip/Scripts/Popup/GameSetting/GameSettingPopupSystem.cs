using Gaga;
using Gaga.Sound;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using Underc.Notification;
using System.Collections.Generic;
using System.Collections;
using System;
using Underc.Platform;

namespace Underc.Popup
{
    public class GameSettingPopupSystem : BaseGameSettingPopupLayer
    {
#pragma warning disable 0649
        [SerializeField] private bool testPlatformLoginButtons;
        [Space]

        // 0
        [SerializeField] private RectTransform content;
        [SerializeField] private float rowHeight = 100;
        // 1
        [SerializeField] private TextMeshProUGUI bgmText;
        [SerializeField] private Slider bgmSlider;
        // 2
        [SerializeField] private TextMeshProUGUI soundText;
        [SerializeField] private Slider soundSlider;
        // 3
        [SerializeField] private SliderToggle vibrateToggle;
        [SerializeField] private SliderToggle alwaysScreenOnToggle;
        // 4
        [SerializeField] private SliderToggle notificationsToggle;
        [SerializeField] private SliderToggle broadcastAlarmToggle;
        // 5
        [SerializeField] private ButtonToggle facebookLoginToggle;
        // 6
        [SerializeField] private ButtonToggle appleLoginToggle;
        [SerializeField] private GameObject appleLoginContent;
#pragma warning restore 0649

        public bool TestPlatformLoginButtons
        {
            set 
            {
                testPlatformLoginButtons = value;
                SetupPlatformLoginButtons();
            }
        }
        public Action<PlatformLoginType, bool> OnPlatformLoginToggled;

        private readonly int INDEX_VALUE_BGM = 1;
        private readonly int INDEX_VALUE_SOUND = 2;
        private readonly int INDEX_VALUE_VIBRATE = 3;
        private readonly int INDEX_VALUE_NOTIFICATIONS = 4;
        private readonly int INDEX_VALUE_BROADCAST = 5;
        private readonly int INDEX_VALUE_SCREEN = 6;
        private readonly int INDEX_VALUE_FACEBOOK_LOGIN = 7;
        private readonly int INDEX_VALUE_APPLE_LOGIN = 8;

        private MySettings mySettings;
        private Dictionary<int, float> originValues;
        private Vector2 originSize;

        public override void Init()
        {
            mySettings = MyInfo.Settings;
            originValues = new Dictionary<int, float>();

            SetupPlatformLoginButtons();
        }

        private void SetupPlatformLoginButtons()
        {
#if UNITY_EDITOR == false
            testPlatformLoginButtons = false;
#endif

            if (originSize == Vector2.zero
                && content != null)
            {
                originSize = content.sizeDelta;
            }

            bool isAppleLoginSupported = false;
#if UNITY_IOS
            Version currentVersion = new Version(UnityEngine.iOS.Device.systemVersion);
            Version ios13 = new Version("13.0");
            if (currentVersion >= currentVersion)
            {
                isAppleLoginSupported = true;
            }
#endif
            if (testPlatformLoginButtons == true
                || isAppleLoginSupported == true)
            {
                if (appleLoginContent != null)
                {
                    appleLoginContent.gameObject.SetActive(true);
                }
                if (content != null)
                {
                    content.sizeDelta = originSize;
                }
            }
            else
            {
                if (appleLoginContent != null)
                {
                    appleLoginContent.gameObject.SetActive(false);
                }
                if (content != null)
                {
                    content.sizeDelta = new Vector2(originSize.x, originSize.y - rowHeight);
                }
            }
        }

        private void OnDisable()
        {
            RemoveListeners();
            
            var newValues = GetCurrentValues();
            SaveChangedValues(originValues, newValues);
        }

        private void RemoveListeners()
        {
            bgmSlider.onValueChanged.RemoveListener(OnBgmChanged);
            soundSlider.onValueChanged.RemoveListener(OnSoundChanged);
            alwaysScreenOnToggle.OnValueChanged.RemoveListener(OnAlwaysScreenOnChanged);
            notificationsToggle.OnValueChanged.RemoveListener(OnNotificationsChanged);
            facebookLoginToggle.OnValueChanged.RemoveListener(OnFacebookLoginChanged);
            appleLoginToggle.OnValueChanged.RemoveListener(OnAppleLoginChanged);
        }

        private void AddListeners()
        {
            bgmSlider.onValueChanged.AddListener(OnBgmChanged);
            soundSlider.onValueChanged.AddListener(OnSoundChanged);
            alwaysScreenOnToggle.OnValueChanged.AddListener(OnAlwaysScreenOnChanged);
            notificationsToggle.OnValueChanged.AddListener(OnNotificationsChanged);
            facebookLoginToggle.OnValueChanged.AddListener(OnFacebookLoginChanged);
            appleLoginToggle.OnValueChanged.AddListener(OnAppleLoginChanged);
        }

        public override void Reset()
        {
            originValues.Clear();

            // 1
            bgmSlider.value = mySettings.BgmVolume;
            OnBgmChanged(bgmSlider.value);

            // 2
            soundSlider.value = mySettings.SoundVolume;
            OnSoundChanged(soundSlider.value);

            // 3-1
            vibrateToggle.UpdateValue(mySettings.Vibrate);
            // 3-2
            alwaysScreenOnToggle.UpdateValue(mySettings.AlwaysScreenOn);
            
            // 4-1
            notificationsToggle.UpdateValue(isOn: NotificationSystem.Instance.IsEnabled, 
                                            animation: false,
                                            ignoreEvent: true);
            // 4-2
            broadcastAlarmToggle.UpdateValue(mySettings.BroadcastAlarm);

            // 5
            facebookLoginToggle.UpdateValue(FacebookLogin.Instance.IsLoggedIn);

            // 6
            appleLoginToggle.UpdateValue(AppleLogin.Instance.IsLoggedIn);

            facebookLoginToggle.enabled = true;
            appleLoginToggle.enabled = true;

            originValues = GetCurrentValues();
        }

        public override IEnumerator UpdateContent()
        {
            RemoveListeners();
            AddListeners();
            yield break;
        }

        private Dictionary<int, float> GetCurrentValues()
        {
            var values = new Dictionary<int, float>();

            values.Add(INDEX_VALUE_BGM, bgmSlider.value);
            values.Add(INDEX_VALUE_SOUND, soundSlider.value);
            values.Add(INDEX_VALUE_VIBRATE, vibrateToggle.IsOn ? 1 : 0);
            values.Add(INDEX_VALUE_NOTIFICATIONS, notificationsToggle.IsOn ? 1 : 0);
            values.Add(INDEX_VALUE_BROADCAST, broadcastAlarmToggle.IsOn ? 1 : 0);
            values.Add(INDEX_VALUE_SCREEN, alwaysScreenOnToggle.IsOn ? 1 : 0);
            values.Add(INDEX_VALUE_FACEBOOK_LOGIN, facebookLoginToggle.IsOn ? 1 : 0);
            values.Add(INDEX_VALUE_APPLE_LOGIN, appleLoginToggle.IsOn ? 1 : 0);

            return values;
        }

        private void SaveChangedValues(Dictionary<int, float> originValues, Dictionary<int, float> currentValues)
        {
            foreach (var originItem in originValues)
            {
                var key = originItem.Key;

                var oriVal = originItem.Value;
                var currVal = currentValues[key];

                if (oriVal != currVal)
                {
                    bool sendGameLog = true;

                    if (key == INDEX_VALUE_BGM)
                    {
                        mySettings.BgmVolume = currVal;
                    }
                    else  if (key == INDEX_VALUE_SOUND)
                    {
                        mySettings.SoundVolume = currVal;
                    }
                    else  if (key == INDEX_VALUE_VIBRATE)
                    {
                        mySettings.Vibrate = currVal == 1;
                    }
                    else  if (key == INDEX_VALUE_NOTIFICATIONS)
                    {
                        // 변경하는 순간 저장하고 있음
                    }
                    else  if (key == INDEX_VALUE_BROADCAST)
                    {
                        mySettings.BroadcastAlarm = currVal == 1;
                    }
                    else  if (key == INDEX_VALUE_SCREEN)
                    {
                        sendGameLog = false;
                        mySettings.AlwaysScreenOn = currVal == 1;
                    }
                    else if (key == INDEX_VALUE_FACEBOOK_LOGIN)
                    {
                        // 변경하는 순간 저장하고 있음
                    }
                    else if (key == INDEX_VALUE_APPLE_LOGIN)
                    {
                        // 변경하는 순간 저장하고 있음
                    }

                    if (sendGameLog)
                    {
                        UndercGameLog.Fobis.SystemOption(key, (currVal > 0 ? 1 : 0));
                    }
                }
            }
        }

        public void OnBgmChanged(float value)
        {
            bgmText.text = ((int)(value * 100)).ToString();
            SoundSystem.Instance.BgmVolumeLimit = value;
        }

        public void OnSoundChanged(float value)
        {
            soundText.text = ((int)(value * 100)).ToString();
            SoundSystem.Instance.SfxVolumeLimit = value;
        }

        public void Vibrate(bool value)
        {
            mySettings.Vibrate = value;
        }

        public void OnAlwaysScreenOnChanged(bool value)
        {
            Screen.sleepTimeout = value == true ? 
                                  SleepTimeout.NeverSleep : 
                                  SleepTimeout.SystemSetting;
        }

        public void OnNotificationsChanged(bool value)
        {
            NotificationSystem.Instance.SetEnable(value);
            notificationsToggle.UpdateValue(isOn: NotificationSystem.Instance.IsEnabled, 
                                            animation: true, 
                                            ignoreEvent: true);
        }

        public void OnFacebookLoginChanged(bool value)
        {
            if (testPlatformLoginButtons == false)
            {
                facebookLoginToggle.enabled = false;
                OnPlatformLoginToggled?.Invoke(PlatformLoginType.Facebook, value);
            }
        }

        public void OnAppleLoginChanged(bool value)
        {
            if (testPlatformLoginButtons == false)
            {
                appleLoginToggle.enabled = false;
                OnPlatformLoginToggled?.Invoke(PlatformLoginType.Apple, value);
            }
        }
    }
}

