using DG.Tweening;
using Gaga.AssetBundle;
using Gaga.Util;
using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using Underc.User;
using UnityEngine;

namespace Underc.Popup
{
    public class GameSettingPopupHelp : BaseGameSettingPopupLayer
    {
#pragma warning disable 0649
        [SerializeField] private TextMeshProUGUI userIdText;
        [SerializeField] private TextMeshProUGUI copyText;
#pragma warning restore 0649

        private const string uiEffectAndUiParticle = @"
<size=32>UIEffect & UIParticle</size>

Copyright 2018 mob-sakai

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the ""Software""), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED ""AS IS"", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
";

        private const string bitmapFontImporter = @"
<size=32>Bitmap Font Importer</size>

MIT License

Copyright (c) 2016 litefeel.com

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the ""Software""), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED ""AS IS"", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
";

        private const string pathCreator = @"
<size=32>Path Creator</size>

Copyright (c) 2019 Sebastian Lague
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files(the ""Software""), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/ or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED ""AS IS"", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
";

        private const string nativeShare = @"
<size=32>Native Share</size>

MIT License

Copyright (c) 2017 Süleyman Yasir KULA

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the ""Software""), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/ or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED ""AS IS"", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
";

        public Action<string> OnLicenseClick;

        private string msgVersion;
        private string msgID;

        private string license;

        private List<string> licenses;

        public override void Init()
        {
            licenses = new List<string>();
            licenses.Add(uiEffectAndUiParticle);
            licenses.Add(bitmapFontImporter);
            licenses.Add(pathCreator);
            licenses.Add(nativeShare);
        }

        public void Setup(Action<string> onLicenseClick)
        {
        }

        private void ShuffleLicense()
        {
            // Fisher-Yates shuffle
            System.Random random = new System.Random();
            for (int i = licenses.Count - 1; i >= 1; i--)
            {
                int randomIndex = random.Next(i + 1);
                string value = licenses[randomIndex];
                licenses[randomIndex] = licenses[i];
                licenses[i] = value;

            }
        }

        public override void Reset() 
        {

        }

        public override IEnumerator UpdateContent()
        {
            msgVersion = StringMaker.New()
                                    .Append("VERSION: ")
                                    .Append(Application.version)
                                    .Append("")
                                    .Append(AssetBundleSystem.Instance.DisplayVersion)
                                    .Build();
            msgID = StringMaker.New()
                               .Append("USER ID: ")
                               .Append(MyInfo.ID)
                               .Build();

            userIdText.text = StringMaker.New()
                                         .Append(msgVersion)
                                         .Append(System.Environment.NewLine)
                                         .Append(msgID)
                                         .Build();
            yield break;
        }

        public void Copy()
        {
            string msgTotal = StringMaker.New()
                                         .Append(msgVersion)
                                         .Append(System.Environment.NewLine)
                                         .Append(msgID)
                                         .Build();

            msgTotal.CopyToClipboard();
        }

        public void GoToFanpage()
        {
            AppService.GoToFanpage();
        }

        public void OpenTermsOfService()
        {
            AppService.OpenTermsOfService();
        }

        public void OpenFAQ()
        {
            AppService.OpenFAQ();
        }

        public void OpenPrivacyPolicy()
        {
            AppService.OpenPrivacyPolicy();
        }

        public void AskDonar()
        {
            AppService.SendEmailToSupport();
        }

        public void OpenGDPR()
        {
            AppService.OpenGDPR();
        }

        public void OpenLicense()
        {
            ShuffleLicense();

            string lineSpace = Environment.NewLine + Environment.NewLine + Environment.NewLine;
            license = "";
            for (int i = 0; i < licenses.Count; i++)
            {
                license += licenses[i];
                license += lineSpace;
            }

            OnLicenseClick?.Invoke(license);
        }

        public void DeleteAccount()
        {
            Popups.DeleteAccount();
        }
    }
}
