using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using Underc.User;

namespace Tests
{
    public class TestRewardInfoOrder 
    {
        private List<RewardType> allRewardTypes;

        [OneTimeSetUp]
        public void Setup()
        {
            allRewardTypes = Enum.GetValues(typeof(RewardType))
                                 .Cast<RewardType>()
                                 .ToList();
            allRewardTypes.Remove(RewardType.none);
            allRewardTypes.Remove(RewardType.rand); 
        }

        [Test]
        public void TestRewardInfoOrder1()
        {
            // 1. Arrange
            List<RewardInfo> rewardInfos = new List<RewardInfo>();
            while (allRewardTypes.Count > 0)
            {
                int randomIndex = UnityEngine.Random.Range(0, allRewardTypes.Count);
                var randomRewardInfo = new RewardInfo(allRewardTypes[randomIndex], 0);
                rewardInfos.Add(randomRewardInfo);

                allRewardTypes.RemoveAt(randomIndex);
            }

            string result = "";
            foreach (RewardInfo rewardInfo in rewardInfos)
            {
                result += rewardInfo.type.ToString() + "\n";
            }
            Debug.Log($"===== result.before : {result}");

            // 2. Act 
            rewardInfos.SortByRewardOrder();

            result = "";
            foreach (RewardInfo rewardInfo in rewardInfos)
            {
                result += rewardInfo.type.ToString() + "\n";
            }
            Debug.Log($"===== result.after : {result}");

            // 3. Assert
            for (int i = 0; i < rewardInfos.Count; i++)
            {
                RewardInfo rewardInfo = rewardInfos[i];
                int rewardOrderIndex = i + 1;
                RewardOrder rewardOrder = (RewardOrder)rewardOrderIndex;
                Assert.AreEqual(rewardInfo.type.ToString(), rewardOrder.ToString());
            }
        }
    }
}
