using Gaga.Util;
using System.Collections.Generic;
using TMPro;
using Underc.Ocean;
using Underc.User;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace Underc.Popup
{
    public class FishRewardDisplay : MonoBehaviour
    {
        public enum ValueType
        {
            None      = -1,
            PointOnly = 0,
            CountOnly = 1,
            Both      = 2
        }

        [SerializeField] private Image fishImage;
        [SerializeField] private float baseFishImageSize = 100f;
        [FormerlySerializedAs("valueDisplayType")]
        [SerializeField] private ValueType valueDisplayType = ValueType.PointOnly;

        public ValueType GetValueType()
        {
            return valueDisplayType;
        }
        
        private List<float> fishImageSizeMuitiples = new List<float>
        {
            1.4f, // 1단계 녀석들은 100을 기준으로 1.4배
            .9f,  // 2단계, 3단계 녀석들은 0.9배에 맞추니 딱 맞아 보였음
            .9f
        };

        private TextMeshProUGUI valueText;

        public void UpdateContent(RewardType rewardType, TextMeshProUGUI rewardValueText, long rewardValue, TextMeshProUGUI additionalValueText, long additionalValue, ValueType valueType)
        {
            if (valueType == ValueType.None)
            {
                valueType = this.valueDisplayType;
            }

            if (rewardType == RewardType.fish)
            {
                SeaItemType fishType = SeaItemType.f;
                int fishID = (int)rewardValue;

                if (fishImage != null)
                {
                    Sprite fishIcon = FishIconSystem.Instance.GetFishIcon(fishType, fishID);
                    if (fishIcon != null)
                    {
                        fishImage.sprite = fishIcon;

                        FishPreset fishPreset = FishSystem.Instance.GetFishPreset(fishType, fishID);
                        float fishImageSize = baseFishImageSize * GetFishImageMultiple(fishPreset.ui.sizeGrade);
                        fishImage.ScaleToFit(fishImageSize);
                    }
                }

                if ((valueType == ValueType.PointOnly || valueType == ValueType.Both) &&
                    rewardValueText != null)
                {
                    BaseBookInfo bookInfo = MyInfo.Ocean.Book.GetBookInfo(SeaItemType.f, fishID);
                    if (bookInfo != null)
                    {
                        StringUtils.KMBOption kmbOption = StringUtils.GeneralKMBOption();
                        rewardValueText.text = StringUtils.ToKMB(bookInfo.Point, kmbOption);
                    }
                }
                else
                {
                    if (rewardValueText != null)
                    {
                        rewardValueText.text = "";
                    }   
                }
                
                if ((valueType == ValueType.CountOnly || valueType == ValueType.Both) &&
                    additionalValueText != null)
                {
                    additionalValueText.text = $"x{additionalValue}";
                }
                else
                {
                    if (additionalValueText != null)
                    {
                        additionalValueText.text = "";
                    }
                }
            }
        }

        private float GetFishImageMultiple(int fishImageSizeGrade)
        {
            float result = 0;
            int fishImageSizeIndex = fishImageSizeGrade - 1;
            if (fishImageSizeIndex < fishImageSizeMuitiples.Count)
            {
                result = fishImageSizeMuitiples[fishImageSizeIndex];
            }

            return result;
        }
    }
}