using Gaga.Sound;
using Gaga.System;
using Gaga.Util;
using Gaga.Attribute;
using System;
using System.Collections;
using System.Collections.Generic;
using Underc.Effect;
using Underc.Net;
using Underc.Scene;
using Underc.UI;
using Underc.User;
using UnityEngine;
using UnityEngine.Events;

namespace Underc.Popup
{
    public enum FirstArrivalUpdate
    {
        UserCore,
        SeaStory
    }

    public enum OpenSoundType
    {
        PlayOnce,
        PlayPerItem
    }

    public enum ItemType
    {
        Single      = 0,
        Multiple    = 1
    }

    public class SimpleRewardItemCollector : MonoBehaviour
    {
        [Serializable]
        public class EffectEvent : UnityEvent<RewardType> { };

        [Serializable]
        public class MultipleRewardItemInfo
        {
            public SimpleRewardItem[] items;
        }

        [SerializeField] private RectTransform uiRoot = null;
        [SerializeField] private RectTransform layoutGroup = null;
        [SerializeField] private RectTransform itemPoolRoot = null;

        [Space]
        [SerializeField] private ItemType rewardItemType = ItemType.Single;
        [SerializeField, ConditionalHide("rewardItemType", 0, true)] private SimpleRewardItem itemRef = null;
        [SerializeField, ConditionalHide("rewardItemType", 1, true)] private MultipleRewardItemInfo itemRefList = null;

        [Space]
        [SerializeField] private float openInterval = 0.1f;
        [SerializeField] private OpenSoundType openSoundType = OpenSoundType.PlayOnce;
        [SerializeField] private SoundPlayer openSfx = null;
        [SerializeField] private float showDelay = 0.3f;
        [SerializeField] private float hideDelay = 0.3f;

        // 이펙트 연출이 끝난 후 내부에서 모든 이벤트 리스너를 제거하고 있음.
        public EffectEvent OnEffectShow
        {
            get;
            private set;
        } = new EffectEvent();

        public UnityEvent OnEffectBegin
        {
            get;
            private set;
        } = new UnityEvent();

        public EffectEvent OnEffectFirstArrived
        {
            get;
            private set;
        } = new EffectEvent();

        public EffectEvent OnEffectArrived
        {
            get;
            private set;
        } = new EffectEvent();

        public UnityEvent OnEffectComplete
        {
            get;
            private set;
        } = new UnityEvent();

        public bool CanOpen
        {
            get => allItems.Count > 0;
        }

        public TopUI TopUI
        {
            get => topUI;
        }
        private TopUI topUI;

        public RewardBonusUI BonusUI
        {
            get => bonusUI;
        }
        private RewardBonusUI bonusUI;

        public bool RunAsFake
        {
            private get;
            set;
        }

        private const string TRIGGER_OPEN = "Open";
        private const string TRIGGER_COLLECT = "Collect";

        private GameObjectPoolGroup<SimpleRewardItem> rewardItemPoolGroup;
        private Dictionary<string, List<SimpleRewardItem>> itemDic;
        private List<SimpleRewardItem> allItems;

        private List<FirstArrivalUpdate> firstArrivalUpdates;
        private List<CustomYieldInstruction> effectYields;

        private Dictionary<RewardType, Vector2> startPositions = new Dictionary<RewardType, Vector2>();
        private Dictionary<RewardType, Vector2> endPositions = new Dictionary<RewardType, Vector2>();

        public void Init()
        {
            itemDic = new Dictionary<string, List<SimpleRewardItem>>();
            rewardItemPoolGroup = new GameObjectPoolGroup<SimpleRewardItem>(itemPoolRoot.gameObject);
            allItems = new List<SimpleRewardItem>();

            if (rewardItemType == ItemType.Single)
            {
                itemRefList.items = new SimpleRewardItem[]{itemRef};
            }
            
            for (int i = 0; i < itemRefList.items.Length; i++)
            {
                var id = i.ToString();
                var itemRef = itemRefList.items[i];

                rewardItemPoolGroup.Add(id, itemRef, 3);
                itemDic.Add(id, new List<SimpleRewardItem>());

                // 프리팹이 아니면 disable 
                if (itemRef.gameObject.scene.rootCount != 0)
                {
                    itemRef.gameObject.SetActive(false);
                }
            }

            firstArrivalUpdates = new List<FirstArrivalUpdate>();
            effectYields = new List<CustomYieldInstruction>();
        }

        public void Reset()
        {
            if (itemDic != null)
            {
                foreach (var item in itemDic)
                {
                    var rewardID = item.Key;
                    var rewardList = item.Value;

                    for (int i = 0; i < rewardList.Count; i++)
                    {
                        var rewardItem = rewardList[i];
                        rewardItemPoolGroup.Return(rewardID, rewardItem);
                    }

                    rewardList.Clear();
                }

                allItems.Clear();
            }

            if (openSfx != null)
            {
                openSfx.gameObject.SetActive(false);
            }

            if (topUI != null)
            {
                topUI.Hide(false);
            }
        }

        private void Release()
        {
            if (topUI != null)
            {
                TopUISystem.Instance.Return(topUI);
                topUI = null;
            }

            if (bonusUI != null)
            {
                RewardBonusUISystem.Instance.Return(bonusUI);
                bonusUI = null;
            }
        }

        public void Setup(List<RewardInfo> rewardInfos, 
                          SimpleRewardItemValueType itemValueType = SimpleRewardItemValueType.Verbose)
        {
            if (topUI == null)
            {
                topUI = TopUISystem.Instance.Get(uiRoot);
            }
            topUI.Use(TopUiItem.Coin,
                      TopUiItem.PearlAndTicket,
                      TopUiItem.Profile,
                      TopUiItem.Level);
            topUI.Order(TopUiItem.Coin,
                        TopUiItem.PearlAndTicket,
                        TopUiItem.Profile,
                        TopUiItem.Level);
            topUI.Reset();
            topUI.Hide(false);

            if (bonusUI == null)
            {
                bonusUI = RewardBonusUISystem.Instance.Get(uiRoot);
            }

            bonusUI.Reset();
            bonusUI.Setup(rewardInfos);
            rewardInfos.SortByRewardOrder();

            VipClassType vipClassType = MyInfo.VipClass.Type;
            for (int i = 0; i < rewardInfos.Count; ++i)
            {
                RewardInfo rewardInfo = rewardInfos[i];
                var rewardID = rewardItemType == ItemType.Single ? "0" : rewardInfo.skinIndex.ToString();
                SimpleRewardItem item =  rewardItemPoolGroup.Get(rewardID);
                item.transform.SetParent(layoutGroup, false);
                item.UpdateContent(rewardInfo, itemValueType, vipClassType);

                itemDic[rewardID].Add(item);
                allItems.Add(item);
            }
        }

        public void UpdateVisible(int index, bool visible)
        {
            allItems[index].gameObject.SetActive(visible);
        }

        public void RegisterAllStartPosition(Vector2 position)
        {
            foreach(RewardType rewardType in Enum.GetValues(typeof(RewardType)))
            {
                startPositions[rewardType] = position;
            }
        }

        public void RegisterEndPosition(RewardType rewardType, Vector2 position)
        {
            endPositions[rewardType] = position;
        }

        private Vector2 GetEndPosition(RewardType rewardType)
        {
            Vector2 result;
            if (endPositions.TryGetValue(rewardType, out result) == false)
            {
                Debug.LogWarning($"==== {rewardType} 타입에 대한 endPosition 값이 등록되어 있지 않습니다.");
            }
            return result;
        }

        public IEnumerator OpenCoroutine(Func<RewardInfo, float> getOpenInterval = null, 
                                         Func<RewardInfo, string> getOpenTrigger = null,
                                         Action<RewardInfo> onOpen = null)
        {
            if (openSoundType == OpenSoundType.PlayOnce)
            {
                openSfx?.Play();
            }

            for (int i = 0; i < allItems.Count; i++)
            {
                if (i > 0)
                {
                    SimpleRewardItem prevItem = allItems[i - 1];
                    float interval = getOpenInterval != null ? 
                                     getOpenInterval(prevItem.RewardInfo) : 
                                     openInterval;
                    yield return new WaitForSeconds(interval);
                }

                SimpleRewardItem item = allItems[i];
                string openTrigger = getOpenTrigger != null ?
                                     getOpenTrigger(item.RewardInfo) :
                                     TRIGGER_OPEN;
                item.SetOpenTrigger(openTrigger);
                if (openSoundType == OpenSoundType.PlayPerItem)
                {
                    openSfx?.Play();
                }
                onOpen?.Invoke(item.RewardInfo);
            }

            yield break;
        }

        public IEnumerator CollectCoroutine(float throwDelay = 0f)
        {
            yield return CloseItems();
            if (throwDelay > 0f)
            {
                yield return new WaitForSeconds(throwDelay);
            }

            yield return ShowUI();
            yield return ThrowItems();
            yield return Sync();
            yield return HideUI();
            yield return ShowVipLevelUp();
            Release();
        }

        private IEnumerator ShowVipLevelUp()
        {
            if (MyInfo.VipClass.ConsumeLevelUp())
            {
                yield return Popups.VipLevelUpCoroutine(RunAsFake);
            }

            yield break;
        }

        private IEnumerator ShowUI()
        {
            if (SetupTopUI() == true)
            {
                topUI.Show(true);
            }

            if (bonusUI.IsActive == true)
            {
                bonusUI.Show();
            }

            for (int i = 0; i < allItems.Count; i++)
            {
                SimpleRewardItem item = allItems[i];
                RewardType rewardType = item.RewardInfo.type;
                long rewardValue = item.RewardInfo.value;
                switch (rewardType)
                {
                    case RewardType.weekly_point:
                        // A-1. 연출을 위해 이전의 위클리 포인트 값으로 미리 세팅함
                        MyInfo.DailyMission.PointInfo.LoadPrevCache();
                        break;
                }

                OnEffectShow.Invoke(rewardType);
            }

            yield return new WaitForSeconds(showDelay);
        }

        private bool SetupTopUI()
        {
            topUI.UseCoin = RewardContains(RewardType.coin)
                            || ContainsAdditionalCoin();
            topUI.UseSecondaryCurrencies = RewardContains(RewardType.pearl)
                                           || RewardContains(RewardType.ticket)
                                           || RewardContains(RewardType.pearl_booster);
            topUI.UseProfile = RewardContains(RewardType.vip_point);
            topUI.UseLevel = RewardContains(RewardType.xp_booster);
                                
            topUI.UpdateBG();

            return topUI.UseCoin
                   || topUI.UseSecondaryCurrencies
                   || topUI.UseProfile
                   || topUI.UseLevel;
        }

        private IEnumerator HideUI()
        {
            topUI.Hide(true);
            bonusUI.Hide();

            yield return new WaitForSeconds(hideDelay);
        }

        private IEnumerator CloseItems()
        {
            for (int i = 0; i < allItems.Count; i++)
            {
                SimpleRewardItem item = allItems[i];
                item.SetCloseTrigger(TRIGGER_COLLECT);
            }
            yield break;
        }

        private IEnumerator ThrowItems()
        {
            OnEffectBegin.Invoke();

            EffectSystemDelegate method = null;
            int count = 15;
            Vector2 startPosition = Vector2.zero;
            Vector2 endPosition = Vector2.zero;
            Action onFirstArrived = null;
            Action onArrived = null;
            Transform scaleTarget = null;

            //
            firstArrivalUpdates.Clear();
            effectYields.Clear();
            for (int i = 0; i < allItems.Count; i++)
            {
                SimpleRewardItem item = allItems[i];
                RewardType rewardType = item.RewardInfo.type;
                long rewardValue = item.RewardInfo.value;
                long additionalCoin = item.RewardInfo.additionalValue;
                startPosition = startPositions.ContainsKey(rewardType) == true ?
                                startPositions[rewardType] : 
                                item.EffectStartPosition;
                
                switch (rewardType)
                {
                    case RewardType.coin:
                    case RewardType.coin_g_pickaxe:
                    case RewardType.coin_s_pickaxe:
                        method = EffectSystem.Instance.Coin;
                        count = 15;
                        endPosition = topUI.GetCoinIconPosition();
                        scaleTarget = topUI.GetCoinIcon();
                        onFirstArrived = () => MyInfo.Coin += rewardValue;
                        onArrived = () => topUI.CoinIconAnimation();
                        break;

                    case RewardType.pearl:
                        method = EffectSystem.Instance.Pearl;
                        count = 15;
                        endPosition = topUI.GetPearlIconPosition();
                        scaleTarget = topUI.GetPearlIcon();
                        onFirstArrived = () => MyInfo.Pearl += rewardValue;
                        onArrived = () => topUI.PearlIconAnimation();
                        break;

                    case RewardType.ticket:
                        method = EffectSystem.Instance.Ticket;
                        count = 15;
                        endPosition = topUI.GetTicketIconPosition();
                        scaleTarget = topUI.GetTicketIcon();
                        onFirstArrived = () => MyInfo.Ticket += rewardValue;
                        onArrived = () => topUI.TicketIconAnimation();
                        break;

                    case RewardType.golden:
                        method = EffectSystem.Instance.Light;
                        count = 1;
                        endPosition = bonusUI.BottomUI.Golden.CachedTransform.position;
                        onFirstArrived = () =>
                        {
                            long nextGoldenKey = MyInfo.CasinoBonus.GoldenKey + rewardValue;
                            MyInfo.CasinoBonus.UpdateGoldenKey(nextGoldenKey);
                            bonusUI.BottomUI.Golden.UpdateContent();
                        };
                        break;

                    case RewardType.obsidian:
                        method = EffectSystem.Instance.Light;
                        count = 1;
                        endPosition = bonusUI.BottomUI.Obsidian.CachedTransform.position;
                        onFirstArrived = () =>
                        {
                            long nextObsidianKey = MyInfo.CasinoBonus.ObsidianKey + rewardValue;
                            MyInfo.CasinoBonus.UpdateObsidianKey(nextObsidianKey);
                            bonusUI.BottomUI.Obsidian.UpdateContent();
                        };
                        break;

                    case RewardType.xp_booster:
                        method = EffectSystem.Instance.Light;
                        count = 1;
                        endPosition = topUI.GetLevelPosition();
                        onFirstArrived = () => UpdateOnce(FirstArrivalUpdate.UserCore);
                        break;

                    case RewardType.pearl_booster:
                        method = EffectSystem.Instance.Light;
                        count = 1;
                        endPosition = topUI.GetSecondaryCurrenciesPosition();
                        onFirstArrived = () => UpdateOnce(FirstArrivalUpdate.UserCore);
                        break;

                    case RewardType.fish:
                        method = EffectSystem.Instance.Light;
                        count = 1;
                        endPosition = bonusUI.BottomUI.GotoSea.CachedTransform.position;
                        onFirstArrived = () => UpdateOnce(FirstArrivalUpdate.SeaStory);
                        break;

                    case RewardType.s_pickaxe:
                        method = EffectSystem.Instance.SilverPickax;
                        count = (int)rewardValue;
                        endPosition = bonusUI.BottomUI.MissionIconManager.CachedTransform.position;
                        onFirstArrived = () =>
                        {
                            int nextPickax = MyInfo.ClamHarvest.DisplayInfo.pickax + (int)rewardValue;
                            MyInfo.ClamHarvest.UpdateClamHarvestDisplayInfo(pickax: nextPickax);
                            bonusUI.BottomUI
                                   .MissionIconManager
                                   .GetIcon(MissionIconType.ClamHarvest)
                                   .UpdateInfo(isProgressive: false);
                        };
                        break;

                    case RewardType.g_pickaxe:
                        method = EffectSystem.Instance.GoldPickax;
                        count = (int)rewardValue;
                        endPosition = bonusUI.BottomUI.MissionIconManager.CachedTransform.position;
                        onFirstArrived = () =>
                        {
                            int nextPickax = MyInfo.ClamHarvest.DisplayInfo.pickax + (int)rewardValue;
                            MyInfo.ClamHarvest.UpdateClamHarvestDisplayInfo(nextPickax);
                            bonusUI.BottomUI
                                   .MissionIconManager
                                   .GetIcon(MissionIconType.ClamHarvest)
                                   .UpdateInfo(isProgressive: false);
                        };
                        break;

                    case RewardType.weekly_point:
                        method = EffectSystem.Instance.DailyMissionPoint;
                        count = (int)rewardValue;
                        endPosition = GetEndPosition(rewardType);
                        onFirstArrived = () =>
                        {
                            MyInfo.DailyMission.PointInfo.LoadNextCache();
                        };

                        break;
                    case RewardType.mp_point:
                        method = EffectSystem.Instance.MissionPassPoint;
                        count = (int)rewardValue;
                        endPosition = GetEndPosition(rewardType);
                        onFirstArrived = () =>
                        {
                            long nextMissionPassPoint = MyInfo.MissionPass.CurrentMissionValue + rewardValue;
                            MyInfo.MissionPass.UpdateCurr(nextMissionPassPoint);
                        };
                        break;

                    case RewardType.blitz_point:
                        method = EffectSystem.Instance.BlitzPoint;
                        count = (int)rewardValue;
                        endPosition = GetEndPosition(rewardType);
                        onFirstArrived = () =>
                        {
                            long nextBlitzPoint = MyInfo.AquaBlitz.Curr + rewardValue;
                            MyInfo.AquaBlitz.UpdateCurr(nextBlitzPoint);
                        };
                        break;

                    case RewardType.vip_point:
                        method = VipClassEffect;
                        count = (int)rewardValue;
                        endPosition = topUI.GetProfileButtonPosition();
                        scaleTarget = topUI.GetProfileIcon();
                        onFirstArrived = () =>
                        {
                            long nextVipPoint = MyInfo.VipClass.Xp + rewardValue;
                            if (nextVipPoint > MyInfo.VipClass.NextXp)
                            {
                                UpdateOnce(FirstArrivalUpdate.UserCore);
                            }
                        };
                        onArrived = () => topUI.ProfileAnimation();
                        break;
                    
                    default:
                        Debug.LogWarning($"==== ThrowItems() : {rewardType} 에 대한 처리가 없습니다.");
                        break;
                }

                //Debug.Log($"==== {rewardType}, {startPosition}, {endPosition}");
                if (item.RewardInfo.skipEffect == false)
                {
                    effectYields.Add(InvokeEffect(rewardType,
                                                  method,
                                                  count,
                                                  startPosition,
                                                  endPosition,
                                                  scaleTarget,
                                                  onFirstArrived,
                                                  onArrived));
                }
            }

            // 이펙트 연출이 완료될 때까지 기다림
            yield return new WaitUntil(() =>
            {
                foreach (CustomYieldInstruction effectYield in effectYields)
                {
                    if (effectYield != null && effectYield.keepWaiting)
                    {
                        return false;
                    }
                }
                return true;
            });

            OnEffectComplete.Invoke();

            // 연출이 끝나고 나면 내부에서 모든 이벤트 리스너를 제거한다.
            OnEffectShow.RemoveAllListeners();
            OnEffectBegin.RemoveAllListeners();
            OnEffectFirstArrived.RemoveAllListeners();
            OnEffectArrived.RemoveAllListeners();
            OnEffectComplete.RemoveAllListeners();
        }

        private void VipClassEffect(int count,
                                    Vector2 startPosition,
                                    Vector2 endPosition,
                                    Transform scaleTarget = null,
                                    Action<ItemGainEffect> onBegin = null,
                                    Action<Effect.Effect.CompleteType> onComplete = null,
                                    Action onFirstArrived = null,
                                    Action onArrived = null)
        {
            EffectSystem.Instance.VipClass(MyInfo.VipClass.Type.ToString(),
                                           count,
                                           startPosition,
                                           endPosition,
                                           scaleTarget,
                                           onComplete,
                                           onFirstArrived,
                                           onArrived);
        }

        private void UpdateOnce(FirstArrivalUpdate update)
        {
            /// 같은 작업을 반복하지 않기 위함
            if (firstArrivalUpdates.Contains(update) == false)
            {
                firstArrivalUpdates.Add(update);

                if (update == FirstArrivalUpdate.UserCore)
                {
                    if (RunAsFake == false)
                    {
                        NetworkSystem.HTTPRequester.UserCore(
                            onComplete: resp => 
                            {
                                UserData userData = resp.user;
                                MyInfo.Booster.Update(userData);
                                MyInfo.VipClass.Update(userData.vip_class);
                            }
                        );
                    }
                    else
                    {
                        FakeHttpRequester.Instance.UserCore(
                            onComplete: resp =>
                            {
                                UserData userData = resp.user;
                                MyInfo.Booster.Update(userData);
                                MyInfo.VipClass.Update(userData.vip_class);
                            }
                        );
                    }
                }

                if (update == FirstArrivalUpdate.SeaStory)
                {
                    NetworkSystem.HTTPRequester.SeaStory(
                        seaID: MyInfo.Ocean.CurrentSeaID,
                        onComplete : resp => {
                            NetworkSystem.HTTPHandler.Do(resp);
                        }
                    );
                }
            }
        }

        private IEnumerator Sync()
        {
            if (SceneSystem.ActiveScene == SceneSystem.LobbyScene)
            {
                if (RewardContains(RewardType.golden)
                    || RewardContains(RewardType.obsidian)
                    || RewardContains(RewardType.s_pickaxe)
                    || RewardContains(RewardType.g_pickaxe))
                {
                    yield return LoadCasinoBonusCoroutine();
                }
            }

            yield break;
        }

        private IEnumerator LoadCasinoBonusCoroutine()
        {
            Popups.ShowLoading(false);
            var casinoBonusReq = NetworkSystem.HTTPRequester.CasinoBonus();
            yield return casinoBonusReq.WaitForResponse();
            Popups.HideLoading();

            if (casinoBonusReq.isSuccess == true)
            {
                NetworkSystem.HTTPHandler.Do(casinoBonusReq.data);
            }
            yield break;
        }

        private CustomYieldInstruction InvokeEffect(RewardType rewardType,
                                                    EffectSystemDelegate method, 
                                                    int count, 
                                                    Vector2 startPosition, 
                                                    Vector2 endPosition, 
                                                    Transform scaleTarget,
                                                    Action _onFirstArrived = null, 
                                                    Action _onArrived = null)
        {
            CustomYield.WaitForComplete effectYield = null;
            if (method != null)
            {
                effectYield = new CustomYield.WaitForComplete();
                method.Invoke(count, 
                              startPosition, 
                              endPosition, 
                              scaleTarget,
                              null,
                              completeType => effectYield.Done(),
                              () =>
                              {
                                  _onFirstArrived?.Invoke();
                                   OnEffectFirstArrived?.Invoke(rewardType);
                              },
                              () =>
                              {
                                  _onArrived?.Invoke();
                                  OnEffectArrived?.Invoke(rewardType);
                              });
            }

            return effectYield;
        }

        public bool RewardContains(RewardType rewardType)
        {
            bool result = false;
            for (int i = 0; i < allItems.Count; i++)
            {
                if (allItems[i].RewardInfo.type == rewardType)
                {
                    result = true;
                    break;
                }
            }

            return result;
        }

        public bool ContainsAdditionalCoin()
        {
            for (int i = 0; i < allItems.Count; i++)
            {
                if (allItems[i].RewardInfo.additionalValue > 0L)
                {
                    return true;
                }
            }

            return false;
        }
    }
}