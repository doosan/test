using Gaga;
using Gaga.Util;
using System;
using TMPro;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Popup
{
    [Flags]
    public enum SimpleRewardItemValueType
    {
        Simple = 1,
        Verbose = 2,
        FishPoint = 4,
    }

    public class SimpleRewardItem : MonoBehaviour
    {
        [SerializeField] private Animator animator;
        [SerializeField] private RectTransform startPosTransform;

        [Header("Reward Icon")]
        [SerializeField] private GameObject random;
        [SerializeField] private GameObject coin;
        [SerializeField] private GameObject pearl;
        [SerializeField] private GameObject ticket;
        [SerializeField] private GameObject golden;
        [SerializeField] private GameObject obsidian;
        [SerializeField] private GameObject xpBooster;
        [SerializeField] private GameObject pearlBooster;
        [SerializeField] private FishRewardDisplay fishRewardDisplay;
        [SerializeField] private GameObject silverPickaxe;
        [SerializeField] private GameObject goldPickaxe;
        [SerializeField] private GameObject weeklyPoint;
        [SerializeField] private GameObject coinGoldPickaxe;
        [SerializeField] private GameObject coinSilverPickaxe;
        [SerializeField] private GameObject mpPoint;
        [SerializeField] private GameObject blitzPoint;
        [SerializeField] private GameObject vipClass;
        [SerializeField] private GameObjectVisibleToggle vipClassVisibleToggle;

        [Header("Frame")]
        [SerializeField] private GameObject bg;

        [Header("Tag")]
        [SerializeField] private GameObject uptoTag;

        [Header("Value")]
        [SerializeField] private TextMeshProUGUI valueText;
        [SerializeField] private Text valueTextSub;

        [Header("Value Icon")]
        [SerializeField] private GameObject starValueIcon;
        [SerializeField] private GameObject coinValueIcon;
        [SerializeField] private GameObject iconOpponentSpace;

        [Header("Additional Value")]
        [SerializeField] private GameObject additionalValueContainer;
        [SerializeField] private TextMeshProUGUI additionalValueText;

        public Vector2 EffectStartPosition
        {
            get
            {
                return startPosTransform != null ?
                       startPosTransform.position : 
                       CachedTransform.position ;
            }
        }
        private RectTransform CachedTransform
        {
            get
            {
                if (cachedTransform == null)
                {
                    cachedTransform = GetComponent<RectTransform>();
                }
                return cachedTransform;
            }
        }
        private RectTransform cachedTransform;

        public RewardInfo RewardInfo
        {
            get;
            private set;
        }
        private RewardType rewardType;
        private long rewardValue;
        private long additionalValue;
        private SimpleRewardItemValueType valueType;
        private VipClassType vipClassType;

        private string rewardValueFormat;
        private string rewardValueStr;

        private string openTrigger;

        public void Reset()
        {
            openTrigger = "";
        }

        public void UpdateContent(RewardInfo rewardInfo, 
                                  SimpleRewardItemValueType valueType = SimpleRewardItemValueType.Simple,
                                  VipClassType vipClassType = VipClassType.none)
        {
            UpdateContent(rewardInfo.type, rewardInfo.value, rewardInfo.additionalValue, valueType, vipClassType);
            RewardInfo = rewardInfo;
        }

        public void UpdateContent(RewardType rewardType, 
                                  long rewardValue, 
                                  long additionalValue = 0, 
                                  SimpleRewardItemValueType valueType = SimpleRewardItemValueType.Simple, 
                                  VipClassType vipClassType = VipClassType.none)
        {
            RewardInfo = null;
            this.rewardType = rewardType;
            this.rewardValue = rewardValue;
            this.additionalValue = additionalValue;
            this.valueType = valueType;
            this.vipClassType = vipClassType;

            UpdateIcon();
            UpdateValue();
        }

        public void EnableBG(bool value)
        {
            if (bg != null)
            {
                bg.SetActive(value);
            }
        }

        private void UpdateIcon()
        {
            if (random != null) random.SetActive(rewardType == RewardType.rand);
            if (coin != null) coin.SetActive(rewardType == RewardType.coin);
            if (pearl != null) pearl.SetActive(rewardType == RewardType.pearl);
            if (ticket != null) ticket.SetActive(rewardType == RewardType.ticket);
            if (golden != null) golden.SetActive(rewardType == RewardType.golden);
            if (obsidian != null) obsidian.SetActive(rewardType == RewardType.obsidian);
            if (xpBooster != null) xpBooster.SetActive(rewardType == RewardType.xp_booster);
            if (pearlBooster != null) pearlBooster.SetActive(rewardType == RewardType.pearl_booster);
            if (fishRewardDisplay != null) fishRewardDisplay.gameObject.SetActive(rewardType == RewardType.fish);
            if (silverPickaxe != null) silverPickaxe.SetActive(rewardType == RewardType.s_pickaxe);
            if (goldPickaxe != null) goldPickaxe.SetActive(rewardType == RewardType.g_pickaxe);
            if (weeklyPoint != null) weeklyPoint.SetActive(rewardType == RewardType.weekly_point);
            if (coinGoldPickaxe != null) coinGoldPickaxe.SetActive(rewardType == RewardType.coin_g_pickaxe);
            if (coinSilverPickaxe != null) coinSilverPickaxe.SetActive(rewardType == RewardType.coin_s_pickaxe);
            if (mpPoint != null) mpPoint.SetActive(rewardType == RewardType.mp_point);
            if (blitzPoint != null) blitzPoint.SetActive(rewardType == RewardType.blitz_point);
            if (vipClass != null)
            {
                bool isVipClassVisible = rewardType == RewardType.vip_point;
                vipClass.SetActive(isVipClassVisible);
                if (isVipClassVisible)
                {
                    vipClassVisibleToggle.TurnOnByNameInMultiple(vipClassType.ToString());
                }
            }

            if (uptoTag != null) uptoTag.SetActive(rewardType == RewardType.coin || rewardType == RewardType.fish);
        }

        public void HideIcon()
        {
            if (random != null) random.SetActive(false);
            if (coin != null) coin.SetActive(false);
            if (pearl != null) pearl.SetActive(false);
            if (ticket != null) ticket.SetActive(false);
            if (golden != null) golden.SetActive(false);
            if (obsidian != null) obsidian.SetActive(false);
            if (xpBooster != null) xpBooster.SetActive(false);
            if (pearlBooster != null) pearlBooster.SetActive(false);
            if (fishRewardDisplay != null) fishRewardDisplay.gameObject.SetActive(false);
            if (silverPickaxe != null) silverPickaxe.SetActive(false);
            if (goldPickaxe != null) goldPickaxe.SetActive(false);
            if (weeklyPoint != null) weeklyPoint.SetActive(false);
            if (coinGoldPickaxe != null) coinGoldPickaxe.SetActive(false);
            if (coinSilverPickaxe != null) coinSilverPickaxe.SetActive(false);
            if (mpPoint != null) mpPoint.SetActive(false);
            if (blitzPoint != null) blitzPoint.SetActive(false);
            if (vipClass != null) vipClass.SetActive(false);
            if (uptoTag != null) uptoTag.SetActive(false);
        }

        private void UpdateValue()
        {
            SetAdditionalValueActive(false);

            // Additional Value Text
            bool isPickaxeCoin = rewardType == RewardType.coin_g_pickaxe
                                 || rewardType == RewardType.coin_s_pickaxe;

            if (additionalValueContainer != null)
            {
                SetAdditionalValueActive(isPickaxeCoin);
                additionalValueText.text = $"x{additionalValue}";
            }

            // Value Icon

            FishRewardDisplay.ValueType fishValueType = RewardValueType();
            bool starIconVisible = rewardType == RewardType.fish 
                                   && fishValueType == FishRewardDisplay.ValueType.PointOnly;
            bool coinIconVisible = isPickaxeCoin;
            if (starValueIcon != null) starValueIcon.SetActive(starIconVisible);
            if (coinValueIcon != null) coinValueIcon.SetActive(coinIconVisible);
            if (iconOpponentSpace != null)
            {
                iconOpponentSpace.SetActive(starIconVisible || coinIconVisible);
            }

            // Value Text
            if (valueText != null
                || valueTextSub != null)
            {
                UpdateValueFormat();
                UpdateValueStr();
                string rewardValueText = string.Format(rewardValueFormat, rewardValueStr);
                if (valueText != null)
                {
                    valueText.text = rewardValueText;
                }
                else if (valueTextSub != null)
                {
                    valueTextSub.text = rewardValueText;
                }
            }

            // Fish
            if (fishRewardDisplay != null && rewardType == RewardType.fish)
            {
                SetAdditionalValueActive(fishValueType == FishRewardDisplay.ValueType.CountOnly);
                fishRewardDisplay.UpdateContent(rewardType, valueText, rewardValue, additionalValueText, additionalValue, fishValueType);
            }
        }

        private FishRewardDisplay.ValueType RewardValueType()
        {
            FishRewardDisplay.ValueType result = FishRewardDisplay.ValueType.PointOnly;
            if (fishRewardDisplay != null)
            {
                result = fishRewardDisplay.GetValueType();
            }

            if (HasValueType(SimpleRewardItemValueType.FishPoint))
            {
                result = FishRewardDisplay.ValueType.PointOnly;
            }
            return result;   
        }

        private void SetAdditionalValueActive(bool isOn)
        {
            if (additionalValueContainer != null)
            {
                additionalValueContainer.SetActive(isOn);
            }
        }

        private bool HasValueType(SimpleRewardItemValueType type)
        {
            return (valueType & type) == type;
        }

        private void UpdateValueFormat()
        {
            rewardValueFormat = rewardType != RewardType.none ? "{0}" : "";

            if (HasValueType(SimpleRewardItemValueType.Verbose))
            {
                switch (rewardType)
                {
                    default:
                        rewardValueFormat = "{0}";
                        break;

                    case RewardType.coin:
                        rewardValueFormat = "{0} COINS";
                        break;

                    case RewardType.pearl:
                        rewardValueFormat = "{0} PEARLS";
                        break;

                    case RewardType.ticket:
                        rewardValueFormat = "{0} TICKETS";
                        break;

                    case RewardType.golden:
                        rewardValueFormat = "{0} GOLDEN CHEST";
                        break;

                    case RewardType.obsidian:
                        rewardValueFormat = "{0} OBSIDIAN CHEST";
                        break;

                    case RewardType.xp_booster:
                        rewardValueFormat = "2x XP BOOST ({0})";
                        break;

                    case RewardType.pearl_booster:
                        rewardValueFormat = "2x PEARL&TICKET BOOST ({0})";
                        break;

                    case RewardType.s_pickaxe:
                        rewardValueFormat = "{0} SILVER PICKAXE";
                        break;

                    case RewardType.g_pickaxe:
                        rewardValueFormat = "{0} GOLD PICKAXE";
                        break;

                    case RewardType.mp_point:
                        rewardValueFormat = "{0} MISSION PASS POINT";
                        break;

                    case RewardType.blitz_point:
                        rewardValueFormat = "{0} AQUA BLITZ POINT";
                        break;

                    case RewardType.vip_point:
                        rewardValueFormat = "{0} VIP POINT";
                        break;
                }
            }
        }

        private void UpdateValueStr()
        {
            if (HasValueType(SimpleRewardItemValueType.Verbose))
            {
                rewardValueStr = StringUtils.ToComma(rewardValue);
            }
            else if (rewardType == RewardType.xp_booster
                     || rewardType == RewardType.pearl_booster)
            {
                rewardValueStr = rewardValue.ToBoosterRewardHM();
            }
            else 
            {
                StringUtils.KMBOption kmbOption = StringUtils.GeneralKMBOption();
                rewardValueStr = StringUtils.ToKMB(rewardValue, kmbOption);
            }
        }

        public void SetOpenTrigger(string openTrigger, float openInterval = 0f, bool allowSameTrigger = true)
        {
            if (animator != null)
            {
                if (allowSameTrigger == true
                    || this.openTrigger != openTrigger)
                {
                    this.openTrigger = openTrigger;

                    CancelInvoke("SetOpenTrigger");
                    if (openInterval > 0f)
                    {
                        Invoke("SetOpenTrigger", openInterval);
                    }
                    else
                    {
                        SetOpenTrigger();
                    }
                }
            }
        }

        private void SetOpenTrigger()
        {
            animator.SetTrigger(openTrigger);
        }

        public void SetCloseTrigger(string closeTrigger)
        {
            if (animator != null)
            {
                animator.SetTrigger(closeTrigger);
            }
        }
    }
}