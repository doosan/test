using UnityEngine;
using UnityEngine.UI;
using TMPro;
using Gaga.Util;
using Underc.User;
using Gaga.UI;
using System;
using Underc.UI;
using System.Collections;
using Gaga;

namespace Underc.Popup
{
    public class RewardViewItem : MonoBehaviour
    {
#pragma warning disable 0649
        [SerializeField] private Animator anim;
        [SerializeField] private RectTransform effectStartPos;

        [Header("Rewards")]
        [SerializeField] private GameObject notFishItem;

        [Space]
        [SerializeField] private GameObjectVisibleToggle rewardVisibleToggle;
        [SerializeField] private GameObjectVisibleToggle vipClassVisibleToggle;

        [Space]
        [SerializeField] private TextMeshProUGUI valueText;
        [SerializeField] private RectTransform additionalVipPoint;
        [SerializeField] private TextMeshProUGUI additionalVipPointText;
        [SerializeField] private GameObjectVisibleToggle additionalVipClassVisibleToggle;

        [Header("Fish")]
        [SerializeField] private GameObject fishItem;
        [SerializeField] private RectTransform fishAdditionalCoin;
        [SerializeField] private TextMeshProUGUI fishAdditionalCoinText;
        [SerializeField] private TextMeshProUGUI fishPointText;

        [Space]
        [SerializeField] private TextMeshProUGUI fishTitle;
        [SerializeField] private Transform fishRoot;
        [SerializeField] private UIDragRotator itemRotator;
        [SerializeField] private Button storyButton;

        [Header("VIP Bonus Badge")]
        [SerializeField] private SetNumberPlayerTM fishAdditionalCoinNumberPlayer;
        [SerializeField] private AnimatorParser openAnimation;

#pragma warning restore 0649

        public RewardData Data 
        { 
            get; 
            private set; 
        }
        private VipClassType vipClassType;

        public event Action<BaseBookInfo, Button> OnClickStory;

        private readonly int TRIGGER_OPEN = Animator.StringToHash("Open");
        private readonly int TRIGGER_COLLECT = Animator.StringToHash("Collect");

        private Vector2 fishRotatorOriginPos;
        private BaseBookInfo fishBook;

        private string valueFormat;
        private string valueStr;

        private void Awake()
        {
            if (storyButton != null)
            {
                storyButton.onClick.AddListener(OnStoryButton);
            }
        }

        private void Clear()
        {
            notFishItem.SetActive(false);
            if (fishItem != null)
            {
                fishItem.SetActive(false);
            }
            if (anim != null)
            {
                anim.ResetTrigger(TRIGGER_OPEN);
                anim.ResetTrigger(TRIGGER_COLLECT);
            }

            fishBook = null;
            Data = null;
            OnClickStory = null;
            vipClassType = VipClassType.none;
        }

        public void Setup(RewardData data, VipClassType vipClassType)
        {
            Clear();

            this.Data = data;
            this.vipClassType = vipClassType;

            if (IsFish() == false)
            {
                rewardVisibleToggle.TurnOnByNameInMultiple(Data.typeStr);
                if (Data.typeStr == RewardData.VIP_POINT)
                {
                    vipClassVisibleToggle.TurnOnByNameInMultiple(vipClassType.ToString());
                }
                UpdateValueText();
            }
            else
            {
                UpdateFishBook();
                UpdateFishTitle();
                UpdateFishModel();
                UpdateFishPoint();
            }
        }

        private void UpdateFishBook()
        {
            int fishID = (int)Data.value;
            Debug.LogFormat("fishID: {0}",fishID);
            fishBook = MyInfo.Ocean.Book.GetBookInfo(SeaItemType.f, fishID);
        }

        private void UpdateFishTitle()
        {
            fishTitle.text = fishBook.Title;
        }

        private void UpdateFishModel()
        {
            var fishModel = fishBook.GetModel(fishBook.Type, fishBook.ID, true);
            foreach (Transform child in fishRoot)
            {
                Destroy(child.gameObject);
            }

            var itemTransform = fishModel.transform;
            itemTransform.SetParent(fishRoot, false);
            itemTransform.ToLayer(fishRoot.gameObject.layer);

            itemRotator.gameObject.SetActive(true);
            itemRotator.Target = itemTransform;
            itemRotator.ResetRotationImmediately();
        }

        private void UpdateFishPoint()
        {
            fishPointText.text = StringUtils.ToComma(fishBook.Point);
        }

        public void Open()
        {
            if (anim != null)
            {
                anim.SetTrigger(TRIGGER_OPEN);
            }

            if (IsFish() == false)
            {
                notFishItem.SetActive(true);
                if (fishItem != null)
                {
                    fishItem.SetActive(false);
                }
                rewardVisibleToggle.TurnOnByNameInMultiple(Data.typeStr);
                if (Data.typeStr == RewardData.VIP_POINT)
                {
                    vipClassVisibleToggle.TurnOnByNameInMultiple(vipClassType.ToString());
                }
                UpdateValueText();
                UpdateAdditionalVipPoint();
            }
            else
            {
                notFishItem.SetActive(false);
                if (fishItem != null)
                {
                    fishItem.SetActive(true);
                }
                itemRotator.Reveal();
                UpdateFishAdditionalReward();
            }
        }

        public IEnumerator WaitForOpen()
        {
            yield return openAnimation.WaitForDuration();
        }

        public void Close()
        {
            if (anim != null)
            {
                anim.SetTrigger(TRIGGER_COLLECT);
            }
        }

        private void UpdateValueText()
        {
            if (valueText != null)
            {
                UpdateValueFormat();
                UpdateValueStr();
                valueText.text = string.Format(System.Globalization.CultureInfo.InvariantCulture, valueFormat, valueStr);
            }
        }

        private void UpdateValueStr()
        {
            switch (Data.typeStr)
            {
                case RewardData.XP_BOOSTER:
                case RewardData.PEARL_TICKET_BOOSTER:
                    valueStr = Data.value.ToBoosterRewardHM();
                    break;

                default:
                    valueStr = StringUtils.ToComma(Data.value);
                    break;
            }
        }

        private void UpdateValueFormat()
        {
            switch (Data.Type)
            {
                case RewardType.coin:
                    valueFormat = "{0} COINS";
                    break;

                case RewardType.pearl:
                    valueFormat = "{0} PEARLS";
                    break;

                case RewardType.ticket:
                    valueFormat = "{0} TICKETS";
                    break;

                case RewardType.golden:
                    valueFormat = "{0} GOLDEN CHEST";
                    break;

                case RewardType.obsidian:
                    valueFormat = "{0} OBSIDIAN CHEST";
                    break;

                case RewardType.xp_booster:
                    valueFormat = "2x XP BOOST ({0})";
                    break;

                case RewardType.pearl_booster:
                    valueFormat = "2x PEARL&TICKET BOOST ({0})";
                    break;

                case RewardType.s_pickaxe:
                    valueFormat = "{0} SILVER PICKAXE";
                    break;

                case RewardType.g_pickaxe:
                    valueFormat = "{0} GOLD PICKAXE";
                    break;

                case RewardType.mp_point:
                    valueFormat = "{0} MISSION PASS POINT";
                    break;

                case RewardType.blitz_point:
                    valueFormat = "{0} AQUA BLITZ POINT";
                    break;

                case RewardType.vip_point:
                    valueFormat = "{0} VIP POINT";
                    break;

                default:
                    valueFormat = "{0}";
                    break;
            }
        }

        private void UpdateAdditionalVipPoint()
        {
            bool showVipPoint = Data.additionalVipPoint > 0L;
            additionalVipPoint.gameObject.SetActive(showVipPoint);
            if (showVipPoint)
            {
                // VIP 레벨업 상황이라면 이미 Type 이 바뀌어 있기 때문에 TypeBefore 사용
                additionalVipClassVisibleToggle.TurnOnByNameInMultiple(MyInfo.VipClass.TypeBefore.ToString());
                additionalVipPointText.text = StringMaker.New()
                                                         .Append(StringUtils.ToComma(Data.additionalVipPoint))
                                                         .Append(" <size=17>POINTS</size>")
                                                         .Build();
            }
        }

        private void OnStoryButton()
        {
            if (OnClickStory != null && fishBook != null)
            {
                OnClickStory.Invoke(fishBook, storyButton);
            }
        }

        private bool IsFish()
        {
            return Data.typeStr == RewardData.FISH;
        }

        private void UpdateFishAdditionalReward()
        {
            bool showAdditionalCoin = Data.additionalCoin > 0L;
            fishAdditionalCoin.gameObject.SetActive(showAdditionalCoin);
            if (showAdditionalCoin)
            {
                fishAdditionalCoinText.text = StringMaker.New()
                                                         .Append(StringUtils.ToComma(Data.additionalCoin))
                                                         .Append(" <size=17>COINS</size>")
                                                         .Build();
            }
        }

        public void ApplyVipBonus()
        {
            if (Data.additionalVipCoin > 0)
            {
                fishAdditionalCoinNumberPlayer.startValue = Data.additionalCoin;
                fishAdditionalCoinNumberPlayer.endValue = Data.additionalCoin + Data.additionalVipCoin;
                fishAdditionalCoinNumberPlayer.Play();
            }
        }

        public Vector3 GetEffectStartPos()
        {
            return effectStartPos.position;
        }

        public Vector3 GetAdditionalCoin_StartPos()
        {
            return fishAdditionalCoin.position;
        }

        public Vector3 GetAdditionalVipPoint_StartPos()
        {
            return additionalVipPoint.position;
        }
    }
}
