using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using Gaga.Popup;
using Underc.Effect;
using Underc.Lobby;
using Underc.Net;
using Underc.UI;
using Underc.User;
using UnityEngine;
using Gaga.Util;
using Gaga.System;
using Gaga.Sound;
using UnityEngine.UI;
using UnityEngine.Serialization;
using Gaga;
using TMPro;
using Underc.Net.Client;

namespace Underc.Popup
{
    public delegate void EffectSystemDelegate(int count,
                                              Vector2 startPosition,
                                              Vector2 endPosition,
                                              Transform scaleTarget = null,
                                              Action<ItemGainEffect> onBegin = null,
                                              Action<Effect.Effect.CompleteType> onComplete = null,
                                              Action onFirstArrived = null,
                                              Action onArrived = null);

    public class RewardViewPopup : PreLoadingPopup
    {
        public enum OpenType
        {
            Normal,
            MysteryBox,
            GoldenChest,
            ObsidianChest,
            None
        }

        public enum OpenButtonType
        {
            NormalButton = 0,
            AdsButton    = 1,
            BuyButton    = 2
        }

        public enum Location
        {
            Normal,
            Purchase
        }

        private readonly int TRIGGER_MYSTERY = Animator.StringToHash("Mystery");
        private readonly int TRIGGER_GOLD = Animator.StringToHash("Gold");
        private readonly int TRIGGER_GOLD_AGAIN = Animator.StringToHash("GoldAgain");
        private readonly int TRIGGER_OBSIDIAN = Animator.StringToHash("Obsidian");
        private readonly int TRIGGER_OBSIDIAN_AGAIN = Animator.StringToHash("ObsidianAgain");
        private readonly int TRIGGER_OPEN = Animator.StringToHash("Open");
        private readonly int TRIGGER_COLLECT = Animator.StringToHash("Collect");

        [SerializeField] private float mysteryDuration = 1f;
        [SerializeField] private float goldDuration = 1f;
        [SerializeField] private float obsidianDuration = 1f;
        [SerializeField] private RectTransform uiRoot = null;
        [SerializeField] private Animator animator = null;
        [SerializeField] private Button closeButton = null;
        [SerializeField] private Button infoButton = null;
        [SerializeField] private GameObject noAdsObject = null;
        [SerializeField] private float noAdsDuration = 4f;

        [Header("RewardItem")]
        [SerializeField] private RectTransform itemPoolRoot = null;
        [SerializeField] private RectTransform itemLayoutGroup = null;
        [SerializeField] private RewardViewItem rewardItemTemplate = null;
        [SerializeField] private float openInterval = 0.2f;

        [Header("StoryView")]
        [SerializeField] private CanvasGroup buttonCanvasGroup = null;
        [SerializeField] private FishStoryView storyView = null;
        [SerializeField] private RectTransform itemHolder = null;
        [SerializeField] private float itemHolderYOnStoriView = 80f;

        [Header("Label")]
        [SerializeField] private Animator labelPurchase = null;

        [Header("Sounds")]
        [SerializeField] private SoundPlayer boxDropSFX = null;
        [SerializeField] private SoundPlayer boxShakeSFX = null;
        [SerializeField] private SoundPlayer boxOpenSFX = null;

        [Header("Open Button")]
        [FormerlySerializedAs("adsOpenButtonToggle")]
        [SerializeField] private GameObjectVisibleToggle openButtonToggle;
        [SerializeField] private Button normalOpenButton;
        [SerializeField] private AdsRewardButton adsOpenButton;
        [SerializeField] private Button buyOpenButton;
        [FormerlySerializedAs("openKeyText")]
        [SerializeField] private TextMeshProUGUI openCountText;
        [SerializeField] private TextMeshProUGUI openPriceText;

        [Header("Vip Bonus Badge")]
        [SerializeField] private RectTransform vipBonusBadgePosition;
        [SerializeField] private Button collectButton;
        [SerializeField] private AnimatorParser collectButtonShowAnimation;

        public bool RunAsFake
        {
            private get;
            set;
        }

        private TopUI topUI;
        private RewardBonusUI bonusUI;
        private VipBonusBadge vipBonusBadge;

        private GameObjectPool<RewardViewItem> itemPool;
        private OpenType openType;
        private Location location;
        private RewardData[] rewardDatas;
        private List<RewardViewItem> items;
        private bool isStoryOpened;
        private Image storyButtonImage;
        private float originItemHolderY;
        private Action onComplete;
        private List<FirstArrivalUpdate> firstArrivalUpdates;

        private Action onReopenClick;

        private StateQueue<RewardViewPopupState> stateQueue;
        private float reopenOffset;

        private bool initOnce;

        protected override void Awake()
        {
            base.Awake();

            Init();
        }

        private void Init()
        {
            if (initOnce == false)
            {
                initOnce = true;

                rewardItemTemplate.gameObject.SetActive(false);
                items = new List<RewardViewItem>();

                storyView.Setup(null, () => HideFishStory());

                originItemHolderY = itemHolder.anchoredPosition.y;

                firstArrivalUpdates = new List<FirstArrivalUpdate>();

                stateQueue = new StateQueue<RewardViewPopupState>(host: this);
            }
        }

        protected override void OnDisable()
        {
            Clear();
            base.OnDisable();
        }

        private void Clear()
        {
            animator.ResetTrigger(TRIGGER_MYSTERY);
            animator.ResetTrigger(TRIGGER_GOLD);
            animator.ResetTrigger(TRIGGER_GOLD_AGAIN);
            animator.ResetTrigger(TRIGGER_OBSIDIAN);
            animator.ResetTrigger(TRIGGER_OBSIDIAN_AGAIN);
            animator.ResetTrigger(TRIGGER_OPEN);
            animator.ResetTrigger(TRIGGER_COLLECT);

            RemoveItems();

            buttonCanvasGroup.interactable = true;
            buttonCanvasGroup.alpha = 1f;

            itemHolder.anchoredPosition = new Vector2(itemHolder.anchoredPosition.x, originItemHolderY);

            if (topUI != null)
            {
                TopUISystem.Instance.Return(topUI);
                topUI = null;
            }

            if (bonusUI != null)
            {
                RewardBonusUISystem.Instance.Return(bonusUI);
                bonusUI = null;
            }

            if (vipBonusBadge != null)
            {
                VipBonusBadgeSystem.Instance.Return(vipBonusBadge);
                vipBonusBadge = null;
            }

            labelPurchase.gameObject.SetActive(false);
            labelPurchase.ResetTrigger(TRIGGER_COLLECT);

            closeButton.gameObject.SetActive(false);
            closeButton.onClick.RemoveListener(OnCloseClick);

            infoButton.gameObject.SetActive(false);

            collectButton.gameObject.SetActive(false);
            collectButton.interactable = false;

            ///
            openButtonToggle.gameObject.SetActive(false);
            /// normal
            normalOpenButton.onClick.RemoveListener(OnReopenClick);
            /// ads
            adsOpenButton.onFinish.RemoveListener(OnReopenClick);
            adsOpenButton.onFail.RemoveListener(OnOpenFail);
            /// buy
            buyOpenButton.onClick.RemoveListener(OnReopenClick);
            OpenButtonsInteractable(true);

            noAdsObject.SetActive(false);
            openCountText.text = "";
        }

        public RewardViewPopup Reset()
        {
            Clear();

            if (itemPool == null)
            {
                itemPool = new GameObjectPool<RewardViewItem>(
                    root: itemPoolRoot.gameObject, 
                    size: 3, 
                    create: () => Instantiate(rewardItemTemplate)
                );
            }

            if (topUI == null)
            {
                topUI = TopUISystem.Instance.Get(uiRoot);
                topUI.Use(TopUiItem.Profile,
                          TopUiItem.Coin,
                          TopUiItem.PearlAndTicket,
                          TopUiItem.Level);
                topUI.Order(TopUiItem.Profile,
                            TopUiItem.Coin,
                            TopUiItem.PearlAndTicket,
                            TopUiItem.Level);
                topUI.Reset();
                topUI.Hide(false);
            }

            if (bonusUI == null)
            {
                bonusUI = RewardBonusUISystem.Instance.Get(uiRoot);
                bonusUI.Reset();
            }

            InitLabel();
            InitItems();

            RewardViewItem item = GetItemContainsVipBonus();
            long vipBonus = 0;
            VipBenefitTableItemInfo tableItemInfo = new VipBenefitTableItemInfo();
            if (item != null)
            {
                vipBonus = item.Data.additionalVipCoin;
                tableItemInfo = item.Data.tableItemInfo;
            }

            if (vipBonus > 0)
            {
                vipBonusBadge = VipBonusBadgeSystem.Instance.Get(vipBonusBadgePosition);
                vipBonusBadge.Setup(targetTransform: item.GetComponent<RectTransform>(),
                                    vipBonus: vipBonus,
                                    tableItemInfo: tableItemInfo);
            }

            //
            normalOpenButton.onClick.AddListener(OnReopenClick);
            
            adsOpenButton.SetMode(AdsRewardButton.ButtonMode.AdsReward);
            adsOpenButton.onFinish.AddListener(OnReopenClick);
            adsOpenButton.onFail.AddListener(OnOpenFail);
            
            buyOpenButton.onClick.AddListener(OnReopenClick);
            
            closeButton.onClick.AddListener(OnCloseClick);
            return this;
        }

        private void InitLabel()
        {
            if (location == Location.Purchase)
            {
                labelPurchase.gameObject.SetActive(true);
            }
            else
            {
                labelPurchase.gameObject.SetActive(false);
            }
        }

        private void InitItems()
        {
            // Debug.LogFormat("rewarDatas count: {0}\n{1}", rewardDatas.Length, rewardDatas.ToEachString());
            VipClassType vipClassType = MyInfo.VipClass.Type;
            for (int i = 0; i < rewardDatas.Length; ++i)
            {
                AddItem(rewardDatas[i], vipClassType);
            }
        }

        private RewardData GetLatestRewardData()
        {
            RewardData result = null;
            if (rewardDatas.Length > 0)
            {
                result = rewardDatas[rewardDatas.Length - 1];
            }
            return result;
        }

        private void AddItem(RewardData data, VipClassType vipClassType)
        {
            RewardViewItem item = itemPool.Get();
            item.transform.SetParent(itemLayoutGroup, false);
            item.Setup(data, vipClassType);
            item.OnClickStory += OpenFishStory;

            items.Add(item);
        }

        private void RemoveItems()
        {
            for (int i = 0; i < items.Count; ++i)
            {
                var item = items[i];
                itemPool.Return(item);
            }

            items.Clear();
        }

        private RewardViewItem GetItemContainsVipBonus()
        {
            RewardViewItem result = null;
            for (int i = 0; i < items.Count; ++i)
            {
                if (items[i].Data.additionalVipCoin > 0L)
                {
                    result = items[i];
                    break;
                }
            }
            return result;
        }

        private void OnCloseClick()
        {
            Close();
        }

        private void OnReopenClick()
        {
            OpenButtonsInteractable(false);

            onReopenClick?.Invoke();
        }

        public void OpenButtonsInteractable(bool value)
        {
            normalOpenButton.interactable = value;
            adsOpenButton.Interactable = value;
            buyOpenButton.interactable = value;
        }

        private void OnOpenFail()
        {
            AddNoAdsState();
        }

        private IEnumerator NoAdsCoroutine()
        {
            if (noAdsObject != null)
            {
                noAdsObject.SetActive(true);
                yield return new WaitForSeconds(noAdsDuration);
                noAdsObject.SetActive(false);
            }

            yield break;
        }

        public void Reopen(RewardData[] rewardDatas)
        {
            this.rewardDatas = rewardDatas;

            Reset();
            reopenOffset = 1f;

            StartCoroutine(OpenCoroutine());
        }

        public void Open(RewardData[] rewardDatas,
                         OpenType openType,
                         Location location,
                         Action onComplete,
                         Action onReopenClick)
        {
            this.rewardDatas = rewardDatas;
            this.openType = openType;
            this.location = location;
            this.onComplete = onComplete;
            this.onReopenClick = onReopenClick;

            reopenOffset = 0f;

            StartLoading();
        }

        protected override IEnumerator OnLoading()
        {
            yield break;
        }

        protected override void OnLoadComplete()
        {
            Reset();
            stateQueue.Reset();

            if (openType != OpenType.Normal)
            {
                /// 상자 보상일 때만 초기화
                ResetBoxSounds();
            }

            StartCoroutine(OpenCoroutine());
        }

        private IEnumerator OpenCoroutine()
        {
            switch (openType)
            {
                case OpenType.Normal:
                    /// 이 외 상자들의 사운드 플레이는 
                    /// 애니메이션 내에서 해당 사운드 컴포넌트가 붙어있는 게임 오브젝트를 켜고 끄는 방식으로 작업되어 있습니다.
                    boxOpenSFX.Play();
                    animator.SetTrigger(TRIGGER_OPEN);
                    yield return null;  /// root 오브젝트가 켜지는 것을 한 프레임 기다림 
                    break;

                case OpenType.MysteryBox:
                    animator.SetTrigger(TRIGGER_MYSTERY);
                    yield return new WaitForSeconds(mysteryDuration);
                    break;

                case OpenType.GoldenChest:
                    animator.SetTrigger(TRIGGER_GOLD);
                    yield return new WaitForSeconds(goldDuration - reopenOffset);
                    break;

                case OpenType.ObsidianChest:
                    animator.SetTrigger(TRIGGER_OBSIDIAN);
                    yield return new WaitForSeconds(obsidianDuration - reopenOffset);
                    break;
            }

            RewardViewItem latestItem = null;
            if (items.Count > 0)
            {
                for (int i = 0; i < items.Count; ++i)
                {
                    if (i > 0) yield return new WaitForSeconds(openInterval);

                    latestItem = items[i];
                    latestItem.Open();
                }
            }
            else
            {
                Close();
            }

            if (vipBonusBadge != null
                && vipBonusBadge.CanOpen == true)
            {
                if (latestItem != null)
                {
                    yield return latestItem.WaitForOpen();
                }

                yield return vipBonusBadge.Show(
                    onVipBonusAdding: () =>
                    {
                        foreach (RewardViewItem item in items)
                        {
                            item.ApplyVipBonus();
                        }
                    }
                );
            }
            
            collectButton.gameObject.SetActive(true);
            collectButton.interactable = true;
            collectButtonShowAnimation.SetTrigger();

            yield break;
        }

        public void Collect()
        {
            StartCoroutine(CollectCoroutine());
        }

        private void AddNoAdsState()
        {
            if (stateQueue.CurrentState != RewardViewPopupState.NoAds)
            {
                stateQueue.Add(RewardViewPopupState.NoAds);
            }
        }

        private IEnumerator CollectCoroutine()
        {
            animator.SetTrigger(TRIGGER_COLLECT);
            labelPurchase.SetTrigger(TRIGGER_COLLECT);

            collectButton.interactable = false;

            yield return ShowUI();
            yield return ThrowItems();

            RewardData rewardData = GetLatestRewardData();
            long openCount = rewardData.openCount;
            bool openAds = rewardData.openAds;
            bool openBuy = rewardData.openBuy;
            string openPrice = StringUtils.ToCurrency(rewardData.openPrice);
            if (openCount > 0)
            {
                ShowOpenButton(openType: OpenButtonType.NormalButton,
                               openCount: StringUtils.ToSingleUnit(openCount));
            }
            else if (openCount == 0
                     && openAds == true)
            {
                ShowOpenButton(openType: OpenButtonType.AdsButton);

                if (adsOpenButton.IsLoaded() == false)
                {
                    AddNoAdsState();
                }
            }
            else if (openCount == 0
                     && openBuy == true)
            {
                ShowOpenButton(openType: OpenButtonType.BuyButton,
                               openPrice: openPrice);
            }
            else
            {
                Close();
            }
        }

        private void ShowOpenButton(OpenButtonType openType,
                                    string openCount = "",
                                    string openPrice = "")
        {
            closeButton.gameObject.SetActive(true);
            infoButton.gameObject.SetActive(this.openType == OpenType.ObsidianChest);
            openButtonToggle.gameObject.SetActive(true);
            openButtonToggle.TurnOnByIndexInMultiple((int)openType);
            openCountText.text = openCount;
            openPriceText.text = openPrice;

            if (this.openType == OpenType.GoldenChest)
            {
                /// 상자 보상일 때만 초기화
                ResetBoxSounds();
                animator.SetTrigger(TRIGGER_GOLD_AGAIN);
            }
            else if (this.openType == OpenType.ObsidianChest)
            {
                /// 상자 보상일 때만 초기화
                ResetBoxSounds();
                animator.SetTrigger(TRIGGER_OBSIDIAN_AGAIN);
            }
        }

        private IEnumerator ShowUI()
        {
            if (SetTopUI() == true)
            {
                topUI.Show(true);
            }

            if (SetBonusUI() == true)
            {
                bonusUI.Show();
            }

            yield return new WaitForSeconds(0.3f);
        }

        private bool SetTopUI()
        {
            topUI.UseLevel = RewardContains(RewardData.XP_BOOSTER);
            topUI.UseSecondaryCurrencies = RewardContains(RewardData.PEARL) || RewardContains(RewardData.TICKET) || RewardContains(RewardData.PEARL_TICKET_BOOSTER);
            topUI.UseCoin = RewardContains(RewardData.COIN) || RewardContainsAdditionalCoin();
            topUI.UseProfile = RewardContains(RewardData.VIP_POINT) || RewardContainsAdditionalVipPoint();
            topUI.UpdateBG();

            return topUI.UseLevel || topUI.UseSecondaryCurrencies || topUI.UseCoin || topUI.UseProfile || topUI.UseShopButton;
        }

        private bool SetBonusUI()
        {
            bonusUI.Setup(obsidianChestVisible: RewardContains(RewardData.OBSIDIAN),
                          goldenChestVisible: RewardContains(RewardData.GOLDEN),
                          clamHarvestVisible: RewardContains(RewardData.SILVER_PICKAXE) || RewardContains(RewardData.GOLD_PICKAXE),
                          gotoSeaVisible: RewardContains(RewardData.FISH));

            return bonusUI.IsActive;
        }

        public bool RewardContainsAdditionalVipPoint()
        {
            for (int i = 0; i < items.Count; ++i)
            {
                if (items[i].Data.additionalVipPoint > 0L)
                {
                    return true;
                }
            }
            return false;
        }

        public bool RewardContainsAdditionalCoin()
        {
            for (int i = 0; i < items.Count; ++i)
            {
                if (items[i].Data.additionalCoin > 0L)
                {
                    return true;
                }
            }
            return false;
        }

        public bool RewardContains(string rewardType)
        {
            bool result = false;
            for (int i = 0; i < items.Count; ++i)
            {
                if (items[i].Data.typeStr == rewardType)
                {
                    result = true;
                    break;
                }
            }
            return result;
        }

        private IEnumerator ThrowItems()
        {
            EffectSystemDelegate method = null;
            int count = 15;
            Vector2 startPosition = itemLayoutGroup.position;
            Vector2 endPosition = Vector2.zero;
            Action onFirstArrived = null;
            Action onArrived = null;
            Transform scaleTarget = null;

            firstArrivalUpdates.Clear();
            List<CustomYieldInstruction> effectYields = new List<CustomYieldInstruction>();
            for (int i = 0; i < items.Count; ++i)
            {
                RewardViewItem item = items[i];

                startPosition = item.GetEffectStartPos();
                //string rewardTypeStr = item.Data.typeStr;
                RewardType rewardType = item.Data.Type;
                long rewardValue = item.Data.value;
                long additionalCoin = item.Data.additionalCoin;
                long additionalVipCoin = item.Data.additionalVipCoin;
                long additionalVipPoint = item.Data.additionalVipPoint;

                switch (rewardType)
                {
                    case RewardType.coin:
                        method = EffectSystem.Instance.Coin;
                        count = 15;
                        scaleTarget = topUI.GetCoinIcon();
                        endPosition = topUI.GetCoinIconPosition();
                        onFirstArrived = () => MyInfo.Coin += rewardValue;
                        onArrived = () => topUI.CoinIconAnimation();
                        break;

                    case RewardType.pearl:
                        method = EffectSystem.Instance.Pearl;
                        count = 15;
                        scaleTarget = topUI.GetPearlIcon();
                        endPosition = topUI.GetPearlIconPosition();
                        onFirstArrived = () => MyInfo.Pearl += rewardValue;
                        onArrived = () => topUI.PearlIconAnimation();
                        break;

                    case RewardType.ticket:
                        method = EffectSystem.Instance.Ticket;
                        count = 15;
                        scaleTarget = topUI.GetTicketIcon();
                        endPosition = topUI.GetTicketIconPosition();
                        onFirstArrived = () => MyInfo.Ticket += rewardValue;
                        onArrived = () => topUI.TicketIconAnimation();
                        break;

                    case RewardType.golden:
                        method = EffectSystem.Instance.Light;
                        count = 1;
                        endPosition = bonusUI.BottomUI.Golden.CachedTransform.position;
                        long nextGoldenKey = MyInfo.CasinoBonus.GoldenKey + rewardValue;
                        onFirstArrived = () =>
                        {
                            MyInfo.CasinoBonus.UpdateGoldenKey(nextGoldenKey);
                            bonusUI.BottomUI.Golden.UpdateContent();
                        };
                        break;

                    case RewardType.obsidian:
                        method = EffectSystem.Instance.Light;
                        count = 1;
                        endPosition = bonusUI.BottomUI.Obsidian.CachedTransform.position;
                        long nextObsidianKey = MyInfo.CasinoBonus.ObsidianKey + rewardValue;
                        onFirstArrived = () =>
                        {
                            MyInfo.CasinoBonus.UpdateObsidianKey(nextObsidianKey);
                            bonusUI.BottomUI.Obsidian.UpdateContent();
                        };
                        break;

                    case RewardType.xp_booster:
                        method = EffectSystem.Instance.Light;
                        count = 1;
                        endPosition = topUI.GetLevelPosition();
                        onFirstArrived = () => UpdateOnce(FirstArrivalUpdate.UserCore);
                        break;

                    case RewardType.pearl_booster:
                        method = EffectSystem.Instance.Light;
                        count = 1;
                        endPosition = topUI.GetSecondaryCurrenciesPosition();
                        onFirstArrived = () => UpdateOnce(FirstArrivalUpdate.UserCore);
                        break;

                    case RewardType.fish:
                        method = EffectSystem.Instance.Light;
                        count = 1;
                        endPosition = bonusUI.BottomUI.GotoSea.CachedTransform.position;
                        onFirstArrived = () => UpdateOnce(FirstArrivalUpdate.SeaStory);
                        break;

                    case RewardType.s_pickaxe:
                        method = EffectSystem.Instance.SilverPickax;
                        count = (int)rewardValue;
                        endPosition = bonusUI.BottomUI.MissionIconManager.CachedTransform.position;
                        onFirstArrived = () =>
                        {
                            int nextPickax = MyInfo.ClamHarvest.DisplayInfo.pickax + (int)rewardValue;
                            MyInfo.ClamHarvest.UpdateClamHarvestDisplayInfo(nextPickax);
                            bonusUI.BottomUI
                                   .MissionIconManager
                                   .GetIcon(MissionIconType.ClamHarvest)
                                   .UpdateInfo(isProgressive: false);
                        };
                        break;

                    case RewardType.g_pickaxe:
                        method = EffectSystem.Instance.GoldPickax;
                        count = (int)rewardValue;
                        endPosition = bonusUI.BottomUI.MissionIconManager.CachedTransform.position;
                        onFirstArrived = () =>
                        {
                            int nextPickax = MyInfo.ClamHarvest.DisplayInfo.pickax + (int)rewardValue;
                            MyInfo.ClamHarvest.UpdateClamHarvestDisplayInfo(nextPickax);
                            bonusUI.BottomUI
                                   .MissionIconManager
                                   .GetIcon(MissionIconType.ClamHarvest)
                                   .UpdateInfo(isProgressive: false);
                        };
                        break;

                    case RewardType.vip_point:
                        method = VipClassEffect;
                        count = (int)rewardValue;
                        endPosition = topUI.GetProfileButtonPosition();
                        scaleTarget = topUI.GetProfileIcon();
                        onFirstArrived = () =>
                        {
                            long nextVipPoint = MyInfo.VipClass.Xp + rewardValue;
                            if (nextVipPoint > MyInfo.VipClass.NextXp)
                            {
                                UpdateOnce(FirstArrivalUpdate.UserCore);
                            }
                        };
                        onArrived = () => topUI.ProfileAnimation();
                        break;

                    default:
                        Debug.LogFormat($"==== ThrowEffectToUI() : {rewardType} 에 대한 처리가 없습니다.");
                        break;
                }

                CustomYieldInstruction collectYield = InvokeCollect(method, count, startPosition, endPosition, scaleTarget, onFirstArrived, onArrived);
                effectYields.Add(collectYield);

                if (additionalCoin > 0L)
                {
                    method = EffectSystem.Instance.Coin;
                    count = 15;
                    startPosition = item.GetAdditionalCoin_StartPos();
                    endPosition = topUI.GetCoinIconPosition();
                    scaleTarget = topUI.GetCoinIcon();
                    onFirstArrived = () => MyInfo.Coin += (additionalCoin + additionalVipCoin);
                    onArrived = () => topUI.CoinIconAnimation();
                    effectYields.Add(InvokeCollect(method, count, startPosition, endPosition, scaleTarget, onFirstArrived, onArrived));
                }

                if (additionalVipPoint > 0L)
                {
                    method = VipClassEffect;
                    count = Mathf.Min((int)additionalVipPoint, 15);
                    startPosition = item.GetAdditionalCoin_StartPos();
                    endPosition = topUI.GetProfileButtonPosition();
                    scaleTarget = topUI.GetProfileIcon();
                    onFirstArrived = null;
                    onArrived = () => topUI.ProfileAnimation();
                    effectYields.Add(InvokeCollect(method, count, startPosition, endPosition, scaleTarget, onFirstArrived, onArrived));
                }

                item.Close();
            }

            vipBonusBadge?.Hide();
            yield return new WaitUntil(() =>
            {
                foreach (CustomYieldInstruction effectYield in effectYields)
                {
                    if (effectYield != null && effectYield.keepWaiting)
                    {
                        return false;
                    }
                }
                return true;
            });

            topUI.Hide(true);
            bonusUI.Hide();

            yield break;
        }

        private void VipClassEffect(int count,
                                    Vector2 startPosition,
                                    Vector2 endPosition,
                                    Transform scaleTarget = null,
                                    Action<ItemGainEffect> onBegin = null,
                                    Action<Effect.Effect.CompleteType> onComplete = null,
                                    Action onFirstArrived = null,
                                    Action onArrived = null)
        {
            // VIP 레벨업 상황이라면 이미 Type 이 바뀌어 있기 때문에 TypeBefore 사용
            EffectSystem.Instance.VipClass(MyInfo.VipClass.TypeBefore.ToString(),
                                           count,
                                           startPosition,
                                           endPosition,
                                           scaleTarget,
                                           onComplete,
                                           onFirstArrived,
                                           onArrived);
        }

        // 똑같은 데이터 업데이트 로직은 한 번만 수행하기 위함
        private void UpdateOnce(FirstArrivalUpdate update)
        {
            if (firstArrivalUpdates.Contains(update) == false)
            {
                firstArrivalUpdates.Add(update);

                if (update == FirstArrivalUpdate.UserCore)
                {
                    Action<UserCoreResponse> _OnComplete = (UserCoreResponse resp) => {
                        MyInfo.Booster.Update(resp.user);
                        MyInfo.VipClass.Update(resp.user.vip_class);
                    };

                    if (RunAsFake == false)
                    {
                        NetworkSystem.HTTPRequester.UserCore(_OnComplete);
                    }
                    else
                    {
                        FakeHttpRequester.Instance.UserCore(_OnComplete);
                    }
                }

                if (update == FirstArrivalUpdate.SeaStory)
                {
                    NetworkSystem.HTTPRequester.SeaStory(
                        seaID: MyInfo.Ocean.CurrentSeaID,
                        onComplete: resp => {
                            NetworkSystem.HTTPHandler.Do(resp);
                        }
                    );
                }
            }
        }

        private CustomYieldInstruction InvokeCollect(EffectSystemDelegate method, 
                                                     int count, 
                                                     Vector2 startPos, 
                                                     Vector2 endPos, 
                                                     Transform scaleTarget = null,
                                                     Action onFirstArrived = null, 
                                                     Action onArrived = null)
        {
            CustomYield.WaitForComplete customYield = null;
            if (method != null)
            {
                customYield = new CustomYield.WaitForComplete();
                method.Invoke(
                    count, 
                    startPos, 
                    endPos, 
                    scaleTarget,
                    null,
                    etype => customYield.Done(), 
                    onFirstArrived, 
                    onArrived
                );
            }
            else if (onFirstArrived != null)
            {
                onFirstArrived.Invoke();
            }

            return customYield;
        }

        private void OpenFishStory(BaseBookInfo bookInfo, Button storyButton)
        {
            if (isStoryOpened == true) return;

            isStoryOpened = true;
            storyButtonImage = storyButton.GetComponent<Image>();
            storyButtonImage.DOKill();
            storyButtonImage.DOFade(0f, .295f)
                            .SetEase(Ease.OutQuint);

            storyView.Show(bookInfo.ID, bookInfo.Story);

            buttonCanvasGroup.interactable = false;
            buttonCanvasGroup.DOFade(0f, 0.2f);

            itemHolder.DOAnchorPosY(itemHolderYOnStoriView, 0.3f);
        }

        private void HideFishStory(bool immediately = false)
        {
            if (isStoryOpened == false) return;

            isStoryOpened = false;
            storyButtonImage.DOKill();
            storyButtonImage.DOFade(1f, .295f)
                            .SetEase(Ease.OutQuint);
            storyButtonImage = null;

            storyView.Hide(immediately);

            buttonCanvasGroup.interactable = true;
            buttonCanvasGroup.DOFade(1f, 0.2f);

            itemHolder.DOAnchorPosY(originItemHolderY, 0.3f);
        }

        public override bool CanBack()
        {
            return collectButton.interactable == true;
        }

        public override void GoBack()
        {
            Collect();
        }

        public override void Close()
        {
            HideFishStory(true);

            if (RewardContains(RewardData.GOLDEN)
                || RewardContains(RewardData.OBSIDIAN)
                || RewardContains(RewardData.FISH)
                || RewardContains(RewardData.SILVER_PICKAXE)
                || RewardContains(RewardData.GOLD_PICKAXE))
            {
                stateQueue.Add(RewardViewPopupState.LoadCasinoBonus);
            }

            TryExit();
            stateQueue.Add(RewardViewPopupState.Release);
        }

        private IEnumerator LoadCasinoBonusCoroutine()
        {
            Popups.ShowLoading(false);
            var casinoBonusReq = NetworkSystem.HTTPRequester.CasinoBonus();
            yield return casinoBonusReq.WaitForResponse();
            Popups.HideLoading();

            if (casinoBonusReq.isSuccess == true)
            {
                NetworkSystem.HTTPHandler.Do(casinoBonusReq.data);
            }
            yield break;
        }

        private bool TryExit()
        {
            bool canExit = stateQueue.CurrentState == RewardViewPopupState.NoAds
                           || stateQueue.CurrentState == RewardViewPopupState.None;
            if (canExit == true)
            {
                stateQueue.Reset();
            }
            return canExit;
        }

        private IEnumerator ReleaseCoroutine()
        {
            onComplete?.Invoke();
            base.Close();

            yield break;
        }

        private void ResetBoxSounds()
        {
            boxDropSFX.gameObject.SetActive(false);
            boxShakeSFX.gameObject.SetActive(false);
            boxOpenSFX.gameObject.SetActive(false);

            boxDropSFX.triggerType = AudioTriggerType.OnEnable;
            boxShakeSFX.triggerType = AudioTriggerType.OnEnable;
            boxOpenSFX.triggerType = AudioTriggerType.OnEnable;
        }

        public void OnInfoButtonClick()
        {
            AppService.OpenEpicChestProbabilityTable();
        }
    }

    public enum RewardViewPopupState
    {
        None,
        NoAds,
        LoadCasinoBonus,
        Release,
    }
}
