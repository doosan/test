using System;
using System.Collections.Generic;
using Gaga.System;
using Gaga.Popup;
using Gaga.Util;
using Underc.Net;
using Underc.UI;
using Underc.User;
using Underc.Util;
using UnityEngine;
using System.Collections;

namespace Underc.Popup
{
    public static class Popups
    {
        public const float DEFAULT_BACKGROUND_ALPHA = 0.8f;

        public const string RESOURCES_ERROR = "ErrorPopup";
        public const string RESOURCES_WARNING = "WarningPopup";

        private const string ERROR_CODE_SESSID = "invalid sessid";
        private const string ERROR_MSG_SESSID = "Your session has expired.";

        public const string ID_LEVELUP_BENEFIT = "LevelUpBenefitPopup";
        public const string AB_LEVELUP_BENEFIT = "popup_levelupbenefit";

        public const string ID_PAYTABLE = "PaytablePopup";
        public const string ID_PAYTABLE_PORTRAIT = "PaytablePopupPortrait";
        public const string AB_PAYTABLE = "popup_paytable";

        public const string ID_NEEDMORE = "NeedMorePopup";
        public const string AB_NEEDMORE = "popup_needmore";

        public const string ID_SERVERLIST = "ServerListPopup";
        public const string AB_SERVERLIST = "popup_serverlist";

        public const string ID_FISHSTORE = "FishStorePopup";
        public const string AB_FISHSTORE = "popup_fishstore";

        public const string ID_INVENTORY = "InventoryPopup";
        public const string ID_INVENTORY_HOWTO = "InventoryHowtoPopup";
        public const string AB_INVENTORY = "popup_inventory";

        public const string ID_STORYMAP = "StoryMapPopup";
        public const string AB_STORYMAP = "popup_storymap";

        public const string ID_NEWSEA = "NewSeaPopup";
        public const string AB_NEWSEA = "popup_newsea";

        public const string ID_UNLOCKSEA = "UnlockSeaPopup";
        public const string AB_UNLOCKSEA = "popup_unlocksea";

        public const string ID_SEAMISSION_CLEAR = "SeaMissionClearPopup";
        public const string AB_SEAMISSION_CLEAR = "popup_seamissionclear";

        public const string ID_UNIQUESWIMMER_WARNING = "UniqueWarningPopup";
        public const string AB_UNIQUESWIMMER_WARNING = "popup_uniquewarning";

        public const string ID_QUESTCLAM = "QuestClamPopup";
        public const string AB_QUESTCLAM = "popup_questclam";

        public const string ID_SEAMISSION = "SeaMissionPopup";

        public const string ID_GAME_PROFILE = "GameProfilePopup";
        public const string AB_GAME_PROFILE = "popup_game_profile";

        public const string ID_GAME_SETTING = "GameSettingPopup";
        public const string AB_GAME_SETTING = "popup_game_setting";

        public const string ID_SHOP = "ShopPopup";
        public const string ID_SHOP_PORTRAIT = "ShopPopupPortrait";
        public const string AB_SHOP = "popup_shop";

        public const string ID_PURCHASEFAIL = "PurchaseFailPopup";
        public const string AB_PURCHASEFAIL = "popup_purchasefail";

        public const string ID_MISSION_PASS = "MissionPassPopup";
        public const string AB_MISSION_PASS = "popup_missionpass";

        public const string ID_MISSION_PASS_INFO = "MissionPassInfoPopup";
        public const string AB_MISSION_PASS_INFO = "popup_missionpassinfo";

        public const string ID_MISSION_PASS_COLLECTALL = "MissionPassCollectAllPopup";
        public const string AB_MISSION_PASS_COLLECTALL = "popup_missionpasscollectall";

        public const string ID_MISSION_PASS_REWARD = "MissionPassRewardPopup";
        public const string AB_MISSION_PASS_REWARD = "popup_missionpassreward";

        public const string ID_MISSION_PASS_REWARD_FREE = "MissionPassFreeRewardPopup";
        public const string AB_MISSION_PASS_REWARD_FREE = "popup_missionpassfreereward";

        public const string ID_MISSION_PASS_SEEMORE = "MissionPassSeeMorePopup";
        public const string AB_MISSION_PASS_SEEMORE = "popup_missionpassseemore";

        public const string ID_MISSION_PASS_LEVEL_UP = "MissionPassLevelUpPopup";
        public const string AB_MISSION_PASS_LEVEL_UP = "popup_missionpass_levelup";

        public const string ID_MISSION_PASS_PURCHASE = "MissionPassPurchasePopup";
        public const string AB_MISSION_PASS_PURCHASE = "popup_missionpasspurchase";

        public const string ID_MISSION_PASS_PURCHASE_COMPLETE = "MissionPassPurchaseCompletePopup";
        public const string AB_MISSION_PASS_PURCHASE_COMPLETE = "popup_missionpasspurchasecom";

        public const string ID_MISSION_PASS_INCLUDES = "MissionPassIncludesPopup";
        public const string AB_MISSION_PASS_INCLUDES = "popup_missionpassincludes";

        public const string ID_MISSION_PASS_OPEN = "MissionPassOpenPopup";
        public const string AB_MISSION_PASS_OPEN = "popup_missionpass_open";

        public const string ID_CHALLENGE_COMPLETE = "GameChallengeCompletePopup";
        public const string AB_CHALLENGE_COMPLETE = "popup_challenge_complete";

        public const string ID_COINBUBBLE = "CoinBubblePopup";
        public const string AB_COINBUBBLE = "popup_coinbubble";

        public const string ID_ADSREWARD = "AdsRewardPopup";
        public const string AB_ADSREWARD = "popup_adsreward";

        public const string ID_INBOX = "InboxPopup";
        public const string AB_INBOX = "popup_inbox";

        public const string ID_EXITAPP = "ExitAppPopup";
        public const string AB_EXITAPP = "popup_exit";

        public const string ID_BLOCKED = "BlockedUserPopup";
        public const string AB_BLOCKED = "popup_blocked";

        public const string ID_REWARDVIEW = "RewardViewPopup";
        public const string AB_REWARDVIEW = "popup_rewardview";

        public const string ID_WELCOMEBACK = "WelcomeBackPopup";
        public const string AB_WELCOMEBACK = "popup_welcomeback";

        public const string ID_IOS_NOTI_SETTING = "IosNotiSettingPopup";
        public const string AB_IOS_NOTI_SETTING = "popup_ios_noti_setting";

        public const string ID_IOS_ATT_CONSENT = "IosAttConsentPopup";
        public const string AB_IOS_ATT_CONSENT = "popup_ios_att_consent";

        public const string ID_IOS_NOTI_CONSENT = "IosNotiConsentPopup";
        public const string AB_IOS_NOTI_CONSENT = "popup_ios_noti_consent";

        public const string ID_ACCOMPLISHED = "AccomplishedPopup";
        public const string AB_ACCOMPLISHED = "popup_accomplished";

        public const string ID_RATEUS = "RateusPopup";
        public const string AB_RATEUS = "popup_rateus";

        public const string ID_ADMIN_NOTICE = "AdminNoticePopup";
        public const string ID_ADMIN_EVENT = "AdminEventPopup";
        public const string AB_ADMIN = "popup_admin";

        public const string ID_DELETE_ACCOUNT = "DeleteAccountPopup";
        public const string ID_RESTORE_ACCOUNT = "RestoreAccountPopup";
        public const string AB_DELETE_ACCOUNT = "popup_delete_account";

        public const string ID_APP_UPDATE = "AppUpdatePopup";
        public const string AB_APP_UPDATE = "popup_update";

        public const string ID_MAINTENANCE = "MaintenancePopup";
        public const string AB_MAINTENANCE = "popup_maintenance";

        public const string ID_SOCIAL = "SocialPopup";
        public const string AB_SOCIAL = "popup_social";

        public const string ID_GAMEBET = "GameBetPopup";
        public const string AB_GAMEBET = "popup_gamebet";

        public const string ID_DAILYBONUS = "DailyBonusPopup";
        public const string AB_DAILYBONUS = "popup_dailybonus";

        public const string ID_BOOSTER = "BoosterPopup";
        public const string AB_BOOSTER = "popup_booster";

        public const string ID_HIGHLIGHT = "HighlightPopup";
        public const string AB_HIGHLIGHT = "popup_highlight";

        public const string ID_OFFER_ALLIN = "OfferAllinPopup";
        public const string ID_OFFER_BIGWIN = "OfferBigwinPopup";
        public const string ID_OFFER_EVENT = "OfferEventPopup";
        public const string ID_OFFER_OCEAN = "OfferOceanPopup";
        public const string ID_OFFER_STARTER = "OfferStarterPopup";
        public const string ID_OFFER_SWIMMER = "OfferSwimmerPopup";
        public const string AB_OFFER = "popup_offer";

        public const string ID_COUPON_1 = "CouponPopup_1";
        public const string AB_COUPON_1 = "popup_coupon_1";

        public const string ID_COUPON_2 = "CouponPopup_2";
        public const string AB_COUPON_2 = "popup_coupon_2";

        public const string ID_FISHSTOREINFO = "FishStoreInfoPopup";
        public const string AB_FISHSTOREINFO = "popup_fishstoreinfo";

        public const string ID_SEASTORYINFO = "SeaStoryInfoPopup";
        public const string AB_SEASTORYINFO = "popup_seastoryinfo";

        public const string ID_SEASTORYCOLLECTION = "SeaStoryCollectionPopup";
        public const string AB_SEASTORYCOLLECTION = "popup_seastorycollection";

        public const string ID_BACKTOLOBBY = "BackToLobbyPopup";
        public const string AB_BACKTOLOBBY = "popup_backtolobby";

        public const string ID_TOTALGROWTH = "TotalGrowthPopup";
        public const string ID_TOTALGROWTH_PORTRAIT = "TotalGrowthPopupPortrait";
        public const string AB_TOTALGROWTH = "popup_totalgrowth";

        public const string ID_SHOPGROWTH = "ShopGrowthPopup";
        public const string AB_SHOPGROWTH = "popup_shopgrowth";

        public const string ID_CLAMHARVESTINFO = "ClamHarvestInfoPopup";
        public const string AB_CLAMHARVESTINFO = "popup_clamharvestinfo";

        public const string ID_DAILYMISSION_REWARD = "DailyMissionRewardPopup";
        public const string AB_DAILYMISSION_REWARD = "popup_dailymission_reward";

        public const string ID_DAILYQUEST_UNLOCK = "DailyQuestUnlockPopup";
        public const string AB_DAILYQUEST_UNLOCK = "popup_dailyquest_unlock";

        public const string ID_VIP_BENEFIT = "VipBenefitPopup";
        public const string AB_VIP_BENEFIT = "popup_vip_benefit";

        public const string ID_VIP_LEVELUP = "VipLevelUpPopup";
        public const string AB_VIP_LEVELUP = "popup_vip_levelup";

        public const string ID_VIP_OPEN = "VipOpenPopup";
        public const string AB_VIP_OPEN = "popup_vip_open";

        public const string ID_VIP_RESET_NOTICE = "VipResetNoticePopup";
        public const string AB_VIP_RESET_NOTICE = "popup_vip_reset_notice";

        public const string ID_VIP_RESET_DETAIL = "VipResetDetailPopup";
        public const string AB_VIP_RESET_DETAIL = "popup_vip_reset_detail";

        public const string ID_VIP_RESET_KICKOFF = "VipResetKickOffPopup";
        public const string AB_VIP_RESET_KICKOFF = "popup_vip_reset_kickoff";

        public const string ID_AQUABLITZ_INFO = "AquaBlitzInfoPopup";
        public const string AB_AQUABLITZ_INFO = "popup_aquablitz_info";

        public const string ID_AQUABLITZ_REWARD = "AquaBlitzRewardPopup";
        public const string AB_AQUABLITZ_REWARD = "popup_aquablitz_reward";

        private static LoadingIndicator cachedLoadingIndicator;
        public static void ShowLoading(bool blocksRaycasts = true)
        {
            //Debug.Log("==== ShowLoading");
            PopupSystem.Instance.ShowLoading(blocksRaycasts);
        }

        public static void HideLoading()
        {
            //Debug.Log("==== HideLoading");
            PopupSystem.Instance.HideLoading();
        }

        public static bool IsLoading()
        {
            return PopupSystem.Instance.IsLoading();
        }

        public static PopupObject<ErrorPopup> NetworkError(ErrorPopup.ActionType actionType = ErrorPopup.ActionType.None,
                                                           Action onClose = null)
        {
            return Error("Unstable Network Connection.", actionType, onClose);
        }

        // errorMsg로 actionType을 자동으로 정의함.
        // errorMsg 자동정의에 실패했을때를 대비해 actionType을 추가로 받는다.
        public static PopupObject<ErrorPopup> Error(string errorMsg, 
                                                    ErrorPopup.ActionType fallbackActionType = ErrorPopup.ActionType.None,
                                                    Action onClose = null)
        {
            if (errorMsg == ERROR_CODE_SESSID)
            {
                errorMsg = ERROR_MSG_SESSID;
                fallbackActionType = ErrorPopup.ActionType.Intro;
            }

            return PopupSystem.Instance.Open<ErrorPopup>(RESOURCES_ERROR)
                                       .OnInitialize(p => p.Initialize(errorMsg, fallbackActionType, onClose))
                                       .Async().Cache();
        }

        public static PopupObject<WarningPopup> Warning(string message,
                                                        WarningPopup.ActionType actionType = WarningPopup.ActionType.None,
                                                        WarningPopup.TitleType titleType = WarningPopup.TitleType.Basic,
                                                        string titleMessage = "",
                                                        bool useCloseButton = true,
                                                        Action onOK = null,
                                                        Action onClose = null,
                                                        string okText = "OK")
        {
            return PopupSystem.Instance.Open<WarningPopup>(RESOURCES_WARNING)
                                       .OnInitialize(p => p.Alert(message, actionType, titleType, titleMessage, useCloseButton, onOK, onClose, okText))
                                       .Async().Cache();
        }

        public static PopupObject<WarningPopup> WarningConfirm(string message,
                                                               string titleMessage = "",
                                                               bool useCloseButton = false,
                                                               Action onOK = null,
                                                               Action onNO = null,
                                                               Action onClose = null,
                                                               string okText = "YES",
                                                               string noText = "NO")
        {
            return PopupSystem.Instance.Open<WarningPopup>(RESOURCES_WARNING)
                                       .OnInitialize(p => p.Confirm(message, titleMessage, useCloseButton, onOK, onNO, onClose, okText, noText))
                                       .Async().Cache();
        }

        public static PopupObject<WarningPopup> MoveToManagePopup()
        {
            var message = "Would you like to\ncheck the fish you just got\nin the SEA AQUARIUM?";
            Action moveToMange = () =>
            {
                MyInfo.Ocean.SetPopupInPending(PopupInPending.Manage);
                var gameManager = GameObject.FindObjectOfType<Underc.Game.GameManager>();
                if (gameManager != null)
                {
                    PopupSystem.Instance.Clear(true, false);
                    gameManager.GameUI.GoLobby(Underc.Scene.SceneSystem.LOBBY_STATE_INDEX_MAIN);
                    return;
                }

                var lobbyManager = GameObject.FindObjectOfType<Underc.Lobby.LobbyManager>();
                if (lobbyManager != null)
                {
                    PopupSystem.Instance.Clear(true, false);

                    if (lobbyManager.CurrentState == Underc.Lobby.LobbyManager.State.ExecuteGame)
                    {
                        lobbyManager.GoBack();
                    }
                }
            };

            return WarningConfirm(message: message, titleMessage: string.Empty, useCloseButton: false, onOK: moveToMange);
        }

        public static PopupObject<LevelUpBenefitPopup> LevelUpBenefit(int level, List<int> fishList)
        {
            return PopupSystem.Instance.Open<LevelUpBenefitPopup>(Address.CDN_ASSETBUNDLES, AB_LEVELUP_BENEFIT, ID_LEVELUP_BENEFIT).OnInitialize(p => p.Initialize(level, fishList));
        }

        public static PopupObject<PaytablePopup> Paytable(string slotID)
        {
            var popupName = ScreenSystem.IsLandscape ? ID_PAYTABLE : ID_PAYTABLE_PORTRAIT;
            return PopupSystem.Instance.Open<PaytablePopup>(Address.CDN_ASSETBUNDLES, AB_PAYTABLE, popupName).OnInitialize(p => p.Initialize(slotID));
        }

        public static PopupObject<NeedMorePopup> NeedMore(NeedMorePopup.ResourceType resourceType, Action letParentClose = null)
        {
            return PopupSystem.Instance.Open<NeedMorePopup>(Address.CDN_ASSETBUNDLES, AB_NEEDMORE, ID_NEEDMORE)
                                       .OnInitialize(p => p.Initialize(resourceType, letParentClose));
        }

#if DEV
        public static PopupObject<ServerListPopup> ServerList()
        {
            return PopupSystem.Instance.Open<ServerListPopup>(Net.Address.CDN_ASSETBUNDLES, AB_SERVERLIST, ID_SERVERLIST)
                                       .OnInitialize(p => p.Initialize())
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }
#endif

        public static PopupObject<FishStorePopup> FishStore(FishStorePopupTabIndex tabIndex = FishStorePopupTabIndex.None, bool isTutorial = false)
        {
            return PopupSystem.Instance.Open<FishStorePopup>(Address.CDN_ASSETBUNDLES, AB_FISHSTORE, ID_FISHSTORE)
                                       .OnInitialize(p => p.Open(tabIndex, isTutorial));
        }

        public static PopupObject<InventoryPopup> Inventory()
        {
            return PopupSystem.Instance.Open<InventoryPopup>(Address.CDN_ASSETBUNDLES, AB_INVENTORY, ID_INVENTORY)
                                       .OnInitialize(p => p.Open());
        }

        public static PopupObject<StoryMapPopup> StoryMap(int? chapterIndexBegin, int? chapterIndexEnd, Action<int> onChangeSea, Action onClose)
        {
            return PopupSystem.Instance.Open<StoryMapPopup>(Address.CDN_ASSETBUNDLES, AB_STORYMAP, ID_STORYMAP)
                                       .OnInitialize(p => p.Open(chapterIndexBegin, chapterIndexEnd, onChangeSea, onClose));
        }

        public static PopupObject<NewSeaPopup> NewSea(int seaID, Action<int> onClose = null)
        {
            return PopupSystem.Instance.Open<NewSeaPopup>(Address.CDN_ASSETBUNDLES, AB_NEWSEA, ID_NEWSEA)
                                       .OnInitialize(p => p.Open(seaID, onClose))
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<PopupBehaviour> UnlockSea()
        {
            return PopupSystem.Instance.Open<PopupBehaviour>(Address.CDN_ASSETBUNDLES, AB_UNLOCKSEA, ID_UNLOCKSEA)
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<SeaMissionClearPopup> SeaMissionClear(int starCount)
        {
            return PopupSystem.Instance.Open<SeaMissionClearPopup>(Address.CDN_ASSETBUNDLES, AB_SEAMISSION_CLEAR, ID_SEAMISSION_CLEAR)
                                       .OnInitialize(p => p.Initialize(starCount))
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<InstantMessagePopup> UniqueSwimmerWarning(string name)
        {
            string title = StringMaker.New()
                                      .Append("\" ")
                                      .Append(name)
                                      .Append(" \"")
                                      .Build();
            return PopupSystem.Instance.Open<InstantMessagePopup>(Address.CDN_ASSETBUNDLES, AB_UNIQUESWIMMER_WARNING, ID_UNIQUESWIMMER_WARNING)
                                       .OnInitialize(p => p.Open(title));
        }

        public static PopupObject<InstantMessagePopup> InventoryHowto()
        {
            return PopupSystem.Instance.Open<InstantMessagePopup>(Address.CDN_ASSETBUNDLES, AB_INVENTORY, ID_INVENTORY_HOWTO)
                                       .OnInitialize(p => p.Open());
        }

        public static PopupObject<QuestClamPopup> QuestClam(MyQuestClam.MissionType missionType, long value = 0)
        {
            return PopupSystem.Instance.Open<QuestClamPopup>(Address.CDN_ASSETBUNDLES, AB_QUESTCLAM, ID_QUESTCLAM)
                                       .OnInitialize(p => p.Initialize(missionType, value))
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<SeaMissionPopup> SeaMission()
        {
            int currentSeaID = MyInfo.Ocean.CurrentSeaID;
            var seaAbName = AssetBundleName.Sea(currentSeaID);

            return PopupSystem.Instance.Open<SeaMissionPopup>(Address.CDN_ASSETBUNDLES, seaAbName, ID_SEAMISSION)
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<GameProfilePopup> GameProfile(int tabIndex = -1, Action onOpen = null)
        {
            return PopupSystem.Instance.Open<GameProfilePopup>(Address.CDN_ASSETBUNDLES, AB_GAME_PROFILE, ID_GAME_PROFILE)
                                       .OnInitialize(p =>
                                       {
                                           onOpen?.Invoke();
                                           p.Open(tabIndex);
                                       });

        }

        public static PopupObject<GameSettingPopup> GameSetting(int tabIndex = -1, Action onOpen = null)
        {
            return PopupSystem.Instance.Open<GameSettingPopup>(Address.CDN_ASSETBUNDLES, AB_GAME_SETTING, ID_GAME_SETTING)
                                       .OnInitialize(p =>
                                       {
                                           onOpen?.Invoke();
                                           p.Open(tabIndex);
                                       });

        }

        public static PopupObject<ShopPopup> Shop(Action onOpen = null)
        {
            var popupName = ScreenSystem.IsLandscape ? ID_SHOP : ID_SHOP_PORTRAIT;
            
            return PopupSystem.Instance.Open<ShopPopup>(Address.CDN_ASSETBUNDLES, AB_SHOP, popupName)
                                       .OnInitialize(p =>
                                        {
                                            onOpen?.Invoke();
                                            p.Open();
                                        });
        }

        public static PopupObject<PurchaseFailPopup> PurchaseFail(string transactionID)
        {
            return PopupSystem.Instance.Open<PurchaseFailPopup>(Address.CDN_ASSETBUNDLES, AB_PURCHASEFAIL, ID_PURCHASEFAIL)
                                       .OnInitialize(p => p.Initialize(transactionID))
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<GameChallengeCompletePopup> GameChallengeComplete(MyChallenge.ChallengeType challengeType)
        {
            return PopupSystem.Instance.Open<GameChallengeCompletePopup>(Address.CDN_ASSETBUNDLES, AB_CHALLENGE_COMPLETE, ID_CHALLENGE_COMPLETE)
                                       .OnInitialize(p => p.Initialize(challengeType))
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<CoinBubblePopup> CoinBubble(long reward, 
                                                              long vipBonus,
                                                              VipBenefitTableItemInfo tableItemInfo,
                                                              CoinBubblePopupState initialState = CoinBubblePopupState.Start, 
                                                              Action onInit = null)
        {
            return PopupSystem.Instance.Open<CoinBubblePopup>(Address.CDN_ASSETBUNDLES, AB_COINBUBBLE, ID_COINBUBBLE)
                                       .OnInitialize(p =>
                                       {
                                           onInit?.Invoke();

                                           p.Open(reward, vipBonus, tableItemInfo, initialState);
                                       });
        }

        public static PopupObject<AdsRewardPopup> AdsReward(Action onOpen = null)
        {
            return PopupSystem.Instance.Open<AdsRewardPopup>(Address.CDN_ASSETBUNDLES, AB_ADSREWARD, ID_ADSREWARD)
                                       .OnInitialize(p =>
                                       {
                                           onOpen?.Invoke();
                                           p.Open();
                                       });
        }

        public static PopupObject<ExitAppPopup> ExitApp()
        {
            return PopupSystem.Instance.Open<ExitAppPopup>(Address.CDN_ASSETBUNDLES, AB_EXITAPP, ID_EXITAPP)
                                       .OnInitialize(p => p.Initialize())
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<BlockedUserPopup> BlockedUser()
        {
            return PopupSystem.Instance.Open<BlockedUserPopup>(Address.CDN_ASSETBUNDLES, AB_BLOCKED, ID_BLOCKED)
                                       .OnInitialize(p => p.Initialize())
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<RewardViewPopup> RewardView(string rewardType, 
                                                              long rewardValue,
                                                              RewardViewPopup.OpenType openType = RewardViewPopup.OpenType.Normal,
                                                              RewardViewPopup.Location location = RewardViewPopup.Location.Normal,
                                                              Action onComplete = null,
                                                              Action onOpenChestClick = null)
        {
            return RewardView(new RewardData() { typeStr = rewardType, value = rewardValue }, openType, location, onComplete, onOpenChestClick);
        }

        public static PopupObject<RewardViewPopup> RewardView(RewardData rewardData,
                                                              RewardViewPopup.OpenType openType = RewardViewPopup.OpenType.Normal,
                                                              RewardViewPopup.Location location = RewardViewPopup.Location.Normal,
                                                              Action onComplete = null,
                                                              Action onOpenChestClick = null)
        {
            return RewardView(new RewardData[] { rewardData }, openType, location, onComplete, onOpenChestClick);
        }

        public static PopupObject<RewardViewPopup> RewardView(RewardData[] rewardDatas,
                                                              RewardViewPopup.OpenType openType = RewardViewPopup.OpenType.Normal,
                                                              RewardViewPopup.Location location = RewardViewPopup.Location.Normal,
                                                              Action onComplete = null,
                                                              Action onReopenClick = null,
                                                              Action onInit = null)
        {
            return PopupSystem.Instance.Open<RewardViewPopup>(Address.CDN_ASSETBUNDLES, AB_REWARDVIEW, ID_REWARDVIEW)
                                       .SetBackgroundAlpha(0f)
                                       .OnInitialize(p =>
                                       {
                                           onInit?.Invoke();
                                           p.Open(rewardDatas, openType, location, onComplete, onReopenClick);
                                       })
                                       .Cache();
        }

        public static PopupObject<WelcomeBackPopup> WelcomeBack(List<RewardInfo> rewardInfos,
                                                                Action<WelcomeBackPopup> onComplete = null)
        {
            return PopupSystem.Instance.Open<WelcomeBackPopup>(Address.CDN_ASSETBUNDLES, AB_WELCOMEBACK, ID_WELCOMEBACK)
                                       .OnInitialize(p => p.Open(rewardInfos, onComplete));
        }

        public static PopupObject<PopupBehaviour> IosNotiSetting()
        {
            return PopupSystem.Instance.Open<PopupBehaviour>(Address.CDN_ASSETBUNDLES, AB_IOS_NOTI_SETTING, ID_IOS_NOTI_SETTING)
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<IosAttConsentPopup> IosAttConsent()
        {
            return PopupSystem.Instance.Open<IosAttConsentPopup>(Address.CDN_ASSETBUNDLES, AB_IOS_ATT_CONSENT, ID_IOS_ATT_CONSENT)
                                       .OnInitialize(p => p.Open())
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<IosNotiConsentPopup> IosNotiConsent(Action onCompelte = null)
        {
            return PopupSystem.Instance.Open<IosNotiConsentPopup>(Address.CDN_ASSETBUNDLES, AB_IOS_NOTI_CONSENT, ID_IOS_NOTI_CONSENT)
                                       .OnInitialize(p => p.Open(onCompelte))
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<AccomplishedPopup> Accomplished(long reward, long vipBonus, VipBenefitTableItemInfo tableItemInfo)
        {
            return PopupSystem.Instance.Open<AccomplishedPopup>(Address.CDN_ASSETBUNDLES, AB_ACCOMPLISHED, ID_ACCOMPLISHED)
                                       .OnInitialize(p => p.Open(reward, vipBonus, tableItemInfo))
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<RateusPopup> Rateus(Action onCompelte = null)
        {
            return PopupSystem.Instance.Open<RateusPopup>(Address.CDN_ASSETBUNDLES, AB_RATEUS, ID_RATEUS)
                                       .OnInitialize(p => p.Open(onCompelte))
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<AdminNoticePopup> AdminNotice(AdminNoticeData data, Action<bool> onExecute = null, Action<bool> onComplete = null)
        {
            return PopupSystem.Instance.Open<AdminNoticePopup>(Address.CDN_ASSETBUNDLES, AB_ADMIN, ID_ADMIN_NOTICE)
                                       .OnInitialize(p =>
                                       {
                                           p.Open(data,
                                                  onExecute, 
                                                  onComplete);
                                        })
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<AdminEventPopup> AdminEvent(AdminEventData data, Action<bool> onExecute = null, Action<bool> onComplete = null)
        {
            return PopupSystem.Instance.Open<AdminEventPopup>(Address.CDN_ASSETBUNDLES, AB_ADMIN, ID_ADMIN_EVENT)
                                       .OnInitialize(p =>
                                       {
                                           p.Open(data,
                                                  onExecute,
                                                  onComplete);
                                       })
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<DeleteAccountPopup> DeleteAccount()
        {
            return PopupSystem.Instance.Open<DeleteAccountPopup>(Address.CDN_ASSETBUNDLES, AB_DELETE_ACCOUNT, ID_DELETE_ACCOUNT)
                                       .OnInitialize(p => p.Open())
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<RestoreAccountPopup> RestoreAccount(Action onRestoreClick)
        {
            return PopupSystem.Instance.Open<RestoreAccountPopup>(Address.CDN_ASSETBUNDLES, AB_DELETE_ACCOUNT, ID_RESTORE_ACCOUNT)
                                       .OnInitialize(p => p.Open(onRestoreClick))
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<AppUpdatePopup> AppUpdate(bool force, string img)
        {
            return PopupSystem.Instance.Open<AppUpdatePopup>(Address.CDN_ASSETBUNDLES, AB_APP_UPDATE, ID_APP_UPDATE)
                                       .OnInitialize(p => p.Open(force, img))
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<MaintenancePopup> Maintenance(MaintenanceData data, Action onCompelte = null)
        {
            return PopupSystem.Instance.Open<MaintenancePopup>(Address.CDN_ASSETBUNDLES, AB_MAINTENANCE, ID_MAINTENANCE)
                                        .OnInitialize(p => p.Open(data, onCompelte))
                                        .SetBackgroundAlpha(0f, false);
        }

        public static PopupObject<SocialPopup> Social(Action onCompelte = null)
        {
            return PopupSystem.Instance.Open<SocialPopup>(Address.CDN_ASSETBUNDLES, AB_SOCIAL, ID_SOCIAL)
                                        .OnInitialize(p => p.Open())
                                        .SetBackgroundAlpha(0f, false).OnClose(onCompelte);
        }

        public static PopupObject<GameBetPopup> GameBet(string slotID, Lobby.SlotCardSkin slotCard, Action<GameBetPopup.Result> onChooseBet)
        {
            return PopupSystem.Instance.Open<GameBetPopup>(Address.CDN_ASSETBUNDLES, AB_GAMEBET, ID_GAMEBET)
                                       .OnInitialize(p => p.Initialize(slotID, slotCard, onChooseBet))
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<DailyBonusPopup> DailyBonus(Action onOpen = null, Action onCompelte = null)
        {
            return PopupSystem.Instance.Open<DailyBonusPopup>(Address.CDN_ASSETBUNDLES, AB_DAILYBONUS, ID_DAILYBONUS)
                                       .OnInitialize(p =>
                                       {
                                           onOpen?.Invoke();
                                           p.Open();
                                        })
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA).OnClose(onCompelte);
        }

        public static PopupObject<BoosterPopup> Booster(Action onComplete = null)
        {
            return PopupSystem.Instance.Open<BoosterPopup>(Address.CDN_ASSETBUNDLES, AB_BOOSTER, ID_BOOSTER)
                                       .OnInitialize(p => p.Open())
                                       .SetBackgroundAlpha(0.0f)
                                       .OnClose(onComplete);
        }

        public static PopupObject<HighlightPopup> Highlight(HighlightObjectInfo info, Action onComplete = null)
        {
            return PopupSystem.Instance.Open<HighlightPopup>(Address.CDN_ASSETBUNDLES, AB_HIGHLIGHT, ID_HIGHLIGHT)
                                       .OnInitialize(p => p.Register(info))
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA)
                                       .OnClose(onComplete);
        }

        public static PopupObject<OfferPopup> Offer(OfferInfo info, Action onPurchase = null, Action onOpen = null)
        {
            string popupID = GetOfferPopupID(info.OfferType);
            return PopupSystem.Instance.Open<OfferPopup>(Address.CDN_ASSETBUNDLES, AB_OFFER, popupID)
                                       .OnInitialize(p =>
                                       {
                                           onOpen?.Invoke();
                                           p.Open(info, onPurchase);
                                       })
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<CouponPopup> Coupon1(CouponInfo info, Action onComplete = null)
        {
            return PopupSystem.Instance.Open<CouponPopup>(Address.CDN_ASSETBUNDLES, AB_COUPON_1, ID_COUPON_1)
                                       .OnInitialize(p => p.Open(info))
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA)
                                       .OnClose(onComplete);
        }

        public static PopupObject<CouponPopup> Coupon2(CouponInfo info, Action onComplete = null)
        {
            return PopupSystem.Instance.Open<CouponPopup>(Address.CDN_ASSETBUNDLES, AB_COUPON_2, ID_COUPON_2)
                                       .OnInitialize(p => p.Open(info))
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA)
                                       .OnClose(onComplete);
        }

        private static string GetOfferPopupID(string category)
        {
            if (category == OfferSystem.CATEGORY_ALLIN)
            {
                return Popups.ID_OFFER_ALLIN;
            }
            else if (category == OfferSystem.CATEGORY_STARTER)
            {
                return Popups.ID_OFFER_STARTER;
            }
            else if (category == OfferSystem.CATEGORY_EVENT)
            {
                return Popups.ID_OFFER_EVENT;
            }
            else if (category == OfferSystem.CATEGORY_BIGWIN)
            {
                return Popups.ID_OFFER_BIGWIN;
            }
            else if (category == OfferSystem.CATEGORY_OCEAN)
            {
                return Popups.ID_OFFER_OCEAN;
            }
            else if (category == OfferSystem.CATEGORY_SWIMMER)
            {
                return Popups.ID_OFFER_SWIMMER;
            }
            else
            {
                return string.Empty;
            }
        }

        public static PopupObject<InfoPagePopup> FishStoreInfo()
        {
            return PopupSystem.Instance.Open<InfoPagePopup>(Address.CDN_ASSETBUNDLES, AB_FISHSTOREINFO, ID_FISHSTOREINFO)
                                       .OnInitialize(p => p.Open())
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<InfoPagePopup> SeaStoryInfo()
        {
            return PopupSystem.Instance.Open<InfoPagePopup>(Address.CDN_ASSETBUNDLES, AB_SEASTORYINFO, ID_SEASTORYINFO)
                                       .OnInitialize(p => p.Open())
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<SeaStoryCollectionPopup> SeaStoryCollection(long point, 
                                                                              List<MySeaStory.CollectionInfo.Item> items,
                                                                              bool autoCollect,
                                                                              bool hasTarget,
                                                                              Vector2 collectTarget,
                                                                              Action onFirstEffectArrived = null)
        {
            return PopupSystem.Instance.Open<SeaStoryCollectionPopup>(Address.CDN_ASSETBUNDLES, AB_SEASTORYCOLLECTION, ID_SEASTORYCOLLECTION)
                                       .OnInitialize(p => p.Initialize(point, items, autoCollect, hasTarget, collectTarget, onFirstEffectArrived))
                                       .SetBackgroundAlpha(0.0f);
        }

        public static PopupObject<BackToLobbyPopup> BackToLobby()
        {
            return PopupSystem.Instance.Open<BackToLobbyPopup>(Address.CDN_ASSETBUNDLES, AB_BACKTOLOBBY, ID_BACKTOLOBBY)
                                       .OnInitialize(p => p.Open())
                                       .SetBackgroundAlpha(0.0f);
        }

        public static PopupObject<BackToLobbyPopup> BackToLobby(string info, float delay)
        {
            return PopupSystem.Instance.Open<BackToLobbyPopup>(Address.CDN_ASSETBUNDLES, AB_BACKTOLOBBY, ID_BACKTOLOBBY)
                                       .OnInitialize(p => p.Open(info, delay))
                                       .SetBackgroundAlpha(0.0f);
        }

        public static PopupObject<TotalGrowthPopup> TotalGrowth(long level, long bonusCoin, int shop, int daily, int free, int feed, int chest, int congrat)
        {
            var popupName = ScreenSystem.IsLandscape ? ID_TOTALGROWTH : ID_TOTALGROWTH_PORTRAIT;

            return PopupSystem.Instance.Open<TotalGrowthPopup>(Address.CDN_ASSETBUNDLES, AB_TOTALGROWTH, popupName)
                                       .OnInitialize(p => p.Initialize(level, bonusCoin, shop, daily, free, feed, chest, congrat))
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<ShopGrowthPopup> ShopGrowth(int percent, Action onAction)
        {
            return PopupSystem.Instance.Open<ShopGrowthPopup>(Address.CDN_ASSETBUNDLES, AB_SHOPGROWTH, ID_SHOPGROWTH)
                                       .OnInitialize(p => p.Initialize(percent, onAction))
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<InfoPagePopup> ClamHarvestInfo()
        {
            return PopupSystem.Instance.Open<InfoPagePopup>(Address.CDN_ASSETBUNDLES, AB_CLAMHARVESTINFO, ID_CLAMHARVESTINFO)
                                       .OnInitialize(p => p.Open())
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<DailyMissionRewardPopup> DailyMissionReward(DailyMissionDisplay dailyMissionDisplay,
                                                                              bool autoProgressEnabled,
                                                                              Action onOpen)
        {
            return PopupSystem.Instance.Open<DailyMissionRewardPopup>(Address.CDN_ASSETBUNDLES, AB_DAILYMISSION_REWARD, ID_DAILYMISSION_REWARD)
                                       .OnInitialize(p =>
                                       {
                                           onOpen?.Invoke();
                                           p.Open(dailyMissionDisplay, autoProgressEnabled);
                                       })
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<DailyQuestUnlockPopup> DailyQuestUnlock()
        {
            return PopupSystem.Instance.Open<DailyQuestUnlockPopup>(Address.CDN_ASSETBUNDLES, AB_DAILYQUEST_UNLOCK, ID_DAILYQUEST_UNLOCK)
                                       .OnInitialize(p => p.Open())
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<VipBenefitPopup> VipBenefit(Action onOpen = null)
        {
            return PopupSystem.Instance.Open<VipBenefitPopup>(Address.CDN_ASSETBUNDLES, AB_VIP_BENEFIT, ID_VIP_BENEFIT)
                                       .OnInitialize(p =>
                                       {
                                           onOpen?.Invoke();
                                           p.Open();
                                       });
        }

        public static PopupObject<VipLevelUpPopup> VipLevelUp(Action onCheckTheBenefit, Action onOpen = null)
        {
            return PopupSystem.Instance.Open<VipLevelUpPopup>(Address.CDN_ASSETBUNDLES, AB_VIP_LEVELUP, ID_VIP_LEVELUP)
                                       .OnInitialize(p =>
                                       {
                                           onOpen?.Invoke();
                                           p.Open(onCheckTheBenefit);
                                       });
        }

        public static IEnumerator VipLevelUpCoroutine(bool runAsFake = false)
        {
            bool isCheckTheBenefit = false;
            yield return VipLevelUp(() => isCheckTheBenefit = true)
                        .Async()
                        .Cache()
                        .WaitForClose();

            if (isCheckTheBenefit)
            {
                PopupObject<VipBenefitPopup> popupObject = null;
                popupObject = VipBenefit(onOpen: () => popupObject.GetPopup().RunAsFake = runAsFake)
                              .Async()
                              .Cache();
                yield return popupObject.WaitForClose();
            }
        }

        public static IEnumerator VipResetNoticeCoroutine()
        {
            bool isGoToCheck = false;
            yield return VipResetNotice(() => isGoToCheck = true)
                        .Async()
                        .WaitForClose();

            if (isGoToCheck)
            {
                yield return VipResetDetail()
                            .Async()
                            .Cache()
                            .WaitForClose();
            }
        }

        public static PopupObject<VipResetDetailPopup> VipResetDetail()
        {
            return PopupSystem.Instance.Open<VipResetDetailPopup>(Address.CDN_ASSETBUNDLES, AB_VIP_RESET_DETAIL, ID_VIP_RESET_DETAIL)
                                       .OnInitialize(p => p.Open());
        }

        public static PopupObject<VipResetNoticePopup> VipResetNotice(Action onGoToCheck)
        {
            return PopupSystem.Instance.Open<VipResetNoticePopup>(Address.CDN_ASSETBUNDLES, AB_VIP_RESET_NOTICE, ID_VIP_RESET_NOTICE)
                                       .OnInitialize(p => p.Open(onGoToCheck));
        }

        public static PopupObject<VipResetKickOffPopup> VipResetKickOff()
        {
            return PopupSystem.Instance.Open<VipResetKickOffPopup>(Address.CDN_ASSETBUNDLES, AB_VIP_RESET_KICKOFF, ID_VIP_RESET_KICKOFF)
                                       .OnInitialize(p => p.Open());
        }

        public static IEnumerator VipOpenCoroutine()
        {
            bool isGoToCheck = false;
            yield return VipOpen(() => isGoToCheck = true)
                        .Async()
                        .WaitForClose();

            if (isGoToCheck)
            {
                yield return VipBenefit()
                            .Async()
                            .Cache()
                            .WaitForClose();
            }
        }

        public static PopupObject<VipOpenPopup> VipOpen(Action onGoToCheck)
        {
            return PopupSystem.Instance.Open<VipOpenPopup>(Address.CDN_ASSETBUNDLES, AB_VIP_OPEN, ID_VIP_OPEN)
                                       .OnInitialize(p => p.Open(onGoToCheck));
        }

        public static PopupObject<MissionPassPopup> MissionPass(MissionPassPopupTab tab = MissionPassPopupTab.MissionPass, 
                                                                bool syncData = true,
                                                                bool interactable = true,
                                                                Action onInit = null)
        {
            return PopupSystem.Instance.Open<MissionPassPopup>(Address.CDN_ASSETBUNDLES, AB_MISSION_PASS, ID_MISSION_PASS)
                                       .OnInitialize(p =>
                                       {
                                           onInit?.Invoke();
                                           p.Open(tab, syncData, interactable);
                                       })
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<InfoPagePopup> MissionPassInfo()
        {
            return PopupSystem.Instance.Open<InfoPagePopup>(Address.CDN_ASSETBUNDLES, AB_MISSION_PASS_INFO, ID_MISSION_PASS_INFO)
                                       .OnInitialize(p =>
                                       {
                                           p.Open();
                                       })
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<InstantClosablePopup> MissionPassCollectAll(Action onCollect)
        {
            return PopupSystem.Instance.Open<InstantClosablePopup>(Address.CDN_ASSETBUNDLES, AB_MISSION_PASS_COLLECTALL, ID_MISSION_PASS_COLLECTALL)
                                       .OnInitialize(p =>
                                       {
                                           p.Open("", onCollect);
                                       })
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<MissionPassRewardPopup> MissionPassReward(MissionPassRewardPopup.TitleType titleType,
                                                                            List<RewardInfo> rewardInfos,
                                                                            SimpleRewardItemValueType valueType = SimpleRewardItemValueType.Simple,
                                                                            Action onInit = null,
                                                                            bool openAsShow = true)
        {
            return PopupSystem.Instance.Open<MissionPassRewardPopup>(Address.CDN_ASSETBUNDLES, AB_MISSION_PASS_REWARD, ID_MISSION_PASS_REWARD)
                                       .OnInitialize(p =>
                                       {
                                           onInit?.Invoke();
                                           p.Open(titleType, rewardInfos, valueType, openAsShow);
                                       })
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<MissionPassFreeRewardPopup> MissionPassFreeReward(Action onInit, 
                                                                                    List<RewardInfo> freeRewardInfos, 
                                                                                    List<RewardInfo> bonusRewardInfos, 
                                                                                    Action onRefresh, 
                                                                                    bool debugMode)
        {
            return PopupSystem.Instance.Open<MissionPassFreeRewardPopup>(Address.CDN_ASSETBUNDLES, AB_MISSION_PASS_REWARD_FREE, ID_MISSION_PASS_REWARD_FREE)
                                       .OnInitialize(p =>
                                       {
                                           onInit?.Invoke();
                                           p.Open(freeRewardInfos, bonusRewardInfos, onRefresh, debugMode);
                                       })
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<MissionPassSeeMorePopup> MissionPassSeeMore(List<RewardInfo> rewardInfos, MissionPassSeeMorePopup.TitleType titleType)
        {
            return PopupSystem.Instance.Open<MissionPassSeeMorePopup>(Address.CDN_ASSETBUNDLES, AB_MISSION_PASS_SEEMORE, ID_MISSION_PASS_SEEMORE)
                                       .OnInitialize(p =>
                                       {
                                           p.Initialize(titleType, rewardInfos);
                                       })
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<MissionPassLevelUpPopup> MissionPassLevelUp(int nextLevel)
        {
            return PopupSystem.Instance.Open<MissionPassLevelUpPopup>(Address.CDN_ASSETBUNDLES, AB_MISSION_PASS_LEVEL_UP, ID_MISSION_PASS_LEVEL_UP)
                                       .OnInitialize(p => p.Open(nextLevel))
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static IEnumerator MissionPassPurchaseCoroutine(bool runAsFake = false,
                                                               Action onPurchase = null,
                                                               Action onComplete = null,
                                                               Action onClose = null)
        {
            bool isPurchased = false;
            PopupObject<MissionPassPurchasePopup> popupObject = null;
            popupObject = MissionPassPurchase(
                onInit: () => popupObject.GetPopup().RunAsFake = runAsFake,
                onPurchased: () =>
                {
                    isPurchased = true;
                }
            ).Async();
            yield return popupObject.WaitForClose();

            if (isPurchased)
            {
                yield return MissionPassPurchaseComplete().
                             Async().
                             WaitForClose();

                onPurchase?.Invoke();

                if (MyInfo.VipClass.ConsumeLevelUp())
                {
                    yield return VipLevelUpCoroutine();
                }

                onComplete?.Invoke();
            }

            onClose?.Invoke();
        }

        public static PopupObject<MissionPassPurchasePopup> MissionPassPurchase(Action onInit = null,
                                                                                Action onPurchased = null)
        {
            return PopupSystem.Instance.Open<MissionPassPurchasePopup>(Address.CDN_ASSETBUNDLES, AB_MISSION_PASS_PURCHASE, ID_MISSION_PASS_PURCHASE)
                                       .OnInitialize(p =>
                                       {
                                           onInit?.Invoke();
                                           p.Initialize(onPurchased);
                                       })
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }


        public static PopupObject<InstantOpenAnimationPopup> MissionPassPurchaseComplete()
        {
            return PopupSystem.Instance.Open<InstantOpenAnimationPopup>(Address.CDN_ASSETBUNDLES, AB_MISSION_PASS_PURCHASE_COMPLETE, ID_MISSION_PASS_PURCHASE_COMPLETE)
                                       .OnInitialize(p => p.Open())
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<MissionPassIncludesPopup> MissionPassIncludes()
        {
            return PopupSystem.Instance.Open<MissionPassIncludesPopup>(Address.CDN_ASSETBUNDLES, AB_MISSION_PASS_INCLUDES, ID_MISSION_PASS_INCLUDES)
                                       .OnInitialize(p =>
                                       {
                                           p.Initialize();
                                       })
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<InstantMessagePopup> MissionPassOpen()
        {
            return PopupSystem.Instance.Open<InstantMessagePopup>(Address.CDN_ASSETBUNDLES, AB_MISSION_PASS_OPEN, ID_MISSION_PASS_OPEN)
                                       .OnInitialize(p => p.Open())
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }

        public static PopupObject<InstantMessagePopup> AquaBlitzInfo()
        {
            return PopupSystem.Instance.Open<InstantMessagePopup>(Address.CDN_ASSETBUNDLES, AB_AQUABLITZ_INFO, ID_AQUABLITZ_INFO)
                                       .OnInitialize(p => p.Open())
                                       .SetBackgroundAlpha(DEFAULT_BACKGROUND_ALPHA);
        }
    }
}