using UnityEngine;
using Gaga.Popup;
using Underc.User;
using System.Collections.Generic;

namespace Underc.Popup
{
    public sealed class MissionPassIncludesPopup : PopupBackable
    {
        [SerializeField] private RectTransform rewardItemRoot;
        [SerializeField] private SimpleRewardItem rewardItemRef;

        public void Initialize()
        {
            SetupItems();
        }

        private void SetupItems()
        {
            var missionPass = MyInfo.MissionPass;
            List<MyMissionPass.ItemInfo> infoList = new List<MyMissionPass.ItemInfo>();

            for (int i = 0; i < missionPass.GetItemCount(); i++)
            {
                infoList.Add(missionPass.GetFreeInfo(i));
                infoList.Add(missionPass.GetBonusInfo(i));
            }

            infoList = missionPass.MergeItemInfo(infoList);

            for (int i = 0; i < infoList.Count; i++)
            {
                var rewardInfo = infoList[i];
                var rewardItem = Instantiate(rewardItemRef.gameObject).GetComponent<SimpleRewardItem>();
                rewardItem.transform.SetParent(rewardItemRoot, false);

                rewardItem.UpdateContent(rewardInfo.type, 
                                         rewardInfo.value, 
                                         rewardInfo.extraValue,
                                         vipClassType: MyInfo.VipClass.Type);
            }
        }
    }
}