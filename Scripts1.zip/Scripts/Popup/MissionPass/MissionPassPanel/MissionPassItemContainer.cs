using UnityEngine;
using Underc.User;
using System;

namespace Underc.Popup
{
    public class MissionPassItemContainer : MonoBehaviour
    {
        public enum ClickEventType
        {
            Free        = 0,
            Bonus       = 1,
            Chest       = 2
        }

        public RectTransform CachedRectTransform{get; private set;}

        [SerializeField] private MissionPassNormalItem normalItem;
        [SerializeField] private MissionPassChestItem chestItem;

        public Action<int, ClickEventType> onClick;
        public int Step{get; private set;}

        private void Awake()
        {
            CachedRectTransform = GetComponent<RectTransform>();
        }

        public void Set(int step, 
                        int currentStep, 
                        MyMissionPass.ItemInfo bonusInfo, 
                        MyMissionPass.ItemInfo freeInfo, 
                        bool isBonusEnabled, 
                        VipClassType vipClassType,
                        bool isInReactive)
        {
            Step = step;

            normalItem.gameObject.SetActive(true);
            normalItem.onClick = isBonus => DispatchClick(isBonus ? ClickEventType.Bonus : ClickEventType.Free);

            chestItem.gameObject.SetActive(false);
            chestItem.onClick = null;

            normalItem.Set(step, currentStep, bonusInfo, freeInfo, isBonusEnabled, vipClassType, isInReactive);

            UpdateWidth(normalItem.CachedRectTransform);
        }

        public void SetChest(int step, int progressStep, MyMissionPass.ItemInfo bonusInfo, bool isBonusEnabled)
        {
            Step = step;

            normalItem.gameObject.SetActive(false);
            normalItem.onClick = null;

            chestItem.gameObject.SetActive(true);
            chestItem.onClick = ()=> DispatchClick(ClickEventType.Chest);

            chestItem.Set(step, progressStep, bonusInfo, isBonusEnabled);

            UpdateWidth(chestItem.CachedRectTransform);
        }

        private void UpdateWidth(RectTransform target)
        {
            var tempSizeDelta = CachedRectTransform.sizeDelta;
            tempSizeDelta.x = target.sizeDelta.x;

            CachedRectTransform.sizeDelta = tempSizeDelta;
        }

        private void DispatchClick(ClickEventType clickEventType)
        {
            onClick?.Invoke(Step, clickEventType);
        }
    }
}    