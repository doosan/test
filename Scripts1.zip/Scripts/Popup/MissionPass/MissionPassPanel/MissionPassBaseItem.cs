using UnityEngine;
using Underc.User;

namespace Underc.Popup
{
    public abstract class MissionPassBaseItem : MonoBehaviour
    {
        public RectTransform CachedRectTransform{get; private set;}

        protected virtual void Awake()
        {
            CachedRectTransform = GetComponent<RectTransform>();
        }
    }
}    