using UnityEngine;
using Underc.User;
using TMPro;
using Gaga.Attribute;
using System;

namespace Underc.Popup
{
    public class MissionPassNormalItem : MissionPassBaseItem
    {
        [Separator("Elements")]
        [SerializeField] private MissionPassNormalItemElement bonusElement;
        [SerializeField] private MissionPassNormalItemElement freeElement;

        [Separator("Step View")]
        [SerializeField] private GameObject gaugeLockBg;
        [SerializeField] private GameObject gaugeUnlockBg;
        [SerializeField] private GameObject gaugeStartBg;
        [Space]
        [SerializeField] private TextMeshProUGUI gaugeStepText;
        [SerializeField] private GameObject gaugeStepStartIcon;
        [SerializeField] private GameObject gaugeLockStepBg;
        [SerializeField] private GameObject gaugeUnlockStepBg;

        public MissionPassNormalItemElement BonusElement
        {
            get => bonusElement;
        }

        public Action<bool> onClick; // bool : bonus 
        private int step;

        public void Set(int step, int progressStep, MyMissionPass.ItemInfo bonusInfo, MyMissionPass.ItemInfo freeInfo, bool isBonusEnabled, VipClassType vipClassType, bool isInReactive)
        {
            this.step = step;

            SetElements(bonusInfo, freeInfo, isBonusEnabled, vipClassType, isInReactive);
            SetGauge(step, progressStep);
        }

        private void SetElements(MyMissionPass.ItemInfo bonusInfo, MyMissionPass.ItemInfo freeInfo, bool isBonusEnabled, VipClassType vipClassType, bool isInReactive)
        {
            bonusElement.Set(bonusInfo, isBonusEnabled, vipClassType, isInReactive); 
            bonusElement.onClick = ()=> DispatchClick(true);

            freeElement.Set(freeInfo, true, vipClassType, isInReactive);
            freeElement.onClick = ()=> DispatchClick(false);
        }

        private void SetGauge(int step, int progressStep)
        {
            gaugeStepText.text = step.ToString();

            bool isFirstItem = step == 0;
            bool isUnlock = step <= progressStep;

            if (isFirstItem)
            {
                gaugeLockStepBg.SetActive(false);
                gaugeUnlockStepBg.SetActive(true);
                gaugeStepText.gameObject.SetActive(false);
                gaugeStepStartIcon.SetActive(true);

                gaugeStartBg.SetActive(true);
                gaugeLockBg.SetActive(false);
                gaugeUnlockBg.SetActive(false);
            }
            else
            {
                gaugeStepText.gameObject.SetActive(true);
                gaugeStepStartIcon.SetActive(false);
                gaugeLockStepBg.SetActive(!isUnlock);
                gaugeUnlockStepBg.SetActive(isUnlock);

                gaugeStartBg.SetActive(false);
                gaugeLockBg.SetActive(!isUnlock);
                gaugeUnlockBg.SetActive(isUnlock);
            }
        }

        private void DispatchClick(bool isBonus)
        {
            onClick?.Invoke(isBonus);
        }
    }
}    