using System;
using Gaga.Attribute;
using Underc.User;
using UnityEngine;
using UnityEngine.Serialization;

namespace Underc.Popup
{
    public class MissionPassChestItem : MissionPassBaseItem
    {
        [Separator("Step View")]
        [SerializeField] private GameObject gaugeLockBg;
        [SerializeField] private GameObject gaugeUnlockBg;

        [Separator("Status")]
        [FormerlySerializedAs("completeBadge")]
        [SerializeField] private GameObject rewardBadge;
        [SerializeField] private GameObject lockBadge;

        public Action onClick;
        
        public void Set(int step, int progressStep, MyMissionPass.ItemInfo bonusInfo, bool isBonusEnabled)
        {
            bool isOn = step == progressStep;

            gaugeLockBg.SetActive(!isOn);
            gaugeUnlockBg.SetActive(isOn);

            lockBadge.SetActive(!isBonusEnabled);
            rewardBadge.SetActive(isOn && isBonusEnabled && bonusInfo.status == MyMissionPass.Status.Reward);
        }

        public void OnClickHandler()
        {
            onClick?.Invoke();
        }
    }
}    