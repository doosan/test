using UnityEngine;
using Underc.User;
using System;

namespace Underc.Popup
{
    public class MissionPassNormalItemElement : MonoBehaviour
    {
        [SerializeField] private SimpleRewardItem rewardItem;
        [SerializeField] private Animator[] animators;

        public RectTransform CachedTransform
        {
            get
            {
                if (cachedTransform == null)
                {
                    cachedTransform = GetComponent<RectTransform>();
                }
                return cachedTransform;
            }
        }
        private RectTransform cachedTransform;

        public Action onClick;

        public void Set(MyMissionPass.ItemInfo info, bool isEnabled, VipClassType vipClassType, bool isInReactive)
        {
            string currStatus = info.status.ToString();
                                
            if (isEnabled == false)
            {
                currStatus = "Lock";
            }
            else if (isInReactive
                     && info.prevStatus == MyMissionPass.Status.Reward
                     && info.status == MyMissionPass.Status.Complete)
            {
                currStatus = "ToComplete";
            }
            //Debug.Log($"==== SetStatusView : {isInReactive}, {info.prevStatus} -> {info.status}");

            SetStatusView(currStatus);
            SetReward(info.type, info.value, vipClassType);
        }

        private void SetReward(RewardType itemType, long itemValue, VipClassType vipClassType)
        {
            rewardItem.UpdateContent(itemType, itemValue, vipClassType: vipClassType);
        }

        private void SetStatusView(string status)
        {
            foreach (Animator animator in animators)
            {
                animator.SetTrigger(status.ToString());
            }

        }

        public void OnClickHandler()
        {
            onClick?.Invoke();
        }
    }
}    