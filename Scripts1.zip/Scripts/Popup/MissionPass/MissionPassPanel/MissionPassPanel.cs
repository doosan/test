using System;
using System.Collections;
using System.Collections.Generic;
using Underc.UI;
using Gaga.UI;
using UnityEngine;
using Underc.User;
using Gaga.Attribute;
using UnityEngine.UI;
using TMPro;
using Gaga.Util;
using Gaga.Popup;
using Underc.Net;
using Underc.Net.Client;
using Underc.Tutorial;
using Gaga;

namespace Underc.Popup
{
    public class MissionPassPanel : BaseMissionPassContentPanel, IRecyclingItemProvider
    {
        private readonly int ITEM_SKIN_INDEX_FREE       = 0;
        private readonly int ITEM_SKIN_INDEX_BONUS      = 1;

        [Serializable]
        public sealed class DebugInfo
        {
            [Header("General")]
            public long endTimeStamp;
            public int season;
            public int step;
            public long currentMissionValue;
            public long goalMissionValue;

            [Header("Purchase")]
            public string purchaseID;
            public long vipPoint;
            public float price;
            public float salePrice;
            
            [Header("Items")]
            public bool bonusEnabled;
            public bool missionBoxEnabled;
            public DebugItemInfo[] itemList;
        }

        [Serializable]
        public sealed class DebugItemInfo
        {
            public RewardType bonusType;
            public long bonusValue;
            public MyMissionPass.Status bonusStatus;

            [Space]
            public RewardType freeType;
            public long freeValue;
            public MyMissionPass.Status freeStatus;
        }

        [SerializeField] private TextGroup uptoTextGroup;
        [SerializeField] private TextMeshProUGUI seasonText;
        [SerializeField] private TextMeshProUGUI endsInText;
        [SerializeField] private Button buyButton;
        [SerializeField] private Button collectAllButton;
        [SerializeField] private AnimatorParser buttonToDisabledAnimation;
        [SerializeField] private AnimatorParser buttonDisabledAnimation;
        [SerializeField] private AnimatorParser buttonNormalAnimation;

        [Separator("Quick Move")]
        [SerializeField] private float quickMoveDuration = 0.3f;
        [SerializeField] private GameObject leftQuickMoveButton;
        [SerializeField] private Text leftQuickMoveText;
        [SerializeField] private GameObject rightQuickMoveButton;
        [SerializeField] private Text rightQuickMoveText;
        [SerializeField] private GameObjectVisibleToggle rightQuickMoveVisibleToggle;

        [Separator("Page Move")]
        [SerializeField] private int pageItemCount = 5;
        [SerializeField] private float pageMoveDuration = 0.3f;
        [SerializeField] private float pageActiveOffsetX = 3.0f;
        [SerializeField] private GameObject prevPageMoveButton;
        [SerializeField] private GameObject nextPageMoveButton;

        [Separator("Mission Level")]
        [SerializeField] private RectTransform missionLevelRoot;
        [SerializeField] private Slider missionLevelGauge;
        [SerializeField] private TextMeshProUGUI missionLevelPointText;
        [SerializeField] private TextMeshProUGUI missionLevelText;
        [SerializeField] private GameObjectVisibleToggle levelVisibleToggle;

        [Separator("Unlock Button")]
        [SerializeField] private RectTransform missionPassUnlockRoot;

        [Separator("Item List")]
        [SerializeField] private MissionPassItemContainer itemContainerRef;
        [SerializeField] private RecyclerListView itemListView;
        [SerializeField] private RectTransform itemListProgressBG;

        [Separator("Debug (데이터 갱신 [R]")]
        [SerializeField] private bool debugMode = false;
        [SerializeField] private DebugInfo debugInfo;

        public bool HoldBeforeClose
        {
            private get
            {
                //Debug.Log($"==== holdBeforeClose : {holdBeforeClose}");
                return holdBeforeClose;
            }
            set
            {
                holdBeforeClose = value;
                //Debug.Log($"==== holdBeforeClose : {holdBeforeClose}");
            }
        }
        private bool holdBeforeClose;

        private MyMissionPass myMissionPass;
        private Dictionary<RectTransform, MissionPassItemContainer> cachendItemContainers;
        private Dictionary<int, RectTransform> cachedActiveItems;
        private MissionPassItemContainer recentCompleteItemContainer;

        private bool isInit;
        private bool isEnd;
        private bool isInReactive;

        private bool GetDebugMode()
        {
#if !UNITY_EDITOR
            return false;
#endif

            return debugMode;
        }

        private void OnEnable()
        {
            MyInfo.MissionPass.onEndRemainSeconds += OnMissionPassRemainTime;
            buyButton.interactable = false;
        }

        private void OnDisable()
        {
            MyInfo.MissionPass.onEndRemainSeconds -= OnMissionPassRemainTime;
        }

        public override bool CanBack()
        {
            //TODO : 통신 중일 때에 false 처리 해야 함.
            return true;
        }

        public override bool Close()
        {
            MyInfo.MissionPass.onEndRemainSeconds -= OnMissionPassRemainTime;

            return true;
        }

        public override void Init()
        {
            if (isInit)
            {
                return;
            }

            isInit = true;
            myMissionPass = MyInfo.MissionPass;
        }

        public override void Reset()
        {
            isEnd = false;
        }

        public override IEnumerator UpdateContent(UpdateContentType updateType)
        {
            if (isEnd)
            {
                yield break;
            }

            if (GetDebugMode())
            {
                MyInfo.MissionPass.Update(ConvertDebugInfoToMissionPassData(debugInfo));
                myMissionPass = MyInfo.MissionPass;
            }

            MissionPassPurchaseInfo purchaseInfo = MyInfo.MissionPass.GetPurchaseInfo();
            uptoTextGroup.TextValue = $"{purchaseInfo.uptoValue}X";
            seasonText.text = myMissionPass.Season.ToString();

            UpdateMissionLevel();
            UpdateTime(remainingSec: MyInfo.MissionPass.EndRemainingSec,
                       checkTimeout: false);
            UpdateBuyButton();
            UpdateItemList(updateType == UpdateContentType.First);
            UpdateCollectAllButton();
            UpdateQuickMoveButtons();
            UpdatePageMoveButtons();

            if (MyInfo.Tutorial.IsReady(TutorialChapter.MissionPass))
            {
                PlayTutorial();
            }

            if (MyInfo.MissionPass.IsMissionPassPopupFirstOpen)
            {
                MyInfo.MissionPass.IsMissionPassPopupFirstOpen = false;
            }

            yield break;
        }

        // Dev Test
#if UNITY_EDITOR
        private void Update()
        {
            if (GetDebugMode() && Input.GetKeyDown(KeyCode.R))
            {
                StartCoroutine(UpdateContent(UpdateContentType.Refresh));
            }
        }
#endif

        private void Refresh()
        {
            if (isEnd || isInit == false)
            {
                return;
            }

            //Debug.Log("==== Refresh()");
            OnRefresh?.Invoke();
        }

        private void UpdateMissionLevel()
        {
            missionLevelGauge.value = (float)myMissionPass.CurrentMissionValue / (float)myMissionPass.GoalMissionValue;
            missionLevelPointText.text = string.Format("{0}/{1}", myMissionPass.CurrentMissionValue, myMissionPass.GoalMissionValue);

            int nextStep = myMissionPass.CurrentStep;
            missionLevelText.text = nextStep.ToString();

            MissionPassLevelType levelType = myMissionPass.GetLevelType(myMissionPass.CurrentStep);
            levelVisibleToggle.TurnOnByNameInMultiple(levelType.ToString());
        }

        private void UpdateBuyButton()
        {
            bool prevValue = buyButton.interactable;
            bool nextValue = myMissionPass.EnabledBonus;
            buyButton.interactable = nextValue == false;
            if (nextValue)
            {
                if (prevValue == true)
                {
                    buttonToDisabledAnimation?.SetTrigger();
                }
                else
                {
                    buttonDisabledAnimation?.SetTrigger();
                }
            }
            else
            {
                buttonNormalAnimation?.SetTrigger();
            }
        }

        private void UpdateCollectAllButton()
        {
            if (myMissionPass.EnabledBonus)
            {
                collectAllButton.interactable = myMissionPass.CollectEnabled;
            }
            else
            {
                collectAllButton.interactable = myMissionPass.CollectFreeEnabled;
            }
        }

        private void OnMissionPassRemainTime(long remainingSec)
        {
            if (isEnd)
            {
                return;
            }

            UpdateTime(remainingSec, true);
        }

        private void UpdateTime(long remainingSec, bool checkTimeout)
        {
            endsInText.text = remainingSec.ToSummaryDHMS();

            // 미션패스 시간이 종료되면 팝업을 닫아버림.
            if (checkTimeout == true
                && remainingSec <= 0
                && HoldBeforeClose == false)
            {
                isEnd = true;

                OnClose?.Invoke();
            }
        }

        private void UpdateQuickMoveButtons()
        {
            int progressStep = myMissionPass.CurrentStep;

            if (itemListView.GetFirstActiveItemIndex() > progressStep)
            {
                leftQuickMoveButton.gameObject.SetActive(true);
                rightQuickMoveButton.gameObject.SetActive(false);

                leftQuickMoveText.text = progressStep.ToString();
            }
            else if (itemListView.GetLastActiveItemIndex() < progressStep)
            {
                leftQuickMoveButton.gameObject.SetActive(false);
                rightQuickMoveButton.gameObject.SetActive(true);

                MissionPassLevelType levelType = myMissionPass.GetLevelType(myMissionPass.CurrentStep);
                rightQuickMoveVisibleToggle.TurnOnByNameInMultiple(levelType.ToString());

                rightQuickMoveText.text = progressStep.ToString();
            }
            else
            {
                leftQuickMoveButton.gameObject.SetActive(false);
                rightQuickMoveButton.gameObject.SetActive(false);
            }
        }

        public void MoveToCurrentProgressItem()
        {
            int progressStep = myMissionPass.CurrentStep;
            itemListView.GoTo(progressStep, quickMoveDuration);
        }

        private void UpdatePageMoveButtons()
        {
            if (itemListView == null || itemListView.IsInitialize == false)
            {
                prevPageMoveButton.SetActive(false);
                nextPageMoveButton.SetActive(false);

                return;
            }

            bool isPrevButtonActive = false;
            int firstItemIndex = 0;

            if (cachedActiveItems.ContainsKey(firstItemIndex))
            {
                var firstTr = cachedActiveItems[firstItemIndex];

                if (firstTr.anchoredPosition.x + firstTr.rect.width * -0.5f + pageActiveOffsetX < itemListView.Content.rect.width * -0.5f)
                {
                    isPrevButtonActive = true;
                }
            }
            else
            {
                isPrevButtonActive = true;
            }

            bool isNextButtonActive = false;
            int lastItemIndex = itemListView.GetCount() - 1;

            if (cachedActiveItems.ContainsKey(lastItemIndex))
            {
                var lastTr = cachedActiveItems[lastItemIndex];

                if (lastTr.anchoredPosition.x - lastTr.rect.width * -0.5f - pageActiveOffsetX > itemListView.Content.rect.width * 0.5f)
                {
                    isNextButtonActive = true;
                }
            }
            else
            {
                isNextButtonActive = true;
            }

            prevPageMoveButton.SetActive(isPrevButtonActive);
            nextPageMoveButton.SetActive(isNextButtonActive);
        }

        public void MoveToPrevPage()
        {
            int targetIndex = itemListView.GetFirstActiveItemIndex() - pageItemCount;
            itemListView.GoTo(targetIndex, pageMoveDuration);
        }

        public void MoveToNextPage()
        {
            int targetIndex = itemListView.GetFirstActiveItemIndex() + pageItemCount;
            itemListView.GoTo(targetIndex, pageMoveDuration);
        }

        private void OnListItemUpdate()
        {
            if (isInit == false)
            {
                return;
            }

            UpdateItemProgressBG();
            UpdateQuickMoveButtons();
            UpdatePageMoveButtons();
        }

        private void UpdateItemList(bool jumpToCurrentStep)
        {
            if (cachendItemContainers == null)
            {
                cachendItemContainers = new Dictionary<RectTransform, MissionPassItemContainer>();
            }

            if (cachedActiveItems == null)
            {
                cachedActiveItems = new Dictionary<int, RectTransform>();
            }

            if (itemListView.IsInitialize == false)
            {
                itemListView.Initialize();
            }

            recentCompleteItemContainer = null;
            UpdateItemProgressBG();

            isInReactive = true;
            itemListView.ItemProvider = this;
            itemListView.ReactivateAllItems();
            isInReactive = false;

            itemListView.onUpdate -= OnListItemUpdate;
            itemListView.onUpdate += OnListItemUpdate;

            if (jumpToCurrentStep)
            {
                if (myMissionPass.AllCleared)
                {
                    itemListView.GoToLast();
                }
                else
                {
                    itemListView.GoTo(myMissionPass.ClearedStep);
                }
            }
        }

        public void JumpToFirst()
        {
            if (itemListView != null)
            {
                itemListView.GoToFirst();
            }
        }

        public int GetItemsCount()
        {
            // 마지막 아이템은 서버 정보와 상관없이 ChestItem이 보여져야 하므로 총 카운트에 1을 더함.
            return myMissionPass.GetItemCount();
        }

        public RectTransform CreateItem()
        {
            return Instantiate(itemContainerRef).GetComponent<RectTransform>();
        }

        public void RemoveItem(int index)
        {

        }

        public RecyclerListView.InitializationItemInfo OnItemInitialize(int index, RectTransform item)
        {
            return new RecyclerListView.InitializationItemInfo(item);
        }

        public void OnItemEnable(int index, RectTransform item)
        {
            MissionPassItemContainer itemContainer = null;

            if (cachendItemContainers.ContainsKey(item))
            {
                itemContainer = cachendItemContainers[item];
            }
            else
            {
                itemContainer = item.GetComponent<MissionPassItemContainer>();
                cachendItemContainers.Add(item, itemContainer);
            }

            if (cachedActiveItems.ContainsKey(index))
            {
                cachedActiveItems[index] = itemContainer.CachedRectTransform;
            }
            else
            {
                cachedActiveItems.Add(index, itemContainer.CachedRectTransform);
            }

            int lastIndex = GetItemsCount() - 1;
            bool isChestItem = index == lastIndex;
            int clearedStep = myMissionPass.ClearedStep;
            if (clearedStep == lastIndex
                && myMissionPass.EnabledBonus == false)
            {
                clearedStep -= 1;
            }

            if (isChestItem)
            {
                itemContainer.SetChest(index,
                                       clearedStep,  
                                       myMissionPass.GetBonusInfo(index),
                                       myMissionPass.EnabledBonus);
            }
            else
            {
                itemContainer.Set(index,
                                  clearedStep,
                                  myMissionPass.GetBonusInfo(index), 
                                  myMissionPass.GetFreeInfo(index), 
                                  myMissionPass.EnabledBonus,
                                  MyInfo.VipClass.Type,
                                  isInReactive);
            }

            itemContainer.onClick = Collect;

            bool isRecentComplete = isChestItem ?
                                    myMissionPass.EnabledBonus && index == clearedStep :
                                    index == clearedStep;


            if (isRecentComplete)
            {
                recentCompleteItemContainer = itemContainer;
            }
        }

        public void OnItemDisable(int index, RectTransform item)
        {
            if (recentCompleteItemContainer != null && item == recentCompleteItemContainer.CachedRectTransform)
            {
                recentCompleteItemContainer = null;
            }

            if (cachedActiveItems.ContainsKey(index))
            {
                cachedActiveItems.Remove(index);
            }
        }

        private void UpdateItemProgressBG()
        {
            if (recentCompleteItemContainer == null)
            {
                if (itemListView != null 
                    && itemListView.IsInitialize 
                    && itemListView.GetLastActiveItemIndex() < myMissionPass.ClearedStep)
                {
                    itemListProgressBG.gameObject.SetActive(true);

                    var tempPos = itemListProgressBG.anchoredPosition;
                    tempPos.x = itemListView.CachedRectTransform.rect.width + 200.0f;
                    itemListProgressBG.anchoredPosition = tempPos;
                }
                else
                {
                    itemListProgressBG.gameObject.SetActive(false);
                }
            }
            else
            {
                itemListProgressBG.gameObject.SetActive(true);

                var tempPos = itemListProgressBG.position;
                tempPos.x = recentCompleteItemContainer.CachedRectTransform.position.x + (recentCompleteItemContainer.CachedRectTransform.sizeDelta.x * 0.005f);
                itemListProgressBG.position = tempPos;
            }
        }

        public void OpenCollectDialog()
        {
            if (isEnd)
            {
                return;
            }

            Popups.MissionPassCollectAll(()=>
            {
                CollectAll();
            }).Async();
        }

        public void Collect(int step, MissionPassItemContainer.ClickEventType clickEventType)
        {
            if (isEnd)
            {
                return;
            }

            StartCoroutine(CollectCoroutine(step, clickEventType));
        }

        private IEnumerator CollectCoroutine(int step, MissionPassItemContainer.ClickEventType clickEventType)
        {
            if (clickEventType == MissionPassItemContainer.ClickEventType.Free)
            {
                var info = myMissionPass.GetFreeInfo(step);

                if (info.status != MyMissionPass.Status.Reward)
                {
                    yield break;
                }
            }
            else
            {
                if (myMissionPass.EnabledBonus)
                {
                    var info = myMissionPass.GetBonusInfo(step);
                    if (info.status != MyMissionPass.Status.Reward)
                    {
                        yield break;
                    }
                }
                else
                {
                    OpenPurchasePopup();
                    yield break;
                }
            }

            PopupSystem.Instance.ShowLoading();
            List<RewardInfo> rewardInfos = new List<RewardInfo>();

            if (debugMode)
            {
                if (clickEventType == MissionPassItemContainer.ClickEventType.Chest)
                {
                    var rewardInfo = RewardInfo.New(RewardType.coin, 9999999, 0, false, ITEM_SKIN_INDEX_BONUS);
                    rewardInfos.Add(rewardInfo);
                }
                else
                {
                    MyMissionPass.ItemInfo itemInfo = new MyMissionPass.ItemInfo();
                    int skinIndex = ITEM_SKIN_INDEX_FREE;

                    if (clickEventType == MissionPassItemContainer.ClickEventType.Free)
                    {
                        itemInfo = myMissionPass.GetFreeInfo(step);
                    }
                    else if (clickEventType == MissionPassItemContainer.ClickEventType.Bonus)
                    {
                        skinIndex = ITEM_SKIN_INDEX_BONUS;
                        itemInfo = myMissionPass.GetBonusInfo(step);
                    }

                    var rewardInfo = ConvertItemInfoToRewardInfo(itemInfo, skinIndex);
                    rewardInfos.Add(rewardInfo);
                }
            }
            else
            {
                yield return WaitForClaimBonusRewardInfo(step, clickEventType, rewardInfo => 
                {
                    if (rewardInfo != null)
                    {
                        rewardInfos.Add(rewardInfo);
                    }
                });
            }

            PopupSystem.Instance.HideLoading();

            if (rewardInfos.Count > 0)
            {
                UndercGameLog.Fobis.ButtonMissionPass(1);

                var titleType = clickEventType == MissionPassItemContainer.ClickEventType.Free ? 
                                MissionPassRewardPopup.TitleType.MissionPassFree : 
                                MissionPassRewardPopup.TitleType.MissionPassBonus;

                // 하나만 획득할 때는 물고기 경험치가 보이게 설정
                yield return MissionPassReward(rewardInfos, titleType, (SimpleRewardItemValueType.Simple | SimpleRewardItemValueType.FishPoint));
            }

            Refresh();
        }

        public void CollectAll()
        {
            if (isEnd)
            {
                return;
            }

            if (myMissionPass.CollectEnabled == false)
            {
                return;
            }

            StartCoroutine(CollectAllCoroutine());
        }

        private IEnumerator CollectAllCoroutine()
        {
            bool debugMode = GetDebugMode();

            if (myMissionPass.EnabledBonus == false && myMissionPass.CollectBonusEnabled && myMissionPass.CollectFreeEnabled)
            {
                List<RewardInfo> rewardFreeInfos = null;
                List<RewardInfo> rewardBonusInfos = null;

                if (debugMode)
                {
                    rewardBonusInfos = GetAllBonusRewardInfosByItemList(false);
                    rewardFreeInfos = GetAllFreeRewardInfosByItemList();
                }
                else
                {
                    yield return WaitForPreviewAllBonusRewardInfos((bonusInfoList, freeInfoList) => 
                    {
                        rewardBonusInfos = bonusInfoList;
                        rewardFreeInfos = freeInfoList;
                    });
                }

                if (rewardFreeInfos.Count > 0 && rewardBonusInfos.Count > 0)
                {
                    UndercGameLog.Fobis.ButtonMissionPass(2);

                    PopupObject<MissionPassFreeRewardPopup> popupObject = null;
                    popupObject = Popups.MissionPassFreeReward(
                        onInit: () => popupObject.GetPopup().RunAsFake = RunAsFake,
                        rewardFreeInfos,
                        rewardBonusInfos,
                        Refresh,
                        GetDebugMode()
                    ).Async();
                    yield return popupObject.WaitForClose();

                    if (debugMode == false)
                    {
                        Refresh();
                    }
                }
            }
            else if ((myMissionPass.EnabledBonus && myMissionPass.CollectEnabled)
                    || (myMissionPass.EnabledBonus == false && myMissionPass.CollectFreeEnabled))
            {
                List<RewardInfo> claimInfoList = null;

                if (debugMode)
                {
                    claimInfoList = GetAllRewardInfosByItemList(true);
                }
                else
                {
                    yield return WaitForClaimAllBonusRewardInfos(infoList => 
                    {
                        claimInfoList = infoList;
                    });
                }

                if (claimInfoList.Count > 0)
                {
                    UndercGameLog.Fobis.ButtonMissionPass(2);

                    var rewardTitleType = myMissionPass.CollectBonusEnabled ? 
                                          MissionPassRewardPopup.TitleType.MissionPassBonus : 
                                          MissionPassRewardPopup.TitleType.MissionPassFree;

                    yield return MissionPassReward(claimInfoList, rewardTitleType, SimpleRewardItemValueType.Simple);

                    if (debugMode == false)
                    {
                        Refresh();
                    }
                }
            }
        }

        private IEnumerator MissionPassReward(List<RewardInfo> rewardInfos, MissionPassRewardPopup.TitleType titleType, SimpleRewardItemValueType valueType)
        {
            PopupObject<MissionPassRewardPopup> popupObject = null;
            popupObject = Popups.MissionPassReward(titleType,
                                                   rewardInfos,
                                                   valueType,
                                                   onInit: () => popupObject.GetPopup().RunAsFake = RunAsFake)
                                .Async();
            yield return popupObject.WaitForClose();
        }

        private List<RewardInfo> GetAllRewardInfosByItemList(bool checkEnabledBonus)
        {
            List<RewardInfo> rewardInfos = new List<RewardInfo>();
            rewardInfos.AddRange(GetAllBonusRewardInfosByItemList(checkEnabledBonus));
            rewardInfos.AddRange(GetAllFreeRewardInfosByItemList());

            return rewardInfos;
        }

        private List<RewardInfo> GetAllFreeRewardInfosByItemList()
        {
            List<MyMissionPass.ItemInfo> itemInfos = new List<MyMissionPass.ItemInfo>();

            for (int i = 0; i < myMissionPass.GetItemCount(); i++)
            {
                var itemInfo = myMissionPass.GetFreeInfo(i);

                if (itemInfo.status == MyMissionPass.Status.Reward)
                {
                    itemInfos.Add(itemInfo);
                }
            }

            itemInfos = myMissionPass.MergeItemInfo(itemInfos);
            List<RewardInfo> rewardInfos = new List<RewardInfo>();

            for (int i = 0; i < itemInfos.Count; i++)
            {
                var itemInfo = itemInfos[i];
                rewardInfos.Add(ConvertItemInfoToRewardInfo(itemInfo, ITEM_SKIN_INDEX_FREE));
            }

            return rewardInfos;
        }

        private List<RewardInfo> GetAllBonusRewardInfosByItemList(bool checkEnabledBonus)
        {
            List<MyMissionPass.ItemInfo> itemInfos = new List<MyMissionPass.ItemInfo>();

            if (checkEnabledBonus == false || myMissionPass.EnabledBonus)
            {
                for (int i = 0; i < myMissionPass.GetItemCount(); i++)
                {
                    var itemInfo = myMissionPass.GetBonusInfo(i);

                    if (itemInfo.status == MyMissionPass.Status.Reward)
                    {
                        itemInfos.Add(itemInfo);
                    }
                }
            }

            itemInfos = myMissionPass.MergeItemInfo(itemInfos);
            List<RewardInfo> rewardInfos = new List<RewardInfo>();

            for (int i = 0; i < itemInfos.Count; i++)
            {
                var itemInfo = itemInfos[i];
                var rewardInfo = ConvertItemInfoToRewardInfo(itemInfo, ITEM_SKIN_INDEX_BONUS);
                rewardInfos.Add(rewardInfo);
            }

            return rewardInfos;
        }

        private RewardInfo ConvertItemInfoToRewardInfo(MyMissionPass.ItemInfo itemInfo, int skinIndex)
        {
            return RewardInfo.New(itemInfo.type, itemInfo.value, itemInfo.extraValue, false, skinIndex);
        }

        private IEnumerator WaitForPreviewAllBonusRewardInfos(Action<List<RewardInfo> /*bonus*/, List<RewardInfo> /*free*/> onCompelte)
        {
            PopupSystem.Instance.ShowLoading();
            var rewardBonusInfos = new List<RewardInfo>();
            var rewardFreeInfos = new List<RewardInfo>();

            IRequest<MissionPassClaimAllResponse> rewardPreviewReq;
            if (RunAsFake == false)
            {
                rewardPreviewReq = NetworkSystem.HTTPRequester.MissionPassClaimAllPreview();
            }
            else
            {
                rewardPreviewReq = FakeHttpRequester.Instance.MissionPassClaimAllPreview();
            }

            yield return rewardPreviewReq.WaitForResponse();

            if (rewardPreviewReq.isSuccess && rewardPreviewReq.data.ret == 0)
            {
                var data = rewardPreviewReq.data;

                if (data.IsBuyValid())
                {
                    rewardBonusInfos.AddRange(ConvertClaimDataToRewardInfoList(data.buy, true));
                }

                if (data.IsFreeValid())
                {
                    rewardFreeInfos.AddRange(ConvertClaimDataToRewardInfoList(data.free, false));
                }
            }

            PopupSystem.Instance.HideLoading();

            onCompelte?.Invoke(rewardBonusInfos, rewardFreeInfos);
        }

        private IEnumerator WaitForClaimBonusRewardInfo(int step, MissionPassItemContainer.ClickEventType clickEventType, Action<RewardInfo> onCompelte)
        {
            PopupSystem.Instance.ShowLoading();
            RewardInfo rewardInfo = null;

            IRequest<MissionPassClaimResponse> rewardReq;
            if (RunAsFake == false)
            {
                rewardReq = NetworkSystem.HTTPRequester.MissionPassClaim(step, (int)clickEventType);
            }
            else
            {
                rewardReq = FakeHttpRequester.Instance.MissionPassClaim(step, (int)clickEventType);
            }

            yield return rewardReq.WaitForResponse();

            if (rewardReq.isSuccess && rewardReq.data.ret == 0)
            {
                var data = rewardReq.data.pass;
                var rewardType = (RewardType)Enum.Parse(typeof(RewardType), data.rwd);
                var rewardValue = data.val;
                var rewardSkin = clickEventType == MissionPassItemContainer.ClickEventType.Free ? 
                                 ITEM_SKIN_INDEX_FREE : 
                                 ITEM_SKIN_INDEX_BONUS;

                rewardInfo = RewardInfo.New(rewardType, rewardValue, 0, false, rewardSkin);
            }

            PopupSystem.Instance.HideLoading();

            onCompelte?.Invoke(rewardInfo);
        }

        private IEnumerator WaitForClaimAllBonusRewardInfos(Action<List<RewardInfo>> onCompelte)
        {
            PopupSystem.Instance.ShowLoading();
            var rewardInfos = new List<RewardInfo>();

            IRequest<MissionPassClaimAllResponse> rewardReq;
            if (RunAsFake == false)
            {
                rewardReq = NetworkSystem.HTTPRequester.MissionPassClaimAll();
            }
            else
            {
                rewardReq = FakeHttpRequester.Instance.MissionPassClaimAll();
            }
            yield return rewardReq.WaitForResponse();

            if (rewardReq.isSuccess && rewardReq.data.ret == 0)
            {
                var data = rewardReq.data;

                if (data.IsBuyValid())
                {
                    rewardInfos.AddRange(ConvertClaimDataToRewardInfoList(data.buy, true));
                }

                if (data.IsFreeValid())
                {
                    rewardInfos.AddRange(ConvertClaimDataToRewardInfoList(data.free, false));
                }
            }

            PopupSystem.Instance.HideLoading();

            onCompelte?.Invoke(rewardInfos);
        }

        private List<RewardInfo> ConvertClaimDataToRewardInfoList(MissionPassClaimData[] dataList, bool isBonus)
        {
            var rewardInfoList = new List<RewardInfo>();

            for (int i = 0; i < dataList.Length; i++)
            {
                var rewardData = dataList[i];
                var rewardType = (RewardType)Enum.Parse(typeof(RewardType), rewardData.rwd);
                var rewardSkin = isBonus ? 1 : 0;
                var rewardInfo = RewardInfo.New(rewardType, rewardData.val, rewardData.val2, false, rewardSkin);

                rewardInfoList.Add(rewardInfo);
            }

            return rewardInfoList;
        }

        public void OpenInfo()
        {
            if (isEnd)
            {
                return;
            }

            Popups.MissionPassInfo().Async();
        }

        public void OpenPurchasePopup()
        {
            OpenPurchasePopup(onPurchaseClose: null);
        }

        public void OpenPurchasePopup(Action onPurchaseClose = null)
        {
            if (isEnd)
            {
                return;
            }

            UndercGameLog.Fobis.ButtonMissionPass(3);

            StartCoroutine(Popups.MissionPassPurchaseCoroutine(
                runAsFake: RunAsFake,
                onClose: () =>
                {
                    Refresh();
                    onPurchaseClose?.Invoke();
                }
            ));
        }

        public RectTransform GetLevelRoot()
        {
            return missionLevelRoot;
        }

        public RectTransform GetUnlockButtonRoot()
        {
            return missionPassUnlockRoot;
        }

        public RectTransform GetActiveRewardItem(int index)
        {
            if (cachedActiveItems.Count <= index)
            {
                return null;
            }

            int targetIndex = int.MaxValue;

            foreach (var item in cachedActiveItems)
            {
                if (item.Key < targetIndex)
                {
                    targetIndex = item.Key;
                }
            }

            if (targetIndex == int.MaxValue)
            {
                return null;
            }

            targetIndex += index;

            if (cachedActiveItems.ContainsKey(targetIndex))
            {
                return cachedActiveItems[targetIndex];
            }
            else
            {
                return null;
            }
        }

        public void PlayTutorial()
        {
            TutorialSystem.Instance.Play(TutorialChapter.MissionPass);
        }

        private MissionPassData ConvertDebugInfoToMissionPassData(DebugInfo debugInfo)
        {
#if !UNITY_EDITOR
            return null;
#endif

            var missionPassData = new MissionPassData();
            missionPassData.end_ts = debugInfo.endTimeStamp;
            missionPassData.season = debugInfo.season;
            missionPassData.step = debugInfo.step;
            missionPassData.curr = debugInfo.currentMissionValue;
            missionPassData.all = debugInfo.goalMissionValue;

            missionPassData.buy = new MissionPassBuyItemData();
            missionPassData.buy.itemid = debugInfo.purchaseID;
            missionPassData.buy.vip_point = debugInfo.vipPoint;
            missionPassData.buy.price = debugInfo.price;
            missionPassData.buy.sale_price = debugInfo.salePrice;
            missionPassData.buy.bonus = debugInfo.bonusEnabled;
            missionPassData.buy.mission_box = debugInfo.missionBoxEnabled;

            missionPassData.free = new MissionPassItemData();
            missionPassData.free.types = new string[debugInfo.itemList.Length];
            missionPassData.free.values = new long[debugInfo.itemList.Length];
            missionPassData.free.status = new int[debugInfo.itemList.Length];

            missionPassData.buy.types = new string[debugInfo.itemList.Length];
            missionPassData.buy.values = new long[debugInfo.itemList.Length];
            missionPassData.buy.status = new int[debugInfo.itemList.Length];

            for (int i = 0; i < debugInfo.itemList.Length; i++)
            {
                var info = debugInfo.itemList[i];

                missionPassData.free.types[i] = info.freeType.ToString();
                missionPassData.free.values[i] = info.freeValue;
                missionPassData.free.status[i] = (int)info.freeStatus;

                missionPassData.buy.types[i] = info.bonusType.ToString();
                missionPassData.buy.values[i] = info.bonusValue;
                missionPassData.buy.status[i] = (int)info.bonusStatus;
            }

            return missionPassData;
        }
    }
}
