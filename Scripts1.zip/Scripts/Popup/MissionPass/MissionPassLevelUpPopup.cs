using Gaga;
using Underc.User;
using UnityEngine;

namespace Underc.Popup
{
    public class MissionPassLevelUpPopup : InstantOpenAnimationPopup
    {
        [Header("Level")]
        [SerializeField] private GameObjectVisibleToggle levelVisibleToggle;

        public void Open(int nextLevel)
        {
            base.Open(nextLevel.ToString());

            MissionPassLevelType levelType = MyInfo.MissionPass.GetLevelType(nextLevel);
            levelVisibleToggle.TurnOnByNameInMultiple(levelType.ToString());
        }
    }
}
