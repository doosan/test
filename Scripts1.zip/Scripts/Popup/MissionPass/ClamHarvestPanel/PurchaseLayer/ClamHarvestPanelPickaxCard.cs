using Gaga;
using Gaga.Util;
using System;
using TMPro;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Popup
{
    public class ClamHarvestPanelPickaxCard : MonoBehaviour
    {
        [SerializeField] private GameObjectVisibleToggle pickaxVisibleToggle;
        [SerializeField] private AnimatorParser collectAnimation;
        [SerializeField] private AnimatorParser startAnimation;
        [SerializeField] private TextMeshProUGUI countText;
        [SerializeField] private TextMeshProUGUI priceText;
        [SerializeField] private Button buyButton;

        public RectTransform CachedTransform
        { 
            get
            {
                if (cachedTransform == null)
                {
                    cachedTransform = GetComponent<RectTransform>();
                }
                return cachedTransform;
            }
        }
        private RectTransform cachedTransform;    

        public bool IsSelected
        {
            get; 
            private set;
        }

        public AnimatorParser CollectAnimation
        {
            get => collectAnimation;
        }

        public AnimatorParser StartAnimation
        {
            get => startAnimation;
        }
        
        public ClamHarvestPurchaseItemInfo PurchaseItemInfo
        {
            get;
            private set;
        }

        private Action<ClamHarvestPurchaseItemInfo> onBuy;

        public void Init(Action<ClamHarvestPurchaseItemInfo> onBuy)
        {
            this.onBuy = onBuy;
        }

        public void Reset()
        {
            BuyButtonInteractable(true);
            IsSelected = false;
            countText.text = "";
            priceText.text = "";
        }

        public void UpdateContent(ClamHarvestClamType clamType, 
                                  ClamHarvestPurchaseItemInfo purchaseItemInfo)
        {
            PurchaseItemInfo = purchaseItemInfo;

            pickaxVisibleToggle.TurnOnByNameInMultiple(clamType.ToString());
            countText.text = purchaseItemInfo.val.ToString();
            priceText.text = purchaseItemInfo.priceCurrency;
            startAnimation.SetTrigger();
        }

        public void Buy()
        {
            IsSelected = true;
            onBuy?.Invoke(PurchaseItemInfo);
            BuyButtonInteractable(false);
        }

        public void BuyButtonInteractable(bool value)
        {
            buyButton.interactable = value;
        }
    }
}