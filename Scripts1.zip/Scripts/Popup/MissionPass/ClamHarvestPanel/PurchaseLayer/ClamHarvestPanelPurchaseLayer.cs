using Gaga.Sound;
using Gaga.Util;
using System;
using System.Collections;
using System.Collections.Generic;
using Underc.Effect;
using Underc.User;
using UnityEngine;

namespace Underc.Popup
{
    public class ClamHarvestPanelPurchaseLayer : BaseClamHarvestPanelLayer
    {
        [SerializeField] private float itemPosInterval = 334f;
        [SerializeField] private float itemOpenDelay = .25f;
        [SerializeField] private float itemOpenInterval = .5f;
        [SerializeField] private float closeDelay = .5f;
        [SerializeField] private List<ClamHarvestPanelPickaxCard> pickaxCards;
        [SerializeField] private AnimatorParser closeAnimation;
        [SerializeField] private SoundPlayer openPickaxSound;

        public Action<ClamHarvestPurchaseItemInfo> OnBuy;
        public bool IsOpened;

        public override void Init()
        {
            foreach (ClamHarvestPanelPickaxCard pickaxCard in pickaxCards)
            {
                pickaxCard.Init(OnBuy);
            }
        }

        public override void Reset(bool isBeinning)
        {
            foreach (ClamHarvestPanelPickaxCard pickaxCard in pickaxCards)
            {
                pickaxCard.Reset();
                pickaxCard.gameObject.SetActive(false);
            }

            IsOpened = false;
        }

        public void BuyButtonsInteractable(bool value)
        {
            foreach (ClamHarvestPanelPickaxCard pickaxCard in pickaxCards)
            {
                pickaxCard.BuyButtonInteractable(value);
            }
        }

        public override IEnumerator UpdateContent()
        {
            yield return new WaitForSeconds(itemOpenDelay);
            ClamHarvestClamInfo SelectedClamInfo = ClamHarvest.SelectedClamInfo;
            List<ClamHarvestPurchaseItemInfo> purchaseItemInfos = SelectedClamInfo.purchaseItemInfos;
            ClamHarvestPanelPickaxCard pickaxCard = null;
            for (int i = 0; i < purchaseItemInfos.Count; i++)
            {
                ClamHarvestClamType clamType = SelectedClamInfo.clamType;
                pickaxCard = pickaxCards[i];
                pickaxCard.gameObject.SetActive(true);

                float posX = i * itemPosInterval - (purchaseItemInfos.Count - 1) * itemPosInterval / 2;
                Vector2 originPosition = pickaxCard.CachedTransform.anchoredPosition;
                pickaxCard.CachedTransform.anchoredPosition = new Vector2(posX, originPosition.y);

                yield return new WaitForSeconds(itemOpenInterval * i);

                ClamHarvestPurchaseItemInfo itemInfo = purchaseItemInfos[i];
                pickaxCard.UpdateContent(clamType, itemInfo);
            }

            if (pickaxCard != null)
            {
                yield return pickaxCard.StartAnimation.WaitForDuration();
            }

            IsOpened = true;
            yield break;
        }

        public IEnumerator CollectPickax(Vector3 targetPosition, Action onEffectArrival)
        {
            IsOpened = false;

            ClamHarvestPanelPickaxCard selectedPickaxCard = null;
            foreach (ClamHarvestPanelPickaxCard pickaxCard in pickaxCards)
            {
                if (pickaxCard.gameObject.activeInHierarchy == false)
                {
                    continue;
                }

                pickaxCard.CollectAnimation.SetTrigger();
                if (pickaxCard.IsSelected)
                {
                    selectedPickaxCard = pickaxCard;
                }
            }

            string pickaxType = "";
            int pickaxCount = 0;
            Vector3 pickaxPosition = Vector3.zero;
            if (selectedPickaxCard != null)
            {
                pickaxType = selectedPickaxCard.PurchaseItemInfo.rewardType.ToString();
                pickaxCount = selectedPickaxCard.PurchaseItemInfo.val;
                pickaxPosition = selectedPickaxCard.transform.position;
                yield return selectedPickaxCard.CollectAnimation.WaitForDuration();
            }

            EffectSystem.Instance.Pickax(
                pickaxType: pickaxType,
                count: pickaxCount,
                startPosition: pickaxPosition,
                endPosition: targetPosition,
                onFirstArrived: onEffectArrival
            );
            
            if (closeDelay > 0)
            {
                yield return new WaitForSeconds(closeDelay);
            }
            closeAnimation.SetTrigger();
            yield return closeAnimation.WaitForDuration();
        }

        public override bool CanBack()
        {
            return IsOpened;
        }
    }
}
