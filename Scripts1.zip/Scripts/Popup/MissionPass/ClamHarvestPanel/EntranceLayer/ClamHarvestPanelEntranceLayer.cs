using Gaga;
using Gaga.Sound;
using Gaga.System;
using Gaga.Util;
using System;
using System.Collections;
using TMPro;
using Underc.User;
using UnityEngine;

namespace Underc.Popup
{
    public enum ClamHarvestPanelEntranceLayerAnimState
    { 
        None,
        ButtonOn,
        ButtonOnImmed,
        ButtonOff,
    }

    public class ClamHarvestPanelEntranceLayer : BaseClamHarvestPanelLayer
    {
        [SerializeField] private Animator animator;

        [Header("Day")]
        [SerializeField] private GameObjectVisibleToggle timeVisibleToggle;
        [SerializeField] private TextMeshProUGUI startRemainingTimeText;
        [SerializeField] private TextMeshProUGUI endRemainingTimeText;

        [Header("Clams")]
        [SerializeField] private float itemOpenInterval = .1f;
        [SerializeField] private ClamHarvestPanelClamBoard goldClamBoard;
        [SerializeField] private ClamHarvestPanelClamBoard silverClamBoard;
        [SerializeField] private Transform rewardItemPoolRoot;
        [SerializeField] private SimpleRewardItem rewardItemRef;

        public Action<ClamHarvestClamType> OnPlayClick
        {
            private get; 
            set;
        }

        public ClamHarvestClamType SelectedClamType
        {
            get; private set;
        }

        private GameObjectPool<SimpleRewardItem> rewardItemPool;

        private ClamHarvestTimeState currDayState;
        private ClamHarvestTimeState prevDayState;

        private ClamHarvestPanelEntranceLayerAnimState currAnimState;
        private ClamHarvestPanelEntranceLayerAnimState prevAnimState;

        private bool playButtonOnOnce;
        private bool playBubbleSoundOnce;

        private bool IsAnimStateChanged
        {
            get => prevAnimState != ClamHarvestPanelEntranceLayerAnimState.None
                   && currAnimState != prevAnimState;
        }

        private void OnEnable()
        {
            if (ClamHarvest.ReadDayState() != ClamHarvestTimeState.TimesUp)
            {
                ClamHarvest.onTimeUpdate.AddListener(OnTimeUpdate);
            }
        }

        private void OnDisable()
        {
            ClamHarvest.onTimeUpdate.RemoveListener(OnTimeUpdate);

            SetDayState(ClamHarvestTimeState.None);
            SetAnimState(ClamHarvestPanelEntranceLayerAnimState.ButtonOff);
        }

        public override void Init()
        {
            rewardItemRef.gameObject.SetActive(false);
            rewardItemPool = rewardItemRef.CreatePool(
                rootName: "RewardItemPool",
                parent: rewardItemPoolRoot,
                size: 6
            );

            goldClamBoard.Init();
            silverClamBoard.Init();

            SetDayState(ClamHarvestTimeState.None);
            SetAnimState(ClamHarvestPanelEntranceLayerAnimState.ButtonOff);
        }

        public override void Reset(bool isBeginning)
        {
            if (isBeginning)
            {
                playButtonOnOnce = false;
                playBubbleSoundOnce = false;
            }

            startRemainingTimeText.text = "";
            endRemainingTimeText.text = "";

            goldClamBoard.Reset();
            silverClamBoard.Reset();
        }

        public override IEnumerator UpdateContent()
        {
            OnTimeUpdate();
            
            goldClamBoard.UpdateContent(ClamHarvest.GoldClamInfo, 
                                        rewardItemPool,
                                        itemOpenInterval,
                                        OnPlayClick);
            silverClamBoard.UpdateContent(ClamHarvest.SilverClamInfo, 
                                          rewardItemPool,
                                          itemOpenInterval,
                                          OnPlayClick);

            yield break;
        }

        private void UpdateAnimState()
        {
            ClamHarvestPanelEntranceLayerAnimState nextAnimState = currAnimState;
            if (currDayState == ClamHarvestTimeState.InProgress)
            {
                if (prevDayState == ClamHarvestTimeState.Wait
                    || prevDayState == ClamHarvestTimeState.None)
                {
                    nextAnimState = playButtonOnOnce == false ?
                                    ClamHarvestPanelEntranceLayerAnimState.ButtonOn :
                                    ClamHarvestPanelEntranceLayerAnimState.ButtonOnImmed;
                    playButtonOnOnce = true;
                }
            }
            else if (currDayState == ClamHarvestTimeState.TimesUp)
            {
                if (prevDayState == ClamHarvestTimeState.InProgress)
                {
                    nextAnimState = ClamHarvestPanelEntranceLayerAnimState.ButtonOff;
                }
            }

            SetAnimState(nextAnimState);
        }

        private void SetAnimState(ClamHarvestPanelEntranceLayerAnimState nextAnimState)
        {
            prevAnimState = currAnimState;
            currAnimState = nextAnimState;
            //Debug.Log("==== SetAnimState : " + prevAnimState + " -> " + currAnimState);
        }

        private void OnTimeUpdate()
        {
            SetDayState(ClamHarvest.ReadDayState());
            UpdateAnimState();

            /// Update Time Visible
            if (currDayState == ClamHarvestTimeState.Wait)
            {
                timeVisibleToggle.TurnOnByNameInMultiple(ClamHarvestTimeState.Wait.ToString());
            }
            else if (currDayState == ClamHarvestTimeState.InProgress
                     || currDayState == ClamHarvestTimeState.TimesUp)
            {
                timeVisibleToggle.TurnOnByNameInMultiple(ClamHarvestTimeState.InProgress.ToString());
            }

            startRemainingTimeText.text = (ClamHarvest.StartRemainingSec > 0) ?
                                          ClamHarvest.StartRemainingSec.ToSummaryDHMS() :
                                          "TIME'S UP";
            endRemainingTimeText.text = (ClamHarvest.EndRemainingSec > 0) ?
                                        ClamHarvest.EndRemainingSec.ToSummaryDHMS() :
                                        "TIME'S UP";

            if (IsAnimStateChanged)
            {
                animator.SetTrigger(currAnimState.ToString());
            }
        }

        private void SetDayState(ClamHarvestTimeState nextDayState)
        {
            prevDayState = currDayState;
            currDayState = nextDayState;
        }
    }
}