using Gaga;
using Gaga.System;
using Gaga.Util;
using System;
using System.Collections.Generic;
using TMPro;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Popup
{
    public class ClamHarvestPanelClamBoard : MonoBehaviour
    {
        [SerializeField] private GameObjectVisibleToggle clamStateVisbleToggle;
        [SerializeField] private RectTransform rewardLayoutGroup;
        [SerializeField] private TextMeshProUGUI pickaxText;
        [SerializeField] private Animator animator;

        [Header("Button")]
        [SerializeField] private List<Button> playButtons;
        [SerializeField] private TextMeshProUGUI buttonText;
        [SerializeField] private string playMessage = "LET'S PLAY";
        [SerializeField] private string collectedMessage = "COLLECTED";

        private List<SimpleRewardItem> rewardItems;
        private ClamHarvestClamInfo clamInfo;
        private GameObjectPool<SimpleRewardItem> rewardItemPool;
        private Action<ClamHarvestClamType> onPlayClick;

        private void OnDisable()
        {
            if (rewardItems != null)
            {
                foreach (SimpleRewardItem rewardItem in rewardItems)
                {
                    rewardItem.Reset();
                    rewardItemPool.Return(rewardItem);
                }
                rewardItems.Clear();
            }
        }

        public void Init()
        {
            rewardItems = new List<SimpleRewardItem>();
        }

        public void Reset()
        {
            pickaxText.text = "";
        }

        public void PlayClick()
        {
            onPlayClick?.Invoke(clamInfo.clamType);
        }

        public void UpdateContent(ClamHarvestClamInfo clamInfo, 
                                  GameObjectPool<SimpleRewardItem> rewardItemPool,
                                  float itemOpenInterval,
                                  Action<ClamHarvestClamType> onPlayClick)
        {
            this.clamInfo = clamInfo;
            this.rewardItemPool = rewardItemPool;
            this.onPlayClick = onPlayClick;

            pickaxText.text = clamInfo.pickax.ToString();

            // 아이템 등록은 팝업을 처음 열 때 한 번만
            string dimmedState = "Normal";
            if (clamInfo.IsAllClamsPicked)
            {
                dimmedState = "Dimmed";
                itemOpenInterval = 0f;
            }

            if (rewardItems.Count == 0)
            {
                for (int i = 0; i < clamInfo.rewardableInfos.Count; i++)
                {
                    RewardInfo rewardInfo = clamInfo.rewardableInfos[i];
                    SimpleRewardItem rewardItem = rewardItemPool.Get();
                    rewardItem.UpdateContent(rewardInfo);
                    rewardItem.SetOpenTrigger(openTrigger: dimmedState, 
                                              openInterval: itemOpenInterval * i,
                                              allowSameTrigger: false);
                    rewardItem.transform.SetParent(rewardLayoutGroup, false);
                    
                    rewardItems.Add(rewardItem);
                }
            }
            
            animator.SetTrigger(dimmedState);

            string clamState = clamInfo.IsAllClamsPicked ? "Open" : "Close";
            clamStateVisbleToggle.TurnOnByNameInMultiple(clamState);

            foreach (Button playButton in playButtons)
            {
                playButton.interactable = clamInfo.IsAllClamsPicked == false;
            }
            buttonText.text = clamInfo.IsAllClamsPicked == false ?
                              playMessage :
                              collectedMessage;
        }
    }
}