using Gaga.System;
using System;
using System.Collections;
using System.Collections.Generic;
using Underc.Net;
using Underc.Net.Client;
using Underc.UI;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Popup
{
    public enum ClamHarvestPanelState
    {
        None,
        LoadClamHarvest,
        LoadHarvest,
        LoadPurchase,
        PurchaseLayerOpenDelay,
        UpdateContent,
        Collect,
        RemoveLatestLayer,
        Refresh,
        CollectPurchaseItem,
        CheckVipLevelUp,
        LoadCasinoBonus,
        Release
    }

    [Flags]
    public enum ClamHarvestPanelLayerState
    {
        None = 0,
        Entrance = 1,
        Picking = 2,
        Message = 4,
        Purchase = 8,
    }

    public enum ClamHarvestPanelMessageType
    {
        ReturnLater,
        TimeIsOver
    }

    public class ClamHarvestPanel : BaseMissionPassContentPanel
    {
        [SerializeField] private Button closeButton;
        [SerializeField] private Button infoButton;

        [Header("Layer")]
        [SerializeField] private ClamHarvestPanelEntranceLayer entranceLayer;
        [SerializeField] private ClamHarvestPanelPickingLayer pickingLayer;
        [SerializeField] private ClamHarvestPanelPurchaseLayer purchaseLayer;
        [SerializeField] private ClamHarvestPanelMessageLayer messageLayer;

        public ClamHarvestPanelPurchaseLayer PurchaseLayer
        {
            get => purchaseLayer;
        }

        public ClamHarvestPanelPickingLayer PickingLayer
        {
            get => pickingLayer;
        }

        public override TabTransformInfo TabTransformInfo
        {
            set
            {
                base.TabTransformInfo = value;

                pickingLayer.TabTransformInfo = value;
            }
            protected get
            {
                return base.TabTransformInfo;
            }
        }

        private Dictionary<ClamHarvestPanelLayerState, BaseClamHarvestPanelLayer> allLayers;
        private List<ClamHarvestPanelLayerState> layerStates;
        private StateQueue<ClamHarvestPanelState> stateQueue;

        private MyClamHarvest clamHarvest;
        private bool blinkPickaxIsEmtpy = false;
        private bool isReleased;

        public override void Init()
        {
            stateQueue = new StateQueue<ClamHarvestPanelState>(host: this);
            layerStates = new List<ClamHarvestPanelLayerState>();

            allLayers = new Dictionary<ClamHarvestPanelLayerState, BaseClamHarvestPanelLayer>()
            {
                { ClamHarvestPanelLayerState.Entrance, entranceLayer },
                { ClamHarvestPanelLayerState.Picking, pickingLayer },
                { ClamHarvestPanelLayerState.Purchase, purchaseLayer },
                { ClamHarvestPanelLayerState.Message, messageLayer }
            };

            entranceLayer.OnPlayClick = OnPlayClick;
            pickingLayer.OnPick = OnPick;
            pickingLayer.OnGotcha = OnGotcha;
            pickingLayer.OnCollect = OnCollect;
            purchaseLayer.OnBuy = OnBuy;
            messageLayer.OnClose = OnMessageClose;
            foreach (BaseClamHarvestPanelLayer layer in allLayers.Values)
            {
                layer.Init();
            }

            clamHarvest = MyInfo.ClamHarvest;
        }

        public override void Reset()
        {
            foreach (KeyValuePair<ClamHarvestPanelLayerState, BaseClamHarvestPanelLayer> pair in allLayers)
            {
                pair.Value.Reset(isBeinning: true);
                pair.Value.gameObject.SetActive(pair.Key == ClamHarvestPanelLayerState.Entrance); // 입장 화면만 미리 켜놓음
            }

            infoButton.gameObject.SetActive(false);
            closeButton.gameObject.SetActive(false);

            stateQueue.Reset();
            isReleased = false;
        }

        public override IEnumerator UpdateContent(UpdateContentType updateType)
        {
            if (updateType == UpdateContentType.First)
            {
                layerStates.Clear();
                layerStates.Add(ClamHarvestPanelLayerState.Entrance);
            }

            stateQueue.Add(ClamHarvestPanelState.UpdateContent);

            yield break;
        }

        private void OnPlayClick(ClamHarvestClamType clamType)
        {
            if (clamHarvest.StartRemainingSec > 0)
            {
                OpenMessage(ClamHarvestPanelMessageType.ReturnLater);
            }
            else if (clamHarvest.EndRemainingSec <= 0)
            {
                OpenMessage(ClamHarvestPanelMessageType.TimeIsOver);
            }
            else
            {
                clamHarvest.UpdateSelectedClamInfo(clamType);
                layerStates.Add(ClamHarvestPanelLayerState.Picking);

                stateQueue.Add(ClamHarvestPanelState.UpdateContent);
            }
        }

        private void OnCollect()
        {
            UpdateMainButtons(closeButtonVisible: false, infoButtonVisible: false);
            stateQueue.Add(ClamHarvestPanelState.Collect);
            stateQueue.Add(ClamHarvestPanelState.RemoveLatestLayer);
            stateQueue.Add(ClamHarvestPanelState.Refresh);
        }

        private void OnBuy(ClamHarvestPurchaseItemInfo info)
        {
            stateQueue.Add(ClamHarvestPanelState.LoadPurchase, info);
        }

        private void OnMessageClose()
        {
            stateQueue.Add(ClamHarvestPanelState.RemoveLatestLayer);
        }

        private void OnGotcha()
        {
            /// 리워드 연출 중일 때 눌러지지 않도록 막음
            closeButton.interactable = false;
        }

        private void OnPick(int clamIndex)
        {
            /// 시간이 만료되지 않았을 때만 다음 작업을 수행
            if (clamHarvest.EndRemainingSec > 0)
            {
                clamHarvest.UpdateSelectedClamIndex(clamIndex);

                if (clamHarvest.SelectedClamInfo.pickax <= 0
                    && clamHarvest.SelectedClamInfo.purchaseItemInfos != null
                    && clamHarvest.SelectedClamInfo.purchaseItemInfos.Count > 0)
                {
                    if (GetLatestLayerState() != ClamHarvestPanelLayerState.Purchase)
                    {
                        blinkPickaxIsEmtpy = true;

                        layerStates.Add(ClamHarvestPanelLayerState.Purchase);
                        stateQueue.Add(ClamHarvestPanelState.UpdateContent);
                    }
                }
                else
                {
                    stateQueue.Add(ClamHarvestPanelState.LoadHarvest);
                }
            }
            else
            {
                OpenMessage(ClamHarvestPanelMessageType.TimeIsOver);
            }
        }

        private IEnumerator LoadHarvestCoroutine()
        {
            Popups.ShowLoading();

            MyClamHarvest clamHarvest = MyInfo.ClamHarvest;
            int clamIndex = clamHarvest.SelectedClamIndex;
            ClamHarvestClamType clamType = clamHarvest.SelectedClamInfo.clamType;

            IRequest<HarvestResponse> req;
            if (RunAsFake == false)
            {
                req = NetworkSystem.HTTPRequester.Harvest(clamType, clamIndex);
            }
            else
            {
                req = FakeHttpRequester.Instance.Harvest(clamType, clamIndex);
            }
            yield return req.WaitForResponse();
            Popups.HideLoading();

            if (req.isSuccess)
            {
                MyInfo.ClamHarvest.Update(req.data.data);
                MyInfo.MissionPass.UpdateStep(req.data.data.mission_pass_step);

                ShowPurchaseLayer();
            }
            else
            {
                OnError?.Invoke(req.data.error);
            }

            yield break;
        }

        private IEnumerator LoadPurchaseCoroutine(object param)
        {
            ClamHarvestPurchaseItemInfo info = param as ClamHarvestPurchaseItemInfo;
            if (RunAsFake == false)
            {
                PurchaseSystem purchaseSystem = PurchaseSystem.Instance;
                yield return purchaseSystem.Purchase(itemID: info.itemID,
                                                     showReward: false);
                if (purchaseSystem.IsFailed == true)
                {
                    PurchaseLayer.BuyButtonsInteractable(true);
                    yield break;
                }
            }
            else
            {
                yield return FakeHttpRequester.Instance
                                              .PurchasePickax(info.rewardType, info.val)
                                              .WaitForResponse();
            }

            stateQueue.AddSubstitute(ClamHarvestPanelState.UpdateContent, ClamHarvestPanelState.CollectPurchaseItem);
            OnRefresh?.Invoke();
        }

        private IEnumerator CollectPurchaseItemCoroutine()
        {
            bool waitForEffectArrival = true;
            yield return PurchaseLayer.CollectPickax(
                targetPosition: PickingLayer.PickaxBoardPosition,
                onEffectArrival: () => waitForEffectArrival = false
            );

            while (waitForEffectArrival)
            {
                yield return null;
            }

            yield return RemoveLatestLayerCoroutine();
        }

        private void OpenMessage(ClamHarvestPanelMessageType messageType)
        {
            if (layerStates.Contains(ClamHarvestPanelLayerState.Message) == false)
            {
                messageLayer.MessageVisibleToggle.TurnOnByNameInMultiple(messageType.ToString());
                layerStates.Add(ClamHarvestPanelLayerState.Message);
                stateQueue.Add(ClamHarvestPanelState.UpdateContent);
            }
        }

        public void OpenInfo()
        {
            Popups.ClamHarvestInfo()
                  .Async();
        }

        private ClamHarvestPanelLayerState RemoveLatestLayerState()
        {
            ClamHarvestPanelLayerState latestLayerState = GetLatestLayerState();
            if (layerStates.Count > 0)
            {
                Debug.Log($"==== RemoveLatestLayerState() : {latestLayerState}, {layerStates.Count - 1}");
                layerStates.Remove(latestLayerState);
            }

            return latestLayerState;
        }

        private ClamHarvestPanelLayerState GetLatestLayerState()
        {
            ClamHarvestPanelLayerState latestLayerState = ClamHarvestPanelLayerState.None;
            if (layerStates.Count > 0)
            {
                latestLayerState = layerStates[layerStates.Count - 1];
            }
            return latestLayerState;
        }

        private IEnumerator CollectCoroutine()
        {
            yield return pickingLayer.CollectCoroutine();
        }

        private IEnumerator UpdateContentCoroutine()
        {
            foreach (KeyValuePair<ClamHarvestPanelLayerState, BaseClamHarvestPanelLayer> pair in allLayers)
            {
                ClamHarvestPanelLayerState layerState = pair.Key;
                BaseClamHarvestPanelLayer layer = pair.Value;

                // Picking 레이어가 켜져 있을 때는 Entrance 레이어를 꺼 둠
                bool isEntranceLayerInvisible = layerState == ClamHarvestPanelLayerState.Entrance
                                                && layerStates.Contains(ClamHarvestPanelLayerState.Picking);

                bool isLayerInvisible = layerStates.Contains(layerState) == false
                                        || isEntranceLayerInvisible == true;
                if (isLayerInvisible == false)
                {
                    Debug.Log($"==== UpdateContent() : {layerState}");
                }
                
                if (isLayerInvisible == false
                    && layerState == ClamHarvestPanelLayerState.Purchase)
                {
                    if (blinkPickaxIsEmtpy)
                    {
                        blinkPickaxIsEmtpy = false;
                        pickingLayer.IsInteractable = false;
                        yield return pickingLayer.BlinkPickaxIsEmpty();
                    }

                    yield return new WaitForSeconds(layer.LayerOpenDelay);
                    pickingLayer.IsInteractable = true;
                }

                layer.gameObject.SetActive(isLayerInvisible == false);
                if (layer.gameObject.activeSelf)
                {
                    bool closeButtonVisible = layerState == ClamHarvestPanelLayerState.Entrance
                                              || layerState == ClamHarvestPanelLayerState.Picking
                                              || layerState == ClamHarvestPanelLayerState.Message
                                              || layerState == ClamHarvestPanelLayerState.Purchase;
                    bool infoButtonVisible = layerState == ClamHarvestPanelLayerState.Entrance
                                             || layerState == ClamHarvestPanelLayerState.Message;
                    UpdateMainButtons(closeButtonVisible, infoButtonVisible);
                    layer.Reset(isBeinning: false);
                    yield return layer.UpdateContent();
                }
            }
            yield break;
        }

        private void UpdateMainButtons(bool closeButtonVisible, bool infoButtonVisible)
        {
            closeButton.gameObject.SetActive(closeButtonVisible);
            closeButton.interactable = closeButtonVisible;

            infoButton.gameObject.SetActive(infoButtonVisible);
            infoButton.interactable = infoButtonVisible;
        }

        private IEnumerator LoadCasinoBonusCoroutine()
        {
            Popups.ShowLoading(false);
            var casinoBonusReq = NetworkSystem.HTTPRequester.CasinoBonus();
            yield return casinoBonusReq.WaitForResponse();
            Popups.HideLoading();

            if (casinoBonusReq.isSuccess == true)
            {
                NetworkSystem.HTTPHandler.Do(casinoBonusReq.data);
            }
            yield break;
        }

        public void ShowPurchaseLayer()
        {
            if (clamHarvest.SelectedClamInfo.purchaseItemInfos?.Count > 0)
            {
                layerStates.Add(ClamHarvestPanelLayerState.Purchase);
            }

            stateQueue.Add(ClamHarvestPanelState.UpdateContent);
        }

        private IEnumerator RefreshCoroutine()
        {
            OnRefresh?.Invoke();
            yield break;
        }

        private IEnumerator RemoveLatestLayerCoroutine()
        {
            RemoveLatestLayerState();
            if (layerStates.Count == 0)
            {
                stateQueue.Add(ClamHarvestPanelState.LoadCasinoBonus);
                stateQueue.Add(ClamHarvestPanelState.Release);
            }
            else
            {
                stateQueue.Add(ClamHarvestPanelState.UpdateContent);
                stateQueue.Add(ClamHarvestPanelState.CheckVipLevelUp);
            }
            yield break;
        }

        private IEnumerator CheckVipLevelUpCoroutine()
        {
            if (MyInfo.VipClass.ConsumeLevelUp())
            {
                yield return Popups.VipLevelUpCoroutine();
            }

            yield break;
        }

        private IEnumerator ReleaseCoroutine()
        {
            isReleased = true;
            OnClose?.Invoke();
            yield break;
        }

        public override bool Close()
        {
            if (isReleased == false)
            {
                if (GetLatestLayerState() == ClamHarvestPanelLayerState.Picking
                    && pickingLayer.IsCollectable)
                {
                    pickingLayer.Collect();
                }
                else if (stateQueue.Contains(ClamHarvestPanelState.RemoveLatestLayer) == false)
                {
                    stateQueue.Add(ClamHarvestPanelState.RemoveLatestLayer);
                }
            }

            return isReleased;
        }

        public override bool CanBack()
        {
            bool result = Popups.IsLoading() == false;
            foreach (BaseClamHarvestPanelLayer layer in allLayers.Values)
            {
                if (layer.gameObject.activeInHierarchy)
                {
                    result &= layer.CanBack(); // 모두 통과되어야 함
                }
            }

            return result;
        }
    }
}
