using System.Collections;
using Underc.User;
using UnityEngine;

namespace Underc.Popup
{
    public class BaseClamHarvestPanelLayer : MonoBehaviour
    {
        [SerializeField] private float layerOpenDelay = 0.0f;

        public float LayerOpenDelay
        {
            get => layerOpenDelay;
        }

        protected MyClamHarvest ClamHarvest
        {
            get
            {
                if (clamHarvest == null)
                {
                    clamHarvest = MyInfo.ClamHarvest;
                }
                return clamHarvest;
            }
        }
        protected MyClamHarvest clamHarvest;

        public virtual bool CanBack()
        {
            return true;
        }

        public virtual void Init()
        {
        }

        public virtual void Reset(bool isBeinning)
        {

        }

        public virtual IEnumerator UpdateContent()
        {
            yield break;
        }
    }
}