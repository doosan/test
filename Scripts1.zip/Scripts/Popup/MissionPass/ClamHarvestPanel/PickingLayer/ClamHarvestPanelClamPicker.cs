using Gaga;
using System;
using UnityEngine;

namespace Underc.Popup
{
    public enum ClamHarvestPanelClamPickerState
    {
        None,
        Close,
        Open,
    }

    public class ClamHarvestPanelClamPicker : MonoBehaviour
    {
        [SerializeField] private GameObjectVisibleToggle visibleToggle;

        public RectTransform CachedTransform
        { 
            get
            {
                if (cachedTransform == null)
                {
                    cachedTransform = GetComponent<RectTransform>();
                }
                return cachedTransform;
            }
        }
        private RectTransform cachedTransform;

        public bool Interactable
        {
            set;
            private get;
        }

        public GameObjectVisibleToggle VisibleToggle
        {
            get => visibleToggle;
        }

        private Animator ActiveAnimator
        {
            get => visibleToggle.ActiveObject.GetComponent<Animator>();
        }

        public ClamHarvestPanelClamPickerState State;
        
        private int clamIndex;
        private Action<int> onPick;

        public void Init(int clamIndex,  Action<int> onPick)
        {
            this.clamIndex = clamIndex;
            this.onPick = onPick;
        }

        public void SetState(ClamHarvestPanelClamPickerState state, string trigger = "")
        {
            State = state;

            if (string.IsNullOrEmpty(trigger) == false)
            {
                ActiveAnimator.SetTrigger(trigger);
            }
        }

        public void Pick()
        {
            if (State == ClamHarvestPanelClamPickerState.Close
                && Interactable)
            {
                onPick?.Invoke(clamIndex);
            }
        }
    }
}
