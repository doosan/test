using Gaga;
using System.Collections.Generic;
using TMPro;
using Underc.UI;
using UnityEngine;

namespace Underc.Popup
{
    public class PickaxBoardItem
    {
        public const string TRIGGER_EMPTY = "Empty";
        public const string TRIGGER_USE = "Use";

        public GameObject gameObject;
        public TextMeshProUGUI text;
        public Animator animator;
        public SetNumberPlayerTM numberPlayer;
    }

    public class ClamHarvestPanelPickaxBoard : MonoBehaviour
    {
        [SerializeField] private GameObjectVisibleToggle visibleToggle;
        private Dictionary<string, PickaxBoardItem> pickaxBoardItems;
        public PickaxBoardItem ActiveItem
        {
            get;
            private set;
        }

        public GameObjectVisibleToggle VisibleToggle
        {
            get => visibleToggle;
        }

        public void SetVisibleToggle(string clamName)
        {
            visibleToggle.TurnOnByNameInMultiple(clamName);

            if (pickaxBoardItems == null)
            {
                pickaxBoardItems = new Dictionary<string, PickaxBoardItem>();
            }

            if (pickaxBoardItems.ContainsKey(clamName) == false)
            {
                GameObject activeObject = visibleToggle.ActiveObject;

                var item = new PickaxBoardItem();
                item.gameObject = activeObject;
                item.text = activeObject.GetComponentInChildren<TextMeshProUGUI>();
                item.animator = activeObject.GetComponentInChildren<Animator>();
                item.numberPlayer = activeObject.GetComponentInChildren<SetNumberPlayerTM>();

                pickaxBoardItems.Add(clamName, item);

                /// Reset
                item.text.text = "";
            }

            ActiveItem = pickaxBoardItems[clamName];
        }
    }
}
