using DG.Tweening;
using Gaga;
using Gaga.Sound;
using Gaga.UI;
using Gaga.Util;
using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using Underc.Effect;
using Underc.UI;
using Underc.User;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace Underc.Popup
{
    [Serializable]
    public class RewardItemSpace
    {
        public int count;
        public float value;
    }

    public class ClamHarvestPanelPickingLayer : BaseClamHarvestPanelLayer
    {
        [Header("#UI")]
        [SerializeField] private GameObjectVisibleToggle titleVisibleToggle;
        [SerializeField] private TextMeshProUGUI endRemainingTimeText;
        [SerializeField] private ClamHarvestPanelPickaxBoard pickaxBoard;
        [SerializeField] private SoundPlayer needPickaxSound;

        [Header("#ClamPicker")]
        [SerializeField] private List<ClamHarvestPanelClamPicker> clamPickers;
        [SerializeField] private RangeValue idleIntervalRange;
        [SerializeField] private RectTransform movingTarget;
        [SerializeField] private float movingOffset = -.25f;
        [SerializeField] private float movingDuration;
        [SerializeField] private AnimationCurve movingCurve;
        [SerializeField] private SoundPlayer swingPickaxSound;
        [SerializeField] private AnimatorParser smallClamOpenAnimation;
        [SerializeField] private SoundPlayer openClamEmptySound;
        [SerializeField] private AnimatorParser smallClamPrizeAnimation;
        [SerializeField] private SoundPlayer openClamPrizeSound;
        [SerializeField] private SoundPlayer moveClamSound;

        [Header("#ClamGotcha")]
        [SerializeField] private ClamHarvestPanelClamGotcha clamGotcha;

        [Header("#Reward")]
        [FormerlySerializedAs("endDuration")]
        [SerializeField] private float bigClamOpenDelay = 0f;
        [SerializeField] private HorizontalLayoutGroup horizontalLayoutGroup;
        [SerializeField] private List<RewardItemSpace> rewardItemSpaces;
        [SerializeField] private AnimatorParser bigClamOpenAnimation;
        [SerializeField] private AnimatorParser rewardOpenAnimation;

        [Header("#Result")]
        [SerializeField] private float resultOpenDelay = 1.5f;
        [SerializeField] private float itemOpenDelay = 1f;
        [SerializeField] private float itemThrowDelay = .3f;
        [SerializeField] private float coinOpeningInterval = 1f;
        [SerializeField] private float itemOpeningInterval = 0.35f;
        [SerializeField] private float totalWinAddDelay = .1f;
        [SerializeField] private SetNumberPlayerTM totalWin;
        [SerializeField] private AnimatorParser totalWinAddAnimation;
        [SerializeField] private AnimatorParser resultOpenAnimation;
        [SerializeField] private AnimatorParser buttonOpenAnimation;
        [SerializeField] private SoundPlayer addCoinSound;

        [Header("#Collect")]
        [SerializeField] private Button collectButton;
        [SerializeField] private CanvasGroup collectButtonGroup;
        [SerializeField] private SimpleRewardItemCollector itemCollector;
        [SerializeField] private AnimatorParser closeAnimation;

        public Vector3 PickaxBoardPosition
        {
            get => pickaxBoard.transform.position;
        }

        public bool IsCollectable
        {
            get => collectButton.gameObject.activeInHierarchy == true
                && collectButtonGroup.alpha == 1
                && collectButton.interactable == true;
        }

        public bool IsInteractable
        {
            private get;
            set;
        }

        public TabTransformInfo TabTransformInfo
        {
            private get;
            set;
        }

        public Action<int> OnPick;
        public Action OnGotcha;
        public Action OnCollect;

        private const string TRIGGER_OPEN = "Open";
        private const string TRIGGER_OPENED = "Opened";
        private const string TRIGGER_PRIZE = "Prize";

        private List<Vector2> clamPickerOriginPositions;
        private Coroutine playIdleCoroutine;
        private List<int> closedClams;
        private Dictionary<int, float> idleClamTimes;

        private HighlightPanel highlightPanel;
        private HighlightObjectInfo missionPassTabInfo;

        private void OnEnable()
        {
            if (ClamHarvest.ReadDayState() != ClamHarvestTimeState.TimesUp)
            {
                ClamHarvest.onTimeUpdate.AddListener(OnTimeUpdate);
            }
            ResetTotalWin();
        }

        private void OnDisable()
        {
            ClamHarvest.onTimeUpdate.RemoveListener(OnTimeUpdate);

            for (int i = 0; i < clamPickers.Count; i++)
            {
                ClamHarvestPanelClamPicker clamPicker = clamPickers[i];
                clamPicker.SetState(ClamHarvestPanelClamPickerState.Close);

                clamPicker.CachedTransform.anchoredPosition = clamPickerOriginPositions[i];
            }
        }

        public override void Init()
        {
            // ClamPicker
            closedClams = new List<int>();
            clamPickerOriginPositions = new List<Vector2>();
            idleClamTimes = new Dictionary<int, float>();

            for (int i = 0; i < clamPickers.Count; i++)
            {
                ClamHarvestPanelClamPicker clamPicker = clamPickers[i];
                clamPicker.Init(i, OnPick);
                clamPicker.SetState(ClamHarvestPanelClamPickerState.Close);
                clamPickerOriginPositions.Add(clamPicker.CachedTransform.anchoredPosition);

                idleClamTimes.Add(i, 0f);
            }

            // Reward
            itemCollector.Init();

            if (highlightPanel == null)
            {
                missionPassTabInfo = new HighlightObjectInfo(
                    originTransform: TabTransformInfo.TabTransform(MissionPassPopupTab.MissionPass),
                    visibleType: HighlightVisibleType.Alpha,
                    initialActive: false
                );
                highlightPanel = gameObject.AddComponent<HighlightPanel>();
                highlightPanel.Register(missionPassTabInfo);

                // 복제품은 연출 용도이므로 ToggleGroup 및 이벤트 리스너를 제거한다
                Toggle missionPassToggle = missionPassTabInfo.clonedTransform.GetComponent<Toggle>();
                missionPassToggle.onValueChanged.RemoveAllListeners();
                missionPassToggle.group = null;
                missionPassToggle.isOn = true;
            }
        }

        private void ResetTotalWin()
        {
            totalWin.Text.text = "0";
            totalWin.GetComponentInChildren<Magnet>().Update();
            totalWin.startValue = 0L;
            totalWin.endValue = 0L;
            totalWin.Stop(true);
        }

        public override void Reset(bool isBeinning)
        {
            itemCollector.Reset();
            collectButton.interactable = false;
        }

        public void OnAnimationEvent(string name)
        {
            if (name == "reward")
            {
                collectButton.interactable = true;
            }
        }

        private void SetInteractable(bool value)
        {
            IsInteractable = value;

            // 조개 클릭 비활성화
            for (int i = 0; i < clamPickers.Count; i++)
            {
                clamPickers[i].Interactable = value;
            }

            if (value)
            {
                playIdleCoroutine = StartCoroutine(PlayIdleCoroutine());
            }
            else
            {
                if (playIdleCoroutine != null)
                {
                    StopCoroutine(playIdleCoroutine);
                    playIdleCoroutine = null;
                }
            }
        }

        private IEnumerator PlayIdleCoroutine()
        {
            float nextAnimTime = 0;
            while (true)
            {
                if (Time.time > nextAnimTime)
                {
                    closedClams.Clear();
                    for (int i = 0; i < 7; i++)
                    {
                        int clamIndexMask = 1 << i;
                        if ((clamIndexMask & clamHarvest.SelectedClamInfo.allClamIndex) == 0
                            && Time.time >= idleClamTimes[i])
                        {
                            closedClams.Add(i);
                        }
                    }

                    if (closedClams.Count > 0)
                    {
                        int randomIndex = UnityEngine.Random.Range(0, closedClams.Count);
                        int clamIndex = closedClams[randomIndex];

                        ClamHarvestPanelClamPicker clamPicker = clamPickers[clamIndex];
                        if (clamPicker.State == ClamHarvestPanelClamPickerState.Close)
                        {
                            clamPicker.SetState(ClamHarvestPanelClamPickerState.Close, "Idle");
                            idleClamTimes[clamIndex] = Time.time + 1f/* Idle 연출의 Duration */;
                        }
                    }

                    nextAnimTime = Time.time + UnityEngine.Random.Range(idleIntervalRange.min, idleIntervalRange.max);
                }

                yield return null;
            }
        }

        public IEnumerator BlinkPickaxIsEmpty()
        {
            pickaxBoard.ActiveItem.animator.SetTrigger(PickaxBoardItem.TRIGGER_EMPTY);
            needPickaxSound.Play();
            SetInteractable(false);
            yield break;
        }

        public override IEnumerator UpdateContent()
        {
            UpdateUI();
            yield return UpdateSmallClams();
            yield return UpdateRewards();
        }

        private void UpdateUI()
        {
            ClamHarvestClamInfo clamInfo = clamHarvest.SelectedClamInfo;
            string clamName = clamInfo.clamType.ToString();
            int progressivePickax = clamInfo.progressivePickax;

            // 0. 상단 타이틀
            titleVisibleToggle.TurnOnByNameInMultiple(clamName);

            // 1. 상단 시간 연출
            OnTimeUpdate();

            // 2. 우측 하단 곡괭이 보드 연출
            pickaxBoard.SetVisibleToggle(clamName);

            int currentPickax = 0;
            int.TryParse(pickaxBoard.ActiveItem.text.text, out currentPickax);
            if (progressivePickax > currentPickax)
            {
                SetNumberPlayerTM numberPlayer = pickaxBoard.ActiveItem.numberPlayer;
                numberPlayer.startValue = 0L;
                numberPlayer.endValue = progressivePickax;
                numberPlayer.Play();
            }
            else
            {
                pickaxBoard.ActiveItem.text.text = StringMaker.New()
                                                            .Append(progressivePickax.ToString())
                                                            .Build();
            }

            if (currentPickax != progressivePickax)
            {
                pickaxBoard.ActiveItem.animator.SetTrigger(PickaxBoardItem.TRIGGER_USE);
            }
        }

        public IEnumerator CollectCoroutine()
        {
            closeAnimation.SetTrigger();

            var missionPassPointTransition = MissionPassPointTransition.GetOrAdd(gameObject);
            missionPassPointTransition.Setup(itemCollector, missionPassTabInfo);
            itemCollector.OnEffectBegin.AddListener(() =>
            {
                EffectSystem.Instance.Coin(
                    count: 20,
                    startPosition: totalWin.transform.position,
                    endPosition: itemCollector.TopUI.GetCoinIconPosition(),
                    scaleTarget: itemCollector.TopUI.GetCoinIcon(),
                    onFirstCoinArrived: () => MyInfo.Coin += totalWin.endValue,
                    onCoinArrived: () => itemCollector.TopUI.CoinIconAnimation()
                );
            });
            
            yield return itemCollector.CollectCoroutine(itemThrowDelay);

            yield return missionPassPointTransition.WaitForDone();
        }

        public void Collect()
        {
            if (collectButton.interactable)
            {
                totalWin.Stop();
                totalWin.Play(totalWin.endValue, 0L, 0.5f, EasingFunction.Ease.Linear);

                collectButton.interactable = false;
                OnCollect?.Invoke();
            }
        }

        private IEnumerator UpdateRewards()
        {
            ClamHarvestClamInfo clamInfo = clamHarvest.SelectedClamInfo;
            string clamName = clamInfo.clamType.ToString();
            bool isAllClamsPicked = clamInfo.IsAllClamsPicked;
            if (isAllClamsPicked)
            {
                // 4-1. 조개 오픈
                if (bigClamOpenDelay > 0)
                {
                    yield return new WaitForSeconds(bigClamOpenDelay);
                }
                clamGotcha.VisileToggle.TurnOnByNameInMultiple(clamName);
                clamGotcha.gameObject.SetActive(true);
                openClamPrizeSound.Play();

                // 4-2. 보상 아이템 등장
                UpdateLayoutGroupSpacing();
                itemCollector.Setup(rewardInfos: ClamHarvest.SelectedClamInfo.rewardedInfos,
                                    itemValueType: SimpleRewardItemValueType.Simple);
                rewardOpenAnimation.SetTrigger();

                float rewardOpenDuration = rewardOpenAnimation.Duration;
                float bigClamOpenDuration = bigClamOpenDelay + bigClamOpenAnimation.Duration;
                yield return new WaitForSeconds(Mathf.Max(rewardOpenDuration, bigClamOpenDuration));

                // 4-3. 결과창 등장 & 당첨 조개 지우기
                yield return new WaitForSeconds(resultOpenDelay);
                resultOpenAnimation.SetTrigger();
                yield return resultOpenAnimation.WaitForDuration();

                // 4-4. 결과창에 정산
                yield return new WaitForSeconds(itemOpenDelay);
                if (itemCollector.CanOpen)
                {
                    yield return itemCollector.OpenCoroutine(GetOpenInterval, GetOpenTrigger, OnItemOpen);
                }

                buttonOpenAnimation.SetTrigger();
                yield return buttonOpenAnimation.WaitForDuration();
            }
            else
            {
                clamGotcha.gameObject.SetActive(false);
            }

            MyInfo.ClamHarvest.UpdateClamHarvestDisplayInfo();

            yield break;
        }

        private void OnItemOpen(RewardInfo rewardInfo)
        {
            if (rewardInfo.type == RewardType.coin
                || rewardInfo.type == RewardType.coin_g_pickaxe
                || rewardInfo.type == RewardType.coin_s_pickaxe)
            {
                totalWin.Stop();
                totalWin.startValue = totalWin.endValue;
                totalWin.endValue = totalWin.startValue + rewardInfo.value;
                Invoke("TotalWinAdd", totalWinAddDelay);
            }
        }

        private void TotalWinAdd()
        {
            totalWin.Play(totalWin.startValue, totalWin.endValue, 0.5f, EasingFunction.Ease.EaseOutSine);
            totalWinAddAnimation.SetTrigger();
            addCoinSound.Play();
        }

        private float GetOpenInterval(RewardInfo prevRewardInfo)
        {
            return prevRewardInfo.IsCoinType() ?
                coinOpeningInterval :
                itemOpeningInterval;
        }

        private string GetOpenTrigger(RewardInfo rewardInfo)
        {
            return rewardInfo.IsCoinType() ?
                "Open" :
                "Scale";
        }

        private void UpdateLayoutGroupSpacing()
        {
            int rewardCount = ClamHarvest.SelectedClamInfo.rewardedInfos.Count;
            float targetSpacing = 0;
            foreach (RewardItemSpace space in rewardItemSpaces)
            {
                targetSpacing = space.value;
                if (rewardCount <= space.count)
                {
                    break;
                }
            }
            horizontalLayoutGroup.spacing = targetSpacing;
        }

        private IEnumerator UpdateSmallClams()
        {
            ClamHarvestClamInfo clamInfo = clamHarvest.SelectedClamInfo;
            string clamName = clamInfo.clamType.ToString();
            int pickedClamIndex = clamInfo.ConsumePickedClamIndex();
            int progressiveClamIndex = clamInfo.progressiveClamIndex;
            bool isAllClamsPicked = clamInfo.IsAllClamsPicked;

            // 3-1. 조개 클릭 비활성화
            SetInteractable(false);

            // 3-2. 작은 조개 열기 연출
            string trigger = "";
            for (int i = 0; i < clamPickers.Count; i++)
            {
                ClamHarvestPanelClamPicker clamPicker = clamPickers[i];
                clamPicker.VisibleToggle.TurnOnByNameInMultiple(clamName);

                int indexMask = 1 << i;
                if ((progressiveClamIndex & indexMask) > 0
                    && clamPicker.State == ClamHarvestPanelClamPickerState.Close)
                {
                    trigger = "Opened";
                    if ((pickedClamIndex & indexMask) > 0)
                    {
                        trigger = isAllClamsPicked ? "Prize" : "Open";
                    }

                    clamPicker.SetState(ClamHarvestPanelClamPickerState.Open, trigger);
                }
            }

            if (trigger == "Prize")
            {
                swingPickaxSound.Play();
                yield return smallClamPrizeAnimation.WaitForDuration(movingOffset);
            }
            else if (trigger == "Open")
            {
                swingPickaxSound.Play();
                openClamEmptySound.Play();
                yield return smallClamOpenAnimation.WaitForDuration();
            }

            // 3-3. 큰 조개 열기 연출
            if (isAllClamsPicked)
            {
                OnGotcha?.Invoke();
                for (int i = 0; i < clamPickers.Count; i++)
                {
                    ClamHarvestPanelClamPicker clamPicker = clamPickers[i];

                    int indexMask = 1 << i;
                    if ((pickedClamIndex & indexMask) > 0)
                    {
                        moveClamSound.Play();
                        clamPicker.CachedTransform
                                .DOMove(movingTarget.position, movingDuration)
                                .SetEase(movingCurve);
                    }
                    else
                    {
                        clamPicker.SetState(ClamHarvestPanelClamPickerState.Open, "Fade");
                    }
                }

                yield return new WaitForSeconds(movingDuration);
            }

            // 3-4. 조개 클릭 활성화
            SetInteractable(true);
            yield break;
        }

        private void OnTimeUpdate()
        {
            endRemainingTimeText.text = (clamHarvest.EndRemainingSec > 0) ?
                                        clamHarvest.EndRemainingSec.ToSummaryDHMS() :
                                        "TIME'S UP";
        }

        public override bool CanBack()
        {
            bool result = false;
            if (clamHarvest.SelectedClamInfo.IsAllClamsPicked == false)
            {
                result = IsInteractable;
            }
            else
            {
                result = IsCollectable;
            }

            return result;
        }
    }
}
