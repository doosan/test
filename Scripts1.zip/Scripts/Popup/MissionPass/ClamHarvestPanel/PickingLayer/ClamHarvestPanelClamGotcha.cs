using Gaga;
using UnityEngine;

namespace Underc.Popup
{
    public class ClamHarvestPanelClamGotcha : MonoBehaviour
    {
        [SerializeField] private GameObjectVisibleToggle visibleToggle;

        public GameObjectVisibleToggle VisileToggle
        {
            get => visibleToggle;
        }

        public Animator ActiveAnimator
        {
            get => visibleToggle.ActiveObject.GetComponent<Animator>();
        }
    }
}