using Gaga.Popup;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Underc;
using Underc.LoadingScreen;
using Underc.Net;
using Underc.Net.Client;
using Underc.Ocean;
using Underc.Popup;
using Underc.User;
using Underc.Util;
using UnityEngine;

public class TestClamHarvestPanel : TestSceneScaffold
{
    [SerializeField] private bool runAsFake;

    private List<PickaxPurchaseItemData> pickaxPurchaseItems;

    private IEnumerator Start()
    {
        FishIconSystem.Instance.Initialize();

        yield return SetupAndLoad(new BaseLoadingItem[]
        {
            new LoginLoadingItem(),
            new HTTPLoadingItem<UserCoreResponse>(
                () => NetworkSystem.HTTPRequester.UserCoreWithAlarms(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<FishBookListResponse>(
                () => NetworkSystem.HTTPRequester.FishBookList(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<CasinoBonusResponse>(
                () => NetworkSystem.HTTPRequester.CasinoBonus(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new ABFishLoadingItem(),
            new ABFishIconLoadingItem(),
            new ABLoadingItem(AssetBundleName.SLOT_POSTERS),
            new ABLoadingItem(AssetBundleName.EFFECT),
            new TopUILoadingItem(),
            new RewardBonusUILoadingItem()
        });
    }

    public void OpenDailyBonusPopup()
    {
        var dailyBonusClaimResponse = new DailyBonusClaimResponse();
        dailyBonusClaimResponse.daily_bonus = 600000;
        dailyBonusClaimResponse.coin_per_streak = 100000;

        dailyBonusClaimResponse.streak_bonus = 600000;
        dailyBonusClaimResponse.streak_day = 1;
        dailyBonusClaimResponse.streak_max = 7;

        dailyBonusClaimResponse.starting_coin = 1000;
        dailyBonusClaimResponse.fish_cnt = 36;
        dailyBonusClaimResponse.fish_bonus = 36000;
        dailyBonusClaimResponse.limit_fish_cnt = 1000;

        var dailyBonusClaimReward = new DailyBonusRewardData();
        dailyBonusClaimReward.rwd = "s_pickaxe";
        dailyBonusClaimReward.val = 1;

        dailyBonusClaimResponse.reward = new DailyBonusRewardData[]
        {
            dailyBonusClaimReward
        };

        FakeHttpRequester.Instance.LoadedDailyBonusClaimResponse = dailyBonusClaimResponse;

        PopupObject<DailyBonusPopup> popupObject = null;
        popupObject = Popups.DailyBonus(onOpen: () =>
                                        {
                                            if (popupObject != null)
                                            {
                                                popupObject.GetPopup().RunAsFake = runAsFake;
                                            }
                                        })
                            .Async()
                            .Cache();
    }

    public void OpenClamHarvestPopup_End()
    {
        OpenClamHarvestPopup(MakeClamHarvestData(startTs: -15, endTs: 0));
    }

    public void OpenClamHarvestPopup_InProgress()
    {
        OpenClamHarvestPopup(MakeClamHarvestData(startTs: -15, endTs: 60 * 60 * 1));
    }

    public void OpenClamHarvestPopup_WaitToInProgress()
    {
        OpenClamHarvestPopup(MakeClamHarvestData(startTs: 0, endTs: 60 * 60 * 1));
    }

    public void OpenClamHarvestPopup_Wait()
    {
        OpenClamHarvestPopup(MakeClamHarvestData(startTs: 60 * 60 * 1, endTs: 60 * 60 * 24));
    }

    public void OpenClamHarvestPopup_Reward()
    {
        ClamHarvestData clamHarvestData = MakeClamHarvestData(startTs: -15, endTs: 60 * 60 * 1);
        clamHarvestData.gold.pickaxe = 7;
        clamHarvestData.silver.pickaxe = 7;

        OpenClamHarvestPopup(clamHarvestData);
    }

    public void OpenClamHarvestPopup_Purchase()
    {
        ClamHarvestData clamHarvestData = MakeClamHarvestData(startTs: -15, endTs: 60 * 60 * 1);
        clamHarvestData.gold.pickaxe = 0;
        clamHarvestData.silver.pickaxe = 0;
        clamHarvestData.item = MakePickaxPurchaseItemData(goldRemainingCount: ReadRemainingCount(clamHarvestData.gold),
                                                          silverRemainingCount: ReadRemainingCount(clamHarvestData.silver));

        OpenClamHarvestPopup(clamHarvestData);
    }

    private ClamHarvestData MakeClamHarvestData(long startTs, long endTs)
    {
        var clamHarvestData = new ClamHarvestData();
        clamHarvestData.start_ts = RemainingSeconds(startTs);
        clamHarvestData.end_ts = RemainingSeconds(endTs);
        clamHarvestData.gold = MakeClamData();
        clamHarvestData.silver = MakeClamData();
        return clamHarvestData;
    }

    private void OpenClamHarvestPopup(ClamHarvestData clamHarvestData)
    {
        var missionData = new MissionData();
        missionData.clam_harvest = clamHarvestData;

        FakeHttpRequester.Instance.LoadedMissionResponse = () =>
        {
            // ts 값을 갱신해 줌
            var missionResponse = FakeResponseMaker.New<MissionResponse>();
            missionResponse.data = missionData;

            return missionResponse;
        };

        FakeHttpRequester.Instance.LoadedPurchasePickaxResponse = (RewardType type, int value) =>
        {
            var purchaseResponse = new PurchaseResponse();

            if (type == RewardType.g_pickaxe)
            {
                clamHarvestData.gold.pickaxe = value;
                clamHarvestData.silver.pickaxe = 0;
            }
            else if (type == RewardType.s_pickaxe)
            {
                clamHarvestData.gold.pickaxe = 0;
                clamHarvestData.silver.pickaxe = value;
            }

            return purchaseResponse;
        };

        FakeHttpRequester.Instance.LoadedHarvestResponse = (ClamHarvestClamType type, int index) =>
        {
            ClamHarvestClamData clamData = type == ClamHarvestClamType.gold ?
                                           clamHarvestData.gold :
                                           clamHarvestData.silver;

            var harvestResponse = new HarvestResponse();
            harvestResponse.data = MakeHarvestData(type, index, clamData);
            harvestResponse.data.mission_pass_step = 1;

            return harvestResponse;
        };

        PopupObject<MissionPassPopup> popupObject = null;
        popupObject = Popups.MissionPass(tab: MissionPassPopupTab.ClamHarvest,
                                       syncData: true,
                                       onInit: () =>
                                       {
                                           if (popupObject != null)
                                           {
                                               popupObject.GetPopup().RunAsFake = true;
                                           }
                                       })
                            .Async()
                            .Cache();
    }

    private HarvestData MakeHarvestData(ClamHarvestClamType type,
                                        int index, 
                                        ClamHarvestClamData clamData)
    {
        HarvestData harvestData = null;
        if (clamData.pickaxe > 0)
        {
            clamData.pickaxe -= 1;
            clamData.clam_index |= (1 << index);
            int remainingCount = ReadRemainingCount(clamData);

            harvestData = new HarvestData();
            harvestData.type = type.ToString();
            harvestData.clam_index = clamData.clam_index;
            harvestData.pickaxe = clamData.pickaxe;

            bool gotcha = remainingCount == 0
                          || UnityEngine.Random.Range(0, 7) == 0;

            if (gotcha)
            {
                harvestData.use_pickaxe = harvestData.pickaxe;
                harvestData.remaining_bonus = harvestData.pickaxe * 10000;
                harvestData.reward = FakeRewardDataMaker.Instance
                                                        .GetHarvestRewards(count: 5)
                                                        .Select(data => new CommonRewardData(data.type.ToString(), data.value))
                                                        .ToArray();

                harvestData.clam_index = (1 << 7) - 1;
                harvestData.pickaxe = 0;
            }
            else if (harvestData.pickaxe == 0)
            {
                int goldRemainigCount = 0;
                int silverRemainingCount = 0;
                if (type == ClamHarvestClamType.gold)
                {
                    goldRemainigCount = remainingCount;
                }
                else if (type == ClamHarvestClamType.silver)
                {
                    silverRemainingCount = remainingCount;
                }

                harvestData.item = MakePickaxPurchaseItemData(goldRemainigCount, silverRemainingCount);
            }
        }
        
        return harvestData;
    }

    private int ReadRemainingCount(ClamHarvestClamData clamData)
    {
        int openedCount = 0;
        for (int i = 0; i < clamData.max_pickaxe; i++)
        {
            int indexMask = 1 << i;
            if ((clamData.clam_index & indexMask) > 0)
            {
                openedCount += 1;
            }
        }

        return clamData.max_pickaxe - openedCount;
    }

    private PickaxPurchaseItemData[] MakePickaxPurchaseItemData(int goldRemainingCount, int silverRemainingCount)
    {
        if (pickaxPurchaseItems == null)
        {
            pickaxPurchaseItems = new List<PickaxPurchaseItemData>();
        }

        pickaxPurchaseItems.Clear();
        if (goldRemainingCount >= 1)
        {
            pickaxPurchaseItems.Add(MakePickaxPurchaseItemData(rwd: "g_pickaxe",
                                                               val: 1,
                                                               price: 1.99f,
                                                               itemid: "g.pickaxe1"));
        }
        if (goldRemainingCount >= 3)
        {
            pickaxPurchaseItems.Add(MakePickaxPurchaseItemData(rwd: "g_pickaxe",
                                                               val: 3,
                                                               price: 2.99f,
                                                               itemid: "g.pickaxe3"));
        }

        if (silverRemainingCount >= 1)
        {
            pickaxPurchaseItems.Add(MakePickaxPurchaseItemData(rwd: "s_pickaxe",
                                                               val: 1,
                                                               price: 1.99f,
                                                               itemid: "s.pickaxe1"));
        }
        if (silverRemainingCount >= 3)
        {
            pickaxPurchaseItems.Add(MakePickaxPurchaseItemData(rwd: "s_pickaxe",
                                                               val: 3,
                                                               price: 2.99f,
                                                               itemid: "s.pickaxe3"));
        }



        return pickaxPurchaseItems.ToArray();
    }

    private PickaxPurchaseItemData MakePickaxPurchaseItemData(string rwd, int val, float price, string itemid)
    {
        var itemData = new PickaxPurchaseItemData();
        itemData.rwd = rwd;
        itemData.val = val;
        itemData.price = price;
        itemData.itemid = itemid;
        return itemData;
    }

    private long RemainingSeconds(long remainingSeconds)
    {
        DateTime now = DateTime.Now.ToLocalTime();
        TimeSpan span = (now - new DateTime(1970, 1, 1, 0, 0, 0, 0).ToLocalTime());
        long nowSeconds = (long)span.TotalSeconds;

        return nowSeconds + remainingSeconds;
    }

    private ClamHarvestClamData MakeClamData()
    {
        int clamIndex = 0;
        int pickax = 0;
        int maxPickax = 7;
        for (int i = 0; i < maxPickax; i++)
        {
            if (UnityEngine.Random.Range(0, 2) == 0)
            {
                continue;
            }

            clamIndex += (1 << i);
            pickax += 1;
        }
        List<FakeRewardData> fakeRewardDatas = FakeRewardDataMaker.Instance.GetClamHarvestRewards(5);

        ///
        var clamData = new ClamHarvestClamData();
        clamData.clam_index = clamIndex;
        clamData.pickaxe = pickax;
        clamData.max_pickaxe = maxPickax;
        clamData.reward = fakeRewardDatas.Select(data => new CommonRewardData(data.type.ToString(), data.value))
                                         .ToArray();

        return clamData;
    }
}
