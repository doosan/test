using Gaga;
using Gaga.Util;
using System;
using System.Collections;
using UnityEngine;

namespace Underc.Popup
{
    public class ClamHarvestPanelMessageLayer : BaseClamHarvestPanelLayer
    {
        [SerializeField] private GameObjectVisibleToggle messageVisibleToggle;
        [SerializeField] private AnimatorParser openAnimation;

        public Action OnClose
        {
            private get;
            set;
        }

        public GameObjectVisibleToggle MessageVisibleToggle
        {
            get => messageVisibleToggle;
        }

        private void OnEnable()
        {
            StartCoroutine(OpenAnimationCoroutine());
        }

        private IEnumerator OpenAnimationCoroutine()
        {
            yield return openAnimation.WaitForDuration();
            OnClose?.Invoke();
        }
    }
}