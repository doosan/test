using UnityEngine;
using Gaga.Popup;
using Underc.User;
using System.Collections;
using System;
using TMPro;
using Underc.Net;
using UnityEngine.UI;

namespace Underc.Popup
{
    public sealed class MissionPassPurchasePopup : PopupBackable
    {
        [SerializeField] private TextMeshProUGUI priceText;

        [Space]
        [SerializeField] private GameObject saleView;
        [SerializeField] private TextMeshProUGUI saleText;
        [SerializeField] private GameObject uptoTagObject;
        [SerializeField] private TextMeshProUGUI uptoValueText;

        [Space]
        [SerializeField] private Button buyButton;

        public bool RunAsFake
        {
            private get;
            set;
        }

        private Action onPurchsed;
        private MissionPassPurchaseInfo purchaseInfo;

        public void Initialize(Action onPurchsed)
        {
            this.onPurchsed = onPurchsed;

            allowBackButton = true;
            purchaseInfo = MyInfo.MissionPass.GetPurchaseInfo();

            priceText.text = $"${purchaseInfo.price}";
            float salePrice = purchaseInfo.salePrice;
            if (salePrice > 0)
            {
                saleText.text = $"{salePrice}";
            }
            saleView.SetActive(salePrice > 0);

            int uptoValue = purchaseInfo.uptoValue;
            uptoValueText.text = $"X{uptoValue}";
            uptoTagObject.SetActive(uptoValue > 0);

            buyButton.interactable = MyInfo.MissionPass.EndRemainingSec > 0;
        }

        public void OnCloseButtonClicked()
        {
            UndercGameLog.Fobis.ButtonMissionPassBuy(4);
            Close();
        }

        public void Purchase()
        {
            if (MyInfo.MissionPass.EnabledBonus)
            {
                Debug.Log("이미 구매 했음!!");
                return;
            }

            UndercGameLog.Fobis.ButtonMissionPassBuy(1);
            
            StartCoroutine("PurchaseCoroutine");
        }

        private IEnumerator PurchaseCoroutine()
        {
            allowBackButton = false;

            PurchaseSystem purchaseSystem = PurchaseSystem.Instance;
            bool isSuccess;
            if (RunAsFake == false)
            {
                yield return purchaseSystem.Purchase(
                    itemID: purchaseInfo.itemID,
                    showReward: false
                );
                isSuccess = purchaseSystem.IsFailed == false;
            }
            else
            {
                Popups.ShowLoading();
                var req = FakeHttpRequester.Instance.PurchaseMissionPass(purchaseInfo.itemID);
                yield return req.WaitForResponse();
                Popups.HideLoading();

                isSuccess = true;
            }
            
            if (isSuccess)
            {
                onPurchsed?.Invoke();

                Close();
            }

            allowBackButton = true;
        }

        public void OpenInfo()
        {
            Popups.MissionPassIncludes().Async();
        }

        public override bool CanBack()
        {
            return Popups.IsLoading() == false
                   && allowBackButton == true;
        }
    }
}