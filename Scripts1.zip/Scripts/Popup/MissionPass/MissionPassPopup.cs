using Gaga.Popup;
using Gaga.Sound;
using Gaga.System;
using System.Collections;
using System.Collections.Generic;
using Underc.Lobby;
using Underc.Net;
using Underc.Net.Client;
using Underc.Scene;
using Underc.UI;
using Underc.User;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace Underc.Popup
{
    public enum MissionPassPopupTab
    { 
        MissionPass = 0,
        DailyMission = 1,
        ClamHarvest = 2,
        AquaBlitz = 3
    }

    public enum MissionPassPopupState
    { 
        None,
        UpdateContent,
        LoadMission,
        OpenErrorPopup,
        Release
    }

    public class TabTransformInfo
    {
        public Dictionary<int, RectTransform> tabTransforms
        {
            private get;
            set;
        }

        public TabTransformInfo(Dictionary<int, RectTransform> tabTransforms)
        {
            this.tabTransforms = tabTransforms;
        }

        public Vector2 TabPosition(MissionPassPopupTab tab)
        {
            return tabTransforms[(int)tab].position;
        }

        public RectTransform TabTransform(MissionPassPopupTab tab)
        {
            return tabTransforms[(int)tab];
        }
    }

    public class MissionPassPopup : PreLoadingPopup
    {
        [SerializeField] private List<Toggle> tabToggles;

        [FormerlySerializedAs("contentLayers")]
        [SerializeField] private List<BaseMissionPassContentPanel> contentPanels;
        [SerializeField] private SlotCard slotCardRef;

        [Header("Sound")]
        [SerializeField] private SoundPlayer playSlotSound;

        public bool RunAsFake
        {
            private get
            {
                return runAsFake;
            }
            set
            {
                runAsFake = value;
                foreach (BaseMissionPassContentPanel contentPanel in contentPanels)
                {
                    contentPanel.RunAsFake = value;
                }
            }
        }
        private bool runAsFake;

        public TabTransformInfo TabTransformInfo
        {
            get;
            private set;
        }

        private StateQueue<MissionPassPopupState> stateQueue;
        private GameObjectPool<SlotCard> slotCardPool;
        private Dictionary<int, RectTransform> tabTransformInfos;

        private bool initOnce;

        private int tabIndex;
        private bool openingSync;

        private void Init()
        {
            if (initOnce == false)
            {
                initOnce = true;

                stateQueue = new StateQueue<MissionPassPopupState>(host: this);

                //
                tabTransformInfos = new Dictionary<int, RectTransform>();
                for (int i = 0; i < tabToggles.Count; i++)
                {
                    int toggleIndex = i;
                    Toggle tabToggle = tabToggles[i];
                    tabToggle.onValueChanged.AddListener((bool value) =>
                    {
                        if (value == true
                            && tabIndex != toggleIndex)
                        {
                            tabIndex = toggleIndex;

                            UpdateTab();
                            stateQueue.Add(MissionPassPopupState.UpdateContent, UpdateContentType.First);
                        }
                    });

                    tabTransformInfos.Add(i, tabToggle.GetComponent<RectTransform>());
                }
                TabTransformInfo = new TabTransformInfo(tabTransformInfos);

                for (int i = 0; i < contentPanels.Count; i++)
                {
                    BaseMissionPassContentPanel contentPanel = contentPanels[i];
                    contentPanel.TabTransformInfo = TabTransformInfo;
                    contentPanel.Init();
                    contentPanel.OnRefresh = () =>
                    {
                        if (stateQueue.Contains(MissionPassPopupState.Release) == false)
                        {
                            stateQueue.Add(MissionPassPopupState.LoadMission);
                            stateQueue.Add(MissionPassPopupState.UpdateContent, UpdateContentType.Refresh);
                        }
                    };
                    contentPanel.OnError = (string error) =>
                    {
                        stateQueue.Add(MissionPassPopupState.OpenErrorPopup, error);
                    };
                    contentPanel.OnClose = () =>
                    {
                        stateQueue.Add(MissionPassPopupState.Release);
                    };
                    contentPanel.OnGoToSlot = GoToSlot;
                    contentPanel.OnInteractable = (bool value) => Interactable = value;
                }

                SetupSlotCardPool();
            }
        }

        public Vector2 GetPointGuagePosition(MissionPassPopupTab tab)
        {
            int tabIndex = (int)tab;
            return contentPanels[tabIndex].PointGaugePosition;
        }

        public RectTransform GetPointGaugeTransform(MissionPassPopupTab tab)
        {
            int tabIndex = (int)tab;
            return contentPanels[tabIndex].PointGaugeTransform;
        }

        public void UpdateContent(MissionPassPopupTab tab, UpdateContentType updateType)
        {
            tabIndex = (int)tab;
            UpdateTab();

            stateQueue.Add(MissionPassPopupState.UpdateContent, updateType);
        }

        public IEnumerator UpdateProgressiveContent(MissionPassPopupTab tab, UpdateSpecificContentType contentType)
        {
            tabIndex = (int)tab;
            yield return contentPanels[tabIndex].UpdateProgressiveContent(contentType);

            yield return LoadMissionCoroutine();

            Close();
        }

        private void SetupSlotCardPool()
        {
            slotCardPool = slotCardRef.CreatePool(
                rootName: "SlotCardPool",
                parent: transform,
                size: 1
            );
        }

        public void Open(MissionPassPopupTab tab, bool openingSync, bool interactable)
        {
            this.tabIndex = (int)tab;
            this.openingSync = openingSync;
            Interactable = interactable;

            Init();
            StartLoading();
        }

        protected override IEnumerator OnLoading()
        {
            if (openingSync == false)
            {
                // 처음 한 번만 체크함
                openingSync = true;
                yield break;
            }
            else
            {
                yield return LoadMissionCoroutine();
            }
        }

        protected override void OnLoadComplete()
        {
            UpdateTab();

            stateQueue.Reset();
            stateQueue.Add(MissionPassPopupState.UpdateContent, UpdateContentType.First);
        }

        private void UpdateTab()
        {
            tabToggles[tabIndex].isOn = true;
            foreach (RectTransform tabTransform in tabTransformInfos.Values)
            {
                tabTransform.SetAsFirstSibling();
            }
            tabTransformInfos[tabIndex].SetAsLastSibling();

            foreach (BaseContentPanel contentPanel in contentPanels)
            {
                contentPanel.gameObject.SetActive(false);
            }
            contentPanels[tabIndex].gameObject.SetActive(true);
        }

        private IEnumerator LoadMissionCoroutine()
        {
            Popups.ShowLoading();
            IRequest<MissionResponse> req;
            Debug.Log("vvv RunAsFake : " + RunAsFake);
            if (RunAsFake == false)
            {
                req = NetworkSystem.HTTPRequester.Mission();
            }
            else
            {
                req = FakeHttpRequester.Instance.Mission();
            }
            yield return req.WaitForResponse();
            Popups.HideLoading();

            if (req.isSuccess)
            {
                NetworkSystem.HTTPHandler.Do(req.data);
            }
            else
            {
                OpenErrorPopup(req.data.error);
            }
        }

        private IEnumerator UpdateContentCoroutine(object param)
        {
            UpdateContentType updateType = (UpdateContentType)param;

            BaseContentPanel contentPanel = contentPanels[tabIndex];
            if (updateType == UpdateContentType.First)
            {
                contentPanel.Reset();
            }
            yield return contentPanel.UpdateContent(updateType);
        }

        private IEnumerator ReleaseCoroutine()
        {
            bool result = true;

            BaseContentPanel contentPanel = contentPanels[tabIndex];
            if (contentPanel.gameObject.activeInHierarchy)
            {
                result &= contentPanel.Close();
            }

            if (result)
            {
                base.Close();
            }
            yield break;
        }

        public override bool CanBack()
        {
            bool result = Popups.IsLoading() == false;

            BaseContentPanel contentPanel = contentPanels[tabIndex];
            if (contentPanel.gameObject.activeInHierarchy)
            {
                result &= contentPanel.CanBack();
            }

            return result;
        }

        public override void Close()
        {
            stateQueue.Add(MissionPassPopupState.Release);
        }

        public void OnCloseButtonClicked()
        {
            UndercGameLog.Fobis.ButtonMissionPass(4);
            Close();
        }

        private IEnumerator OpenErrorPopupCoroutine(object param)
        {
            string message = (string)param;

            OpenErrorPopup(message);

            yield break;
        }

        private void OpenErrorPopup(string message)
        {
            stateQueue.Reset();

            Popups.Error(message)
                  .Async()
                  .OnClose(Close);
        }

        private void GoToSlot(string slotID, MissionPassPopupTab tab)
        {
            string currSceneName = SceneSystem.ActiveScene;
            if (currSceneName == SceneSystem.GameScene || currSceneName == SceneSystem.GameScenePortrait)
            {
                if (slotID == "0"
                    || slotID == MyInfo.SlotGame.currentSlotID)
                {
                    // A-1. 현재 slotID 와 같을 때는 팝업을 닫아주기
                    Close();
                }
                else
                {
                    Close();

                    if (tab == MissionPassPopupTab.AquaBlitz)
                    {
                        MyInfo.AquaBlitz.UpdateMissionClicked(true);
                    }

                    SoundSystem.Instance.StopBGM();
                    playSlotSound.Play();

                    // A-2. 특정 slotID 의 게임으로 바로 이동
                    SceneSystem.LoadGame(slotID, MakeSlotCard(slotID).CurrentSkin);
                }
            }
            else if (currSceneName == SceneSystem.LobbyScene)
            {
                if (slotID == "0")
                {
                    // B-1. Any 일때는 팝업만 닫아주기 
                    Close();
                }
                else
                {
                    Close();

                    if (tab == MissionPassPopupTab.AquaBlitz)
                    {
                        MyInfo.AquaBlitz.UpdateMissionClicked(true);
                    }

                    SoundSystem.Instance.StopBGM();
                    playSlotSound.Play();
                    SoundSystem.Instance.FadeOutWhenDestroyed(playSlotSound.Key);

                    // B-2. 특정 slotID 의 게임으로 바로 이동
                    SceneSystem.LoadGame(slotID, MakeSlotCard(slotID).CurrentSkin);
                }
            }
            else
            {
                Close();
            }
        }

        private SlotCard MakeSlotCard(string slotID)
        {
            SlotCard slotCard = slotCardPool.Get();

            SlotData slotData = MyInfo.SlotGame.GetSlotData(slotID);
            if (slotData == null)
            {
                slotData = new SlotData(slotID);
            }

            SlotCardInfo slotCardInfo = MyInfo.SlotGame.CreateSlotCardInfo(slotData);
            slotCard.SetInfo(info: slotCardInfo, 0);
            
            return slotCard;
        }
    }
}
