using Gaga.Popup;
using System.Collections;
using Underc;
using Underc.Net;
using Underc.Net.Client;
using Underc.Popup;
using Underc.User;
using UnityEngine;

public class TestMissionPassCollectAllPopup : TestSceneScaffold
{
    [SerializeField] private int[] freeStatus;
    [SerializeField] private int[] buyStatus;
    [SerializeField] private bool hasMissionPass;

    private IEnumerator Start()
    {
        yield return SetupAndLoad(GetRewardLoadingItems());

        PrepareVipLevelUp();
    }

    private void PrepareVipLevelUp()
    {
        //
        var vipData = new VipData();
        vipData.vip_class = 1;
        vipData.xp = 0;
        vipData.next_xp = 500;
        MyInfo.VipClass.Update(vipData, null, null, null);

        //
        FakeHttpRequester.Instance.LoadedUserCore = () =>
        {
            var userCoreResponse = new UserCoreResponse();
            var userData = new UserData();
            userData.vip_class = 2;

            vipData.vip_class = 2;
            vipData.xp = 0;

            userCoreResponse.user = userData;
            return userCoreResponse;
        };

        // 
        var profileResponse = new ProfileResponse();
        var profileData = new ProfileData();
        profileData.vip = vipData;

        profileResponse.data = profileData;
        FakeHttpRequester.Instance.LoadedProfileResponse = profileResponse;
    }

    public void OpenMissionPassCollectAllPopup()
    {
        // Step 값 읽기
        int step = 0;
        for (int i = 0; i < freeStatus.Length; i++)
        {
            int status = freeStatus[i];
            if (status > 0)
            {
                step = i;
            }
        }

        MissionPassData missionPassData = MissionDataMaker.Instance.NewMissionPass(
            step,
            freeStatus,
            buyStatus,
            hasMissionPass
        );

        //
        FakeHttpRequester.Instance.LoadedPurchaseMissionPassResponse = () =>
        {
            missionPassData.buy.bonus = true;
            missionPassData.buy.mission_box = true; 

            return new ClientResponse();
        };

        //
        FakeHttpRequester.Instance.LoadedMissionPassClaimAllPreviewResponse = () =>
        {
            var missionPassClaimAllResponse = new MissionPassClaimAllResponse();
            missionPassClaimAllResponse.free = MissionDataMaker.Instance.NewMissionPassPreviewDatas(missionPassData.free);
            missionPassClaimAllResponse.buy = MissionDataMaker.Instance.NewMissionPassPreviewDatas(missionPassData.buy);
            return missionPassClaimAllResponse;
        };

        //
        FakeHttpRequester.Instance.LoadedMissionPassClaimAllResponse = () =>
        {
            var missionPassClaimAllResponse = new MissionPassClaimAllResponse();
            missionPassClaimAllResponse.free = MissionDataMaker.Instance.NewMissionPassClaimDatas(missionPassData.free);
            missionPassClaimAllResponse.buy = MissionDataMaker.Instance.NewMissionPassClaimDatas(missionPassData.buy);
            return missionPassClaimAllResponse;
        };

        //
        FakeHttpRequester.Instance.LoadedMissionPassClaimResponse = (int _step, int _type) =>
        {
            var missionPassClaimResponse = new MissionPassClaimResponse();
            MissionPassClaimData missionPassClaimData = null;

            MissionPassItemContainer.ClickEventType clickEventType = (MissionPassItemContainer.ClickEventType)_type;
            switch (clickEventType)
            {
                case MissionPassItemContainer.ClickEventType.Bonus:
                case MissionPassItemContainer.ClickEventType.Chest:
                    missionPassClaimData = MissionDataMaker.Instance.NewMissionPassClaimData(missionPassData.buy, _step);
                    break;

                case MissionPassItemContainer.ClickEventType.Free:
                    missionPassClaimData = MissionDataMaker.Instance.NewMissionPassClaimData(missionPassData.free, _step);
                    break;
            }

            missionPassClaimResponse.pass = missionPassClaimData;
            return missionPassClaimResponse;
        };

        //
        MissionDataMaker.Instance.LoadMissionResponse(
            missionPassData: missionPassData,
            dailyMissionData: null,
            clamHarvestData: null,
            aquaBlitzData: null
        );

        PopupObject<MissionPassPopup> popupObject = null;
        popupObject = Popups.MissionPass(onInit: () =>
                            {
                                if (popupObject != null)
                                {
                                    popupObject.GetPopup().RunAsFake = true;
                                }
                            })
                            .Async()
                            .Cache();
    }
}
