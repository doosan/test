using Gaga.System;
using System.Collections;
using System.Collections.Generic;
using Underc;
using Underc.LoadingScreen;
using Underc.Net;
using Underc.Net.Client;
using Underc.Popup;
using Underc.UI;
using Underc.User;
using Underc.Util;
using UnityEngine;

public class TestMissionPassIcon : TestSceneScaffold
{
    [SerializeField] private GameBottomUI gameBottomUI;
    private Queue<MissionPassData> missionPassDatas;
    private Queue<DailyMissionData> dailyMissionDatas;

    private MissionDataMaker MissionDataMaker
    {
        get
        {
            if (missionDataMaker == null)
            {
                missionDataMaker = MissionDataMaker.Instance;
            }
            return missionDataMaker;
        }
    }
    private MissionDataMaker missionDataMaker;

    private IEnumerator Start()
    {
        Init1();

        yield return SetupAndLoad(new BaseLoadingItem[]
        {
            new LoginLoadingItem(),
        });

        Init2();

        yield return JustLoad(new BaseLoadingItem[]
        {
            new HTTPLoadingItem<UserCoreResponse>(
                () => NetworkSystem.HTTPRequester.UserCoreWithAlarms(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<FishBookListResponse>(
                () => NetworkSystem.HTTPRequester.FishBookList(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<CasinoBonusResponse>(
                () => NetworkSystem.HTTPRequester.CasinoBonus(),
                resp =>
                {
                    MyInfo.CasinoBonus.Update(resp.data);
                }
            ),
            new HTTPLoadingItem<MissionResponse>(
                () => FakeHttpRequester.Instance.Mission(),
                resp =>
                {
                    MyInfo.DailyMission.Update(resp.ts, resp.data.daily_quest);
                    MyInfo.MissionPass.Update(resp.data.ocean_pass);
                }
            ),
            new HTTPLoadingItem<SeaMineResponse>(
                () => NetworkSystem.HTTPRequester.SeaMine(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            // A-1. sea_mine 을 먼저 호출해줘야 sea_story 에 정상적인 값이 로드됨.
            // A-2. RewardPopupBottomUI 의 우하단 물고기 콜렉션 카운트를 체크하기 위함.
            new HTTPLoadingItem<SeaStoryResponse>(
                () => NetworkSystem.HTTPRequester.SeaStory(MyInfo.Ocean.CurrentSeaID),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new ABFishLoadingItem(),
            new ABFishIconLoadingItem(),
            new ABLoadingItem(AssetBundleName.EFFECT),
            new TopUILoadingItem(),
            new RewardBonusUILoadingItem()
        });
    }

    private void Init1()
    {
        missionPassDatas = new Queue<MissionPassData>();
        dailyMissionDatas = new Queue<DailyMissionData>();

        foreach (BaseMissionIcon missionIcon in gameBottomUI.MissionIconManager.MissionIcons)
        {
            missionIcon.Display.RunAsFake = true;
        }
    }

    private void Init2()
    {
        gameBottomUI.Setup(null);

        missionPassDatas.Enqueue(MissionDataMaker.NewMissionPass(
            step: 0,
            curr: 0,
            all: 1000
        ));
        missionPassDatas.Enqueue(MissionDataMaker.NewMissionPass(
            step: 0,
            curr: 0,
            all: 1000
        ));

        dailyMissionDatas.Enqueue(MissionDataMaker.NewDailyMission(
            isUnlock: 0,
            unlock: 60
        ));
        dailyMissionDatas.Enqueue(MissionDataMaker.NewDailyMission(
            isUnlock: 1,
            unlock: 60
        ));

        MissionDataMaker.LoadMissionResponse(
            missionPassData: missionPassDatas.Dequeue(),
            dailyMissionData: dailyMissionDatas.Dequeue(),
            aquaBlitzData: null
        );
    }

    public void OpenMissionPass()
    {
        if (missionPassDatas.Count > 0)
        {
            MissionDataMaker.LoadMissionResponse(
                missionPassData: missionPassDatas.Dequeue(),
                dailyMissionData: dailyMissionDatas.Dequeue(),
                aquaBlitzData: null
            );

            Coroutines coroutines = Coroutines.Create(this).Cache();
            coroutines.Add(LoadMission())
                      .Add(ProgressMissionPass())
                      .Sequence();
        }
    }

    private IEnumerator LoadMission()
    {
        IRequest<MissionResponse> req = FakeHttpRequester.Instance.Mission();
        yield return req.WaitForResponse();

        if (req.isSuccess)
        {
            NetworkSystem.HTTPHandler.Do(req.data);

            bool isMissionPassUnlock = MyInfo.DailyMission.DisplayInfo.ConsumeJustUnlockState();
            if (isMissionPassUnlock)
            {
                yield return Popups.MissionPassOpen()
                                   .WaitForClose();

                BaseMissionIcon missionPassIcon = gameBottomUI.MissionIconManager.GetIcon(MissionIconType.MissionPass);
                yield return missionPassIcon.UnlockCoroutine();
                missionPassIcon.UpdateInfo(isProgressive: false);

                yield return Popups.MissionPass(syncData: true).Async().Cache().WaitForClose();
            }
        }
    }

    private IEnumerator ProgressMissionPass()
    {
        BaseMissionIcon icon = gameBottomUI.MissionIconManager.GetIcon(MissionIconType.MissionPass);
        icon.Switch();
        yield return new WaitForSeconds(.5f);
        yield return icon.UpdateInfoCoroutine();
        yield return new WaitForSeconds(1f);
    }
}
