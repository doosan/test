using Gaga;
using Gaga.Popup;
using Gaga.System;
using System;
using System.Collections;
using System.Collections.Generic;
using Underc;
using Underc.LoadingScreen;
using Underc.Net;
using Underc.Net.Client;
using Underc.Popup;
using Underc.User;
using Underc.Util;
using UnityEngine;

public class TestDailyMissionPanel : TestSceneScaffold
{
    [SerializeField] private bool setup = true;

    [SerializeField] private long itemRemainingSec = 60 * 1;
    [SerializeField] private long itemCurr = 25;
    [SerializeField] private long itemAll = 100;

    [SerializeField] private long pointRemainingSec = 60 * 5;
    [SerializeField] private long pointCurr = 25;
    [SerializeField] private long pointAll = 100;

    private bool loadOnce = false;

    private IEnumerator Start()
    {
        if (setup)
        {
            yield return SetupAndLoad(new BaseLoadingItem[]
            {
                new LoginLoadingItem(),
                new HTTPLoadingItem<UserCoreResponse>(
                    () => NetworkSystem.HTTPRequester.UserCoreWithAlarms(),
                    resp => NetworkSystem.HTTPHandler.Do(resp)
                ),
                new HTTPLoadingItem<FishBookListResponse>(
                    () => NetworkSystem.HTTPRequester.FishBookList(),
                    resp => NetworkSystem.HTTPHandler.Do(resp)
                ),
                new HTTPLoadingItem<CasinoBonusResponse>(
                    () => NetworkSystem.HTTPRequester.CasinoBonus(), 
                    resp => NetworkSystem.HTTPHandler.Do(resp)
                ),
                new HTTPLoadingItem<SeaMineResponse>(
                    () => NetworkSystem.HTTPRequester.SeaMine(),
                    resp => NetworkSystem.HTTPHandler.Do(resp)
                ),
                /// 1-1. sea_mine 을 먼저 호출해줘야 sea_story 에 정상적인 값이 로드됨.
                /// 1-2. RewardPopupBottomUI 의 우하단 물고기 콜렉션 카운트를 체크하기 위함.
                new HTTPLoadingItem<SeaStoryResponse>(
                    () => NetworkSystem.HTTPRequester.SeaStory(MyInfo.Ocean.CurrentSeaID),
                    resp => NetworkSystem.HTTPHandler.Do(resp)
                ),
                new ABFishLoadingItem(),
                new ABFishIconLoadingItem(),
                new ABLoadingItem(AssetBundleName.EFFECT),
                new TopUILoadingItem(),
                new RewardBonusUILoadingItem()
            });
        }
    }

    public void OpenDailyMissionPopup_PointTimeout()
    {
        int stepValue = UnityEngine.Random.Range(0, 5);

        if (loadOnce == false)
        {
            loadOnce = true;

            Queue<DailyMissionData> dailyMissionDatas = new Queue<DailyMissionData>();
            dailyMissionDatas.Enqueue(
                MissionDataMaker.Instance.NewDailyMission(
                    isUnlock: 2,
                    unlock: 60,
                    step: stepValue,
                    itemCurr: itemCurr,
                    itemAll: itemAll,
                    itemEndTs: GlobalTime.Instance.GetTimeStamp() + 20,
                    passPoints: FakeRewardDataMaker.Instance
                                                   .GetMissionPassPoints(5)
                                                   .ToArray(),
                    pointCurr: pointCurr,
                    pointAll: pointAll,
                    pointEndTs: GlobalTime.Instance.GetTimeStamp() + 10,
                    pointState: (int)DailyMissionPointState.InProgress
                )
            );

            MissionDataMaker.Instance.LoadMissionResponse(
                missionPassData: MissionDataMaker.Instance.NewMissionPass(1, 100, 500),
                dailyMissionDatas: dailyMissionDatas
            );
        }

        _OpenDailyMissionPopup();
    }

    public void OpenDailyMissionPopup_MissionTimeout()
    {
        if (loadOnce == false)
        {
            loadOnce = true;
            int stepValue = UnityEngine.Random.Range(0, 5);

            Queue<DailyMissionData> dailyMissionDatas = new Queue<DailyMissionData>();
            dailyMissionDatas.Enqueue(
                MissionDataMaker.Instance.NewDailyMission(
                    isUnlock: 2,
                    unlock: 60,
                    step: stepValue,
                    itemCurr: itemCurr,
                    itemAll: itemAll,
                    itemEndTs: GlobalTime.Instance.GetTimeStamp() + 10,
                    passPoints: FakeRewardDataMaker.Instance
                                                   .GetMissionPassPoints(5)
                                                   .ToArray(),
                    pointCurr: pointCurr,
                    pointAll: pointAll,
                    pointEndTs: GlobalTime.Instance.GetTimeStamp() + 20,
                    pointState: (int)DailyMissionPointState.InProgress
                )
            );
            dailyMissionDatas.Enqueue(
                MissionDataMaker.Instance.NewDailyMission(
                    isUnlock: 2,
                    unlock: 60,
                    step: 1,
                    itemCurr: 0,
                    itemAll: itemAll,
                    itemEndTs: GlobalTime.Instance.GetTimeStamp() + itemRemainingSec,
                    passPoints: FakeRewardDataMaker.Instance
                                                   .GetMissionPassPoints(5)
                                                   .ToArray(),
                    pointCurr: pointCurr,
                    pointAll: pointAll,
                    pointEndTs: 0,
                    pointState: (int)DailyMissionPointState.InProgress
                )
            );

            MissionDataMaker.Instance.LoadMissionResponse(
                missionPassData: MissionDataMaker.Instance.NewMissionPass(1, 100, 500),
                dailyMissionDatas: dailyMissionDatas
            );
        }

        _OpenDailyMissionPopup();
    }

    public void OpenDailyMissionPopup(string step)
    {
        int stepValue = int.Parse(step); // 1, 2, 3, 4, 5, 0 (complete)

        MissionDataMaker.Instance.LoadMissionResponse(
            missionPassData: MissionDataMaker.Instance.NewMissionPass(1, 100, 500),
            dailyMissionData: MissionDataMaker.Instance.NewDailyMission(
                isUnlock: 2,
                unlock: 60,
                step: stepValue,
                itemCurr: itemCurr,
                itemAll: itemAll,
                itemEndTs: GlobalTime.Instance.GetTimeStamp() + itemRemainingSec,
                passPoints: FakeRewardDataMaker.Instance
                                               .GetMissionPassPoints(5)
                                               .ToArray(),
                pointCurr: pointCurr,
                pointAll: pointAll,
                pointEndTs: GlobalTime.Instance.GetTimeStamp() + pointRemainingSec,
                pointState: (int)DailyMissionPointState.InProgress
            ),
            pointRewardCount: TestPointRewardCount.CountRandom
        );

        _OpenDailyMissionPopup();
    }
    
    public void OpenDailyMissionPopup_NextStep(int prevStep)
    {
        MyInfo.DailyMission.Update(prevStep);

        MissionDataMaker.Instance.LoadMissionResponse(
            missionPassData: MissionDataMaker.Instance.NewMissionPass(1, 100, 500),
            dailyMissionData: MissionDataMaker.Instance.NewDailyMission(
                isUnlock: 2,
                unlock: 60,
                step: prevStep,
                itemCurr: itemCurr,
                itemAll: itemAll,
                itemEndTs: GlobalTime.Instance.GetTimeStamp() + itemRemainingSec,
                passPoints: FakeRewardDataMaker.Instance
                                               .GetMissionPassPoints(5)
                                               .ToArray(),
                pointCurr: pointCurr,
                pointAll: pointAll,
                pointEndTs: GlobalTime.Instance.GetTimeStamp() + pointRemainingSec,
                pointState: (int)DailyMissionPointState.InProgress
            ),
            pointRewardCount: TestPointRewardCount.CountRandom
        );

        _OpenDailyMissionPopup(
            interactable: false,
            onOpen: (PopupObject<MissionPassPopup> missionPassPopupObject) =>
            {
                MissionPassPopup missionPassPopup = missionPassPopupObject.GetPopup();
                Coroutines.Create(this)
                          .Add(NextStepCoroutine(missionPassPopup))
                          .Sequence();
            }
        );
    }

    private IEnumerator NextStepCoroutine(MissionPassPopup missionPassPopup)
    {
        yield return new WaitForSeconds(.5f);
        yield return missionPassPopup.UpdateProgressiveContent(MissionPassPopupTab.DailyMission, UpdateSpecificContentType.Mission);
    }

    public void OpenWeeklyPointPopup(string step)
    {
        Enum.TryParse(step, out DailyMissionPointState state);

        SetupWeeklyQuestData(state);

        _OpenDailyMissionPopup();
    }

    public void SetupWeeklyQuestData(DailyMissionPointState pointState, TestPointRewardCount pointRewardCount = TestPointRewardCount.CountRandom)
    {
        MissionDataMaker.Instance.LoadMissionResponse(
            missionPassData: MissionDataMaker.Instance.NewMissionPass(1, 100, 500),
            dailyMissionData: MissionDataMaker.Instance.NewDailyMission(
                isUnlock: 2,
                unlock: 60,
                step: UnityEngine.Random.Range(0, 6),
                itemCurr: itemCurr,
                itemAll: itemAll,
                itemEndTs: GlobalTime.Instance.GetTimeStamp() + itemRemainingSec,
                passPoints: FakeRewardDataMaker.Instance
                                               .GetMissionPassPoints(5)
                                               .ToArray(),
                pointCurr: pointState == DailyMissionPointState.Collect ? pointAll : pointCurr,
                pointAll: pointAll,
                pointEndTs: GlobalTime.Instance.GetTimeStamp() + pointRemainingSec,
                pointState: (int)pointState
            ),
            pointRewardCount: pointRewardCount
        ); 
    }

    private PopupObject<MissionPassPopup> _OpenDailyMissionPopup(bool interactable = true, Action<PopupObject<MissionPassPopup>> onOpen = null)
    {
        PopupObject<MissionPassPopup> popupObject = null;
        popupObject = Popups.MissionPass(tab: MissionPassPopupTab.DailyMission,
                                         syncData: true,
                                         interactable: interactable,
                                         onInit: () =>
                                         {
                                             if (popupObject != null)
                                             {
                                                 popupObject.GetPopup().RunAsFake = true;
                                             }
                                         })
                            .Async()
                            .Cache()
                            .OnOpen(() => onOpen?.Invoke(popupObject));
        return popupObject;
    }
}
