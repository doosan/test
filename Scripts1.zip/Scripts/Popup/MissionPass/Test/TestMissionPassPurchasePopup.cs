using Gaga.Popup;
using Gaga.System;
using System.Collections;
using Underc;
using Underc.LoadingScreen;
using Underc.Net;
using Underc.Net.Client;
using Underc.Popup;
using UnityEngine;

public class TestMissionPassPurchasePopup : TestSceneScaffold
{
    [SerializeField] private float price = 4.99f;
    [SerializeField] private float salePrice = 2.99f;
    [SerializeField] private float priceValue = 3f;
    [SerializeField] private bool bonus = false;
    [SerializeField] private bool missionBox = false;

    private IEnumerator Start()
    {
        yield return SetupAndLoad(new BaseLoadingItem[]
        { 
            new LoginLoadingItem(),
        });
    }

    private void LoadData()
    {
        bonus = false;
        missionBox = false;

        MissionPassData missionPassData = MissionDataMaker.Instance.NewMissionPass(
            price,
            salePrice,
            priceValue,
            bonus,
            missionBox
        );

        FakeHttpRequester.Instance.LoadedPurchaseMissionPassResponse = () =>
        {
            bonus = true;
            missionBox = true;

            return new ClientResponse();
        };

        MissionDataMaker.Instance.LoadMissionResponse(
            missionPassData: missionPassData,
            dailyMissionData: null,
            clamHarvestData: null,
            aquaBlitzData: null
        );
    }

    private IEnumerator LoadMission()
    {
        var req = FakeHttpRequester.Instance.Mission();
        yield return req.WaitForResponse();

        if (req.isSuccess)
        {
            NetworkSystem.HTTPHandler.Do(req.data);
        }
    }

    public void OpenMissionPassPurchase()
    {
        Coroutines.Create(this)
                  .Add(LoadData)
                  .Add(LoadMission)
                  .Add(_OpenMissionPassPurchase)
                  .Sequence();
    }

    private void _OpenMissionPassPurchase()
    {
        PopupObject<MissionPassPurchasePopup> popupObject = null;
        popupObject = Popups.MissionPassPurchase(onInit: () =>
                             {
                                 if (popupObject != null)
                                 {
                                     popupObject.GetPopup().RunAsFake = true;
                                 }
                             })
                            .Async()
                            .Cache();
    }

}
