using Gaga;
using System;
using System.Collections;
using System.Collections.Generic;
using Underc.LoadingScreen;
using Underc.Popup;
using Underc.UI;
using Underc.User;
using UnityEngine;

public enum TestDailyQuestMissionTextType
{
    Item,
    Banner,
    Tooltip
}

public class TestDailyMissionTooltip : TestSceneScaffold
{
    [SerializeField] private GameObjectVisibleToggle visibleToggle;
    [SerializeField] private List<DailyMissionItem> dailyQuestItems;
    [SerializeField] private List<DailyMissionIcon> dailyMissionIcons;

    private List<MissionFormatInfo> missionFormatInfos;

    private IEnumerator Start()
    {
        yield return SetupAndLoad(new BaseLoadingItem[]
        {
            new SlotIconLoadingItem(),
        });

        MakeMissionInfos();

        TestDailyQuestMissionTextType testType;
        string toggleName = visibleToggle.ActiveObject.name;
        if (Enum.TryParse(toggleName, out testType))
        {
            switch (testType)
            {
                case TestDailyQuestMissionTextType.Item:
                    //SetupItems();
                    break;

                case TestDailyQuestMissionTextType.Tooltip:
                    SetupTooltips();
                    break;
            }
        }
    }

    private void MakeMissionInfos()
    {
        missionFormatInfos = new List<MissionFormatInfo>();
        missionFormatInfos.Add(new MissionFormatInfo(MissionFormatType.spin.ToString(), 80, 0));
        missionFormatInfos.Add(new MissionFormatInfo(MissionFormatType.time.ToString(), 3, 0));
        missionFormatInfos.Add(new MissionFormatInfo(MissionFormatType.bettotal.ToString(), 1000000, 0));
        missionFormatInfos.Add(new MissionFormatInfo(MissionFormatType.wintotal.ToString(), 10000000, 0));
        missionFormatInfos.Add(new MissionFormatInfo(MissionFormatType.paywin.ToString(), 3, 4000000));
        missionFormatInfos.Add(new MissionFormatInfo(MissionFormatType.paybet.ToString(), 1, 400000));
        missionFormatInfos.Add(new MissionFormatInfo(MissionFormatType.lvup.ToString(), 5, 0));
        missionFormatInfos.Add(new MissionFormatInfo(MissionFormatType.big.ToString(), 9, 0));
        missionFormatInfos.Add(new MissionFormatInfo(MissionFormatType.mega.ToString(), 7, 0));
        missionFormatInfos.Add(new MissionFormatInfo(MissionFormatType.epic.ToString(), 4, 0));
        missionFormatInfos.Add(new MissionFormatInfo(MissionFormatType.free.ToString(), 6, 0));
        missionFormatInfos.Add(new MissionFormatInfo(MissionFormatType.golden.ToString(), 3, 0));
        missionFormatInfos.Add(new MissionFormatInfo(MissionFormatType.fish.ToString(), 3, 0));
    }

    private void SetupTooltips()
    {
        for (int i = 0; i < dailyMissionIcons.Count; i++)
        {
            DailyMissionIcon icon = dailyMissionIcons[i];
            MissionFormatInfo missionFormatInfo = missionFormatInfos[i];

            icon.NextMissionText.text = missionFormatInfo.GetFormat(
                missionFormatColor: MissionFormatColor.Brown, 
                linebreak: " "
            );
        }
    }
}
