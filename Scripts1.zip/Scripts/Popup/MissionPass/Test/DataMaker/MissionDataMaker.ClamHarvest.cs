using Gaga.System;
using System.Collections.Generic;
using System.Linq;
using Underc;
using Underc.Net;

public partial class MissionDataMaker : GameObjectSingleton<MissionDataMaker>
{
    public ClamHarvestData MakeClamHarvestData(long startTs, long endTs)
    {
        var clamHarvestData = new ClamHarvestData();
        clamHarvestData.start_ts = startTs;
        clamHarvestData.end_ts = endTs;
        clamHarvestData.gold = MakeClamData();
        clamHarvestData.silver = MakeClamData();
        return clamHarvestData;
    }

    private ClamHarvestClamData MakeClamData()
    {
        int clamIndex = 0;
        int pickax = 0;
        int maxPickax = 7;
        for (int i = 0; i < maxPickax; i++)
        {
            if (UnityEngine.Random.Range(0, 2) == 0)
            {
                continue;
            }

            clamIndex += (1 << i);
            pickax += 1;
        }
        int randomCount = UnityEngine.Random.Range(2, 4);
        List<FakeRewardData> fakeRewardDatas = FakeRewardDataMaker.Instance.GetCommonRewards(randomCount);

        ///
        var clamData = new ClamHarvestClamData();
        clamData.clam_index = clamIndex;
        clamData.pickaxe = pickax;
        clamData.max_pickaxe = maxPickax;
        clamData.reward = fakeRewardDatas.Select(data => new CommonRewardData(data.type.ToString(), data.value))
                                         .ToArray();

        return clamData;
    }
}