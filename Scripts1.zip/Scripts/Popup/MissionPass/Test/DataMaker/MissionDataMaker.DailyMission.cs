using Gaga.System;
using System.Collections.Generic;
using System.Linq;
using Underc;
using Underc.Net;
using Underc.Net.Client;
using Underc.User;

public partial class MissionDataMaker : GameObjectSingleton<MissionDataMaker>
{
    public void LoadMissionResponse(MissionPassData missionPassData = null,
                                    DailyMissionData dailyMissionData = null,
                                    TestPointRewardCount pointRewardCount = TestPointRewardCount.CountRandom)
    {
        var missionData = new MissionData();

        FakeHttpRequester.Instance.LoadedMissionResponse = () =>
        {
            missionData.ocean_pass = missionPassData;
            missionData.daily_quest = dailyMissionData;

            var missionResponse = FakeResponseMaker.New<MissionResponse>();
            missionResponse.data = missionData;

            return missionResponse;
        };

        LoadMissionPointClaimResponse(pointRewardCount);
    }

    private void LoadMissionPointClaimResponse(TestPointRewardCount pointRewardCount)
    {
        FakeHttpRequester.Instance.LoadedDailyMissionPointClaimResponse = () =>
        {
            var pointRewardDatas = new List<FakeRewardData>();
            FakeRewardDataMaker fakeRewardDataMaker = FakeRewardDataMaker.Instance;
            if (pointRewardCount == TestPointRewardCount.CountRandom)
            {
                pointRewardDatas.AddRange(fakeRewardDataMaker.GetCommonRewards(UnityEngine.Random.Range(3, 6)));
            }
            else
            {
                List<RewardType> rewardTypes = new List<RewardType>()
                {
                    RewardType.coin,
                    RewardType.pearl,
                    RewardType.ticket,
                    RewardType.obsidian,
                    RewardType.golden,
                };
                if (pointRewardCount == TestPointRewardCount.Count6)
                {
                    rewardTypes.Add(RewardType.fish);
                }
                pointRewardDatas.AddRange(fakeRewardDataMaker.GetSpecificRewards(rewardTypes));
            }

            var dailyMissionPointClaimData = new DailyMissionPointClaimData();
            dailyMissionPointClaimData.reward = pointRewardDatas.Select(data => new CommonRewardData(data.type.ToString(), data.value))
                                                                .ToArray();

            var dailyMissionPointClaimResponse = FakeResponseMaker.New<DailyMissionPointClaimResponse>();
            dailyMissionPointClaimResponse.data = dailyMissionPointClaimData;

            return dailyMissionPointClaimResponse;
        };
    }

    public DailyMissionData NewDailyMission(int isUnlock, 
                                            int unlock,
                                            int step = 0,
                                            long itemCurr = 0,
                                            long itemAll = 0,
                                            long itemEndTs = 0,
                                            long[] passPoints = null,
                                            long pointCurr = 0,
                                            long pointAll = 0,
                                            long pointEndTs = 0,
                                            int pointState = 0)
    {
        var dailyMissionData = new DailyMissionData();
        dailyMissionData.is_unlock = isUnlock;
        dailyMissionData.unlock = unlock;
        dailyMissionData.step = step;
        dailyMissionData.curr = itemCurr;
        dailyMissionData.all = itemAll;
        dailyMissionData.daily_end_ts = itemEndTs;
        dailyMissionData.mission = "spin";
        dailyMissionData.mp_point = passPoints;
        dailyMissionData.daily_end_ts = itemEndTs;
        dailyMissionData.weekly_curr = pointCurr;
        dailyMissionData.weekly_all = pointAll;
        dailyMissionData.weekly_end_ts = pointEndTs;
        dailyMissionData.n = pointState;
        return dailyMissionData;
    }
}