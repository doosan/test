using Gaga;
using Gaga.System;
using System.Collections.Generic;
using System.Linq;
using Underc;
using Underc.Net;
using Underc.Net.Client;
using Underc.User;
using UnityEngine;

public partial class MissionDataMaker : GameObjectSingleton<MissionDataMaker>
{
    public void LoadMissionResponse(MissionPassData missionPassData = null,
                                    Queue<DailyMissionData> dailyMissionDatas = null,
                                    ClamHarvestData clamHarvestData = null,
                                    Queue<AquaBlitzData> aquaBlitzDatas = null)
    {
        var missionData = new MissionData();
        AquaBlitzData aquaBlitzData = null;
        DailyMissionData dailyMissionData = null;

        LoadMissionPointClaimResponse(TestPointRewardCount.CountRandom);

        FakeHttpRequester.Instance.LoadedMissionResponse = () =>
        {
            if (dailyMissionDatas != null
                && dailyMissionDatas.Count > 0)
            {
                dailyMissionData = dailyMissionDatas.Dequeue();
                if (missionData.daily_quest != null)
                {
                    if (dailyMissionData.daily_end_ts == 0)
                    {
                        dailyMissionData.daily_end_ts = missionData.daily_quest.daily_end_ts;
                    }
                    if (dailyMissionData.weekly_end_ts == 0)
                    {
                        dailyMissionData.weekly_end_ts = missionData.daily_quest.weekly_end_ts;
                    }
                }
            }

            if (aquaBlitzDatas != null 
                && aquaBlitzDatas.Count > 0)
            {
                aquaBlitzData = aquaBlitzDatas.Dequeue();
                if (missionData.aqua_blitz != null)
                {
                    if (aquaBlitzData.end_ts == 0)
                    {
                        aquaBlitzData.end_ts = missionData.aqua_blitz.end_ts;
                    }
                    if (aquaBlitzData.mission_end_ts == 0)
                    {
                        aquaBlitzData.mission_end_ts = missionData.aqua_blitz.mission_end_ts;
                    }
                }
            }

            missionData.ocean_pass = missionPassData;
            missionData.daily_quest = dailyMissionData;
            missionData.clam_harvest = clamHarvestData;
            missionData.aqua_blitz = aquaBlitzData;

            // ts 값을 갱신해 줌
            var missionResponse = FakeResponseMaker.New<MissionResponse>();
            missionResponse.data = missionData;

            return missionResponse;
        };

        FakeHttpRequester.Instance.LoadedAquaBlitzClaimResponse = (int rewardIndex) =>
        {
            bool isLastReward = rewardIndex == aquaBlitzData.status.Length - 1;
            int rewardStep = rewardIndex + 1;
            int nextStep = Mathf.Clamp(rewardStep + 1, aquaBlitzData.step, MyInfo.AquaBlitz.PointRewardInfoCount);
            aquaBlitzData.status[rewardIndex] = isLastReward ? 0 : 2;
            aquaBlitzData.step = nextStep;

            AquaBlitzPointRewardInfo rewardInfo = MyInfo.AquaBlitz.GetPointRewardInfo(rewardIndex);
            var claimResponse = FakeResponseMaker.New<AquaBlitzClaimResponse>();
            claimResponse.reward = new CommonRewardData[] {
                new CommonRewardData(rewardInfo.type.ToString(), rewardInfo.value)
            };
            return claimResponse;
        };

        FakeHttpRequester.Instance.LoadedAquaBlitzMissionClaimResponse = (int _missionIndex) =>
        {
            AquaBlitzMissionInfo missionInfo = MyInfo.AquaBlitz.GetMissionInfo(_missionIndex);
            foreach (RewardInfo rewardInfo in missionInfo.rewardInfos)
            {
                switch (rewardInfo.type)
                {
                    case RewardType.blitz_point:
                        aquaBlitzData.curr += rewardInfo.value;
                        break;

                    case RewardType.mp_point:
                        break;
                }
            }

            // 아쿠아 블리츠 미션 갱신
            AquaBlitzMissionData mission = aquaBlitzData.mission[_missionIndex];
            mission.curr = 0;
            //mission.all += (long)(mission.all * 1.2f);
            //foreach (AquaBlitzMissionRewardData rewardData in mission.reward)
            //{
            //    rewardData.val += (long)(rewardData.val * 1.2f);
            //}

            // 미션 패스 레벨업
            if (missionPassData != null)
            {
                while (missionPassData.curr >= missionPassData.all)
                {
                    missionPassData.curr -= missionPassData.all;

                    missionPassData.step += 1;
                }
            }

            // 아쿠아 블리츠 레벨업
            while (aquaBlitzData.curr >= aquaBlitzData.all)
            {
                aquaBlitzData.curr -= aquaBlitzData.all;

                int stepIndex = aquaBlitzData.step - 1;
                aquaBlitzData.status[stepIndex] = 1;
                aquaBlitzData.step = Mathf.Min(aquaBlitzData.step + 1, aquaBlitzData.status.Length);
            }

            var claimResponse = FakeResponseMaker.New<AquaBlitzClaimResponse>();
            claimResponse.reward = missionInfo.rewardInfos
                                              .Select((RewardInfo rewardInfo) => new CommonRewardData(rewardInfo.type.ToString(), rewardInfo.value))
                                              .ToArray();
            claimResponse.mission_pass_step = missionPassData.step;
            claimResponse.aqua_blitz_curr = aquaBlitzData.curr;
            claimResponse.aqua_blitz_step = aquaBlitzData.step;
            return claimResponse;
        };
    }

    public void LoadMissionResponse(MissionPassData missionPassData = null,
                                    DailyMissionData dailyMissionData = null,
                                    ClamHarvestData clamHarvestData = null,
                                    AquaBlitzData aquaBlitzData = null)
    {
        Queue<AquaBlitzData> aquaBlitzDatas = new Queue<AquaBlitzData>();
        aquaBlitzDatas.Enqueue(aquaBlitzData);

        Queue<DailyMissionData> dailyMissionDatas = new Queue<DailyMissionData>();
        dailyMissionDatas.Enqueue(dailyMissionData);

        LoadMissionResponse(missionPassData, dailyMissionDatas, clamHarvestData, aquaBlitzDatas);
    }

    public AquaBlitzMissionSpinData CloneAquaBlitzMissionSpin(AquaBlitzMissionData originData, int missionIndex, int missionCurr)
    {
        AquaBlitzMissionSpinData missionSpinData = MakeAquaBlitzMissionSpinData(missionIndex, missionCurr, originData.all);
        missionSpinData.curr = missionCurr;

        return missionSpinData;
    }

    public AquaBlitzData CloneAquaBlitz(AquaBlitzData originData,
                                        int blitzStep = 5,
                                        int[] blitzStatus = null,
                                        long blitzCurr = 3300,
                                        long blitzAll = 3500,
                                        int[] missionCurrs = null,
                                        int blitzRemainingSec = 60 * 2,
                                        int missionRemainingSec = 60)
    {
        var aquaBlitzData = new AquaBlitzData();
        aquaBlitzData.types = originData.types;
        aquaBlitzData.big = originData.big;
        aquaBlitzData.values = originData.values;
        aquaBlitzData.mission = missionCurrs == null ? 
                                MakeAquaBlitzMissionDatas() :
                                originData.mission;
        WriteAquaBlitz(aquaBlitzData,
                       blitzStep,
                       blitzStatus,
                       blitzCurr,
                       blitzAll,
                       missionCurrs,
                       blitzRemainingSec,
                       missionRemainingSec);

        return aquaBlitzData;
    }

    private void WriteAquaBlitz(AquaBlitzData originData,
                                int blitzStep = 5,
                                int[] blitzStatus = null,
                                long blitzCurr = 3300,
                                long blitzAll = 3500,
                                int[] missionCurrs = null,
                                int blitzRemainingSec = 60 * 2,
                                int missionRemainingSec = 60)
    {
        originData.step = blitzStep;
        originData.status = blitzStatus;
        originData.curr = blitzCurr;
        originData.all = blitzAll;
        if (missionCurrs != null)
        {
            for (int i = 0; i < originData.mission.Length; i++)
            {
                originData.mission[i].curr = missionCurrs[i];
            }
        }

        if (blitzRemainingSec > 0)
        {
            originData.end_ts = GlobalTime.Instance.GetTimeStamp() + blitzRemainingSec;
        }
        if (missionRemainingSec > 0)
        {
            originData.mission_end_ts = GlobalTime.Instance.GetTimeStamp() + missionRemainingSec;
        }
    }

    public AquaBlitzData NewAquaBlitz(int blitzStep = 5,
                                      int[] blitzStatus = null,
                                      long blitzCurr = 3300,
                                      long blitzAll = 3500,
                                      int[] missionCurrs = null,
                                      int blitzRemainingSec = 60 * 2,
                                      int missionRemainingSec = 60)
    {
        var aquaBlitzData = new AquaBlitzData();
        aquaBlitzData.types = new string[] { "coin", "coin", "coin", "coin", "coin", "coin", "coin", "coin", "coin", "coin", "coin" };
        aquaBlitzData.big = new int[] { 3, 6, 9 };
        aquaBlitzData.values = new long[] { 100000, 10000, 2, 1, 5, 12, 12, 1000000, 3, 2, 1000000 };
        aquaBlitzData.mission = MakeAquaBlitzMissionDatas();
        WriteAquaBlitz(aquaBlitzData, 
                       blitzStep, 
                       blitzStatus, 
                       blitzCurr, 
                       blitzAll, 
                       missionCurrs, 
                       blitzRemainingSec, 
                       missionRemainingSec);

        return aquaBlitzData;
    }

    private AquaBlitzMissionData[] MakeAquaBlitzMissionDatas()
    {
        return new AquaBlitzMissionData[]
        {
            MakeAquaBlitzMissionData(slotID: GetRandomSlotID(),
                                     mission: "win",
                                     curr: 0,
                                     all: 10,
                                     status: 0,
                                     reward: MakeAquaBlitzMissionRewardDatas(passPoint: 500, blitzPoint: 300)),

            MakeAquaBlitzMissionData(slotID: GetRandomSlotID(),
                                     mission: "win",
                                     curr: 0,
                                     all: 10,
                                     status: 0,
                                     reward: MakeAquaBlitzMissionRewardDatas(passPoint: 500, blitzPoint: 300)),

            MakeAquaBlitzMissionData(slotID: GetRandomSlotID(),
                                     mission: "win",
                                     curr: 0,
                                     all: 10,
                                     status: 0,
                                     reward: MakeAquaBlitzMissionRewardDatas(passPoint: 500, blitzPoint: 300)),

            MakeAquaBlitzMissionData(slotID: GetRandomSlotID(),
                                     mission: "win",
                                     curr: 0,
                                     all: 10,
                                     status: 0,
                                     reward: MakeAquaBlitzMissionRewardDatas(passPoint: 500, blitzPoint: 300)),

            MakeAquaBlitzMissionData(slotID: GetRandomSlotID(),
                                     mission: "win",
                                     curr: 0,
                                     all: 10,
                                     status: 1,
                                     reward: MakeAquaBlitzMissionRewardDatas(passPoint: 500, blitzPoint: 300)),
        }; ;
    }

    private AquaBlitzMissionSpinData MakeAquaBlitzMissionSpinData(int missionIndex, long curr, long all)
    {
        var data = new AquaBlitzMissionSpinData();
        data.index = missionIndex;
        data.curr = curr;
        data.all = all;
        return data;
    }

    private AquaBlitzMissionData MakeAquaBlitzMissionData(int slotID, string mission, long curr, long all, int status, AquaBlitzMissionRewardData[] reward)
    {
        var data = new AquaBlitzMissionData();
        data.slotid = slotID;
        data.mission = mission;
        data.curr = curr;
        data.all = all;
        data.reward = reward;
        data.status = status;

        return data;
    }

    private int GetRandomSlotID()
    {
        if (slotPosterItemsInShown == null)
        {
            Debug.LogWarning($"Init() 메서드를 먼저 호출해 주세요.");
            Init();
        }

        int randomItemIndex = Random.Range(0, slotPosterItemsInShown.Count);
        int slotID = slotPosterItemsInShown[randomItemIndex].id;
        //Debug.Log($"==== GetRandomSlotID : {slotID}");
        return slotID;
    }

    private AquaBlitzMissionRewardData[] MakeAquaBlitzMissionRewardDatas(long passPoint, long blitzPoint)
    {
        return new AquaBlitzMissionRewardData[]
        {
            MakeAquaBlitzMissionRewardData("mp_point", passPoint),
            MakeAquaBlitzMissionRewardData("blitz_point", blitzPoint)
        };
    }
    private AquaBlitzMissionRewardData MakeAquaBlitzMissionRewardData(string rwd, long val)
    {
        var data = new AquaBlitzMissionRewardData();
        data.rwd = rwd;
        data.val = val;

        return data;
    }
}