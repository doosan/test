using Gaga;
using Gaga.System;
using System.Collections.Generic;
using Underc;

public partial class MissionDataMaker : GameObjectSingleton<MissionDataMaker>
{
    public class MissionPassSeasonInfo
    {
        public long remainingSec;

        public MissionPassSeasonInfo(long remainingSec)
        {
            this.remainingSec = remainingSec;
        }
    }

    public class MissionPassStepInfo
    {
        public int step;
        public long curr;
        public long all;

        public MissionPassStepInfo(int step, long curr, long all)
        {
            this.step = step;
            this.curr = curr;
            this.all = all;
        }
    }

    public class MissionPassStatusInfo
    {
        public int[] free;
        public int[] buy;

        public MissionPassStatusInfo(int[] free, int[] buy)
        {
            this.free = free;
            this.buy = buy;
        }
    }

    public class MissionPassBuyInfo
    {
        public float price;
        public float sale_price;
        public float price_value;
        public bool bonus;
        public bool mission_box;

        public MissionPassBuyInfo(float price, float sale_price, float price_value, bool bonus, bool mission_box)
        {
            this.price = price;
            this.sale_price = sale_price;
            this.price_value = price_value;
            this.bonus = bonus;
            this.mission_box = mission_box;
        }
    }

    public MissionPassData NewMissionPass(int step, long curr, long all)
    {
        return NewMissionPass(
            seasonInfo: new MissionPassSeasonInfo(60 * 5),
            stepInfo: new MissionPassStepInfo(step, curr, all),
            buyInfo: new MissionPassBuyInfo(price: 4.99f, sale_price: 2.99f, price_value: 3f, bonus: false, mission_box: false),
            statusInfo: new MissionPassStatusInfo(new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
                                                  new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 })
        );
    }

    public MissionPassData NewMissionPass(float price, float salePrice, float priceValue, bool bonus, bool missionBox)
    {
        return NewMissionPass(
            seasonInfo: new MissionPassSeasonInfo(60 * 5),
            stepInfo: new MissionPassStepInfo(1, 1, 3),
            buyInfo: new MissionPassBuyInfo(price, salePrice, priceValue, bonus, missionBox),
            statusInfo: new MissionPassStatusInfo(new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
                                                  new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 })
        );
    }

    public MissionPassData NewMissionPass(int step, int[] freeStatus, int[] buyStatus, bool hasMissionPass)
    {
        return NewMissionPass(
            seasonInfo: new MissionPassSeasonInfo(60 * 5),
            stepInfo: new MissionPassStepInfo(step, 1, 3),
            buyInfo: new MissionPassBuyInfo(price: 4.99f, sale_price: 2.99f, price_value: 3f, bonus: hasMissionPass, mission_box: hasMissionPass),
            statusInfo: new MissionPassStatusInfo(freeStatus, buyStatus)
        );
    }

    public MissionPassData NewMissionPass(long remainingSec)
    {
        return NewMissionPass(
            seasonInfo: new MissionPassSeasonInfo(remainingSec),
            stepInfo: new MissionPassStepInfo(1, 1, 3),
            buyInfo: new MissionPassBuyInfo(price: 4.99f, sale_price: 2.99f, price_value: 3f, bonus: false, mission_box: false),
            statusInfo: new MissionPassStatusInfo(new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
                                                  new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 })
        );
    }

    private MissionPassData NewMissionPass(
        MissionPassSeasonInfo seasonInfo,
        MissionPassStepInfo stepInfo, 
        MissionPassBuyInfo buyInfo, 
        MissionPassStatusInfo statusInfo
    )
    {
        var missionPassData = new MissionPassData();
        missionPassData.end_ts = GlobalTime.Instance.GetTimeStamp() + seasonInfo.remainingSec;
        missionPassData.season = 1;

        missionPassData.step = stepInfo.step;
        missionPassData.curr = stepInfo.curr;
        missionPassData.all = stepInfo.all;

        MissionPassItemData freeData = new MissionPassItemData();
        freeData.types = new string[] { "vip_point" , "coin", "pearl", "ticket", "golden", "obsidian", "fish", "xp_booster", "coin" };
        freeData.values = new long[] { 500, 50000, 3000, 500, 1, 1, 5, 16, 10000000 };
        freeData.status = statusInfo.free;  // 상태(0: 미션 미완료, 1: 미션 완료, 2: 보상 완료)
        missionPassData.free = freeData;

        MissionPassBuyItemData buyData = new MissionPassBuyItemData();
        buyData.itemid = "missionpass.p1";
        buyData.vip_point = 500;
        buyData.price = buyInfo.price;
        buyData.sale_price = buyInfo.sale_price;
        buyData.bonus = buyInfo.bonus;
        buyData.mission_box = buyInfo.mission_box;
        buyData.types = new string[] { "vip_point", "coin", "pearl", "ticket", "golden", "obsidian", "fish", "xp_booster", "coin" };
        buyData.values = new long[] { 500, 99999, 5000, 1000, 3, 3, 131, 32, 5000000 };
        buyData.status = statusInfo.buy;    // 상태(0: 미션 미완료, 1: 미션 완료, 2: 보상 완료)
        missionPassData.buy = buyData;

        return missionPassData;
    }

    public MissionPassClaimData NewMissionPassClaimData(MissionPassItemData itemData, int stepIndex)
    {
        string type = itemData.types[stepIndex];
        long value = itemData.values[stepIndex];

        int lastIndex = itemData.status.Length - 1;
        int status = itemData.status[stepIndex];
        if (status == 1)
        {
            itemData.status[stepIndex] = stepIndex == lastIndex ? 
                                         0 :
                                         2;
        }

        var claimData = new MissionPassClaimData();
        claimData.rwd = type;
        claimData.val = value;

        return claimData;
    }

    public MissionPassClaimData[] NewMissionPassPreviewDatas(MissionPassItemData itemData)
    {
        int length = itemData.types.Length;
        var claimDatas = new List<MissionPassClaimData>();
        for (int i = 0; i < length; i++)
        {
            string type = itemData.types[i];
            long value = itemData.values[i];

            var claimData = new MissionPassClaimData();
            claimData.rwd = type;
            claimData.val = value;

            claimDatas.Add(claimData);
        }

        return claimDatas.ToArray();
    }

    public MissionPassClaimData[] NewMissionPassClaimDatas(MissionPassItemData itemData)
    {
        int length = itemData.types.Length;
        var claimDatas = new List<MissionPassClaimData>();
        for (int i = 0; i < length; i++)
        {
            MissionPassClaimData claimData = NewMissionPassClaimData(itemData, i);
            claimDatas.Add(claimData);
        }

        return claimDatas.ToArray();
    }
}