using Gaga.System;
using SlotGame;
using System.Collections.Generic;
using UnityEngine;

public partial class MissionDataMaker : GameObjectSingleton<MissionDataMaker>
{
    private List<SlotPosterItem> slotPosterItemsInShown;

    private bool initOnce;

    public void Init()
    {
        if (initOnce == false)
        {
            initOnce = true;

            SlotPresetList slotPresetList = Resources.Load<SlotPresetList>("SlotPresetList");
            slotPosterItemsInShown = slotPresetList.FindShown();
        }
    }
}
