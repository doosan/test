using Gaga.DeveloperTools;
using Gaga.Popup;
using Gaga.Util;
using System.Collections;
using Underc;
using Underc.LoadingScreen;
using Underc.Net;
using Underc.Net.Client;
using Underc.Popup;
using Underc.User;
using Underc.Util;
using UnityEngine;

public class TestMissionPassPanel : TestSceneScaffold
{
    private bool loadOnce;

    private IEnumerator Start()
    {
#if GGDEV
        SetupDeveloperTools();
#endif

        yield return SetupAndLoad(new BaseLoadingItem[]
        {
            new LoginLoadingItem(),
            new SettingsLoadingItem(),
            new HTTPLoadingItem<UserCoreResponse>(
                () => NetworkSystem.HTTPRequester.UserCoreWithAlarms(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<FishBookListResponse>(
                () => NetworkSystem.HTTPRequester.FishBookList(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<ProfileResponse>(
                () => NetworkSystem.HTTPRequester.Profile(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new ABFishLoadingItem(),
            new ABFishIconLoadingItem(),
            new SlotIconLoadingItem(),
            new ABLoadingItem(AssetBundleName.EFFECT),
            new TopUILoadingItem(),
            new RewardBonusUILoadingItem()
        });
    }

    public void Open()
    {
        PopupObject<MissionPassPopup> popupObject = null;
        popupObject = Popups.MissionPass(tab: MissionPassPopupTab.MissionPass,
                                         syncData: true)
                            .Async()
                            .Cache();
    }

    public void RunTutorial()
    {
        var missionDataMaker = MissionDataMaker.Instance;
        MissionPassData missionPassData = MissionDataMaker.Instance.NewMissionPass(
            step: 1,
            freeStatus: new int[] { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
            buyStatus: new int[] { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
            hasMissionPass: false
        );

        missionDataMaker.LoadMissionResponse(
            missionPassData: missionPassData,
            dailyMissionData: null,
            clamHarvestData: null,
            aquaBlitzData: null
        );

        FakeHttpRequester.Instance.LoadedPurchaseMissionPassResponse = () =>
        {
            missionPassData.buy.bonus = true;
            missionPassData.buy.mission_box = true;

            return new ClientResponse();
        };

        PopupObject<MissionPassPopup> popupObject = null;
        popupObject = Popups.MissionPass(tab: MissionPassPopupTab.MissionPass,
                                         syncData: true,
                                         onInit: () => popupObject.GetPopup().RunAsFake = true)
                            .Async()
                            .Cache();
    }

    public void TimeExpired()
    {
        if (loadOnce == false)
        {
            loadOnce = true;

            var missionDataMaker = MissionDataMaker.Instance;
            MissionPassData missionPassData = missionDataMaker.NewMissionPass(
                remainingSec: 10
            );

            missionDataMaker.LoadMissionResponse(
                missionPassData: missionPassData,
                dailyMissionData: null,
                clamHarvestData: null,
                aquaBlitzData: null
            );
        }

        PopupObject<MissionPassPopup> popupObject = null;
        popupObject = Popups.MissionPass(tab: MissionPassPopupTab.MissionPass,
                                         syncData: true,
                                         onInit: () => popupObject.GetPopup().RunAsFake = true)
                            .Async()
                            .Cache();
    }

    private IEnumerator LoadMission()
    {
        IRequest<MissionResponse> req = FakeHttpRequester.Instance.Mission();
        yield return req.WaitForResponse();

        if (req.isSuccess)
        {
            NetworkSystem.HTTPHandler.Do(req.data);
        }
    }

#if GGDEV
        private void SetupDeveloperTools()
        {
            if (DeveloperTools.Instance.ContainsID("sepa_general") == true)
            {
                DeveloperTools.Instance.RemoveItem("sepa_general");
            }

            DeveloperTools.Instance.AddSeparator("sepa_general", 0);
      
            if (DeveloperTools.Instance.ContainsID("uid") == true)
            {
                DeveloperTools.Instance.RemoveItem("uid");
            }

            DeveloperTools.Instance.AddActionItem("uid", MyInfo.ID, () => MyInfo.ID.CopyToClipboard(), 0);

            if (DeveloperTools.Instance.ContainsID("serverName") == true)
            {
                DeveloperTools.Instance.RemoveItem("serverName");
            }

            DeveloperTools.Instance.AddActionItem("serverName"
                                                  ,Address.SERVER_NAME
                                                  ,()=>
                                                    {
#if DEV
                                                        DeveloperTools.Instance.IsOn = false;
                                                        Popups.ServerList();
#endif
                                                    }
                                                  ,0);
        }
#endif

        protected override void Update()
        {
            base.Update();
#if GGDEV
            if (Input.GetKeyDown(KeyCode.D) == true && Input.GetKey(KeyCode.LeftShift))
            {
                Gaga.DeveloperTools.DeveloperTools.Instance.IsOn = !Gaga.DeveloperTools.DeveloperTools.Instance.IsOn;
            }
#endif
        }

}
