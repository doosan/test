
using Gaga.Popup;
using Gaga.System;
using System.Collections;
using Underc.LoadingScreen;
using Underc.Net;
using Underc.Net.Client;
using Underc.Util;
using UnityEngine;
using UnityEngine.UI;

public class TestSceneScaffold : MonoBehaviour
{
    private PopupBehaviour[] editingPopups;
    private Button[] allButtons;

    protected IEnumerator SetupAndLoad(BaseLoadingItem[] loadingItems)
    {
        SDKConfig.Initialize(SDKConfig.SDKType.Dev);

        ClosePopupInEdit();
        GetAllButtons();
        SetButtonInteractable(false);
        yield return Load(loadingItems);
        SetButtonInteractable(true);
    }

    protected BaseLoadingItem[] GetRewardLoadingItems()
    {
        return new BaseLoadingItem[]
        {
            new LoginLoadingItem(),
            new HTTPLoadingItem<UserCoreResponse>(
                () => NetworkSystem.HTTPRequester.UserCoreWithAlarms(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<FishBookListResponse>(
                () => NetworkSystem.HTTPRequester.FishBookList(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<ProfileResponse>(
                () => NetworkSystem.HTTPRequester.Profile(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new ABFishLoadingItem(),
            new ABFishIconLoadingItem(),
            new ProfileIconLoadingItem(),
            new SlotIconLoadingItem(),
            new ABLoadingItem(AssetBundleName.EFFECT),
            new TopUILoadingItem(),
            new RewardBonusUILoadingItem(),
        };
    }

    protected IEnumerator JustLoad(BaseLoadingItem[] loadingItems)
    {
        SetButtonInteractable(false);
        yield return Load(loadingItems);
        SetButtonInteractable(true);
    }

    private IEnumerator Load(BaseLoadingItem[] loadingItems)
    {
        int tryCount = 3;
        while (tryCount > 0)
        {
            Debug.Log("==== 로딩을 시작합니다 : " + tryCount + " / 3");
            tryCount -= 1;

            bool hasError = false;
            foreach (BaseLoadingItem loadingItem in loadingItems)
            {
                string error = "";
                yield return loadingItem.Load(
                    onProgress: (int progress) => { },
                    onComplete: (Result result) =>
                    {
                        if (result.success == false)
                        {
                            error = result.error;
                        }
                    }
                );

                if (string.IsNullOrEmpty(error) == false)
                {
                    Debug.LogWarning("==== 로딩 중 에러가 발생했습니다 : " + loadingItem.Name + ", " + error);
                    hasError = true;
                    break;
                }
            }

            if (hasError == false)
            {
                break;
            }
        }
    }

    protected void SetButtonInteractable(bool value)
    {
        foreach (Button button in allButtons)
        {
            button.interactable = value;
        }
    }

    private void GetAllButtons()
    {
        allButtons = GetComponentsInChildren<Button>();
    }

    private void ClosePopupInEdit()
    {
        editingPopups = GetComponentsInChildren<PopupBehaviour>();
        foreach (PopupBehaviour popup in editingPopups)
        {
            popup.gameObject.SetActive(false);
        }
    }

    protected virtual void Update()
    {
#if UNITY_EDITOR
        if (Input.GetKeyDown(KeyCode.LeftArrow) && Input.GetKey(KeyCode.LeftShift))
        {
            BackButtonSystem.Instance.Back();
        }
        else if (Input.GetKeyDown(KeyCode.UpArrow) && Input.GetKey(KeyCode.LeftShift))
        {
            if (BackButtonSystem.Instance.Count > 0)
            {
                foreach (var item in BackButtonSystem.Instance.GetEnumerable())
                {
                    Debug.LogFormat("BackableItem {0}", item.name);
                }
            }

        }
#elif UNITY_ANDROID
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                BackButtonSystem.Instance.Back();
            }
#endif
    }
}
