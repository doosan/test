using Gaga.Popup;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Underc.LoadingScreen;
using Underc.Net;
using Underc.Net.Client;
using Underc.Popup;
using Underc.User;
using Underc.Util;
using UnityEngine;

public class TestMissionPassRewardPopup : TestSceneScaffold
{
    [SerializeField] Transform startPositionTransform;

    private IEnumerator Start()
    {
        yield return SetupAndLoad(new BaseLoadingItem[]
        {
            new LoginLoadingItem(),
            new HTTPLoadingItem<UserCoreResponse>(
                () => NetworkSystem.HTTPRequester.UserCoreWithAlarms(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<CasinoBonusResponse>(
                () => NetworkSystem.HTTPRequester.CasinoBonus(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<SeaListResponse>(
                () => NetworkSystem.HTTPRequester.SeaList(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<SeaMineResponse>(
                () => NetworkSystem.HTTPRequester.SeaMine(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<FishBookListResponse>(
                () => NetworkSystem.HTTPRequester.FishBookList(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new ABFishLoadingItem(),
            new ABFishIconLoadingItem(),
            new ABLoadingItem(AssetBundleName.EFFECT),
            new TopUILoadingItem(),
            new RewardBonusUILoadingItem(),
        });
    }

    public void MissionPassFree()
    {
        List<RewardInfo> rewardInfos = FakeRewardDataMaker.Instance
                                                          .GetCommonRewards(Random.Range(6, 10))
                                                          .Select((FakeRewardData data) =>
                                                          {
                                                              var rewardInfo = new RewardInfo();
                                                              rewardInfo.type = data.type;
                                                              rewardInfo.value = data.value;
                                                              return rewardInfo;
                                                          })
                                                          .ToList();

        PopupObject<MissionPassRewardPopup> popupObject = null;
        popupObject = Popups.MissionPassReward(MissionPassRewardPopup.TitleType.MissionPassFree,
                                               rewardInfos,
                                               onInit: () =>
                                               {
                                                   SimpleRewardItemCollector itemCollector = popupObject?.GetPopup().RewardItemCollector;
                                                   itemCollector.RegisterAllStartPosition(startPositionTransform.position);
                                               });
    }

    public void MissionPassBonus()
    {
        List<RewardInfo> rewardInfos = FakeRewardDataMaker.Instance
                                                          .GetCommonRewards(Random.Range(6, 10))
                                                          .Select((FakeRewardData data) =>
                                                          {
                                                              var rewardInfo = new RewardInfo();
                                                              rewardInfo.type = data.type;
                                                              rewardInfo.value = data.value;
                                                              return rewardInfo;
                                                          })
                                                          .ToList();

        PopupObject<MissionPassRewardPopup> popupObject = null;
        popupObject = Popups.MissionPassReward(MissionPassRewardPopup.TitleType.MissionPassBonus,
                                               rewardInfos,
                                               onInit: () =>
                                               {
                                                   SimpleRewardItemCollector itemCollector = popupObject?.GetPopup().RewardItemCollector;
                                                   itemCollector.RegisterAllStartPosition(startPositionTransform.position);
                                               });
    }
}
