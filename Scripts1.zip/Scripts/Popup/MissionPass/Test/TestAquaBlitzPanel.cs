using Gaga.Popup;
using System.Collections;
using System.Collections.Generic;
using Underc;
using Underc.LoadingScreen;
using Underc.Net;
using Underc.Net.Client;
using Underc.Popup;
using Underc.User;
using Underc.Util;
using UnityEngine;

public class TestAquaBlitzPanel : TestSceneScaffold
{
    [SerializeField]
    private List<int> blitzStatus = new List<int>()
    {
        2, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0
    };

    private MissionDataMaker MissionDataMaker
    { 
        get
        {
            if (aquaBlitzDataMaker == null)
            {
                aquaBlitzDataMaker = MissionDataMaker.Instance;
            }
            return aquaBlitzDataMaker;
        }
    }
    private MissionDataMaker aquaBlitzDataMaker;

    private IEnumerator Start()
    {
        yield return SetupAndLoad(new BaseLoadingItem[]
        {
            new LoginLoadingItem(),
            new HTTPLoadingItem<FishBookListResponse>(
                () => NetworkSystem.HTTPRequester.FishBookList(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new ABFishLoadingItem(),
            new ABFishIconLoadingItem(),
            new ProfileIconLoadingItem(),
            new SlotIconLoadingItem(),
            new ABLoadingItem(AssetBundleName.EFFECT),
            new TopUILoadingItem(),
            new RewardBonusUILoadingItem(),
        });
    }

    public void PointRewardTooltip()
    {
        MissionDataMaker.LoadMissionResponse(
            aquaBlitzData: MissionDataMaker.NewAquaBlitz(
                blitzStep: 5,
                blitzStatus: new int[] { 2, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0 }
            )
        );

        MyInfo.AquaBlitz.UpdateLatestMissionSpinIndex(-1);

        PopupObject<MissionPassPopup> popupObject = null;
        popupObject = Popups.MissionPass(tab: MissionPassPopupTab.AquaBlitz,
                                         syncData: true,
                                         onInit: () =>
                                         {
                                             if (popupObject != null)
                                             {
                                                 popupObject.GetPopup().RunAsFake = true;
                                             }
                                         })
                            .Async()
                            .Cache();
    }

    public void CollectPointReward()
    {
        MissionDataMaker.LoadMissionResponse(
            aquaBlitzData: MissionDataMaker.NewAquaBlitz(
                blitzStep: 5,
                blitzStatus: new int[] { 2, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0 }
            )
        );

        MyInfo.AquaBlitz.UpdateLatestMissionSpinIndex(-1);

        PopupObject<MissionPassPopup> popupObject = null;
        popupObject = Popups.MissionPass(tab: MissionPassPopupTab.AquaBlitz,
                                         syncData: true,
                                         onInit: () =>
                                         {
                                             if (popupObject != null)
                                             {
                                                 popupObject.GetPopup().RunAsFake = true;
                                             }
                                         })
                            .Async()
                            .Cache();
    }

    public void CollectPointRewardTail()
    {
        MissionDataMaker.LoadMissionResponse(
            missionPassData: MissionDataMaker.NewMissionPass(
                step: 1,
                curr: 0,
                all: 1000
            ),
            aquaBlitzData: MissionDataMaker.NewAquaBlitz(
                blitzStep: 11, 
                blitzStatus: new int[] { 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0 },
                missionCurrs: new int[] { 10, 2, 2, 2, 2 }
            )
        );

        MyInfo.AquaBlitz.UpdateLatestMissionSpinIndex(-1);

        PopupObject<MissionPassPopup> popupObject = null;
        popupObject = Popups.MissionPass(tab: MissionPassPopupTab.AquaBlitz,
                                         syncData: true,
                                         onInit: () =>
                                         {
                                             if (popupObject != null)
                                             {
                                                 popupObject.GetPopup().RunAsFake = true;
                                             }
                                         })
                            .Async()
                            .Cache();
    }

    public void CollectMissionReward()
    {
        MissionDataMaker.LoadMissionResponse(
            missionPassData: MissionDataMaker.NewMissionPass(
                step: 1,
                curr: 900,
                all: 1000
            ),
            aquaBlitzData: MissionDataMaker.NewAquaBlitz(
                blitzStep: 5,
                blitzStatus: blitzStatus.ToArray(),
                missionCurrs: new int[] { 10, 2, 2, 2, 2 }
            )
        );

        MyInfo.AquaBlitz.UpdateLatestMissionSpinIndex(-1);

        PopupObject <MissionPassPopup> popupObject = null;
        popupObject = Popups.MissionPass(tab: MissionPassPopupTab.AquaBlitz,
                                         syncData: true,
                                         onInit: () =>
                                         {
                                             if (popupObject != null)
                                             {
                                                 popupObject.GetPopup().RunAsFake = true;
                                             }
                                         })
                            .Async()
                            .Cache();
    }

    public void ShowMissionInProgress()
    {
        MissionDataMaker.LoadMissionResponse(
            aquaBlitzData: MissionDataMaker.NewAquaBlitz(
                blitzStep: 5,
                blitzStatus: new int[] { 2, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0 }
            )
        );

        MyInfo.AquaBlitz.UpdateLatestMissionSpinIndex(UnityEngine.Random.Range(0, 5));

        PopupObject<MissionPassPopup> popupObject = null;
        popupObject = Popups.MissionPass(tab: MissionPassPopupTab.AquaBlitz,
                                         syncData: true,
                                         onInit: () =>
                                         {
                                             if (popupObject != null)
                                             {
                                                 popupObject.GetPopup().RunAsFake = true;
                                             }
                                         })
                            .Async()
                            .Cache();
    }

    public void BlitzTimeExpired()
    {
        Queue<AquaBlitzData> aquaBlitzDatas = new Queue<AquaBlitzData>();
        AquaBlitzData aquaBlitzData1 = MissionDataMaker.NewAquaBlitz(
            blitzStep: 5,
            blitzStatus: new int[] { 2, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0 },

            missionCurrs: new int[] { 10, 2, 2, 2, 2 },
            blitzRemainingSec: 10,
            missionRemainingSec: 20
        );

        AquaBlitzData aquaBlitzData2 = MissionDataMaker.CloneAquaBlitz(
            originData: aquaBlitzData1,
            blitzStep: 1,
            blitzStatus: new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
            blitzCurr: 0,

            missionCurrs: new int[] { 10, 2, 2, 2, 2 },
            blitzRemainingSec: 300,
            missionRemainingSec: 0
        );

        aquaBlitzDatas.Enqueue(aquaBlitzData1);
        aquaBlitzDatas.Enqueue(aquaBlitzData2);
        aquaBlitzDatas.Enqueue(MissionDataMaker.CloneAquaBlitz(
            originData: aquaBlitzData2,
            blitzStep: 1,
            blitzStatus: new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
            blitzCurr: 0,

            missionCurrs: null,
            blitzRemainingSec: 0,
            missionRemainingSec: 300
        ));

        MissionDataMaker.LoadMissionResponse(aquaBlitzDatas: aquaBlitzDatas);

        PopupObject<MissionPassPopup> popupObject = null;
        popupObject = Popups.MissionPass(tab: MissionPassPopupTab.AquaBlitz,
                                         syncData: true,
                                         onInit: () =>
                                         {
                                             if (popupObject != null)
                                             {
                                                 popupObject.GetPopup().RunAsFake = true;
                                             }
                                         })
                            .Async()
                            .Cache();
    }

    public void MissionTimeExpired()
    {
        Queue<AquaBlitzData> aquaBlitzDatas = new Queue<AquaBlitzData>();
        AquaBlitzData aquaBlitzData1 = MissionDataMaker.NewAquaBlitz(
            blitzStep: 5,
            blitzStatus: new int[] { 2, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0 },

            missionCurrs: new int[] { 10, 2, 2, 2, 2 },
            blitzRemainingSec: 20,
            missionRemainingSec: 10
        );

        AquaBlitzData aquaBlitzData2 = MissionDataMaker.CloneAquaBlitz(
            originData: aquaBlitzData1,
            blitzStep: 5,
            blitzStatus: new int[] { 2, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0 },

            missionCurrs: null,
            blitzRemainingSec: 0,
            missionRemainingSec: 300
        );

        aquaBlitzDatas.Enqueue(aquaBlitzData1);
        aquaBlitzDatas.Enqueue(aquaBlitzData2);
        aquaBlitzDatas.Enqueue(MissionDataMaker.CloneAquaBlitz(
            originData: aquaBlitzData2,
            blitzStep: 1,
            blitzStatus: new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
            blitzCurr: 0,

            missionCurrs: new int[] { 0, 0, 0, 0, 0 },
            blitzRemainingSec: 300,
            missionRemainingSec: 0
        ));

        MissionDataMaker.LoadMissionResponse(aquaBlitzDatas: aquaBlitzDatas);

        PopupObject<MissionPassPopup> popupObject = null;
        popupObject = Popups.MissionPass(tab: MissionPassPopupTab.AquaBlitz,
                                         syncData: true,
                                         onInit: () =>
                                         {
                                             if (popupObject != null)
                                             {
                                                 popupObject.GetPopup().RunAsFake = true;
                                             }
                                         })
                            .Async()
                            .Cache();
    }
}
