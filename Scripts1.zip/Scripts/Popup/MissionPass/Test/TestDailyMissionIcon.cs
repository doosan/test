using Gaga;
using Gaga.System;
using Gaga.Util;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Underc;
using Underc.Game;
using Underc.LoadingScreen;
using Underc.Net;
using Underc.Net.Client;
using Underc.UI;
using Underc.User;
using Underc.Util;
using UnityEngine;
using UnityEngine.UI;

public class DailyMissionClaimData
{
    public CommonRewardData[] reward;
    public DailyMissionData daily_quest;
}

public enum TestDailyMissionType
{
    Count1,
    Count2,
    Complete2,
    Complete1
}

public enum TestMissionRewardCount
{
    Count3 = 0,
    Count4 = 1,
    Count5 = 2,
    Count6 = 3
}

public enum TestPointRewardCount
{
    CountRandom,
    Count5,
    Count6
}

public class TestDailyMissionIcon : TestSceneScaffold
{
    [Space]
    [SerializeField] private TestDailyMissionType type;

    [Space]
    [SerializeField] private TestMissionRewardCount missionRewardCount;
    [SerializeField] private TestPointRewardCount pointRewardCount;

    [Space]
    [SerializeField] private int level = 58;
    [SerializeField] private Text levelText;
    [SerializeField] private MissionIconManager missionIconManager;
    [SerializeField] private RectTransform paytableButtonTransform;

    private MissionDataMaker MissionDataMaker
    {
        get
        {
            if (missionDataMaker == null)
            {
                missionDataMaker = MissionDataMaker.Instance;
            }
            return missionDataMaker;
        }
    }
    private MissionDataMaker missionDataMaker;

    private Queue<DailyMissionData> dailyMissionQueue;
    private Queue<DailyMissionClaimData> dailyMissionClaimQueue;
    private Queue<AquaBlitzMissionSpinData> aquaBlitzMissionSpinDataQueue;

    private AquaBlitzData aquaBlitzData;

    private long DailyMissionItemEndTs
    {
        get;
        set;
    }
    private long DailyMissionPointEndTs
    {
        get;
        set;
    }
    private long ClamHarvestStartTs
    {
        get;
        set;
    }
    private long ClamHarvestEndTs
    {
        get;
        set;
    }
    private List<long> MissionPassPoints
    {
        get;
        set;
    }

    private IEnumerator Start()
    {
        yield return SetupAndLoad(new BaseLoadingItem[]
        {
            new LoginLoadingItem(),
            new HTTPLoadingItem<UserCoreResponse>(
                () => NetworkSystem.HTTPRequester.UserCoreWithAlarms(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<FishBookListResponse>(
                () => NetworkSystem.HTTPRequester.FishBookList(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<CasinoBonusResponse>(
                () => NetworkSystem.HTTPRequester.CasinoBonus(),
                resp =>
                {
                    MyInfo.CasinoBonus.Update(resp.data);
                }
            ),
        });

        Init2();

        yield return JustLoad(new BaseLoadingItem[]
        {
            new HTTPLoadingItem<MissionResponse>(
                () => FakeHttpRequester.Instance.Mission(),
                resp =>
                {
                    NetworkSystem.HTTPHandler.Do(resp);
                }
            ),
            new HTTPLoadingItem<SeaMineResponse>(
                () => NetworkSystem.HTTPRequester.SeaMine(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            // A-1. sea_mine 을 먼저 호출해줘야 sea_story 에 정상적인 값이 로드됨.
            // A-2. RewardPopupBottomUI 의 우하단 물고기 콜렉션 카운트를 체크하기 위함.
            new HTTPLoadingItem<SeaStoryResponse>(
                () => NetworkSystem.HTTPRequester.SeaStory(MyInfo.Ocean.CurrentSeaID),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new ABFishLoadingItem(),
            new ABFishIconLoadingItem(),
            new SlotIconLoadingItem(),
            new ABLoadingItem(AssetBundleName.EFFECT),
            new TopUILoadingItem(),
            new RewardBonusUILoadingItem()
        });

        Init3();

        Coroutines coroutines = Coroutines.Create(this).Cache();
        coroutines.Add(LoadEnter)
                  .Add(Setup)
                  .Sequence();
    }

    private void Init3()
    {
        long timeStamp = GlobalTime.Instance.GetTimeStamp();
        DailyMissionItemEndTs = timeStamp + 30;
        DailyMissionPointEndTs = timeStamp + 30;
        ClamHarvestStartTs = timeStamp + 60 * 5;
        ClamHarvestEndTs = timeStamp + 60 * 10;

        MissionPassPoints = FakeRewardDataMaker.Instance
                                               .GetMissionPassPoints(5);

        PrepareDailyMissionData();
        PrepareAquaBlitzData();
        PrepareResponses();

        MakeEnterResponse();
    }

    private void Init2()
    {
        MissionDataMaker.Init();
        MissionDataMaker.LoadMissionResponse(
            clamHarvestData: MissionDataMaker.MakeClamHarvestData(
                startTs: ClamHarvestStartTs,
                endTs: ClamHarvestEndTs
            ),
            aquaBlitzData: MissionDataMaker.NewAquaBlitz(
                blitzStep: 5,
                blitzStatus: new int[] { 2, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0 },
                missionCurrs: new int[] { 4, 2, 2, 2, 2 }
            )
        );
    }

    public void Spin()
    {
        LevelUp();

        MakeSpinResponse();

        StartCoroutine(LoadSpin());
    }

    private void MakeEnterResponse()
    {
        var gameEnterResponse = FakeResponseMaker.New<GameEnterResponse>();

        gameEnterResponse.daily_quest = MakeDailyMissionData(isUnlock: 0,
                                                             unlock: 60,
                                                             step: 0,
                                                             itemCurr: 0,
                                                             itemAll: 0,
                                                             pointCurr: 0, 
                                                             pointAll: 0,
                                                             pointState: DailyMissionPointState.InProgress);

        if (type == TestDailyMissionType.Complete1)
        {
            var spinData = new AquaBlitzMissionSpinData()
            {
                all = 0,
                curr = 0,
                index = 0
            };

            gameEnterResponse.aqua_blitz_mission = spinData;
        }
        else
        {
            int missionIndex = 0;
            AquaBlitzMissionData originData = aquaBlitzData.mission[missionIndex];
            gameEnterResponse.aqua_blitz_mission = MissionDataMaker.CloneAquaBlitzMissionSpin(
                originData,
                missionIndex,
                missionCurr: 4
            );
        }

        FakeHttpRequester.Instance.LoadedGameEnterResponse = gameEnterResponse;
    }

    private void MakeSpinResponse()
    {
        var gameSpinResponse = FakeResponseMaker.New<GameSpinResponse>();
        if (level >= 60)
        {
            gameSpinResponse.daily_quest = dailyMissionQueue.Dequeue();
            if (aquaBlitzMissionSpinDataQueue.Count > 0)
            {
                gameSpinResponse.aqua_blitz_mission = aquaBlitzMissionSpinDataQueue.Dequeue();
            }
        }
        else
        {
            gameSpinResponse.daily_quest = MakeDailyMissionData(isUnlock: 0, 
                                                                unlock: 60, 
                                                                step: 0, 
                                                                itemCurr: 0, 
                                                                itemAll: 0, 
                                                                pointCurr: 0, 
                                                                pointAll: 0,
                                                                pointState: DailyMissionPointState.InProgress);
        }
        FakeHttpRequester.Instance.LoadedGameSpinResponse = gameSpinResponse;
    }

    private void LevelUp()
    {
        level += 1;
        SetLevel(level);
    }

    private void SetupExternalIcon(RectTransform externalIcon)
    {
        paytableButtonTransform.gameObject.SetActive(false);

        var gameObject = new GameObject("ExternalIconContainer");

        RectTransform externalIconContainerTransform = gameObject.AddComponent<RectTransform>();
        externalIconContainerTransform.SetParent(paytableButtonTransform.parent, false);
        externalIconContainerTransform.SetSiblingIndex(paytableButtonTransform.GetSiblingIndex());
        externalIconContainerTransform.anchoredPosition = paytableButtonTransform.anchoredPosition;

        externalIcon.SetParent(externalIconContainerTransform, false);
    }

    private void Setup()
    {
        //
        SetupExternalIcon(missionIconManager.CachedTransform);

        missionIconManager.Setup(slotMachine: null);
        foreach (BaseMissionIcon missionIcon in missionIconManager.MissionIcons)
        {
            missionIcon.Display.RunAsFake = true;
        }
        
        UpdateMissionIcons();

        //
        SetLevel(level);
        ((IGameUiElement)missionIconManager).Show(false);
    }

    private void SetLevel(int level)
    {
        MyInfo.Level = level;
        levelText.text = StringMaker.New()
                                    .Append("LV. ")
                                    .Append(level.ToString())
                                    .Build();
    }

    private void PrepareResponses()
    {
        Queue<DailyMissionData> dailyMissionDatas = new Queue<DailyMissionData>();

        Queue<AquaBlitzData> aquaBlitzDatas = new Queue<AquaBlitzData>();
        aquaBlitzDatas.Enqueue(MissionDataMaker.NewAquaBlitz(
                blitzStep: 5,
                blitzStatus: new int[] { 2, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0 },
                missionCurrs: new int[] { 10, 2, 2, 2, 2 }
        ));

        FakeHttpRequester.Instance.LoadedDailyMissionItemClaimResponse = () =>
        {
            var dailyRewardClaimResponse = FakeResponseMaker.New<DailyMissionItemClaimResponse>();
            if (dailyMissionClaimQueue.Count > 0)
            {
                var claimData = dailyMissionClaimQueue.Dequeue();
                dailyRewardClaimResponse.reward = claimData.reward;
                dailyRewardClaimResponse.daily_quest = claimData.daily_quest;

                dailyMissionDatas.Clear();
                dailyMissionDatas.Enqueue(claimData.daily_quest);

                DailyMissionData dailyMissionData = MakeDailyMissionData(
                    isUnlock: 2,
                    unlock: 60,
                    step: 1,
                    itemCurr: 0,
                    itemAll: 3,
                    pointCurr: 0,
                    pointAll: 100,
                    pointState: DailyMissionPointState.InProgress
                );
                dailyMissionData.daily_end_ts += 60 * 5;
                dailyMissionDatas.Enqueue(dailyMissionData);
            }
            
            return dailyRewardClaimResponse;
        };

        MissionDataMaker.LoadMissionResponse(
            missionPassData: MissionDataMaker.NewMissionPass(
                step: 1,
                curr: 0,
                all: 500
            ),
            dailyMissionDatas: dailyMissionDatas,
            clamHarvestData: MissionDataMaker.MakeClamHarvestData(
                startTs: ClamHarvestStartTs,
                endTs: ClamHarvestEndTs
            ),
            aquaBlitzDatas: aquaBlitzDatas
        );
    }

    private void PrepareAquaBlitzData()
    {
        aquaBlitzData = MissionDataMaker.NewAquaBlitz(blitzStep: 5,
                                                      blitzStatus: new int[] { 2, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0 },
                                                      missionCurrs: new int[] { 4, 2, 2, 2, 2 });

        aquaBlitzMissionSpinDataQueue = new Queue<AquaBlitzMissionSpinData>();

        if (type == TestDailyMissionType.Complete2)
        {

        }
        else
        {
            int missionIndex = 0;
            AquaBlitzMissionData originData = aquaBlitzData.mission[missionIndex];
            aquaBlitzMissionSpinDataQueue.Enqueue(MissionDataMaker.CloneAquaBlitzMissionSpin(originData, missionIndex, missionCurr: 4));
            aquaBlitzMissionSpinDataQueue.Enqueue(MissionDataMaker.CloneAquaBlitzMissionSpin(originData, missionIndex, missionCurr: 7));
            aquaBlitzMissionSpinDataQueue.Enqueue(MissionDataMaker.CloneAquaBlitzMissionSpin(originData, missionIndex, missionCurr: 10));
            aquaBlitzMissionSpinDataQueue.Enqueue(MissionDataMaker.CloneAquaBlitzMissionSpin(originData, missionIndex, missionCurr: 10));
            aquaBlitzMissionSpinDataQueue.Enqueue(MissionDataMaker.CloneAquaBlitzMissionSpin(originData, missionIndex, missionCurr: 10));
            aquaBlitzMissionSpinDataQueue.Enqueue(MissionDataMaker.CloneAquaBlitzMissionSpin(originData, missionIndex, missionCurr: 10));
        }

        MyInfo.SlotGame.currentSlotID = aquaBlitzData.mission[0].slotid.ToString();
    }

    private void PrepareDailyMissionData()
    {
        dailyMissionQueue = new Queue<DailyMissionData>();
        dailyMissionClaimQueue = new Queue<DailyMissionClaimData>();
        if (type == TestDailyMissionType.Count1)
        {
            dailyMissionQueue.Enqueue(MakeDailyMissionData(isUnlock: 1, unlock: 60, step: 1, itemCurr: 0, itemAll: 2, pointCurr: 0, pointAll: 100, pointState: DailyMissionPointState.InProgress));
            dailyMissionQueue.Enqueue(MakeDailyMissionData(isUnlock: 2, unlock: 60, step: 1, itemCurr: 1, itemAll: 3, pointCurr: 0, pointAll: 100, pointState: DailyMissionPointState.InProgress));
            dailyMissionQueue.Enqueue(MakeDailyMissionData(isUnlock: 2, unlock: 60, step: 1, itemCurr: 2, itemAll: 3, pointCurr: 0, pointAll: 100, pointState: DailyMissionPointState.InProgress));
            dailyMissionQueue.Enqueue(MakeDailyMissionData(isUnlock: 2, unlock: 60, step: 1, itemCurr: 3, itemAll: 3, pointCurr: 0, pointAll: 100, pointState: DailyMissionPointState.InProgress));
            
            dailyMissionClaimQueue.Enqueue(MakeDailyMissionClaimData(
                prevStep: 1,
                reward: FakeRewardDataMaker.Instance
                                           .GetDailyMissionRewards(GetItemRewardCount())
                                           .Select(data => new CommonRewardData(data.type.ToString(), data.value))
                                           .ToArray(),
                dailyMission: MakeDailyMissionData(isUnlock: 2,
                                                   unlock: 60,
                                                   step: 0,
                                                   itemCurr: 0,
                                                   itemAll: 0,
                                                   pointCurr: 100, 
                                                   pointAll: 100,
                                                   pointState: DailyMissionPointState.InProgress)
            ));
        }
        else if (type == TestDailyMissionType.Count2)
        {
            dailyMissionQueue.Enqueue(MakeDailyMissionData(isUnlock: 1, unlock: 60, step: 1, itemCurr: 0, itemAll: 2, pointCurr: 0, pointAll: 100, pointState: DailyMissionPointState.InProgress));
            dailyMissionQueue.Enqueue(MakeDailyMissionData(isUnlock: 2, unlock: 60, step: 1, itemCurr: 1, itemAll: 3, pointCurr: 0, pointAll: 100, pointState: DailyMissionPointState.InProgress));
            dailyMissionQueue.Enqueue(MakeDailyMissionData(isUnlock: 2, unlock: 60, step: 1, itemCurr: 2, itemAll: 3, pointCurr: 0, pointAll: 100, pointState: DailyMissionPointState.InProgress));
            dailyMissionQueue.Enqueue(MakeDailyMissionData(isUnlock: 2, unlock: 60, step: 1, itemCurr: 3, itemAll: 3, pointCurr: 0, pointAll: 100, pointState: DailyMissionPointState.InProgress));
            dailyMissionQueue.Enqueue(MakeDailyMissionData(isUnlock: 2, unlock: 60, step: 2, itemCurr: 1, itemAll: 2, pointCurr: 50, pointAll: 100, pointState: DailyMissionPointState.InProgress));
            dailyMissionQueue.Enqueue(MakeDailyMissionData(isUnlock: 2, unlock: 60, step: 2, itemCurr: 2, itemAll: 2, pointCurr: 50, pointAll: 100, pointState: DailyMissionPointState.InProgress));

            dailyMissionClaimQueue.Enqueue(MakeDailyMissionClaimData(
                prevStep: 1,
                reward: FakeRewardDataMaker.Instance
                                           .GetDailyMissionRewards(GetItemRewardCount())
                                           .Select(data => new CommonRewardData(data.type.ToString(), data.value))
                                           .ToArray(),
                dailyMission: MakeDailyMissionData(isUnlock: 2,
                                                   unlock: 60,
                                                   step: 2,
                                                   itemCurr: 0,
                                                   itemAll: 2,
                                                   pointCurr: 50, 
                                                   pointAll: 100,
                                                   pointState: DailyMissionPointState.InProgress)
            ));
            dailyMissionClaimQueue.Enqueue(MakeDailyMissionClaimData(
                    prevStep: 2,
                    reward: FakeRewardDataMaker.Instance
                                               .GetDailyMissionRewards(GetItemRewardCount())
                                               .Select(data => new CommonRewardData(data.type.ToString(), data.value))
                                               .ToArray(),
                    dailyMission: MakeDailyMissionData(isUnlock: 2,
                                                       unlock: 60,
                                                       step: 0,
                                                       itemCurr: 0,
                                                       itemAll: 0,
                                                       pointCurr: 100, 
                                                       pointAll: 100,
                                                       pointState: DailyMissionPointState.Collect)
            ));
        }
        else if (type == TestDailyMissionType.Complete2
                 || type == TestDailyMissionType.Complete1)
        {
            dailyMissionQueue.Enqueue(MakeDailyMissionData(isUnlock: 1, unlock: 60, step: 5, itemCurr: 0, itemAll: 1, pointCurr: 0, pointAll: 100, pointState: DailyMissionPointState.InProgress));
            dailyMissionQueue.Enqueue(MakeDailyMissionData(isUnlock: 2, unlock: 60, step: 5, itemCurr: 1, itemAll: 1, pointCurr: 0, pointAll: 100, pointState: DailyMissionPointState.InProgress));

            dailyMissionClaimQueue.Enqueue(MakeDailyMissionClaimData(
                prevStep: 5,
                reward: FakeRewardDataMaker.Instance
                                           .GetDailyMissionRewards(GetItemRewardCount())
                                           .Select(data => new CommonRewardData(data.type.ToString(), data.value))
                                           .ToArray(),
                dailyMission: MakeDailyMissionData(isUnlock: 2,
                                                   unlock: 60,
                                                   step: 0,
                                                   itemCurr: 0,
                                                   itemAll: 0,
                                                   pointCurr: 0,
                                                   pointAll: 100,
                                                   pointState: DailyMissionPointState.InProgress)
            ));
        }
    }

    private int GetItemRewardCount()
    {
        return (int)missionRewardCount;
    }

    private DailyMissionClaimData MakeDailyMissionClaimData(int prevStep, 
                                                            CommonRewardData[] reward, 
                                                            DailyMissionData dailyMission)
    {
        var dailyRewardClaimData = new DailyMissionClaimData();
        dailyMission.prev_step = prevStep;
        dailyRewardClaimData.reward = reward;
        dailyRewardClaimData.daily_quest = dailyMission;
        return dailyRewardClaimData;
    }

    private DailyMissionData MakeDailyMissionData(int isUnlock,
                                                  int unlock, 
                                                  int step, 
                                                  int itemCurr, 
                                                  int itemAll, 
                                                  long pointCurr,
                                                  long pointAll,
                                                  DailyMissionPointState pointState)
    {
        return MissionDataMaker.NewDailyMission(
            isUnlock: isUnlock,
            unlock: unlock,
            step: step,
            itemCurr: itemCurr,
            itemAll: itemAll,
            itemEndTs: DailyMissionItemEndTs,
            passPoints: MissionPassPoints.ToArray(),
            pointCurr: pointCurr,
            pointAll: pointAll,
            pointEndTs: DailyMissionPointEndTs,
            pointState: (int)pointState
        );
    }

    private IEnumerator LoadEnter()
    {
        SetButtonInteractable(false);
        var req = FakeHttpRequester.Instance.GameEnter();
        yield return req.WaitForResponse();
        SetButtonInteractable(true);

        if (req.isSuccess)
        {
            MyInfo.DailyMission.Update(req.data.ts, req.data.daily_quest);
            MyInfo.AquaBlitz.Update(checkUpdateTs: false, req.data.ts, req.data.aqua_blitz_mission);
        }
    }

    private void UpdateMissionIcons()
    {
        foreach (BaseMissionIcon missionIcon in missionIconManager.GetAllIcon())
        {
            missionIcon.UpdateInfo(isProgressive: false);
        }
    }

    private void UpdateMissionIconsCoroutine()
    {
        foreach (BaseMissionIcon missionIcon in missionIconManager.GetAllIcon())
        {
            StartCoroutine(missionIcon.UpdateInfoCoroutine());
        }
    }

    private IEnumerator LoadSpin()
    {
        SetButtonInteractable(false);
        var req = FakeHttpRequester.Instance.GameSpin();
        yield return req.WaitForResponse();

        if (dailyMissionQueue.Count > 0)
        {
            SetButtonInteractable(true);
        }

        if (req.isSuccess)
        {
            //
            MyInfo.DailyMission.Update(req.data.ts, req.data.daily_quest);
            MyInfo.AquaBlitz.Update(checkUpdateTs: true, req.data.ts, req.data.aqua_blitz_mission);

            //
            bool isDailyQuestUnlock = MyInfo.DailyMission.DisplayInfo.ConsumeJustUnlockState();
            if (isDailyQuestUnlock)
            {
                yield return missionIconManager.GetIcon(MissionIconType.DailyMission).UnlockCoroutine();
            }

            UpdateMissionIconsCoroutine();

            if (MyInfo.DailyMission.DisplayInfo.Progress >= 1)
            {
                DailyMissionIcon dailyMissionIcon = missionIconManager.DailyMissionIcon;
                yield return dailyMissionIcon.GetReward(missionIconManager.IsInPlay, missionIconManager.GetActiveMissionIcon);
            }
        }
    }
}
