using UnityEngine;
using System.Collections.Generic;
using Underc.User;
using System.Collections;
using Gaga.UI;
using System;
using Gaga.Util;
using Gaga.Sound;
using UnityEngine.UI;
using Gaga.System;

namespace Underc.Popup
{
    public sealed class MissionPassRewardPopup : HighlightPopup
    {
        [Serializable]
        public sealed class TitleInfo
        {
            public TitleType type;
            public GameObject view;
        }

        [Header("Title")]
        [SerializeField] private TitleInfo[] titleInfoList;

        [Header("Content")]
        [SerializeField] private SimpleRewardItemCollector rewardItemCollector;
        [SerializeField] private GridLayoutGroupCenter rewardGrid;
        [SerializeField] private Button collectButton;
        [SerializeField] private GameObject benefitButton;

        [Header("Duration")]
        [SerializeField] private float shortDuration = 3f;
        [SerializeField] private float longDuration = 8f;

        [Header("Animation")]
        [SerializeField] private AnimatorParser collectAnimation;
        [SerializeField] private AnimatorParser openAnimation;

        [Header("Sound")]
        [SerializeField] private SoundPlayer commonSound;
        [SerializeField] private SoundPlayer missionClearSound;

        private readonly int REWARD_GRID_MAX_COUNT = 14;
        private readonly int REWARD_GRID_ROW_COUNT = 7;

        private bool waitForSeeMore; 

        public enum TitleType
        {
            MissionPassFree,
            MissionPassBonus,
            AquaBlitzPointReward,
            AquaBlitzMissionReward
        }

        public bool RunAsFake
        {
            set
            {
                runAsFake = value;
                rewardItemCollector.RunAsFake = value;
            }
            private get
            {
                return runAsFake;
            }
        }
        private bool runAsFake;

        public SimpleRewardItemCollector RewardItemCollector
        {
            get => rewardItemCollector;
        }

        private bool isInit;
        private bool isCollecting;

        private List<RewardInfo> rewardInfos;
        private TitleType titleType;

        // A-1. rewardInfos 로 전달된 값들은 팝업이 꺼질 때 자신의 오브젝트 풀로 리턴되고,
        // A-2. rewardInfos 리스트는 초기화 됩니다.
        // A-3. (Close() 메서드 참고)
        public void Open(TitleType titleType, List<RewardInfo> rewardInfos, SimpleRewardItemValueType valueType, bool openAsShow)
        {
            this.titleType = titleType;

            if (isInit == false)
            {
                rewardItemCollector.Init();
                isInit = true;
            }

            Reset();

            SetupTitle(titleType);
            SetupContent(rewardInfos, valueType);
            if (openAsShow)
            {
                Show();
            }
        }

        private void Reset()
        {
            waitForSeeMore = false;
            collectButton.interactable = false;
        }

        public void Run(float delay, IEnumerator coroutine, Action onComplete)
        {
            StartCoroutine(RunCoroutine(delay, coroutine, onComplete));
        }

        private IEnumerator RunCoroutine(float delay, IEnumerator coroutine, Action onComplete)
        {
            yield return new WaitForSeconds(delay);
            yield return coroutine;
            onComplete?.Invoke();
        }

        public void Show()
        {
            Coroutines.Create(this)
                      .Cache()
                      .Add(OpenCoroutine())
                      .Add(WaitCoroutine())
                      .Add(CollectAllCoroutine())
                      .Sequence();
        }

        private IEnumerator WaitCoroutine()
        {
            var duration = (rewardInfos.Count >= REWARD_GRID_MAX_COUNT) ?
                           longDuration :
                           shortDuration;

            while (duration > 0f)
            {
                if (waitForSeeMore == false)
                {
                    duration -= Time.deltaTime;
                }

                yield return null;
            }

            yield return new WaitForSeconds(duration);
        }

        private void SetupTitle(TitleType titleType)
        {
            for (int i = 0; i < titleInfoList.Length; i++)
            {
                var info = titleInfoList[i];
                info.view.SetActive(info.type == titleType);
            }
        }

        private void SetupContent(List<RewardInfo> rewardInfos, SimpleRewardItemValueType valueType)
        {
            this.rewardInfos = rewardInfos;
            bool showMoreItems = rewardInfos.Count > REWARD_GRID_MAX_COUNT;
            int infoCount = showMoreItems ? REWARD_GRID_MAX_COUNT : rewardInfos.Count;

            benefitButton.SetActive(showMoreItems);

            int gridRowCount = (int)Math.Ceiling((float)infoCount / (float)REWARD_GRID_ROW_COUNT);

            rewardGrid.constraint = GridLayoutGroup.Constraint.FixedRowCount;
            rewardGrid.constraintCount = gridRowCount;

            rewardItemCollector.RegisterAllStartPosition(rewardGrid.transform.position);
            
            rewardItemCollector.Reset();
            rewardItemCollector.Setup(rewardInfos, valueType);

            // Setup() 에서 리워드 정렬을 수행 후 Visible 업데이트
            for (int i = 0; i < rewardInfos.Count; i++)
            {
                rewardItemCollector.UpdateVisible(i, i < infoCount);
            }
        }

        public void CollectAll()
        {
            if (isCollecting)
            {
                return;
            }

            Coroutines coroutines = Coroutines.Create(this);
            coroutines.Clear();

            coroutines.Add(CollectAllCoroutine())
                      .Sequence();
        }

        public override void Close()
        {
            for (int i = 0; i < rewardInfos.Count; i++)
            {
                rewardInfos[i].Release();
            }
            rewardInfos.Clear();

            base.Close();
        }

        private void PlayOpenSound()
        {
            if (titleType == TitleType.AquaBlitzMissionReward)
            {
                missionClearSound.Play();
            }
            else
            {
                commonSound.Play();
            }
        }

        private IEnumerator OpenCoroutine()
        {
            PlayOpenSound();
            openAnimation?.SetTrigger();

            float timeBegin = Time.time;

            yield return rewardItemCollector.OpenCoroutine();

            float timePassed = Time.time - timeBegin;
            yield return openAnimation.WaitForDuration(-timePassed);
            // 보상 아이템 등장할 때까지 백버튼 허용 안 함
            collectButton.interactable = true;
        }

        private IEnumerator CollectAllCoroutine()
        {
            isCollecting = true;

            collectButton.interactable = false;

            collectAnimation?.SetTrigger();
            yield return rewardItemCollector.CollectCoroutine();

            isCollecting = false;

            Close();
        }

        public void OpenSeeMorePopup()
        {
            if (rewardInfos == null || rewardInfos.Count == 0 || isCollecting)
            {
                return;
            }

            waitForSeeMore = true;
            Popups.MissionPassSeeMore(
                       rewardInfos,
                       MissionPassSeeMorePopup.TitleType.MissionPass
                  )
                  .Async()
                  .OnClose(() => waitForSeeMore = false);
        }

        public override bool CanBack()
        {
            return Popups.IsLoading() == false
                   && collectButton.interactable == true
                   && base.CanBack();
        }

        public override void GoBack()
        {
            collectButton.onClick.Invoke();
        }
    }
}    