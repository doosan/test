using System.Collections;
using Underc.UI;
using Underc.User;
using UnityEngine;
using static Gaga.Util.CustomYield;

namespace Underc.Popup
{
    public class MissionPassPointTransition : MonoBehaviour
    {
        private const float LEVEL_UP_DELAY = .4f;

        private bool isMissionPassStepUp;
        private SimpleWaitForDone waitForMissionPassLevelUp = new SimpleWaitForDone();

        public static MissionPassPointTransition GetOrAdd(GameObject gameObject)
        {
            var result = gameObject.GetComponent<MissionPassPointTransition>();
            if (result == null)
            {
                result = gameObject.AddComponent<MissionPassPointTransition>();
            }

            return result;
        }

        public void Setup(SimpleRewardItemCollector itemCollector, 
                          HighlightObjectInfo missionPassTabInfo, 
                          bool showMissionPassLevelUp = true)
        {
            isMissionPassStepUp = false;
            waitForMissionPassLevelUp.Done();

            itemCollector.RegisterEndPosition(RewardType.mp_point, missionPassTabInfo.clonedTransform.position);
            itemCollector.OnEffectShow.AddListener((RewardType rewardType) =>
            {
                if (rewardType == RewardType.mp_point)
                {
                    missionPassTabInfo.SetCloneActive(true);
                }
            });
            itemCollector.OnEffectFirstArrived.AddListener((RewardType rewardType) =>
            {
                if (rewardType == RewardType.mp_point)
                {
                    Animator tabAnimator = missionPassTabInfo.clonedTransform
                                                             .GetComponentInChildren<Animator>();
                    tabAnimator.SetTrigger("On");
                }
            });
            itemCollector.OnEffectComplete.AddListener(() =>
            {
                missionPassTabInfo.SetCloneActive(false, keepFade: true);

                isMissionPassStepUp = MyInfo.MissionPass.ConsumeStepUpInProgress();
                if (showMissionPassLevelUp)
                {
                    CheckIfMissionPassStepUp();
                }
            });
        }

        public void CheckIfMissionPassStepUp()
        {
            if (isMissionPassStepUp)
            {
                waitForMissionPassLevelUp.Ready();
                ShowMissionPassLevelUp();
                //Invoke("ShowMissionPassLevelUp", LEVEL_UP_DELAY);
            }
        }

        private void ShowMissionPassLevelUp()
        {
            Popups.MissionPassLevelUp(MyInfo.MissionPass.ClearedStep)
                  .Async()
                  .OnClose(() => waitForMissionPassLevelUp.Done());
        }

        public IEnumerator WaitForDone()
        {
            yield return waitForMissionPassLevelUp;
        }
    }
}