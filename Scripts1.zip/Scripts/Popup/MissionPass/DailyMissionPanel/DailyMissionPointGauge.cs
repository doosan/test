using DG.Tweening;
using Gaga.Sound;
using Gaga.Util;
using System.Collections;
using TMPro;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.UI
{ 
    public class DailyMissionPointGauge : MonoBehaviour
    {
        [SerializeField] private CanvasGroup canvasGroup;
        [SerializeField] private RectTransform crownIcon;

        [Space]
        [SerializeField] private TextMeshProUGUI progressText;

        [Header("Slider")]
        [SerializeField] private Slider progressSlider;
        [SerializeField] private float gaugeDelay = .0f;
        [SerializeField] private float gaugeDuration = .3f;
        [SerializeField] private Ease gaugeEase = Ease.Linear;

        [Header("Animation")]
        [SerializeField] private AnimatorParser completeAnimation;
        [SerializeField] private AnimatorParser fullAnimation;
        [SerializeField] private AnimatorParser growAnimation;
        [SerializeField] private AnimatorParser toCompleteAnimation;

        [Header("Sound")]
        [SerializeField] private SoundPlayer fullSound;

        public bool IsFull
        {
            get => progressSlider.normalizedValue == 1;
        }

        public Vector2 CrownIconPosition
        {
            get => crownIcon.position;
        }

        public RectTransform CachedTransform
        {
            get
            {
                if (cachedTransform == null)
                {
                    cachedTransform = GetComponent<RectTransform>();
                }
                return cachedTransform;
            }
        }
        private RectTransform cachedTransform;

        private long curr = 0;
        private long all = 0;

        public void Init()
        {

        }

        public void Reset()
        {
            progressText.text = "";
            progressSlider.normalizedValue = 0;
        }

        public IEnumerator Full()
        {
            fullAnimation.SetTrigger();
            fullSound.Play();
            yield return fullAnimation.WaitForDuration();
        }

        public IEnumerator ToComplete()
        {
            toCompleteAnimation.SetTrigger();
            yield return toCompleteAnimation.WaitForDuration();
        }

        public void Complete()
        {
            completeAnimation.SetTrigger();
        }

        public void Grow()
        {
            growAnimation.SetTrigger();
        }

        public void UpdateContent(bool isProgressive, bool isPointRefreshed)
        {
            if (isPointRefreshed)
            {
                canvasGroup.alpha = 0;
                canvasGroup.DOFade(1f, .3f);
                //Refresh();
            }

            DailyMissionPointInfo pointInfo = MyInfo.DailyMission.PointInfo;
            if (pointInfo.state != DailyMissionPointState.Complete)
            {
                all = pointInfo.all;
                float progress = all == 0 ?
                                 0 :
                                 pointInfo.curr / (float)all;

                if (progressSlider.normalizedValue != progress
                    && isProgressive == true)
                {
                    DOTween.To(getter: () => curr, 
                               setter: value => curr = value, 
                               endValue: pointInfo.curr, 
                               duration: gaugeDuration)
                           .OnUpdate(UpdateProgressText);
                    
                    progressSlider.DOValue(progress, gaugeDuration)
                                  .SetDelay(gaugeDelay)
                                  .SetEase(gaugeEase)
                                  .OnUpdate(SetEndEffect);
                }
                else
                {
                    curr = pointInfo.curr;
                    UpdateProgressText();
                    progressSlider.normalizedValue = progress;
                    SetEndEffect();
                }
            }
            else
            {
                progressSlider.normalizedValue = 1;
                Complete();
            }
        }

        private void UpdateProgressText()
        {
            progressText.text = $"{StringUtils.ToGeneralKMB(curr)}/{StringUtils.ToGeneralKMB(all)}";
        }

        private void SetEndEffect()
        {
            float progress = progressSlider.normalizedValue;
            bool endEffectVisible = progress != 0 && progress != 1;
        }
    }
}
