using Gaga.System;
using Gaga.Util;
using System.Collections;
using TMPro;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Popup
{
    public class DailyMissionInfoTooltip : MonoBehaviour
    {
        private class AnimationInfo
        {
            public AnimatorParser open;
            public AnimatorParser close;

            public AnimationInfo(AnimatorParser open, AnimatorParser close)
            {
                this.open = open;
                this.close = close;
            }
        }

        [SerializeField] private AnimatorParser openAnimation_InProgress;
        [SerializeField] private AnimatorParser closeAnimation_InProgress;
        [SerializeField] private AnimatorParser openAnimation_Complete;
        [SerializeField] private AnimatorParser closeAnimation_Complete;
        [SerializeField] private Button closeButton;
        [SerializeField] private TextMeshProUGUI remainingTimeText;

        public TextMeshProUGUI RemainingTimeText
        {
            get => remainingTimeText;
        }

        private AnimationInfo inProgressAnimation;
        private AnimationInfo completeAnimation;
        private Coroutines coroutines;

        private void OnDisable()
        {
            closeButton.gameObject.SetActive(false);
            gameObject.SetActive(false);
            if (coroutines != null
                && coroutines.IsRunning)
            {
                coroutines.Clear();
            }
        }

        public void Init()
        {
            inProgressAnimation = new AnimationInfo(openAnimation_InProgress, closeAnimation_InProgress);
            completeAnimation = new AnimationInfo(openAnimation_Complete, closeAnimation_Complete);
        }

        public void Reset()
        {

        }

        public void Open()
        {
            gameObject.SetActive(true);
            closeButton.gameObject.SetActive(true);
            
            AnimationInfo animInfo = ReadAnimationInfo();
            animInfo.open.SetTrigger();
        }

        public void OnAnimationEvent(string name)
        {
            if (name == "close")
            {
                AnimationInfo animInfo = ReadAnimationInfo();
                coroutines = Coroutines.Create(this).Cache()
                                       .Add(WaitForAnimation(animInfo.close))
                                       .Add(CloseGameObject)
                                       .Sequence();

                closeButton.gameObject.SetActive(false);
            }
        }

        public void Close()
        {
            AnimationInfo animInfo = ReadAnimationInfo();
            animInfo.close.SetTrigger();
        }

        private void CloseGameObject()
        {
            gameObject.SetActive(false);
        }

        private IEnumerator WaitForAnimation(AnimatorParser targetAnimation)
        {
            targetAnimation.SetTrigger();
            yield return targetAnimation.WaitForDuration();
        }

        private AnimationInfo ReadAnimationInfo()
        {
            DailyMissionPointState state = MyInfo.DailyMission.PointInfo.state;
            Debug.Log($"==== ReadAnimationInfo : {state}");
            AnimationInfo animInfo = (state == DailyMissionPointState.Complete) ?
                                     completeAnimation :
                                     inProgressAnimation;
            return animInfo;
        }
    }
}
