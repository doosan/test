using Gaga;
using Gaga.Sound;
using Gaga.Util;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using Underc.UI;
using Underc.User;
using UnityEngine;

namespace Underc.Popup
{
    public class DailyMissionPanel : BaseMissionPassContentPanel
    {
        [Header("Info")]
        [SerializeField] private DailyMissionInfoTooltip infoTooltip;

        [Header("Point")]
        [SerializeField] private TextMeshProUGUI pointEndRemainingText;
        [SerializeField] private DailyMissionPointGauge pointGauge;

        [Header("Mission")]
        [SerializeField] private float refreshAnimationDelay = 50f/60f;
        [SerializeField] private AnimatorParser refreshAnimation;
        [SerializeField] private float lineAnimationDelay = 1.25f;
        [SerializeField] private Animator lineAnimator;
        [SerializeField] private List<AnimatorParser> lineAnimations;
        [SerializeField] private List<DailyMissionItem> missionItems;
        [SerializeField] private TextMeshProUGUI missionEndRemainingText;

        [Header("Sound")]
        [SerializeField] private SoundPlayer toCompleteZoomInSound;
        [SerializeField] private SoundPlayer toCompleteZoomOutSound;
        [SerializeField] private SoundPlayer toProgressZoomOutSound;

        public override Vector2 PointGaugePosition
        {
            get => pointGauge.CrownIconPosition;
        }

        public override RectTransform PointGaugeTransform
        {
            get => pointGauge.CachedTransform;
        }

        private TimeoutWatcher<DailyMissionRemainingTime> TimeoutWatcher
        {
            get
            {
                if (timeoutWatcher == null)
                {
                    timeoutWatcher = new TimeoutWatcher<DailyMissionRemainingTime>();
                }
                return timeoutWatcher;
            }
        }
        private TimeoutWatcher<DailyMissionRemainingTime> timeoutWatcher;

        private MyDailyMission DailyMission
        {
            get
            {
                if (dailyMission == null)
                {
                    dailyMission = MyInfo.DailyMission;
                }
                return dailyMission;
            }
        }
        private MyDailyMission dailyMission;

        private void OnEnable()
        {
            DailyMission.onTimeUpdate.AddListener(OnTimeUpdate);

            TimeoutWatcher.Add(DailyMissionRemainingTime.Point,
                               () => DailyMission.PointEndRemainingSec);
            TimeoutWatcher.Add(DailyMissionRemainingTime.Mission,
                               () => DailyMission.MissionEndRemainingSec);
        }

        private void OnDisable()
        {
            DailyMission.onTimeUpdate.RemoveListener(OnTimeUpdate);
        }

        public override void Init()
        {
            infoTooltip.Init();
            pointGauge.Init();
            foreach (DailyMissionItem item in missionItems)
            {
                item.Init();
            }
        }

        public override void Reset()
        {
            infoTooltip.Reset();

            pointGauge.Reset();
            pointEndRemainingText.text = "";

            missionEndRemainingText.text = "";
            foreach (DailyMissionItem item in missionItems)
            {
                item.Reset();
            }
        }

        public override IEnumerator UpdateProgressiveContent(UpdateSpecificContentType contentType)
        {
            if (contentType == UpdateSpecificContentType.Mission)
            {
                int prevStep = DailyMission.PrevStep;
                int nextStep = prevStep + 1;

                // A-1
                int prevStepIndex = prevStep - 1;
                DailyMissionItem missionItem = missionItems[prevStepIndex];
                missionItem.ToComplete();

                toCompleteZoomInSound.Play();
                toCompleteZoomOutSound.Play();
                yield return new WaitForSeconds(lineAnimationDelay);

                // A-2
                if (prevStepIndex < lineAnimations.Count)
                {
                    AnimatorParser lineAnimation = lineAnimations[prevStepIndex];
                    lineAnimation.SetTrigger();
                    yield return lineAnimation.WaitForDuration();
                }

                // A-3
                int nextStepIndex = nextStep - 1;
                if (nextStepIndex < missionItems.Count)
                {
                    DailyMissionInfo dailyMissionInfo = DailyMission.Info;
                    missionItem = missionItems[nextStepIndex];
                    missionItem.UpdateContent(isMissionRefreshed: false,
                                              info: dailyMissionInfo,
                                              rewardIndex: nextStepIndex,
                                              state: DailyMissionItemState.None);
                    toCompleteZoomInSound.Play();
                    toProgressZoomOutSound.Play();
                    yield return missionItem.ToInProgress();
                }
            }
            else if (contentType == UpdateSpecificContentType.Point)
            {
                pointGauge.UpdateContent(
                    isProgressive: false,
                    isPointRefreshed: false
                );
            }
        }

        public override IEnumerator UpdateContent(UpdateContentType updateType)
        {
            // Point
            pointGauge.UpdateContent(
                isProgressive: false,
                isPointRefreshed: TimeoutWatcher.Consume(DailyMissionRemainingTime.Point)
            );
            OnTimeUpdate(DailyMissionRemainingTime.Point);

            // Mission
            bool isMissionRefreshed = TimeoutWatcher.Consume(DailyMissionRemainingTime.Mission);
            if (isMissionRefreshed)
            {
                refreshAnimation.SetTrigger();
                yield return new WaitForSeconds(refreshAnimationDelay);
                
            }

            DailyMissionInfo dailyMissionInfo = DailyMission.Info;
            int step = dailyMissionInfo.step;
            for (int i = 0; i < missionItems.Count; i++)
            {
                int iStep = i + 1;

                DailyMissionItem missionItem = missionItems[i];
                missionItem.UpdateContent(isMissionRefreshed,
                                          info: dailyMissionInfo,
                                          rewardIndex: i,
                                          state: (step == 0 || iStep < step) ? DailyMissionItemState.Complete :
                                                 (iStep == step) ? DailyMissionItemState.InProgress :
                                                 DailyMissionItemState.Lock);
            }

            int animStep = (step == 0) ? 5 : step;
            lineAnimator.SetTrigger($"Step{animStep}");
            OnTimeUpdate(DailyMissionRemainingTime.Mission);
            yield break;
        }
        
        private void OnTimeUpdate(DailyMissionRemainingTime missionType)
        {
            if (missionType == DailyMissionRemainingTime.Mission)
            {
                missionEndRemainingText.text = DailyMission.MissionEndRemainingSec.ToSummaryDHMS();
            }
            else if (missionType == DailyMissionRemainingTime.Point)
            {
                pointEndRemainingText.text = DailyMission.PointEndRemainingSec.ToNDaysLeft();
                infoTooltip.RemainingTimeText.text = DailyMission.PointEndRemainingSec.ToSummaryDHMS("TIME'S UP");
            }

            TimeoutWatcher.Watch(onTimeout: OnTimeout);
        }

        private void OnTimeout(DailyMissionRemainingTime type)
        {
            if (type == DailyMissionRemainingTime.Point)
            {
                OnClose?.Invoke();
            }
            else
            {
                OnRefresh?.Invoke();
            }
        }

        public override bool Close()
        {
            return true;
        }

        public override bool CanBack()
        {
            return true;
        }
    }
}
