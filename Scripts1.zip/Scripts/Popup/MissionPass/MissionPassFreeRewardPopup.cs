using UnityEngine;
using Gaga.Popup;
using System.Collections.Generic;
using Underc.User;
using System.Collections;
using Gaga.Attribute;
using System;
using Gaga.System;
using Underc.Net;
using Underc.Net.Client;
using Gaga.Util;
using Gaga.Sound;
using UnityEngine.UI;

namespace Underc.Popup
{
    public sealed class MissionPassFreeRewardPopup : PopupBackable
    {
        private readonly int REWARD_FREE_COUNT              = 7;
        private readonly int REWARD_BONUS_COUNT             = 7;

        [Separator("General")]
        [SerializeField] private Button collectButton;
        [SerializeField] private Button unlockButton;
        [SerializeField] private AnimatorParser collectFreeAnimation;

        [Separator("Content")]
        [SerializeField] private SimpleRewardItemCollector freeRewardItemContainer;
        [SerializeField] private GameObject freeBenefitButton;

        [Separator("Bonus")]
        [SerializeField] private SimpleRewardItemCollector bonusRewardItemContainer;
        [SerializeField] private GameObject bonusBenefitButton;

        [Header("Animation")]
        [SerializeField] private AnimatorParser openAnimation;

        [Header("Sound")]
        [SerializeField] private SoundPlayer commonSound;

        public bool RunAsFake
        {
            private get
            {
                return runAsFake;
            }
            set
            {
                runAsFake = value;
                freeRewardItemContainer.RunAsFake = value;
                bonusRewardItemContainer.RunAsFake = value;
            }
        }
        private bool runAsFake;

        private bool isInit;
        private bool isCollecting;

        private List<RewardInfo> freeRewardInfos;
        private List<RewardInfo> bonusRewardInfos;

        private Action onRefresh;
        private bool debugMode;

        // A-1. freeRewardInfos, bonusRewardInfos 으로 전달된 값들은 팝업이 꺼질 때 자신의 오브젝트 풀로 리턴되고,
        // A-2. freeRewardInfos, bonusRewardInfos 리스트는 초기화 됩니다.
        // A-3. (Close() 메서드 참고)
        public void Open(List<RewardInfo> freeRewardInfos, List<RewardInfo> bonusRewardInfos, Action onRefresh, bool debugMode)
        {
            if (isInit == false)
            {
                freeRewardItemContainer.Init();
                bonusRewardItemContainer.Init();
                isInit = true;
            }

            this.onRefresh = onRefresh;
            this.debugMode = debugMode;

            SetupFreeItems(freeRewardInfos);
            SetupBonusItems(bonusRewardInfos);

            StartCoroutine(OpenCoroutine());
        }

        private void SetupFreeItems(List<RewardInfo> freeRewardInfos)
        {
            this.freeRewardInfos = freeRewardInfos;
            SetupItems(freeRewardInfos, REWARD_FREE_COUNT, freeBenefitButton, freeRewardItemContainer);
        }

        private void SetupBonusItems(List<RewardInfo> bonusRewardInfos)
        {
            this.bonusRewardInfos = bonusRewardInfos;
            SetupItems(bonusRewardInfos, REWARD_BONUS_COUNT, bonusBenefitButton, bonusRewardItemContainer);
        }

        private void SetupItems(List<RewardInfo> rewardInfos, int maxItemCount, GameObject benefitButton, SimpleRewardItemCollector container)
        {
            bool showMoreItems = rewardInfos.Count > maxItemCount;
            int infoCount = showMoreItems ? maxItemCount : rewardInfos.Count;

            benefitButton.SetActive(showMoreItems);

            container.RegisterAllStartPosition(Vector2.zero);
            
            container.Reset();
            container.Setup(rewardInfos, SimpleRewardItemValueType.Simple);

            // Setup() 에서 리워드 정렬을 수행 후 Visible 업데이트
            for (int i = 0; i < rewardInfos.Count; i++)
            {
                container.UpdateVisible(i, i < infoCount);
            }
        }

        public override void Close()
        {
            ReleaseRewardInfos(freeRewardInfos);
            ReleaseRewardInfos(bonusRewardInfos);

            base.Close();
        }

        private void ReleaseRewardInfos(List<RewardInfo> infos)
        {
            for (int i = 0; i < infos.Count; i++)
            {
                infos[i].Release();
            }
            infos.Clear();
        }

        private IEnumerator OpenCoroutine()
        {
            float timeBegin = Time.time;
            Interactable(false);
            allowBackButton = false;

            var seq = Coroutines.Create(
                this, 
                bonusRewardItemContainer.OpenCoroutine(), 
                freeRewardItemContainer.OpenCoroutine()
            );
            yield return seq.Parallel();

            Interactable(true);

            // 오픈 애니메이션이 끝날 때까지 백버튼 허용 안 함
            float timePassed = Time.time - timeBegin;
            yield return openAnimation.WaitForDuration(-timePassed);

            allowBackButton = true;
        }

        public void OpenPurchasePopup()
        {
            StartCoroutine(Popups.MissionPassPurchaseCoroutine(onComplete: Close));
        }

        private void Interactable(bool value)
        {
            collectButton.interactable = value;
            unlockButton.interactable = value;
        }

        public void CollectAll()
        {
            if (isCollecting)
            {
                return;
            }

            Interactable(false);

            StartCoroutine(CollectAllCoroutine());
        }

        private IEnumerator CollectAllCoroutine()
        {
            PopupSystem.Instance.ShowLoading();
            isCollecting = true;

            if (debugMode)
            {
                PopupSystem.Instance.HideLoading();
                yield return freeRewardItemContainer.CollectCoroutine();
            }
            else
            {
                IRequest<MissionPassClaimAllResponse> rewardReq;
                if (RunAsFake == false)
                {
                    rewardReq = NetworkSystem.HTTPRequester.MissionPassClaimAll();
                }
                else
                {
                    rewardReq = FakeHttpRequester.Instance.MissionPassClaimAll();
                }
                yield return rewardReq.WaitForResponse();

                PopupSystem.Instance.HideLoading();

                if (rewardReq.isSuccess && rewardReq.data.ret == 0)
                {
                    commonSound.Play();

                    collectFreeAnimation.SetTrigger();
                    yield return collectFreeAnimation.WaitForDuration();

                    yield return freeRewardItemContainer.CollectCoroutine();

                    //onRefresh?.Invoke();
                }
            }

            isCollecting = false;

            Close();
        }

        public void OpenFreeSeeMorePopup()
        {
            OpenSeeMorePopup(freeRewardInfos, MissionPassSeeMorePopup.TitleType.FreePass);
        }

        public void OpenBonusSeeMorePopup()
        {
            OpenSeeMorePopup(bonusRewardInfos, MissionPassSeeMorePopup.TitleType.MissionPassBenefit);
        }

        private void OpenSeeMorePopup(List<RewardInfo> rewardInfos, MissionPassSeeMorePopup.TitleType titleType)
        {
            if (rewardInfos == null || rewardInfos.Count == 0 || isCollecting)
            {
                return;
            }

            Popups.MissionPassSeeMore(rewardInfos, titleType).Async();
        }

        public override bool CanBack()
        {
            return Popups.IsLoading() == false
                   && collectButton.interactable == true
                   && base.CanBack();
        }
    }
}    