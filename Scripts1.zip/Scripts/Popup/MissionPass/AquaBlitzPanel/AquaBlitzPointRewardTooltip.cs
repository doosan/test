using Gaga.UI;
using System.Collections.Generic;
using TMPro;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Popup
{
    public class AquaBlitzPointRewardTooltip : MonoBehaviour, IRecyclingItemProvider
    {
        [SerializeField] private RecyclerListView listView;

        [SerializeField] private TextMeshProUGUI levelText;

        [SerializeField] private AquaBlitzPointRewardItem refRewardItem;
        [SerializeField] private AquaBlitzPointRewardItem refRewardItemTail;

        [SerializeField] private Button closeButton;

        private MyAquaBlitz AquaBlitz
        {
            get
            {
                if (aquaBlitz == null)
                {
                    aquaBlitz = MyInfo.AquaBlitz;
                }
                return aquaBlitz;
            }
        }
        private MyAquaBlitz aquaBlitz;

        private Dictionary<RectTransform, AquaBlitzPointRewardItem> rewardItems;

        private void OnEnable()
        {
            listView.onListItemPositionChanged.AddListener(OnListItemPositionChanged);
            listView.onListItemSiblingOrderChanged.AddListener(OnListItemSiblingOrderChanged);

            UpdateContent();
        }

        private void OnDisable()
        {
            listView.onListItemPositionChanged.RemoveListener(OnListItemPositionChanged);
            listView.onListItemSiblingOrderChanged.RemoveListener(OnListItemSiblingOrderChanged);
        }

        private void OnListItemPositionChanged(int itemIndex, Vector2 anchoredPosition, Vector2 sizeDelta)
        {
            if (refRewardItemTail.gameObject.activeInHierarchy
                && IsLastIndex(itemIndex))
            {
                float nextPositionX = anchoredPosition.x + sizeDelta.x;
                float nextPositionY = refRewardItemTail.CachedTransform.anchoredPosition.y;
                if (refRewardItemTail.CachedTransform.anchoredPosition.x != nextPositionX)
                {
                    refRewardItemTail.CachedTransform.anchoredPosition = new Vector2(nextPositionX, nextPositionY);
                }
            }
        }

        private void OnListItemSiblingOrderChanged(int itemIndex, BaseListView.SiblingOrder siblingOrder)
        {
            if (IsLastIndex(itemIndex))
            {
                if (siblingOrder == BaseListView.SiblingOrder.First)
                {
                   refRewardItemTail.CachedTransform.SetAsFirstSibling();
                }
                else if (siblingOrder == BaseListView.SiblingOrder.Last)
                {
                    refRewardItemTail.CachedTransform.SetAsLastSibling();
                }
            }
        }

        public void Init()
        {
            refRewardItem.gameObject.SetActive(false);
            refRewardItemTail.gameObject.SetActive(false);

            rewardItems = new Dictionary<RectTransform, AquaBlitzPointRewardItem>();

            listView.Initialize();
        }

        public void Reset()
        {
            refRewardItemTail.gameObject.SetActive(false);
        }

        private void UpdateLevelText(int step)
        {
            levelText.text = step >= MyInfo.AquaBlitz.PointRewardInfoCount ?
                             "MAX" : 
                             $"LEVEL {step}";
        }

        public void UpdateContent()
        {
            //
            UpdateLevelText(AquaBlitz.Step);

            // 가장 최근에 완료한 지점으로
            int startIndex = AquaBlitz.Step - 1;

            listView.ItemProvider = this;
            listView.ReactivateAllItems();
            listView.GoTo(startIndex, 0.0f);
        }

        public void Close()
        {
            gameObject.SetActive(false);
        }

        int IRecyclingItemProvider.GetItemsCount()
        {
            return Mathf.Max(0, AquaBlitz.PointRewardInfoCount - 1); // 맨 끝의 Tail 용 데이터 제외
        }

        RectTransform IRecyclingItemProvider.CreateItem()
        {
            AquaBlitzPointRewardItem rewardItem = Instantiate(refRewardItem);
            RectTransform rewardItemTransform = rewardItem.GetComponent<RectTransform>();
            rewardItems.Add(rewardItemTransform, rewardItem);

            return rewardItemTransform;
        }

        void IRecyclingItemProvider.OnItemEnable(int index, RectTransform item)
        {
            //Debug.Log($"==== OnItemEnable : {index}, {IsLastIndex(index)}");
            AquaBlitzPointRewardItem rewardItem;
            if (rewardItems.ContainsKey(item) == false)
            {
                rewardItem = item.GetComponent<AquaBlitzPointRewardItem>();
                rewardItems.Add(item, rewardItem);
            }
            else
            {
                rewardItem = rewardItems[item];
            }


            AquaBlitzPointRewardInfo rewardInfo = AquaBlitz.GetPointRewardInfo(index);
            int step = index + 1;
            float curr = step == AquaBlitz.Step ? AquaBlitz.Curr : 
                         step < AquaBlitz.Step ? AquaBlitz.All :
                         0;
            float all = AquaBlitz.All;

            //Debug.Log($"==== OnItemEnable : {step}, {rewardInfo.status}, {curr}/{all}");
            rewardItem.Setup(rewardInfo, step, curr, all);

            if (IsLastIndex(index))
            {
                refRewardItemTail.gameObject.SetActive(true);
                refRewardItemTail.CachedTransform.SetParent(listView.Content);

                int tailIndex = index + 1;
                int tailStep = tailIndex + 1;
                bool isStepInProgress = AquaBlitz.Step == tailStep;
                float tailCurr = isStepInProgress ? AquaBlitz.Curr : 0;
                float tailAll = AquaBlitz.All;
                AquaBlitzPointRewardInfo tailRewardInfo = AquaBlitz.GetPointRewardInfo(tailIndex);
                refRewardItemTail.Setup(tailRewardInfo, tailStep, tailCurr, tailAll);
            }
        }

        void IRecyclingItemProvider.RemoveItem(int index)
        {

        }

        RecyclerListView.InitializationItemInfo IRecyclingItemProvider.OnItemInitialize(int index, RectTransform item)
        {
            return new RecyclerListView.InitializationItemInfo(item);
        }

        void IRecyclingItemProvider.OnItemDisable(int index, RectTransform item)
        {
            //Debug.Log($"==== OnItemDisable : {index}, {IsLastIndex(index)}"); ;
            if (IsLastIndex(index))
            {
                refRewardItemTail.gameObject.SetActive(false);
            }
        }

        private bool IsLastIndex(int index)
        {
            return index == AquaBlitz.PointRewardInfoCount - 2;  // 맨 끝의 Tail 용 데이터 제외
        }
    }
}