using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using Gaga.Sound;
using Gaga.Util;
using System.Collections;
using TMPro;
using Underc.User;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace Underc.Popup
{
    public struct AquaBlitzRemainingUpdate
    {
        public long curr;
        public long all;
        public int step;

        public AquaBlitzRemainingUpdate(long curr, long all, int step)
        {
            this.curr = curr;
            this.all = all;
            this.step = step;
        }
    }

    public class AquaBlitzPointGauge : MonoBehaviour
    {
        public enum CountVisibleType
        {
            True,
            False,
            Keep
        }

        [SerializeField] private CanvasGroup canvasGroup;
        [FormerlySerializedAs("button")]
        [SerializeField] private Button clickArea;

        [Space]
        [SerializeField] private RectTransform pointIconTransform;
        [SerializeField] private Animator pointIconAnimator;
        [SerializeField] private TextMeshProUGUI stepText;
        [SerializeField] private TextMeshProUGUI pointText;
        [SerializeField] private TextMeshProUGUI seasonText;

        [Header("Reward")]
        [SerializeField] private GameObject rewardCountObject;
        [SerializeField] private TextMeshProUGUI rewardCountText;
        [SerializeField] private Animator rewardIconAnimator;
        [SerializeField] private CanvasGroup rewardIconCanvasGroup;

        [Header("Animation")]
        [SerializeField] private AnimatorParser rewardOpenAnimation;
        [SerializeField] private AnimatorParser rewardCloseAnimation;

        [Header("Sound")]
        [SerializeField] private SoundPlayer rewardOpenSound;

        [Header("Gauge")]
        [SerializeField] private float gaugeDelay = .0f;
        [SerializeField] private float gaugeDuration = .3f;
        [SerializeField] private Ease gaugeEase = Ease.Linear;
        [SerializeField] private Slider pointGuage;

        public RectTransform CachedTransform
        {
            get
            {
                if (cachedTransform == null)
                {
                    cachedTransform = GetComponent<RectTransform>();
                }
                return cachedTransform;
            }
        }
        private RectTransform cachedTransform;

        public bool Interactable
        {
            set => clickArea.interactable = value;
        }

        public Vector2 PointIconPosition
        {
            get => pointIconTransform.position;
        }

        public float GaugeDelay
        {
            get
            {
                return gaugeDelay;
            }
        }

        public float GaugeDuration
        {
            get
            {
                return gaugeDuration;
            }
        }

        private long curr;
        private long all;
        private TweenerCore<long, long, NoOptions> currTween;
        private AquaBlitzRemainingUpdate remainingUpdate;

        public void Init()
        {
        }

        public void Reset()
        {
            stepText.text = "";
            pointGuage.value = 0;
            pointText.text = "";
            seasonText.text = "";
            rewardCountObject.SetActive(false);
        }

        public IEnumerator RewardOpen()
        {
            MyInfo.AquaBlitz.UpdatePointRewardOpened(true);
            rewardOpenSound.Play();
            rewardOpenAnimation.SetTrigger();
            yield return rewardOpenAnimation.WaitForDuration();
        }

        public void UpdateContent(bool isProgressive, bool isPointRefreshed, bool isStepUpInProgress)
        {
            if (isPointRefreshed)
            {
                canvasGroup.alpha = 0;
                canvasGroup.DOFade(1f, .3f);
            }

            long nextAll = MyInfo.AquaBlitz.All;
            int nextStep = MyInfo.AquaBlitz.Step;
            long nextCurr = MyInfo.AquaBlitz.Curr;
            if (isStepUpInProgress == true)
            {
                Debug.Log($"==== UpdateContent : {nextStep} vs {MyInfo.AquaBlitz.PointRewardInfoCount}");
                if (nextStep > MyInfo.AquaBlitz.PointRewardInfoCount)
                {
                    nextCurr = MyInfo.AquaBlitz.All;
                }
                else
                {
                    nextCurr += MyInfo.AquaBlitz.All;
                }
            }

            int season = MyInfo.AquaBlitz.Season;
            int pointRewardCount = MyInfo.AquaBlitz.PointRewardCount;

            ResetCurrTween();
            if (pointGuage.value != nextCurr
                && isProgressive == true)
            {
                all = nextAll;
                currTween = DOTween.To(getter: () => curr,
                                       setter: value => curr = value,
                                       endValue: nextCurr,
                                       duration: gaugeDuration)
                                   .SetDelay(gaugeDelay)
                                   .SetEase(gaugeEase)
                                   .OnUpdate(OnCurrUpdate); 
            }
            else
            {
                curr = nextCurr;
                all = nextAll;
                OnCurrUpdate();
                UpdateStepText(nextStep);
                UpdateSeasonText(season);
                UpdateRewardCount(pointRewardCount);
            }
        }

        public float UpdateRewardCount(int rewardCount, CountVisibleType countVisibleType = CountVisibleType.True)
        {
            float duration = 0f;

            string rewardTrigger = rewardCount > 0 ? "On" : "Off";
            if (MyInfo.AquaBlitz.ConsumePointRewardOpened())
            {
                duration = rewardCloseAnimation.Duration;
                StartCoroutine(RewardCloseCoroutine(rewardCount, rewardTrigger));
            }
            else
            {
                _UpdateRewardCount(rewardCount, rewardTrigger, countVisibleType);
            }

            return duration;
        }

        private void _UpdateRewardCount(int rewardCount, string rewardTrigger, CountVisibleType countVisibleType = CountVisibleType.True)
        {
            if (countVisibleType == CountVisibleType.True)
            {
                bool hasReward = rewardCount >= 1;
                rewardCountObject.SetActive(hasReward);
            }
            else if (countVisibleType == CountVisibleType.False)
            {
                rewardCountObject.SetActive(false);
            }

            rewardCountText.text = rewardCount.ToString();
            rewardIconAnimator.SetTrigger(rewardTrigger);
        }

        public IEnumerator RewardCloseCoroutine(int rewardCount, string rewardTrigger)
        {
            rewardCloseAnimation.SetTrigger();
            yield return rewardCloseAnimation.WaitForDuration();
            _UpdateRewardCount(rewardCount, rewardTrigger);
        }

        public void GetPoint()
        {
            pointIconAnimator.SetTrigger("On");
        }

        private void ResetCurrTween()
        {
            currTween?.Kill();
            currTween = null;
        }

        private void OnCurrUpdate()
        {
            //Debug.Log($"==== OnCurrUpdate : {curr} / {all}");
            long currValue = curr;
            if (curr >= all)
            {
                remainingUpdate = new AquaBlitzRemainingUpdate(curr, all, MyInfo.AquaBlitz.Step);
                currValue = all;
                
                UpdateRewardCount(MyInfo.AquaBlitz.PointRewardCount, countVisibleType: AquaBlitzPointGauge.CountVisibleType.Keep);
            }

            pointGuage.wholeNumbers = true;
            pointGuage.maxValue = all;
            pointGuage.value = currValue;

            pointText.text = $"{currValue} / {all}";
        }

        public IEnumerator DoRemainingUpdate()
        {
            long nextCurr = remainingUpdate.curr;
            long all = remainingUpdate.all;
            int step = remainingUpdate.step;
            nextCurr -= all;

            curr = 0;
            pointGuage.value = curr;
            pointText.text = $"{curr} / {all}";
            UpdateStepText(step);

            currTween = DOTween.To(getter: () => curr,
                                   setter: value => curr = value,
                                   endValue: nextCurr,
                                   duration: gaugeDuration)
                               .SetDelay(gaugeDelay)
                               .SetEase(gaugeEase)
                               .OnUpdate(OnCurrUpdate);
            yield return new WaitForSeconds(gaugeDuration);
        }

        private void UpdateStepText(int step)
        {
            stepText.text = (step >= MyInfo.AquaBlitz.PointRewardInfoCount) ?
                            "MAX" : step.ToString();
        }

        private void UpdateSeasonText(int season)
        {
            seasonText.text = $"SEASON {season}";
        }
    }
}