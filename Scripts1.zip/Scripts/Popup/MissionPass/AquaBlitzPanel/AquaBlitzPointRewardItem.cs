using Gaga;
using System.Collections.Generic;
using TMPro;
using Underc.User;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace Underc.Popup
{
    public class AquaBlitzPointRewardItem : MonoBehaviour
    {
        [SerializeField] private GameObject guageObject;
        [SerializeField] private Slider gaugeSlider;
        [SerializeField] private TextMeshProUGUI stepText;

        [Header("Common")]
        [FormerlySerializedAs("rewardItemCommon")]
        [SerializeField] private SimpleRewardItem commonRewardItem;
        [FormerlySerializedAs("rewardStateVisibleToggleCommon")]
        [SerializeField] private List<GameObjectVisibleToggle> commonRewardStateVisibleToggles;

        [Header("Big")]
        [FormerlySerializedAs("rewardItemBig")]
        [SerializeField] private SimpleRewardItem bigRewardItem;
        [FormerlySerializedAs("rewardStateVisibleToggleCommon")]
        [SerializeField] private List<GameObjectVisibleToggle> bigRewardStateVisibleToggles;

        public RectTransform CachedTransform
        {
            get
            {
                if (cachedTransform == null)
                {
                    cachedTransform = GetComponent<RectTransform>();
                }
                return cachedTransform;
            }
        }
        private RectTransform cachedTransform;

        private void OnEnable()
        {
            Reset();
        }

        public void Reset()
        {
            guageObject.SetActive(true);
            if (stepText != null)
            {
                stepText.text = "";
            }

            if (commonRewardItem != null)
            { 
                foreach (GameObjectVisibleToggle visibleToggle in commonRewardStateVisibleToggles)
                {
                    visibleToggle?.TurnOff();
                }
                commonRewardItem.gameObject.SetActive(false);
            }

            if (bigRewardItem != null)
            {
                foreach (GameObjectVisibleToggle visibleToggle in bigRewardStateVisibleToggles)
                {
                    visibleToggle?.TurnOff();
                }
                bigRewardItem.gameObject.SetActive(false);
            }
        }

        public void Setup(AquaBlitzPointRewardInfo info, int step, float curr, float all)
        {
            AquaBlitzPointRewardStatus status = info.status;
            bool isBigIndex = info.isBigIndex;
            bool hasReward = info.type != RewardType.none;

            guageObject.SetActive(step > 0);
            if (stepText != null)
            {
                stepText.text = step.ToString();
            }

            gaugeSlider.value = curr / all;

            //
            List<GameObjectVisibleToggle> rewardStateVisibleToggles = null;
            SimpleRewardItem rewardItem = null;
            if (isBigIndex)
            {
                rewardStateVisibleToggles = bigRewardStateVisibleToggles;
                rewardItem = bigRewardItem;
            }
            else
            {
                rewardStateVisibleToggles = commonRewardStateVisibleToggles;
                rewardItem = commonRewardItem;
            }

            foreach (GameObjectVisibleToggle visibleToggle in rewardStateVisibleToggles)
            {
                visibleToggle.gameObject.SetActive(hasReward);
                visibleToggle.TurnOnByNameInMultiple(status.ToString());
            }
            rewardItem.gameObject.SetActive(hasReward);
            if (hasReward)
            {
                rewardItem.UpdateContent(info);
            }
        }
    }
}