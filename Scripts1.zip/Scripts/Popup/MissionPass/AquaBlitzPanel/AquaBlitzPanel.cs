using Gaga;
using Gaga.Popup;
using Gaga.System;
using Gaga.Util;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using Underc.Net;
using Underc.Net.Client;
using Underc.Scene;
using Underc.UI;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Popup
{
    public class AquaBlitzPanel : BaseMissionPassContentPanel
    {
        [Header("Point Gauge")]
        [SerializeField] private TextMeshProUGUI pointEndRemainingText;
        [SerializeField] private AquaBlitzPointGauge pointGauge;

        [Header("Mission Items")]
        [SerializeField] private TextMeshProUGUI missionEndRemainingText;
        [SerializeField] private Transform missionItemContent;
        [SerializeField] private Transform missionItemPoolRoot;
        [SerializeField] private AquaBlitzMissionItem missionItemRef;

        [SerializeField] private AquaBlitzPointRewardTooltip pointRewardTooltip;

        private GameObjectPool<AquaBlitzMissionItem> missionItemPool;
        private List<AquaBlitzMissionItem> missionItems;

        public override Vector2 PointGaugePosition
        {
            get => pointGauge.PointIconPosition;
        }

        private MyAquaBlitz AquaBlitz
        {
            get
            {
                if (aquaBlitz == null)
                {
                    aquaBlitz = MyInfo.AquaBlitz;
                }
                return aquaBlitz;
            }
        }
        private MyAquaBlitz aquaBlitz;

        private TimeoutWatcher<AquaBlitzRemainingTime> TimeoutWatcher
        {
            get
            {
                if (timeoutWatcher == null)
                {
                    timeoutWatcher = new TimeoutWatcher<AquaBlitzRemainingTime>();
                }
                return timeoutWatcher;
            }
        }
        private TimeoutWatcher<AquaBlitzRemainingTime> timeoutWatcher;

        private Coroutines Coroutines
        {
            get
            {
                coroutines = Coroutines.Create(this).Cache();
                return coroutines;
            }
        }
        private Coroutines coroutines;

        private void OnEnable()
        {
            AquaBlitz.onTimeUpdate.AddListener(OnTimeUpdate);

            TimeoutWatcher.Add(AquaBlitzRemainingTime.Point,
                               () => AquaBlitz.PointEndRemainingSec);
            TimeoutWatcher.Add(AquaBlitzRemainingTime.Mission,
                               () => AquaBlitz.MissionEndRemainingSec);
        }

        private void OnDisable()
        {
            AquaBlitz.onTimeUpdate.RemoveListener(OnTimeUpdate);
        }

        public override bool CanBack()
        {
            return Coroutines.IsRunning == false;
        }

        public override bool Close()
        {
            bool result = true;
            if (pointRewardTooltip.gameObject.activeInHierarchy)
            {
                pointRewardTooltip.Close();
                result = false;
            }

            return result;
        }

        public override void Init()
        {
            pointGauge.Init();
            pointRewardTooltip.Init();

            missionItemRef.gameObject.SetActive(false);
            missionItemPool = missionItemRef.CreatePool(
                rootName: "MissionItemPool",
                parent: missionItemPoolRoot,
                size: 5
            );
            missionItems = new List<AquaBlitzMissionItem>();
        }

        public override void Reset()
        {
            pointGauge.Reset();
            pointRewardTooltip.Reset();
            pointEndRemainingText.text = "";
            missionEndRemainingText.text = "";

            ResetMissionItems();
        }

        private void ResetMissionItems()
        {
            if (missionItems != null)
            {
                foreach (AquaBlitzMissionItem missionItem in missionItems)
                {
                    missionItem.Reset();
                }
            }
        }

        private void SetupMissionItems()
        {
            bool isMissionRefreshed = TimeoutWatcher.Consume(AquaBlitzRemainingTime.Mission);

            for (int infoIndex = 0; infoIndex < AquaBlitz.MissionInfoCount; infoIndex++)
            {
                if (infoIndex >= missionItems.Count)
                {
                    AquaBlitzMissionItem missionItem = missionItemPool.Get();
                    missionItems.Add(missionItem);
                    missionItem.transform.SetParent(missionItemContent);
                }

                if (infoIndex < missionItems.Count)
                {
                    AquaBlitzMissionItem missionItem = missionItems[infoIndex];
                    AquaBlitzMissionInfo missionInfo = AquaBlitz.GetMissionInfo(infoIndex);

                    bool isMissionInProgress = (SceneSystem.IsGameSceneInActive == true || RunAsFake == true)
                                             && (AquaBlitz.LatestMissionSpinIndex == infoIndex);
                    missionItem.Setup(isMissionRefreshed, infoIndex, missionInfo, isMissionInProgress, OnMissionItemGoClick, OnMissionItemCollectClick);
                }
            }
        }

        private void OnMissionItemGoClick(string slotID)
        {
            OnGoToSlot?.Invoke(slotID, MissionPassPopupTab.AquaBlitz);
        }

        private void OnMissionItemCollectClick(int missionIndex)
        {
            Coroutines.Add(LoadAquaBlitzMissionClaimCoroutine(missionIndex))
                      .Sequence()
                      .OnComplete(() => OnRefresh?.Invoke());
        }

        private IEnumerator LoadAquaBlitzMissionClaimCoroutine(int missionIndex)
        {
            Popups.ShowLoading();
            IRequest<AquaBlitzClaimResponse> req;
            if (RunAsFake == false)
            {
                req = NetworkSystem.HTTPRequester.AquaBlitzMissionClaim(missionIndex);
            }
            else
            {
                req = FakeHttpRequester.Instance.AquaBlitzMissionClaim(missionIndex);
            }
            yield return req.WaitForResponse();
            Popups.HideLoading();

            if (req.isSuccess)
            {
                OnInteractable(false);

                // 보상 정보 업데이트
                MyInfo.MissionPass.UpdateStep(req.data.mission_pass_step);
                List<RewardInfo> rewardInfos = MyInfo.AquaBlitz.AsRewardInfos(req.data.reward);

                int nextStep = req.data.aqua_blitz_step;
                long nextCurr = req.data.aqua_blitz_curr;
                if (nextStep == MyInfo.AquaBlitz.Step
                    && nextCurr >= MyInfo.AquaBlitz.All)
                {
                    nextStep += 1;
                }
                bool hasPointReward = nextStep > MyInfo.AquaBlitz.Step;
                bool waitForRewardDone = true;

                // 보상 팝업
                if (rewardInfos.Count > 0)
                {
                    PopupObject<MissionPassRewardPopup> popupObject = null;
                    var missionPassPointTransition = MissionPassPointTransition.GetOrAdd(gameObject);
                    popupObject = Popups.MissionPassReward(
                        titleType: MissionPassRewardPopup.TitleType.AquaBlitzMissionReward,
                        rewardInfos: rewardInfos,
                        onInit: () =>
                        {
                            MissionPassRewardPopup popup = popupObject.GetPopup();
                            var missionPassTabInfo = new HighlightObjectInfo(
                                originTransform: TabTransformInfo.TabTransform(MissionPassPopupTab.MissionPass),
                                visibleType: HighlightVisibleType.Alpha,
                                initialActive: false
                            );
                            popup.Register(missionPassTabInfo);

                            // 복제품은 연출 용도이므로 ToggleGroup 및 이벤트 리스너를 제거한다
                            Toggle missionPassToggle = missionPassTabInfo.clonedTransform.GetComponent<Toggle>();
                            missionPassToggle.onValueChanged.RemoveAllListeners();
                            missionPassToggle.group = null;
                            missionPassToggle.isOn = true;

                            var pointGaugeInfo = new HighlightObjectInfo(
                                originTransform: pointGauge.CachedTransform,
                                visibleType: HighlightVisibleType.Alpha,
                                initialActive: false
                            );
                            popup.Register(pointGaugeInfo);

                            AquaBlitzPointGauge clonedPointGauge = pointGaugeInfo.clonedTransform.GetComponent<AquaBlitzPointGauge>();
                            AquaBlitzPointGauge originPointGauge = pointGaugeInfo.originTransform.GetComponent<AquaBlitzPointGauge>();

                            //
                            SimpleRewardItemCollector itemCollector = popup.RewardItemCollector;
                            itemCollector.RegisterEndPosition(RewardType.blitz_point, PointGaugePosition);

                            missionPassPointTransition.Setup(itemCollector, missionPassTabInfo, showMissionPassLevelUp: false);

                            itemCollector.OnEffectShow.AddListener((RewardType rewardType) =>
                            {
                                if (rewardType == RewardType.blitz_point)
                                {
                                    pointGaugeInfo.SetCloneActive(true);
                                    // A-1 이전 값을 그대로 보여줌
                                    clonedPointGauge.UpdateContent(isProgressive: false, isPointRefreshed: false, isStepUpInProgress:false);
                                }
                            });
                            itemCollector.OnEffectFirstArrived.AddListener((RewardType rewardType) =>
                            {
                                if (rewardType == RewardType.blitz_point)
                                {
                                    // A-2 다음 값을 세팅 후 보여줌
                                    MyInfo.AquaBlitz.UpdateStepAndCurr(nextStep, nextCurr);
                                    bool isStepUpInProgress = MyInfo.AquaBlitz.ConsumeStepUpInProgress();
                                    clonedPointGauge.UpdateContent(isProgressive: true, isPointRefreshed: false, isStepUpInProgress);
                                    clonedPointGauge.GetPoint();

                                    originPointGauge.UpdateContent(isProgressive: true, isPointRefreshed: false, isStepUpInProgress);
                                }
                            });
                            itemCollector.OnEffectComplete.AddListener(() =>
                            {
                                pointGaugeInfo.SetCloneActive(isOn: false, keepFade: true);
                                waitForRewardDone = false;
                            });
                        }
                    ).Async();

                    while (waitForRewardDone)
                    {
                        yield return null;
                    }

                    if (hasPointReward)
                    {
                        int startRewardIndex = AquaBlitz.GetNextPointRewardIndex();
                        int endRewardIndex = nextStep - 1;
                        int pointRewardCount = MyInfo.AquaBlitz.PointRewardCount;
                        float duration;
                        for (int rewardIndex = startRewardIndex; rewardIndex < endRewardIndex; rewardIndex++)
                        {
                            pointRewardCount -= 1;
                            duration = pointGauge.UpdateRewardCount(pointRewardCount, countVisibleType: AquaBlitzPointGauge.CountVisibleType.Keep);
                            if (duration > 0f)
                            {
                                yield return new WaitForSeconds(duration);
                            }
                            yield return LoadAquaBlitzClaimCoroutine(rewardIndex);
                        }

                        duration = pointGauge.UpdateRewardCount(pointRewardCount, countVisibleType: AquaBlitzPointGauge.CountVisibleType.Keep);
                        if (duration > 0f)
                        {
                            yield return new WaitForSeconds(duration);
                        }

                        yield return pointGauge.DoRemainingUpdate();
                    }

                    missionPassPointTransition.CheckIfMissionPassStepUp();
                    yield return missionPassPointTransition.WaitForDone();
                }

                OnInteractable(true);
            }
        }

        public override IEnumerator UpdateContent(UpdateContentType updateType)
        {
            pointGauge.UpdateContent(
                isProgressive: false,
                isPointRefreshed: TimeoutWatcher.Consume(AquaBlitzRemainingTime.Point),
                isStepUpInProgress: false
            );

            SetupMissionItems();
            for (int itemIndex = 0; itemIndex < missionItems.Count; itemIndex++)
            {
                AquaBlitzMissionItem missionItem = missionItems[itemIndex];
                missionItem.UpdateContent();
            }

            OnTimeUpdate();
            yield break;
        }

        public void OpenInfoPopup()
        {
            Popups.AquaBlitzInfo()
                  .Async();
        }

        public void ClickPointReward()
        {
            int rewardIndex = AquaBlitz.GetNextPointRewardIndex();
            AquaBlitzPointRewardInfo rewardInfo = AquaBlitz.GetPointRewardInfo(rewardIndex);
            if (rewardInfo.status == AquaBlitzPointRewardStatus.Done)
            {
                // 연출 용도로 미리 하나 뺌
                pointGauge.UpdateRewardCount(MyInfo.AquaBlitz.PointRewardCount - 1);

                Coroutines.Add(LoadAquaBlitzClaimCoroutine(rewardIndex))
                          .Sequence()
                          .OnComplete(() => OnRefresh?.Invoke());
            }
            else
            {
                pointRewardTooltip.gameObject.SetActive(true);
            }
        }

        private IEnumerator LoadAquaBlitzClaimCoroutine(int pointRewardIndex)
        {
            Popups.ShowLoading();
            IRequest<AquaBlitzClaimResponse> req;
            if (RunAsFake == false)
            {
                int step = pointRewardIndex + 1;
                req = NetworkSystem.HTTPRequester.AquaBlitzClaim(step);
            }
            else
            {
                req = FakeHttpRequester.Instance.AquaBlitzPointClaim(pointRewardIndex);
            }
            yield return req.WaitForResponse();
            Popups.HideLoading();

            if (req.isSuccess)
            {
                List<RewardInfo> rewardInfos = MyInfo.AquaBlitz.AsRewardInfos(req.data.reward);

                PopupObject<MissionPassRewardPopup> popupObject = null;
                popupObject = Popups.MissionPassReward(
                    titleType: MissionPassRewardPopup.TitleType.AquaBlitzPointReward,
                    rewardInfos: rewardInfos,
                    onInit: () =>
                    {
                        MissionPassRewardPopup popup = popupObject.GetPopup();
                        var pointGaugeInfo = new HighlightObjectInfo(
                            originTransform: pointGauge.CachedTransform,
                            visibleType: HighlightVisibleType.Alpha,
                            initialActive: true
                        );
                        popup.Register(pointGaugeInfo);

                        AquaBlitzPointGauge clonedPointGauge = pointGaugeInfo.clonedTransform.GetComponent<AquaBlitzPointGauge>();
                        popup.Run(
                            delay: .3f,
                            coroutine: clonedPointGauge.RewardOpen(),
                            onComplete: () =>
                            {
                                pointGaugeInfo.SetCloneActive(isOn: false, keepFade: true);
                                popup.Show();
                            }
                        );
                    },
                    openAsShow: false
                ).Async();

                yield return popupObject.WaitForClose();
            }
            else
            {
                OnError?.Invoke(req.data.error);
            }

            yield break;
        }

        private void OnTimeUpdate()
        {
            pointEndRemainingText.text = AquaBlitz.PointEndRemainingSec.ToNDaysLeft();
            missionEndRemainingText.text = AquaBlitz.MissionEndRemainingSec.ToSummaryDHMS();

            pointGauge.Interactable = AquaBlitz.PointEndRemainingSec > 0;
            for (int itemIndex = 0; itemIndex < missionItems.Count; itemIndex++)
            {
                AquaBlitzMissionItem missionItem = missionItems[itemIndex];
                missionItem.Interactable = AquaBlitz.MissionEndRemainingSec > 0;
            }

            //
            TimeoutWatcher.Watch(onTimeout: OnTimeout);
        }

        private void OnTimeout(AquaBlitzRemainingTime type)
        {
            if (type == AquaBlitzRemainingTime.Point)
            {
                OnClose?.Invoke();
            }
            else
            {
                OnRefresh?.Invoke();
            }
        }
    }
}
