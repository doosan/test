using Gaga;
using Gaga.Sound;
using Gaga.System;
using Gaga.Util;
using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Popup
{
    public class AquaBlitzMissionItem : MonoBehaviour
    {
        public enum AquaBlitzMissionItemButtonStatus
        { 
            Go,
            Collect,
            UnderRepair
        }

        [SerializeField] private TextMeshProUGUI slotIconText;
        [SerializeField] private Image slotIconImage;
        [SerializeField] private TextMeshProUGUI missionText;

        [Header("Guage")]
        [SerializeField] private Slider progressSlider;
        [SerializeField] private TextMeshProUGUI progressText;

        [Header("Reward Item")]
        [SerializeField] private Transform rewardItemContent;
        [SerializeField] private Transform rewardItemPoolRoot;
        [SerializeField] private SimpleRewardItem rewardItemRef;

        [Header("Button")]
        [SerializeField] private GameObjectVisibleToggle buttonVisibleToggle;

        [Header("Animation")]
        [SerializeField] private AnimatorParser refreshAnimation;
        [SerializeField] private AnimatorParser renewAnimation;
        [SerializeField] private SoundPlayer renewSound;
        [SerializeField] private GameObject selectedEffect;

        public bool Interactable
        {
            set
            {
                foreach (Button button in buttonVisibleToggle.GetComponentsInChildren<Button>())
                {
                    button.interactable = value;
                }
            }
        }

        private GameObjectPool<SimpleRewardItem> rewardItemPool;
        private List<SimpleRewardItem> rewardItems;

        private bool isMissionRefreshed;
        private int missionIndex;
        private AquaBlitzMissionInfo prevMissionInfo;
        private AquaBlitzMissionInfo missionInfo;
        private bool isMissionInProgress;
        private Action<string> onGoClick;
        private Action<int> onCollectClick;
        private int latestPicIndex;

        public void Reset()
        {
            ResetRewardItems();

            missionText.text = "";
            slotIconImage.color = new Color(1, 1, 1, 0);

            missionInfo = null;
            prevMissionInfo = null;
        }

        public void Setup(bool isMissionRefreshed,
                          int missionIndex, 
                          AquaBlitzMissionInfo nextMissionInfo, 
                          bool isMissionInProgress,
                          Action<string> onGoClick = null, 
                          Action<int> onCollectClick = null)
        {
            this.isMissionRefreshed = isMissionRefreshed;
            this.missionIndex = missionIndex;

            if (this.missionInfo != null)
            {
                prevMissionInfo = this.missionInfo.Clone();
            }

            this.missionInfo = nextMissionInfo;
            this.isMissionInProgress = isMissionInProgress;
            this.onGoClick = onGoClick;
            this.onCollectClick = onCollectClick;

            if (rewardItemPool == null)
            {
                rewardItemRef.gameObject.SetActive(false);
                rewardItemPool = rewardItemRef.CreatePool(
                    rootName: "RewardItemPool",
                    parent: rewardItemPoolRoot,
                    size: 2
                );
                rewardItems = new List<SimpleRewardItem>();
            }

            SetupRewardItems();
        }

        public void GoClick()
        {
            onGoClick?.Invoke(missionInfo.slotID.ToString());
        }

        public void CollectClick()
        {
            onCollectClick?.Invoke(missionIndex);
        }

        private void ResetRewardItems()
        {
            if (rewardItems != null)
            {
                foreach (SimpleRewardItem rewardItem in rewardItems)
                {
                    rewardItemPool.Return(rewardItem);
                }
                rewardItems.Clear();
            }
        }

        private void SetupRewardItems()
        {
            for (int infoIndex = 0; infoIndex < missionInfo.RewardInfoCount; infoIndex++)
            {
                if (rewardItems.Count <= infoIndex)
                {
                    SimpleRewardItem rewardItem = rewardItemPool.Get();
                    rewardItem.Reset();
                    rewardItem.transform.SetParent(rewardItemContent);

                    rewardItems.Add(rewardItem);
                }
            }
        }

        public void UpdateContent()
        {
            if (missionInfo.Equals(prevMissionInfo) == false)
            {
                if (prevMissionInfo != null)
                {
                    Debug.Log($"==== UpdateContent : {isMissionRefreshed}");
                    if (isMissionRefreshed)
                    {
                        refreshAnimation.SetTrigger();
                    }
                    else
                    {
                        renewAnimation.SetTrigger();
                        renewSound.Play();
                    }

                    StartCoroutine(UpdateContentCoroutine(15f/60f));
                }
                else
                {
                    StartCoroutine(UpdateContentCoroutine());
                }
            }
        }

        private IEnumerator UpdateContentCoroutine(float delay = 0)
        {
            if (delay > 0)
            {
                yield return new WaitForSeconds(delay);
            }

            int nextPicIndex = missionInfo.slotID;
            slotIconText.text = nextPicIndex.ToString();

            if (nextPicIndex >= 1000
                && latestPicIndex != nextPicIndex)
            {
                SlotIconSystem.Instance.GetAsync(
                    picIndex: nextPicIndex,
                    onComplete: (Sprite sprite) =>
                    {
                        latestPicIndex = nextPicIndex;
                        slotIconImage.SetPicture(sprite);
                    }
                );
            }
            else
            {
                slotIconImage.color = new Color(1, 1, 1, 1);
            }
            missionText.text = missionInfo.missionFormatInfo.GetFormat(missionFormatColor: MissionFormatColor.White, linebreak: "\n");

            float progress = missionInfo.curr / (float)missionInfo.all;
            progressSlider.value = progress;

            progressText.text = $"{StringUtils.ToGeneralKMB(missionInfo.curr)}/{StringUtils.ToGeneralKMB(missionInfo.all)}";

            for (int itemIndex = 0; itemIndex < rewardItems.Count; itemIndex++)
            {
                RewardInfo rewardInfo = missionInfo.GetRewardInfo(itemIndex);
                SimpleRewardItem rewardItem = rewardItems[itemIndex];
                rewardItem.UpdateContent(rewardInfo);
            }

            int status = missionInfo.status;
            AquaBlitzMissionItemButtonStatus buttonStatus = AquaBlitzMissionItemButtonStatus.UnderRepair;
            if (status == 0)
            {
                buttonStatus = progress >= 1f ?
                               AquaBlitzMissionItemButtonStatus.Collect :
                               AquaBlitzMissionItemButtonStatus.Go;
            }
            buttonVisibleToggle.TurnOnByNameInMultiple(buttonStatus.ToString());

            selectedEffect?.SetActive(isMissionInProgress);
            yield break;
        }
    }
}