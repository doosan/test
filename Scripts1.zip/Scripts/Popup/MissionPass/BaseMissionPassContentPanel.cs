using System;
using System.Collections;
using Underc.UI;
using UnityEngine;

namespace Underc.Popup
{
    public enum UpdateSpecificContentType
    {
        Point,
        Mission
    }

    public abstract class BaseMissionPassContentPanel : BaseContentPanel
    {
        public bool RunAsFake
        {
            protected get;
            set;
        }

        public virtual TabTransformInfo TabTransformInfo
        {
            set;
            protected get;
        }

        public virtual Vector2 PointGaugePosition
        {
            get;
        }

        public virtual RectTransform PointGaugeTransform
        {
            get;
        }

        public Action<string, MissionPassPopupTab> OnGoToSlot
        {
            protected get;
            set;
        }

        public Action<bool> OnInteractable
        {
            protected get;
            set;
        }

        public virtual IEnumerator UpdateProgressiveContent(UpdateSpecificContentType contentType)
        {
            yield break;
        }
    }
}