using UnityEngine;
using Gaga.Popup;
using Underc.User;
using System.Collections.Generic;
using Gaga.Attribute;

namespace Underc.Popup
{
    public sealed class MissionPassSeeMorePopup : PopupBackable
    {
        public enum TitleType
        {
            FreePass,
            MissionPass,
            MissionPassBenefit
        }

        [Separator("Title")]
        [SerializeField] private GameObject titleFreePass;
        [SerializeField] private GameObject titleMissionPass;
        [SerializeField] private GameObject titleMissionPassBenefit;

        [Separator("Items")]
        [SerializeField] private RectTransform rewardItemRoot;
        [SerializeField] private SimpleRewardItem freeRewardItemRef;
        [SerializeField] private SimpleRewardItem bonusRewardItemRef;

        private List<RewardInfo> clonedRewardInfos;

        protected override void Awake()
        {
            titleFreePass.SetActive(false);
            titleMissionPass.SetActive(false);
            titleMissionPassBenefit.SetActive(false);

            base.Awake();
        }

        public void Initialize(TitleType titleType, List<RewardInfo> rewardInfos)
        {
            SetupTitle(titleType);
            SetupItems(rewardInfos);
        }

        public override void Close()
        {
            for (int i = 0; i < clonedRewardInfos.Count; i++)
            {
                clonedRewardInfos[i].Release();
            }
            clonedRewardInfos.Clear();

            base.Close();
        }

        private void SetupTitle(TitleType titleType)
        {
            titleFreePass.SetActive(titleType == TitleType.FreePass);
            titleMissionPass.SetActive(titleType == TitleType.MissionPass);
            titleMissionPassBenefit.SetActive(titleType == TitleType.MissionPassBenefit);
        }

        private void SetupItems(List<RewardInfo> rewardInfos)
        {
            clonedRewardInfos = new List<RewardInfo>();

            for (int i = 0; i < rewardInfos.Count; i++)
            {
                clonedRewardInfos.Add(rewardInfos[i].Clone());
                
                var info = clonedRewardInfos[i];
                SimpleRewardItem rewardItemRef = info.skinIndex == 1 ? bonusRewardItemRef : freeRewardItemRef;

                var rewardItem = Instantiate(rewardItemRef.gameObject).GetComponent<SimpleRewardItem>();
                rewardItem.transform.SetParent(rewardItemRoot, false);

                rewardItem.UpdateContent(info.type, 
                                         info.value, 
                                         info.additionalValue, 
                                         vipClassType: MyInfo.VipClass.Type);
            }
        }
    }
}