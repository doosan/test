using Gaga.UI;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Popup
{
    public sealed class QuestClamItem : MonoBehaviour
    {
        #pragma warning disable 0649
        [SerializeField] private Text text;
        [SerializeField] private float textDuration = 0.6f;
        [SerializeField] private GameObject coinIcon;
        [SerializeField] private GameObject pearlIcon;
        [SerializeField] private GameObject ticketIcon;
        [SerializeField] private Animator animator;
        #pragma warning restore 0649

        public QuestClamPopup.CurrencyType CurrencyType{get; private set;}
        public long Value{get; private set;}

        public void Set(QuestClamPopup.CurrencyType currencyType, long value)
        {
            CurrencyType = currencyType;
            this.Value = value;

            coinIcon.SetActive(currencyType == QuestClamPopup.CurrencyType.Coin);
            pearlIcon.SetActive(currencyType == QuestClamPopup.CurrencyType.Pearl);
            ticketIcon.SetActive(currencyType == QuestClamPopup.CurrencyType.Ticket);

            text.SetNumber(0, true);
        }

        public void ClaimAnimation()
        {
            animator.SetTrigger("Claim");
        }

        private void OnEnable()
        {
            text.SetNumber(Value, true, textDuration);
        }
    }
}