using Gaga.Popup;
using Gaga.Util;
using TMPro;
using Underc;
using Underc.User;
using UnityEngine;

public class PurchaseFailPopup : PopupBackable
{
#pragma warning disable 0649
    [SerializeField] private TextMeshProUGUI purchaseInfoText;
#pragma warning restore 0649
    private string msgTransactionID;
    private string msgTotal;

    public void Initialize(string transactionID)
    {
        msgTransactionID = StringMaker.New()
                                      .Append("TRANSACTION ID: ")
                                      .Append(transactionID)
                                      .Build();

        msgTotal = StringMaker.New()
                              .Append("USER ID: ")
                              .Append(MyInfo.ID)
                              .Append(System.Environment.NewLine)
                              .Append(msgTransactionID)
                              .Build();
        purchaseInfoText.text = msgTotal;
    }

    public void Copy()
    {
        msgTotal.CopyToClipboard();
    }

    public void Email()
    {
        AppService.SendEmailToSupport(msgTransactionID);
    }
}
