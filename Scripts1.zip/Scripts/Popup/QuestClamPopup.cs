using UnityEngine;
using UnityEngine.UI;
using Gaga.Popup;
using Underc.Net;
using Underc.Net.Client;
using System.Collections;
using Underc.User;
using Underc.UI;
using Underc.Effect;
using System.Collections.Generic;
using System;
using Gaga.Util;
using static Underc.Popup.WarningPopup;

namespace Underc.Popup
{
    public sealed class QuestClamPopup : PopupBackable
    {
        public enum CollectType
        {
            Mission
        }

        public enum CurrencyType
        {
            Coin,
            Pearl,
            Ticket
        }

        [Serializable] 
        public class ItemInfo
        {
            public GameObject container;
            public QuestClamItem content;

            public void Reset()
            {
                container.SetActive(false);
                content.gameObject.SetActive(false);
            }
        }

        [Serializable] 
        public class MissionTitle
        {
            public MyQuestClam.MissionType missionType;
            public GameObject title;
        }

        #pragma warning disable 0649
        [SerializeField] private GameObject contentRoot;
        [SerializeField] private Button claimButton;
        [SerializeField] private float closeDelayTime = 1.0f;

        [Header("Mission")]
        [SerializeField] private GameObject missionView;
        [SerializeField] private Text missionText;
        [SerializeField] private MissionTitle[] missionTitles;

        [Header("Reward Items")]
        [SerializeField] private float itemDelayTime = 0.15f;

        [Header("Mission Items")]
        [SerializeField] private ItemInfo[] missionItems;

        #pragma warning restore 0649

        private List<ItemInfo> activeItemList;
        private long missionValue;
        private MyQuestClam.MissionType missionType;

        private ItemInfo[] currentItems;

        public void Initialize(MyQuestClam.MissionType missionType, long value = 0)
        {
            this.missionType = missionType;
            Initialize(CollectType.Mission, value);
        }

        private void Initialize(CollectType collectType, long value = 0)
        {
            activeItemList = new List<ItemInfo>();

            ResetItems();

            claimButton.interactable = false;

            if (collectType == CollectType.Mission)
            {
                currentItems = missionItems;
                missionValue = value;
                RequestCollectMission();
            }

            missionView.SetActive(collectType == CollectType.Mission);
        }

        private void RequestCollectMission()
        {
            contentRoot.SetActive(false);
            Popups.ShowLoading();

            NetworkSystem.HTTPRequester.CollectQuestClam(OnCollectMissionHandler);
        }

        private void OnCollectMissionHandler(QuestClamCollectResponse resp)
        {
            Popups.HideLoading();

            if (resp.isSuccess == false)
            {
                Popups.Warning(resp.error, ActionType.None, TitleType.Network).OnClose(() => Close());
                return;
            }

            bool isValid = resp.data.reward_coin > 0 || resp.data.reward_pearl > 0 || resp.data.reward_ticket > 0;
            
            if (isValid == true)
            {
                MyInfo.QuestClam.Update(resp.data);
                StartCoroutine(Show(CollectType.Mission, missionType, missionValue, 0,
                                    MyInfo.QuestClam.RewardCoin, MyInfo.QuestClam.RewardPearl, MyInfo.QuestClam.RewardTicket));
            }
            else
            {
                Close();
            }
        }

        private IEnumerator Show(CollectType collectType, MyQuestClam.MissionType missionType, long value, long timeCoin, long coin, long pearl, long ticket)
        {
            allowBackButton = false;

            contentRoot.SetActive(true);
            
            if (collectType == CollectType.Mission)
            {
                missionText.text = StringUtils.ToKMB(value);

                for (int i = 0; i < missionTitles.Length; i++)
                {
                    var missionTitle = missionTitles[i];
                    missionTitle.title.SetActive( missionTitle.missionType == missionType);
                }
            }

            yield return new WaitForSeconds(itemDelayTime);

            Debug.LogFormat("timecoin: {0} startCoin: {1} pearl: {2} ticket: {3}",timeCoin,coin,pearl,ticket);
            AddItem(CurrencyType.Coin, timeCoin);
            AddItem(CurrencyType.Coin, coin);
            AddItem(CurrencyType.Pearl, pearl);
            AddItem(CurrencyType.Ticket, ticket);

            for (int i = 0; i < activeItemList.Count; i++)
            {
                var item = activeItemList[i];
                item.container.SetActive(true);
            }

            for (int i = 0; i < activeItemList.Count; i++)
            {
                yield return new WaitForSeconds(itemDelayTime);
                var item = activeItemList[i];
                item.content.gameObject.SetActive(true);
            }

            claimButton.interactable = true;
        }

        public void Collect()
        {
            claimButton.interactable = false;
            claimButton.gameObject.SetActive(false);

            TopUI topUI = GameObject.FindObjectOfType<TopUI>();

            for (int i = 0; i < activeItemList.Count; i++)
            {
                var item = activeItemList[i];
                item.content.gameObject.SetActive(true);

                item.content.ClaimAnimation();

                if (topUI != null)
                {
                    Vector3 startPos = item.content.transform.position;
                    long value = item.content.Value;

                    if (item.content.CurrencyType == CurrencyType.Coin)
                    {
                        Vector2 endPos = topUI.GetCoinIconPosition();

                        EffectSystem.Instance.Coin(
                            startPosition: startPos
                            ,endPosition: endPos
                            ,scaleTarget: topUI.GetCoinIcon()
                            ,onFirstArrived: () => MyInfo.Coin += value
                            ,onArrived: topUI.CoinIconAnimation
                        );
                    }
                    else if (item.content.CurrencyType == CurrencyType.Pearl)
                    {
                        Vector2 endPos = topUI.GetPearlIconPosition();

                        EffectSystem.Instance.Pearl(
                            startPosition: startPos
                            ,endPosition: endPos
                            ,onFirstArrived: () => MyInfo.Pearl += value
                            ,onArrived: topUI.PearlIconAnimation
                        );
                    }
                    else if (item.content.CurrencyType == CurrencyType.Ticket)
                    {
                        Vector2 endPos = topUI.GetTicketIconPosition();

                        EffectSystem.Instance.Ticket(
                            startPosition: startPos
                            ,endPosition: endPos
                            ,scaleTarget: topUI.GetTicketIcon()
                            ,onFirstArrived: () => MyInfo.Ticket += value
                            ,onArrived: topUI.TicketIconAnimation
                        );
                    }
                }
            }

            Invoke("Close", closeDelayTime);
        }

        private void ResetItems()
        {
            activeItemList.Clear();

            for (int i = 0; i < missionItems.Length; i++)
            {
                missionItems[i].Reset();
            }
        } 
        
        private void AddItem(CurrencyType currencyType, long value)
        {
            if (value > 0)
            {
                int index = activeItemList.Count;

                if (index >= currentItems.Length)
                {
                    return;
                }

                Debug.LogFormat("AddItem. type: {0} value: {1}",currencyType, value);
                var item = currentItems[index];
                item.content.Set(currencyType, value);
                
                activeItemList.Add(item);
            }
        }

        public override bool CanBack()
        {
            return claimButton.interactable && base.CanBack();
        }

        public override void GoBack()
        {
            Collect();
        }
    }
}