﻿using Gaga.Popup;


namespace Underc.Popup
{
    public class ExitAppPopup : PopupBehaviour
    {
        public void Initialize(){}

        public void GoToFanPage()
        {
            UndercGameLog.Fobis.PopupBackButton(1);
            AppService.GoToFanpage();
        }

        public void GoToReview()
        {
            UndercGameLog.Fobis.PopupBackButton(2);
            AppService.OpenStore();
        }

        public void ExitApp()
        {
            UndercGameLog.Fobis.PopupBackButton(3);
            AppService.ExitApp();
        }

        public void OnCloseClick()
        {
            UndercGameLog.Fobis.PopupBackButton(4);
            Close();
        }
    }
}
