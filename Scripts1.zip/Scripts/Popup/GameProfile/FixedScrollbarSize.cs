using UnityEngine;
using UnityEngine.UI;

namespace Underc.Popup
{
    [ExecuteInEditMode]
    public class FixedScrollbarSize : MonoBehaviour
    {
#pragma warning disable 0649
        [SerializeField] private float fixedSize = 0.2f;
        [SerializeField] private Scrollbar scrollbar;
#pragma warning restore 0649

        private void Update()
        {
            if (scrollbar == null)
            {
                Debug.LogWarning("스크롤바가 지정되어 있지 않습니다.");
                return;
            }

            if (scrollbar.size != fixedSize)
            {
                scrollbar.size = fixedSize;
            }
        }
    }
}
