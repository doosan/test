using System;
using DG.Tweening;
using Gaga;
using Gaga.Sound;
using Underc.Net;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace Underc.Popup
{
    public class GameProfilePopupEditIconPageItem : MonoBehaviour, IPointerClickHandler
    {
        public int ItemIndex
        {
            get; private set;
        }
        public UserIconInfo Info
        {
            get; private set;  
        }
        public VisibleState DefaultVisibleState
        {
            get; private set;
        }

        #pragma warning disable 0649
        [SerializeField] private Image defaultImage;
        [SerializeField, FormerlySerializedAs("iconImage")] private Image pictureImage;
        [SerializeField] private GameObjectVisibleToggle visibleToggle;
        #pragma warning restore 0649
        private Action<int> onItemClick;

        public void Clear()
        {
            defaultImage.gameObject.SetActive(true);
            pictureImage.gameObject.SetActive(false);
            onItemClick = null;
        }

        public void Setup(int itemIndex, UserIconInfo info, Action<int> onItemClick)
        {
            ItemIndex = itemIndex;
            Info = info;
            this.onItemClick = onItemClick;

            if (string.IsNullOrEmpty(info.url) == false)
            {
                DownloadSystem.Instance.GetSprite(url: info.url, 
                                                  onComplete: SetPicture, 
                                                  useCache: true);
            }
            else
            {
                ProfileIconSystem.Instance.GetAsync(info.pic, SetPicture);
            }
        }

        public void SetDefaultVisibleState(VisibleState state)
        {
            DefaultVisibleState = state;

            SetVisibleState(state);
        }

        public void ResetToDefaultVisibleState()
        {
            SetVisibleState(DefaultVisibleState);
        }

        public void SetVisibleState(VisibleState state)
        {
            visibleToggle.TurnOnByNameInMultiple(state.ToString());
        }

        public void OnPointerClick(PointerEventData eventData)
        {
            if (onItemClick == null)
            {
                return;
            }

            onItemClick.Invoke(ItemIndex);
        }

        private void SetPicture(Sprite sprite)
        {
            if (sprite != null)
            {
                defaultImage.gameObject.SetActive(false);
                pictureImage.gameObject.SetActive(true);

                pictureImage.DOFade(1.0f, 0.3f);
                pictureImage.sprite = sprite;
                float fullScale = Mathf.Max(sprite.rect.width / sprite.rect.height,
                                            sprite.rect.height / sprite.rect.width);
                pictureImage.rectTransform.localScale = new Vector3(fullScale, fullScale, 1);
            }
            else
            {
                pictureImage.color = new Color(1, 1, 1, 0);
                pictureImage.sprite = null;
            }
        }

        public enum VisibleState
        {
            Choice, Now, Default
        }
    }

}