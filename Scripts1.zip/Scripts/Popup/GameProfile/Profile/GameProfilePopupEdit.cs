using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using Gaga;
using Gaga.System;
using Gaga.UI;
using Gaga.Util;
using Underc.User;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace Underc.Popup
{
    public class GameProfilePopupEdit : MonoBehaviour
    {
        public bool IsOpened
        {
            get => animator.IsStateName("Open") == true;
        }

        #pragma warning disable 0649
        [SerializeField] private Animator animator;
        [SerializeField] private InputField inputField;

        [Header("")]
        [SerializeField] private Button leftButton;
        [SerializeField] private Button rightButton;
        [SerializeField] private ListView listView;
        [SerializeField] private GameProfilePopupEditIconPage pageRef;
        [SerializeField, FormerlySerializedAs("indicatorRef")] private GameObjectVisibleToggle pageIndicatorRef;
        [SerializeField, FormerlySerializedAs("indicatorRoot")] private Transform pageIndicatorRoot;
        [SerializeField] private float pageMoveTime = 0.6f;

        [Header("Warning")]
        [SerializeField] private GameObject warningPanel;
        [SerializeField] private float warningDuration = 3f;
        #pragma warning restore 0649

        private List<GameProfilePopupEditIconPage> pages = new List<GameProfilePopupEditIconPage>();
        private List<GameObjectVisibleToggle> pageIndicators = new List<GameObjectVisibleToggle>();
        private GameObjectPool<GameProfilePopupEditIconPage> pagePool;
        private GameObjectPool<GameObjectVisibleToggle> pageIndicatorPool;

        private List<UserIconInfo> userIconInfos = new List<UserIconInfo>();
        private int selectedInfoIndex;

        private FacebookStateInfo fbInfo;
        private Action onSaved;
        private Action onClosed;
        private MyProfile myProfile;

        private void OnEnable()
        {
            leftButton.onClick.AddListener(GoToLeft);
            rightButton.onClick.AddListener(GoToRight);
        }

        private void OnDisable()
        {
            leftButton.onClick.RemoveListener(GoToLeft);
            rightButton.onClick.RemoveListener(GoToRight);
        }

        public void Open(FacebookStateInfo fbInfo, Action onSaved, Action onClosed)
        {
            this.fbInfo = fbInfo;
            this.onSaved = onSaved;
            this.onClosed = onClosed;
            myProfile = MyInfo.Profile;

            selectedInfoIndex = -1;

            listView.onTargetIndexChanged -= OnPageChanged;
            listView.onTargetIndexChanged += OnPageChanged;

            SetupPage();
            SetupPageIndicators();
            
            inputField.text = myProfile.Nick;
            inputField.onValidateInput -= OnValidateInput;
            inputField.onValidateInput += OnValidateInput;
            if (animator.IsStateName("Stay"))
            {
                animator.SetTriggerDistinct("Open");
            }
            warningPanel.SetActive(false);
        }

        private char OnValidateInput(string text, int charIndex, char addedChar)
        {
            if (char.IsPunctuation(addedChar)   // https://thedeveloperblog.com/char-ispunctuation
                || char.IsWhiteSpace(addedChar) // 공백
                || addedChar == '\ufffd'        // 이모지를 입력했을 때 대체되는 유니코드 (�)
                || IsEmoji(addedChar))          
            {
                return '\0';
            }
            return addedChar;
        }

        private bool IsEmoji(char addedChar)
        {
            // Filter out the Unicode categories you want (example below),
            // keep in mind that, while this can filter out Emojis,
            // it can also filter out chars you might want to keep (e.g. Asiatic languages, which I don't need to care about right now),
            // so this is not a perfect solution.
            bool result = false;
            var unicodeCategory = char.GetUnicodeCategory(addedChar);
            Debug.Log($"==== IsEmoji : {addedChar}, {unicodeCategory}");
            switch (unicodeCategory)
            {
                case UnicodeCategory.OtherSymbol:
                case UnicodeCategory.Surrogate:
                case UnicodeCategory.ModifierSymbol:
                case UnicodeCategory.NonSpacingMark:
                case UnicodeCategory.EnclosingMark:
                    // Refer to https://www.compart.com/en/unicode/ for a comprehensive list of Unicode categories and chars
                    // https://apps.timwhitlock.info/emoji/tables/unicode
                    result = true;
                    break;
            }

            return result;
        }

        public void Warning()
        {
            StartCoroutine(WarningCoroutine());
        }

        private IEnumerator WarningCoroutine()
        {
            warningPanel.SetActive(true);
            yield return new WaitForSeconds(warningDuration);
            warningPanel.SetActive(false);
        }
        
        public void Close()
        {
            listView.onTargetIndexChanged -= OnPageChanged;
            inputField.onValidateInput -= OnValidateInput;

            if (animator.IsStateName("Open"))
            {
                animator.SetTriggerDistinct("Close");   
            }

            if (onClosed != null)
            {
                onClosed.Invoke();
                onClosed = null;
            }
        }

        private void SetupPageIndicators()
        {
            if (pageIndicatorPool == null)
            {
                pageIndicatorPool = pageIndicatorRef.CreatePool<GameObjectVisibleToggle>(
                    rootName: "PageIndicatorPool",
                    parent: transform,
                    size: 2
                );
            }

            // Clear
            foreach (GameObjectVisibleToggle pageIndicator in pageIndicators)
            {
                pageIndicator.GetComponent<Button>().onClick.RemoveAllListeners();
                pageIndicatorPool.Return(pageIndicator);
            }
            pageIndicators.Clear();

            // Reset
            int pageCount = listView.GetCount();
            for (int i = 0; i < pageCount; i++)
            {
                int index = i;

                GameObjectVisibleToggle pageIndicator = pageIndicatorPool.Get();
                pageIndicator.transform.SetParent(pageIndicatorRoot.transform, false);
                pageIndicators.Add(pageIndicator);

                pageIndicator.GetComponent<Button>()
                             .onClick
                             .AddListener(() => GoToPage(index));
            }

            SetPageIndicator(0);
        }

        private void GoToLeft()
        {
            GoToPage(listView.TargetIndex - 1);
        }

        private void GoToRight()
        {
            GoToPage(listView.TargetIndex + 1);
        }

        private void SetupPage()
        {
            if (pagePool == null)
            {
                pagePool = pageRef.CreatePool<GameProfilePopupEditIconPage>(
                    rootName: "PagePool",
                    parent: listView.transform,
                    size: 2
                );
            }

            // Prepare data
            userIconInfos.Clear();

            if (fbInfo.isLoggedIn == true)
            {
                if (string.IsNullOrEmpty(MyInfo.Profile.PicUrl) == false)
                {
                    userIconInfos.Add(new UserIconInfo(url: MyInfo.Profile.PicUrl));
                }
                else if (string.IsNullOrEmpty(fbInfo.fbUser?.pic_url) == false)
                {
                    userIconInfos.Add(new UserIconInfo(url: fbInfo.fbUser?.pic_url));
                }
            }

            foreach (int picNum in ProfileIconSystem.Instance.AssetKeys)
            {
                userIconInfos.Add(new UserIconInfo(pic: picNum));
            }
            userIconInfos.Sort(Sort);

            // Clear
            foreach (GameProfilePopupEditIconPage page in pages)
            {
                pagePool.Return(page);
            }
            pages.Clear();
            listView.RemoveAllItems(false);

            // 
            int pageCount = (ProfileIconSystem.Instance.AssetCount / 10) + 1;
            while (pages.Count < pageCount)
            {
                GameProfilePopupEditIconPage page = pagePool.Get();
                page.Setup(pageIndex: pages.Count,
                           userIconInfos: userIconInfos, 
                           onInfoSelected: (int infoIndex) => selectedInfoIndex = infoIndex);
                pages.Add(page);

                listView.AddItem(page.GetComponent<RectTransform>());
            }
        }

        private int Sort(UserIconInfo a, UserIconInfo b)
        {
            if ((string.IsNullOrEmpty(a.url) == false && a.url == myProfile.PicUrl)
                || (a.pic != -1 && a.pic == myProfile.PicNum))
            {
                return -1;
            }
            else if ((string.IsNullOrEmpty(b.url) == false && b.url == myProfile.PicUrl)
                     || (b.pic != -1 && b.pic == myProfile.PicNum))
            {
                return 1;
            }

            if (string.IsNullOrEmpty(a.url) == false)
            {
                return -1;
            }
            else if (string.IsNullOrEmpty(b.url) == false)
            {
                return 1;
            }

            return a.pic.CompareTo(b.pic);
        }

        private void GoToPage(int index)
        {
            listView.GoTo(index, pageMoveTime);
        }

        private void OnPageChanged(int index)
        {
            SetPageIndicator(index);
        }

        private void SetPageIndicator(int index)
        {
            pages[index].Reset(selectedInfoIndex);
            
            for (int i = 0; i < pageIndicators.Count; i++)
            {
                GameObjectVisibleToggle indicator = pageIndicators[i];
                indicator.IsOn = index == i;
            }

            leftButton.gameObject.SetActive(index > 0);
            rightButton.gameObject.SetActive(index < pageIndicators.Count-1);
        }

        public void Edit()
        {
            UndercGameLog.Fobis.AccountNameEdit();
            inputField.ActivateInputField();
        }

        public void Save()
        {
            UndercGameLog.Fobis.AccountProfileSave();

            bool isInputEmpty = string.IsNullOrEmpty(inputField.text);

            // 바뀐 값이 하나도 없으면 리턴
            bool isNothingChanged = selectedInfoIndex == -1 
                                    && (isInputEmpty == true 
                                       || (isInputEmpty == false && myProfile.Nick == inputField.text));

            if (isNothingChanged == true)
            {
                Close();
                return;
            }

            // 하나라도 바뀐 값이 있으면 통과
            int newPic = myProfile.PicNum;
            string newUrl = myProfile.PicUrl;
            if (selectedInfoIndex != -1)
            {
                UserIconInfo selectedInfo = userIconInfos[selectedInfoIndex];
                newPic = selectedInfo.pic;
                newUrl = selectedInfo.url;
            }

            string newNick = myProfile.Nick;
            if (string.IsNullOrEmpty(inputField.text) == false)
            {
                newNick = inputField.text;
            }

            MyInfo.Profile.Save(newNick, newPic, newUrl);
            onSaved?.Invoke();
        }
    }

    public struct UserIconInfo
    {
        public string url;
        public int pic;

        public UserIconInfo(string url = "", int pic = -1)
        {
            this.url = url;
            this.pic = pic;
        }
    }
}
