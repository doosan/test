using Gaga.Sound;
using System;
using System.Collections.Generic;
using Underc.User;
using UnityEngine;

namespace Underc.Popup
{
    public class GameProfilePopupEditIconPage : MonoBehaviour
    {
        public int InfoOffset { get; private set; }
        
        #pragma warning disable 0649
        [SerializeField] private List<GameProfilePopupEditIconPageItem> items;
        [SerializeField] private SoundPlayer clickSound;
        #pragma warning restore 0649
        private Action<int> onInfoSelected;

        public void Setup(int pageIndex, List<UserIconInfo> userIconInfos, Action<int> onInfoSelected)
        {
            this.onInfoSelected = onInfoSelected;
            InfoOffset = pageIndex * items.Count;
            
            MyProfile myProfile = MyInfo.Profile;
            
            for (int i = 0; i < items.Count; i++)
            { 
                GameProfilePopupEditIconPageItem item = items[i];
                item.Clear();
                item.SetDefaultVisibleState(GameProfilePopupEditIconPageItem.VisibleState.Default);

                int infoIndex = i + InfoOffset;
                if (infoIndex < userIconInfos.Count)
                {
                    UserIconInfo info = userIconInfos[infoIndex];
                    item.Setup(i, 
                               info, 
                               (int itemIndex) =>
                               {
                                   clickSound.Play();
                                   OnItemClick(itemIndex);
                               });
                    if ((info.pic != -1 && info.pic == myProfile.PicNum) || 
                        (string.IsNullOrEmpty(info.url) == false && myProfile.PicUrl == info.url))
                    {
                        item.SetDefaultVisibleState(GameProfilePopupEditIconPageItem.VisibleState.Now);
                    }
                }
            }
        }

        public void Reset(int infoIndex)
        {
            OnItemClick(itemIndex: infoIndex - InfoOffset);
        }

        private void OnItemClick(int itemIndex)
        {
            onInfoSelected.Invoke(InfoOffset + itemIndex);

            for (int i = 0; i < items.Count; i++)
            {
                GameProfilePopupEditIconPageItem item = items[i];
                if (i == itemIndex)
                {
                    item.SetVisibleState(GameProfilePopupEditIconPageItem.VisibleState.Choice);
                }
                else
                {
                    item.ResetToDefaultVisibleState();
                }
            }
        }
    }
}