using Gaga.Popup;
using Gaga.UI;
using Gaga.Util;
using System;
using System.Collections;
using TMPro;
using Underc.UI;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Popup
{
    public class GameProfilePopupCommonProfile : BaseGameProfilePopupLayer
    {
        [SerializeField] private Text nickText;
        [SerializeField] private Text fbNameText;

        [SerializeField] private GameProfilePopupEdit edit;

        [SerializeField] private TextMeshProUGUI coinText;
        [SerializeField] private TextMeshProUGUI pearlText;
        [SerializeField] private TextMeshProUGUI ticketText;

        [SerializeField] private ProfileImage profileImage;

        public Action OnShopClosed;

        public Action OnEditSaved;
        public GameProfilePopupEdit EditView
        {
            get => edit;
        }
        
        private FacebookStateInfo facebookStateInfo;

        public override void ResetOnce()
        {
            nickText.text = "";
            fbNameText.text = "";

            profileImage.ResetOnce();
        }

        public override void Reset()
        {
            coinText.text = "";
            pearlText.text = "";
            ticketText.text = "";

            edit.Close();
        }

        public override IEnumerator UpdateContent()
        {
            facebookStateInfo = MyInfo.Profile.FacebookStateInfo;

            Debug.Log("==== GameSettingPopupCommonProfile");
            profileImage.UpdateImage();
            UpdateNick();
            UpdateFacebookInfo();
            UpdateMoney();
            yield break;
        }

        private void UpdateNick()
        {
            nickText.text = Profile.Nick;
        }

        public void Shop()
        {
            Popups.Shop()
                  .Async()
                  .Cache()
                  .OnClose(OnShopClosed);
        }

        public void Edit()
        {
            UndercGameLog.Fobis.AccountProfileEdit();

            edit.Open(fbInfo: facebookStateInfo, 
                      onSaved: OnEditSaved, 
                      onClosed: () =>
                      {
                          UpdateNick();
                          profileImage.UpdateImage();
                      });
        }

        private void UpdateFacebookInfo()
        {
            if (facebookStateInfo.isLoggedIn == true)
            {
                fbNameText.text = facebookStateInfo.fbUser?.name;
            }
            else
            {
                fbNameText.text = "Not yet connected";
            }
        }

        private void UpdateMoney()
        {
            coinText.SetNumber(MyInfo.Coin, true);
            pearlText.SetNumber(MyInfo.Pearl, true);
            ticketText.SetNumber(MyInfo.Ticket, true);
        }
    }
}
