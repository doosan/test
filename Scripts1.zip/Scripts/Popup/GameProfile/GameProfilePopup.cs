using System.Collections;
using System.Collections.Generic;
using Gaga;
using Gaga.Popup;
using Underc.Net;
using UnityEngine;
using UnityEngine.UI;
using Underc.User;
using Gaga.System;
using Underc.Platform;

namespace Underc.Popup
{
    public enum GameProfilePopupState
    {
        None, 
        LoadProfile, 
        UpdateContent,
        TogglePlatformLogin,
        UpdateFacebook, 
        SaveProfile,
        Release
    }

    public struct NewProfileInfo
    {
        public string nick;
        public int picNum;
        public string picUrl;

        public NewProfileInfo(string nick, int picNum, string picUrl)
        {
            this.nick = nick;
            this.picNum = picNum;
            this.picUrl = picUrl;
        }
    }

    public sealed class GameProfilePopup : PopupBackable
    {
#pragma warning disable 0649
        [SerializeField] private List<Toggle> tabToggles;
        [SerializeField] private List<GameObjectVisibleToggle> tabVisibleToggles;
        [SerializeField] private GameObjectVisibleToggle layerVisibleToggle;

        [SerializeField] private GameProfilePopupCommonProfile commonProfile;
        [SerializeField] private GameProfilePopupProfile profile;
        [SerializeField] private GameProfilePopupRecord record;
        [SerializeField] private GameProfilePopupInbox inbox;
#pragma warning restore 0649

        public bool RunAsFake
        {
            set
            {
                foreach (BaseGameProfilePopupLayer layer in layers)
                {
                    layer.RunAsFake = value;
                }
                runAsFake = value;
            }
            private get
            {
                return runAsFake;
            }
        }
        private bool runAsFake;

        private bool initOnce;
        private bool loadOnce;

        private int tabIndex;
        private StateQueue<GameProfilePopupState> stateQueue;
        private List<BaseGameProfilePopupLayer> layers;

        protected override void OnEnable()
        {
            base.OnEnable();

            Init();
            ResetOnce();
            UpdateTab();
        }

        public void Init()
        {
            if (initOnce == false)
            {
                initOnce = true;

                stateQueue = new StateQueue<GameProfilePopupState>(host: this);
                layers = new List<BaseGameProfilePopupLayer>()
                {
                    profile, record, inbox
                };
                foreach (BaseGameProfilePopupLayer layer in layers)
                {
                    layer.Init();
                    layer.RootTransform = transform;
                }

                // Tab
                for (int i = 0; i < tabToggles.Count; i++)
                {
                    int toggleIndex = i;
                    tabToggles[i].onValueChanged.AddListener((bool value) =>
                    {
                        if (value == true
                            && tabIndex != toggleIndex)
                        {
                            tabIndex = toggleIndex;

                            UpdateTab();
                            UpdateContent();
                        }
                    });
                }

                commonProfile.OnEditSaved = () => stateQueue.Add(GameProfilePopupState.SaveProfile);
                commonProfile.OnShopClosed = () => stateQueue.Add(GameProfilePopupState.UpdateContent);
                profile.OnFacebookLoginToggled = (bool isOn) =>
                {
                    stateQueue.Add(GameProfilePopupState.TogglePlatformLogin, new TogglePlatformInfo(PlatformLoginType.Facebook, isOn));
                    stateQueue.Add(GameProfilePopupState.UpdateContent);
                };
                inbox.OnError = OpenErrorPopup;
            }
        }

        private void ResetOnce()
        {
            commonProfile.ResetOnce();
            commonProfile.Reset();
            foreach (BaseGameProfilePopupLayer layer in layers)
            {
                layer.ResetOnce();
                layer.Reset();
            }

            loadOnce = false;
        }

        public void Open(int tabIndex)
        {
            if (tabIndex != -1)
            {
                this.tabIndex = tabIndex;
            }

            UpdateTab();

            stateQueue.Reset();
            if (RunAsFake == false)
            { 
                stateQueue.Add(GameProfilePopupState.LoadProfile);
            }

            UpdateContent();
        }

        private void UpdateContent()
        {
            if (loadOnce == false)
            {
                loadOnce = true;

                //
                if (commonProfile.gameObject.activeSelf)
                {
                    stateQueue.Add(GameProfilePopupState.UpdateFacebook);
                }
            }

            stateQueue.Add(GameProfilePopupState.UpdateContent);
        }

        private IEnumerator TogglePlatformLoginCoroutine(object param)
        {
            yield return PlatformLoginSystem.Instance.TogglePlatformLogin((TogglePlatformInfo)param);
        }

        private IEnumerator UpdateFacebookCoroutine()
        {
            yield return PlatformLoginSystem.Instance.UpdateFacebook();
        }

        private IEnumerator LoadProfileCoroutine()
        {
            Popups.ShowLoading();
            var req = NetworkSystem.HTTPRequester.Profile();
            yield return req.WaitForResponse();
            Popups.HideLoading();

            if (req.isSuccess)
            {
                NetworkSystem.HTTPHandler.Do(req.data);
            }
            else
            {
                OpenErrorPopup(req.data.error);
            }
        }

        private void OpenErrorPopup(string message)
        {
            stateQueue.Reset();
            Popups.Error(message)
                  .Async()
                  .OnClose(Close);
        }

        private void UpdateTab()
        {
            foreach (GameObjectVisibleToggle tabVisibleToggle in tabVisibleToggles)
            {
                tabVisibleToggle.IsOn = false;
            }
            tabVisibleToggles[tabIndex].IsOn = true;

            foreach (BaseGameProfilePopupLayer layer in layers)
            {
                layer.Reset();
                layer.gameObject.SetActive(false);
            }
            BaseGameProfilePopupLayer currentLayer = layers[tabIndex];
            currentLayer.gameObject.SetActive(true);

            //
            bool commonProfileVisible = currentLayer is GameProfilePopupProfile
                                        || currentLayer is GameProfilePopupRecord;
            commonProfile.gameObject.SetActive(commonProfileVisible);
        }

        private IEnumerator SaveProfileCoroutine()
        {
            var myProfile = MyInfo.Profile;
            string newNick = myProfile.NickInSave;
            int newPicNum = myProfile.PicNumInSave;
            string newPicUrl = myProfile.PicUrlInSave;

            Popups.ShowLoading();
            var req = NetworkSystem.HTTPRequester.ProfileSet(newNick, newPicNum, newPicUrl);
            yield return req.WaitForResponse();
            Popups.HideLoading();

            if (req.isSuccess)
            {
                myProfile.Update(newNick, newPicNum, newPicUrl);
                commonProfile.EditView.Close();
            }
            else
            {
                if (req.data.error == "reject")
                {
                    commonProfile.EditView.Warning();
                }
                else
                {
                    Popups.Error(req.data.error)
                          .Async();
                }
            }
        }

        private IEnumerator UpdateContentCoroutine()
        {
            if (commonProfile.gameObject.activeSelf)
            {
                commonProfile.Reset();
                yield return commonProfile.UpdateContent();
            }

            BaseGameProfilePopupLayer contentLayer = layers[tabIndex];
            contentLayer.Reset();
            yield return contentLayer.UpdateContent();
        }

        private IEnumerator ReleaseCoroutine()
        {
            if (commonProfile.gameObject.activeSelf)
            {
                yield return commonProfile.Unload();
            }
            foreach (BaseGameProfilePopupLayer layer in layers)
            {
                yield return layer.Unload();
            }

            base.Close();
        }

        public override bool CanBack()
        {
            bool result = Popups.IsLoading() == false;
            foreach (BaseGameProfilePopupLayer layer in layers)
            {
                if (layer.gameObject.activeInHierarchy)
                {
                    result &= layer.CanBack(); // 모두 통과되어야 함
                }
            }

            return result;
        }

        public override void GoBack()
        {
            base.GoBack();
        }

        public override void Close()
        {
            if (commonProfile.EditView.IsOpened)
            {
                commonProfile.EditView.Close();
            }
            else
            {
                stateQueue.Add(GameProfilePopupState.Release);
            }
        }
    }
}