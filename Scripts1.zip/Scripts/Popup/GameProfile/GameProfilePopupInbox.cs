using Gaga.UI;
using Gaga.Util;
using System;
using System.Collections;
using System.Collections.Generic;
using Underc.Auth;
using Underc.Effect;
using Underc.Net;
using Underc.Platform;
using Underc.UI;
using Underc.User;
using UnityEngine;

namespace Underc.Popup
{
    public class WaitForInboxFB : CustomYield.Generic<WaitForInboxFB>
    {
        public FBUser Me { get; private set; }
        public AccountSystem.PlatformConnectionResult FBResult { get; private set; }

        public void Done(FBUser me)
        {
            Me = me;
            if (Me == null) Fail("FBUser null");
            else Done();
        }

        public void Done(AccountSystem.PlatformConnectionResult rest)
        {
            FBResult = rest;
            switch (FBResult)
            {
                case AccountSystem.PlatformConnectionResult.AlreadyConnected:
                case AccountSystem.PlatformConnectionResult.Success:
                    Done();
                    break;

                case AccountSystem.PlatformConnectionResult.Failed:
                    Fail();
                    break;

                case AccountSystem.PlatformConnectionResult.SuccessAndRestart:
                case AccountSystem.PlatformConnectionResult.FailedAndRestart:
                case AccountSystem.PlatformConnectionResult.Canceled:
                    Cancel();
                    break;

                default:
                    Fail();
                    break;
            }
        }
    }

    public class GameProfilePopupInbox : BaseGameProfilePopupLayer, IRecyclingItemProvider
    {
        private readonly string DELETE_WARNING_COLLECT = "Are you sure to delete\nCollectible BONUS?";
        private readonly string DELETE_WARNING_SEND = "It is easier to ‘SEND’ than delete.\nOf course, your friends and family\nWill love it, definitely!";

        [Header("InboxIsEmpty")]
        [SerializeField] private GameObject inboxIsEmpty = null;

        [Header("List")]
        [SerializeField] private RecyclerListView itemListView = null;
        [SerializeField] private InboxPopupItem itemReference = null;

        public Action<string> OnError
        {
            private get;
            set;
        }

        private bool dirtyStorySync;

        private TopUI topUI;
        private Dictionary<RectTransform, InboxPopupItem> cacheItems;
        private List<InboxItemData> itemList;

        public override void Init()
        {
            cacheItems = new Dictionary<RectTransform, InboxPopupItem>();
            itemList = new List<InboxItemData>();

            inboxIsEmpty.SetActive(false);
        }

        public override void ResetOnce()
        {
            dirtyStorySync = false;
        }

        public override void Reset()
        {
            ReturnTopUI();
        }

        private void OnDisable()
        {
            Clear();
        }

        public override IEnumerator UpdateContent()
        {
            SetupTopUI();
            yield return null;
            topUI.Show(true);

            Popups.ShowLoading();
            var req = NetworkSystem.HTTPRequester.Inbox();
            yield return req.WaitForResponse();
            Popups.HideLoading();

            InboxItemData[] inboxData = null;
            if (req.isSuccess == true)
            {
                inboxData = req.data.data;
                Debug.LogFormat("server inboxData\n{0}", inboxData.ToEachString(",\n"));
                if (RunAsFake)
                {
                    inboxData = InboxDataDummyCreator.AddDummyItems(inboxData);
                }
            }

            if (inboxData != null)
            {
                UpdateListView(inboxData);
            }
            else
            {
                OnError?.Invoke(req.data.error);
            }
        }

        public override IEnumerator Unload()
        {
            ReturnTopUI();
            MyInfo.Alarms.UpdateInbox(GetCollectableItemCounts());

            if (dirtyStorySync == true)
            {
                dirtyStorySync = false;

                Popups.ShowLoading(false);

                var seaStoryReq = NetworkSystem.HTTPRequester.SeaStory(MyInfo.Ocean.CurrentSeaID);
                yield return seaStoryReq.WaitForResponse();

                if (seaStoryReq.isSuccess)
                {
                    NetworkSystem.HTTPHandler.Do(seaStoryReq.data);
                }

                Popups.HideLoading();
            }

            yield break;
        }

        private void UpdateListView(InboxItemData[] inboxData)
        {
            if (inboxData == null)
            {
                return;
            }

            CreateItemList(inboxData);

            if (IsItemEmpty())
            {
                DisplayEmpty();
            }
            else
            {
                DisplayItemListView();
            }
        }

        private void CreateItemList(InboxItemData[] inboxData)
        {
            itemList.Clear();

            for (int i = 0; i < inboxData.Length; ++i)
            {
                InboxItemData item = inboxData[i];

                if (Enum.IsDefined(typeof(InboxItemType), item.type) == false)
                {
                    continue;
                }

                InboxItemType itemType = (InboxItemType)item.type;
                if (itemType == InboxItemType.None)
                {
                    continue;
                }

                if (itemType == InboxItemType.FacebookLogin && AccountSystem.IsFacebookConnected)
                {
                    continue;
                }

                itemList.Add(item);
            }
        }

        private bool IsItemEmpty()
        {
            return GetItemsCount() == 0;
        }

        private void Clear()
        {
            itemList.Clear();
            inboxIsEmpty.SetActive(false);
        }

        private void SetupTopUI()
        {
            if (topUI == null)
            {
                topUI = TopUISystem.Instance.Get(RootTransform);
                topUI.Use(TopUiItem.Coin);
                topUI.Reset();
                topUI.Hide(false);
            }
        }

        private void ReturnTopUI()
        {
            if (topUI != null)
            {
                TopUISystem.Instance.Return(topUI);
                topUI = null;
            }
        }

        private void DisplayEmpty()
        {
            inboxIsEmpty.SetActive(true);

            itemListView.Stop();
            itemListView.gameObject.SetActive(false);
        }

        private void DisplayItemListView()
        {
            itemListView.gameObject.SetActive(true);
            itemListView.ItemProvider = this;
            itemListView.ReactivateAllItems();

            int startIndex = 0;
            itemListView.GoTo(startIndex, 0.0f);
        }

        public void GoToFanpage()
        {
            AppService.GoToFanpage();
        }

        private int GetCollectableItemCounts()
        {
            if (itemList == null)
            {
                return 0;
            }

            int count = 0;
            for (int i = 0; i < itemList.Count; ++i)
            {
                var data = itemList[i];
                InboxItemType itemType = (InboxItemType)data.type;
                if (InboxItemData.IsCollectableItem(itemType))
                {
                    ++count;
                }
            }

            return count;
        }

        private void OnExecuteItem(InboxPopupItem item)
        {
            if (item.ItemType == InboxItemType.FacebookLogin)
            {
                StartCoroutine(FBLoginAndCollect(item));
            }
            else if (item.ItemType == InboxItemType.InviteFriends)
            {
                StartCoroutine(Invite(item));
            }
            else if (InboxItemData.IsCollectableItem(item.ItemType))
            {
                StartCoroutine(CollectReward(item));
            }
            else
            {
                StartCoroutine(Send(item));
            }

            bool sendGameLog = true;
            int gameLogType = 0;

            if (item.ItemType == InboxItemType.FacebookLogin)
            {
                gameLogType = 2;
            }
            else if (item.ItemType == InboxItemType.SendGift1Week)
            {
                gameLogType = 3;
            }
            else if (item.ItemType == InboxItemType.SendGift2Week)
            {
                gameLogType = 4;
            }
            else if (item.ItemType == InboxItemType.InviteFriends)
            {
                gameLogType = 5;
            }
            else
            {
                sendGameLog = false;
            }

            if (sendGameLog)
            {
                UndercGameLog.Fobis.ButtonInbox(gameLogType);
            }
        }

        private IEnumerator FBLoginAndCollect(InboxPopupItem item)
        {
            Debug.LogFormat("FBLogin And Collect Item: {0}", item.Data.id);

            itemListView.enabled = false;
            item.SetInteraction(false);
            yield return item.PlayAnim();
            itemListView.enabled = true;

            Popups.ShowLoading();

            var waitfb = ConnectToFaceBook();
            yield return waitfb;

            Debug.LogFormat("FBConnect Complete. result: {0}", waitfb.FBResult);

            if (FBIsLogin() == false)
            {
                Debug.Log("FBLogin Fail or canceled");
                item.SetInteraction(true);
                Popups.HideLoading();
                yield break;
            }

            var req = NetworkSystem.HTTPRequester.Inbox();
            yield return req.WaitForResponse();

            Popups.HideLoading();

            if (req.isSuccess == false)
            {
                yield return DeleteItem(item, false);
                yield break;
            }

            UpdateListView(req.data.data);
            yield break;
        }

        private IEnumerator CollectReward(InboxPopupItem item)
        {
            Debug.LogFormat("Collect Item: {0}", item.Data.id);

            bool isMystery = item.RewardType == RewardData.RANDOM;

            itemListView.enabled = false;
            item.SetInteraction(false);
            yield return item.PlayAnim();
            itemListView.enabled = true;

            Popups.ShowLoading();
            InboxItemRewardData rewardData = null;
            var req = NetworkSystem.HTTPRequester.InboxClaim(item.Data.id);
            yield return req.WaitForResponse();
            Popups.HideLoading();

            if (req.isSuccess == true)
            {
                rewardData = req.data.data;
            }
            else
            {
                if (RunAsFake == true
                    && item.Data.id == 0)
                {
                    Debug.LogWarningFormat("DummyItem Claim. error: {0}", req.data.error);
                    rewardData = InboxDataDummyCreator.CreateDummyReward(item.Data.rwd, item.Data.val);
                }
            }

            if (rewardData == null)
            {
                item.SetInteraction(true);
                OnError?.Invoke(req.data.error);
                yield break;
            }

            Debug.LogFormat("reward type: rwd: {0} value: {1}", rewardData.rwd, rewardData.val);
            dirtyStorySync = rewardData.rwd == RewardData.FISH;
            if (isMystery == true)
            {
                yield return Popups.RewardView(rewardData.rwd, rewardData.val, RewardViewPopup.OpenType.MysteryBox).WaitForClose();
            }
            else if (item.ItemType == InboxItemType.OceanPassReward || rewardData.rwd != RewardData.COIN)
            {
                yield return Popups.RewardView(rewardData.rwd, rewardData.val).WaitForClose();
            }
            else
            {
                var startPos = item.GetRewardStartPos();
                var endPos = topUI.GetCoinIconPosition();
                EffectSystem.Instance.Coin(
                    5, 
                    startPos, 
                    endPos, 
                    topUI.GetCoinIcon(),
                    null, 
                    null,
                    () => MyInfo.Coin += rewardData.val, 
                    () => topUI?.CoinIconAnimation()
                );
            }

            yield return DeleteItem(item, false);

            if (MyInfo.VipClass.ConsumeLevelUp())
            {
                yield return Popups.VipLevelUpCoroutine(RunAsFake);
            }
        }

        private WaitForInboxFB GetMe()
        {
            var wait = new WaitForInboxFB();
            FacebookLogin.Instance.GetMe((user) =>
            {
                wait.Done(user);
            });

            return wait;
        }

        private WaitForInboxFB ConnectToFaceBook()
        {
            var wait = new WaitForInboxFB();
            AccountSystem.ConnectToFacebook(result =>
            {
                wait.Done(result);
            });

            return wait;
        }

        private void CollectError(string message)
        {
            Debug.Log(message);
            Popups.Warning(message,
                           WarningPopup.ActionType.None,
                           WarningPopup.TitleType.Network);
        }

        private IEnumerator Invite(InboxPopupItem item)
        {
            Debug.LogFormat("Send Item: {0}", item.Data.id);

            itemListView.enabled = false;
            item.SetInteraction(false);
            yield return item.PlayAnim();
            itemListView.enabled = true;

            Popups.ShowLoading();

            WaitForInboxFB waitGetMe = GetMe();
            yield return waitGetMe;

            //유저가 페이스북 연동을 풀었다면 다시 페이스북 로그인을 해서 유저 정보를 가져오자
            if (waitGetMe.Me == null)
            {
                WaitForInboxFB waitLogin = ConnectToFaceBook();
                yield return waitLogin;

                if (waitLogin.IsCancelled)
                {
                    //로그인을 취소했거나, 성공 혹은 실패를 통해 인트로 씬으로 돌아가는 경우
                    Popups.HideLoading();
                    item.SetInteraction(true);
                    yield break;
                }
                else if (waitLogin.HasError)
                {
                    //페북 로그인이 실패 한경우
                    CollectError("facebook login failed.");
                    Popups.HideLoading();
                    item.SetInteraction(true);
                    yield break;
                }
                else
                {
                    waitGetMe = GetMe();
                    yield return waitGetMe;
                }
            }

            //send fb request
            var title = "Invite your friends and enjoy together.";
            var message = string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0} has invited you to Aquuua Casino, an innovative casino game, you’ve never seen before.", waitGetMe.Me.name);
            object[] filter = new object[] { "app_non_users" };
            var data = FacebookLogin.REQUEST_DATA_INVITE;

            Facebook.Unity.IAppRequestResult reqResult = null;
            bool waitForReq = true;
            FacebookLogin.Instance.SendAppInvite(title, message, filter, data, (res) =>
            {
                reqResult = res;
                waitForReq = false;
            });

            yield return new WaitWhile(() => waitForReq);

            if (reqResult == null)
            {
                CollectError("SendAppInvite failed. fb not yet initialized");
                Popups.HideLoading();
                item.SetInteraction(true);
                yield break;
            }

            if (reqResult.Cancelled == true)
            {
                Popups.HideLoading();
                item.SetInteraction(true);
                yield break;
            }

            if (string.IsNullOrEmpty(reqResult.Error) == false)
            {
                Popups.HideLoading();
                item.SetInteraction(true);
                OnError?.Invoke(string.Format(System.Globalization.CultureInfo.InvariantCulture, "SendAppInvite error: {0}", reqResult.Error));
                yield break;
            }

            Debug.LogFormat("SendAppInvite Complete. {0}", reqResult.RawResult);

            if (string.IsNullOrEmpty(reqResult.RequestID))
            {
                // CollectError("requestid null");
                Popups.HideLoading();
                item.SetInteraction(true);
                yield break;
            }

            var req = NetworkSystem.HTTPRequester.FBInvite(reqResult.RequestID);
            yield return req.WaitForResponse();

            if (req.isSuccess == false)
            {
                CollectError(req.data.error);

                Popups.HideLoading();
                item.SetInteraction(true);
                OnError?.Invoke(req.data.error);
                yield break;
            }

            item.Sent();
            //기획서에 따라 sent 로 표시 한 뒤 1초 후에 사라지게 한다
            yield return new WaitForSeconds(1f);
            Popups.HideLoading();
            yield return DeleteItem(item, true);

            yield break;
        }

        private IEnumerator Send(InboxPopupItem item)
        {
            Debug.LogFormat("Send Item: {0}", item.Data.id);

            itemListView.enabled = false;
            item.SetInteraction(false);
            yield return item.PlayAnim();
            itemListView.enabled = true;

            Popups.ShowLoading();

            var req = NetworkSystem.HTTPRequester.InboxSend(item.Data.id);
            yield return req.WaitForResponse();

            if (req.isSuccess == false)
            {
                Popups.HideLoading();
                item.SetInteraction(true);
                OnError?.Invoke(req.data.error);
                yield break;
            }

            item.Sent();
            //기획서에 따라 sent 로 표시 한 뒤 1초 후에 사라지게 한다
            yield return new WaitForSeconds(1f);
            Popups.HideLoading();
            yield return DeleteItem(item, true);

            yield break;
        }

        private void OnDeleteItem(InboxPopupItem item)
        {
            var warningMesssage = GetDelWarningMessage(item.ItemType);
            if (string.IsNullOrEmpty(warningMesssage) == true)
            {
                StartCoroutine(DeleteItem(item, true));
            }
            else
            {
                Popups.WarningConfirm(message: warningMesssage, titleMessage: string.Empty, useCloseButton: false, onOK: () =>
                {
                    StartCoroutine(DeleteItem(item, true));
                });
            }
        }

        private string GetDelWarningMessage(InboxItemType itemType)
        {
            if (InboxItemData.IsCollectableItem(itemType))
            {
                return DELETE_WARNING_COLLECT;
            }
            else if (InboxItemData.IsSendableItem(itemType))
            {
                return DELETE_WARNING_SEND;
            }
            else
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// 인박스 리스트뷰에서 아이템을 삭제한다. 서버에게 삭제 요청을 할지 말지 정할 수 있다
        /// 콜렉트의 경우 서버에서 자동으로 삭제되므로 리스트뷰에서만 삭제. Send 의 경우 클라에서 직접 삭제 요청을 해야한다
        /// </summary>
        private IEnumerator DeleteItem(InboxPopupItem item, bool reqToServer)
        {
            if (reqToServer == true)
            {
                NetworkSystem.HTTPRequester.InboxDelete(item.Data.id);
            }

            yield return item.Hide();
            itemListView.RemoveItem(item.ItemIndex);

            if (IsItemEmpty())
            {
                DisplayEmpty();
            }

            yield break;
        }

        private bool FBIsLogin()
        {
            return AccountSystem.IsFacebookConnected;
        }

#region IRecyclingItemProvider
        public int GetItemsCount()
        {
            if (itemList == null)
            {
                return 0;
            }
            else
            {
                return itemList.Count;
            }
        }

        public void RemoveItem(int index)
        {
            itemList.RemoveAt(index);
        }

        public RectTransform CreateItem()
        {
            var rectItem = Instantiate(itemReference.gameObject).GetComponent<RectTransform>();
            var inboxItem = rectItem.GetComponent<InboxPopupItem>();
            inboxItem.Init();
            inboxItem.OnExecute += OnExecuteItem;
            inboxItem.OnDelete += OnDeleteItem;
            cacheItems.Add(rectItem, inboxItem);
            return rectItem;
        }

        public RecyclerListView.InitializationItemInfo OnItemInitialize(int index, RectTransform item)
        {
            return new RecyclerListView.InitializationItemInfo(item);
        }

        public void OnItemEnable(int index, RectTransform item)
        {
            InboxPopupItem inboxItem = null;
            if (cacheItems.ContainsKey(item) == false)
            {
                inboxItem = item.GetComponent<InboxPopupItem>();
                cacheItems.Add(item, inboxItem);
            }
            else
            {
                inboxItem = cacheItems[item];
            }

            InboxItemData data = itemList[index];
            inboxItem.ItemIndex = index;
            inboxItem.SetUp(data, MyInfo.VipClass.Type);
        }

        public void OnItemDisable(int index, RectTransform item)
        {
        }

#endregion

#if GGDEV
        public void Test(int index)
        {
            if (index == 1)
            {
                Popups.RewardView(RewardData.COIN, 100);
            }
            else if (index == 2)
            {
                Popups.RewardView(RewardData.PEARL, 1, RewardViewPopup.OpenType.MysteryBox);
            }
            else if (index == 3)
            {
                long[] randomFishIds = new long[] { 5, 4, 20, 29, 39, 53, 7, 10, 24, 34, 41, 65, 18 };
                long fishid = randomFishIds[UnityEngine.Random.Range(0, randomFishIds.Length)];
                Popups.RewardView(RewardData.FISH, fishid);
            }
            else if (index == 4)
            {
                long[] randomFishIds = new long[] { 5, 4, 20, 29, 39, 53, 7, 10, 24, 34, 41, 65, 18 };
                long fishid = randomFishIds[UnityEngine.Random.Range(0, randomFishIds.Length)];
                Popups.RewardView(RewardData.FISH, fishid, RewardViewPopup.OpenType.GoldenChest);
            }
            else if (index == 5)
            {
                // long[] randomFishIds = new long[] { 5, 4, 20, 29, 39, 53, 7, 10, 24, 34, 41, 65, 18 };
                long[] randomFishIds = new long[] { 5, 4, 20, 29, 39, 53, 100, 130, 131, 132, 134 };
                long fishid = randomFishIds[UnityEngine.Random.Range(0, randomFishIds.Length)];

                var rewardData = new RewardData() { typeStr = RewardData.GOLDEN, value = 20 };
                Popups.RewardView(rewardData: rewardData, openType: RewardViewPopup.OpenType.ObsidianChest);
            }
            else if (index == 6)
            {
                long[] randomFishIds = new long[] { 5, 4, 20, 29, 39, 53, 7, 10, 24, 34, 41, 65, 18 };
                long fishid = randomFishIds[UnityEngine.Random.Range(0, randomFishIds.Length)];

                var rewardData = new RewardData() { typeStr = RewardData.FISH, value = fishid, additionalCoin = 0L };
                Popups.RewardView(rewardData: rewardData, openType: RewardViewPopup.OpenType.ObsidianChest);
            }
            else if (index == 7)
            {
                RewardData[] rewardDatas = new RewardData[]
                {
                    new RewardData(){typeStr=RewardData.OBSIDIAN,value = 1000},
                    new RewardData(){typeStr=RewardData.XP_BOOSTER,value = 60},
                    new RewardData(){typeStr=RewardData.PEARL_TICKET_BOOSTER,value = 30},
                };

                Popups.RewardView(rewardDatas: rewardDatas, openType: RewardViewPopup.OpenType.ObsidianChest, location: RewardViewPopup.Location.Purchase, onComplete: null);
            }
            else if (index == 8)
            {
                RewardData[] rewardDatas = new RewardData[]
                {
                    new RewardData(){typeStr=RewardData.COIN,value = 1000},
                    new RewardData(){typeStr=RewardData.PEARL,value = 1},
                    new RewardData(){typeStr=RewardData.OBSIDIAN,value = 1000},
                    new RewardData(){typeStr=RewardData.XP_BOOSTER,value = 10},
                    new RewardData(){typeStr=RewardData.PEARL_TICKET_BOOSTER,value = 121},
                };

                Popups.RewardView(rewardDatas);
            }
        }
#endif
    }
}