using System.Collections;
using Underc.User;
using UnityEngine;

namespace Underc.Popup
{
    public class BaseGameProfilePopupLayer : MonoBehaviour
    {
        protected MyProfile Profile
        {
            get
            {
                if (profile == null)
                {
                    profile = MyInfo.Profile;
                }
                return profile;
            }
        }
        protected MyProfile profile;

        public Transform RootTransform
        {
            protected get;
            set;
        }

        public bool RunAsFake
        {
            protected get;
            set;
        }

        public virtual bool CanBack()
        {
            return true;
        }

        public virtual void Init()
        {
            
        }

        public virtual void ResetOnce()
        {

        }

        public virtual void Reset()
        {

        }

        public virtual IEnumerator Unload()
        {
            yield break; 
        }

        public virtual IEnumerator UpdateContent()
        {
            yield break;
        }
    }
}