using Gaga.Util;
using System.Collections;
using TMPro;
using Underc.User;
using UnityEngine;

namespace Underc.Popup
{
    public class GameProfilePopupRecord : BaseGameProfilePopupLayer
    {
        [SerializeField] private TextMeshProUGUI biggestWinText;
        [SerializeField] private TextMeshProUGUI totalWinningsText;
        [SerializeField] private TextMeshProUGUI congratsSentText;

        private MyProfile myProfile;

        public override void Init()
        {
            myProfile = MyInfo.Profile;
        }

        public override void Reset()
        {
            biggestWinText.text = "";
            totalWinningsText.text = "";
            congratsSentText.text = "";
        }

        public override IEnumerator UpdateContent()
        {
            biggestWinText.text = StringUtils.ToKMB(myProfile.MaxWin,
                                                    kiloStartingPoint: 2,
                                                    ignoreDecimalPointUnderKilos: false);
            totalWinningsText.text = StringUtils.ToKMB(myProfile.TotWin,
                                                       kiloStartingPoint: 2,
                                                       ignoreDecimalPointUnderKilos: false);
            congratsSentText.text = myProfile.ClapSent.ToString();
            yield break;
        }
    }
}