using Underc.User;
using UnityEngine;
using TMPro;
using System;
using Gaga;
using System.Collections;
using Underc.Platform;
using UnityEngine.UI;
using Underc.Util;
using Gaga.Util;
using Gaga.Popup;

namespace Underc.Popup
{
    public class GameProfilePopupProfile : BaseGameProfilePopupLayer
    {
        [SerializeField] private TextMeshProUGUI levelText;
        [SerializeField] private TextMeshProUGUI classText;
        [SerializeField] private GameObjectVisibleToggle classSymbolVisibleToggle;
        [SerializeField] private GameObject classSymbol;
        [SerializeField] private GameObject fbButtonContainer;
        [SerializeField] private TextMeshProUGUI storyText;
        [SerializeField] private RawImage seaImage;

        //[SerializeField] private VipClass testingVipClass = VipClass.purple_diamond;

        public Action<bool> OnFacebookLoginToggled;

        private MyProfile profile;
        private MyVipClass vipClass;

        private void Update()
        {
            bool classSymbolVisible = PopupSystem.Instance.IsPeek<GameProfilePopup>();
            if (classSymbol.activeSelf != classSymbolVisible)
            {
                classSymbol.SetActive(classSymbolVisible);
            }
        }

        private void OnDisable()
        {
            seaImage.texture = null;
        }

        public override void Init()
        {
            profile = MyInfo.Profile;
            vipClass = MyInfo.VipClass;
        }

        public override void Reset()
        {
            levelText.text = "";
            classText.text = "";
            storyText.text = "";
            seaImage.color = new Color(1, 1, 1, 0);
            classSymbolVisibleToggle.TurnOff();
        }

        public override IEnumerator UpdateContent()
        {
            levelText.text = profile.Level.ToString();
            classText.text = vipClass.Type.ToString()
                                          .ToUpperInvariant()
                                          .Replace('_', '\n');
            classSymbolVisibleToggle.TurnOnByNameInMultiple(vipClass.Type.ToString());
            UpdateFacebookInfo();
            UpdateSeaName();
            UpdateSeaImage();
            yield break;       
        }

        private void UpdateSeaImage()
        {
            seaImage.color = new Color(1, 1, 1, 1);
            seaImage.texture = ScreenshotSystem.Instance.LatestProfileSea;
        }

        private void UpdateSeaName()
        {
            int seaID = profile.Seas;
            MySea sea = null;
            while (sea == null && seaID > 0)
            {
                sea = MyInfo.Ocean.GetSea(seaID);
                seaID -= 1;
            }

            int chapter = sea.Star + 1;
            storyText.text = StringMaker.New()
                                        .Append(sea.ID.ToString())
                                        .Append("-")
                                        .Append(chapter.ToString())
                                        .Build();
        }

        private void UpdateFacebookInfo()
        {
            fbButtonContainer.SetActive(FacebookLogin.Instance.IsLoggedIn == false);
        }

        public void ConnectFacebook()
        {
            OnFacebookLoginToggled.Invoke(true);
        }

        public void OpenVipBenefit()
        {
            Popups.VipBenefit()
                  .Async()
                  .Cache();
        }
    }
}