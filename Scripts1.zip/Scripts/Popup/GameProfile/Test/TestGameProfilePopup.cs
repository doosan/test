using Gaga.Popup;
using Gaga.System;
using System.Collections;
using Underc.LoadingScreen;
using Underc.Net;
using Underc.Net.Client;
using Underc.Popup;
using Underc.User;
using Underc.Util;
using UnityEngine;

public class TestGameProfilePopup : TestSceneScaffold
{
    [SerializeField] private bool testPlatformLoginButtons = true;

    private IEnumerator Start()
    {
        yield return SetupAndLoad(new BaseLoadingItem[]
        {
            new LoginLoadingItem(),
            new SettingsLoadingItem(),
            new HTTPLoadingItem<UserCoreResponse>(
                () => NetworkSystem.HTTPRequester.UserCoreWithAlarms(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<SeaListResponse>(
                () => NetworkSystem.HTTPRequester.SeaList(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<FishBookListResponse>(
                () => NetworkSystem.HTTPRequester.FishBookList(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<SwimmerBookListResponse>(
                () => NetworkSystem.HTTPRequester.SwimmerBookList(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<ProfileResponse>(
                () => NetworkSystem.HTTPRequester.Profile(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new ABFishLoadingItem(),
            new ABFishIconLoadingItem(),
            new ProfileIconLoadingItem(),
            new ABLoadingItem(AssetBundleName.EFFECT),
            new TopUILoadingItem(),
            new RewardBonusUILoadingItem(),
            new ProfileFirstPicLoadingItem()
        });

        // 모든 물고기 이름 찾기
        //string stringInfo = "";
        //BookInfoProvider bookInfoProvider = MyInfo.Ocean.Book.CreateFishBookInfoProvider();
        //for (int i = 0; i < bookInfoProvider.ItemCount; i++)
        //{
        //    BaseBookInfo bookInfo = bookInfoProvider.GetBookInfo(i);
        //    stringInfo += (bookInfo.Title + "\n");
        //}

        //bookInfoProvider = MyInfo.Ocean.Book.CreateSwimmerBookInfoProvider();
        //for (int i = 0; i < bookInfoProvider.ItemCount; i++)
        //{
        //    BaseBookInfo bookInfo = bookInfoProvider.GetBookInfo(i);
        //    stringInfo += (bookInfo.Title + "\n");
        //}
        //Debug.Log(stringInfo);
    }

    public void OpenGameProfilePopup()
    {
        PopupObject<GameProfilePopup> popupObject = null;
        popupObject = Popups.GameProfile(onOpen: () =>
                                         {
                                             if (popupObject != null)
                                             {
                                                 //popupObject.GetPopup().System.TestPlatformLoginButtons = testPlatformLoginButtons;
                                             }
                                         })
                            .Async()
                            .Cache();
    }

    private IEnumerator OpenVipBenefitPopup()
    {
        Popups.VipBenefit()
              .Async()
              .Cache();
        yield break;
    }

    public void OpenVipBenenfitPopup()
    {
        var fakeVipDataLoader = FakeVipDataLoader.Instance;
        fakeVipDataLoader.SetupProfileResponse(100, 500, VipClassType.gold);

        Coroutines.Create(this,
                          fakeVipDataLoader.LoadProfile,
                          OpenVipBenefitPopup)
                  .Sequence();
    }

    public void OpenInboxPopup()
    {
        PopupObject<GameProfilePopup> popupObject = null;
        popupObject = Popups.GameProfile(tabIndex: 2,
                                         onOpen: () =>
                                         {
                                             if (popupObject != null)
                                             {
                                                 popupObject.GetPopup().RunAsFake = true;
                                             }
                                         })
                            .Async()
                            .Cache();
    }
}
