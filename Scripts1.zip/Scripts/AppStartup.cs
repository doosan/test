using Gaga.AssetBundle;
using Gaga.DeveloperTools;
using Gaga.Popup;
using Gaga.Sound;
using Underc.LoadingScreen;
using Underc.Net;
using Underc.User;
using UnityEngine;
using Underc.Effect;
using Underc.Util;
using Underc.Scene;
using Underc.Ocean;
using Underc.Tutorial;
using Underc.UI;
using Gaga.System;
using Underc.Notification;
using Underc.Net.Client;
using Underc.Auth;
using Underc.Platform;

namespace Underc
{
    public static class AppStartup
    {
        private static bool alreadyStartup = false;

        public static void ProgramBegins()
        {
            if (alreadyStartup == true)
            {
                return;
            }

            alreadyStartup = true;

            Debug.Log("************* Application Startup!!! *************");

            Screen.sleepTimeout = SleepTimeout.NeverSleep; 

            ScreenSystem.Instance.Initialize();
            ScreenSystem.Instance.SetFrameRate(AppConfig.TARGET_FRAME_GENERAL);
            ScreenSystem.Instance.SetResolution(AppConfig.RESOLUTION_WIDTH, AppConfig.RESOLUTION_HEIGHT, ScreenSystem.ScreenMatchMode.Height);
            ScreenSystem.Instance.SetLetterBox(new ScreenSystem.LetterBox(ScreenSystem.LetterBox.Condition.Greater, new Vector2(19.5f, 9), ScreenSystem.LetterBox.BoxMode.Pillar),
                                               new ScreenSystem.LetterBox(ScreenSystem.LetterBox.Condition.Less, new Vector2(4, 3), ScreenSystem.LetterBox.BoxMode.Letter),
                                               new ScreenSystem.LetterBox(ScreenSystem.LetterBox.Condition.Less, new Vector2(9, 19.5f), ScreenSystem.LetterBox.BoxMode.Letter),
                                               new ScreenSystem.LetterBox(ScreenSystem.LetterBox.Condition.Greater, new Vector2(3, 4), ScreenSystem.LetterBox.BoxMode.Pillar));


            LoadingIndicator.Initialize();
            LoadingScreenSystem.Instance.Initialize("Loading", AppConfig.RESOLUTION_WIDTH, AppConfig.RESOLUTION_HEIGHT, Gaga.System.ScreenMatchMode.Expand, 100, 40);
            PopupSystem.Instance.Initialize("S_Popup", AppConfig.RESOLUTION_WIDTH, AppConfig.RESOLUTION_HEIGHT, Gaga.System.ScreenMatchMode.Expand, 100, 50);
            PopupSystem.Instance.SetIndicator(LoadingIndicator.Get(parent: null, autoReturn: false).SetZ(-1600f));
            TutorialSystem.Instance.Initialize("Tutorial", AppConfig.RESOLUTION_WIDTH, AppConfig.RESOLUTION_HEIGHT, Gaga.System.ScreenMatchMode.Expand, 100, 100);
            ScreenshotSystem.Instance.Initialize("", AppConfig.RESOLUTION_WIDTH, AppConfig.RESOLUTION_HEIGHT, Gaga.System.ScreenMatchMode.Expand, 100, 110);
            VipResetNoticeSystem.Instance.Initialize("", AppConfig.RESOLUTION_WIDTH, AppConfig.RESOLUTION_HEIGHT, Gaga.System.ScreenMatchMode.Expand, 100, 120);

            bool assetBundleDevMode = true;

#if !UNITY_EDITOR
            assetBundleDevMode = false;
#endif
            StreamingAssetBundles streamingAssetBundles = Resources.Load<StreamingAssetBundles>("StreamingAssetBundles");
            var assetBundleLoaderNetConfig = new NetConfig(
                timeout: 0, // 에셋번들 로드할 때 timeout을 10으로 지정했더니, 에셋번들 사이즈가 클 때(약 20메가) 로드하다가 취소되는 경우가 있어 0(timeout 없음)으로 설정을 되돌림
                retry: RestClient.DEFAULT_RETRY,
                interval: RestClient.DEFAULT_INTERVAL
            );
            AssetBundleSystem.Instance.Initialize(assetBundleDevMode, AssetBundleName.ReadPlatformName(), streamingAssetBundles, assetBundleLoaderNetConfig);

#if GGDEV
            DeveloperTools.Instance.Initialize("S_DeveloperTools", AppConfig.RESOLUTION_WIDTH, AppConfig.RESOLUTION_HEIGHT);
            DeveloperToolsGesture.Instance.Initialize();
#endif

            AccountSystem.Initialize();
            MyInfo.Initialize();
            PlatformLoginSystem.Instance.Initialize();

            SoundSystem.Instance.Initialize();
            MySettings mySettings = MyInfo.Settings;
            SoundSystem.Instance.SfxVolumeLimit = mySettings.SoundVolume;
            SoundSystem.Instance.BgmVolumeLimit = mySettings.BgmVolume;

            NetworkSystem.Initialize();
            SeaSystem.Instance.Initialize();
            SeaHiddenStorySystem.Instance.Initialize();
            SceneSystem.Initialize();
            DownloadSystem.Instance.Initialize();
            FishIconSystem.Instance.Initialize();
            FishSystem.Instance.Initialize();
            DeepLinkSystem.Instance.Initialize();
            OfferSystem.Instance.Initialize();
            AdminNoticeSystem.Instance.Initialize();
            AdminEventSystem.Instance.Initialize();
            CouponSystem.Instance.Initialize();
            NotificationSystem.Instance.ClearAllDeliveredNotifications();
            MaintenanceSystem.Instance.Initialize();
            DownloadMonitor.Instance.Initialize(15);

            EffectSystem.Instance.Initialize("Effect", AppConfig.RESOLUTION_WIDTH, AppConfig.RESOLUTION_HEIGHT, 60);
        }
    }
}