﻿using System;
using System.Collections.Generic;
using System.Linq;
using Gaga.System;
using Gaga.Util;
using UnityEngine;

#if UNITY_ANDROID
using Unity.Notifications.Android;
#elif UNITY_IOS || UNITY_IPHONE
using Unity.Notifications.iOS;
#endif

namespace Underc
{
    public class DeepLinkData
    {
        public string Protocol { get; private set; }
        public bool HasParameter { get => parameters != null && parameters.Count > 0; }

        private Dictionary<string, string> parameters;
        public DeepLinkData(string protocol, Dictionary<string, string> queryParameter = null)
        {
            Protocol = protocol;
            parameters = queryParameter;
        }

        public string GetParameter(string key)
        {
            if (HasParameter == false || parameters.ContainsKey(key) == false)
            {
                return string.Empty;
            }

            return parameters[key];
        }
    }

    public class DeepLinkSystem : GameObjectSingleton<DeepLinkSystem>
    {
        public const string PROTOCOL_FANPAGE         = "fanpage";
        public const string PROTOCOL_PUSH_LOG        = "push_log";

        public bool IsActivateByNotification
        {
            get
            {
#if UNITY_ANDROID
                return lastNotificationIndtent != null;
#elif UNITY_IOS || UNITY_IPHONE
                //todo ios
                return false;
#else
                return false;
#endif
            }
        }
        public bool IsActivateByFacebook
        {
            get
            {
                return !string.IsNullOrEmpty(lastProtocol) && lastProtocol == PROTOCOL_FANPAGE;
            }
        }

        public int NotificiatinoID
        {
            get
            {
                if (IsActivateByNotification == false)
                {
                    return 0;
                }
                else
                {
#if UNITY_ANDROID
                    return lastNotificationIndtent.Id;
#elif UNITY_IOS || UNITY_IPHONE
                    //todo ios
                    return 0;
#else
                    return 0;
#endif

                }
            }
        }

        public int FacebokID
        {
            get
            {
                if (IsActivateByFacebook == false)
                {
                    return 0;
                }
                else if (Int32.TryParse(GetParameter("id"), out int fbID))
                {
                    return fbID;
                }
                else
                {
                    return 0;
                }
            }
        }

        private List<DeepLinkData> dataList;
        public bool HasData { get => dataList != null && dataList.Count > 0; }

#if UNITY_ANDROID
        private AndroidNotificationIntentData lastNotificationIndtent;
#endif
        private Dictionary<string, string> lastQueryParameters;
        private string lastProtocol;

        public void Initialize()
        {
            dataList = new List<DeepLinkData>();
            lastQueryParameters = new Dictionary<string, string>();

            DetectNotificationIntent();
            Parse(Application.absoluteURL);

            Application.deepLinkActivated += OnDeepLinkActivated;
        }

        public void ResetDatas()
        {
            ResetDeepLinkData();
            ResetActivateData();
        }

        public void ResetDeepLinkData()
        {
            Debug.LogFormat("DeepLinkSystem ResetDeepLinkData");

            if (lastQueryParameters != null)
            {
                lastQueryParameters.Clear();
            }

            if (dataList != null)
            {
                dataList.Clear();
            }
        }

        public void ResetActivateData()
        {
            Debug.LogFormat("DeepLinkSystem ResetActivateData");

            lastProtocol = string.Empty;

#if UNITY_ANDROID
            lastNotificationIndtent = null;
#elif UNITY_IOS || UNITY_IPHONE
            //todo ios
#endif
        }

        public void ApplicationFocus(bool isFocus)
        {
            if (isFocus)
            {
                DetectNotificationIntent();
            }
        }

        //TODO:: 에폭에서 로컬 노티 지원하면 이 로직(DetectIntent)은 NotificationSystem으로 이동해야함.
        private void DetectNotificationIntent()
        {
#if UNITY_ANDROID
            lastNotificationIndtent = AndroidNotificationCenter.GetLastNotificationIntent();
            if (lastNotificationIndtent != null)
            {
                var id = lastNotificationIndtent.Id;
                var channel = lastNotificationIndtent.Channel;
                var notification = lastNotificationIndtent.Notification;
                Debug.LogFormat("DeepLinkSystem unityNoti. id: {0} channel: {1} intent: {2} ", id, channel, notification.IntentData);

                //TODO : 로컬 노티 로그를 보내는 부분을 에폭에서 지원하기 전까지 이 부분에서 로그를 보냄. 이후 제거
                Parse(("undercnoti://push_log?id=" + id.ToString()));
            }
            else
            {
                Debug.LogFormat("DeepLinkSystem detect noti indent null");
            }
#elif UNITY_IOS || UNITY_IPHONE
            //todo ios
#endif
        }

        public void LogActivatingStatus()
        {
            if (IsActivateByNotification == true)
            {
                Debug.LogFormat("ActivateByNotification. id: {0}", NotificiatinoID);
            }
            else if (IsActivateByFacebook == true)
            {
                Debug.LogFormat("ActivateByFacebook id: {0}", FacebokID);
            }
            else
            {
                Debug.LogFormat("Activate");
            }
        }

        private void OnDeepLinkActivated(string url)
        {
            Parse(url);
        }

        public List<DeepLinkData> FindDatas(params string[] protocols)
        {
            return dataList.Where(data => protocols.Contains(data.Protocol)).ToList();
        }

        public void RemoveData(DeepLinkData data)
        {
            Debug.Log("DeepLinkSystem RemoveData : " + data.Protocol);
            dataList.Remove(data);
        }

        private void Parse(string uriString)
        {
            ResetDatas();

            if (string.IsNullOrEmpty(uriString) == true)
            {
                Debug.Log("DeepLinkSystem absoluteURL null");
                return;
            }

            Uri uri;
            if (Uri.TryCreate(uriString, UriKind.Absolute, out uri) == false)
            {
                Debug.LogFormat("DeepLinkSystem ParseURL fail. {0}", uriString);
                return;
            }

            //접속한 주소의 쿼리 키밸류를 저장한다
            Dictionary<string, string> queryParameters = null;
            string query = uri.Query;
            if (string.IsNullOrEmpty(query) == false)
            {
                if (query.StartsWith("?") == true)
                {
                    query = query.Remove(0, 1);
                }

                string[] paramArr = query.Split('&');
                if (paramArr.Length > 0)
                {
                    queryParameters = new Dictionary<string, string>();
                    foreach (var kv in paramArr)
                    {
                        string key = null;
                        string value = null;
                        string[] keyValue = kv.Split('=');

                        if (keyValue.Length >= 2)
                        {
                            key = keyValue[0];
                            value = keyValue[1];
                        }

                        if (string.IsNullOrEmpty(key) == false && string.IsNullOrEmpty(value) == false)
                        {
                            queryParameters.Add(key, value);
                        }
                    }
                }
            }

            if (queryParameters != null)
            {
                foreach (var kv in queryParameters)
                {
                    lastQueryParameters.Add(kv.Key, kv.Value);
                }
            }

            //zempotunderc://www.aquuuacasino.com/fanpage
            var localPath = uri.LocalPath;
            lastProtocol = localPath.Split('/').Last();

            if (string.IsNullOrEmpty(lastProtocol) || string.Equals(lastProtocol, "/"))
            {
                if (string.IsNullOrEmpty(uri.Host))
                {
                    return;
                }

                lastProtocol = uri.Host;
            }

            Debug.LogFormat("DeepLinkSystem url: {0} local: {1} protocol: {2}", uri.AbsoluteUri, localPath, lastProtocol);

            var data = new DeepLinkData(lastProtocol, queryParameters);
            dataList.Add(data);

#if !REAL
            if (data.HasParameter)
            {
                foreach (var kv in queryParameters)
                {
                    Debug.LogFormat("DeepLinkSystem enqueue protocol: {0} key: {1}, value: {2}", data.Protocol, kv.Key, kv.Value);
                }
            }
            else
            {
                Debug.LogFormat("DeepLinkSystem protocol: {0}", data.Protocol);
            }
#endif
        }

        public string GetParameter(string key)
        {
            if (lastQueryParameters != null && lastQueryParameters.TryGetValue(key, out string value))
            {
                return value;
            }
            else
            {
                return string.Empty;
            }
        }
    }
}
