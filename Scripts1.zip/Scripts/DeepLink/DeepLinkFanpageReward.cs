using System;
using System.Collections;
using System.Collections.Generic;
using Underc.Net;
using Underc.Popup;

namespace Underc
{
    public class DeepLinkFanpageReward : IDeepLinkReward
    {
        private bool isProcessing;

        public bool IsProcessing()
        {
            return isProcessing;
        }

        public bool HasReward()
        {
            if (DeepLinkSystem.Instance.HasData == true && isProcessing == false)
            {
                var datas = DeepLinkSystem.Instance.FindDatas(DeepLinkSystem.PROTOCOL_FANPAGE);
                return datas != null && datas.Count > 0;
            }

            return false;
        }

        public void Claim(Action onComplete)
        {
            DeepLinkSystem.Instance.StartCoroutine(WaitForClaim(onComplete));
        }

        public IEnumerator WaitForClaim()
        {
            yield return WaitForClaim(null);
        }

        private IEnumerator WaitForClaim(Action onComplete)
        {
            if (HasReward() == false)
            {
                onComplete?.Invoke();
                yield break;
            }

            isProcessing = true;

            List<DeepLinkData> todoList = DeepLinkSystem.Instance.FindDatas(DeepLinkSystem.PROTOCOL_FANPAGE);

            for (int i = 0; i < todoList.Count; ++i)
            {
                DeepLinkData data = todoList[i];
                string protocol = data.Protocol;

                if (protocol == DeepLinkSystem.PROTOCOL_FANPAGE)
                {
                    yield return GetFanpageReward(data);
                }
            }

            isProcessing = false;

            onComplete?.Invoke();
        }

        private IEnumerator GetFanpageReward(DeepLinkData data)
        {
            if (data.HasParameter == false)
            {
                yield break;
            }

            string linkKey = data.GetParameter("link_key");

            Popups.ShowLoading();
            var req = NetworkSystem.HTTPRequester.FanPageReward(linkKey);
            yield return req.WaitForResponse();
            Popups.HideLoading();

            // A-1. 리퀘스트 성공 여부와 상관없이 데이터 제거. 
            // A-2. 팬페이지 보상 기간 만료 후 요청하면 에러가 발생하는데,
            // A-3. 받을 데이터가 여전히 남아있다고 판단해 에러 팝업이 끊임없이 발생하고 있었음.
            DeepLinkSystem.Instance.RemoveData(data);

            if (req.isSuccess == false)
            {
                HandleError(req.data.error);
                yield break;
            }

            FanpageRewardData rewardData = req.data.data;
            RewardViewPopup.OpenType openType = rewardData.is_mystery == 1 ? RewardViewPopup.OpenType.MysteryBox : RewardViewPopup.OpenType.Normal;
            var waitPopup = Popups.RewardView(rewardData.rwd, rewardData.val, openType).WaitForClose();
            yield return waitPopup;
        }

        private string ERROR_ID_INVALID = "LinkIdInvalid";
        private string ERROR_ALREADY_RCEIVED = "AlreadyReceived";

        private void HandleError(string errorType)
        {
            string title = string.Empty;
            string errorMessage = string.Empty;
            WarningPopup.TitleType titleType = WarningPopup.TitleType.Basic;

            if (errorType == ERROR_ID_INVALID)
            {
                title = "This reward link has expired";
                errorMessage = "Get different rewards\nat the sea aquarium.";
            }
            else if (errorType == ERROR_ALREADY_RCEIVED)
            {
                title = "The link has already been rewarded.";
                errorMessage = "Get different rewards\nat the sea aquarium.";
            }
            else
            {
                titleType = WarningPopup.TitleType.Network;
                errorMessage = "Unknow error";
            }

            Popups.Warning(errorMessage,
                           WarningPopup.ActionType.None,
                           titleType,
                           title);
        }
    }
}