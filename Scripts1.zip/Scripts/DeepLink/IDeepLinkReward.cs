using System;
using System.Collections;

namespace Underc
{
    public interface IDeepLinkReward
    {
        bool IsProcessing();
        bool HasReward();
        void Claim(Action onComplete);
        IEnumerator WaitForClaim();
    }
}