using System;
using System.Collections;
using Gaga.AssetBundle;
using SlotGame.Machine;
using SlotGame.Util;

namespace Underc.LoadingScreen
{
    public class SlotMachineLoadingItem : BaseLoadingItem
    {
        private Action<Result, SlotMachine> onLoadComplete;
        private string slotID;

        public SlotMachineLoadingItem(string slotID, Action<Result, SlotMachine> onLoadComplete, int weight) : base(weight)
        {
            this.slotID = slotID;
            this.onLoadComplete = onLoadComplete;
        }

        public SlotMachineLoadingItem(string slotID, Action<Result, SlotMachine> onLoadComplete) : this(slotID, onLoadComplete, 1){}
        public SlotMachineLoadingItem(string slotID, int weight) : this(slotID, null, weight){}
        public SlotMachineLoadingItem(string slotID) : this(slotID, null, 1){}

        protected override IEnumerator OnLoad(Action<int> onProgress, Result result)
        {
            bool success = false;
            string error = null;
            bool isDone = false;

            var slotAssetBundle = AssetBundleSystem.Instance.GetLoadedAssetBundle(AssetBundleName.Slot(slotID));
            SlotMachine slotMachine = null;

            if (slotAssetBundle == null)
            {
                isDone = true;
                success = false;
            }
            else
            {
                slotAssetBundle.GetGameObjectAsync("SlotMachine", slotObj =>
                {
                    isDone = true;
                    success = slotObj != null;

                    if (success)
                    {
                        slotMachine = slotObj.GetComponent<SlotMachine>();
                    }
                });
            }


            while (isDone == false)
			{
				yield return null;
			}

            if (success == false)
            {
                error = "SlotMachine load failed";
            }

            result.success = success;
            result.error = error;

            if(onLoadComplete != null)
            {
                onLoadComplete(result, slotMachine);
            }
        }
    }
}