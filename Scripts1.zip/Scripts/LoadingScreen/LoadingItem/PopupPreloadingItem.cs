using System;
using System.Collections;
using Gaga.Popup;
using Underc.Net;

namespace Underc.LoadingScreen
{
    public sealed class PopupPreloadingItem<T> : BaseLoadingItem where T : PopupBehaviour
    {
        public override string Name
        {
            get
            {
                return string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0} '{1}' from '{2}' bundle",GetType().Name, popupName, abName);
            }
        }

        private string abName;
        private string popupName;

        public PopupPreloadingItem(string abName, string popupName, int weight, Action<Result> onComplete) : base(weight, onComplete)
        {
            this.abName = abName;
            this.popupName = popupName;
        }

        public PopupPreloadingItem(string abName, string popupName, Action<Result> onComplete) : this(abName, popupName, 1, onComplete){}
        public PopupPreloadingItem(string abName, string popupName, int weight) : this(abName, popupName, weight, null){}
        public PopupPreloadingItem(string abName, string popupName) : this(abName, popupName, 1, null){}

        protected override IEnumerator OnLoad(System.Action<int> onProgress, Result result)
        {
            bool success = false;
            string error = null;
            bool isDone = false;

            PopupSystem.Instance.AddCachedPopupAsync<T>(Address.CDN_ASSETBUNDLES
                                                        ,abName
                                                        ,popupName
                                                        ,loadSuccess=>
                                                        {
                                                            success = loadSuccess;
                                                            isDone = true;
                                                        });

            while (isDone == false)
            {
                yield return null;
            }

            result.success = success;
            result.error = error;
        }
    }
}