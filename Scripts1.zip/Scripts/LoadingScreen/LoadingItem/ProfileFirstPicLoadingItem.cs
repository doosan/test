using System;
using System.Collections;
using Underc.Net.Client;
using Underc.User;
using Underc.Net;
using Underc.Auth;

namespace Underc.LoadingScreen
{
    public sealed class ProfileFirstPicLoadingItem : BaseLoadingItem
    {
        public ProfileFirstPicLoadingItem(int weight, Action<Result> onComplete) : base(weight, onComplete){}
        public ProfileFirstPicLoadingItem(Action<Result> onComplete) : this(1, onComplete){}
        public ProfileFirstPicLoadingItem(int weight) : this(weight, null){}
        public ProfileFirstPicLoadingItem() : this(1, null){} 
        
        protected override IEnumerator OnLoad(Action<int> onProgress, Result result)
        {
            bool success = false;
            string error = null;
            bool isDone = false;

            MyProfile myProfile = MyInfo.Profile;
            if (myProfile.FacebookProfileInfoCache != null)             /// 페이스북 계정 연결을 시도한 흔적이 있으면
            {
                FacebookProfileInfo facebookProfileInfo = myProfile.ConsumeFacebookProfileInfo();
                NetworkSystem.HTTPRequester.ProfileSet(
                    nick: facebookProfileInfo.nick,
                    pic_url: facebookProfileInfo.picUrl,
                    onComplete: (ClientResponse response) =>
                    {
                        isDone = true;
                        success = response.isSuccess && response.ret == 0;
                        if (success == true)
                        {
                            myProfile.Update(facebookProfileInfo.nick, 0, facebookProfileInfo.picUrl);
                        }
                        else
                        {
                            error = response.error;
                        }
                    }
                );
            }
            else if ((AccountSystem.IsFacebookConnected == false                        /// 페이스북 계정 연결이 안되어 있는 상태에서
                      && string.IsNullOrEmpty(myProfile.PicUrl) == false                /// PicUrl 값은 있고
                      && ProfileIconSystem.Instance.Get(myProfile.PicNum) == null)      /// PicNum 값이 없으면

                     || (string.IsNullOrEmpty(myProfile.PicUrl) == true                 /// PicUrl 값이 없고
                         && ProfileIconSystem.Instance.Get(myProfile.PicNum) == null))  /// PicNum 값도 없으면
            {
                int firstPicNum = myProfile.LoadPicNum();
                NetworkSystem.HTTPRequester.ProfileSet(
                    nick: myProfile.Nick, 
                    pic_num: firstPicNum, 
                    onComplete: (ClientResponse response) => 
                    {
                        isDone = true;
                        success = response.isSuccess && response.ret == 0;
                        if (success == true)
                        {
                            myProfile.Update(myProfile.Nick, firstPicNum, "");
                        }
                        else
                        {
                            error = response.error;
                        }
                    }
                );                
            }
            else
            {
                isDone = true;
                success = true;
            }

            while (isDone == false)
			{
				yield return null;
			}

            result.success = success;
            result.error = error;
        }
    }
}