using System;
using System.Collections;

namespace Underc.LoadingScreen
{
    public sealed class AdsInitializingLoadingItem : BaseLoadingItem
    {
        public AdsInitializingLoadingItem(int weight, Action<Result> onComplete) : base(weight, onComplete){}
        public AdsInitializingLoadingItem(Action<Result> onComplete) : this(1, onComplete){}
        public AdsInitializingLoadingItem(int weight) : this(weight, null){}
        public AdsInitializingLoadingItem() : this(1, null){}

        protected override IEnumerator OnLoad(Action<int> onProgress, Result result)
        {
            bool success = true;
            string error = null;

            AdsSystem.Instance.Initialize(popupLayerName: "", 
                                          resolutionWidth: AppConfig.RESOLUTION_WIDTH, 
                                          resolutionHeight: AppConfig.RESOLUTION_HEIGHT, 
                                          match: Gaga.System.ScreenMatchMode.Expand, 
                                          pixelsPerUnit: 100, 
                                          depth: 120);

            result.success = success;
            result.error = error;
            yield break;
        }
    }
}