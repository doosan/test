﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Underc.Auth;
using Underc.Net;
using Underc.Platform;

namespace Underc.LoadingScreen
{
    public sealed class FBDataSendItem : BaseLoadingItem
    {
        public FBDataSendItem(int weight, Action<Result> onComplete) : base(weight, onComplete){}
        public FBDataSendItem(Action<Result> onComplete) : this(1, onComplete){}
        public FBDataSendItem(int weight) : this(weight, null){}
        public FBDataSendItem() : this(1, null){}

        protected override IEnumerator OnLoad(Action<int> onProgress, Result result)
        {
            bool success = true;
            string error = null;

            if (AccountSystem.IsFacebookConnected == true)
            {
                //아래 작업은 기다릴 필요가 없다
                FBLoginSuccess();
            }

            result.success = success;
            result.error = error;
            yield break;
        }

        private void FBLoginSuccess()
        {
            // SendFBFriends();
            SendRequests();
        }

        private void SendFBFriends()
        {
            Debug.Log("FBDataSendItem SendFBFriends");
            FacebookLogin.Instance.GetFriends((friends) =>
            {
                if (friends != null && friends.Length > 0)
                {
                    List<string> fbidList = new List<string>();
                    for (int i = 0; i < friends.Length; i++)
                    {
                        fbidList.Add(friends[i].uid);
                    }

                    NetworkSystem.HTTPRequester.FBSendFriends(fbidList.ToArray());
                }
            });
        }

        private void SendRequests()
        {
            Debug.Log("FBDataSendItem HandleRequests");
            FacebookLogin.Instance.GetRequests((List<FBRequest> fbreqList) =>
            {
                if (fbreqList == null || fbreqList.Count == 0)
                {
                    Debug.Log("FBDataSendItem requests emptied");
                    return;
                }

                List<string> inviteRequestIDs = new List<string>();
                foreach (var fbreq in fbreqList)
                {
                    if (string.IsNullOrEmpty(fbreq.id) == true)
                    {
                        continue;
                    }

                    if (fbreq.data == FacebookLogin.REQUEST_DATA_INVITE)
                    {
                        inviteRequestIDs.Add(fbreq.id);
                    }
                }

                //실제 읽어온 requestid 는 "{request_object_id}_{user_id}" 로 되어 있지만
                //서버엔 요청을 보낼 당시의 {request_object_id} 만 저장되어있으므로 앞부분만 잘라 보낸다
                var splitedReqIDs = inviteRequestIDs.Select(id => id.Split('_')[0]).ToArray();
                NetworkSystem.HTTPRequester.FBRequest(splitedReqIDs, (resp) =>
                {
                    if (resp.isSuccess)
                    {
                        for (int i = 0; i < resp.results.Length; ++i)
                        {
                            bool isSuccess = resp.results[i] == 0;
                            if (isSuccess == false) continue;

                            var successRequestID = inviteRequestIDs[i];
                            FacebookLogin.Instance.DeleteRequest(successRequestID);
                        }
                    }
                });
            });
        }
    }
}

