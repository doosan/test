using System;
using System.Collections;
using Gaga.AssetBundle;
using Underc.Build;
using Underc.User;
using UnityEngine;

namespace Underc.LoadingScreen
{
    public sealed class ABManifestLoadingItem : BaseLoadingItem
    {
        public ABManifestLoadingItem(int weight, Action<Result> onComplete) : base(weight, onComplete){}
        public ABManifestLoadingItem(Action<Result> onComplete) : this(1, onComplete){}
        public ABManifestLoadingItem(int weight) : this(weight, null){}
        public ABManifestLoadingItem() : this(1, null){}

        protected override IEnumerator OnLoad(Action<int> onProgress, Result result)
        {
            string error = null;
            bool isDone = false;
            bool isSuccess = false;

            AssetBundleSystem abManager = AssetBundleSystem.Instance;
            string directoryName = Resources.Load<AssetBundleVersion>("AssetBundleVersion").directoryName;
            abManager.SetupRemoteManifest(url: Net.Address.CDN_ASSETBUNDLES, 
                                          directoryName: directoryName,
                                          directoryDisplayName: directoryName,
                                          bundleVersion: MyInfo.AssetBundleFileName,
                                          success => 
                                          {
                                              isDone = true;
                                              isSuccess = success;
                                          });

            while (isDone == false)
            {
                yield return null;
            }

            if (isSuccess == false)
            {
                error = "Loading abmanifest failed.";
            }

            result.success = isSuccess;
            result.error = error;
        }
    }
}