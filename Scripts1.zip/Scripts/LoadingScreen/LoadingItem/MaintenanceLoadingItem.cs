﻿using System;
using System.Collections;
using Gaga;
using Underc.Net;
using UnityEngine;

namespace Underc.LoadingScreen
{
    public class MaintenanceLoadingItem : BaseLoadingItem
    {
        private CanvasGroup gaugeGroup;

        public MaintenanceLoadingItem(CanvasGroup gaugeGroup, int weight, Action<Result> onComplete): base(weight, onComplete)
        {
            this.gaugeGroup = gaugeGroup;
        }

        public MaintenanceLoadingItem(CanvasGroup gaugeGroup, Action<Result> onComplete) : this(gaugeGroup, 1, onComplete){}
        public MaintenanceLoadingItem(CanvasGroup gaugeGroup, int weight) : this(gaugeGroup, weight, null){}
        public MaintenanceLoadingItem(CanvasGroup gaugeGroup) : this(gaugeGroup, 1, null){}

        protected override IEnumerator OnLoad(Action<int> onProgress, Result result)
        {
            var req = NetworkSystem.HTTPRequester.NotiCheck();
            yield return req.WaitForResponse();

            if (req.isSuccess == false)
            {
                result.success = false;
                result.error = req.data.error;
                yield break;
            }

            result.success = true;
            result.error = null;

            MaintenanceData[] datas = req.data.check;
            MaintenanceSystem.Instance.UpdateDatas(datas);

            var item = MaintenanceSystem.Instance.GetAppData();
            if (item == null)
            {
                yield break;
            }

            long now = GlobalTime.Instance.GetTimeStamp();
            if (item.start <= now && now < item.end)
            {
                var popupObject = MaintenanceSystem.Instance.OpenPopup(item);
                MaintenanceSystem.Instance.StartWatch();
                gaugeGroup.alpha = 0f;
                yield return popupObject.WaitForClose();
                gaugeGroup.alpha = 1f;
                MaintenanceSystem.Instance.StopWatch();
            }

            yield break;
        }
    }
}
