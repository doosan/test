using System;
using System.Collections;
using Underc.Tutorial;
using Underc.User;
using Underc.Net;

namespace Underc.LoadingScreen
{
    public sealed class TutorialLoadingItem : BaseLoadingItem
    {
        public TutorialLoadingItem(int weight, Action<Result> onComplete) : base(weight, onComplete){}
        public TutorialLoadingItem(Action<Result> onComplete) : this(1, onComplete){}
        public TutorialLoadingItem(int weight) : this(weight, null){}
        public TutorialLoadingItem() : this(1, null){}

        protected override IEnumerator OnLoad(Action<int> onProgress, Result result)
        {
            bool success = false;
            string error = null;
            bool isDone = false;

            TutorialSystem.Instance.LoadAssets(loadSuccess=>
            {
                isDone = true;
                success = loadSuccess;

                MyInfo.Tutorial.SyncAll();
            });

            while (isDone == false)
			{
				yield return null;
			}

            onProgress?.Invoke(50);

            if (success == false)
            {
                error = "Tutorial load faield";
            }
            else
            {
                var req = NetworkSystem.HTTPRequester.TutorialSlot();
                yield return req.WaitForResponse();

                if (req.isSuccess && string.IsNullOrEmpty(req.data.data.slotid) == false)
                {
                    NetworkSystem.HTTPHandler.Do(req.data);
                }

                onProgress?.Invoke(100);
            }

            result.success = success;
            result.error = error;
        }
    }
}