using System;
using System.Collections;

namespace Underc.LoadingScreen
{
    public sealed class ProfileIconLoadingItem : BaseLoadingItem
    {
        public ProfileIconLoadingItem(int weight, Action<Result> onComplete) : base(weight, onComplete){}
        public ProfileIconLoadingItem(Action<Result> onComplete) : this(1, onComplete){}
        public ProfileIconLoadingItem(int weight) : this(weight, null){}
        public ProfileIconLoadingItem() : this(1, null){}

        protected override IEnumerator OnLoad(Action<int> onProgress, Result result)
        {
            bool success = false;
            string error = null;
            bool isDone = false;

            ProfileIconSystem.Instance.Initialize(
                onComplete: initSuccess =>
                {
                    success = initSuccess;
                    isDone = true;

                    if (success == false)
                    {
                        error = "Failed to load profile icons.";
                    }
                },
                onProgress
            );

            while (isDone == false)
			{
				yield return null;
			}

            result.success = success;
            result.error = error;
        }
    }
}