﻿using System;
using System.Collections;
using Underc.Net;
using Underc.Popup;
using UnityEngine;


namespace Underc.LoadingScreen
{
    public sealed class VersionCheckLoadingItem : BaseLoadingItem
    {
        public VersionCheckLoadingItem(int weight, Action<Result> onComplete) : base(weight, onComplete){}
        public VersionCheckLoadingItem(Action<Result> onComplete) : this(1, onComplete){}
        public VersionCheckLoadingItem(int weight) : this(weight, null){}
        public VersionCheckLoadingItem() : this(1, null){}

        protected override IEnumerator OnLoad(Action<int> onProgress, Result result)
        {
            VersionData minData = null;
            VersionData latestData = null;

            var req = NetworkSystem.HTTPRequester.Version();
            yield return req.WaitForResponse();

            if (req.isSuccess == false)
            {
                result.success = false;
                result.error = req.data.error;
                yield break;
            }

            minData = req.data.min;
            latestData = req.data.latest;

            //test
            // minData = new VersionData()
            // {
            //     ver = "0.8.10",
            //     img = "https://lh3.googleusercontent.com/Ba8FA8irG-GKXJnp-qNq-euXWntF-v423HBFnZsjJI0ZOmMv8DcQm7PuqL9bECaAtCo"
            // };
            // latestData = new VersionData()
            // {
            //     ver = "0.8.11",
            //     img = "https://images-na.ssl-images-amazon.com/images/I/61p7mgi0GAL._AC_SY355_.jpg"
            // };

            if (minData == null || string.IsNullOrEmpty(minData.ver))
            {
                minData = new VersionData() { ver = Application.version };
            }

            if (latestData == null || string.IsNullOrEmpty(latestData.ver))
            {
                latestData = new VersionData() { ver = Application.version };
            }

            Version now = null;
            Version min = null;
            Version latest = null;

            if (Version.TryParse(Application.version, out now) == false ||
                Version.TryParse(minData.ver, out min) == false ||
                Version.TryParse(latestData.ver, out latest) == false)
            {
                result.success = false;
                result.error = string.Format(System.Globalization.CultureInfo.InvariantCulture, "Version Parsing failed. app: {0} min: {1} latst: {2}", Application.version, minData.ver, latestData.ver);
                yield break;
            }

            if (now >= latest)
            {
                result.success = true;
                result.error = null;

                Debug.LogFormat("[VersionCheck] latest version. app: {0} min: {1} latst: {2}", Application.version, minData.ver, latestData.ver);
                yield break;
            }

            bool isForce = false;
            string imgURL = string.Empty;
            if (now < min)
            {
                isForce = true;
                imgURL = minData.img;
            }
            else
            {
                isForce = false;
                imgURL = latestData.img;
            }

            result.success = true;
            result.error = null;

            if(string.IsNullOrEmpty(imgURL) == false )
            {
                yield return Popups.AppUpdate(isForce, imgURL).WaitForClose();
            }
            else
            {
                yield break;
            }
        }
    }
}

