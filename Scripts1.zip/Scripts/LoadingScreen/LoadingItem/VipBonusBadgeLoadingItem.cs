using System;
using System.Collections;
using Underc.UI;

namespace Underc.LoadingScreen
{
    public class VipBonusBadgeLoadingItem : BaseLoadingItem
    {
        public VipBonusBadgeLoadingItem(int weight, Action<Result> onComplete) : base(weight, onComplete) { }
        public VipBonusBadgeLoadingItem(int weight) : this(weight, null) { }
        public VipBonusBadgeLoadingItem() : this(1, null) { }

        protected override IEnumerator OnLoad(Action<int> onProgress, Result result)
        {
            bool success = false;
            string error = null;
            bool isDone = false;

            VipBonusBadgeSystem.Instance.Preload(
                onComplete: _success =>
                {
                    isDone = true;
                    success = _success;
                },
                onProgress
            );

            while (isDone == false)
            {
                yield return null;
            }

            if (success == false)
            {
                error = "VipBonusBadge preload failed";
            }

            result.success = success;
            result.error = error;
        }
    }
}