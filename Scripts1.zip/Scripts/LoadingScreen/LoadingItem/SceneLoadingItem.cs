using System;
using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Underc.LoadingScreen
{
    public sealed class SceneLoadingItem : BaseLoadingItem
    {
        private string sceneName;

        public SceneLoadingItem(string sceneName, int weight, Action<Result> onComplete) : base(weight, onComplete)
        {
            this.sceneName = sceneName;
        }

        public SceneLoadingItem(string sceneName, Action<Result> onComplete) : this(sceneName, 1, onComplete){}
        public SceneLoadingItem(string sceneName, int weight) : this(sceneName, weight, null){}
        public SceneLoadingItem(string sceneName) : this(sceneName ,1, null){} 

        protected override IEnumerator OnLoad(Action<int> onProgress, Result result)
        {
            AsyncOperation asyncOper = SceneManager.LoadSceneAsync(sceneName);
            asyncOper.allowSceneActivation = false;

            while (asyncOper.progress < 0.9f)
            {
                int progressVal = (int)(asyncOper.progress * 100.0f);
                onProgress(progressVal);
                yield return null;
            }

            onProgress(100);

            result.success = true;
            result.error = "";
            result.sceneAsyncOperation = asyncOper;
        }
    }
}