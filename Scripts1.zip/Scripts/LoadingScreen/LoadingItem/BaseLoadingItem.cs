using System;
using System.Collections;
using UnityEngine;

namespace Underc.LoadingScreen
{
    public abstract class BaseLoadingItem
    {
        private Action<Result> onComplete;
        private int weight = 1;
        public int Weight
        {
            get
            {
                return weight;
            }
            set
            {
                weight = Mathf.Clamp(value, 1, int.MaxValue);
            }
        }

        public virtual string Name
        {
            get
            {
                return GetType().Name;
            }
        }

        public BaseLoadingItem(int weight, Action<Result> onComplete)
        {
            Weight = weight;
            this.onComplete = onComplete;
        }

        public BaseLoadingItem(Action<Result> onComplete) : this(1, onComplete){}
        public BaseLoadingItem(int weight) : this(weight, null){}
        public BaseLoadingItem() : this(1, null){}

        public IEnumerator Load(Action<int> onProgress, Action<Result> onComplete)
        {
            Result result = new Result();

            yield return OnLoad(onProgress, result);

            if (result.success == true)
            {
                if (onProgress != null)
                {
                    onProgress(100);
                }
            }

            onComplete(result);
            
            if (this.onComplete != null)
            {
                this.onComplete(result);
            }
        }

        protected abstract IEnumerator OnLoad(Action<int> onProgress, Result result);
    }

    public class Result
    {
        public bool success;
        public string error;
        public AsyncOperation sceneAsyncOperation; 
    }
}