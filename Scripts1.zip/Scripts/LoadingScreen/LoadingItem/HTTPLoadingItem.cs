using System;
using System.Collections;
using Underc.Net;
using Underc.Net.Client;
using static Underc.Net.Client.RestClient;

namespace Underc.LoadingScreen
{
    public sealed class HTTPLoadingItem<T> : BaseLoadingItem where T : ClientResponse
    {
        private Func<IRequest<T>> requestFunc;
        private Action<T> handler;

        public override string Name
        {
            get
            {
                return string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0} ({1})", GetType().Name, typeof(T).Name);
            }
        }

        public HTTPLoadingItem(Func<IRequest<T>> requestFunc, Action<T> handler, int weight, Action<Result> onComplete) : base(weight, onComplete)
        {
            this.requestFunc = requestFunc;
            this.handler = handler;
        }

        public HTTPLoadingItem(Func<IRequest<T>> requestFunc, Action<T> handler, Action<Result> onComplete) : this(requestFunc, handler, 1, onComplete){}
        public HTTPLoadingItem(Func<IRequest<T>> requestFunc, Action<T> handler, int weight) : this(requestFunc, handler, weight, null){}
        public HTTPLoadingItem(Func<IRequest<T>> requestFunc, Action<T> handler) : this(requestFunc, handler, 1, null){}

        protected override IEnumerator OnLoad(Action<int> onProgress, Result result)
        {
            if (requestFunc == null )
            {
                result.success = false;
                yield break;
            }

            var request = requestFunc.Invoke();
            yield return request.WaitForResponse();

            result.success = request.data.isSuccess && request.data.ret == 0;

            if (result.success == false)
            {
                result.error = request.data.error;
            }

            if (handler != null && result.success)
            {
                handler(request.data);
            }
        }
    }
}