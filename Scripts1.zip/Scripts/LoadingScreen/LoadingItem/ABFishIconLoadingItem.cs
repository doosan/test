using System;
using System.Collections;
using Underc.Ocean;

namespace Underc.LoadingScreen
{
    public sealed class ABFishIconLoadingItem : BaseLoadingItem
    {
        public ABFishIconLoadingItem(int weight, Action<Result> onComplete) : base(weight, onComplete){}
        public ABFishIconLoadingItem(Action<Result> onComplete) : this(1, onComplete){}
        public ABFishIconLoadingItem(int weight) : this(weight, null){}
        public ABFishIconLoadingItem() : this(1, null){}

        protected override IEnumerator OnLoad(Action<int> onProgress, Result result)
        {
            bool success = false;
            string error = null;
            bool isDone = false;

            FishIconSystem.Instance.Setup(itemSuccess =>
                                          {
                                              isDone = true;
                                              success = itemSuccess;
                                          }
                                          ,progress =>
                                          {
                                              int progressVal = (int)(progress * 100.0f);
                                              onProgress(progressVal);
                                          });

            while (isDone == false)
			{
				yield return null;
			}

            if (success == false)
            {
                error = "AbInventory load failed";
            }

            result.success = success;
            result.error = error;
        }
    }
}