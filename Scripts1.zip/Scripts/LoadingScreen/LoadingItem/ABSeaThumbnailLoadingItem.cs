using System;
using System.Collections;
using Underc.Ocean;

namespace Underc.LoadingScreen
{
    public sealed class ABSeaThumbnailLoadingItem : BaseLoadingItem
    {
        private string seaID;

        public ABSeaThumbnailLoadingItem(int weight, Action<Result> onComplete) : base(weight, onComplete){}
        public ABSeaThumbnailLoadingItem(Action<Result> onComplete) : this(1, onComplete){}
        public ABSeaThumbnailLoadingItem(int weight) : this(weight, null){}
        public ABSeaThumbnailLoadingItem() : this(1, null){}

        protected override IEnumerator OnLoad(Action<int> onProgress, Result result)
        {
            bool success = false;
            string error = null;
            bool isDone = false;

            SeaThumbnailSystem.Instance.Load(itemSuccess =>
                                            {
                                                isDone = true;
                                                success = itemSuccess;
                                            }
                                            ,progress =>
                                            {
                                                int progressVal = (int)(progress * 100.0f);
                                                onProgress(progressVal);
                                            });

            while (isDone == false)
			{
				yield return null;
			}

            if (success == false)
            {
                error = "AbSeaThumbnail load failed";
            }

            result.success = success;
            result.error = error;
        }
    }
}