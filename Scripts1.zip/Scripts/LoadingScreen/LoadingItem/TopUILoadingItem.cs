using System;
using System.Collections;
using Underc.UI;

namespace Underc.LoadingScreen
{
    public sealed class TopUILoadingItem : BaseLoadingItem
    {
        public TopUILoadingItem(int weight, Action<Result> onComplete) : base(weight, onComplete){}
        public TopUILoadingItem(Action<Result> onComplete) : this(1, onComplete){}
        public TopUILoadingItem(int weight) : this(weight, null){}
        public TopUILoadingItem() : this(1, null){}

        protected override IEnumerator OnLoad(Action<int> onProgress, Result result)
        {
            bool success = false;
            string error = null;
            bool isDone = false;

            TopUISystem.Instance.Preload(loadSuccess =>
            {
                isDone = true;
                success = loadSuccess;
            },
            onProgress);

            while (isDone == false)
			{
				yield return null;
			}

            if (success == false)
            {
                error = "TopUI preload failed";
            }

            result.success = success;
            result.error = error;
        }
    }
}