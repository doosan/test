using System;
using System.Collections;
using Underc.Ocean;
using Underc.User;

namespace Underc.LoadingScreen
{
    public sealed class ABFishLoadingItem : BaseLoadingItem
    {
        private string seaID;

        public ABFishLoadingItem(int weight, Action<Result> onComplete) : base(weight, onComplete){}
        public ABFishLoadingItem(Action<Result> onComplete) : this(1, onComplete){}
        public ABFishLoadingItem(int weight) : this(weight, null){}
        public ABFishLoadingItem() : this(1, null){}

        protected override IEnumerator OnLoad(Action<int> onProgress, Result result)
        {
            bool success = false;
            string error = null;
            bool isDone = false;

            int seaID = MyInfo.Ocean.CurrentSeaID;

            FishSystem.Instance.Load(seaID,
                                     onComplete: itemSuccess =>
                                     {
                                         isDone = true;
                                         success = itemSuccess;
                                     },
                                     onProgress: progress =>
                                     {
                                         int progressVal = (int)(progress * 100.0f);
                                         onProgress(progressVal);
                                     }); 

            while (isDone == false)
			{
				yield return null;
			}

            if (success == false)
            {
                error = "AbFish load failed";
            }

            result.success = success;
            result.error = error;
        }
    }
}