using System;
using System.Collections;
using Underc.Notification;

namespace Underc.LoadingScreen
{
    public sealed class NotificationInitializeLoadingItem : BaseLoadingItem
    {
        public NotificationInitializeLoadingItem(int weight, Action<Result> onComplete) : base(weight, onComplete){}
        public NotificationInitializeLoadingItem(Action<Result> onComplete) : this(1, onComplete){}
        public NotificationInitializeLoadingItem(int weight) : this(weight, null){}
        public NotificationInitializeLoadingItem() : this(1, null){} 

        protected override IEnumerator OnLoad(Action<int> onProgress, Result result)
        {
            NotificationSystem.Instance.Initialize();
            
            yield return null;

            result.success = true;
            result.error = null;
        }
    }
}
