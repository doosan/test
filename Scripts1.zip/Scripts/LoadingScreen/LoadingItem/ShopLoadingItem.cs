using System.Collections;
using System;
using Underc.User;
using Underc.Tutorial;
using Underc.Net;

namespace Underc.LoadingScreen
{
    public class ShopLoadingItem : BaseLoadingItem
    {
        public ShopLoadingItem(int weight, Action<Result> onComplete) : base(weight, onComplete){}
        public ShopLoadingItem(Action<Result> onComplete) : this(1, onComplete){}
        public ShopLoadingItem(int weight) : this(weight, null){}
        public ShopLoadingItem() : this(1, null){}

        protected override IEnumerator OnLoad(Action<int> onProgress, Result result)
        {
            // Settings 데이터 Sync 이후에 체크 가능
            if (MyInfo.Tutorial.IsComplete(TutorialChapter.PlaySlot) == true) 
            {
                // 굳이 첫 로딩 때 데이터를 로드하는 이유는 ShopHUD 에 Free 라벨을 붙이기 위해
                var req = NetworkSystem.HTTPRequester.Shop();
                yield return req.WaitForResponse();

                if (req.isSuccess == true)
                {
                    result.success = true;
                    NetworkSystem.HTTPHandler.Do(req.data);
                }
                else
                {
                    result.success = false;
                    result.error = req.data.error;
                }
            }
            else
            {
                result.success = true;
            }
        }
    }
}
