using System;
using System.Collections;
using UnityEngine;

namespace Underc.LoadingScreen
{
    public class SlotIconLoadingItem : BaseLoadingItem
    {
        public SlotIconLoadingItem(int weight, Action<Result> onComplete) : base(weight, onComplete) { }
        public SlotIconLoadingItem(int weight) : this(weight, null) { }
        public SlotIconLoadingItem() : this(1, null) { }

        protected override IEnumerator OnLoad(Action<int> onProgress, Result result)
        {
            bool success = false;
            bool isDone = false;
            string error = null;

            SlotIconSystem.Instance.Initialize(
                onComplete: initSuccess =>
                {
                    success = initSuccess;
                    isDone = true;

                    if (success == false)
                    {
                        error = "Failed to load slot icons.";
                    }
                },
                onProgress
            );

            while (isDone == false)
            {
                yield return null;
            }

            result.success = success;
            result.error = error;
        }
    }
}