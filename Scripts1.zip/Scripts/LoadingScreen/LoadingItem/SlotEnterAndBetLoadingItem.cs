using System;
using System.Collections;
using SlotGame.Machine;
using Underc.Net;
using Underc.User;

namespace Underc.LoadingScreen
{
    public sealed class SlotEnterAndBetLoadingItem : BaseLoadingItem
    {
        public struct Data
        {
            public EnterData enterData;
            public BetData betData;
        }

        private Action<Result, Data, int> onLoadComplete;
        private string slotID;

        public SlotEnterAndBetLoadingItem(string slotID, Action<Result, Data, int> onLoadComplete, int weight) : base(weight)
        {
            this.slotID = slotID;
            this.onLoadComplete = onLoadComplete;
        }

        public SlotEnterAndBetLoadingItem(string slotID, Action<Result, Data, int> onLoadComplete) : this(slotID, onLoadComplete, 1){}
        public SlotEnterAndBetLoadingItem(string slotID, int weight) : this(slotID, null, weight){}
        public SlotEnterAndBetLoadingItem(string slotID) : this(slotID, null, 1){}

        protected override IEnumerator OnLoad(Action<int> onProgress, Result result)
        {
            bool success = false;
            string error = null;
            bool isDone = false;
            Data data = new Data();

            EnterData enterData = null;
            BetData betData = null;

            var savedSlotPlayInfo = MyInfo.SlotGame.GetSlotPlayInfo();

            NetworkSystem.HTTPRequester.GameEnter(slotID, enterResp =>
            {
                onProgress(50);

                enterData = enterResp.data;

                MaintenanceSystem.Instance.CurrentSlotID = slotID;

                MyInfo.Challenge.Update(enterResp.challenge);
                MyInfo.SpinQuest.Update(enterResp.spin_quest);
                MyInfo.DailyMission.Update(enterResp.ts, enterResp.daily_quest);
                MyInfo.QuestClam.Update(enterResp.quest_clam);
                MyInfo.Booster.SecondaryCurrenciesAddedSec = enterResp.level.pearl_booster_add_sec;
                MyInfo.AquaBlitz.Update(checkUpdateTs: false, enterResp.ts, enterResp.aqua_blitz_mission);

                long currentBet = enterResp.data.bet;

                if (enterResp.isSuccess == true && enterResp.ret == 0)
                {
                    if (savedSlotPlayInfo.IsValid 
                        && savedSlotPlayInfo.slotID == slotID
                        && savedSlotPlayInfo.totalBet <= MyInfo.Coin)
                    {
                        currentBet = savedSlotPlayInfo.totalBet;
                    }
 
                    NetworkSystem.HTTPRequester.GameBet(slotID, currentBet, betResp=>
                    {
                        onProgress(100);

                        if (betResp.isSuccess == true && betResp.ret == 0)
                        {
                            betData = betResp.data;
                            
                            isDone = true;
                            success = true;

                            data.enterData = enterData;
                            data.betData = betData;
                        }
                        else
                        {
                            isDone = true;
                            error = betResp.error;
                        }
                    });
                }
                else
                {
                    isDone = true;
                    error = enterResp.error;
                }
            });

            while (isDone == false)
			{
				yield return null;
			}

            result.success = success;
            result.error = error;

            if(onLoadComplete != null)
            {
                onLoadComplete(result, data, savedSlotPlayInfo.IsValid ? savedSlotPlayInfo.autoSpinCount : 0);
            }
        }
    }
}