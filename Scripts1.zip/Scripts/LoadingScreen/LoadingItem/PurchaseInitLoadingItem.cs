using System;
using System.Collections;

namespace Underc.LoadingScreen
{
    public sealed class PurchaseInitLoadingItem : BaseLoadingItem
    {
        public PurchaseInitLoadingItem(int weight, Action<Result> onComplete) : base(weight, onComplete){}
        public PurchaseInitLoadingItem(Action<Result> onComplete) : this(1, onComplete){}
        public PurchaseInitLoadingItem(int weight) : this(weight, null){}
        public PurchaseInitLoadingItem() : this(1, null){}  

        protected override IEnumerator OnLoad(Action<int> onProgress, Result result)
        {
#if TEST_PURCHASE_INIT == false
            PurchaseSystem.Instance.InitStoreItems();
#endif
            result.success = true;
            result.error = null;
            yield break;
        }
    }
}