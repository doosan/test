using System;
using System.Collections;
using Underc.Auth;
using UnityEngine;

namespace Underc.LoadingScreen
{
    public sealed class LoginLoadingItem : BaseLoadingItem
    {
        public LoginLoadingItem(int weight, Action<Result> onComplete) : base(weight, onComplete){}
        public LoginLoadingItem(Action<Result> onComplete) : this(1, onComplete){}
        public LoginLoadingItem(int weight) : this(weight, null){}
        public LoginLoadingItem() : this(1, null){}

        protected override IEnumerator OnLoad(Action<int> onProgress, Result result)
        {
            bool success = false;
            string error = null;
            bool isDone = false;

            AccountSystem.Login(
                ()=>
                {
                    success = true;
                    isDone = true;
                }
                ,
                progress =>
                {
                    onProgress((int)(progress * 100.0f));
                }
                ,errorMsg=>
                {
                    success = false;
                    isDone = true;
                    error = errorMsg;
                }
            );

            yield return new WaitUntil(() => isDone != false);

            result.success = success;
            result.error = error;
        }
    }
}
