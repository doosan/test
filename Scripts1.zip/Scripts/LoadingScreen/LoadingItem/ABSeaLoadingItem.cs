using System;
using System.Collections;
using Underc.Ocean;
using Underc.User;

namespace Underc.LoadingScreen
{
    public sealed class ABSeaLoadingItem : BaseLoadingItem
    {
        private string seaID;

        public ABSeaLoadingItem(int weight, Action<Result> onComplete) : base(weight, onComplete){}
        public ABSeaLoadingItem(Action<Result> onComplete) : this(1, onComplete){}
        public ABSeaLoadingItem(int weight) : this(weight, null){}
        public ABSeaLoadingItem() : this(1, null){}

        protected override IEnumerator OnLoad(Action<int> onProgress, Result result)
        {
            bool success = false;
            string error = null;
            bool isDone = false;

            int seaID = MyInfo.Ocean.CurrentSeaID;

            SeaSystem.Instance.LoadSea(seaID
                                        ,itemSuccess =>
                                        {
                                            isDone = true;
                                            success = itemSuccess;
                                        }
                                        ,progress =>
                                        {
                                            int progressVal = (int)(progress * 100.0f);
                                            onProgress(progressVal);
                                        });

            while (isDone == false)
			{
				yield return null;
			}

            if (success == false)
            {
                error = "AbSea load failed";
            }

            result.success = success;
            result.error = error;
        }
    }
}