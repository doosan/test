using System;
using System.Collections;
using Underc.UI;

namespace Underc.LoadingScreen
{
    public class RewardBonusUILoadingItem : BaseLoadingItem
    {
        public RewardBonusUILoadingItem(int weight, Action<Result> onComplete) : base(weight, onComplete) { }
        public RewardBonusUILoadingItem(int weight) : this(weight, null) { }
        public RewardBonusUILoadingItem() : this(1, null) { }

        protected override IEnumerator OnLoad(Action<int> onProgress, Result result)
        {
            bool success = false;
            string error = null;
            bool isDone = false;

            RewardBonusUISystem.Instance.Preload(
                onComplete: _success =>
                {
                    isDone = true;
                    success = _success;
                },
                onProgress
            );

            while (isDone == false)
            {
                yield return null;
            }

            if (success == false)
            {
                error = "RewardBonusUI preload failed";
            }

            result.success = success;
            result.error = error;
        }
    }
}