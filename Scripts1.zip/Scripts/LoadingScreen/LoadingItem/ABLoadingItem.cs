using System;
using System.Collections;
using Gaga.AssetBundle;
using UnityEngine;

namespace Underc.LoadingScreen
{
    public class ABLoadingItem : BaseLoadingItem
    {
        private string assetBundleName;
        public override string Name
        {
            get
            {
                return string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0} ({1})", GetType().Name, assetBundleName);
            }
        }

        public ABLoadingItem(string assetBundleName, int weight, Action<Result> onComplete = null) : base(weight, onComplete)
        {
            this.assetBundleName = assetBundleName;
        }

        public ABLoadingItem(string assetBundleName, Action<Result> onComplete) : this(assetBundleName, 1, onComplete){}
        public ABLoadingItem(string assetBundleName, int weight) : this(assetBundleName, weight, null){}
        public ABLoadingItem(string assetBundleName) : this(assetBundleName, 1, null){}

        protected override IEnumerator OnLoad(Action<int> onProgress, Result result)
        {
            bool success = false;
            string error = null;
            bool isDone = false;

            if (string.IsNullOrEmpty(assetBundleName) == true)
            {
                isDone = true;
                success = false;
            }
            else
            {
                int retryCnt = 3;
                isDone = false;

                while (success == false && retryCnt > 0 )
                {
                    AssetBundleSystem.Instance.Load(AssetBundleLoadType.Load
                                                    ,Net.Address.CDN_ASSETBUNDLES
                                                    ,assetBundleName
                                                    ,(successCommon, abCommon) =>
                                                    {
                                                        isDone = true;
                                                        success = successCommon;
                                                    }
                                                    ,progress =>
                                                    {
                                                        int progressVal = (int)(progress * 100.0f);
                                                        onProgress(progressVal);
                                                    });

                    retryCnt--;

                    while (isDone == false)
                    {
                        yield return null;
                    }

                    if (success == false)
                    {
                        yield return new WaitForSeconds(1.0f);
                    }
                }
            }

            if (success == false)
            {
                error = assetBundleName + " load failed";
            }

            result.success = success;
            result.error = error;
        }
    }
}