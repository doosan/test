using UnityEngine;
using System.Collections;
using System;
using Underc.Popup;
using System.Collections.Generic;

namespace Underc.LoadingScreen
{
    public abstract class BaseLoadingScreen<T> : MonoBehaviour where T : LoadingResult, new()
    {
        public readonly string ERROR_FORMAT = "Failed to login to game server.\n<color=#FF00FF><size=26>({0})</color></size>\n\nPlease try again.\nYour sea needs you!";

        public delegate void StateDelegate();
        public event StateDelegate OnEnter;
        public event StateDelegate OnLoadBegin;
        public event StateDelegate OnExit;

        public delegate void ResultDelegate(T result);
        public event ResultDelegate OnLoadComplete;

        protected T result;
        public T Result{get{return result;}}

        private string sceneName;
        AsyncOperation sceneAsyncOperation = null;

        public virtual void Initialize(string sceneName = null)
        {
            this.sceneName = sceneName;

            StartCoroutine(StateCoroutine());
        }

        public virtual void Abort()
        {
            StopAllCoroutines();
        }

        private IEnumerator StateCoroutine()
        {
            if (OnEnter != null)
            {
                OnEnter();
            }

            yield return Enter();
           
            if (OnLoadBegin != null)
            {
                OnLoadBegin();
            }

            result = new T();
            yield return Execute(result);

            if (OnLoadComplete != null)
            {
                OnLoadComplete(result);
            }

            if (sceneAsyncOperation != null)
            {
                sceneAsyncOperation.allowSceneActivation = true;
            }

            yield return Exit();

            if (OnExit != null)
            {
                OnExit();
            }
        }

        protected abstract BaseLoadingItem[] SetupLoadingItems(T result);
        protected abstract IEnumerator Enter();
        protected abstract IEnumerator Exit();
        protected virtual void OnProgress(int progress){}
        protected virtual void OnLoading(BaseLoadingItem item){}

        protected virtual IEnumerator OnError(string error, BaseLoadingItem loadingItem)
        {
            yield return Popups.Error(string.Format(System.Globalization.CultureInfo.InvariantCulture, ERROR_FORMAT, error), ErrorPopup.ActionType.Intro).Async().WaitForClose();
        }

        protected virtual IEnumerator Execute(T result)
        {
            var loadList = SetupLoadingItems(result);
           
            if (string.IsNullOrEmpty(sceneName) == false)
            {
                var loadListWithScene = new List<BaseLoadingItem>();
                loadListWithScene.AddRange(loadList);

                var sceneLoadingItem = new SceneLoadingItem(sceneName, sceneResult=>
                {
                    sceneAsyncOperation = sceneResult.sceneAsyncOperation;
                });

                loadListWithScene.Add(sceneLoadingItem);
                loadList = loadListWithScene.ToArray();
            }

            bool success = false;
            string error = null;
            int currentIndex = 0;
            float startProgress = 0;
            float currentProgress = 0;
            int totalWeight = 0;

            for (int i = 0; i < loadList.Length; i++)
            {
                var loadItem = loadList[i];
                totalWeight += loadItem.Weight;

                // Debug.LogFormat("loading weight index : {0}, curr : {1} , total : {2}", i, loadItem.Weight, totalWeight);
            }

            Action<int> onLoadProgress = progress =>
            {
                if (progress > 100)
                {
                    progress = 100;
                }

                float range = ((float)loadList[currentIndex].Weight / (float)totalWeight) * 100.0f;
                currentProgress = startProgress + (((float)progress / 100.0f) * range);
                int displayProgress = Mathf.RoundToInt(currentProgress);

                OnProgress(displayProgress);

                // Debug.LogFormat("loading load index : {2} , range : {0} , curr : {1} , dp : {3}", range, currentProgress, currentIndex, displayProgress);
            };

            Action<Result> onLoadComplete = itemResult =>
            {
                success = itemResult.success;
                startProgress = currentProgress;

                if (itemResult.success == false)
                {
                    if (string.IsNullOrEmpty(itemResult.error))
                    {
                        error = "Load Failed";
                    }
                    else
                    {
                        error = itemResult.error;
                    }
                }
            };

            for (int i = 0; i < loadList.Length; i++)
            {
                currentIndex = i;
                var loadItem = loadList[i];
                Debug.LogFormat("Start Load : {0}", loadItem.Name);
                OnLoading(loadItem);
                yield return loadItem.Load(onLoadProgress, onLoadComplete);

                if (success == false)
                {
                    result.error = error;
                    result.isSuccess = false;
                    yield return OnError(error, loadItem);
                    yield break;
                }
            }

            if (string.IsNullOrEmpty(error) == true)
            {
                result.isSuccess = true;
            }
        }
    }

    public class LoadingResult
    {
        public bool isSuccess;
        public string error;
    }
}