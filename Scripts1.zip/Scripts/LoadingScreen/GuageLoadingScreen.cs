using UnityEngine;
using System.Collections;
using UnityEngine.UI;

namespace Underc.LoadingScreen
{
    public abstract class GaugeLoadingScreen<T> : BaseLoadingScreen<T> where T : LoadingResult, new()
    {
        #pragma warning disable 0649
        [Header("Gauge")]
        [SerializeField] private Slider gauge;
        [SerializeField] private Text gaugeText;
        [SerializeField] private float gaugeDuration = 1.5f;
        [SerializeField] private float gaugeShowMin = 0.01f;
        [SerializeField] private float gaugeShowMax = 1.0f;
        #pragma warning restore 0649

        protected float currentGaugeValue;
        protected float targetGaugeValue;

        public override void Initialize(string sceneName = null)
        {
            base.Initialize(sceneName);

            targetGaugeValue = 0.0f;
            UpdateGauge(0.0f);
            StopCoroutine("GaugeProgress");
            StartCoroutine("GaugeProgress");
        }

        protected virtual void UpdateGauge(float value)
        {
            value = Mathf.Clamp(value, gaugeShowMin, gaugeShowMax);
            gauge.value = value;
        }

        protected override void OnProgress(int progress)
        {
            var progressVal = progress * 0.01f;
            targetGaugeValue = progressVal;
        }

        private IEnumerator GaugeProgress()
        {
            currentGaugeValue = 0.0f;
            float frameRate = (float)Application.targetFrameRate;

            while (true)
            {
                currentGaugeValue += (1.0f / gaugeDuration) / frameRate;
                if (currentGaugeValue > targetGaugeValue)
                {
                    currentGaugeValue = targetGaugeValue;
                }

                UpdateGauge(currentGaugeValue);

                long gaugeVal = (long)(currentGaugeValue * 100.0f);
                gaugeText.text = string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0}%", gaugeVal);

                yield return null;
            }
        }

        protected override IEnumerator Execute(T result)
        {
            yield return base.Execute(result);

            while (currentGaugeValue < 1.0f)
            {
                yield return null;
            }
        }
    }
}