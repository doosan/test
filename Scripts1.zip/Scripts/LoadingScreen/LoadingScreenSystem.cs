using System;
using System.Collections.Generic;
using Gaga.System;
using Underc.Scene;
using UnityEngine;
using UnityEngine.UI;
using Underc.Lobby;

namespace Underc.LoadingScreen
{
    public sealed class LoadingScreenSystem : CanvasSingleton<LoadingScreenSystem>
    {
        private readonly string SCREEN_OBJECT_INTRO             = "IntroLoadingScreen";
        private readonly string SCREEN_OBJECT_GAME_LANDSCAPE    = "GameLoadingScreen";
        private readonly string SCREEN_OBJECT_GAME_PORTRAIT     = "GameLoadingScreenPortrait";
        private readonly string SCREEN_OBJECT_LOBBY             = "LobbyLoadingScreen";

        private Transform cacheObjects;
        private GameObject currentLoadingScreenObject;
        private Image backgroundImage;
        private Dictionary<string, GameObject> cacheList;

        public bool IsLoading { get => currentLoadingScreenObject != null; }

        protected override void OnInitialize(string popupLayerName, int resolutionWidth, int resolutionHeight, ScreenMatchMode match, int pixelsPerUnit, int depth)
        {
            base.OnInitialize(popupLayerName, resolutionWidth, resolutionHeight, match, pixelsPerUnit, depth);

            SetupBackgroundPanel(popupLayerName);
            HideBg();
        }

        private bool IsPreload()
        {
            return cacheList != null;
        }

        public void PreloadAndCaching(Action<bool> onComplete)
        {
            if (IsPreload())
            {
                onComplete(true);
                return;
            }

            cacheList = new Dictionary<string, GameObject>();

            if (cacheObjects == null)
            {
                cacheObjects = new GameObject("CacheObjects").transform;
                cacheObjects.SetParent(transform, false);
                cacheObjects.gameObject.SetActive(false);
            }

            CreateScreensFromResources(createSuccess =>
            {
                if (createSuccess)
                {
                    onComplete(true);
                }
                else
                {
                    onComplete(false);
                }
            }
            , SCREEN_OBJECT_INTRO
            , SCREEN_OBJECT_GAME_LANDSCAPE
            , SCREEN_OBJECT_GAME_PORTRAIT
            , SCREEN_OBJECT_LOBBY);
        }

        private void CreateScreensFromResources(Action<bool> onComplete, params string[] args)
        {
            string error = string.Empty;

            for (int i = 0; i < args.Length; i++)
            {
                string screenObjectName = args[i];

                if (cacheList.ContainsKey(screenObjectName))
                {
                    continue;
                }

                var prefab = Resources.Load(screenObjectName);
                if( prefab == null )
                {
                    error = string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0} Screen load failed.", screenObjectName);
                    break;
                }

                var screenObject = GameObject.Instantiate(prefab, cacheObjects) as GameObject;
                cacheList.Add(screenObjectName, screenObject);
            }

            if( string.IsNullOrEmpty(error) == true )
            {
                onComplete(true);
            }
            else
            {
                onComplete(false);
            }
        }

        private void CreateScreens(Gaga.AssetBundle.AssetBundle ab, Action<bool> onComplete, params string[] args)
        {
            for (int i = 0; i < args.Length; i++)
            {
                var screenObjectName = args[i];

                if (cacheList.ContainsKey(screenObjectName))
                {
                    continue;
                }

                var screenObject = ab.GetGameObject(screenObjectName, cacheObjects);

                if (screenObject == null)
                {
                    onComplete(false);
                    return;
                }
                else
                {
                    cacheList.Add(screenObjectName, screenObject);
                }
            }

            onComplete(true);
        }

        private void SetupBackgroundPanel(string popupLayerName)
        {
            RectTransform newPanel = new GameObject("BackgroundPanel").AddComponent<RectTransform>();
            newPanel.anchorMin = new Vector2(0, 0);
            newPanel.anchorMax = new Vector2(1, 1);
            newPanel.anchoredPosition = Vector2.zero;
            newPanel.sizeDelta = Vector2.zero;
            newPanel.SetParent(root, false);

            backgroundImage = newPanel.gameObject.AddComponent<Image>();
            backgroundImage.color = new Color(0, 0, 0, 0);
            backgroundImage.gameObject.SetActive(false);
            backgroundImage.gameObject.layer = LayerMask.NameToLayer(popupLayerName);
        }

        private void ShowBg()
        {
            backgroundImage.gameObject.SetActive(true);
        }

        private void HideBg()
        {
            backgroundImage.gameObject.SetActive(false);
        }

        private void Show<T1, T2>(string screenObjectName, Action<T1> onInit, Action onLoadBegin, Action<T2> onLoadComplete, Action onEnd) where T1 : BaseLoadingScreen<T2> where T2 : LoadingResult, new()
        {
            if (IsPreload() == false)
            {
                Debug.LogWarning("Preload first.");
                return;
            }

            Hide();
            ShowBg();

            if (cacheList.ContainsKey(screenObjectName))
            {
                var obj = cacheList[screenObjectName];
                obj.transform.SetParent(root, false);

                var loadingScene = obj.GetComponent<T1>();
                currentLoadingScreenObject = loadingScene.gameObject;

                if (onInit == null)
                {
                    loadingScene.Initialize();
                }
                else
                {
                    onInit(loadingScene as T1);
                }

                loadingScene.OnLoadBegin += () =>
                {
                    if (onLoadBegin != null)
                    {
                        onLoadBegin();
                    }
                };

                loadingScene.OnLoadComplete += result =>
                {
                    if (onLoadComplete != null)
                    {
                        onLoadComplete(result as T2);
                    }
                };

                loadingScene.OnExit += () =>
                {
                    HideBg();
                    Hide();

                    if (onEnd != null)
                    {
                        onEnd();
                    }
                };
            }
            else
            {
                SceneSystem.LoadIntro();
            }
        }

        public void Hide()
        {
            if (currentLoadingScreenObject == null)
            {
                return;
            }

            currentLoadingScreenObject.transform.SetParent(cacheObjects, false);
            currentLoadingScreenObject = null;
        }

        public void IntroLoading(Action onLoadBegin, Action<LoadingResult> onLoadComplete, Action onEnd = null, string SceneName = "")
        {
            SetOrientation(ScreenSystem.Orientation.Landscape);

            Show<IntroLoadingScreen, LoadingResult>(SCREEN_OBJECT_INTRO,
                                    loading =>
                                    {
                                        loading.Initialize(SceneName);
                                    },
                                    onLoadBegin,
                                    onLoadComplete,
                                    onEnd);
        }

        private void SetOrientation(ScreenSystem.Orientation orientation)
        {
            CanvasScaler canvasScaler = GetComponentInChildren<CanvasScaler>();

            if (orientation == ScreenSystem.Orientation.Landscape)
            {
                ScreenSystem.Instance.SetLandscape();

                if (canvasScaler != null)
                {
                    if (canvasScaler.referenceResolution.x < canvasScaler.referenceResolution.y)
                    {
                        canvasScaler.referenceResolution = new Vector2(canvasScaler.referenceResolution.y, canvasScaler.referenceResolution.x);
                    }
                }
            }
            else if (orientation == ScreenSystem.Orientation.Portrait)
            {
                ScreenSystem.Instance.SetPortrait();

                if (canvasScaler != null)
                {
                    if (canvasScaler.referenceResolution.x > canvasScaler.referenceResolution.y)
                    {
                        canvasScaler.referenceResolution = new Vector2(canvasScaler.referenceResolution.y, canvasScaler.referenceResolution.x);
                    }
                }
            }
        }

        public void GameLoading(string slotID, bool isLandscape, SlotCardSkin poster, Action onLoadBegin, Action<GameLoadingResult> onLoadComplete, Action onEnd = null, string SceneName = "")
        {
            var screenObjectName = SCREEN_OBJECT_GAME_LANDSCAPE;

            if(isLandscape)
            {
                SetOrientation(ScreenSystem.Orientation.Landscape);
            }
            else
            {
                SetOrientation(ScreenSystem.Orientation.Portrait);
                screenObjectName = SCREEN_OBJECT_GAME_PORTRAIT;
            }

            Show<GameLoadingScreen, GameLoadingResult>(screenObjectName,
                                    loading =>
                                    {
                                        loading.Initialize(slotID, poster, SceneName);
                                    },
                                    onLoadBegin,
                                    onLoadComplete,
                                    onEnd);
        }

        public void LobbyLoading(Action onLoadBegin, Action<LoadingResult> onLoadComplete, Action onEnd = null, string SceneName = "")
        {
            SetOrientation(ScreenSystem.Orientation.Landscape);

            Show<LobbyLoadingScreen, LoadingResult>(SCREEN_OBJECT_LOBBY,
                                    loading =>
                                    {
                                        loading.Initialize(SceneName);
                                    },
                                    onLoadBegin,
                                    onLoadComplete,
                                    onEnd);
        }
    }
}