using Gaga;
using System.Collections;
using Underc;
using Underc.LoadingScreen;
using Underc.Net;
using Underc.Net.Client;
using Underc.User;
using Underc.Util;
using UnityEngine;

public class TestAdminEventSystem : TestSceneScaffold
{
    [SerializeField] private bool useFakeData = true;
    private ulong beginningTime;
    private ulong nextDay;

    private IEnumerator Start()
    {
        Init();

        yield return SetupAndLoad(new BaseLoadingItem[]
        {
            new LoginLoadingItem(),
            new TopUILoadingItem(),
            new ABLoadingItem(AssetBundleName.EFFECT)
        });

        ResetTime();
    }

    private void Init()
    {
        AdminEventSystem.Instance.Initialize();
    }

    private void ResetTime()
    {
        beginningTime = (ulong)GlobalTime.Instance.GetTimeStamp();
        nextDay = beginningTime + 60 * 60 * 24;

        AdminEventSystem.Instance.DontShowCoolTime = 10;
    }

    public void LoadAdminEvent()
    {
        var response = new AdminEventResponse();
        response.data = new AdminEventData[]
        {
            new AdminEventData(){
                id = 6,
                win_type = "100",
                cur = 1,
                win_count = 3,
                img = "http://10.145.128.49:80/images/event/6.png",
                btn = "hi",
                target1 = (int)TargetToMove.Slot,
                target2 = 1001,
                start_ts = beginningTime,
                end_ts = nextDay,
                reward = 100000000,
                ver = ""
            },
            new AdminEventData(){
                id = 7,
                win_type = "100",
                cur = 100,
                win_count = 3,
                img = "http://10.145.128.49:80/images/event/6.png",
                btn = "hoi",
                target1 = (int)TargetToMove.Slot,
                target2 = 1002,
                start_ts = beginningTime,
                end_ts = nextDay,
                reward = 100000000,
                ver = ""
            },
        };

        FakeHttpRequester.Instance.LoadedAdminEventResponse = response;

        StartCoroutine(LoadAndShow());
    }

    private IEnumerator LoadAndShow()
    {
        IRequest<AdminEventResponse> req;
        if (useFakeData)
        {
            req = FakeHttpRequester.Instance.AdminEvent();
        }
        else
        {
            req = NetworkSystem.HTTPRequester.Event();
        }
        yield return req.WaitForResponse();

        AdminEventSystem.Instance.SetData(req.data.data);

        if (AdminEventSystem.Instance.HasData == true)
        {
            yield return AdminEventSystem.Instance.Show();
        }
    }
}
