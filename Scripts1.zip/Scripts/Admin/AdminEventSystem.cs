using Gaga;
using Gaga.System;
using Gaga.Util;
using System;
using System.Collections;
using System.Collections.Generic;
using Underc.Popup;
using UnityEngine;
using static Gaga.Util.CustomYield;

namespace Underc
{
    public class AdminEventSystem : GameObjectSingleton<AdminEventSystem>
    {
        public bool HasData
        {
            get
            {
                return cachedDatas.Count > 0;
            }
        }

        public bool CheckOnce
        {
            get;
            private set;
        }

        public int DontShowCoolTime
        {
            private get;
            set;
        } = 60 * 60 * 24;

        private const string KEY_DONT_SHOW_TIMESTAMP = "k_dont_show_e";
        private const char TIMESTAMP_SEPARATOR = '_';
        private const char DATA_SEPARATOR = ',';

        private Dictionary<long, long> dontShowTimestamps;
        private List<AdminEventData> cachedDatas;
        private Queue<AdminEventData> showQueue;
        private SimpleWaitForDone waitForDone;
        private Action onComplete;
        
        public void Initialize()
        {
            dontShowTimestamps = new Dictionary<long, long>();
            cachedDatas = new List<AdminEventData>();
            showQueue = new Queue<AdminEventData>();
            waitForDone = new SimpleWaitForDone();
        }

        public void SetData(AdminEventData[] datas)
        {
            CacheData(datas);
            LoadDontShowSettings();
        }

        public CustomYieldInstruction Show(Action onComplete = null)
        {
            waitForDone.Ready();

            StartCoroutine(ShowCoroutine(() =>
            {
                onComplete?.Invoke();
                waitForDone.Done();
            }));

            return waitForDone;
        }

        public IEnumerator ShowCoroutine(Action onComplete = null)
        {
            GlobalTime globalTime = GlobalTime.Instance;

            showQueue.Clear();
            foreach (AdminEventData data in cachedDatas)
            {
                // check don't show
                long timestamp;
                if (dontShowTimestamps.TryGetValue(data.id, out timestamp) == true
                    && IsInDontShow(timestamp) == true)
                {
                    continue;
                }

                // 
                Debug.Log($"==== id : {data.id}, startRemainingTime : {globalTime.SecondDiff((long)data.start_ts)}, endRemaningTime : {globalTime.SecondDiff((long)data.end_ts)}");
                if (globalTime.SecondDiff((long)data.start_ts) > 0   // 시작 시간 전이거나
                    || globalTime.SecondDiff((long)data.end_ts) <= 0)// 종료 시간 이후이면
                {
                    continue;
                }

                showQueue.Enqueue(data);
            }

            while (showQueue.Count > 0)
            {
                AdminEventData data = showQueue.Dequeue();

                UndercLink.UndercLinkActionType actionType = UndercLink.UndercLinkActionType.None;
                yield return Popups.AdminEvent(
                    data: data,
                    onExecute: (needToUpdate) =>
                    {
                        if (needToUpdate == true)
                        {
                            AppService.OpenStore();
                            actionType = UndercLink.UndercLinkActionType.Exit;
                        }
                        else
                        {
                            actionType = UndercLink.EstimateAction(data.target1, data.target2, data.link);
                        }
                    },
                    onComplete: (dontShow) =>
                    {
                        if (dontShow == true)
                        {
                            dontShowTimestamps.Add(data.id, GlobalTime.Instance.GetTimeStamp());
                        }
                    }
                ).WaitForClose();

                if (actionType == UndercLink.UndercLinkActionType.Exit)
                {
                    break;
                }
                else if (actionType == UndercLink.UndercLinkActionType.IEnumerator)
                {
                    yield return UndercLink.DoAction(data.target1, data.target2, data.link);
                }
            }

            SaveDontShowSettings();
            onComplete?.Invoke();

            yield break;
        }

        private void CacheData(AdminEventData[] datas)
        {
            cachedDatas.Clear();

            if (datas != null)
            {
                cachedDatas.AddRange(datas);
            }
        }

        private void SaveDontShowSettings()
        {
            if (dontShowTimestamps.Count == 0)
            {
                UndercPrefs.DeleteLocalValue(KEY_DONT_SHOW_TIMESTAMP);
            }
            else
            {
                var timestampValueStrs = new List<string>();
                foreach (KeyValuePair<long, long> pair in dontShowTimestamps)
                {
                    long id = pair.Key;
                    long timestamp = pair.Value;

                    string timestampValueStr = StringMaker.New()
                                                          .Append(id.ToString())
                                                          .Append(TIMESTAMP_SEPARATOR.ToString())
                                                          .Append(timestamp.ToString())
                                                          .Build();
                    timestampValueStrs.Add(timestampValueStr);
                }

                string dontShowTimestampValue = timestampValueStrs.ToEachString(DATA_SEPARATOR.ToString());
                UndercPrefs.SetLocalValue(KEY_DONT_SHOW_TIMESTAMP, dontShowTimestampValue);
                Debug.LogFormat($"==== NoticeSystem SaveToggleData: {dontShowTimestampValue}");
            }
        }

        private void LoadDontShowSettings()
        {
            dontShowTimestamps.Clear();

            string dontShowTimestampValue = UndercPrefs.GetLocalValue(KEY_DONT_SHOW_TIMESTAMP, "");
            if (string.IsNullOrEmpty(dontShowTimestampValue) == false)
            {
                string[] timestampValueStrs = dontShowTimestampValue.Split(',');
                foreach (string timestampValueStr in timestampValueStrs)
                {
                    if (string.IsNullOrEmpty(timestampValueStr) == true)
                    {
                        continue;
                    }

                    string[] timestampValue = timestampValueStr.Split('_');
                    if (timestampValue.Length < 2)
                    {
                        continue;
                    }

                    long id;
                    long timestamp;
                    if (long.TryParse(timestampValue[0], out id) == false
                        || long.TryParse(timestampValue[1], out timestamp) == false)
                    {
                        continue;
                    }

                    if (IsInDontShow(timestamp) == true)
                    {
                        dontShowTimestamps.Add(id, timestamp);
                    }
                }
            }
        }

        private bool IsInDontShow(long timestamp)
        {
            long now = GlobalTime.Instance.GetTimeStamp();
            long seconds = now - timestamp;
            Debug.Log($"==== IsInDontShow : {seconds}");
            return seconds < DontShowCoolTime;
        }

    }
}
