using Gaga.Popup;
using System.Collections;
using Underc.Lobby;
using Underc.Popup;
using UnityEngine;

namespace Underc
{
    public static class UndercLink
    {
        public enum UndercLinkActionType
        {
            None,
            IEnumerator,
            Exit,
        }

        public static UndercLinkActionType EstimateAction(int target1, int target2, string link = "")
        {
            UndercLinkActionType actionType = UndercLinkActionType.None;

            if (System.Enum.IsDefined(typeof(TargetToMove), target1) == false)
            {
                Debug.LogWarningFormat("NoticeSystem target1 '{0}' not defiend.", target1);
            }
            else if (target1 == (int)TargetToMove.None)
            {
            }
            else
            {
                TargetToMove location = (TargetToMove)target1;
                switch (location)
                {
                    case TargetToMove.Shop:
                        actionType = UndercLinkActionType.IEnumerator;
                        break;

                    case TargetToMove.Grow:
                        actionType = UndercLinkActionType.IEnumerator;
                        break;

                    case TargetToMove.OceanStory:
                        actionType = UndercLinkActionType.IEnumerator;
                        break;

                    case TargetToMove.Slot:
                        actionType = UndercLinkActionType.Exit;
                        PlaySlot(target2.ToString());
                        break;

                    case TargetToMove.Inbox:
                        actionType = UndercLinkActionType.IEnumerator;
                        break;

                    case TargetToMove.Url:
                        actionType = UndercLinkActionType.None;
                        OpenUrl(link);
                        break;
                }
            }

            Debug.Log($"==== GoTo : {target1}, {target2}, {actionType}");
            return actionType; 
        }

        public static IEnumerator DoAction(int target1, int target2, string link = "")
        {
            TargetToMove location = (TargetToMove)target1;
            switch (location)
            {
                case TargetToMove.Shop:
                    yield return OpenShop();
                    break;

                case TargetToMove.Grow:
                    yield return OpenGrow(target2);
                    break;

                case TargetToMove.OceanStory:
                    yield return OpenStoryMap(target2);
                    break;

                case TargetToMove.Inbox:
                    yield return OpenInbox();
                    break;
            }

            yield break;
        }

        private static IEnumerator OpenShop()
        {
            yield return Popups.Shop().Async().Cache().WaitForClose();
        }

        private static void OpenUrl(string url)
        {
            AppService.OpenUrl(url);
        }

        private static IEnumerator OpenGrow(int tab)
        {
            // 서버값은 1 부터 시작
            int tabIndex = tab - 1;
            if (tabIndex < -1)
            {
                //GrowPopupTab enum 에는 -1 도 존재
                tabIndex = -1;
            }

            if (System.Enum.IsDefined(typeof(FishStorePopupTabIndex), tabIndex) == false)
            {
                Debug.LogWarningFormat("NoticeSystem grow failed.. invalid tab index '{0}'", tabIndex);
            }
            else
            {
                FishStorePopupTabIndex growPopupTabIndex = (FishStorePopupTabIndex)tabIndex;
                Popups.FishStore(growPopupTabIndex)
                      .Async()
                      .Cache()
                      .WaitForClose();
            }

            yield break;
        }

        private static IEnumerator OpenStoryMap(int page)
        {
            var lobbyManager = GameObject.FindObjectOfType<LobbyManager>();
            if (lobbyManager == null 
                || lobbyManager.CurrentState != LobbyManager.State.ExecuteOcean)
            {
                Debug.LogWarning("NoticeSystem oceanSgtory failed. open only at 'ExecuteOcean' state");
            }
            else
            {
                int chapterIndex = page - 1;
                PopupObject<StoryMapPopup> storyMapPopup = lobbyManager.OceanLobby.OpenOcean(chapterIndex);
                yield return storyMapPopup.WaitForClose();
            }

            yield break;
        }

        private static IEnumerator OpenInbox()
        {
            yield return Popups.GameProfile(tabIndex: 2)
                               .Async()
                               .Cache()
                               .WaitForClose();
        }

        private static void PlaySlot(string slotID)
        {
            var lobbyManager = GameObject.FindObjectOfType<LobbyManager>();
            var slotListView = GameObject.FindObjectOfType<SlotListView>();

            if (lobbyManager == null || slotListView == null || lobbyManager.CurrentState != LobbyManager.State.ExecuteGame)
            {
                Debug.LogWarning("NoticeSystem playSlot failed. play only at 'ExecuteGame' state in gamelobby");
                return;
            }

            lobbyManager.PlayGame(slotID);
        }
    }
}