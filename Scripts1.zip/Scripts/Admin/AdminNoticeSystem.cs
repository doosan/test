#if DEV && UNITY_EDITOR
//#define TEST_NOTICE
#endif

using System.Collections;
using System.Collections.Generic;
using Gaga.System;
using Underc.Popup;
using UnityEngine;
using System;
using Gaga;
using Gaga.Util;
using Gaga.Popup;
using Underc.User;

namespace Underc
{
    /*
    1. 공지팝업의 닫기 버튼은 타 팝업들처럼 공지이미지와는 별개로 스크린 우측 상단에 고정한다.
    2. 유발하는 버튼은 공지이미지의 디자인, 크기와 연관되지 않고 미리 서로가 약속한 위치에 항상 있다. 위치를 고려하여 공지 이미지를 디자인한다.
    3. 공지 팝업을 통해 이동할 때 "바다 > 슬롯" or "슬롯 > 바다" 등 컨텍스트 자체를 변경하는 이동은 하지 않는다. 어드민페이지에서 설정할 때 이를 고려하여 설정.
    4. 위치에서 다수의 공지 팝업이 준비 된 경우 특정 공지 팝업을 눌러 이동하면 그 뒤 공지팝업은 스킵된다
    */
    public class AdminNoticeSystem : GameObjectSingleton<AdminNoticeSystem>
    {
        public enum PlacementType
        {
            Ocean = 1,
            Lobby,
            Slot
        }

        private const string KEY_TOGGLED_LIST = "k_ntc_tg_l";
        private const char ID_TS_SEPARATOR = '_';
        private const char DATA_SEPARATOR = ',';

        private Dictionary<PlacementType, bool> noticeFlagDic;

        private bool toggleChanged;
        private List<AdminNoticeData> dataList;

        private Queue<AdminNoticeData> showQueue;
        private Dictionary<uint, long> toggledDic;

        private CustomYield.WaitForComplete waitForComplete;

        public bool HasData { get => dataList != null && dataList.Count > 0; }

        public void Initialize()
        {
            noticeFlagDic = new Dictionary<PlacementType, bool>();
            dataList = new List<AdminNoticeData>();
            showQueue = new Queue<AdminNoticeData>();
            toggledDic = new Dictionary<uint, long>();

            waitForComplete = new CustomYield.WaitForComplete();
        }

        public void SetData(AdminNoticeData[] datas)
        {
            Debug.LogFormat("SetNotice");

#if TEST_NOTICE
            datas = CreateTestDatas();
#endif

            SetupNewSlotGameInfo(datas);
            CacheData(datas);
            LoadToggleData();
        }

        // MyInfo.SlotGame에 popupID에 해당하는 newSlotInfo를 등록 함
        private void SetupNewSlotGameInfo(AdminNoticeData[] datas)
        {
            foreach (var data in datas)
            {
                if (data.target1 == (int)TargetToMove.Slot)
                {
                    int popupID = (int)data.id;
                    string slotID = data.target2.ToString();
                    MyInfo.SlotGame.CheckAndCreateNewSlotInfo(popupID, slotID);
                }
            }
        }

        private void CacheData(AdminNoticeData[] datas)
        {
            dataList.Clear();

            if (datas == null)
            {
                return;
            }

            for (int i = 0; i < datas.Length; ++i)
            {
                var data = datas[i];

                if (Enum.IsDefined(typeof(PlacementType), data.pos) == false)
                {
                    Debug.LogWarningFormat("NoticeSystem invalid notcie data. pos '{0}' not defiend.", data.pos);
                    continue;
                }

                dataList.Add(data);
            }
        }

        private Queue<AdminNoticeData> FindData(PlacementType findType)
        {
            showQueue.Clear();

            for (int i = 0; i < dataList.Count; ++i)
            {
                var data = dataList[i];

                PlacementType placementType = (PlacementType)data.pos;
                if (placementType != findType)
                {
                    continue;
                }

                if (IsDontShowID(data.id) == true)
                {
                    continue;
                }

                showQueue.Enqueue(data);
            }

            return showQueue;
        }

        //특정 위치의 공지를 열었었는지에 대한 flag. true 이면 열어본 상태
        private bool GetNoticeFlag(PlacementType placementType)
        {
            if (noticeFlagDic.ContainsKey(placementType) == false)
            {
                return false;
            }
            else
            {
                return noticeFlagDic[placementType];
            }
        }

        private void SetNoticeFlag(PlacementType placementType, bool flag)
        {
            if (noticeFlagDic.ContainsKey(placementType) == false)
            {
                noticeFlagDic.Add(placementType, flag);
            }
            else
            {
                noticeFlagDic[placementType] = flag;
            }
        }

        public CustomYieldInstruction ShowOceanNotice(Action onComplete = null)
        {
            return ShowNotice(PlacementType.Ocean, onComplete);
        }

        public void ExitOcean()
        {
            SetNoticeFlag(PlacementType.Ocean, false);
        }

        public CustomYieldInstruction ShowLobbyNotice(Action onComplete = null)
        {
            return ShowNotice(PlacementType.Lobby, onComplete);
        }

        public void ExitLobby()
        {
            SetNoticeFlag(PlacementType.Lobby, false);
        }

        public CustomYieldInstruction ShowSlotNotice(Action onComplete = null)
        {
            return ShowNotice(PlacementType.Slot, onComplete);
        }

        public void ExitSlot()
        {
            SetNoticeFlag(PlacementType.Slot, false);
        }

        private CustomYieldInstruction ShowNotice(PlacementType placeType, Action onComplete = null)
        {
            waitForComplete.Ready();

            if (GetNoticeFlag(placeType) == true || HasData == false)
            {
                onComplete?.Invoke();
                waitForComplete.Done();
            }
            else
            {
                SetNoticeFlag(placeType, true);
                StartCoroutine(ShowNoticeCoroutine(placeType, () =>
                {
                    onComplete?.Invoke();
                    waitForComplete.Done();
                }));
            }

            return waitForComplete;
        }

        private IEnumerator ShowNoticeCoroutine(PlacementType placeType, Action onComplete = null)
        {
            Queue<AdminNoticeData> queue = FindData(placeType);
            
            while (queue.Count > 0)
            {
                AdminNoticeData data = queue.Dequeue();

                UndercLink.UndercLinkActionType actionType = UndercLink.UndercLinkActionType.None;
                yield return Popups.AdminNotice(
                    data,
                    onExecute: (needToUpdate) =>
                    {
                        if (needToUpdate == true)
                        {
                            AppService.OpenStore();
                            actionType = UndercLink.UndercLinkActionType.Exit;
                        }
                        else
                        {
                            actionType = UndercLink.EstimateAction(data.target1, data.target2, data.link);
                        }
                    },
                    onComplete: (toggleOn) =>
                    {
                        if (toggleOn == true)
                        {
                            toggleChanged = true;
                            toggledDic.Add(data.id, GlobalTime.Instance.GetTimeStamp());
                        }
                    }
                ).WaitForClose();

                if (actionType == UndercLink.UndercLinkActionType.Exit)
                {
                    break;
                }
                else if (actionType == UndercLink.UndercLinkActionType.IEnumerator)
                {
                    yield return UndercLink.DoAction(data.target1, data.target2, data.link);
                }
            }

            if (toggleChanged == true) SaveToggleData();
            onComplete?.Invoke();

            yield break;
        }

        private bool IsDontShowID(uint id)
        {
            long ts;
            if (toggledDic.TryGetValue(id, out ts))
            {
                var now = GlobalTime.Instance.GetTimeStamp();
                TimeSpan elapsedTime = TimeSpan.FromSeconds(now - ts);

                if (IsAlreadyPassed(elapsedTime) == true)
                {
                    Debug.LogFormat("NoticeSystem {0} already passed toggleTim.e elapsedSeconds: {1}", id, elapsedTime.TotalSeconds);
                    toggledDic.Remove(id);
                    return false;
                }
                else
                {
                    Debug.LogFormat("NoticeSystem {0} can't open", id);
                    return true;
                }
            }
            else
            {
                return false;
            }
        }

        private bool IsAlreadyPassed(TimeSpan elapsedTime)
        {
            // if (elapsedTime.TotalMinutes >= 1)
            if (elapsedTime.TotalHours >= 24)
            {
                toggleChanged = true;
                return true;
            }
            else
            {
                return false;
            }
        }

        private void LoadToggleData()
        {
            toggledDic.Clear();

            var loadedDataStr = UndercPrefs.GetLocalValue(KEY_TOGGLED_LIST, null);
            if (string.IsNullOrEmpty(loadedDataStr) == true)
            {
                return;
            }

            string[] loadedDataArr = loadedDataStr.Split(DATA_SEPARATOR);
            var now = GlobalTime.Instance.GetTimeStamp();

            for (int i = 0; i < loadedDataArr.Length; ++i)
            {
                var toggleData = loadedDataArr[i];
                if (string.IsNullOrEmpty(toggleData) == true)
                {
                    continue;
                }

                var kv = toggleData.Split(ID_TS_SEPARATOR);
                if (kv.Length < 2)
                {
                    continue;
                }

                uint id;
                long ts;
                if (uint.TryParse(kv[0], out id) == false ||
                    long.TryParse(kv[1], out ts) == false)
                {
                    continue;
                }

                TimeSpan elapsedTime = TimeSpan.FromSeconds(now - ts);

                if (IsAlreadyPassed(elapsedTime) == true)
                {
                    continue;
                }

                toggledDic.Add(id, ts);
            }
        }

        private void SaveToggleData()
        {
            toggleChanged = false;

            if (toggledDic.Count == 0)
            {
                DeleteToggleData();
                return;
            }

            var helperList = new List<string>();
            foreach (var kv in toggledDic)
            {
                uint id = kv.Key;
                long ts = kv.Value;

                var toggleData = string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0}{1}{2}", id, ID_TS_SEPARATOR, ts);
                helperList.Add(toggleData);
            }

            var saveData = helperList.ToEachString(DATA_SEPARATOR.ToString());
            Debug.LogFormat("NoticeSystem SaveToggleData: {0}", saveData);
            UndercPrefs.SetLocalValue(KEY_TOGGLED_LIST, saveData);
        }

        private void DeleteToggleData()
        {
            Debug.Log("NoticeSystem DeleteToggleData");
            UndercPrefs.DeleteLocalValue(KEY_TOGGLED_LIST);
        }

        private AdminNoticeData[] CreateTestDatas()
        {
            AdminNoticeData[] datas = new AdminNoticeData[]
            {
                new AdminNoticeData(){
                    id = 1,
                    pos = (int)PlacementType.Ocean,
                    img = "https://c2.img.netmarble.kr/web/netmarble/sns.jpg",
                    btn = "OceanLobby_1",
                    target1 = (int)TargetToMove.Shop,
                    target2 = 2,
                    ver = "0.1.19"
                },
                new AdminNoticeData(){
                    id = 2,
                    pos = (int)PlacementType.Ocean,
                    img = "https://file.gamejob.co.kr/net/Corp/CoImage/LogoView?FN=2020\\5\\GJ_CoLogo_16291788.png",
                    btn = "OceanLobby_2",
                    target1 = (int)TargetToMove.Grow,
                    target2 = 1,
                    ver = "1.1.19"
                },

                new AdminNoticeData(){
                    id = 3,
                    pos = (int)PlacementType.Ocean,
                    img = "https://i.ytimg.com/vi/JA8dbIuaZZw/hqdefault.jpg",
                    btn = "OceanLobby_3",
                    target1 = (int)TargetToMove.None,
                    target2 = 3
                },
                new AdminNoticeData(){
                    id = 10,
                    pos = (int)PlacementType.Slot,
                    img = "https://images-na.ssl-images-amazon.com/images/I/61p7mgi0GAL._AC_SY355_.jpg",
                    btn = "SlotLobby_1",
                    target1 = (int)TargetToMove.Shop,
                    target2 = 1,
                },
                new AdminNoticeData(){
                    id = 11,
                    pos = (int)PlacementType.Slot,
                    img = "https://lh3.googleusercontent.com/Ba8FA8irG-GKXJnp-qNq-euXWntF-v423HBFnZsjJI0ZOmMv8DcQm7PuqL9bECaAtCo",
                    btn = "Slot_1",
                    target1 = (int)TargetToMove.None,
                    target2 = 1020,
                },
                new AdminNoticeData(){
                    id = 101,
                    pos = (int)PlacementType.Lobby,
                    img = "http://10.145.128.49/images/notice/28.jpg",
                    btn = "gypark notice inbox",
                    target1 = (int)TargetToMove.Inbox,
                    target2 = 0,
                },
                new AdminNoticeData(){
                    id = 100,
                    pos = (int)PlacementType.Lobby,
                    img = "http://10.145.128.49/images/notice/30.png",
                    btn = "gypark notice",
                    target1 = (int)TargetToMove.Slot,
                    target2 = 1042,
                },
            };

            return datas;
        }
    }
}

