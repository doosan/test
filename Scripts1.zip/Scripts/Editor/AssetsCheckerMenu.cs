using UnityEngine;
using System.Collections.Generic;
using UnityEditor;
using Gaga.Util;

namespace Underc
{
    public class AssetsCheckerMenu
    {
        private const float NAME_WIDTH = 170f;
        private const float LINE_HEIGHT = 20f;
        public float Width
        {
            get
            {
                return NAME_WIDTH + 10;
            }
        }

        private Vector2 scrollPosition = Vector2.zero;
        private GUISkin mySkin;
        private List<BaseAssetsChecker> items;
        public int CurrentIndex{get; private set;}
        private float marginY;

        public AssetsCheckerMenu(List<BaseAssetsChecker> items)
        {
            CurrentIndex = 0;
            this.items = items;
            mySkin = EditorResources.Load<GUISkin>("SlotPresetMakerSkin");
        }
     
        public void Draw(float marginY)
        {
            this.marginY = marginY;
            EditorGUILayout.BeginVertical(mySkin.GetStyle("normal_line"), GUILayout.Width(Width));
            DrawList();
            EditorGUILayout.EndVertical();

            var clickIndex = GetIndexAtMouseClick();
            if (clickIndex > -1)
            {
                CurrentIndex = clickIndex;
            }
        }

        private int GetIndexAtMouseClick()
        {
            int index = -1;

            if (Event.current.mousePosition.x < Width 
                && Event.current.mousePosition.y > marginY
                && Event.current.mousePosition.y < marginY + ((LINE_HEIGHT+1) * items.Count)
                && Event.current.type == EventType.MouseDown)
            {
                Event.current.Use();

                index = (int)((scrollPosition.y + Event.current.mousePosition.y - marginY) / (LINE_HEIGHT + 1));
                index = Mathf.Clamp(index, 0, items.Count);
            }

            return index;
        }

        private void DrawList()
        {
            scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition, false, false);

            for (int index = 0; index < items.Count; index++)
            {
                var item = items[index];
                bool isCurrentItem = CurrentIndex == index;
                string lineStyle = isCurrentItem ? "selected_line" : "normal_line" ;
                EditorGUILayout.BeginHorizontal(mySkin.GetStyle(lineStyle), 
                                                GUILayout.Height(LINE_HEIGHT));

                Color color = item.IsValid == true ? Color.white : Color.red;
                MyGUILayout.LabelField(item.GetTitle(), NAME_WIDTH, TextAnchor.MiddleLeft, color);

                EditorGUILayout.EndHorizontal();
            }

            EditorGUILayout.EndScrollView();
        }
    }
}