using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using Gaga.Util;

namespace Underc
{
    public class AssetsCheckerWindow : EditorWindow
    {
        private readonly float TOP_MARGIN = 40.0f;

        private List<BaseAssetsChecker> items;
        private GUISkin mySkin;
        private AssetsCheckerMenu menu;
        
        [MenuItem("Underc/Assets Checker",false, 31)]
        private static void ShowWindow()
        {
            AssetsCheckerWindow window = (AssetsCheckerWindow)GetWindow(typeof(AssetsCheckerWindow)
                                                                        ,false
                                                                        ,"Assets Checker");
            window.Show();
        }

        private void OnEnable()
        {
            Initialize();
        }

        private void Initialize()
        {
            if (items != null)
            {
                return;
            }

            mySkin = EditorResources.Load<GUISkin>("SlotPresetMakerSkin");

            SetupItems();
            SetupMenu();           

            UpdateItems();
        }

        private void SetupItems()
        {
            items = new List<BaseAssetsChecker>();
            items.Add(new GameAssetsChecker());
            items.Add(new SeaAssetsChecker());
        }

        private void SetupMenu()
        {
            menu = new AssetsCheckerMenu(items);
        }

        private void UpdateItems()
        {
            for (int i = 0; i < items.Count; i++)
            {
                items[i].Update();
            }
        }

        private void OnGUI()
        {
            Color backgroundColor = new Color(0.0f, 0.0f, 0.0f, 0.2f);
            var r = new Rect(0, 0, EditorGUIUtility.currentViewWidth, TOP_MARGIN + 5);
            EditorGUI.DrawRect(r, backgroundColor);

            EditorGUILayout.BeginVertical(GUILayout.Height(TOP_MARGIN));
            EditorGUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("Refresh", GUILayout.Width(150.0f), GUILayout.Height(TOP_MARGIN)))
            {
                UpdateItems();
            }
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.EndVertical();

            EditorGUILayout.BeginHorizontal(mySkin.GetStyle("normal_box"));

            menu.Draw(TOP_MARGIN + 5);
            EditorGUILayout.Space();

            if (menu.CurrentIndex > -1)
            {
                items[menu.CurrentIndex].Draw(EditorGUIUtility.currentViewWidth - menu.Width);
            }

            EditorGUILayout.EndHorizontal();
        }
    }
}