using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using Gaga.Util;
using System;
using UnityEditor.SceneManagement;

namespace Underc
{
    public class TestSceneViewer : EditorWindow
    {
        private enum ItemType
        {
            Recent,
            All
        }

        private class TestSceneInfo
        {
            public string name;
            public string path;
        }

        private readonly string[] IGNORE_NAMES = new string[]{"unity-ui-extensions", "BitmapFontImporter", "UIParticle", "JsonDotNet"};
        private readonly int RECENT_COUNT = 4;

        private List<TestSceneInfo> testSceneInfos;
        private string searchText;
        private string selectedName;
        private ItemType selectedItemType = ItemType.All;
        private Vector2 scrollPos;
        private List<string> recentTestSceneNames;

        [MenuItem("Underc/TestScene Viewer",false, 31)]
        private static void ShowWindow()
        {
            TestSceneViewer window = (TestSceneViewer)GetWindow(typeof(TestSceneViewer)
                                                                ,false
                                                                ,"TestScene Viewer");
            window.Show();
        }

        private void OnFocus()
        {
            if (recentTestSceneNames == null)
            {
                recentTestSceneNames = new List<string>();
            }

            UpdateInfos();
            UpdateRecentTestSceneNames();
        }

        private void OnGUI()
        {
            if (testSceneInfos == null)
            {
                return;
            }

            Draw();
        }

        private void Draw()
        {
            EditorGUILayout.BeginVertical();
            
            if (recentTestSceneNames != null && recentTestSceneNames.Count > 0)
            {
                EditorGUILayout.Space(10);
                EditorGUILayout.LabelField("Recent Scenes");
                DrawRecentTestSceneList();
            }

            EditorGUILayout.Space(10);
            EditorGUILayout.LabelField("All Scenes");
            DrawSearchField();
            DrawAllTestSceneList();

            EditorGUILayout.EndVertical();
        }

        private void UpdateInfos()
        {
            testSceneInfos = new List<TestSceneInfo>();

            var sceneAssetsGuidList = AssetDatabase.FindAssets("t:SceneAsset");
            var sceneAssetsPathList = Array.ConvertAll<string, string>(sceneAssetsGuidList, AssetDatabase.GUIDToAssetPath);

            foreach (var path in sceneAssetsPathList)
            {
                SceneAsset asset = AssetDatabase.LoadAssetAtPath(path, typeof(SceneAsset)) as SceneAsset;

                bool isValid = true;
                
                if (asset.name.ToLowerInvariant().Contains("test"))
                {
                    foreach (var ignoreName in IGNORE_NAMES)
                    {
                        if (path.Contains(ignoreName))
                        {
                            isValid = false;
                            break;
                        }
                    }
                }
                else
                {
                    isValid = false;
                }

                if (isValid)
                {
                    // Debug.Log(asset.name + " , " + path);
                    testSceneInfos.Add(new TestSceneInfo(){name = asset.name, path = path});
                }
            }
        }

        private void AddRecentTestScene(string name)
        {
            if (recentTestSceneNames.Contains(name))
            {
                return;
            }

            recentTestSceneNames.Add(name);

            if (recentTestSceneNames.Count > RECENT_COUNT)
            {
                recentTestSceneNames.RemoveAt(0);
            }
        }

        private void UpdateRecentTestSceneNames()
        {
            recentTestSceneNames.RemoveAll(name => testSceneInfos.Find(info => info.name == name) == null);
        }

        private void DrawSearchField()
        {
            GUILayout.BeginHorizontal(GUI.skin.FindStyle("Toolbar"), GUILayout.Height(24));
            searchText = GUILayout.TextField(searchText, 
                                             GUI.skin.FindStyle("ToolbarSeachTextField"));
            if (GUILayout.Button("", GUI.skin.FindStyle("ToolbarSeachCancelButton")))
            {
                searchText = "";
                GUI.FocusControl(null);
            }
            GUILayout.Space(2f);
            GUILayout.EndHorizontal();
        }

        private void DrawTestSceneItem(ItemType itemType, TestSceneInfo info, bool ignoreSearchText)
        {
            bool isValid = ignoreSearchText
                           || string.IsNullOrEmpty(searchText)
                           || info.name.ToLowerInvariant().Contains(searchText.ToLowerInvariant());

            if (isValid)
            {
                EditorGUILayout.BeginHorizontal();

                GUIStyle alignedButton = new GUIStyle(GUI.skin.button);
                alignedButton.alignment = TextAnchor.MiddleLeft;
                alignedButton.padding.left = 14;

                bool isSelect = selectedName == info.name && selectedItemType == itemType;

                var tempColor = GUI.color;

                if (isSelect)
                {
                    GUI.color = Color.yellow;
                }

                if (GUILayout.Button(info.name, alignedButton, GUILayout.ExpandWidth(true), GUILayout.Height(30)))
                {
                    if (selectedName != info.name || selectedItemType != itemType)
                    {
                        selectedName = info.name;
                        selectedItemType = itemType;
                    }
                }

                if (isSelect)
                {
                    if (GUILayout.Button("Path", GUILayout.Width(50), GUILayout.Height(30)))
                    {
                        try
                        {
                            Selection.activeObject = AssetDatabase.LoadMainAssetAtPath(info.path);
                        }
                        catch (System.Exception){}
                    }

                    if (GUILayout.Button("Open", GUILayout.Width(50), GUILayout.Height(30)))
                    {
                        try
                        {
                            Selection.activeObject = AssetDatabase.LoadMainAssetAtPath(info.path);
                        }
                        catch (System.Exception){}

                        EditorSceneManager.OpenScene(info.path);
                        AddRecentTestScene(info.name);
                    }

                    if (UnityEditor.EditorApplication.isPlayingOrWillChangePlaymode == false)
                    {
                        GUI.color = Color.green;
                        // 재생 버튼
                        if (GUILayout.Button("Play", GUILayout.Width(50), GUILayout.Height(30)))
                        {
                            EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo();
                            EditorSceneManager.OpenScene(info.path);
                            AddRecentTestScene(info.name);

                            UnityEditor.EditorApplication.isPlaying = true;
                        }
                    }
                    else
                    {
                        GUI.color = Color.red;
                        // 정지 버튼
                        if (GUILayout.Button("Stop", GUILayout.Width(50), GUILayout.Height(30)))
                        {
                            UnityEditor.EditorApplication.isPlaying = false;
                        }
                    }
                }

                EditorGUILayout.EndHorizontal();

                GUI.color = tempColor;
            }
        }

        private void DrawRecentTestSceneList()
        {
            EditorGUILayout.BeginVertical();

            for (int i = 0; i < recentTestSceneNames.Count; i++)
            {
                var sceneName = recentTestSceneNames[i];
                var info = testSceneInfos.Find(data => data.name == sceneName);

                if (info != null)
                {
                    DrawTestSceneItem(ItemType.Recent, info, true);           
                }
            }

            EditorGUILayout.EndVertical();
        }

        private void DrawAllTestSceneList()
        {
            scrollPos = EditorGUILayout.BeginScrollView(scrollPos, false, false);
            EditorGUILayout.BeginVertical();

            for (int i = 0; i < testSceneInfos.Count; i++)
            {
                var info = testSceneInfos[i];
                DrawTestSceneItem(ItemType.All, info, false);           
            }

            EditorGUILayout.EndVertical();
            EditorGUILayout.EndScrollView();
        }
    }
}