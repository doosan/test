using UnityEngine;
using UnityEditor;
using Gaga.Util;
using Underc.Ocean;
using System.Collections.Generic;
using System;
using System.Linq;
using System.Text;
using Underc.Util;

namespace Underc
{
    public class SeaAssetsChecker : BaseAssetsChecker
    {
        private readonly string SEA_PATH = "Assets/0.UNDERC/Ocean/Sea/Assets/";
        private readonly string SEA_THUMBNAIL_PATH = "Assets/0.UNDERC/Ocean/SeaThumbnail/Assets/";

        private List<SeaAssetInfo> seaAssetInfos = new List<SeaAssetInfo>();
        private List<MissingName> missingNames = new List<MissingName>();
        private List<Texture> missingTextures = new List<Texture>();
        private string[] exceptions = new string[] { "Clam" };
        
        public SeaAssetsChecker():base()
        {
            seaAssetInfos.Clear();

            int seaID = 1;
            while (true)
            {
                string seaIdStr = seaID.ToString();

                //
                string seaPath = StringMaker.New()
                                            .Append(GetSeaPath(seaIdStr))
                                            .Append("/Sea.prefab")
                                            .Build();

                string seaThumbnailPath = StringMaker.New()
                                                     .Append(SEA_THUMBNAIL_PATH)
                                                     .Append(seaIdStr)
                                                     .Append("/SeaThumbnail_")
                                                     .Append(seaIdStr)
                                                     .Append(".prefab")
                                                     .Build();

                //
                if (string.IsNullOrEmpty(AssetDatabase.AssetPathToGUID(seaPath)) == false
                    || string.IsNullOrEmpty(AssetDatabase.AssetPathToGUID(seaThumbnailPath)) == false)
                {
                    seaAssetInfos.Add(new SeaAssetInfo(seaID, "Sea" + seaIdStr));
                }
                else
                {
                    break;
                }

                seaID += 1;
            }
        }

        public override string GetTitle()
        {
            return "Sea";
        }

        protected override int GetListCount()
        {
            return seaAssetInfos.Count;
        }

        protected override ListItem GetListItem(int index)
        {
            SeaAssetInfo seaAsset = seaAssetInfos[index];
            ListItem listItem = new ListItem();

            if (seaAsset != null)
            {
                string seaID = seaAsset.id.ToString();
                string name = StringMaker.New()
                                         .Append("(")
                                         .Append(seaID)
                                         .Append(")  ")
                                         .Append(seaAsset.name.ToString())
                                         .Build();

                listItem.name = name;

                listItem = CheckSea(seaID, listItem);
                listItem = CheckThumbnail(seaID, listItem);
            }
            else
            {
                listItem.AddMessage("프리셋 파일 누락");
            }

            bool hasError = string.IsNullOrEmpty(listItem.message) == false;
            listItem.state = hasError == true ? State.Error : State.Normal;

            return listItem;
        }

        private ListItem CheckSea(string seaID, ListItem listItem)
        {
            string dirPath = GetSeaPath(seaID);

            bool isValidFolder = AssetDatabase.IsValidFolder(dirPath);
            if (isValidFolder == true)
            {
                // 프리팹 체크
                GameObject seaPrefab = GetPrefab("Sea", seaID);
                if (seaPrefab == null)
                {
                    listItem.AddMessage("Sea 프리팹 누락");
                }
                else
                {
                    if (IsAssetbundlePrefab("sea", seaID) == false)
                    {
                        listItem.AddMessage("Sea 프리팹 에셋번들 미설정");
                    }

                    ReadMissingMaterialsAndTextures(seaPrefab);
                    WriteMissingNames(listItem, seaID);
                }

                // BGM
                if (CheckMissingBGM(seaID) == true)
                {
                    listItem.AddMessage("Sea 프리팹 아래 BGM 게임 오브젝트 할당 누락 ");
                }

                // 1 Star Animation
                if (CheckMissingOneStarAnimation(seaID) == true)
                {
                    listItem.AddMessage("Sea 프리팹의 AnimatorParser 컴포넌트 할당 누락 ");
                }

                // 미션 배너
                if (GetPrefab("SeaMissionBanner", seaID) == null)
                {
                    listItem.AddMessage("SeaMissionBanner 프리팹 누락");
                }
                else
                {
                    if (IsAssetbundlePrefab("SeaMissionBanner", seaID) == false)
                    {
                        listItem.AddMessage("SeaMissionBanner 프리팹 에셋번들 미설정");
                    }
                }

                // 미션 팝업
                if (GetPrefab("SeaMissionPopup", seaID) == null)
                {
                    listItem.AddMessage("SeaMissionPopup 프리팹 누락");
                }
                else
                {
                    if (IsAssetbundlePrefab("SeaMissionPopup", seaID) == false)
                    {
                        listItem.AddMessage("SeaMissionPopup 프리팹 에셋번들 미설정");
                    }
                }
            }
            else
            {
                listItem.AddMessage("Sea 폴더 누락");
            }

            return listItem;
        }

        private void WriteMissingNames(ListItem listItem, string seaID)
        {
            foreach (MissingName missingName in missingNames)
            {
                string type = missingName.values[0];
                string assetBundleName = missingName.values[1];
                if (string.IsNullOrEmpty(assetBundleName) == true) continue;

                string bundleSuffix = assetBundleName.Split('_')[1];
                if (bundleSuffix == seaID || bundleSuffix == "common") continue;
                
                string message = "";
                switch (type)
                {
                    case "m":
                    message = StringMaker.New()
                                         .Append("Sea 프리팹 ")
                                         .Append(WrapProperty(missingName.values[2]))
                                         .Append(" 게임 오브젝트의 ")
                                         .Append(WrapProperty(missingName.values[3]))
                                         .Append(" 머티리얼이 잘못된 에셋번들 경로 ")
                                         .Append(WrapProperty(assetBundleName))
                                         .Append(" 에 포함")
                                         .Build();
                    break;

                    case "t":
                    message = StringMaker.New()
                                         .Append("Sea 프리팹 ")
                                         .Append(WrapProperty(missingName.values[2]))
                                         .Append(" 게임 오브젝트의 ")
                                         .Append(WrapProperty(missingName.values[3]))
                                         .Append(" 머티리얼에 포함된 ")
                                         .Append(WrapProperty(missingName.values[4]))
                                         .Append(" 텍스처가 잘못된 에셋번들 경로 ")
                                         .Append(WrapProperty(assetBundleName))
                                         .Append(" 에 포함")
                                         .Build();
                    break;
                }

                listItem.AddMessage(message);
            }
        }
        
        private string WrapProperty(string value, string prefix = "", string suffix = "")
        {
            var sb = new StringBuilder();
            sb.Append(prefix);
            sb.Append(value);
            sb.Append(suffix);
            return sb.ToString();
        }

        private void ReadMissingMaterialsAndTextures(GameObject seaPrefab)
        {
            missingNames.Clear();
            Action<Renderer[]> _ReadMissingNames = (Renderer[] renderers) =>
            {
                foreach (var renderer in renderers)
                {
                    // Material 이 비었는지 확인
                    Material material = renderer.sharedMaterial;
                    if (material == null)
                    {
                        string rendererPath = AssetDatabase.GetAssetPath(renderer.GetInstanceID());
                        missingNames.Add(new MissingName("r", AssetDatabase.GetImplicitAssetBundleName(rendererPath), renderer.name));
                        continue;
                    }

                    if (material.name.Contains("Default")) continue;

                    // Material에 지정된 에셋 번들이 현재 바다의 ID와 일치하지 않는지 확인하기 위함
                    string materialPath = AssetDatabase.GetAssetPath(material.GetInstanceID());
                    missingNames.Add(new MissingName("m", AssetDatabase.GetImplicitAssetBundleName(materialPath), renderer.name, material.name));

                    // Texture에 지정된 에셋 번들이 현재 바다의 ID와 일치하지 않는지 확인하기 위함
                    missingTextures.Clear();
                    Shader shader = material.shader;
                    for (int i = 0; i < ShaderUtil.GetPropertyCount(shader); i++)
                    {
                        if (ShaderUtil.GetPropertyType(shader, i) != ShaderUtil.ShaderPropertyType.TexEnv) continue;

                        Texture texture = material.GetTexture(ShaderUtil.GetPropertyName(shader, i));
                        if (texture == null) continue;

                        missingTextures.Add(texture);
                    }
                    foreach (Texture texture in missingTextures)
                    {
                        string texturePath = AssetDatabase.GetAssetPath(texture.GetInstanceID());
                        missingNames.Add(new MissingName("t", AssetDatabase.GetImplicitAssetBundleName(texturePath), renderer.name, material.name, texture.name));
                    }
                }
            };
                
            _ReadMissingNames(seaPrefab.GetComponentsInChildren<ParticleSystemRenderer>());
            _ReadMissingNames(seaPrefab.GetComponentsInChildren<MeshRenderer>());
            _ReadMissingNames(seaPrefab.GetComponentsInChildren<SpriteRenderer>());
        }

        private bool CheckMissingBGM(string seaID)
        {
            bool result = false;

            GameObject seaPrefab = GetPrefab("Sea", seaID);
            if (seaPrefab != null)
            {
                Sea2D sea2D = seaPrefab.GetComponent<Sea2D>();
                result = sea2D.Bgm == null;
            }
            
            return result;
        }

        private bool CheckMissingOneStarAnimation(string seaID)
        {
            bool result = false;

            GameObject seaPrefab = GetPrefab("Sea", seaID);
            if (seaPrefab != null)
            {
                Sea2D sea2D = seaPrefab.GetComponent<Sea2D>();
                result = sea2D.StarAnimation == null;
            }

            return result;
        }

        private string GetSeaPath(string seaID)
        {
            return StringMaker.New()
                              .Append(SEA_PATH)
                              .Append("Sea")
                              .Append(seaID)
                              .Build();
        }

        private GameObject GetPrefab(string prefabName, string seaID)
        {
            string seaPath = GetSeaPath(seaID);
            string seaPrefabPath = StringMaker.New()
                                        .Append(seaPath)
                                        .Append("/")
                                        .Append(prefabName)
                                        .Append(".prefab")
                                        .Build();
            return (GameObject)AssetDatabase.LoadAssetAtPath(seaPrefabPath, typeof(GameObject));
        }

        private bool IsAssetbundlePrefab(string prefabName, string seaID)
        {
            string seaPath = GetSeaPath(seaID);
            string seaPrefabPath = StringMaker.New()
                                        .Append(seaPath)
                                        .Append("/")
                                        .Append(prefabName)
                                        .Append(".prefab")
                                        .Build();

            var importer = AssetImporter.GetAtPath(seaPrefabPath);
            return AssetBundleName.Sea(int.Parse(seaID)) == importer.assetBundleName;
        }

        private ListItem CheckThumbnail(string seaID, ListItem listItem)
        {
            string seaThumbnailPath = StringMaker.New()
                                                 .Append(SEA_THUMBNAIL_PATH)
                                                 .Append(seaID)
                                                 .Append("/SeaThumbnail_")
                                                 .Append(seaID)
                                                 .Append(".prefab")
                                                 .Build();

            var thumbPrefab = AssetDatabase.LoadAssetAtPath(seaThumbnailPath, typeof(GameObject));
            if (thumbPrefab == null)
            {
                listItem.AddMessage("SeaThumbnail 프리팹 누락");
            }

            return listItem;
        }
    }

    public class SeaAssetInfo
    {
        public int id;
        public string name;

        public SeaAssetInfo(int id, string name)
        {
            this.id = id;
            this.name = name;
        }
    }

    public class MissingName
    {
        public string[] values;

        public MissingName(params string[] values)
        {
            this.values = values;
        }
    }

}