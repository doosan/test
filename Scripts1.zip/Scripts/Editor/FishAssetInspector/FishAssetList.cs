using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace Underc
{
    [CreateAssetMenu(fileName = "FishAssetList", menuName = "Underc/Fish/Asset List")]
    public class FishAssetList : ScriptableObject
    {
        [SerializeField] private List<FishAssetInfo> items = new List<FishAssetInfo>();

        [SerializeField] private UnityEngine.Object assetsFolder;

        public List<FishAssetInfo> Items
        {
            get => items;
        }

        public int Count
        {
            get => items.Count;
        }

        public FishAssetInfo Get(int index)
        {
            return items[index];
        }

        public void Reset()
        {
            items.Clear();
        }

        public void Add(int index, GameObject assetObject, string name, int sizeGrade )
        {
            items.Add(new FishAssetInfo(index, assetObject, name, sizeGrade));
        }
    }

    public enum FishTextureCategory
    {
        Level1,
        Level2or3,
        Unique,
    }

    public enum FishTexturePreset
    {
        Level1MainTexture,
        Level1VertexTexture,
        Level2or3MainTexture,
        Level2or3NormalTexture,
        Level2or3RampTexture,
        ParticleTexture,
        None
    }

    public enum FishTexturePresetEqual
    {
        Passed,
        Missed,
        Errored
    }

    [Serializable]
    public class FishMaterialInfo
    {
        public string labelName;
        public List<Material> materials;
        public List<int> shaderIndices;

        public FishMaterialInfo(string labelName, List<Material> materials, List<int> shaderIndices)
        {
            this.labelName = labelName;
            this.materials = materials;
            this.shaderIndices = shaderIndices;
        }
    }

    [Serializable]
    public class FishTexturePresetInfo
    {
        public string labelName;
        public List<FishTexturePreset> presets;
        public List<FishTexturePresetEqual> presetEquals;

        public FishTexturePresetInfo(string labelName, FishTexturePreset[] presets)
        {
            this.labelName = labelName;

            this.presets = new List<FishTexturePreset>();
            this.presets.AddRange(presets);

            presetEquals = new List<FishTexturePresetEqual>();
        }

        public FishTexturePresetEqual CheckPresetEqual()
        {
            FishTexturePresetEqual result = FishTexturePresetEqual.Passed;
            for (int i = 0; i < presetEquals.Count; i++)
            {
                FishTexturePresetEqual presetEqual = presetEquals[i];
                // 이전 결과 값이 Passed 일 때는 모든 값을 받아들임
                if (result == FishTexturePresetEqual.Passed)
                {
                    result = presetEqual;
                }
                else
                {
                    // 이전 결과 값이 Missed 일 때는 Passed 가 아닌 값만 받아들임
                    if (result == FishTexturePresetEqual.Missed
                        && presetEqual != FishTexturePresetEqual.Passed)
                    {
                        result = presetEqual;
                    }
                }
            }

            return result;
        }

        public void SetPresetEqual(int textureIndex, bool presetEquality)
        {
            if (presetEquals.Count <= textureIndex)
            {
                presetEquals.Add(FishTexturePresetEqual.Errored);
            }

            presetEquals[textureIndex] = presetEquality == true ? 
                                         FishTexturePresetEqual.Passed :
                                         FishTexturePresetEqual.Errored;
        }

        public void SetPresetMissed(int textureIndex)
        {
            if (presetEquals.Count <= textureIndex)
            {
                presetEquals.Add(FishTexturePresetEqual.Missed);
            }

            presetEquals[textureIndex] = FishTexturePresetEqual.Missed;
        }
    }

    [Serializable]
    public class FishAssetInfo
    {
        public int index;
        public string name;
        public GameObject assetObject;
        public int sizeGrade;

        public FishTextureCategory textureCategory;

        public List<FishTexturePresetInfo> texturePresetInfos;
        public List<FishMaterialInfo> materialInfos;

        public MeshRenderer[] meshRenderers;
        public SkinnedMeshRenderer[] skinnedMeshRenderers;
        public ParticleSystemRenderer[] particleSystemRenderers;

        public FishAssetInfo(int index, GameObject assetObject, string name, int sizeGrade)
        {
            this.index = index;
            this.assetObject = assetObject;
            this.name = name;
            this.sizeGrade = sizeGrade;

            //
            int lodCount = 0;
            foreach (Transform child in assetObject.transform)
            {
                if (child.name.Contains("LOD"))
                {
                    lodCount += 1;
                }
            }

            //
            textureCategory = (sizeGrade == 1) ?
                               FishTextureCategory.Level1 :
                               FishTextureCategory.Level2or3;

            //
            texturePresetInfos = new List<FishTexturePresetInfo>();
            materialInfos = new List<FishMaterialInfo>();

            meshRenderers = assetObject.GetComponentsInChildren<MeshRenderer>();
            skinnedMeshRenderers = assetObject.GetComponentsInChildren<SkinnedMeshRenderer>();
            particleSystemRenderers = assetObject.GetComponentsInChildren<ParticleSystemRenderer>();
        }

        public FishMaterialInfo GetMaterialInfo(string labelName)
        {
            FishMaterialInfo result = null;
            foreach (FishMaterialInfo materialInfo in materialInfos)
            {
                if (materialInfo.labelName == labelName)
                {
                    result = materialInfo;
                    break;
                }
            }

            return result;
        }

        public FishTexturePresetInfo GetTexturePresetInfo(string labelName)
        {
            FishTexturePresetInfo result = null;
            foreach (FishTexturePresetInfo texturePresetInfo in texturePresetInfos)
            {
                if (texturePresetInfo.labelName == labelName)
                {
                    result = texturePresetInfo;
                    break;
                }
            }

            return result;
        }

        public void AddMaterialInfo(string labelName, List<Material> materials)
        {
            List<int> textureIndices = new List<int>();
            var fishMaterialInfo = new FishMaterialInfo(labelName, materials, textureIndices);
            materialInfos.Add(fishMaterialInfo);

            for (int i = 0; i < materials.Count; i++)
            {
                Material material = materials[i];
                Shader shader = material.shader;
                for (int shaderIndex = 0; shaderIndex < ShaderUtil.GetPropertyCount(shader); shaderIndex++)
                {
                    if (ShaderUtil.GetPropertyType(shader, shaderIndex) != ShaderUtil.ShaderPropertyType.TexEnv) continue;

                    Texture texture = material.GetTexture(ShaderUtil.GetPropertyName(shader, shaderIndex));
                    if (texture == null) continue;

                    textureIndices.Add(shaderIndex);
                }
            }
        }

        public void AddTexturePresetInfo(string labelName, FishTexturePreset[] preset)
        {
            texturePresetInfos.Add(new FishTexturePresetInfo(labelName, preset));
        }

        public FishTexturePresetEqual CheckTexturePresetEqual()
        {
            FishTexturePresetEqual result = FishTexturePresetEqual.Passed;
            for (int i = 0; i < texturePresetInfos.Count; i++)
            {
                FishTexturePresetEqual presetEqual = texturePresetInfos[i].CheckPresetEqual();
                // 이전 결과 값이 Passed 일 때는 모든 값을 받아들임
                if (result == FishTexturePresetEqual.Passed)
                {
                    result = presetEqual;
                }
                else
                {
                    // 이전 결과 값이 Missed 일 때는 Passed 가 아닌 값만 받아들임
                    if (result == FishTexturePresetEqual.Missed
                        && presetEqual != FishTexturePresetEqual.Passed)
                    {
                        result = presetEqual;
                    }
                }
            }

            return result;
        }
    }
}