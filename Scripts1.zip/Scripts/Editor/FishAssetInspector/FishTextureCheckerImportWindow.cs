using Gaga.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using Underc.Ocean;
using Underc.User;
using UnityEditor;
using UnityEngine;

namespace Underc
{
    public class FishTextureCheckerImportWindow
    {
        private const float WIDTH = 240f;

        private GUISkin guiSkin;
        private FishAssetList fishAssetList;

        private FishPresetTable fishPresetTable;
        private Dictionary<string, FishPreset> fishPresetDict;
        private Regex grabDigitOfEnd;

        private SerializedProperty assetsFolder;
        private bool isImported;

        public FishTextureCheckerImportWindow(GUISkin guiSkin,
                                              FishAssetList fishAssetList,
                                              SerializedObject serializedObject)
        {
            this.guiSkin = guiSkin;
            this.fishAssetList = fishAssetList;

            fishPresetTable = EditorResources.Load<FishPresetTable>("FishPresetTable");

            fishPresetDict = new Dictionary<string, FishPreset>();
            foreach (FishPreset preset in fishPresetTable.items)
            {
                SeaItemType presetType;
                Enum.TryParse(preset.type, out presetType);
                string assetID = GetAssetID(presetType, preset.id);
                fishPresetDict[assetID] = preset;
            }
            grabDigitOfEnd = new Regex(@"\d+$");

            assetsFolder = serializedObject.FindProperty("assetsFolder");
        }

        private string GetAssetID(SeaItemType type, int id)
        {
            return StringMaker.New()
                              .Append(type.ToString())
                              .Append(id.ToString())
                              .Build();
        }

        public bool IsJustImported()
        {
            bool result = isImported;
            isImported = false;
            return result;
        }

        public void Draw()
        {
            EditorGUILayout.BeginVertical(guiSkin.GetStyle("normal_line"), GUILayout.Width(WIDTH));

            MyGUILayout.FolderObjectField(assetsFolder);
            if (assetsFolder.objectReferenceValue == null)
            {
                EditorGUILayout.HelpBox("타겟 폴더를 지정해 주세요.", MessageType.Info);
            }
            else
            {
                if (GUILayout.Button("IMPORT"))
                {
                    string folderPath = AssetDatabase.GetAssetPath(assetsFolder.objectReferenceValue);
                    string[] assetGuids = AssetDatabase.FindAssets("t:prefab", new string[] { folderPath });
                    string[] assetPaths = assetGuids.Select(guid => AssetDatabase.GUIDToAssetPath(guid)).ToArray();

                    fishAssetList.Reset();
                    int index = 0;
                    foreach (string assetPath in assetPaths)
                    {
                        GameObject fishObject = AssetDatabase.LoadAssetAtPath(assetPath, typeof(GameObject)) as GameObject;
                        string fishName = fishObject.name;
                        SeaItemType fishType = fishName.StartsWith("Fish") ? SeaItemType.f :
                                               fishName.StartsWith("Swimmer") ? SeaItemType.s :
                                               SeaItemType.n;
                        int fishID = int.Parse(grabDigitOfEnd.Match(fishName).ToString());
                        string assetID = GetAssetID(fishType, fishID);
                        FishPreset fishPreset = fishPresetDict[assetID];

                        fishAssetList.Add(index, fishObject, fishName, fishPreset.ui.sizeGrade);

                        index += 1;
                    }
                    EditorUtility.SetDirty(fishAssetList);
                    AssetDatabase.SaveAssets();

                    isImported = true;
                }
            }

            GUILayout.FlexibleSpace();
            EditorGUILayout.EndVertical();
        }
    }
}