using Gaga.Util;
using UnityEditor;
using UnityEngine;

namespace Underc
{
    public class FishTextureCheckerListWindow
    {
        private const float LABEL_WIDTH = 95f;
        private const float LABEL_HEIGHT = 20f;

        public int ActiveIndex
        {
            get; private set;
        }
        private float Width
        {
            get => LABEL_WIDTH + 25f;
        }
        private float Height
        {
            get => LABEL_HEIGHT + 1f;
        }

        private GUISkin guiSkin;
        private FishAssetList fishAssetList;

        private int mouseIndex;
        private Vector2 scrollPosition;
        private Rect position;

        public FishTextureCheckerListWindow(GUISkin guiSkin, FishAssetList fishAssetList)
        {
            this.guiSkin = guiSkin;
            this.fishAssetList = fishAssetList;

            mouseIndex = -1;
            ActiveIndex = -1;
        }

        public void Draw(Rect position)
        {
            this.position = position;

            EditorGUILayout.BeginVertical(guiSkin.GetStyle("normal_line"), GUILayout.Width(Width));
            scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition, false, false);

            ReadMouseIndex();
            ReadKeyboardInput();

            foreach (FishAssetInfo info in fishAssetList.Items)
            {
                bool isActive = info.index == mouseIndex;
                if (isActive)
                {
                    ActiveIndex = mouseIndex;
                }

                string lineStyle = isActive ? "selected_line" : "normal_line";
                EditorGUILayout.BeginHorizontal(guiSkin.GetStyle(lineStyle),
                                                GUILayout.Height(LABEL_HEIGHT));
                ColorState colorState = isActive ? ColorState.Active : ColorState.Normal;
                MyGUILayout.LabelField(info.name, LABEL_WIDTH - 4, TextAnchor.MiddleLeft, colorState);

                FishTexturePresetEqual presetEqual = info.CheckTexturePresetEqual();
                string testLine = presetEqual == FishTexturePresetEqual.Passed ? "passed_line" :
                                  presetEqual == FishTexturePresetEqual.Missed ? "missed_line" :
                                  "errored_line";
                EditorGUILayout.BeginVertical(guiSkin.GetStyle(testLine), GUILayout.Width(4));
                GUILayout.FlexibleSpace();
                EditorGUILayout.EndVertical();

                EditorGUILayout.EndHorizontal();
            }

            EditorGUILayout.EndScrollView();
            EditorGUILayout.EndVertical();
        }

        private void ReadMouseIndex()
        {
            if (Event.current.type == EventType.MouseDown
                && Event.current.mousePosition.x < Width
                && Event.current.mousePosition.y < (Height * fishAssetList.Count))
            {
                Event.current.Use();

                mouseIndex = (int)(Event.current.mousePosition.y / Height);
            }
        }

        private void ReadKeyboardInput()
        {
            Event e = Event.current;
            if (e.type == EventType.KeyDown)
            {
                Event.current.Use();

                int offset = 0;
                switch (e.keyCode)
                {
                    case KeyCode.DownArrow:
                        offset = 1;
                        break;

                    case KeyCode.UpArrow:
                        offset = -1;
                        break;
                }

                if (offset != 0)
                {
                    mouseIndex += offset;
                    if (mouseIndex >= fishAssetList.Count)
                    {
                        mouseIndex = 0;
                    }
                    else if (mouseIndex < 0)
                    {
                        mouseIndex = fishAssetList.Count - 1;
                    }

                    float windowHeight = position.height;
                    float currentBeginY = scrollPosition.y;
                    float targetBeginY = mouseIndex * Height;

                    float currentEndY = windowHeight + scrollPosition.y;
                    float targetEndY = (mouseIndex + 1) * Height;
                    if (targetBeginY < currentBeginY)
                    {
                        scrollPosition = new Vector2(scrollPosition.x, targetBeginY);
                    }
                    else if (targetEndY > currentEndY)
                    {
                        scrollPosition = new Vector2(scrollPosition.x, targetEndY - windowHeight);
                    }
                }
            }
        }
    }

}