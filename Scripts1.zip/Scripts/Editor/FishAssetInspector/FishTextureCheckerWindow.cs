using Gaga.Util;
using UnityEditor;
using UnityEngine;

namespace Underc
{
    public class FishTextureCheckerWindow : EditorWindow
    {
        private FishAssetList fishAssetList;
        private GUISkin guiSkin;

        private FishTextureCheckerImportWindow importWindow;
        private FishTextureCheckerListWindow listWindow;
        private FishTextureCheckerItemWindow itemWindow;

        private SerializedObject serializedObject;

        private bool refreshOnce = false;

        [MenuItem("Underc/Fish Texture Checker", false, 31)]
        private static void ShowWindow()
        {
            FishTextureCheckerWindow window = GetWindow<FishTextureCheckerWindow>();
            window.titleContent = new GUIContent("Fish Texture Checker");
        }

        private void OnEnable()
        {
            fishAssetList = EditorResources.Load<FishAssetList>("FishAssetList");
            guiSkin = EditorResources.Load<GUISkin>("SlotPresetMakerSkin");

            serializedObject = new SerializedObject(fishAssetList);

            importWindow = new FishTextureCheckerImportWindow(guiSkin, fishAssetList, serializedObject);
            listWindow = new FishTextureCheckerListWindow(guiSkin, fishAssetList);
            itemWindow = new FishTextureCheckerItemWindow(guiSkin, fishAssetList);

            refreshOnce = true;
        }

        private void OnDisable()
        {
            refreshOnce = false;
        }

        private void OnGUI()
        {
            if (Application.isPlaying == false)
            {
                if (fishAssetList != null)
                {
                    serializedObject.Update();

                    EditorGUILayout.BeginHorizontal(guiSkin.GetStyle("normal_box"));

                    //
                    importWindow.Draw();
                    listWindow.Draw(position);
                    itemWindow.Draw(listWindow.ActiveIndex);

                    if (importWindow.IsJustImported() == true
                        || refreshOnce == true)
                    {
                        refreshOnce = false;

                        for (int i = 0; i < fishAssetList.Count; i++)
                        {
                            itemWindow.Draw(i);
                        }
                        EditorUtility.SetDirty(fishAssetList);
                    }

                    EditorGUILayout.EndHorizontal();

                    if (GUI.changed)
                    {
                        EditorUtility.SetDirty(fishAssetList);
                    }

                    serializedObject.ApplyModifiedProperties();
                }
            }
            else
            {
                EditorGUILayout.HelpBox("에디터 플레이 중에는 수행 할 수 없습니다.", MessageType.Warning);
            }
        }
    }
}