using Gaga.Util;
using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.Presets;
using UnityEngine;

namespace Underc
{
    public class FishTextureCheckerItemWindow
    {
        private GUISkin guiSkin;
        private FishAssetList fishAssetList;

        private int activeIndex;
        private Dictionary<FishTexturePreset, UnityEngine.Object> rawTexturePresets;

        private Vector2 scrollPosition;

        public FishTextureCheckerItemWindow(GUISkin guiSkin,
                                            FishAssetList fishAssetList)
        {
            this.guiSkin = guiSkin;
            this.fishAssetList = fishAssetList;

            rawTexturePresets = new Dictionary<FishTexturePreset, UnityEngine.Object>();
            AddRawTexturePreset(FishTexturePreset.Level1MainTexture);
            AddRawTexturePreset(FishTexturePreset.Level1VertexTexture);
            AddRawTexturePreset(FishTexturePreset.Level2or3MainTexture);
            AddRawTexturePreset(FishTexturePreset.Level2or3NormalTexture);
            AddRawTexturePreset(FishTexturePreset.Level2or3RampTexture);
            AddRawTexturePreset(FishTexturePreset.ParticleTexture);
            AddRawTexturePreset(FishTexturePreset.None);
        }

        private void AddRawTexturePreset(FishTexturePreset preset)
        {
            UnityEngine.Object rawPreset = EditorResources.Load<UnityEngine.Object>(preset.ToString());
            if (rawPreset is Preset)
            {
                rawTexturePresets.Add(preset, rawPreset);
            }
            else
            {
                rawTexturePresets.Add(preset, null);
            }
        }

        public void Draw(int activeIndex)
        {
            if (activeIndex != -1
                && fishAssetList.Items.Count > 0)
            {
                FishAssetInfo assetInfo = fishAssetList.Items[activeIndex];
                GameObject assetObject = assetInfo.assetObject;

                EditorGUILayout.BeginVertical(guiSkin.GetStyle("normal_box"));
                scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition, false, false);

                EditorGUILayout.ObjectField(label: "AssetObject",
                                            obj: assetObject,
                                            objType: typeof(GameObject),
                                            allowSceneObjects: false);

                assetInfo.textureCategory = (FishTextureCategory)EditorGUILayout.EnumPopup(
                    "Target Texture Category",
                    assetInfo.textureCategory
                );

                switch (assetInfo.textureCategory)
                {
                    case FishTextureCategory.Level1:
                        EditorGUILayout.Separator();
                        string labelName = "Level1 LOD0";
                        AddMaterials(assetInfo, 
                                     labelName,
                                     assetInfo.skinnedMeshRenderers);
                        AddTexturePresets(assetInfo,
                                          labelName,
                                          FishTexturePreset.Level1MainTexture);
                        DrawMaterials(assetInfo.GetMaterialInfo(labelName),
                                      assetInfo.GetTexturePresetInfo(labelName), 
                                      labelName);

                        EditorGUILayout.Separator();
                        labelName = "Level1 LOD1";
                        AddMaterials(assetInfo,
                                     labelName,
                                     assetInfo.meshRenderers);
                        AddTexturePresets(assetInfo,
                                          labelName,
                                          FishTexturePreset.Level1MainTexture,
                                          FishTexturePreset.Level1VertexTexture);
                        DrawMaterials(assetInfo.GetMaterialInfo(labelName),
                                      assetInfo.GetTexturePresetInfo(labelName),
                                      labelName);

                        EditorGUILayout.Separator();
                        labelName = "Level1 Particles";
                        AddMaterials(assetInfo,
                                     labelName,
                                     assetInfo.particleSystemRenderers);
                        AddTexturePresets(assetInfo,
                                          labelName,
                                          FishTexturePreset.ParticleTexture);
                        DrawMaterials(assetInfo.GetMaterialInfo(labelName),
                                      assetInfo.GetTexturePresetInfo(labelName),
                                      labelName);
                        break;

                    case FishTextureCategory.Level2or3:
                        EditorGUILayout.Separator();
                        labelName = "Level2or3 LOD0";
                        AddMaterials(assetInfo,
                                     labelName,
                                     assetInfo.skinnedMeshRenderers);
                        AddTexturePresets(assetInfo,
                                          labelName,
                                          FishTexturePreset.Level2or3MainTexture,
                                          FishTexturePreset.Level2or3NormalTexture,
                                          FishTexturePreset.Level2or3RampTexture);
                        DrawMaterials(assetInfo.GetMaterialInfo(labelName),
                                      assetInfo.GetTexturePresetInfo(labelName),
                                      labelName);

                        EditorGUILayout.Separator();
                        labelName = "Level2or3 Particles";
                        AddMaterials(assetInfo,
                                     labelName,
                                     assetInfo.particleSystemRenderers);
                        AddTexturePresets(assetInfo,
                                          labelName,
                                          FishTexturePreset.ParticleTexture);
                        DrawMaterials(assetInfo.GetMaterialInfo(labelName),
                                      assetInfo.GetTexturePresetInfo(labelName),
                                      labelName);
                        break;
                }

                //
                EditorGUILayout.Separator();

                FishTexturePresetEqual presetEqual = assetInfo.CheckTexturePresetEqual();
                GUI.enabled = presetEqual != FishTexturePresetEqual.Passed;
                EditorGUILayout.BeginHorizontal();
                GUILayout.FlexibleSpace();
                EditorGUILayout.BeginVertical(GUILayout.Width(80));
                if (GUILayout.Button("APPLY"))
                {
                    ApplyTexturePresets(assetInfo);
                }
                EditorGUILayout.EndVertical();
                EditorGUILayout.EndHorizontal();
                GUI.enabled = true;

                GUILayout.FlexibleSpace();

                EditorGUILayout.EndScrollView();
                EditorGUILayout.EndVertical();
            }
        }

        private void AddTexturePresets(FishAssetInfo assetInfo,
                                       string labelName,
                                       params FishTexturePreset[] presets)
        {
            FishTexturePresetInfo texturePresetInfo = assetInfo.GetTexturePresetInfo(labelName);
            if (texturePresetInfo == null)
            {
                assetInfo.AddTexturePresetInfo(labelName, presets);
            }
        }

        private void AddMaterials(FishAssetInfo assetInfo,
                                  string labelName,
                                  Renderer[] renderers)
        {
            if (renderers != null)
            {
                FishMaterialInfo materialInfo = assetInfo.GetMaterialInfo(labelName);
                if (materialInfo == null)
                {
                    List<Material> materials = new List<Material>();
                    foreach (Renderer renderer in renderers)
                    {
                        Material material = renderer.sharedMaterial;
                        if (material == null) continue;

                        materials.Add(material);
                    }

                    assetInfo.AddMaterialInfo(labelName, materials);
                }
            }
        }

        private void ApplyTexturePresets(FishAssetInfo assetInfo)
        {
            for (int infoIndex = 0; infoIndex < assetInfo.materialInfos.Count; infoIndex++)
            {
                FishMaterialInfo materialInfo = assetInfo.materialInfos[infoIndex];
                FishTexturePresetInfo presetInfo = assetInfo.texturePresetInfos[infoIndex];
                
                for (int materialIndex = 0; materialIndex < materialInfo.materials.Count; materialIndex++)
                {
                    Material material = materialInfo.materials[materialIndex];
                    Shader shader = material.shader;
                    for (int textureIndex = 0; textureIndex < materialInfo.shaderIndices.Count; textureIndex++)
                    {
                        int shaderIndex = materialInfo.shaderIndices[textureIndex];
                        Texture texture = material.GetTexture(ShaderUtil.GetPropertyName(shader, shaderIndex));

                        if (textureIndex >= presetInfo.presets.Count) continue;

                        FishTexturePreset preset = presetInfo.presets[textureIndex];
                        UnityEngine.Object rawPreset = rawTexturePresets[preset];
                        if (rawPreset == null) continue;

                        ApplyPreset(rawPreset, texture);
                    }
                }
            }
        }

        private void ApplyPreset(UnityEngine.Object presetObj, UnityEngine.Object textureObj)
        {
            Preset preset = presetObj as Preset;
            string texturePath = AssetDatabase.GetAssetPath(textureObj);
            TextureImporter textureImporter = TextureImporter.GetAtPath(texturePath) as TextureImporter;
            preset.ApplyTo(textureImporter);

            AssetDatabase.ImportAsset(texturePath);
        }

        private bool IsPresetSame(UnityEngine.Object presetObj, UnityEngine.Object textureObj)
        {
            bool result = false;
            if (presetObj != null)
            {
                Preset preset = presetObj as Preset;
                string texturePath = AssetDatabase.GetAssetPath(textureObj);
                TextureImporter textureImporter = TextureImporter.GetAtPath(texturePath) as TextureImporter;

                result = preset.DataEquals(textureImporter);
            }

            return result;
        }

        private void DrawMaterials(FishMaterialInfo materialInfo,
                                   FishTexturePresetInfo presetInfo,
                                   string labelName)
        {
            EditorGUILayout.LabelField(labelName);

            EditorGUI.indentLevel += 1;

            for (int materialIndex = 0; materialIndex < materialInfo.materials.Count; materialIndex++)
            {
                Material material = materialInfo.materials[materialIndex];
                EditorGUILayout.ObjectField(label: "Material",
                                            obj: material,
                                            objType: typeof(Material),
                                            allowSceneObjects: false);

                EditorGUI.indentLevel += 1;

                Shader shader = material.shader;
                for (int textureIndex = 0; textureIndex < materialInfo.shaderIndices.Count; textureIndex++)
                {
                    int shaderIndex = materialInfo.shaderIndices[textureIndex];
                    Texture texture = material.GetTexture(ShaderUtil.GetPropertyName(shader, shaderIndex));

                    EditorGUILayout.BeginVertical(GUI.skin.textArea);

                    //
                    DrawAsButton(label: "Texture",
                                 obj: texture,
                                 objType: typeof(Texture));

                    // 텍스쳐가 할당된 프리셋과 같은 포맷을 갖고 있는지 체크해 색깔로 표시
                    if (textureIndex < presetInfo.presets.Count)
                    {
                        FishTexturePreset preset = presetInfo.presets[textureIndex];
                        UnityEngine.Object rawPreset = rawTexturePresets[preset];
                        if (rawPreset == null)
                        {
                            presetInfo.SetPresetMissed(textureIndex);
                        }
                        else
                        {
                            presetInfo.SetPresetEqual(textureIndex, IsPresetSame(rawPreset, texture));
                        }
                    }
                    
                    FishTexturePresetEqual presetEqual = presetInfo.presetEquals[textureIndex];
                    string testLine = presetEqual == FishTexturePresetEqual.Passed ? "passed_line" :
                                      presetEqual == FishTexturePresetEqual.Missed ? "missed_line" :
                                      "errored_line";
                    EditorGUILayout.BeginHorizontal(guiSkin.GetStyle(testLine), GUILayout.Height(4));
                    GUILayout.FlexibleSpace();
                    EditorGUILayout.EndHorizontal();

                    // 텍스쳐에 할당된 프리셋을 표시
                    EditorGUILayout.Space();
                    if (textureIndex < presetInfo.presets.Count)
                    {
                        FishTexturePreset preset = presetInfo.presets[textureIndex];
                        presetInfo.presets[textureIndex] = (FishTexturePreset)EditorGUILayout.EnumPopup(
                            "Target Texture Preset",
                            preset
                        );

                        UnityEngine.Object rawPreset = rawTexturePresets[preset];
                        GUI.enabled = false;
                        EditorGUILayout.ObjectField(label: "Raw Preset",
                                                    obj: rawPreset,
                                                    objType: typeof(UnityEngine.Object),
                                                    allowSceneObjects: false);
                        GUI.enabled = true;
                    }
                    else
                    {
                        FishTexturePreset preset = FishTexturePreset.None;
                        if (textureIndex >= presetInfo.presets.Count)
                        {
                            presetInfo.presets.Add(preset);
                        }
                        presetInfo.presets[textureIndex] = (FishTexturePreset)EditorGUILayout.EnumPopup(
                            "Target Texture Preset",
                            preset
                        );

                        GUI.enabled = false;
                        EditorGUILayout.ObjectField(label: "Raw Preset",
                                                    obj: null,
                                                    objType: typeof(UnityEngine.Object),
                                                    allowSceneObjects: false);
                        GUI.enabled = true;
                    }


                    //
                    EditorGUILayout.EndVertical();
                }

                materialIndex += 1;
                EditorGUI.indentLevel -= 1;
            }

            EditorGUI.indentLevel -= 1;
        }

        private void DrawAsButton(string label, UnityEngine.Object obj, Type objType)
        {
            EditorGUILayout.BeginHorizontal();

            EditorGUILayout.ObjectField(label: label,
                                        obj: obj,
                                        objType: objType,
                                        allowSceneObjects: false);

            if (GUILayout.Button(content: EditorGUIUtility.IconContent("d_Animation.Play"),
                                 style: UnityEditor.EditorStyles.toolbarButton,
                                 GUILayout.Width(20f)))
            {
                EditorGUIUtility.PingObject(obj);
                Selection.activeObject = obj;
            }
            EditorGUILayout.EndHorizontal();
        }
    }
}