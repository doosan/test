using UnityEngine;
using UnityEditor;
using SlotGame;
using Gaga.Util;
using Underc.Game;
using SlotGame.Util;
using System.IO;
using Gaga.AssetBundle;

namespace Underc
{
    public class GameAssetsChecker : BaseAssetsChecker
    {
        private readonly string POSTER_PATH             = "Assets/0.UNDERC/Common/Assets/Posters/";
        private readonly string GAMEINFO_PATH           = "Assets/0.UNDERC/Game/Assets/Loading/LoadingInfo/";
        private readonly string PAYTABLE_PATH           = "Assets/0.UNDERC/Game/Assets/Paytable/";
        private readonly string WINBROADPOSTER_PATH     = "Assets/0.UNDERC/Game/Assets/WinBroadcastPoster/";
        private readonly string SLOTICON_PATH           = "Assets/0.UNDERC/Common/Assets/IconSlots/";

        private SlotPresetList slotPresetList;
        
        public GameAssetsChecker():base()
        {
            slotPresetList = EditorResources.Load<SlotPresetList>("SlotPresetList");
        }

        public override string GetTitle()
        {
            return "Game";
        }

        protected override int GetListCount()
        {
            return slotPresetList.Items.Count;
        }

        protected override ListItem GetListItem(int index)
        {
            var slotItem = slotPresetList.Items[index];
            ListItem listItem = new ListItem();

            string slotID = slotItem.id.ToString();
            string name = StringMaker.New()
                                    .Append("(")
                                    .Append(slotID)
                                    .Append(")  ")
                                    .Append(slotItem.name)
                                    .Build();

            listItem.name = name;

            listItem = CheckPoster(slotID, listItem);
            listItem = CheckGameInfo(slotID, listItem);
            listItem = CheckPaytable(slotID, listItem);
            listItem = CheckBroadcastPosters(slotID, listItem);
            listItem = CheckSlotIcon(slotID, listItem);
            listItem = CheckAssetNames(slotID, listItem);

            if (slotItem.show == false)
            {
                listItem.state = State.Develop;
            }
            else
            {
                bool hasError = string.IsNullOrEmpty(listItem.message) == false;
                listItem.state = hasError == true ? State.Error : State.Normal;
            }

            return listItem;
        }

        private ListItem CheckSlotIcon(string slotID, ListItem listItem)
        {
            string slotIconPath = StringMaker.New()
                                             .Append(SLOTICON_PATH)
                                             .Append(slotID)
                                             .Append(".png")
                                             .Build();

            var asset = AssetDatabase.LoadAssetAtPath<Texture2D>(slotIconPath);
            if (asset == null)
            {
                listItem.AddMessage("슬롯 아이콘 누락");
            }

            return listItem;
        }

        private ListItem CheckPoster(string slotID, ListItem listItem)
        {
            string posterDirPath = StringMaker.New()
                                              .Append(POSTER_PATH)
                                              .Append(slotID)
                                              .Build();

            bool isValidPosterDir = AssetDatabase.IsValidFolder(posterDirPath);

            if (isValidPosterDir == true)
            {
                string posterPrefabPath = StringMaker.New()
                                                    .Append(POSTER_PATH)
                                                    .Append(slotID)
                                                    .Append("/Poster")
                                                    .Append(slotID)
                                                    .Append(".prefab")
                                                    .Build();

                var posterPrefab = AssetDatabase.LoadAssetAtPath(posterPrefabPath, typeof(GameObject));

                if (posterPrefab == null)
                {
                    listItem.AddMessage("포스터 프리펩 파일 누락");
                }
            }
            else
            {
                listItem.AddMessage("포스터 폴더 누락");
            }

            return listItem;
        }

        private ListItem CheckGameInfo(string slotID, ListItem listItem)
        {
            string gameInfoDirPath = StringMaker.New()
                                                .Append(GAMEINFO_PATH)
                                                .Append(slotID)
                                                .Build();

            bool isValidGameInfoDir = AssetDatabase.IsValidFolder(gameInfoDirPath);

            if (isValidGameInfoDir == true)
            {
                string gameLoadingInfoPath = StringMaker.New()
                                            .Append(GAMEINFO_PATH)
                                            .Append(slotID)
                                            .Append("/GameLoadingInfo_")
                                            .Append(slotID)
                                            .Append(".asset")
                                            .Build();

                string gameLoadingInfoDirPath = Path.GetDirectoryName(gameLoadingInfoPath);

                var gameInfoPrefab = AssetDatabase.LoadAssetAtPath<GameLoadingInfo>(gameLoadingInfoPath);

                if (gameInfoPrefab != null)
                {
                    if (string.IsNullOrEmpty(gameInfoPrefab.Description1) == true)
                    {
                        listItem.AddMessage("게임 LoadingInfo 설명 1 누락");
                    }
                    if (string.IsNullOrEmpty(gameInfoPrefab.Description2) == true)
                    {
                        listItem.AddMessage("게임 LoadingInfo 설명 2 누락");
                    }
                    if (gameInfoPrefab.Symbol1 == null)
                    {
                        listItem.AddMessage("게임 LoadingInfo 심볼 1 누락");
                    }
                    else if (gameLoadingInfoDirPath != Path.GetDirectoryName(AssetDatabase.GetAssetPath(gameInfoPrefab.Symbol1)))
                    {
                        listItem.AddMessage(string.Format("게임 LoadingInfo 심볼 1 '{0}' 파일이 다른 경로에 있습니다.", gameInfoPrefab.Symbol1.name));
                    }
                    if (gameInfoPrefab.Symbol2 == null)
                    {
                        listItem.AddMessage("게임 LoadingInfo 심볼 2 누락");
                    }
                    else if (gameLoadingInfoDirPath != Path.GetDirectoryName(AssetDatabase.GetAssetPath(gameInfoPrefab.Symbol2)))
                    {
                        listItem.AddMessage(string.Format("게임 LoadingInfo 심볼 2 '{0}' 파일이 다른 경로에 있습니다.", gameInfoPrefab.Symbol2.name));
                    }
                }
                else
                {
                    listItem.AddMessage("게임 LoadingInfo 파일 누락");
                }
            }
            else
            {
                listItem.AddMessage("게임 LoadingInfo 폴더 누락");
            }

            return listItem;
        }

        private ListItem CheckPaytable(string slotID, ListItem listItem)
        {
            string dirPath = StringMaker.New()
                                        .Append(PAYTABLE_PATH)
                                        .Append(slotID)
                                        .Build();

            bool isValidGameInfoDir = AssetDatabase.IsValidFolder(dirPath);

            if (isValidGameInfoDir == true)
            {
                string paytableInfoPath = StringMaker.New()
                                            .Append(PAYTABLE_PATH)
                                            .Append(slotID)
                                            .Append("/PaytableInfo")
                                            .Append(".asset")
                                            .Build();

                string paytableInfoDirPath = Path.GetDirectoryName(paytableInfoPath).Replace("\\", "/");

                var paytableInfo = AssetDatabase.LoadAssetAtPath<PaytableInfo>(paytableInfoPath);
                if (paytableInfo != null)
                {
                    if (paytableInfo.Items == null || paytableInfo.Items.Length == 0)
                    {
                        listItem.AddMessage("빈 Paytable 아이템");
                    }
                    else
                    {
                        for (int i = 0; i < paytableInfo.Items.Length; i++)
                        {
                            var info = paytableInfo.Items[i];
                            if (string.IsNullOrEmpty(info.title) == true)
                            {
                                listItem.AddMessage("Paytable Item " + i + " 타이틀 누락");
                            }
                            else if (info.texure == null)
                            {
                                listItem.AddMessage("Paytable Item " + i + " 텍스쳐 누락");
                            }
                            else if(AssetDatabase.GetAssetPath(info.texure).IndexOf(paytableInfoDirPath) == -1)
                            {
                                listItem.AddMessage(string.Format("Paytable Item {0} 번 텍스쳐 '{1}' 파일이 다른 경로에 있습니다.",i,info.texure.name));
                            }
                        }
                    }
                }
                else
                {
                    listItem.AddMessage("PaytableInfo 파일 누락");
                }
            }
            else
            {
                listItem.AddMessage("PayTable 폴더 누락");
            }

            return listItem;
        }

        private ListItem CheckBroadcastPosters(string slotID, ListItem listItem)
        {
            string posterPath = StringMaker.New()
                                           .Append(WINBROADPOSTER_PATH)
                                           .Append(WinBroadcastTexture.POSTER_PREFIX)
                                           .Append(slotID)
                                           .Append(".png")
                                           .Build();

            var asset = AssetDatabase.LoadAssetAtPath<Texture2D>(posterPath);

            if (asset == null)
            {
                listItem.AddMessage("WinBroadcast 포스터 누락");
            }

            return listItem;
        }

        private ListItem CheckAssetNames(string slotID, ListItem listItem)
        {
#if UNITY_EDITOR
            string bundleName = string.Format("{0}.unity3d", AssetBundleName.Slot(slotID));
            var duplicateNames = AssetBundleSystem.FindDuplicateAssetNames(bundleName);
            if (duplicateNames == null || duplicateNames.Length == 0)
            {
                return listItem;
            }

            int showLimit = 4;
            int addedCount = 0;
            listItem.AddMessage(string.Format("- 중복된 이름 파일들 ({0}) -", duplicateNames.Length));
            for (int i = 0; i < duplicateNames.Length; i++)
            {
                if (addedCount == showLimit)
                {
                    if (addedCount < duplicateNames.Length)
                    {
                        listItem.AddMessage("...");
                    }
                    break;
                }

                listItem.AddMessage(duplicateNames[i]);
                ++addedCount;
            }
#endif

            return listItem;
        }
    }
}