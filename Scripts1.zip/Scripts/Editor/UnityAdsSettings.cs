using UnityEditor;

namespace Underc
{
    public static class UnityAdsSettings
    {
        private const string ASSET_PATH_PROJECT_SETTINGS = "ProjectSettings/ProjectSettings.asset";
        private const string ASSET_PATH_UNITY_CONNECT_SETTINGS = "ProjectSettings/UnityConnectSettings.asset";

        [MenuItem("Underc/Reset Unity Ads Settings", false, 34)]
        public static void Reset()
        {
            SDKConfig.UnityProjectInfo unityProjectInfo = SDKConfig.GetCurrentSdkInfo().GetUnityProjectInfo();
            Reset(unityProjectInfo);
        }

        public static void Reset(SDKConfig.UnityProjectInfo unityProjectInfo)
        {
            SerializedObject projectSettings = new SerializedObject(AssetDatabase.LoadAllAssetsAtPath(ASSET_PATH_PROJECT_SETTINGS)[0]);
            SerializedProperty cloudProjectId = projectSettings.FindProperty("cloudProjectId");
            SerializedProperty projectName = projectSettings.FindProperty("projectName");

            cloudProjectId.stringValue = unityProjectInfo.cloudID;
            projectName.stringValue = unityProjectInfo.name;
            projectSettings.ApplyModifiedProperties();

            //
            SerializedObject unityConnectSettings = new SerializedObject(AssetDatabase.LoadAllAssetsAtPath(ASSET_PATH_UNITY_CONNECT_SETTINGS)[0]);
            SerializedProperty testMode = unityConnectSettings.FindProperty("m_TestMode");
            SerializedProperty unityAdsSettings = unityConnectSettings.FindProperty("UnityAdsSettings");
            SerializedProperty iosGameID = unityAdsSettings.FindPropertyRelative("m_IosGameId");
            SerializedProperty androidGameID = unityAdsSettings.FindPropertyRelative("m_AndroidGameId");
            SerializedProperty gameId = unityAdsSettings.FindPropertyRelative("m_GameId");

            testMode.boolValue = unityProjectInfo.adsTestMode;
            iosGameID.stringValue = unityProjectInfo.adsIosGameID;
            androidGameID.stringValue = unityProjectInfo.adsAndroidGameID;
            gameId.stringValue = unityProjectInfo.GetGameID();

            unityConnectSettings.ApplyModifiedProperties();
        }
    }
}