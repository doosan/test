using System.Collections.Generic;
using System.Linq;
using System.Text;
using Gaga.Util;
using UnityEditor;
using UnityEditor.U2D;
using UnityEngine.U2D;

namespace Underc
{
    public class SpriteAtlasMigration : EditorWindow
    {
        private class SpriteAtlasMigrationAsset
        {
            public string path;
            public SpriteAtlas atlas;
            private Dictionary<string, TextureImporterPlatformSettings> settingDic;

            public bool HasMigrationSetting { get => settingDic != null && settingDic.Count > 0; }
            public int Count { get => settingDic == null ? 0 : settingDic.Count; }
            private string migrationLog;

            public SpriteAtlasMigrationAsset(string path, SpriteAtlas atlas)
            {
                this.path = path;
                this.atlas = atlas;
            }

            public void SetMigrationSetting(string buildTarget, TextureImporterPlatformSettings setting)
            {
                if (settingDic == null)
                {
                    settingDic = new Dictionary<string, TextureImporterPlatformSettings>();
                }

                settingDic.Add(buildTarget, setting);
            }

            public void Migrate()
            {
                var sb = new StringBuilder(path);
                foreach (var kv in settingDic)
                {
                    string buildTarget = kv.Key;
                    TextureImporterPlatformSettings migrationSetting = kv.Value;
                    TextureImporterPlatformSettings originSetting = SpriteAtlasExtensions.GetPlatformSettings(atlas, buildTarget);

                    sb.AppendLine();
                    sb.AppendFormat("\t{0} fomat {1} > {2}", buildTarget, (int)originSetting.format, (int)migrationSetting.format);

                    SpriteAtlasExtensions.SetPlatformSettings(atlas, migrationSetting);
                }

                migrationLog = sb.ToString();
            }

            public override string ToString()
            {
                return string.IsNullOrEmpty(migrationLog) ? path : migrationLog;
            }
        }

        [MenuItem("Underc/SpriteAtlas Migration", false, 33)]
        public static void RunSpriteAtlasMigration()
        {
            string message = "현재 유니티 버전에서 지원되지 않는 포맷의 \nSpriteAtlas 를 마이그레이션 하시겠습니까?";

            if (EditorUtility.DisplayDialog("ASTC Migration", message, "Run", "Cancel"))
            {
                Do();
            }
        }

        public static void Do()
        {
            Debug.Log("SpriteAtlas Migration");
            string[] atlasGuids = AssetDatabase.FindAssets("t:SpriteAtlas");

            SpriteAtlasMigrationAsset[] migrationAssets = atlasGuids.Select(presetGuid =>
            {
                var path = AssetDatabase.GUIDToAssetPath(presetGuid);
                SpriteAtlas atlas = AssetDatabase.LoadAssetAtPath<SpriteAtlas>(path);
                return new SpriteAtlasMigrationAsset(path, atlas);
            }).Where(asset =>
            {
                FindMigrationSetting(asset);
                return asset.HasMigrationSetting;
            }).ToArray();

            foreach (var asset in migrationAssets)
            {
                asset.Migrate();
            }

            Debug.LogFormat("migration Complete ({0})\n{1}", migrationAssets.Length, migrationAssets.ToEachString(",\n"));
        }

        private static void FindMigrationSetting(SpriteAtlasMigrationAsset asset)
        {
            //BuildTarget enum 을 사용해서는 안된다.
            //BuildTarget.iPhone 은 OBSOLETE 되어 BuildTarget.iOS 을 사용해야 하지만 platformSetting 을 가져 올 때 사용되는 문자열 키는 "iPhone" 이다
            string[] checkTargets = { "Android", "iPhone" };

            foreach (var buildTarget in checkTargets)
            {
                TextureImporterPlatformSettings originSetting = SpriteAtlasExtensions.GetPlatformSettings(asset.atlas, buildTarget);
                if (IsMigrationFormat(originSetting.format) == false)
                {
                    continue;
                }

                TextureImporterPlatformSettings migratedSetting = new TextureImporterPlatformSettings();
                originSetting.CopyTo(migratedSetting);

                migratedSetting.format = GetMigratedFormat(originSetting.format);

                asset.SetMigrationSetting(buildTarget, migratedSetting);
            }
        }
        private static bool IsMigrationFormat(TextureImporterFormat format)
        {
            bool result = false;
            switch (format)
            {
#pragma warning disable CS0618 
                case TextureImporterFormat.ASTC_RGBA_4x4:
                case TextureImporterFormat.ASTC_RGBA_5x5:
                case TextureImporterFormat.ASTC_RGBA_6x6:
                case TextureImporterFormat.ASTC_RGBA_8x8:
                case TextureImporterFormat.ASTC_RGBA_10x10:
                case TextureImporterFormat.ASTC_RGBA_12x12:
#pragma warning restore CS0618 
                    result = true;
                    break;
            }

            return result;
        }

        private static TextureImporterFormat GetMigratedFormat(TextureImporterFormat originFormat)
        {
            TextureImporterFormat format = originFormat;

#pragma warning disable CS0618
            switch (format)
            {
                case TextureImporterFormat.ASTC_RGBA_4x4:
                    format = TextureImporterFormat.ASTC_4x4;
                    break;
                case TextureImporterFormat.ASTC_RGBA_5x5:
                    format = TextureImporterFormat.ASTC_5x5;
                    break;
                case TextureImporterFormat.ASTC_RGBA_6x6:
                    format = TextureImporterFormat.ASTC_6x6;
                    break;
                case TextureImporterFormat.ASTC_RGBA_8x8:
                    format = TextureImporterFormat.ASTC_8x8;
                    break;
                case TextureImporterFormat.ASTC_RGBA_10x10:
                    format = TextureImporterFormat.ASTC_10x10;
                    break;
                case TextureImporterFormat.ASTC_RGBA_12x12:
                    format = TextureImporterFormat.ASTC_12x12;
                    break;
            }
#pragma warning restore CS0618

            return format;
        }
    }
}