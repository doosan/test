#if UNITY_EDITOR
using Gaga.Popup;
using UnityEditor;
using UnityEngine;

namespace Underc
{
    public class PopupTest
    {
        [InitializeOnLoadMethod]
        private static void AddEvents()
        {
            EditorApplication.hierarchyChanged -= OnHierarchyChanged;        
            EditorApplication.hierarchyChanged += OnHierarchyChanged;
        }

        private static void OnHierarchyChanged ()
        {
            if(Application.isPlaying == true
                && Selection.activeGameObject != null 
                && PrefabUtility.GetPrefabInstanceStatus(Selection.activeGameObject) == PrefabInstanceStatus.Connected)
            {
                ShowPopup(Selection.activeGameObject);
            }
        }

        private static void ShowPopup(GameObject popupObject)
        {
            var popup = popupObject.GetComponent<PopupBehaviour>();

            if (popup != null)
            {
                PrefabUtility.UnpackPrefabInstance(popupObject, PrefabUnpackMode.Completely, InteractionMode.AutomatedAction);
                PopupSystem.Instance.Open<PopupBehaviour>(popup);
            }
        }
    }
}
#endif