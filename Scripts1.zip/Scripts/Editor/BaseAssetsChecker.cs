using UnityEngine;
using UnityEditor;
using Gaga.Util;
using System.Collections.Generic;
using System;
using System.Linq;

namespace Underc
{
    public abstract class BaseAssetsChecker
    {
        public enum State
        {
            Normal,
            Error,
            Develop
        }

        protected class ListItem
        {
            public bool ignore;
            public State state;
            public string name;
            public string message { get; private set; }

            public List<string> Messages
            {
                get
                {
                    if (string.IsNullOrEmpty(message) == false && messages.Count == 0)
                    {
                        messages.Clear();
                        foreach (string item in message.Split(','))
                        {
                            messages.Add(item.Trim());
                        }
                    }
                    return messages;
                }
            }
            private List<string> messages = new List<string>();

            public void AddMessage(string message)
            {
                if (string.IsNullOrEmpty(this.message) == true)
                {
                    this.message = message;
                }
                else
                {
                    this.message += " , " + message;
                }
            }

            public void ClearMessage()
            {
                message = null;
                messages.Clear();
            }
        }

        private readonly float LABEL_STATUS_WIDTH        = 40.0f;
        private readonly float LABEL_INDEX_WIDTH        = 40.0f;
        private readonly float LABEL_NAME_WIDTH         = 180.0f;
        private readonly float LABEL_SUMMARY_WIDTH      = 600.0f;

        public GUISkin Skin { get;private set; }
        private float width;

        private Vector2 scrollPosition = Vector2.zero;
        public bool IsValid{get; private set;}
        private List<ListItem> listItems;

        public BaseAssetsChecker()
        {
            Skin = EditorResources.Load<GUISkin>("SlotPresetMakerSkin");
            listItems = new List<ListItem>();
        }

        public abstract string GetTitle();
        protected abstract int GetListCount();
        protected abstract ListItem GetListItem(int index);

        private int errorCount;
        private int developCount;

        public void Update()
        {
            errorCount = 0;
            developCount = 0;

            IsValid = true;

            var count = GetListCount();

            listItems.Clear();
            for (int i = 0; i < count; i++)
            {
                var listItem = GetListItem(i);
                listItems.Add(listItem);

                if (listItem.state == State.Error)
                {
                    IsValid = false;
                    errorCount++;
                }
                else if (listItem.state == State.Develop)
                {
                    developCount++;
                }
            }
        }

        public void Draw(float width)
        {
            this.width = width;

            EditorGUILayout.BeginVertical();
            
            DrawTitle();

            EditorGUILayout.Space();
            EditorGUILayout.Space();

            DrawSummary();

            scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition, false, false);

            DrawItems();

            EditorGUILayout.EndScrollView();
            EditorGUILayout.EndVertical();
        }

        private void DrawTitle()
        {
            MyGUILayout.Title(GetTitle(), EditorGUIUtility.singleLineHeight, Skin.GetStyle("title"));
        }

        private void DrawSummary()
        {
            int totalCount = listItems.Count;
            string message = StringMaker.New()
                                       .Append("( total : ")
                                       .Append(totalCount.ToString())
                                       .Append(" , error : ")
                                       .Append(errorCount.ToString())
                                       .Append(" , develop : ")
                                       .Append(developCount.ToString())
                                       .Append(" )")
                                       .Build();

            MyGUILayout.LabelField(message, LABEL_SUMMARY_WIDTH, TextAnchor.MiddleLeft, Color.white);
        }

        private void DrawItems()
        {
            EditorGUILayout.BeginVertical(Skin.GetStyle("normal_box"));

            EditorListColumn[] columns = new EditorListColumn[]
            {
                new EditorListColumn { width = LABEL_STATUS_WIDTH, name = "Status" },
                new EditorListColumn { width = LABEL_INDEX_WIDTH, name = "Index" },
                new EditorListColumn { width = LABEL_NAME_WIDTH, name = "Name" },
                new EditorListColumn { width = width - 256, name = "Message" }
            };

            // List Header
            EditorGUILayout.BeginHorizontal(GUILayout.Width(columns.Width()));
            MyGUILayout.ListHeader(columns,
                                   EditorGUIUtility.singleLineHeight,
                                   Skin.GetStyle("empty_box"),
                                   Skin.GetStyle("normal_line"));
            EditorGUILayout.EndHorizontal();

            // List Items
            Action<int, int> onDraw = (int rowIndex, int colIndex) =>
            {
                ListItem listItem = listItems[rowIndex];
                Color color = MyGUILayout.TextColorNormal;

                switch (colIndex)
                {
                    case 0:
                    GUILayout.Space(0);
                    Vector2 lastestPosition = GUILayoutUtility.GetLastRect().position;
                    EditorGUI.DrawRect(new Rect(lastestPosition.x+11, lastestPosition.y, columns[0].width-22, 18), 
                                       GetStateColor(listItem.state));
                    break;

                    case 1:
                    MyGUILayout.LabelField((rowIndex + 1).ToString(), 
                                           columns[1].width, 
                                           TextAnchor.MiddleLeft, 
                                           color);
                    break;

                    case 2:
                    MyGUILayout.LabelField(listItem.name, columns[2].width, TextAnchor.MiddleLeft, color);
                    break;

                    case 3:
                    if (listItem.state == State.Develop)
                    {
                        MyGUILayout.LabelField("개발 중", columns[3].width, TextAnchor.MiddleLeft, color);
                    }
                    
                    foreach (string message in listItem.Messages)
                    {
                        MyGUILayout.LabelField(message, columns[3].width, TextAnchor.MiddleLeft, color);
                    }
                    break;
                }
            };

            EditorListRow[] rows = listItems.Select((ListItem listItem) => 
                                                    {
                                                        int lineCount = listItem.state == State.Develop ? 
                                                                        1 :
                                                                        listItem.Messages.Count;
                                                        return new EditorListRow(height: lineCount * 19);
                                                    })
                                            .ToArray();

            MyGUILayout.ListItems(onDraw,
                                  columns,
                                  rows,
                                  Skin.GetStyle("empty_box"),
                                  Skin.GetStyle("empty_line2"),
                                  Skin.GetStyle("empty_line1"));

            EditorGUILayout.EndVertical();
        }

        public Color GetStateColor(State state)
        {
            switch (state)
            {
                case State.Normal : return Color.cyan;
                case State.Error : return Color.red;
                case State.Develop : return Color.yellow;
                default : return Color.red;
            }
        }
    }
}