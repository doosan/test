using UnityEditor;
using UnityEngine;

#if UNITY_EDITOR_WIN
public static class SetAudioLatencyAsDefault
{
    [MenuItem("Underc/Set Audio Latency As Default", false, 3)]
    private static void Do()
    {
        AudioConfiguration config = AudioSettings.GetConfiguration();

        if (config.dspBufferSize != 0)
        {
            config.dspBufferSize = 0;
            config.sampleRate = 0;
            AudioSettings.Reset(config);

            Debug.LogWarning("윈도우즈 에디터에서는 Best Latency 세팅을 적용하면 사운드 딜레이가 발생하므로 Default 값으로 변경합니다.");
        }
    }
}
#endif