using UnityEngine;
using UnityEngine.Networking;
using Underc.User;
using epoch.Client.WebView;
using Gaga.Util;
using Gaga.AssetBundle;
using Underc.Net;
using System;

#if UNITY_EDITOR
using UnityEditor;
#endif

namespace Underc
{
    public enum Store
    {
        Empty = 0,
        Android = 1,
        iOS = 2,
        Etc = 3,
    }

    public static class AppService
    {
#pragma warning disable 0414
        private static readonly string APPLE_STORE_ID       = "1531042278";
        private static readonly string FB_FANPAGE_ID        = "101712631675250";

        private static readonly string URL_BASE             = "https://www.aquuuacasino.com";

        private static readonly string URL_TERMS_OF_SERVICE = URL_BASE + "/hc/en-us/articles/900002548643-Terms-of-Service";
        private static readonly string URL_FAQ              = URL_BASE + "/hc/en-us/categories/900000190866-FAQ";
        private static readonly string URL_PRIVACY_POLICY   = URL_BASE + "/hc/en-us/articles/900003425166-Privacy-Policy";
        private static readonly string URL_EPICCHEST_TABLE  = URL_BASE + "/hc/en-us/articles/10063934713113-Epic-Chest-Probability";

        private static readonly string URL_ASK_EMMA         = URL_BASE + "/hc/en-us/requests/new";
        private static readonly string URL_GDPR             = URL_BASE + "/hc/en-us/articles/900003425246-GDPR";
        private static readonly string URL_LICENSE          = "";
        private static readonly string URLENCODE_SPACE      = "%20";

        private static WebViewSettings webViewSettings;
#pragma warning restore 0414

        public static Store Store
        {
            get => (Store)StoreIntValue;
        }

        public static int StoreIntValue
        {
            get
            {
#if UNITY_ANDROID
                storeIntValue = 1;
#elif UNITY_IOS || UNITY_IPHONE
                storeIntValue = 2;
#else
                storeIntValue = 3;
#endif
                return storeIntValue;
            }
        }

        private static string serverTimeZone;
        private static int storeIntValue;

        public static string GetAppVersion()
        {
            return StringMaker.New()
                              .Append(Address.SERVER_NAME)
                              .Append(" ")
                              .Append(Application.version)
                              .Append(AssetBundleSystem.Instance.DisplayVersion ?? string.Empty)
                              .Build();
        }

        public static void OpenStore()
        {
            string storeURL = string.Empty;

#if UNITY_EDITOR
            storeURL = string.Format(System.Globalization.CultureInfo.InvariantCulture, "https://play.google.com/store/apps/details?id={0}", Application.identifier);
#elif UNITY_ANDROID
            storeURL = string.Format(System.Globalization.CultureInfo.InvariantCulture, "market://details?id={0}", Application.identifier);
#elif UNITY_IOS || UNITY_IPHONE
            storeURL = string.Format(System.Globalization.CultureInfo.InvariantCulture, "itms-apps://itunes.apple.com/app/id{0}", APPLE_STORE_ID);
#endif

            if (string.IsNullOrEmpty(storeURL) == false)
            {
                Application.OpenURL(storeURL);
                Debug.Log("Store URL : " + storeURL);
            }
            else
            {
                Debug.LogWarning("storeURL is empty");
            }
        }

        private static void OpenWebView(string url)
        {
            if (webViewSettings == null)
            {
                webViewSettings = new WebViewSettings();
                webViewSettings.ShowFullScreen = true;
#if UNITY_ANDROID || UNITY_IOS || UNITY_IPHONE
                webViewSettings.ShowTitleBar = false;
#endif
                webViewSettings.ShowNotToday = false;
            }

            WebView.ShowWebView(url, webViewSettings, (WebState state) =>
            {
                if (state == WebState.Open)
                {
                }
                else if (state == WebState.Fail)
                {
                }
                else if (state == WebState.Close)
                {
                }
            });
        }

        public static void OpenTermsOfService()
        {
            OpenWebView(URL_TERMS_OF_SERVICE);
        }

        public static void OpenFAQ()
        {
            OpenWebView(URL_FAQ);
        }

        public static void OpenPrivacyPolicy()
        {
            OpenWebView(URL_PRIVACY_POLICY);
        }

        public static void GoToFanpage()
        {
            Debug.Log($"UndercIosPlugin.CheckFacebookAppExists : {UndercIosPlugin.CheckFacebookAppExists()}");

            string baseURL = "https://www.facebook.com/";
#if UNITY_EDITOR

#elif UNITY_ANDROID
            if (CheckPackageExists("com.facebook.katana"))
            {
                baseURL = "fb://page/";
            }
#elif UNITY_IOS
            if (UndercIosPlugin.CheckFacebookAppExists())
            {
                baseURL = "fb://profile/";
            }
#endif

            string fanpageURL = StringMaker.New()
                                           .Append(baseURL)
                                           .Append(FB_FANPAGE_ID)
                                           .Build();

            if (string.IsNullOrEmpty(fanpageURL) == false)
            {
                Application.OpenURL(fanpageURL);
                Debug.Log("Fanpage URL : " + fanpageURL);
            }
        }

        private static bool CheckPackageExists(string package)
        {
            //note
            //특정앱을 열 수 있는지에 대해 iOS 의 경우 https://stackoverflow.com/questions/27844180/determining-if-facebook-app-is-installed-from-unity 참고할 것
            bool result = false;

            AndroidJavaClass up = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
            AndroidJavaObject ca = up.GetStatic<AndroidJavaObject>("currentActivity");
            AndroidJavaObject packageManager = ca.Call<AndroidJavaObject>("getPackageManager");

            //take the list of all packages on the device
            AndroidJavaObject appList = packageManager.Call<AndroidJavaObject>("getInstalledPackages", 0);
            int num = appList.Call<int>("size");
            for (int i = 0; i < num; i++)
            {
                AndroidJavaObject appInfo = appList.Call<AndroidJavaObject>("get", i);
                string packageNew = appInfo.Get<string>("packageName");
                if (packageNew.CompareTo(package) == 0)
                {
                    result = true;
                    break;
                }
            }

            return result;
        }

        public static void OpenGDPR()
        {
            OpenWebView(URL_GDPR);
        }

        public static void OpenLicense()
        {
            OpenWebView(URL_LICENSE);
        }

        public static void OpenEpicChestProbabilityTable()
        {
            OpenWebView(URL_EPICCHEST_TABLE);
        }

        public static void OpenUrl(string url)
        {
            Application.OpenURL(url);
        }

        public static void ExitApp()
        {
#if UNITY_EDITOR
            EditorApplication.isPlaying = false;
#else
            Application.Quit();
#endif
        }

        public static void SendEmailToSupport(string message = null)
        {
            var url = string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0}?pid={1}", URL_ASK_EMMA, MyInfo.ID);
            Application.OpenURL(url);
        }

        private static string EscapeURL(string url)
        {
            return UnityWebRequest.EscapeURL(url).Replace("+", URLENCODE_SPACE);
        }

        public static string Now()
        {
            return string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0:yyyy-MM-dd HH:mm:ss}", ToCST(System.DateTime.UtcNow));
        }

        public static DateTime NowDate(long timeStamp)
        {
            DateTime utcTime = DateTimeOffset.FromUnixTimeSeconds(timeStamp).DateTime;
            return ToCST(utcTime);
        }

        public static System.DateTime ToCST(System.DateTime dateUtc)
        {
            try
            {
                dateUtc = dateUtc.AddHours(-6);
                return dateUtc;
            }
            catch (System.TimeZoneNotFoundException e)
            {
                return new System.DateTime(dateUtc.AddHours(-6).Ticks, System.DateTimeKind.Unspecified);
            }
        }

        public static string GetLocalTimeZone()
        {
            TimeZoneInfo localZone = TimeZoneInfo.Local;
            var tz = localZone.BaseUtcOffset.ToString();
            tz = tz.Substring(0, tz.LastIndexOf(':'));
            tz = tz[0] == '-' ? tz : string.Format(System.Globalization.CultureInfo.InvariantCulture, "+{0}", tz);

            return tz;
        }

        public static void SetServerTimeZone(string tz)
        {
            serverTimeZone = tz;
        }

        public static string GetServerTimeZone()
        {
            return serverTimeZone;
        }
    }
}