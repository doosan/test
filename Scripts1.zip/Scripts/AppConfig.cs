namespace Underc
{
    public static class AppConfig
    {
        public const int RESOLUTION_WIDTH               = 1280;
        public const int RESOLUTION_HEIGHT              = 720;
        public const int TARGET_FRAME_GENERAL           = 60;
        public const int TARGET_FRAME_SLOT              = 60;
    }
}