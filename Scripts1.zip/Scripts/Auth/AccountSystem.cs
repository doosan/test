/*
신규가입시 진행 절차

기기 1
앱설치 및 실행
epochAccount가 null이면 MOC 서버로 신규가입 시도
서버로 부터 플레이팹 ID/PWD을 받고 플레이팹 로그인 (로그인 실패시 가입후 재로그인, A-PID 생성)
MOC 서버 로그인 시도 (기기 ID, 플레이팹 세션 티켓 서버로 전달)
MOC 서버 로그인 성공 (UserID - 1)
페북 최초 연결
MOC 서버로 fb_connect 호출 (기기ID, 페북 access_token 전달)
fb_connect 응답에 신규가입시 전달했던 플레이팹 ID, PWD가 와야함.
클라는 현재 로그인된 플레이팹 ID와 PWD가 같으므로 플레이팹 재로그인 안함.


기기 2
앱설치 및 실행
epochAccount가 null이면 MOC 서버로 신규가입 시도
서버로 부터 플레이팹 ID/PWD을 받고 플레이팹 로그인 (로그인 실패시 가입후 재로그인, B-PID 생성)
MOC 서버 로그인 시도 (기기 ID, 플레이팹 세션 티켓 서버로 전달)
MOC 서버 로그인 성공 (UserID - 2)
페북 연결 (기기1에서 연결했던 계정)
MOC 서버 fb_connect 응답에 기기1에서 전달했던 플레이팹 ID, PWD가 와야함. 즉 플레이팹 ID, PWD는 페북 최초 연결시에 설정된 값이 와야함. 갱신 x
클라는 현재 로그인된 플레이팹 ID와 PWD가 페북 연결에서 받은 계정정보와 다르므로 플레이팹 재로그인 ( A-PID로 변경)
MOC 서버 로그인 재시도 (기기 ID, 플레이팹 세션 티켓 서버로 전달)
MOC 서버 로그인 성공 (UserID - 1)
*/

using System;
using Gaga.IO;
using Underc.Net;
using Underc.User;
using Underc.Platform;
using Underc.Popup;
using System.Collections.Generic;
using Underc.Net.Client;
using UnityEngine.CrashReportHandler;

namespace Underc.Auth
{
    public class PlatformLoginInfo
    {
        public PlatformLoginType type;
        public IPlatformLogin platformLogin;
        public string connectReq;
        public string tokenName;

        public PlatformLoginInfo(PlatformLoginType type, IPlatformLogin platformLogin, string connectReq, string tokenName)
        {
            this.type = type;
            this.platformLogin = platformLogin;
            this.connectReq = connectReq;
            this.tokenName = tokenName;
        }
    }

    public static class AccountSystem
    {
        private static readonly string EPOCH_ACCOUNT_FILENAME_LEGACY    = "ea.sav"; // 암호화된 계정 정보 파일명. 앞으로 안쓰지만 지우면 안됨.
        private static readonly string EPOCH_ACCOUNT_FILENAME           = "nea.sav";
        private static readonly float PROGRESS_REGISTER_SERVER          = 0.2f;
        private static readonly float PROGRESS_REGISTER_EPOCH           = 0.4f;
        private static readonly float PROGRESS_LOGIN_EPOCH              = 0.6f;
        private static readonly float PROGRESS_LOGIN_SERVER             = 1.0f;

        [Serializable]
        public sealed class EpochAccountInfo
        {
            public string key;
            public string id;
            public string password;
        }

        public enum PlatformConnectionResult
        {
            AlreadyConnected,   //이미연결됨
            Success,            //성공
            SuccessAndRestart,  //성공, 앱 재시작
            Failed,             //실패
            FailedAndRestart,   //실패, 앱 재시작 (연결 기록이 없는 페북 연결 시도시)
            Canceled            //취소
        }

        public static string SessionTicket
        {
            get; private set;
        }

        public static string PlayfabID
        {
            get; private set;
        }

        private static Action onComplete;
        private static Action<float> onProgress;
        private static Action<string> onError;
        private static EpochAccountInfo epochAccount;
        private static bool isFirstLogin;

        private static Dictionary<PlatformLoginType, PlatformLoginInfo> platformLoginInfos;
        private static Queue<PlatformLoginInfo> platformLoginInfoQueue;

        public static void Initialize()
        {
            platformLoginInfos = new Dictionary<PlatformLoginType, PlatformLoginInfo>();
            platformLoginInfos.Add(PlatformLoginType.Facebook,
                                   new PlatformLoginInfo(PlatformLoginType.Facebook, FacebookLogin.Instance, "fb_connect", "access_token"));
            if (AppService.Store == Store.iOS)
            {
                platformLoginInfos.Add(PlatformLoginType.Apple,
                                       new PlatformLoginInfo(PlatformLoginType.Apple, AppleLogin.Instance, "apple_connect", "token"));
            }

            platformLoginInfoQueue = new Queue<PlatformLoginInfo>();
            foreach (PlatformLoginInfo info in platformLoginInfos.Values)
            {
                platformLoginInfoQueue.Enqueue(info);
            }
        }

        public static void Login(Action onComplete, Action<float> onProgress, Action<string> onError)
        {
            Debug.Log("AccountSystem Login - start");

            AccountSystem.onComplete = onComplete;
            AccountSystem.onProgress = onProgress;
            AccountSystem.onError = onError;

            RestorePlatformLoginQueue(SetupEpoch);
        }

        private static void RestorePlatformLoginQueue(Action onComplete)
        {
            if (platformLoginInfoQueue.Count > 0)
            {
                PlatformLoginInfo platformLoginInfo = platformLoginInfoQueue.Dequeue();
                Debug.Log("==== RestorePlatformLogin : " + platformLoginInfo.type);
                RestorePlatformLogin(platformLoginInfo.platformLogin, 
                                     () => RestorePlatformLoginQueue(onComplete) /* call recursively */);
            }
            else
            {
                onComplete?.Invoke();
            }
        }

        private static void RegisterServer()
        {
            Debug.Log("AccountSystem RegisterServer - start");

            NetworkSystem.HTTPRequester.Register(registerResp =>
            {
                bool isRegisterSuccess = registerResp.isSuccess == true && registerResp.ret == 0;
                if (isRegisterSuccess == true)
                {
                    Debug.Log("AccountSystem RegisterServer - success");

                    onProgress?.Invoke(PROGRESS_REGISTER_SERVER);

                    epochAccount = CreateEpochAccount(registerResp.userid, registerResp.pwd);
                    LoginEpoch(epochAccount.id, epochAccount.password);
                }
                else
                {
                    Debug.Log("AccountSystem RegisterServer - error");
                    onError?.Invoke(registerResp.error);
                }
            });
        }

        private static void LoginServer(string epochSessionTicket, bool isRevoke = false)
        {
            Debug.Log("AccountSystem LoginServer - start");
            NetworkSystem.HTTPRequester.Login(epochSessionTicket, isRevoke, LoginProcess);
        }

        private static void LoginProcess(LoginResponse loginResponse)
        {
            MyInfo.ID = loginResponse.userid;

            if (string.IsNullOrEmpty(MyInfo.ID) == false)
            {
                CrashReportHandler.SetUserMetadata("user_id", MyInfo.ID);
            }

            bool isLoginSuccess = loginResponse.isSuccess == true && loginResponse.ret == 0;
            if (isLoginSuccess == true)
            {
                Debug.Log("AccountSystem LoginServer - success");

                onProgress?.Invoke(PROGRESS_LOGIN_SERVER);

                MyInfo.registedTimeStmap = loginResponse.reg_ts;
                MyInfo.broadcastPollingTime = loginResponse.time.poll;
                MyInfo.notiCheckPollingTime = loginResponse.time.check_poll;

                var sessionID = loginResponse.sessid;
                NetworkSystem.HTTPRequester.SetDefaultMessages(long.Parse(MyInfo.ID), sessionID);

                if (isFirstLogin)
                {
                    // 첫 로그인이라 페이스북 로그인 또는 애플 로그인 하나만 IsLoggedIn == true 일 것이라 가정
                    PlatformLoginInfo targetPlatformLoginInfo = null;
                    foreach (PlatformLoginInfo info in platformLoginInfos.Values)
                    {
                        if (info.platformLogin.IsLoggedIn)
                        {
                            targetPlatformLoginInfo = info;
                            break;
                        }
                    }

                    if (targetPlatformLoginInfo != null)
                    {
                        PlatformLoginType type = targetPlatformLoginInfo.type;
                        IPlatformLogin platformLogin = targetPlatformLoginInfo.platformLogin;
                        string connectReq = targetPlatformLoginInfo.connectReq;
                        string tokenName = targetPlatformLoginInfo.tokenName;
                        ConnectToPlatform(
                            type: type,
                            platformLogin: platformLogin,
                            connectReq: connectReq,
                            tokenName: tokenName,
                            onComplete: result =>
                            {
                                if (result == PlatformConnectionResult.Success)
                                {
                                    onComplete?.Invoke();
                                }
                                else if (result == PlatformConnectionResult.Canceled
                                        || result == PlatformConnectionResult.Failed)
                                {
                                    onError?.Invoke(string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0} failed.", platformLogin.ToString()));
                                }
                            }
                        );
                    }
                    else
                    {
                        onComplete?.Invoke();
                    }
                }
                else
                {
                    onComplete?.Invoke();
                }
            }
            else
            {
                Debug.Log("AccountSystem LoginServer - error : " + loginResponse.error);
                string error = loginResponse.error;
                if (error == "revoke")
                {
                    Popups.RestoreAccount(onRestoreClick: () => LoginServer(SessionTicket, isRevoke: true))
                          .Async();
                }
                else if (error == "no uid"
                         || error == "removed")
                {
                    //서버에 유저 정보가 없으면 에폭어카운트 파일을 제거후 로그인 처음부터 다시 진행
                    DeleteEpochAccount();
                    Login(onComplete, onProgress, onError);
                }
                else
                {
                    onError?.Invoke(error);
                }
            }
        }

        private static void SetupEpoch()
        {
            epoch.Client.Util.Util.CreateEpochGameObject((epoch.Client.Util.Zone)SDKConfig.GetCurrentSdkInfo().epochZoneIndex, result =>
            {
                if(result == true)
                {
                    Debug.Log("AccountSystem CreateEpochGameObject - success");

                    if (epochAccount == null)
                    {
                        epochAccount = ReadEpochAccount();

                        if (epochAccount == null)
                        {
                            isFirstLogin = true;
                            RegisterServer();
                        }
                        else
                        {
                            if (string.IsNullOrEmpty(epochAccount.id) || string.IsNullOrEmpty(epochAccount.password))
                            {
                                epochAccount = null;
                                isFirstLogin = true;
                                RegisterServer();
                            }
                            else
                            {
                                isFirstLogin = false;
                                LoginEpoch(epochAccount.id, epochAccount.password);
                            }
                        }
                    }
                    else
                    {   
                        isFirstLogin = false;
                        LoginEpoch(epochAccount.id, epochAccount.password);
                    }
                }
                else
                {
                    Debug.Log("AccountSystem CreateEpochGameObject - error");
                    onError?.Invoke("error - CreateEpochGameObject");
                }
            });  
        }

        private static void RegisterEpoch(string id, string pwd)
        {
            Debug.Log("AccountSystem RegisterEpoch - start");

            epoch.Client.Auth.Auth.RegisterAccount(epoch.Client.Util.Platform.UserID
                                                   ,id
                                                   ,pwd
                                                   ,result =>
                                                   {
                                                       if (result.IsSuccess())
                                                       {
                                                           Debug.Log("AccountSystem RegisterEpoch - success");

                                                           epoch.Client.Util.Util.PlayfabID = result.PlayFabId;
                                                           Debug.Log("register PlayfabID : "+epoch.Client.Util.Util.PlayfabID);
                                                           UndercGameLog.Fobis.AccountJoin();

                                                           onProgress?.Invoke(PROGRESS_REGISTER_EPOCH);
                                                           LoginEpoch(id, pwd);
                                                       }
                                                       else
                                                       {
                                                           Debug.Log("AccountSystem RegisterEpoch - error");
                                                           onError?.Invoke(result.GetMessage());
                                                       }
                                                   });
        }

        private static void LoginEpoch(string id, string pwd)
        {
            Debug.Log("AccountSystem LoginEpoch - start : " + id +" , "+ pwd);
            epoch.Client.Auth.Auth.LoginPlatform(
                epoch.Client.Util.Platform.UserID
                ,authResult =>
                {
                    Debug.Log("AccountSystem LoginEpoch Result  :  "+authResult.IsSuccess());
                    if (authResult.IsSuccess())
                    {
                        PlayfabID = authResult.PlayFabId;
                        SessionTicket = authResult.SessionTicket;

                        
                        onProgress?.Invoke(PROGRESS_LOGIN_EPOCH);
                        LoginServer(SessionTicket);
                    }
                    else
                    {
                        Debug.Log("AccountSystem LoginEpoch - error message : "+authResult.GetMessage());
                        Debug.Log("AccountSystem LoginEpoch - error code : "+authResult.GetDetailCode());

                        isFirstLogin = true;
                        RegisterEpoch(id, pwd);
                    }
                }
                ,id
                ,pwd);
        }  

        private static void RestorePlatformLogin(IPlatformLogin platformLogin, Action onComplete)
        {
#if UNITY_EDITOR
            onComplete?.Invoke();
#else
            if (platformLogin.IsLoggedIn)
            {
                platformLogin.LogIn(result =>
                {
                    onComplete?.Invoke();
                });
            }
            else
            {
                onComplete?.Invoke();
            }
#endif
        }

        public static void ConnectToFacebook(Action<PlatformConnectionResult> onComplete)
        {
            PlatformLoginInfo info = platformLoginInfos[PlatformLoginType.Facebook];
            ConnectToPlatform(info.type, info.platformLogin, info.connectReq, info.tokenName, onComplete);
        }

        public static void ConnectToApple(Action<PlatformConnectionResult> onComplete)
        {
            PlatformLoginInfo info = platformLoginInfos[PlatformLoginType.Apple];
            ConnectToPlatform(info.type, info.platformLogin, info.connectReq, info.tokenName, onComplete);
        }

        public static void ConnectToPlatform(PlatformLoginType type, Action<PlatformConnectionResult> onComplete)
        {
            PlatformLoginInfo info = platformLoginInfos[type];
            ConnectToPlatform(info.type, info.platformLogin, info.connectReq, info.tokenName, onComplete);
        }

        public static void ConnectToPlatform(PlatformLoginType type, IPlatformLogin platformLogin, string connectReq, string tokenName, Action<PlatformConnectionResult> onComplete)
        {
            Debug.Log("==== ConnectToPlatform : " + type + ", " + connectReq);
            var startTimeLog = AppService.Now();
            var startTypeLog = (int)type;

            platformLogin.LogIn(result =>
            {
                if (result == PlatformLoginResult.Success)
                {
                    NetworkSystem.HTTPRequester.PlatformConnect(
                        connectReq,
                        tokenName,
                        platformLogin.IdentityToken,
                        (PlatformConnectResponse response) =>
                        {
                            var endTimeLog = AppService.Now();
                            var endTypeLog = (int)type;

                            if (response.isSuccess == true && response.ret == 0)
                            {
                                UndercGameLog.Fobis.AccountLink(startTimeLog, startTypeLog, endTimeLog, endTypeLog, 1);

                                //페북로그인 후 현재 유저 ID와 다르면 재로그인을 위해 인트로로 보냄.
                                //이때 페북 계정이 다른기기와 한번도 연동된 적이 없다면, 신규가입을 위해
                                //현재 epoch계정정보를 제거함.
                                Debug.Log($"==== PlatformConnectResponse : {response.userid} vs {epochAccount.id}");
                                if (response.userid != epochAccount.id
                                    && response.required == "register")
                                {
                                    DeleteEpochAccount();
                                    LogoutPlatformLogin(exceptType: type);
                                    onComplete?.Invoke(PlatformConnectionResult.FailedAndRestart);
                                    Scene.SceneSystem.LoadIntro();
                                }
                                else if (response.userid != epochAccount.id
                                         && string.IsNullOrEmpty(response.userid) == false)
                                {
                                    epochAccount = CreateEpochAccount(response.userid, response.pwd);
                                    LogoutPlatformLogin(exceptType: type);
                                    onComplete?.Invoke(PlatformConnectionResult.SuccessAndRestart);
                                    Scene.SceneSystem.LoadIntro();
                                }
                                else
                                {
                                    // 계정에 처음연동되는 페북이라면 보너스를 받기위해 서버로 OceanBonus를 요청함.
                                    NetworkSystem.HTTPRequester.OceanBonus(resp =>
                                    {
                                        if (resp.isSuccess && resp.ret == 0)
                                        {
                                            NetworkSystem.HTTPHandler.Do(resp);
                                        }

                                        onComplete?.Invoke(PlatformConnectionResult.Success);
                                    });
                                }
                            }
                            else
                            {
                                UndercGameLog.Fobis.AccountLink(startTimeLog, startTypeLog, endTimeLog, endTypeLog, 3);

                                platformLogin.LogOut();
                                onComplete?.Invoke(PlatformConnectionResult.Failed);
                            }
                        }
                    );
                }
                else if (result == PlatformLoginResult.Canceled)
                {
                    UndercGameLog.Fobis.AccountLink(startTimeLog, startTypeLog, AppService.Now(), 1, 2);

                    onComplete?.Invoke(PlatformConnectionResult.Failed);
                }
                else
                {
                    UndercGameLog.Fobis.AccountLink(startTimeLog, startTypeLog, AppService.Now(), 1, 3);

                    onComplete?.Invoke(PlatformConnectionResult.Failed);
                    Popups.Error(platformLogin.Error);
                }
            });
        }

        public static void DisconnectToPlatform(PlatformLoginType type, Action<bool> onComplete)
        {
            if (type == PlatformLoginType.Facebook)
            {
                DisconnectToFacebook(onComplete);
            }
            else if (type == PlatformLoginType.Apple)
            {
                DisconnectToApple(onComplete);
            }
        }

        public static void DisconnectToApple(Action<bool> onComplete)
        {
            if (AppleLogin.Instance.IsLoggedIn)
            {
                AppleLogin.Instance.LogOut();
                onComplete?.Invoke(false);
            }
            else
            {
                onComplete?.Invoke(false);
            }
        }

        public static void DisconnectToFacebook(Action<bool> onComplete)
        {
            if (FacebookLogin.Instance.IsLoggedIn)
            {
                NetworkSystem.HTTPRequester.FBDisconnect(resp =>
                {
                    if (resp.userid == epochAccount.id)
                    {
                        FacebookLogin.Instance.LogOut();
                        onComplete?.Invoke(true);
                    }
                    else
                    {
                        onComplete?.Invoke(false);
                    }
                });
            }
            else
            {
                onComplete?.Invoke(false);
            }
        }

        public static bool IsFacebookConnected
        {
            get => FacebookLogin.Instance.IsLoggedIn;
        }

        public static bool IsAppleLoginConnected
        {
            get => AppleLogin.Instance.IsLoggedIn;
        }

        public static bool IsPlatformLoginConnected(PlatformLoginType type)
        {
            bool result = false;
            if (platformLoginInfos.ContainsKey(type))
            {
                result = platformLoginInfos[type].platformLogin.IsLoggedIn;
            }
            return result;
        }

        private static EpochAccountInfo CreateEpochAccount(string id, string pwd)
        {
            var newAcc = new EpochAccountInfo();
            newAcc.id = id;
            newAcc.password = pwd;
            newAcc.key = GetKey();

            FileIO.WriteSerializeClassToFileWithBase64(newAcc, EPOCH_ACCOUNT_FILENAME);

            return newAcc;
        }

        private static EpochAccountInfo ReadEpochAccount()
        {
            // 암호화 되지 않은 어카운트 파일이 있다면 제거 후 새로운 암호화 파일로 대치
            EpochAccountInfo legacyInfo = FileIO.ReadSerializeClassFromFile<EpochAccountInfo>(EPOCH_ACCOUNT_FILENAME_LEGACY);

            if (legacyInfo != null)
            {
                Debug.Log("AccountSystem - 암호화 되지 않은 계정 정보를 발견!! 제거 후 암호화 된 계정 정보로 대치 함.");
                FileIO.DeleteFile(EPOCH_ACCOUNT_FILENAME_LEGACY);

                CreateEpochAccount(legacyInfo.id, legacyInfo.password);
            }
            else
            {
                Debug.Log("AccountSystem - 암호화 되지 않은 계정 정보 미발견");
            }

            Debug.Log("AccountSystem tryReadEpochAccount");
            EpochAccountInfo info = FileIO.ReadSerializeClassFromFileWithBase64<EpochAccountInfo>(EPOCH_ACCOUNT_FILENAME);

            if (info == null)
            {
                Debug.Log("AccountSystem accountInfo null");
                return null;
            }

            if (string.IsNullOrEmpty(info.key))
            {
                info.key = "d";
            }

            // 개발환경에서 여러서버를 전환할때 플레이팹 계정정보가 꼬이는 현상을 해결하기위해
            // 서버타입을 key로분리해 체크함.

            string targetKey = GetKey();

            if (info.key != targetKey)
            {
                Debug.Log("AccountSystem info key != targetkey");
                LogoutPlatformLogin();
                DeleteEpochAccount();
                return null;
            }

            return info;
        }

        public static void LogoutPlatformLogin(PlatformLoginType exceptType = PlatformLoginType.None)
        {
            foreach (PlatformLoginInfo platformLoginInfo in platformLoginInfos.Values)
            {
                if ((platformLoginInfo.type & exceptType) > 0)
                {
                    continue;
                }

                platformLoginInfo.platformLogin.LogOut();
            }
        }

        private static void DeleteEpochAccount()
        {
            FileIO.DeleteFile(EPOCH_ACCOUNT_FILENAME);
            epochAccount = null;
        }

        // 앱 첫구동 체크
        public static bool IsFirstLaunch()
        {
            Debug.Log("AccountSystem call isFirstLaunch");
            var acc = ReadEpochAccount();

            // 아무데도 로그인한 흔적이 없으면
            return acc == null && IsAnyPlatformLoggedIn() == false;
        }

        public static bool IsAnyPlatformLoggedIn(PlatformLoginType exceptType = PlatformLoginType.None)
        {
            bool result = false;
            foreach (PlatformLoginInfo platformLoginInfo in platformLoginInfos.Values)
            {
                if ((platformLoginInfo.type & exceptType) > 0)
                {
                    continue;
                }

                result |= platformLoginInfo.platformLogin.IsLoggedIn;
            }
            return result;
        }

        private static string GetKey()
        {
            string targetKey = "";
#if REAL
            targetKey = "r";
#elif QA || STAGE
            targetKey = "q";
#else
            targetKey = "d";
#endif
            return targetKey;
        }
    }
}