﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Underc.User;
using Underc.Scene;
using Underc.Net;
using Underc.Popup;
using Gaga;
using Gaga.Popup;
using Gaga.System;

namespace Underc
{
    public class MaintenanceSystem : GameObjectSingleton<MaintenanceSystem>
    {
        private Dictionary<string, MaintenanceData> dataDic;
        private Coroutine pollingCoroutine;
        public string CurrentSlotID { get; set; }
        private PopupObject<MaintenancePopup> popupObject;
        private bool running;

        public void Initialize()
        {
            dataDic = new Dictionary<string, MaintenanceData>();

            UnityEngine.SceneManagement.SceneManager.sceneLoaded += OnSceneLoaded;
            UnityEngine.SceneManagement.SceneManager.sceneUnloaded += OnSceneUnloaded;
        }

        private void OnSceneLoaded(UnityEngine.SceneManagement.Scene scene, UnityEngine.SceneManagement.LoadSceneMode mode)
        {
            if (scene.name == SceneSystem.LobbyScene || scene.name == SceneSystem.GameScene || scene.name == SceneSystem.GameScenePortrait)
            {
                StartWatch();
            }
        }

        private void OnSceneUnloaded(UnityEngine.SceneManagement.Scene scene)
        {
            if (scene.name == SceneSystem.LobbyScene || scene.name == SceneSystem.GameScene || scene.name == SceneSystem.GameScenePortrait)
            {
                StopWatch();
            }
        }

        public void StopWatch()
        {
            popupObject = null;
            CurrentSlotID = string.Empty;
            running = false;

            StopPolling();
        }

        public void StartWatch()
        {
            running = true;
            StartPolling();
        }

        private void StartPolling()
        {
            pollingCoroutine = StartCoroutine(PollingCoroutine());
        }

        private void StopPolling()
        {
            if (pollingCoroutine != null)
            {
                StopCoroutine(pollingCoroutine);
                pollingCoroutine = null;
            }
        }

        private void FindMaintenceData()
        {
            if (running == false)
            {
                return;
            }

            MaintenanceData data = GetAppData() ?? GetSlotData(CurrentSlotID);
            OpenPopup(data);
        }

        public PopupObject<MaintenancePopup> OpenPopup(MaintenanceData data)
        {
            if (popupObject == null)
            {
                if (data != null)
                {
                    popupObject = Popups.Maintenance(data, () => { popupObject = null; }).SetIgnoreCount(true);
                }
            }
            else
            {
                MaintenancePopup popup = popupObject.GetPopup();
                if (popup != null)
                {
                    popup.UpdateData(data);
                }
            }

            return popupObject;
        }

        private IEnumerator PollingCoroutine()
        {
            float pollingTime = MyInfo.notiCheckPollingTime;
            if( pollingTime == 0 )
            {
                pollingTime = 30f;
            }

            var waitForSeconds = new WaitForSeconds(pollingTime);
            do
            {
                var req = NetworkSystem.HTTPRequester.NotiCheck();
                yield return req.WaitForResponse();

                if (req.data.isSuccess == true && req.data.ret == 0)
                {
                    UpdateDatas(req.data.check);
                }

                yield return waitForSeconds;
            } while (running);
        }

        public void UpdateDatas(MaintenanceData[] datas)
        {
            dataDic.Clear();

            if (datas != null)
            {
                for (int i = 0; i < datas.Length; ++i)
                {
                    MaintenanceData data = datas[i];
                    dataDic.Add(data.id, data);
                }
            }

            FindMaintenceData();
        }

        public MaintenanceData GetAppData()
        {
            var data = GetData(MaintenanceData.ID_APP);
            return data;
        }

        public MaintenanceData GetSlotData(string slotid)
        {
            var data = GetData(slotid);
            return data;
        }

        private MaintenanceData GetData(string id)
        {
            if (dataDic == null || string.IsNullOrEmpty(id))
            {
                return null;
            }

            MaintenanceData data = null;
            if (dataDic.TryGetValue(id, out data) == false)
            {
                return null;
            }

            //종료 시간이 아직 지나지 않은 데이터만 반환한다
            long now = GlobalTime.Instance.GetTimeStamp();
            if (now < data.end)
            {
                return data;
            }
            else
            {
                return null;
            }
        }
    }
}
