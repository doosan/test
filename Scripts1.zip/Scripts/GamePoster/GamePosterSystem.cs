using Gaga.AssetBundle;
using UnityEngine;
using Gaga.Skin;
using Gaga.System;
using Underc.User;
using Gaga.Util;

namespace Underc
{
    public sealed class GamePosterSystem : GameObjectSingleton<GamePosterSystem>
    {
        private readonly string POSTER_OPTIONS_NAME         = "GamePosterOptions";
        private readonly int MAX_POSTER_POOL_CNT            = 3;

        private bool isInit = false;
        private Gaga.AssetBundle.AssetBundle posterAssetBundle;
        private GameObjectPoolGroup<GamePoster> posterPoolGroup;
        public GamePosterOptions PosterOptions{get; private set;}

        public void Initialize()
        {
            if (isInit)
            {
                return;
            }

            isInit = true;
            posterAssetBundle = AssetBundleSystem.Instance.GetLoadedAssetBundle(Util.AssetBundleName.SLOT_POSTERS);

            var poolRoot = new GameObject("Pool");
            poolRoot.transform.SetParent(transform);

            posterPoolGroup = new GameObjectPoolGroup<GamePoster>(poolRoot);
            PosterOptions = posterAssetBundle.GetAsset<GamePosterOptions>(POSTER_OPTIONS_NAME);
        }

        private void OnDestroy()
        {
            if (posterAssetBundle != null)
            {
                AssetBundleSystem.Instance.Unload(posterAssetBundle.Name, false);
            }
        }

        public void Preload()
        {
            var slotDatas = MyInfo.SlotGame.GetSlotDatas(MyInfo.SlotGame.DEFAULT_ORDER);

            foreach (var data in slotDatas)
            {
                var skin = Skin.ConvertToSkinType(data.Skin);
                var posterID = CreatePosterID(data.slotid, skin);

                if (IsValidPosterID(posterID) && ContainsPosterPool(posterID) == false)
                {
                    AddPosterPool(posterID);
                }
            }
        }

        public bool ContainsPosterPool(string slotID, SkinType skin)
        {
            var posterID = CreatePosterID(slotID, skin);
            return ContainsPosterPool(posterID);
        }

        public bool ContainsPosterPool(string posterID)
        {
            return posterPoolGroup.Contains(posterID);
        }

        private int CountsPosterPool(string slotID, SkinType skin)
        {
            var posterID = CreatePosterID(slotID, skin);
            return CountPosterPool(posterID);
        }

        private int CountPosterPool(string posterID)
        {
            return posterPoolGroup.IdleCount(posterID);
        }

        public bool IsValidPosterID(string slotID, SkinType skin)
        {
            var posterID = CreatePosterID(slotID, skin);
            return IsValidPosterID(posterID);
        }

        public bool IsValidPosterID(string posterID)
        {
            return posterAssetBundle.ContainsAssetName(posterID);
        }

        private void AddPosterPool(string posterID)
        {
            Debug.Log($"GamePosterSystem AddPosterPool : {posterID}");

             posterPoolGroup.Add(posterID, 
                                ()=>
                                {
                                    var obj = posterAssetBundle.GetGameObject(posterID);
                                    var objComp = obj.AddComponent<GamePoster>();
                                    objComp.Init(posterID);

                                    return objComp;
                                }, 
                                1);
        }

        public GamePoster Get(string slotID, SkinType skin = SkinType.None)
        {
            var posterID = CreatePosterID(slotID, skin);

            if (IsValidPosterID(posterID) == false)
            {
                return null;
            }

            if (ContainsPosterPool(slotID, skin) == false)
            {
                AddPosterPool(posterID);
            }

            var poster = posterPoolGroup.Get(posterID);
            poster.Reset();

            return poster;
        }

        public void Return(GamePoster poster)
        {
            if (ContainsPosterPool(poster.ID))
            {
                if (CountPosterPool(poster.ID) >= MAX_POSTER_POOL_CNT)
                {
                    Debug.Log($"GamePosterSystem Return시 포스터 갯수가 최대 갯수 인 {MAX_POSTER_POOL_CNT}를(을) 초과해 바로 삭제함. - {poster.ID}");
                    Destroy(poster.gameObject);
                }
                else
                {
                    try
                    {
                        posterPoolGroup.Return(poster.ID, poster);
                    }
                    catch{}
                }
            }
            else
            {
                Destroy(poster.gameObject);
            }
        }

        private string CreatePosterID(string id, SkinType skin = SkinType.None)
        {
            var sm = StringMaker.New();
            sm.Append("Poster");
            sm.Append(id);

            if (skin != SkinType.None)
            {
                sm.Append("_");
                sm.Append(skin.ToString());
            }

            var posterID = sm.Build();

            if (skin != SkinType.None && IsValidPosterID(posterID) == false)
            {
                return CreatePosterID(id, SkinType.None);
            }

            return posterID;
        }
    }
}