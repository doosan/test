using UnityEngine;
using Spine.Unity;

namespace Underc
{
    public sealed class GamePoster : MonoBehaviour
    {
        public string ID{get; private set;}
        public SkeletonGraphic SkeletonGraphic{get; private set;}

        public void Init(string id)
        {
            if (string.IsNullOrEmpty(ID))
            {
                ID = id;
            }

            SkeletonGraphic = GetComponentInChildren<SkeletonGraphic>(true);
        }

        public void Reset()
        {
            if (SkeletonGraphic != null)
            {
                SkeletonGraphic.timeScale = 1.0f;
            }
        }
    }
}