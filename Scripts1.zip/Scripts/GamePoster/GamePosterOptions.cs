using UnityEngine;
using System;
using System.Collections.Generic;

namespace Underc
{
    public class GamePosterOptions : ScriptableObject
    {
        [Serializable]
        public sealed class JackpotInfo
        {
            public string slotID;
            public int maxCount;
        }

#pragma warning disable 0649
        [SerializeField] private List<JackpotInfo> jackpotInfoList;
#pragma warning restore 0649

        private Dictionary<string, JackpotInfo> jackpotInfoDic;

        public int GetMaxJackpotCount(string slotID)
        {
            if (jackpotInfoDic == null)
            {
                jackpotInfoDic = new Dictionary<string, JackpotInfo>();

                for (int i = 0; i < jackpotInfoList.Count; i++)
                {
                    var info = jackpotInfoList[i];

                    if (jackpotInfoDic.ContainsKey(info.slotID) == false)
                    {
                        jackpotInfoDic.Add(info.slotID, info);
                    }
                }
            }

            if (jackpotInfoDic.ContainsKey(slotID))
            {
                return jackpotInfoDic[slotID].maxCount;
            }
            else
            {
                return int.MaxValue;
            }
        }
    }
}