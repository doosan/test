using Gaga.AssetBundle;
using Gaga.System;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEngine;

namespace Underc
{
    public class BaseIconSystem<T> : Singleton<T> where T : class
    {
        public int AssetCount
        {
            get => assetNames.Count;
        }
        public Dictionary<int, string>.KeyCollection AssetKeys
        {
            get => assetNames.Keys;
        }

        private Dictionary<int, string> assetNames;
        private Gaga.AssetBundle.AssetBundle assetBundle;

        protected void Initialize(string assetBundleName, 
                                  Action<bool> onComplete, 
                                  Action<int> onProgress)
        {
            AssetBundleSystem.Instance.Load(
                loadType: AssetBundleLoadType.Load,
                url: Net.Address.CDN_ASSETBUNDLES,
                assetBundleName: assetBundleName,
                onLoadComplete: (bool isSuccess, Gaga.AssetBundle.AssetBundle ab) =>
                {
                    assetBundle = ab;
                    CacheAssetNames();

                    onComplete?.Invoke(isSuccess);
                },
                onLoadProgress: (float progress) =>
                {
                    int progressVal = (int)(progress * 100.0f);
                    onProgress?.Invoke(progressVal);
                }
            );
        }

        private void CacheAssetNames()
        {
            assetNames = new Dictionary<int, string>();
            var grabIndexPattern = new Regex("\\d+");
            foreach (KeyValuePair<string, string> asset in assetBundle.Assets)
            {
                string matched = grabIndexPattern.Match(asset.Key).ToString();
                if (string.IsNullOrEmpty(matched) == true)
                {
                    if (int.TryParse(asset.Key, out _))
                    {
                        Debug.LogWarning("에셋 인덱스를 찾을 수 없습니다 : " + asset.Key);
                    }
                    continue;
                }

                int assetIndex = int.Parse(matched);
                //Debug.Log("==== CacheAssetNames : " + assetIndex + ", " + asset.Key);
                assetNames.Add(assetIndex, asset.Key);
                /// e.g. {1: "ui_profile_img_1"}
                /// e.g. {1: "1001_Thumbnail"}
            }
        }

        public Sprite Get(int picIndex)
        {
            if (assetBundle == null)
            {
                return null;
            }

            var iconName = GetIconName(picIndex);
            if (string.IsNullOrEmpty(iconName) == true)
            {
                return null;
            }

            return assetBundle.GetSprite(iconName);
        }

        public void GetAsync(int picIndex, Action<Sprite> onComplete)
        {
            if (assetBundle == null)
            {
                Debug.Log("==== GetAsync : assetBundle is null");
                onComplete(null);
                return;
            }

            var iconName = GetIconName(picIndex);
            if (string.IsNullOrEmpty(iconName) == true)
            {
                Debug.Log("==== GetAsync : iconName is empty");
                onComplete(null);
                return;
            }

            //Debug.Log("==== GetAsync 3 : " + picIndex + ", " + iconName);
            assetBundle.GetSpriteAsync(iconName, onComplete);
        }

        private string GetIconName(int picIndex)
        {
            if (assetNames.ContainsKey(picIndex) == false)
            {
                if (picIndex >= 0)
                {
                    Debug.LogWarning("해당 인덱스의 에셋은 존재하지 않습니다 : " + picIndex);
                }
                return null;
            }

            return assetNames[picIndex];
        }
    }
}