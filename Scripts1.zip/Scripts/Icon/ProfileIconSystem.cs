using System;
using Underc.Util;

namespace Underc
{
    public sealed class ProfileIconSystem : BaseIconSystem<ProfileIconSystem>
    {
        public void Initialize(Action<bool> onComplete, Action<int> onProgress)
        {
            base.Initialize(AssetBundleName.ICON_PROFILE, onComplete, onProgress);
        }
    }
}