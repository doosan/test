using System;
using System.Collections.Generic;
using Underc.Net;
using UnityEngine;

namespace Underc
{
    public static class UndercPrefs
    {
        private static Dictionary<string, string> remoteValues;

        public static void SetLocalValue(string key, string value)
        {
            PlayerPrefs.SetString(key, value);
            PlayerPrefs.Save();
        }

        public static string GetLocalValue(string key, string defaultValue)
        {
            var rv = defaultValue;
            if (ContainsLocalValue(key) == true)
            {
                rv = PlayerPrefs.GetString(key, defaultValue);
            }
            else
            {
                SetLocalValue(key, defaultValue);
            }

            return rv;
        }

        public static void SetLocalValue(string key, int value)
        {
            PlayerPrefs.SetInt(key, value);
            PlayerPrefs.Save();
        }

        public static int GetLocalValue(string key, int defaultValue)
        {
            var rv = defaultValue;
            if (ContainsLocalValue(key) == true)
            {
                rv = PlayerPrefs.GetInt(key, defaultValue);
            }
            else
            {
                SetLocalValue(key, defaultValue);
            }

            return rv;
        }

        public static void SetLocalValue(string key, float value)
        {
            PlayerPrefs.SetFloat(key, value);
            PlayerPrefs.Save();
        }

        public static float GetLocalValue(string key, float defaultValue)
        {
            var rv = defaultValue;
            if (ContainsLocalValue(key) == true)
            {
                rv = PlayerPrefs.GetFloat(key, defaultValue);
            }
            else
            {
                SetLocalValue(key, defaultValue);
            }

            return rv;
        }

        public static void SetLocalValue(string key, long value)
        {
            PlayerPrefs.SetString(key, value.ToString());
            PlayerPrefs.Save();
        }

        public static string GetLocalValue(string key)
        {
            return PlayerPrefs.GetString(key);
        }

        public static bool ContainsLocalValue(string key)
        {
            return PlayerPrefs.HasKey(key);
        }

        public static void DeleteLocalValue(string key)
        {
            PlayerPrefs.DeleteKey(key);
        }

        public static void DeleteAllLocalValues()
        {
            PlayerPrefs.DeleteAll();
        }

        public static void Sync(Action<bool> onComplete = null)
        {
            if (remoteValues == null)
            {
                remoteValues = new Dictionary<string, string>();
            }

            remoteValues.Clear();

            NetworkSystem.HTTPRequester.GetAllSettings(resp=>
            {
                if (resp.isSuccess == true)
                {
                    if (resp.keys != null)
                    {
                        for (int i = 0; i < resp.keys.Length; i++)
                        {
                            var key = resp.keys[i];
                            var val = resp.values[i];

                            remoteValues.Add(key, val);
                        }
                    }
                }

                if (onComplete != null)
                {
                    onComplete(resp.isSuccess);
                }
            });
        }

        public static void SetRemoteValue(string key, string value, bool allowEmptyValue = false)
        {
            if (remoteValues == null)
            {
                Debug.Log("Data not synchronized, call SyncRemoteValues() method first");
                return;
            }

            if (string.IsNullOrEmpty(key) == true 
                || (allowEmptyValue == false && string.IsNullOrEmpty(value) == true))
            {
                return;
            }

            if (ContainsRemoteValue(key) == true)
            {
                remoteValues[key] = value;
            }
            else
            {
                remoteValues.Add(key, value);
            }

            NetworkSystem.HTTPRequester.UserSet(key, value);
        }

        public static string GetRemoteValue(string key, string defaultValue)
        {
            if (remoteValues == null)
            {
                Debug.Log("Data not synchronized, call SyncRemoteValues() method first");
                return null;
            }

            if (ContainsRemoteValue(key) == true)
            {
                return remoteValues[key];
            }
            else if (string.IsNullOrEmpty(defaultValue) == false)
            {
                SetRemoteValue(key, defaultValue);
                return defaultValue;
            }
            else
            {
                return null;
            }
        }

        public static string GetRemoteValue(string key)
        {
            return ContainsRemoteValue(key) == true ? remoteValues[key] : null;
        }

        public static bool ContainsRemoteValue(string key)
        {
            return remoteValues.ContainsKey(key);
        } 
    }
}