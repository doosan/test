namespace Underc
{
    public static class TestConfig
    {
        public static int NowDayOffset;
        public static int NowMonthOffset;
    }
}