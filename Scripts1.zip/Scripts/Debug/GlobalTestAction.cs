#if GGDEV_TEST
using Gaga;
using System;
using System.Collections.Generic;
using System.Reflection;
using Underc.Net;
using Underc.Net.Client;
using Underc.Popup;
using Underc.User;
#endif

using UnityEngine;

namespace Underc
{
    public sealed class GlobalTestAction : MonoBehaviour
    {
        private static bool isInit;

#if GGDEV_TEST
        [SerializeField] private long xp;
        [SerializeField] private long nextXp;
        [SerializeField] private VipClassType vipClass;
        [SerializeField] private List<VipResetData> vipResetDatas;

        private void Awake()
        {
            if (isInit)
            {
                DestroyImmediate(gameObject);
                return;
            }

            isInit = true;
            DontDestroyOnLoad(gameObject);
        }

        public void ResetAppReview()
        {
            Popup.RateusPopup.Reset();
        }
        
        public void ResetNoticeSystem()
        {
            AdminNoticeSystem.Instance.SendMessage("DeleteToggleData", SendMessageOptions.DontRequireReceiver);
        }

        public void ShowVipResetNotice()
        {
            // 3초 후 vip_reset 의 Fake 응답을 받도록 설정
            MyInfo.VipClass.UpdateResetTimeStamp(GlobalTime.Instance.GetTimeStamp() + 3);
            VipResetNoticeSystem.Instance.RunAsFake = true;

            // VIP 리셋 팝업 열림 초기화
            VipResetNoticePopup.IsOpened = false;

            var vipData = new VipData();
            vipData.vip_class = (int)vipClass;
            vipData.xp = xp;
            vipData.next_xp = nextXp;

            var response = new VipResetResponse();
            response.vip = vipData;
            response.vip_reset = vipResetDatas.ToArray();
            FakeHttpRequester.Instance.LoadedVipReset = response;

            Gaga.DeveloperTools.DeveloperTools.Instance.IsOn = false;
        }

        public void ClearVipResetNotice()
        {
            VipResetNoticeSystem.Instance.RunAsFake = false;

            // VIP 리셋 팝업 열림 초기화
            VipResetNoticePopup.IsOpened = false;

            Gaga.DeveloperTools.DeveloperTools.Instance.IsOn = false;
        }

        public void ShowVipResetTime()
        {
            VipResetNoticePopup.IsOpened = false;
            
            VipResetNoticeSystem.Instance.ShowVipResetTime();
        }

        public void AddDayToNow(int value)
        {
            TestConfig.NowDayOffset += value;
        }

        public void AddMonthToNow(int value)
        {
             TestConfig.NowMonthOffset += value;
        }

        public void ClosePanel()
        {
            Gaga.DeveloperTools.DeveloperTools.Instance.IsOn = false;
        }

        public void SetRetryErrorInTest(string value)
        {
            Type requesterType = typeof(HTTPRequester);
            FieldInfo requesterFieldInfo = requesterType.GetField("client", BindingFlags.NonPublic | BindingFlags.Instance);
            if (requesterFieldInfo == null) return;

            RestClient restClient = requesterFieldInfo.GetValue(NetworkSystem.HTTPRequester) as RestClient;
            if (restClient == null) return;

            restClient.SetRetryErrorInTest(value);

            Gaga.DeveloperTools.DeveloperTools.Instance.IsOn = false;
        }

        public void PurchaseFail(int failStepValue)
        {
            PurchaseFailStep failStep = (PurchaseFailStep)failStepValue;
            PurchaseSystem.Instance.FailStep = failStep;

            Gaga.DeveloperTools.DeveloperTools.Instance.IsOn = false;
        }
#endif

    }
}