using UnityEngine;
using Gaga.System;
using System.Collections;
using System.Collections.Generic;
using PDollarGestureRecognizer;
using Gaga.DeveloperTools;

namespace Underc
{
    public sealed class DeveloperToolsGesture : GameObjectSingleton<DeveloperToolsGesture>
    {
        private readonly int MAX_POINTS_LENGTH       = 50;
        private readonly float THRESHOLD             = 5.0f;

        private List<Point> points = new List<Point>();
        private List<Gesture> trainingSet;
        private Vector3 startVirtualKeyPosition = Vector2.zero;
        private RuntimePlatform platform;
        private bool isTouch;
        private bool isEnable;

#if GGDEV
        public void Initialize()
        {
            TextAsset[] gesturesXml = Resources.LoadAll<TextAsset>("GestureSet/10-stylus-MEDIUM/");
            trainingSet = new List<Gesture>();

            foreach (TextAsset gestureXml in gesturesXml)
            {
                trainingSet.Add(GestureIO.ReadGestureFromXML(gestureXml.text));
            }

            platform = Application.platform;
            isTouch = false;
            points.Clear();
        }

        private void OnEnable()
        {
            StartCoroutine("UpdateGessture");
        }

        private IEnumerator UpdateGessture()
        {
            while (true)
            {
                Vector3 virtualKeyPosition = new Vector3(Input.mousePosition.x, Input.mousePosition.y);

                if (isTouch)
                {
                    if (Input.GetMouseButtonUp(0))
                    {
                        if (isEnable)
                        {
                            Gesture candidate = new Gesture(points.ToArray());
                            Result gestureResult = PointCloudRecognizer.Classify(candidate, trainingSet.ToArray());

                            // Debug.Log(gestureResult.GestureClass);
                            if (gestureResult.GestureClass == "O")
                            {
                                DeveloperTools.Instance.IsOn = !DeveloperTools.Instance.IsOn;
                            }
                        }
    
                        isEnable = false;
                        isTouch = false;

                        continue;
                    }

                    if (Vector2.Distance(startVirtualKeyPosition, virtualKeyPosition) >= THRESHOLD)
                    {
                        isEnable = true;
                    }
                    
                    points.Add(new Point(virtualKeyPosition.x, -virtualKeyPosition.y, 1));

                    if (points.Count > MAX_POINTS_LENGTH)
                    {
                        points.Clear();
                        isTouch = false;
                        isEnable = false;
                        continue;
                    }
                }
                else
                {
                    if (Input.GetMouseButtonDown(0))
                    {
                        isEnable = false;
                        startVirtualKeyPosition = virtualKeyPosition;
                        points.Clear();
                        isTouch = true;
                    }
                }
                
                yield return null;
            }
        }
#endif
    }
}