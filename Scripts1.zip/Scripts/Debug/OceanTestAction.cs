using System;
using System.Collections.Generic;
using Underc.Popup;
using Underc.User;
using Underc.Notification;
using UnityEngine;
using Underc.Ocean;
using Gaga.Sound;
using Gaga.Popup;

namespace Underc
{
    public class OceanTestAction : MonoBehaviour
    {
#if GGDEV_TEST
        private List<Camera> camerasInOff;
        private FlockRoot flockRoot;
        private bool isFlocksInOff;
        public void ToggleAllCamerasExceptOcean(bool andExceptDeveloperTools)
        {
            if (camerasInOff == null)
            {
                camerasInOff = new List<Camera>();
            }

            if (camerasInOff.Count == 0)
            {
                foreach (Camera camera in Camera.allCameras)
                {
                    if (camera.GetComponentInParent<OceanView>() != null
                        || (andExceptDeveloperTools == true && camera.name.Contains("DeveloperTools") == true))
                    {
                        continue;
                    }

                    camera.gameObject.SetActive(false);
                    camerasInOff.Add(camera);
                }
            }
            else if (camerasInOff.Count > 0)
            {
                foreach (Camera camera in camerasInOff)
                {
                    camera.gameObject.SetActive(true);
                }
                camerasInOff.Clear();
            }
        }

        public void ToggleAllFishes()
        {
            if (flockRoot == null)
            {
                flockRoot = GameObject.Find("FlockRoot")
                                      .GetComponent<FlockRoot>();
            }

            if (isFlocksInOff == false)
            {
                flockRoot.ClearFlocks();
                isFlocksInOff = true;
            }
            else
            {
                flockRoot.OnPresetUpdated();
                isFlocksInOff = false;
            }
        }

        public void ShowAdsLog()
        {
            AdsSystem.Instance.ShowLog();
        }

        public void ShowAds(string placement)
        {
            AdsPlacement adsPlacement = (AdsPlacement)Enum.Parse(typeof(AdsPlacement), placement);

            AdsSystem.Instance.Show(adsPlacement,
                                    (AdsPlacement _placement, AdsState _state) => { });
        }

        public void ShowAudioConfiguration()
        {
            AudioConfiguration config = AudioSettings.GetConfiguration();
            Debug.Log("==== ShowAudioConfiguration");
            Debug.Log($"speakerMode : {config.speakerMode}\n" +
                      $"dspBufferSize : {config.dspBufferSize}\n" +
                      $"sampleRate : {config.sampleRate}\n" +
                      $"numRealVoices : {config.numRealVoices}\n" +
                      $"numVirtualVoices : {config.numVirtualVoices}\n");
        }

        public void DebugSoundInfos()
        {
            SoundSystem.Instance.DebugAll();
        }

        public void SeaStoryCollection()
        {
            long point = 9999;

            List<MySeaStory.CollectionInfo.Item> items = new List<MySeaStory.CollectionInfo.Item>();

            MySeaStory.CollectionInfo.Item item1 = new MySeaStory.CollectionInfo.Item();
            item1.count = 3;
            item1.id = 1;
            item1.itemType = SeaItemType.f;
            items.Add(item1);

            MySeaStory.CollectionInfo.Item item2 = new MySeaStory.CollectionInfo.Item();
            item2.count = 2;
            item2.id = 120;
            item2.itemType = SeaItemType.f;
            items.Add(item2);

            MySeaStory.CollectionInfo.Item item3 = new MySeaStory.CollectionInfo.Item();
            item3.count = 1;
            item3.id = 134;
            item3.itemType = SeaItemType.f;
            items.Add(item3);

            for (int i = 1; i < 130; i++)
            {
                MySeaStory.CollectionInfo.Item item = new MySeaStory.CollectionInfo.Item();
                item.count = UnityEngine.Random.Range(1, 9999);
                item.id = i;
                item.itemType = SeaItemType.f;
                items.Add(item);
            }

            Popups.SeaStoryCollection(point, items, false, false, Vector2.zero);
        }

        public void SeaMissionClearPopup(int star)
        {
            star = Mathf.Clamp(star, 1, 3);
            Popups.SeaMissionClear(star).Async();
        }

        public void TestLocalPush(int testType)
        {
            UndercNotifications.SetTestPush(testType);
        }

        public void TestUndercLinkShop(int target2)
        {
            UndercLink.EstimateAction((int)TargetToMove.Shop, target2);
        }

        public void TestUndercLinkGrow(int target2)
        {
            UndercLink.EstimateAction((int)TargetToMove.Grow, target2);
        }

        public void TestUndercLinkOceanStory(int target2)
        {
            UndercLink.EstimateAction((int)TargetToMove.OceanStory, target2);
        }

        public void TestUndercLinkSlot(int target2)
        {
            UndercLink.EstimateAction((int)TargetToMove.Slot, target2);
        }

        public void TestUndercLinkInbox(int target2)
        {
            UndercLink.EstimateAction((int)TargetToMove.Inbox, target2);
        }

        public void TestUndercLinkUrl(string link)
        {
            UndercLink.EstimateAction((int)TargetToMove.Url, -1, link);
        }

        public void RunClamHarvest()
        {
            MyInfo.ClamHarvest.RunAsFake = true;

            Popups.MissionPass(MissionPassPopupTab.ClamHarvest);

            Gaga.DeveloperTools.DeveloperTools.Instance.IsOn = false;
        }

        public void OpenVipLevelUpPopup()
        {
            Popups.VipLevelUp(null, null)
                  .Async()
                  .Cache();
        }

        public void OpenProfilePopup()
        {
            PopupObject<GameProfilePopup> popupObject = null;
            popupObject = Popups.GameProfile(onOpen: () =>
                                             {
                                                 if (popupObject != null)
                                                 {
                                                     popupObject.GetPopup().RunAsFake = true;
                                                 }
                                             })
                                .Async()
                                .Cache();
        }

        public void SetVipLevel(string vipClassName)
        {
            VipClassType vipClass = VipClassType.none;
            if (Enum.TryParse(vipClassName, out vipClass))
            {
                MyInfo.VipClass.Update((int)vipClass);
            }
        }

        public void LoadIntro()
        {
            Scene.SceneSystem.LoadIntro();
        }
#endif
    }
}
