using UnityEngine;
using Gaga.Sound;
using System.Collections.Generic;
using Underc.User;
using Underc.Net;
using Underc.Popup;
using System;
using Gaga.System;
using Underc.Notification;
using Underc.Tutorial;
using Underc.LoadingScreen;

#if GGDEV
using Gaga.DeveloperTools;
using Gaga.Util;
#endif

#if UNITY_EDITOR
using UnityEditor;
#endif

namespace Underc.Scene
{
    public class BaseScene : MonoBehaviour, IBackable
    {
        public const int APPLICATION_RESTART_MIN = 60;
        public static List<object> parameters = new List<object>();

        private DateTime? pauseTime;
        public bool clearAllSoundsOnDestroy = true;
        
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        private static void OnRuntimeMethodLoad()
        {
            AppStartup.ProgramBegins();

#if UNITY_EDITOR
            var currentSceneName = UnityEngine.SceneManagement.SceneManager.GetActiveScene().name;

            if (currentSceneName != SceneSystem.SplashScene)
            {
                foreach(EditorBuildSettingsScene scene in EditorBuildSettings.scenes)
                {
                    if (scene.enabled == true)
                    {
                        string sceneName = scene.path.Substring(scene.path.LastIndexOf('/') + 1).Replace(".unity","");

                        if (currentSceneName == sceneName)
                        {
                            SceneSystem.LoadIntro();
                            return;
                        }
                    }
                }
            }
#endif

        }

        protected virtual void OnSceneEnter()
        {
#if GGDEV
            SetupDeveloperTools();
#endif
            BackButtonSystem.Instance.Add(this);
        }

        protected virtual void OnSceneExit()
        {
            BackButtonSystem.Instance.Remove(this);
        }

        protected virtual void OnDestroy()
        {
            try
            {
                if (clearAllSoundsOnDestroy)
                {
                    SoundSystem.Instance.StopAll();
                }
                
                DownloadSystem.Instance.AbortAll();
                if (Gaga.Util.NumberCounter.IsActive)
                {
                    Gaga.Util.NumberCounter.Instance.KillAll(true);
                }
            }
            catch (System.Exception){}
        }

        protected virtual void OnApplicationQuit()
        {
            MyInfo.SlotGame.SaveNewSlotInfoList();
        }

        protected virtual void OnApplicationPause(bool pauseStatus)
        {
            if (pauseStatus)
            {
                pauseTime = DateTime.Now;

                MyInfo.SlotGame.SaveNewSlotInfoList();
            }
            else
            {
                NotificationSystem.Instance.ClearAllDeliveredNotifications();

                if (string.IsNullOrEmpty(MyInfo.ID) == false)
                {
                    UndercNotifications.ReleaseNotificationLog();
                }

                if (pauseTime != null)
                {
                    var pauseEndTime = DateTime.Now;
                    int elapsedTime = (int)((TimeSpan)(pauseEndTime - pauseTime.Value)).TotalMinutes;

                    Debug.LogFormat("OnApplicationPause elapsedTime(Min) : "+elapsedTime);

                    if (elapsedTime >= APPLICATION_RESTART_MIN)
                    {
                        RestartApplicatoin();
                    }
                }
            }
        }

        protected virtual void OnApplicationFocus(bool isFocus)
        {
            UndercNotifications.SetNotifications(!isFocus);
            DeepLinkSystem.Instance.ApplicationFocus(isFocus);
        }

        public void RestartApplicatoin()
        {
            SceneSystem.LoadIntro();
        }

        public virtual bool CanBack()
        {
            return true;
        }

        public virtual void GoBack()
        {
            Debug.LogFormat("BaseScene ({0}) Back", name);
        }

#if GGDEV
        private void SetupDeveloperTools()
        {
            if (DeveloperTools.Instance.ContainsID("sepa_general") == true)
            {
                DeveloperTools.Instance.RemoveItem("sepa_general");
            }

            DeveloperTools.Instance.AddSeparator("sepa_general", 0);
      
            if (DeveloperTools.Instance.ContainsID("uid") == true)
            {
                DeveloperTools.Instance.RemoveItem("uid");
            }

            DeveloperTools.Instance.AddActionItem("uid", MyInfo.ID, () => MyInfo.ID.CopyToClipboard(), 0);

            if (DeveloperTools.Instance.ContainsID("serverName") == true)
            {
                DeveloperTools.Instance.RemoveItem("serverName");
            }

            DeveloperTools.Instance.AddActionItem("serverName"
                                                  ,Address.SERVER_NAME
                                                  ,()=>
                                                    {
#if DEV
                                                        DeveloperTools.Instance.IsOn = false;
                                                        Popups.ServerList();
#endif
                                                    }
                                                  ,0);
        }
#endif

        private void ExecuteBackButton()
        {
            //BackButtonSystem 은 Gaga 네임스페이스라 내부에서 언더씨의 TutorialSystem 을 사용할 수가 없다. 여기서 블럭해야한다
            if (TutorialSystem.Instance.IsInPlay == false &&
                LoadingScreenSystem.Instance.IsLoading == false )
            {
                BackButtonSystem.Instance.Back();
            }
        }

        private void Update()
        {
            #if GGDEV
            if (Input.GetKeyDown(KeyCode.D) == true && Input.GetKey(KeyCode.LeftShift))
            {
                Gaga.DeveloperTools.DeveloperTools.Instance.IsOn = !Gaga.DeveloperTools.DeveloperTools.Instance.IsOn;
            }
            #endif

            #if UNITY_EDITOR
            if (Input.GetKeyDown(KeyCode.LeftArrow) && Input.GetKey(KeyCode.LeftShift))
            {
                ExecuteBackButton();
            }
            #elif UNITY_ANDROID
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                ExecuteBackButton();
            }
            #endif
        }
    }
}