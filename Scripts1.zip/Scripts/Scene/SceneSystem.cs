using Gaga.Popup;
using Underc.Effect;
using Underc.LoadingScreen;
using System.Collections;
using Underc.Lobby;
using UnityEngine.SceneManagement;
using Underc.User;
using UnityEngine.Events;

namespace Underc.Scene
{
    public static class SceneSystem
    {
        public const string ENTER_SCENE_METHOD          = "OnSceneEnter";
        public const string EXIT_SCENE_METHOD           = "OnSceneExit";

        public const string SplashScene                 = "SplashScene";
        public const string IntroScene                  = "IntroScene";
        public const string LoadingScene                = "LoadingScene";
        public const string GameScene                   = "GameScene";
        public const string GameScenePortrait           = "GameScenePortrait";
        public const string LobbyScene                  = "LobbyScene";

        public const int LOBBY_STATE_INDEX_MAIN         = 0;
        public const int LOBBY_STATE_INDEX_GAME         = 1;

        private static bool broadcastSceneEnter;
        private static bool isInHold;

        public static string ActiveScene
        {
            get => SceneManager.GetActiveScene().name;
        }

        public static bool IsGameSceneInActive
        {
            get
            {
                string activeScene = ActiveScene;
                return activeScene == GameScene || activeScene == GameScenePortrait;
            }
        }

        public static UnityEvent onSceneLoaded = new UnityEvent();

        public static void Initialize()
        {
            SetupEvent();
        }

        private static void SetupEvent()
        {
            UnityEngine.SceneManagement.SceneManager.sceneLoaded += (UnityEngine.SceneManagement.Scene scene, UnityEngine.SceneManagement.LoadSceneMode mode)=>
            {
                onSceneLoaded.Invoke();
                if (broadcastSceneEnter == true)
                {
                    BoradcastSceneEnter(true);
                }
            };
        }

        private static IEnumerator BoradcastSceneEnterAfterFirstFrame(BaseScene currentScene)
        {
            yield return null;
            currentScene.BroadcastMessage(ENTER_SCENE_METHOD, UnityEngine.SendMessageOptions.DontRequireReceiver);
        }

        private static void BoradcastSceneEnter(bool skipFirstFrame = false)
        {
            var currentScene = UnityEngine.GameObject.FindObjectOfType<BaseScene>();
            if (currentScene != null)
            {
                if (skipFirstFrame == true)
                {
                    currentScene.StartCoroutine(BoradcastSceneEnterAfterFirstFrame(currentScene));
                }
                else
                {
                    currentScene.BroadcastMessage(ENTER_SCENE_METHOD, UnityEngine.SendMessageOptions.DontRequireReceiver);
                }

                broadcastSceneEnter = false;
            }
        }

        private static void BoradcastSceneExit()
        {
            var currentScene = UnityEngine.GameObject.FindObjectOfType<BaseScene>();
            if (currentScene != null)
            {
                currentScene.BroadcastMessage(EXIT_SCENE_METHOD, UnityEngine.SendMessageOptions.DontRequireReceiver);
            }
        }


        private static void ClearCurrentScene()
        {
            try
            {
                EffectSystem.Instance.Clear();
                PopupSystem.Instance.Clear();   
            }
            catch (System.Exception){}
        }

        public static void LoadGame(string slotID, SlotCardSkin poster)
        {
            ClearCurrentScene();

            bool isLandscape = MyInfo.SlotGame.SlotPresetList.IsLandscape(int.Parse(slotID));
            string sceneName = isLandscape ? GameScene : GameScenePortrait;

            LoadingScreenSystem.Instance.GameLoading(
                slotID,
                isLandscape,
                poster,
                OnLoadStartHandler,
                result =>
                {
                    if (result.isSuccess == true)
                    {
                        SetParameters(result.slotID, result.enterData, result.betData, result.userBet, result.slotMachinePrefab, result.autoSpinCount);
                        // GC.Collect();
                    }
                    else
                    {
                        LoadScene(IntroScene);
                    }
                }
                ,OnLoadEndHandler
                ,sceneName
            );
        }

        public static void LoadLobby(int startState = LOBBY_STATE_INDEX_GAME)
        {
            ClearCurrentScene();

            LoadingScreenSystem.Instance.LobbyLoading(
                OnLoadStartHandler,
                result =>
                {
                    if (result.isSuccess == true)
                    {
                        SetParameters(startState);
                        // GC.Collect();
                    }
                    else
                    {
                        LoadScene(IntroScene);
                    }
                }
                ,OnLoadEndHandler
                ,LobbyScene
            );
        }

        public static void LoadLobbyWithLogin()
        {
            ClearCurrentScene();

            LoadingScreenSystem.Instance.IntroLoading(
                OnLoadStartHandler,
                result =>
                {
                    if (result.isSuccess == true)
                    {
                        SetParameters(LOBBY_STATE_INDEX_GAME);
                        // GC.Collect();
                    }
                    else
                    {
                        LoadScene(IntroScene);
                    }
                }
                ,OnLoadEndHandler
                ,LobbyScene
            );
        }

        public static void Hold()
        {
            isInHold = true;
        }

        public static void Release()
        {
            if (isInHold == true)
            {
                isInHold = false;
                _LoadIntro();
            }
        }

        public static void LoadIntro()
        {
            if (isInHold == false)
            {
                _LoadIntro();
            }
        }

        public static void _LoadIntro()
        {
            ClearCurrentScene();
            OnLoadStartHandler();
            LoadScene(IntroScene);
        }

        public static void LoadSplash()
        {
            ClearCurrentScene();
            OnLoadStartHandler();
            LoadScene(SplashScene);
        }

        private static void OnLoadStartHandler()
        {
            broadcastSceneEnter = false;
            BaseScene.parameters.Clear();
            BoradcastSceneExit();
            LoadScene(LoadingScene);
        }

        private static void OnLoadEndHandler()
        {
            broadcastSceneEnter = true;
            BoradcastSceneEnter();
        }

        private static void SetParameters(params object[] parameters)
        {
            BaseScene.parameters.Clear();
            BaseScene.parameters.AddRange(parameters);
        }

        public static void LoadScene(string sceneName, params object[] parameters)
        {
            SetParameters(parameters);
            
            UnityEngine.SceneManagement.SceneManager.LoadScene(sceneName);
            // GC.Collect();
        }
    }
}