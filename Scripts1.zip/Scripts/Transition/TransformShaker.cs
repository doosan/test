using DG.Tweening;
using Gaga.Attribute;
using UnityEngine;

namespace Underc.Transition
{
    public class TransformShaker : MonoBehaviour
    {
        public enum ShakeType
        {
            Locked
        }

#pragma warning disable 0649
        [Separator("Lock")]
        [Header("Shake")]
        [SerializeField] private Transform shakeTarget = null;
        [SerializeField] private ShakeType shakeType = ShakeType.Locked;
        [SerializeField] private float shakeDuration = 0.1f;
        [SerializeField] private Vector3 shakeRotation = new Vector3(0f, 0f, 10f);
        [SerializeField] private Ease shakeEase1 = Ease.OutSine;
        [SerializeField] private Ease shakeEase2 = Ease.OutSine;

        [Header("Scale")]
        [SerializeField] private Transform scaleTarget = null;
        [SerializeField] private float scaleDuration = 0.1f;
        [SerializeField] private Vector3 scaleStartValue = new Vector3(1f, 1f, 1f);
        [SerializeField] private Vector3 scaleEndValue = new Vector3(1.5f, 1.5f, 1.5f);
        [SerializeField] private Ease scaleEase1 = Ease.OutSine;
        [SerializeField] private Ease scaleEase2 = Ease.OutSine;
#pragma warning restore 0649

        private Tween currentShakeTween;
        private Tween currentScaleTween;
        private Sequence rotateSequence;
        private Sequence scaleSequence;

        private void Awake()
        {
            if (shakeTarget == null)
            {
                shakeTarget = transform;
            }
        }

        private void OnDestroy()
        {
            if (rotateSequence != null)
            {
                rotateSequence.Kill();
                rotateSequence = null;
            }

            if (scaleSequence != null)
            {
                scaleSequence.Kill();
                scaleSequence = null;
            }
        }

        public void Do()
        {
            PlayShake();
            PlayScale();
        }

        private void PlayShake()
        {
            if (shakeTarget == null || shakeDuration == 0f)
            {
                return;
            }

            if (currentShakeTween != null && currentShakeTween.IsPlaying())
            {
                currentShakeTween.Pause();
            }

            switch (shakeType)
            {
                case ShakeType.Locked:
                    currentShakeTween = LockedShake();
                    break;
            }
        }

        private Tween LockedShake()
        {
            if (rotateSequence == null)
            {
                rotateSequence = DOTween.Sequence();
                rotateSequence.Append(shakeTarget.DORotate(shakeRotation, shakeDuration).SetEase(shakeEase1));
                rotateSequence.Append(shakeTarget.DORotate(shakeRotation * -0.7f, shakeDuration).SetEase(shakeEase2));
                rotateSequence.Append(shakeTarget.DORotate(shakeRotation * 0.6f, shakeDuration).SetEase(shakeEase1));
                rotateSequence.Append(shakeTarget.DORotate(Vector3.zero, shakeDuration).SetEase(shakeEase2));
                rotateSequence.SetAutoKill(false);
            }
            else
            {
                rotateSequence.Restart();
            }

            return rotateSequence;
        }

        private void PlayScale()
        {
            if (scaleTarget == null || scaleDuration == 0f)
            {
                return;
            }

            if (currentScaleTween != null && currentScaleTween.IsPlaying())
            {
                currentScaleTween.Pause();
            }

            currentScaleTween = PlayScaleSequence();
        }

        private Tween PlayScaleSequence()
        {
            if (scaleSequence == null)
            {
                scaleSequence = DOTween.Sequence();
                scaleSequence.Append(scaleTarget.DOScale(scaleEndValue, scaleDuration).SetEase(scaleEase1));
                scaleSequence.Append(scaleTarget.DOScale(scaleStartValue, scaleDuration).SetEase(scaleEase2));
                scaleSequence.SetAutoKill(false);
            }
            else
            {
                scaleSequence.Restart();
            }

            return scaleSequence;
        }
    }
}