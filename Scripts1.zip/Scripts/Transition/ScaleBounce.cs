using System.Collections;
using DG.Tweening;
using UnityEngine;

namespace Underc.Transition
{
    public class ScaleBounce : MonoBehaviour
    {
        #pragma warning disable 0649
        [SerializeField] private Transform targetTransform;
        
        [SerializeField] private Vector3 startValue = Vector3.one;
        [SerializeField] private Vector3 endValue = Vector3.one;

        [SerializeField] private float startDuration = .1f;
        [SerializeField] private float endDuration = .5f;

        [SerializeField] private Ease ease = Ease.OutBack;
        #pragma warning restore 0649

        private Sequence sequence;
        private void Start()
        {
            Init();
        }

        private void Init()
        {
            if (targetTransform == null)
            {
                targetTransform = transform;
            }

            if (sequence == null)
            {
                sequence = DOTween.Sequence();
                sequence.OnStart(() => targetTransform.localScale = Vector3.one);
                sequence.Append(targetTransform.DOScale(startValue, startDuration));
                sequence.Append(targetTransform.DOScale(endValue, endDuration).SetEase(ease));
                sequence.SetAutoKill(false);
                sequence.Pause();
            }
        }

        public void Do()
        {
            if (sequence.IsPlaying() == false)
            {
                sequence.Restart();
            }
        }
    }
}
