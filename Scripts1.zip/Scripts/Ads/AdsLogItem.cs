using UnityEngine;
using UnityEngine.UI;

namespace Underc
{
    public class AdsLogItem : MonoBehaviour
    {
        [SerializeField] private Text placementText;
        [SerializeField] private Text stateText;

        public void UpdateValue(string placement, string state)
        {
            placementText.text = placement;
            stateText.text = state;
        }
    }
}
