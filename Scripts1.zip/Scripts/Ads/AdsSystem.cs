using Gaga.Sound;
using Gaga.System;
using Gaga.Util;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Underc.User;
using UnityEngine;
using UnityEngine.Advertisements;

namespace Underc
{
    public enum AdsPlacement
    { 
        None,
        RewardKey,
    }

    public sealed class AdsSystem : CanvasSingleton<AdsSystem>, 
                                    IUnityAdsInitializationListener, 
                                    IUnityAdsLoadListener,
                                    IUnityAdsShowListener
    {
        private Regex grabDigitOfEnd;
        private Dictionary<AdsPlacement, AdsState> adsStates;
        private bool testMode = true;
        private AdsLog adsLog;

        private Action<AdsPlacement, AdsState> onAdsStateChanged;
        private ShowOptions showOptions;

        protected override void OnInitialize(string popupLayerName, 
                                             int resolutionWidth, 
                                             int resolutionHeight, 
                                             ScreenMatchMode match, 
                                             int pixelsPerUnit, 
                                             int depth)
        {
            base.OnInitialize(popupLayerName, resolutionWidth, resolutionHeight, match, pixelsPerUnit, depth);

            grabDigitOfEnd = new Regex(@"\d+$");
            adsStates = new Dictionary<AdsPlacement, AdsState>();

            string gameID = SDKConfig.GetCurrentSdkInfo().GetUnityProjectInfo().GetGameID();
            Advertisement.Initialize(gameID, testMode, this);
            Debug.Log("==== AdsSystem.OnInitialize : " + gameID + ", " + testMode);

            adsLog = Instantiate(Resources.Load("AdsLog") as GameObject).GetComponent<AdsLog>();
            adsLog.transform.SetParent(transform.Find("Root"), false);
            adsLog.Hide();
        }

        void IUnityAdsInitializationListener.OnInitializationComplete()
        {
            Debug.Log("==== AdsSystem.OnInitializationComplete");
            //Prepare();
        }

        public void Load()
        {
            if (Advertisement.isInitialized)
            {
                Load(AdsPlacement.RewardKey);
            }
        }

        void IUnityAdsInitializationListener.OnInitializationFailed(UnityAdsInitializationError error, string message)
        {
            Debug.Log($"==== AdsSystem.OnInitializationFailed: {error} - {message}");
        }

        void IUnityAdsLoadListener.OnUnityAdsAdLoaded(string placementId)
        {
            Debug.Log("==== AdsSystem.OnUnityAdsAdLoaded");
            SetState(AsAdsPlacement(placementId), AdsState.Loaded);
        }

        void IUnityAdsLoadListener.OnUnityAdsFailedToLoad(string placementId, UnityAdsLoadError error, string message)
        {
            Debug.Log($"==== AdsSystem.OnUnityAdsFailedToLoad: {placementId} - {error} - {message}");
            SetState(AsAdsPlacement(placementId), AdsState.FailedToLoad);
        }

        void IUnityAdsShowListener.OnUnityAdsShowFailure(string placementId, UnityAdsShowError error, string message)
        {
            Debug.Log($"==== AdsSystem.OnUnityAdsShowFailure: {placementId} - {error} - {message}");
            SetState(AsAdsPlacement(placementId), AdsState.FailedToShow);
        }

        void IUnityAdsShowListener.OnUnityAdsShowStart(string placementId)
        {
            Debug.Log($"==== AdsSystem.OnUnityAdsShowStart: {placementId}");
        }

        void IUnityAdsShowListener.OnUnityAdsShowClick(string placementId)
        {
            Debug.Log($"==== AdsSystem.OnUnityAdsShowClick: {placementId}");
        }

        void IUnityAdsShowListener.OnUnityAdsShowComplete(string placementId, UnityAdsShowCompletionState showCompletionState)
        {
            AdsState adsState = showCompletionState == UnityAdsShowCompletionState.COMPLETED ? AdsState.Completed :
                                showCompletionState == UnityAdsShowCompletionState.SKIPPED ? AdsState.Skipped :
                                AdsState.Unknown;

            Debug.Log($"==== AdsSystem.OnUnityAdsShowComplete: {placementId} - {showCompletionState}");
            SetState(AsAdsPlacement(placementId), adsState);
        }

        public void ShowLog()
        {
            adsLog.Show();
        }

        public bool IsLoaded(AdsPlacement adsPlacement)
        {
            AdsState adsState = AdsState.None;
            adsStates.TryGetValue(adsPlacement, out adsState);
            return adsState == AdsState.Loaded;
        }

        private void Load(AdsPlacement adsPlacement)
        {
            if (adsPlacement != AdsPlacement.None)
            {
                AdsState adsState = AdsState.None;
                adsStates.TryGetValue(adsPlacement, out adsState);

                if (adsState != AdsState.Load)
                {
                    SetState(adsPlacement, AdsState.Load);
                    Advertisement.Load(adsPlacement.ToString(), this);
                }
            }
        }

        public void Show(AdsPlacement adsPlacement, Action<AdsPlacement, AdsState> onAdsStateChanged)
        {
            if (showOptions == null)
            {
                showOptions = new ShowOptions();
            }

            showOptions.gamerSid = StringMaker.New()
                                              .Append(MyInfo.ID)
                                              .Append(",")
                                              .Append(grabDigitOfEnd.Replace(adsPlacement.ToString(), ""))
                                              .Build();
            Debug.Log($"==== AdsSystem.Show : {showOptions.gamerSid}");
            this.onAdsStateChanged = onAdsStateChanged;

            UndercGameLog.Singular.AdsStart();
            UndercGameLog.Firebase.AdsStart();

            SetState(adsPlacement, AdsState.Show);
            Advertisement.Show(adsPlacement.ToString(), showOptions, this);
        }

        private void SetState(AdsPlacement adsPlacement, AdsState adsState)
        {
            Debug.Log("==== AdsSystem.SetState : " + adsPlacement + ", " + adsState);
            if (adsPlacement != AdsPlacement.None)
            {
                adsStates[adsPlacement] = adsState;
                adsLog.UpdateValue(adsPlacement, adsState);

                switch (adsState)
                {
                    case AdsState.Show:
                        SoundSystem.Instance.PauseAll();
                        break;

                    case AdsState.Completed:
                        Load();
                        SoundSystem.Instance.ResumeAll();
                        break;

                    case AdsState.FailedToShow:
                    case AdsState.Skipped:
                    case AdsState.Unknown:
                        SoundSystem.Instance.ResumeAll();
                        break;
                }

                if (onAdsStateChanged != null)
                {
                    onAdsStateChanged.Invoke(adsPlacement, adsState);
                }
            }
        }

        private AdsPlacement AsAdsPlacement(string adsPlacementID)
        {
            AdsPlacement adsPlacement;
            if (Enum.TryParse(adsPlacementID, out adsPlacement) == false)
            {
                Debug.LogWarning("존재하지 않는 AdsPlacement 타입입니다 : " + adsPlacementID);
            }

            return adsPlacement;
        }
    }

    public enum AdsState
    {
        None,

        Load,
        FailedToLoad, 
        Loaded,

        Show,
        Completed,
        FailedToShow,
        Skipped,
        Unknown,
    }
}