using Gaga.System;
using System.Collections.Generic;
using UnityEngine;

namespace Underc
{
    public class AdsLog : MonoBehaviour
    {
        [SerializeField] private GameObject root;
        [SerializeField] private AdsLogItem adsLogItemRef;
        private GameObjectPool<AdsLogItem> adsLogItemPool;
        private Dictionary<AdsPlacement, AdsLogItem> adsLogItems;

        private void Initialize()
        {
            adsLogItems = new Dictionary<AdsPlacement, AdsLogItem>();

            adsLogItemRef.gameObject.SetActive(false);
            adsLogItemPool = new GameObjectPool<AdsLogItem>(root,
                                                            size: 5,
                                                            () => Instantiate(adsLogItemRef).GetComponent<AdsLogItem>());
        }

        public void UpdateValue(AdsPlacement placement, AdsState state)
        {
            if (adsLogItems == null)
            {
                Initialize();
            }

            if (adsLogItems.ContainsKey(placement) == false)
            {
                adsLogItems.Add(placement, adsLogItemPool.Get());
            }

            AdsLogItem adsLogItem = adsLogItems[placement];
            adsLogItem.gameObject.SetActive(true);
            adsLogItem.UpdateValue(placement.ToString(), state.ToString());
        }

        public void Hide()
        {
            gameObject.SetActive(false);
        }

        public void Show()
        {
            gameObject.SetActive(true);
        }
    }
}
