#if DEV && UNITY_EDITOR
// #define DUMMY_DEAL
// #define DUMMY_BENEFIT
// #define BLOCK_OFFER
#endif

using System;
using System.Collections;
using System.Collections.Generic;
using Gaga.Popup;
using Gaga.System;
using Gaga.Util;
using Underc.Net;
using Underc.Popup;
using Underc.User;
using UnityEngine;
using Underc.Tutorial;
using Underc.Net.Client;
using Underc.Scene;

namespace Underc
{
    public class OfferSystem : GameObjectSingleton<OfferSystem>
    {
        public class WaitForOffer : CustomYield.WaitForComplete
        {
            public bool Purchased { get; set; }
            public int OfferedCount { get; private set; }

            public override void Ready()
            {
                Purchased = false;
                base.Ready();
            }

            public void Done(int count)
            {
                OfferedCount = count;
                if (OfferedCount > 0)
                {
                    base.Done();
                }
                else
                {
                    Fail();
                }
            }
        }

        public static readonly string CATEGORY_ALLIN = "allin";
        public static readonly string CATEGORY_STARTER = "starter";
        public static readonly string CATEGORY_EVENT = "event";
        public static readonly string CATEGORY_BIGWIN = "bigwin";
        public static readonly string CATEGORY_OCEAN = "ocean";
        public static readonly string CATEGORY_SWIMMER = "swimmer";

        private readonly string TRIGGER_ALLIN = "allin";
        private readonly string TRIGGER_SLOT_LOBBY = "slot_lobby";
        private readonly string TRIGGER_SHOP = "leave_shop";
        private readonly string TRIGGER_BIGWIN = "bigwin";
        private readonly string TRIGGER_SWIMMER = "swimmer";
        private readonly string TRIGGER_OCEAN = "newocean";

        public bool RunAsFake
        {
            private get;
            set;
        }

        private Queue<OfferInfo> offerQueue;
        private WaitForOffer waitForComplete;
        public bool GameLobbyOpened { get; private set; }
        public bool Running { get; private set; }
        private float winMultiplier;

        private HashSet<int> openedDeals;
        private int dealID;

        public void Initialize()
        {
            waitForComplete = new WaitForOffer();
            offerQueue = new Queue<OfferInfo>();
            openedDeals = new HashSet<int>();

            PopupSystem.Instance.onSequeneceAllComplete += OnSequeneceComplete;
            SceneSystem.onSceneLoaded.AddListener(OnSceneLoaded);
        }

        private void OnDestroy()
        {
            PopupSystem.Instance.onSequeneceAllComplete -= OnSequeneceComplete;
            SceneSystem.onSceneLoaded.RemoveListener(OnSceneLoaded);
        }

        private void OnSequeneceComplete()
        {
            Running = false;
        }

        public bool IsReady
        {
            get
            {
                if (TutorialSystem.Instance.IsInPlay == true)
                {
                    return false;
                }

                return true;
            }
        }

        private void OnSceneLoaded()
        {
            if (SceneSystem.ActiveScene == SceneSystem.LobbyScene)
            {
                // 로비에 진입할 때 마다 데이터를 새로 로드하기 위함
                GameLobbyOpened = false;
            }
        }

        public WaitForOffer OpenUniqueSwimmer(Action onComplete = null)
        {
            waitForComplete.Ready();

            StartCoroutine(OfferCoroutine(TRIGGER_SWIMMER, onComplete));

            return waitForComplete;
        }

        public WaitForOffer OpenAllin(Action onComplete = null)
        {
            waitForComplete.Ready();

            StartCoroutine(OfferCoroutine(TRIGGER_ALLIN, onComplete));

            return waitForComplete;
        }

        public WaitForOffer OpenNewOcean(Action onComplete = null)
        {
            waitForComplete.Ready();

            StartCoroutine(OfferCoroutine(TRIGGER_OCEAN, onComplete));

            return waitForComplete;
        }

        public WaitForOffer OpenBigwin(long winMultiplier, Action onComplete = null)
        {
            waitForComplete.Ready();

            StartCoroutine(OfferCoroutine(TRIGGER_BIGWIN, winMultiplier, onComplete));

            return waitForComplete;
        }

        public WaitForOffer OpenShop(Action onComplete = null)
        {
            waitForComplete.Ready();

            StartCoroutine(OfferCoroutine(TRIGGER_SHOP, onComplete));

            return waitForComplete;
        }

        public WaitForOffer OpenGameLobby(Action onComplete = null)
        {
            GameLobbyOpened = true;

            waitForComplete.Ready();

            StartCoroutine(OfferCoroutine(TRIGGER_SLOT_LOBBY, onComplete));

            return waitForComplete;
        }

        private IEnumerator OfferCoroutine(string trigger, Action onComplete)
        {
            return OfferCoroutine(trigger, 0L, onComplete);
        }

        private IEnumerator OfferCoroutine(string trigger, long winMultiplier, Action onComplete)
        {
            waitForComplete.OnCompleteEvent += (w) =>
            {
                onComplete?.Invoke();
            };

#if BLOCK_OFFER
            waitForComplete.Fail("Blocked");
            yield break;
#endif

            if (IsReady == false)
            {
                waitForComplete.Fail("Not readied");
                yield break;
            }

            Popups.ShowLoading();
            IRequest<OfferResponse> offerReq;
            if (RunAsFake == false)
            {
                offerReq = NetworkSystem.HTTPRequester.Offer(trigger, winMultiplier);
            }
            else
            {
                offerReq = FakeHttpRequester.Instance.Offer();
            }
            yield return offerReq.WaitForResponse();
            Popups.HideLoading();

            if (offerReq.isSuccess == false)
            {
                var errorMessage = offerReq.data.error;
                OpenErrorPopup(errorMessage, () =>
                {
                    waitForComplete.Fail(errorMessage);
                });
                yield break;
            }

            OfferData[] offers = offerReq.data.offer;
            dealID = offerReq.data.deal.offer_id;

            int offerCount = offers == null ? 0 : offers.Length;
            if (offerCount > 0)
            {
                yield return OpenOffers(offers);
            }

            yield return null;

            //OpenOffers 도중 구매를 했다면 PurchaseSystem 에서 새로운 딜정보를 MyInfo 에 갱신하게 된다.
            if (waitForComplete.Purchased == false)
            {
                OfferData deal = offerReq.data.deal;
                MyInfo.Deal.Update(deal);
            }

            waitForComplete.Done(offerCount);
        }

        private IEnumerator OpenOffers(OfferData[] offers)
        {
            offerQueue.Clear();
            for (int i = 0; i < offers.Length; ++i)
            {
                OfferData data = offers[i];
#if DUMMY_BENEFIT
                data.benefits = CreateDummyBenefits();
#endif
                
                // 한 번 열었던 오퍼는 다시 열지 않도록
                int offerID = data.offer_id;
                if (openedDeals.Contains(offerID) == false)
                {
                    var info = new OfferInfo(data);
                    offerQueue.Enqueue(info);

                    if (data.offer_id == dealID)
                    {
                        openedDeals.Add(offerID);
                    }
                }
            }

            if (offerQueue.Count > 0)
            {
                Running = true;

                while (offerQueue.Count > 0)
                {
                    OfferInfo info = offerQueue.Dequeue();

                    Debug.LogFormat("offer open:{0}", info);

                    PopupObject<OfferPopup> popupObject = null;
                    popupObject = Popups.Offer(info, 
                                               onPurchase: () =>
                                               {
                                                   //오퍼 팝업에서 구매를 누른 경우 시퀀스를 중지한다.
                                                   waitForComplete.Purchased = true;
                                                   PopupSystem.Instance.ClearSequence();
                                                   Running = false;
                                               },
                                               onOpen: () =>
                                               {
                                                   if (popupObject != null)
                                                   {
                                                       popupObject.GetPopup().RunAsFake = RunAsFake;
                                                   }
                                               })
                                        .Async()
                                        .Sequence();
                }

                yield return new WaitWhile(() => Running);
                yield return null;
                yield return new WaitWhile(() => PopupSystem.Instance.Count > 0);
            }

            yield break;
        }

        private void OpenErrorPopup(string errorMessage, Action onPopupClose)
        {
            Debug.LogFormat("close by error: {0}", errorMessage);

            Popups.Warning(message: errorMessage,
                           actionType: WarningPopup.ActionType.None,
                           titleType: WarningPopup.TitleType.Network,
                           useCloseButton: false).OnClose(onPopupClose);
        }

    }

    public class OfferInfo
    {
        public int OfferID { get; private set; }
        public string OfferType { get; private set; }
        public string ImagePath { get; private set; }
        public string ProductID { get; private set; }
        public long VipPoint { get; private set; }
        public float WasPrice { get; private set; }
        public float Price { get; private set; }
        public long Coins { get; private set; }
        public string More { get; private set; }
        public long EndTs { get; private set; }
        public int BenefitCount { get { return benefits == null ? 0 : benefits.Length; } }

        private OfferBenefitData[] benefits;

        public OfferInfo(OfferData data)
        {
            OfferID = data.offer_id;
            OfferType = data.type;
            ImagePath = data.img_path;
            ProductID = data.item_id;
            VipPoint = data.vip_point;
            WasPrice = data.price_was;
            Price = data.price;
            Coins = data.coin;
            More = data.more;
            EndTs = data.end_ts;

            if (data.benefit != null && data.benefit.Length > 0)
            {
                benefits = new OfferBenefitData[data.benefit.Length];
                for (int i = 0; i < benefits.Length; ++i)
                {
                    benefits[i] = new OfferBenefitData()
                    {
                        rwd = data.benefit[i].rwd,
                        val = data.benefit[i].val
                    };
                }
            }
        }

        public OfferBenefitData GetBenefit(int index)
        {
            return benefits[index];
        }

        public override string ToString()
        {
            return string.Format(System.Globalization.CultureInfo.InvariantCulture, "id: {0} type: {1}", OfferID, OfferType);
        }
    }
}