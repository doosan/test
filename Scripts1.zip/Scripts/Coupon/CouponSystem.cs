using Gaga.System;
using Gaga.Util;
using System.Collections;
using System.Collections.Generic;
using Underc.Net;
using Underc.Net.Client;
using Underc.Popup;
using Underc.Scene;
using Underc.User;

namespace Underc
{
    public class CouponSystem : GameObjectSingleton<CouponSystem>
    {
        public bool HasData
        {
            get => infos.Count > 0;
        }

        public bool CheckOnce
        {
            get; private set;
        }

        public bool IsOpenedOnce
        {
            get; private set;
        }

        private const int TOTAL_PRESET_COUNT = 2;
        private List<CouponInfo> infos;

        public void Initialize()
        {
            infos = new List<CouponInfo>();

            SceneSystem.onSceneLoaded.AddListener(OnSceneLoaded);

            /// Dummy Begin
            //var info1 = new CouponInfo();
            //var itemInfos1 = new List<CouponItemInfo>();
            //itemInfos1.Add(new CouponItemInfo(1, 0, 100, "all", 48, 5));
            //itemInfos1.Add(new CouponItemInfo(1, 1, 30, "above20", 48, 5));
            //info1.id = 1;
            //info1.imgUrl = "https://abc.com/1";
            //info1.items = itemInfos1;

            //infos.Add(info1);

            //var info2 = new CouponInfo();
            //var itemInfos2 = new List<CouponItemInfo>();
            //itemInfos2.Add(new CouponItemInfo(2, 0, 100, "all", 24, 3));
            //info2.id = 2;
            //info2.imgUrl = "https://abc.com/2";
            //info2.items = itemInfos2;

            //infos.Add(info2);
            /// Dummy End
        }

        private void OnDestroy()
        {
            SceneSystem.onSceneLoaded.RemoveListener(OnSceneLoaded);
        }

        private void OnSceneLoaded()
        {
            if (SceneSystem.ActiveScene == SceneSystem.LobbyScene)
            {
                CheckOnce = false; 
            }
        }

        public void UpdateCoupon(CouponResponse response)
        {
            infos.Clear();
            foreach (CouponData data in response.data)
            {
                infos.Add(new CouponInfo(data));
            }
        }

        public IEnumerator OpenCouponPopup()
        {
            CheckOnce = true;
            IsOpenedOnce = false;

            foreach (CouponInfo info in infos)
            {
                if (MyInfo.Shop.CoinCoupon.CanMerge(info) == false)
                {
                    continue;
                }

                int itemCount = info.itemInfos.Count;
                if (itemCount == 1)
                {
                    yield return Popups.Coupon1(info).WaitForClose();
                    yield return ReloadShop();
                }
                else if (itemCount == 2)
                {
                    yield return Popups.Coupon2(info).WaitForClose();
                    yield return ReloadShop();
                }
            }

            yield break;
        }

        private IEnumerator ReloadShop()
        {
            IsOpenedOnce = true;

            Popups.ShowLoading();
            var shopReq = NetworkSystem.HTTPRequester.Shop();
            yield return shopReq.WaitForResponse();
            if (shopReq.isSuccess == true)
            {
                NetworkSystem.HTTPHandler.Do(shopReq.data);
            }
            Popups.HideLoading();
        }
    }

    public class CouponInfo
    {
        public int id;
        public string imgUrl;
        public List<CouponItemInfo> itemInfos;

        public CouponInfo()
        {

        }

        public CouponInfo(CouponData data)
        {
            id = data.coupon_id;
            imgUrl = data.img_url;
            itemInfos = new List<CouponItemInfo>();
            foreach (CouponItemData couponItem in data.coupon)
            {
                itemInfos.Add(new CouponItemInfo(id,
                                             0,
                                             couponItem.bonus_rate,
                                             couponItem.coupon_target,
                                             couponItem.expire_time,
                                             couponItem.cnt));
            }
        }
    }

    public class CouponMergeInfo
    {
        public int index;
        public int bonusRate;
        public string target;

        public CouponMergeInfo(CouponItemInfo couponItemInfo)
        {
            index = couponItemInfo.index;
            bonusRate = couponItemInfo.bonusRate;
            target = couponItemInfo.target;
        }
    }

    public class CouponItemInfo
    {
        public int id;
        public int index;
        public int bonusRate;
        public string target;
        public long expireTime;
        public int count;

        public float targetValue;
        public string targetValueCurrency;
        public long remainingSec;

        public CouponItemInfo(int id, int index, int bonusRate, string target, long expireTime, int count)
        {
            this.id = id;
            this.index = index;
            this.bonusRate = bonusRate;
            this.target = target;
            this.expireTime = expireTime;
            this.count = count;
    
            if (target.StartsWith("above") == true)
            {
                string targetValueStr = target.Substring(5);
                int targetValueOrigin;
                if (int.TryParse(targetValueStr, out targetValueOrigin))
                {
                    targetValue = targetValueOrigin - 0.01f;
                    targetValueCurrency = StringUtils.ToCurrency(targetValue);
                }
            }
        }
    }
}