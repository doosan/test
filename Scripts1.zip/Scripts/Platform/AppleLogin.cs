using AppleAuth;
using AppleAuth.Enums;
using AppleAuth.Extensions;
using AppleAuth.Interfaces;
using AppleAuth.Native;
using Gaga.System;
using System;
using System.Collections;
using System.Text;

namespace Underc.Platform
{
    public enum AppleLoginState
    {
        None,
        Reset,
        TryGetCredential,
        TryQuickLogin,
        TrySignInWithApple,
        Success,
        Fail
    }

    public enum AppleLoginError
    {
        Canceled
    }

    public sealed class AppleLogin : GameObjectSingleton<AppleLogin>, IPlatformLogin
    {
        public bool IsLoggedIn
        { 
            get
            {
                return string.IsNullOrEmpty(AppleUserId) == false;
            }
        }
        public string IdentityToken
        {
            get => UndercPrefs.GetLocalValue(APPLE_IDENTITY_TOKEN, "");
            set => UndercPrefs.SetLocalValue(APPLE_IDENTITY_TOKEN, value);
        }
        public string AuthorizationCode
        {
            get => UndercPrefs.GetLocalValue(APPLE_AUTHORIZATION_CODE, "");
            set => UndercPrefs.SetLocalValue(APPLE_AUTHORIZATION_CODE, value);
        }
        public string Error
        {
            get;
            private set;
        }
        private string failureReason;

        private const string APPLE_USER_ID = "AppleUserId";
        private const string APPLE_IDENTITY_TOKEN = "AppleIdentityToken";
        private const string APPLE_AUTHORIZATION_CODE = "AppleAuthorizationCode";
        private string AppleUserId
        { 
            get => UndercPrefs.GetLocalValue(APPLE_USER_ID, "");
            set => UndercPrefs.SetLocalValue(APPLE_USER_ID, value);
        }

        private bool initOnce;
        private IAppleAuthManager appleAuthManager;
        private StateQueue<AppleLoginState> stateQueue;

        private Action<PlatformLoginResult> onComplete;

        public void LogIn(Action<PlatformLoginResult> onComplete)
        {
            this.onComplete = onComplete;
            Debug.Log("Apple Login");

#if UNITY_EDITOR
            Debug.LogWarning("에디터에서는 애플 로그인을 사용하지 않습니다.");
            onComplete?.Invoke(PlatformLoginResult.Failed);
            return;
#endif
            Init();
            SetLoginState();
        }

        public void LogOut()
        {
            WriteAppleId(null);
        }

        private void SetLoginState()
        {
            if (stateQueue != null)
            {
                Reset();
                if (stateQueue != null)
                {
                    stateQueue.Set(AppleLoginState.TryGetCredential);
                }
                else
                {
                    stateQueue.Set(AppleLoginState.Fail);
                }
            }
            else
            {
                stateQueue.Set(AppleLoginState.Fail);
            }
        }

        private void Reset()
        {
            Error = "";
            failureReason = "";
        }

        private IEnumerator TryGetCredentialCoroutine()
        {
            // 1. 처음에는 보유중인 Apple ID의 상태를 조회
            string appleUserId = AppleUserId;
            if (string.IsNullOrEmpty(appleUserId) == false)
            {
                appleAuthManager.GetCredentialState(
                    userId: appleUserId,
                    successCallback: (CredentialState state) =>
                    {
                        switch (state)
                        {
                            case CredentialState.Authorized:
                                stateQueue.Set(AppleLoginState.Success);
                                break;

                            case CredentialState.Revoked:
                            case CredentialState.NotFound:
                                stateQueue.Set(AppleLoginState.TrySignInWithApple);
                                break;
                        }
                    },
                    errorCallback: (IAppleError error) =>
                    {
                        WriteAppleId(null);
                        WriteError(error);

                        if (IsCanceled())
                        {
                            stateQueue.Set(AppleLoginState.Fail);
                        }
                        else
                        {
                            stateQueue.Set(AppleLoginState.TrySignInWithApple);
                        }
                    }
                );
            }
            else
            {
                stateQueue.Set(AppleLoginState.TryQuickLogin);
            }
            yield break;
        }

        private IEnumerator TryQuickLoginCoroutine()
        {
            // 2. 다음에는 퀵 로그인 시도
            appleAuthManager.QuickLogin(
                quickLoginArgs: new AppleAuthQuickLoginArgs(),
                successCallback: (ICredential credential) =>
                {
                    // Previous Apple sign in credential
                    var appleIdCredential = credential as IAppleIDCredential;
                    WriteAppleId(appleIdCredential);

                    // Saved Keychain credential (read about Keychain Items)
                    var passwordCredential = credential as IPasswordCredential;

                    stateQueue.Set(AppleLoginState.Success);
                },
                errorCallback: (IAppleError error) =>
                {
                    WriteAppleId(null);
                    WriteError(error);

                    if (IsCanceled())
                    {
                        stateQueue.Set(AppleLoginState.Fail);
                    }
                    else
                    {
                        stateQueue.Set(AppleLoginState.TrySignInWithApple);
                    }
                }
            );
            yield break;
        }

        private IEnumerator TrySignInWithAppleCoroutine()
        {
            // 3. 다음에는 애플 로그인 시도
            appleAuthManager.LoginWithAppleId(
                new AppleAuthLoginArgs(LoginOptions.IncludeEmail | LoginOptions.IncludeFullName),
                (ICredential credential) =>
                {
                    WriteAppleId(credential as IAppleIDCredential);

                    stateQueue.Set(AppleLoginState.Success);
                },
                (IAppleError error) =>
                {
                    WriteAppleId(null);
                    WriteError(error);

                    stateQueue.Set(AppleLoginState.Fail);
                }
            );
            yield break;
        }

        private IEnumerator SuccessCoroutine()
        {
            onComplete?.Invoke(PlatformLoginResult.Success);
            yield break;
        }

        private IEnumerator FailCoroutine()
        {
            onComplete?.Invoke(PlatformLoginResult.Failed);
            yield break;
        }

        private bool IsCanceled()
        {
            return Error == AppleLoginError.Canceled.ToString()
                   && failureReason.StartsWith("No credentials") == false;
        }

        private void WriteError(IAppleError error)
        {
            Error = error.GetAuthorizationErrorCode().ToString();
            if (string.IsNullOrEmpty(error.LocalizedFailureReason) == false)
            {
                failureReason = error.LocalizedFailureReason;
            }
            
            string options = "";
            if (error.LocalizedRecoveryOptions != null)
            {
                foreach (string option in error.LocalizedRecoveryOptions)
                {
                    options += (option.ToString() + ", ");
                }
            }

            Debug.Log("==== WriteError : " + Error + "\n"
                      + "Code : " + error.Code + "\n"
                      + "Domain : " + error.Domain + "\n"
                      + "LocalizedDescription : " + error.LocalizedDescription + "\n"
                      + "options : " + options + "\n"
                      + "LocalizedRecoverySuggestion : " + error.LocalizedRecoverySuggestion + "\n"
                      + "LocalizedFailureReason : " + error.LocalizedFailureReason + "\n");
        }

        private void WriteAppleId(IAppleIDCredential appleIdCredential = null)
        {
            if (appleIdCredential == null)
            {
                AppleUserId = "";
                Debug.Log("==== WriteAppleId : null");
            }
            else
            {
                AppleUserId = appleIdCredential.User;

                IdentityToken = Encoding.UTF8.GetString(
                    appleIdCredential.IdentityToken,
                    0,
                    appleIdCredential.IdentityToken.Length
                );

                AuthorizationCode = Encoding.UTF8.GetString(
                    appleIdCredential.AuthorizationCode,
                    0,
                    appleIdCredential.AuthorizationCode.Length
                );

                //// Email (Received ONLY in the first login)
                //string email = appleIdCredential.Email;

                //// Full name (Received ONLY in the first login)
                //IPersonName fullName = appleIdCredential.FullName;
                Debug.Log($"==== WriteAppleId : {stateQueue.CurrentState}, {AppleUserId}, {IdentityToken}, {AuthorizationCode}");
            }
        }

        private void Init()
        {
            if (initOnce == false
                && AppleAuthManager.IsCurrentPlatformSupported == true)
            {
                initOnce = true;

                // Creates a default JSON deserializer, to transform JSON Native responses to C# instances
                var deserializer = new PayloadDeserializer();
                // Creates an Apple Authentication manager with the deserializer
                appleAuthManager = new AppleAuthManager(deserializer);
                stateQueue = new StateQueue<AppleLoginState>(host: this, keepLatestState: true);

                appleAuthManager.SetCredentialsRevokedCallback(result =>
                {
                    Debug.Log("==== Received revoked callback " + result);
                    LogOut();
                    Scene.SceneSystem.LoadIntro();
                });
            }
        }

        private void Update()
        {
            if (appleAuthManager != null)
            {
                appleAuthManager.Update();
            }
        }
    }
}