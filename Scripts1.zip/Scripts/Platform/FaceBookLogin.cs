using System;
using System.Collections.Generic;
using Facebook.Unity;
using UnityEngine;
using Gaga.System;

namespace Underc.Platform
{
    public enum PlatformLoginResult
    {
        Success,
        Failed,
        Canceled
    }
    
    [Flags]
    public enum PlatformLoginType
    {
        None = 0,
        Facebook = 1,
        Apple = 2
    }

    public interface IPlatformLogin
    {
        bool IsLoggedIn
        {
            get;
        }
        string IdentityToken
        {
            get;
        }
        string Error
        {
            get;
        }
        void LogIn(Action<PlatformLoginResult> onComplete);
        void LogOut();
    }

    public sealed class FacebookLogin : Singleton<FacebookLogin>, IPlatformLogin
    {
        public static readonly string REQUEST_DATA_INVITE = "invite";
        
        private readonly string LOGGEDIN_STATE_KEY               = "fbloggedinstate";
        private readonly string GRAPH_URL_PREFIX                 = "https://graph.facebook.com/";
        private readonly List<string> PERMISSIONS                = new List<string>() { "public_profile", "email"};

        private FBUser me;
        private List<FBFriend> friendsList;

        public string IdentityToken
        {
            get => AccessToken.TokenString;
        }

        public AccessToken AccessToken
        {
            get
            {
                return Facebook.Unity.AccessToken.CurrentAccessToken;
            }
        }

        public string Error
        {
            get
            {
                return "Facebook connection failed.";
            }
        }

        public bool IsLoggedIn
        {
            get
            {
#if UNITY_EDITOR
                return FB.IsLoggedIn ;
#else

                return FB.IsLoggedIn || UndercPrefs.GetLocalValue(LOGGEDIN_STATE_KEY, 0) == 1;
#endif
            }
            private set
            {
                UndercPrefs.SetLocalValue(LOGGEDIN_STATE_KEY, value ? 1 : 0);
            }
        }

        public void Initialize(Action<bool> onComplete)
        {
            Debug.Log("Facebook IsInitialized :" + FB.IsInitialized.ToString());

            if (FB.IsInitialized == false)
            {
                FB.Init(SDKConfig.GetCurrentSdkInfo().facebookAppID, null, true, true, true, false, true, null, "en_US", OnHideUnity, () =>
                {
                    if (FB.IsInitialized)
                    {
                        Debug.Log("Facebook Init success");
                        FB.ActivateApp();
                        onComplete?.Invoke(true);
                    }
                    else
                    {
                        Debug.Log("Facebook Init failed");
                        onComplete?.Invoke(false);
                    }
                });
            }
            else
            {
                Debug.Log("Facebook Init already success");
                FB.ActivateApp();
                onComplete.Invoke(true);
            }
        }

        public void LogIn(Action<PlatformLoginResult> onComplete)
        {
            Debug.Log("Facebook Login");

            Initialize(initSuccess =>
            {
                if (initSuccess)
                {
                    GUI.enabled = FB.IsInitialized;

                    Debug.Log("Facebook Login start : " + FB.IsLoggedIn.ToString());

                    if (FB.IsLoggedIn)
                    {
                        IsLoggedIn = true;

                        Debug.Log("Facebook token : " + AccessToken.TokenString);
                        Debug.Log("Facebook token ExpirationTime : " + AccessToken.ExpirationTime.ToString());

                        onComplete?.Invoke(PlatformLoginResult.Success);
                        return;
                    }
                    else
                    {
                        FB.LogInWithReadPermissions(PERMISSIONS, delegate (ILoginResult result)
                        {
                            Debug.Log("Facebook LogInWithReadPermissions done : " + result.RawResult);

                            if (FB.IsLoggedIn)
                            {
                                IsLoggedIn = true;
                                
                                Debug.Log("Facebook OnFBLogin - success");
                                Debug.Log("Facebook token : " + AccessToken.TokenString);
                                Debug.Log("Facebook token ExpirationTime : " + AccessToken.ExpirationTime.ToString());

                                onComplete?.Invoke(PlatformLoginResult.Success);
                            }
                            else
                            {
                                IsLoggedIn = false;

                                if (result.Cancelled)
                                {
                                    Debug.Log("Facebook OnFBLogin - canceled");
                                    onComplete?.Invoke(PlatformLoginResult.Canceled);
                                }
                                else
                                {
                                    Debug.Log("Facebook OnFBLogin - failed");
                                    onComplete?.Invoke(PlatformLoginResult.Failed);
                                }
                            }
                        });
                    }

                    Debug.Log("Facebook Login end : " + FB.IsLoggedIn.ToString());
                }
                else
                {
                    onComplete?.Invoke(PlatformLoginResult.Failed);
                }
            });
        }

        public void LogOut()
        {
            me = null;
            friendsList = null;

            try
            {
                FB.LogOut();
            }
            catch (System.Exception){}

            IsLoggedIn = false;
        }

        private void OnHideUnity(bool isGameShown)
        {
            Debug.Log("Facebook OnHideUnity: " + isGameShown.ToString());

            if (!isGameShown)
            {
                // pause the game - we will need to hide
                Time.timeScale = 0;
            }
            else
            {
                // start the game back up - we're getting focus again
                Time.timeScale = 1;
            }
        }

        public void GetMe(Action<FBUser> onComplete, bool useCachedData = true)
        {
            if (FB.IsLoggedIn == false)
            {
                onComplete?.Invoke(null);
                return;
            }

            if (me != null && useCachedData)
            {
                onComplete?.Invoke(me);
                return;
            }

            FB.API("/me?fields=id,name,first_name,last_name,picture.height(240),email,timezone,verified", HttpMethod.GET, delegate (IGraphResult result)
            {
                Debug.LogFormat("Facebook GetMe. {0}", result.RawResult);

                try
                {
                    IDictionary<string, object> resultData = result.ResultDictionary;

#if (UNITY_ANDROID || UNITY_IOS) && !UNITY_EDITOR
                    if (result.Error != null)
                    {
                        onComplete?.Invoke(null);
                        return;
                    }
#endif
                    me = new FBUser();
                    me.uid = resultData["id"] as string;
                    me.name = resultData["name"] as string;
                    me.first_name = resultData["first_name"] as string;
                    me.last_name = resultData["last_name"] as string;

                    if (result.ResultDictionary.ContainsKey("picture"))
                    {
                        IDictionary<string, object> pictureDict = resultData["picture"] as IDictionary<string, object>;
                        if (pictureDict.ContainsKey("data"))
                        {
                            IDictionary<string, object> pictureDataDict = pictureDict["data"] as IDictionary<string, object>;
                            if (pictureDataDict.ContainsKey("url"))
                            {
                                me.pic_url = pictureDataDict["url"] as string;
                                Debug.Log("picture url : " + me.pic_url);
                            }
                        }
                    }

                    object email;
                    if (resultData.TryGetValue("email", out email))
                    {
                        me.email = email.ToString();
                    }
                    else
                    {
                        me.email = "";
                    }

                    Debug.Log("Facebook email: " + email);

                    me.token = this.AccessToken.TokenString;

                    onComplete?.Invoke(me);
                }
                catch (Exception e)
                {
                    Debug.Log("Facebook FB.api(/me) failed: " + e.Message);
                    onComplete?.Invoke(null);
                }
            });
        }

        public void GetFriends(Action<FBFriend[]> onComplete, bool useCachedData = true)
        {
            if (FB.IsLoggedIn == false)
            {
                Debug.LogFormat("GetFriends fail. fb not login");
                friendsList = null;
                onComplete?.Invoke(null);
                return;
            }

            if (friendsList != null && useCachedData)
            {
                Debug.LogFormat("GetFriends use cachedData");
                onComplete?.Invoke(friendsList.ToArray());
                return;
            }

            friendsList = new List<FBFriend>();
            LoadFriends("/me/friends", friendsList, result =>
            {
                onComplete?.Invoke(friendsList.ToArray());
            });
        }

        private void LoadFriends(string url, List<FBFriend> data, Action<List<FBFriend>> onComplete, int maxCount = int.MaxValue)
        {
            try
            {
                FB.API(url, HttpMethod.GET, delegate (IGraphResult result)
                {
                    IDictionary<string, object> resultData = result.ResultDictionary;
#if GGDEV
                    Debug.Log("Get friend result: " + result.RawResult);
#endif

                    object dataList;
                    if (result.ResultDictionary.TryGetValue("data", out dataList))
                    {
                        var friendList = (List<object>)dataList;
                        foreach (var f in friendList)
                        {
                            FBFriend friend = new FBFriend();
                            var dic = (Dictionary<string, object>)f;

                            friend.uid = dic["id"] as string;
                            friend.name = dic["name"] as string;
                            friend.picUrl = string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0}{1}/picture", GRAPH_URL_PREFIX, friend.uid);

                            data.Add(friend);
                            if (data.Count >= maxCount)
                            {
                                break;
                            }
                        }
                    }

                    if (resultData.ContainsKey("paging") && data.Count < maxCount)
                    {
                        IDictionary<string, object> pageDic = resultData["paging"] as IDictionary<string, object>;
                        if (pageDic.ContainsKey("next"))
                        {
                            string nextURL = pageDic["next"] as string;
                            Debug.Log("next url: " + nextURL);

                            if (nextURL.Length > 0)
                            {
                                LoadFriends(nextURL, data, onComplete);
                            }
                            else
                            {
                                onComplete?.Invoke(data);
                            }
                        }
                        else
                        {
                            onComplete?.Invoke(data);
                        }
                    }
                    else
                    {
                        onComplete?.Invoke(data);
                    }
                });
            }
            catch (Exception e)
            {
                Debug.Log("Facebook FB.api(/me/friends) failed: " + e.Message);
                onComplete?.Invoke(null);
            }
        }

        public int GetFriendsCount()
        {
            return friendsList == null ? 0 : friendsList.Count;
        }

        public void SendAppInvite(string title, string message,
                                  IEnumerable<object> filters = null, string data = "",
                                  Action<IAppRequestResult> onComplete = null
        )
        {
            if (FB.IsInitialized == false)
            {
                onComplete?.Invoke(null);
                return;
            }

            FB.AppRequest(message, null, filters, null, null, data, title, (IAppRequestResult result) =>
            {
                onComplete?.Invoke(result);
            });
        }

        public void FeedShare(string link, string linkName = "", string linkCaption = "", string linkDescription = "", Action<IShareResult> onComplete = null)
        {
            if (FB.IsInitialized == false)
            {
                onComplete?.Invoke(null);
                return;
            }

            Uri linkUri = new Uri(link);
            FB.FeedShare(link: linkUri, linkName: linkName, linkCaption: linkCaption, linkDescription: linkDescription, callback: (IShareResult result) =>
            {
                onComplete?.Invoke(result);
            });
        }

        public void GetRequests(Action<List<FBRequest>> complete)
        {
            string query = "me/apprequests?limit=100&fields=from,data";
            FB.API(query, HttpMethod.GET, (IGraphResult result) =>
            {
                Debug.LogFormat("Facebook GetRequest complete. {0}", result.RawResult);
                if (result.Cancelled || string.IsNullOrEmpty(result.Error) == false)
                {
                    Debug.LogFormat("Facebook GetRequest Cancel or error");
                    complete?.Invoke(null);
                    return;
                }

                try
                {
                    foreach (var kv in result.ResultDictionary)
                    {
                        Debug.Log("key: " + kv.Key);
                    }

                    if (result.ResultDictionary.ContainsKey("data"))
                    {
                        List<FBRequest> requestList = new List<FBRequest>();
                        IList<object> requestDatas = result.ResultDictionary["data"] as IList<object>;
                        foreach (var data in requestDatas)
                        {
                            var dataDic = data as IDictionary<string, object>;
                            if (dataDic == null) continue;

                            var request = new FBRequest();
                            request.id = dataDic["id"] as string;
                            request.data = dataDic["data"] as string;

                            var fromDic = dataDic["from"] as IDictionary<string, object>;
                            if (fromDic != null)
                            {
                                request.from_id = fromDic["id"] as string;
                                request.from_name = fromDic["name"] as string;
                            }

                            requestList.Add(request);
                        }

                        Debug.LogFormat("Facebook GetRequest complete");
                        complete?.Invoke(requestList);
                    }
                    else
                    {
                        Debug.LogFormat("Facebook GetRequest fail. containsKey data false");
                        complete?.Invoke(null);
                    }
                }
                catch (System.Exception e)
                {
                    Debug.LogFormat("Facebook GetRequests fail {0} ", e.Message);
                    complete?.Invoke(null);
                }
            });
        }

        public void DeleteRequest(string requestId)
        {
            FB.API(requestId, HttpMethod.DELETE, (IGraphResult result) =>
            {
                Debug.LogFormat("Facebook DeleteRequest done. {0}", result.RawResult);
            });
        }

        public void GetAppLink(Action<string> complete)
        {
            FB.GetAppLink((IAppLinkResult result) =>
            {
                Debug.LogFormat("Facebook GetAppLink: {0}", result.RawResult);
                if (string.IsNullOrEmpty(result.Error) == false)
                {
                    return;
                }

                complete?.Invoke(result.Url ?? result.TargetUrl);
            });
        }

        public void GetDeferredAppLink(Action<string> complete)
        {
            if (Facebook.Unity.Constants.IsMobile)
            {
                FB.Mobile.FetchDeferredAppLinkData((IAppLinkResult result) =>
                {
                    Debug.LogFormat("Facebook FetchDeferredAppLinkData: {0}", result.RawResult);
                    if (string.IsNullOrEmpty(result.Error) == false)
                    {
                        return;
                    }

                    complete?.Invoke(result.Url ?? result.TargetUrl);
                });
            }
            else
            {
                complete?.Invoke(null);
            }
        }
    }

    public sealed class FBUser
    {
        public string uid;
        public string first_name;
        public string last_name;
        public string name;
        public string pic_url;
        public string email;
        public string token;
    }

    public sealed class FBFriend
    {
        public string uid;
        public string name;
        public string picUrl;
    }

    public sealed class FBRequest
    {
        public string id;
        public string data;
        public string from_id;
        public string from_name;
    }
}