using Gaga.System;
using System.Collections;
using Underc.Auth;
using Underc.Net;
using Underc.Net.Client;
using Underc.Popup;
using Underc.Scene;
using Underc.User;
using static Gaga.Util.CustomYield;

namespace Underc.Platform
{
    public enum PlatformLoginSystemState
    {
        TogglePlatformLogin,
        UpdateFacebook,
        SetFacebookProfile,
        SetCurrentProfile,
        SaveProfile,
        Done,
        ReleaseSceneLoading,
    }
    public struct TogglePlatformInfo
    {
        public PlatformLoginType type;
        public bool isOn;

        public TogglePlatformInfo(PlatformLoginType type, bool isOn)
        {
            this.type = type;
            this.isOn = isOn;
        }
    }

    public class PlatformLoginSystem : GameObjectSingleton<PlatformLoginSystem>
    {
        private StateQueue<PlatformLoginSystemState> stateQueue;
        private MyProfile myProfile;
        private FacebookStateInfo facebookStateInfo;

        public void Initialize()
        {
            stateQueue = new StateQueue<PlatformLoginSystemState>(this);

            myProfile = MyInfo.Profile;
            facebookStateInfo = myProfile.FacebookStateInfo;
        }

        public IEnumerator TogglePlatformLogin(TogglePlatformInfo info)
        {
            var waitForDone = new SimpleWaitForDone();

            if (AccountSystem.IsPlatformLoginConnected(info.type) != info.isOn)
            {
                if (info.isOn)
                {
                    AccountSystem.ConnectToPlatform(info.type, result =>
                    {
                        Debug.Log("==== ConnectToPlatform : " + info.type);

                        /// 1-1.
                        if (result == AccountSystem.PlatformConnectionResult.SuccessAndRestart)
                        {
                            SceneSystem.Hold();
                        }

                        if (info.type == PlatformLoginType.Facebook)
                        {
                            stateQueue.Add(PlatformLoginSystemState.UpdateFacebook);
                            stateQueue.Add(PlatformLoginSystemState.SetFacebookProfile);
                        }
                        stateQueue.Add(PlatformLoginSystemState.Done, waitForDone);

                        /// 1-2.
                        if (result == AccountSystem.PlatformConnectionResult.SuccessAndRestart)
                        {
                            stateQueue.Add(PlatformLoginSystemState.ReleaseSceneLoading, info);
                        }
                    });
                }
                else
                {
                    AccountSystem.DisconnectToPlatform(info.type, isSuccess =>
                    {
                        Debug.Log("==== DisconnectToPlatform : " + info.type);

                        if (info.type == PlatformLoginType.Facebook)
                        {
                            stateQueue.Add(PlatformLoginSystemState.UpdateFacebook);
                            stateQueue.Add(PlatformLoginSystemState.SetFacebookProfile);
                        }
                        stateQueue.Add(PlatformLoginSystemState.Done, waitForDone);
                    });
                }
            }
            else
            {
                waitForDone.Done();
            }

            yield return waitForDone;
        }

        public IEnumerator UpdateFacebook()
        {
            var waitForDone = new SimpleWaitForDone();

            stateQueue.Add(PlatformLoginSystemState.UpdateFacebook);
            stateQueue.Add(PlatformLoginSystemState.SetCurrentProfile);
            stateQueue.Add(PlatformLoginSystemState.Done, waitForDone);
            yield return waitForDone;
        }
        
        private IEnumerator UpdateFacebookCoroutine()
        {
            FacebookLogin faceBook = FacebookLogin.Instance;
            if (faceBook.IsLoggedIn)
            {
                Popups.ShowLoading();

                bool waitForDone = true;
                bool isSuccess = false;
                faceBook.GetMe(onComplete: (FBUser fbUser) =>
                {
                    waitForDone = false;

                    if (fbUser != null)
                    {
                        isSuccess = true;
                        facebookStateInfo.Update(faceBook.IsLoggedIn, fbUser);
                    }
                    else
                    {
                        isSuccess = false;
                        facebookStateInfo.Update(false, null);
                    }
                });

                while (waitForDone)
                {
                    yield return null;
                }

                if (isSuccess == false)
                {
                    waitForDone = true;
                    AccountSystem.DisconnectToFacebook(b =>
                    {
                        waitForDone = false;
                    });

                    while (waitForDone)
                    {
                        yield return null;
                    }
                }

                Popups.HideLoading();
            }
            else
            {
                facebookStateInfo.Update(isLoggedIn: false, fbUser: null);
            }
        }

        private IEnumerator SetCurrentProfileCoroutine()
        {
            yield return ProfileSet(new NewProfileInfo(myProfile.Nick, myProfile.PicNum, myProfile.PicUrl));
        }

        private IEnumerator SetFacebookProfileCoroutine()
        {
            //
            var newProfileInfo = new NewProfileInfo();
            if (facebookStateInfo.isLoggedIn)
            {
                newProfileInfo.picUrl = facebookStateInfo.fbUser.pic_url;
                newProfileInfo.nick = facebookStateInfo.fbUser.name;
            }
            else
            {
                newProfileInfo.picNum = myProfile.LoadPicNum();
                newProfileInfo.nick = myProfile.Nick;
            }

            //
            yield return ProfileSet(newProfileInfo);
        }

        private IEnumerator ProfileSet(NewProfileInfo newProfileInfo)
        {
            Popups.ShowLoading();
            IRequest<ClientResponse> req = NetworkSystem.HTTPRequester.ProfileSet(
                newProfileInfo.nick,
                newProfileInfo.picNum,
                newProfileInfo.picUrl,
                (ClientResponse response) =>
                {
                    if (response.isSuccess == true && response.ret == 0)
                    {
                        myProfile.Update(newProfileInfo.nick, newProfileInfo.picNum, newProfileInfo.picUrl);
                    }
                    else
                    {
                        Popups.Error(response.error)
                              .Async();
                    }
                }
            );

            yield return req.WaitForResponse();
            Popups.HideLoading();
        }

        private IEnumerator ReleaseSceneLoadingCoroutine(object param)
        {
            TogglePlatformInfo info = (TogglePlatformInfo)param;
            if (info.type == PlatformLoginType.Facebook)
            {
                myProfile.CacheFacebookProfileInfo(myProfile.FacebookStateInfo.fbUser);
            }

            SceneSystem.Release();
            yield break;
        }

        private IEnumerator DoneCoroutine(object param)
        {
            if (param != null)
            {
                var waitForDone = (SimpleWaitForDone)param;
                waitForDone.Done();
            }
            yield break;
        }
    }
}