using System;
using System.Collections;
using Underc.Popup;
using Underc.UI;
using Underc.User;
using UnityEngine;

namespace Underc.Tutorial
{
    public class MissionPassChapter : BaseTutorial
    {
        private readonly int STEP_INTRO         = 0;
        private readonly int STEP_LEVEL         = 1;
        private readonly int STEP_REWARDITEM    = 2;
        private readonly int STEP_OPEN_UNLOCK   = 3;

        [Space]
        [SerializeField] private GameObject skipPanel;
        [SerializeField] private float skipPanelDelay = 0.5f;

        [Space]
        [SerializeField] private HighlightPanel highlightPanel;
        [SerializeField] private int activeRewardItemIndex = 1;

        private MissionPassPanel missionPassPanel;
        private HighlightObjectInfo highlightObjectInfo;

        protected override void Awake()
        {
            base.Awake();

            HideSkipPanel();
        }

        private bool SetupMissionPassPanel()
        {
            missionPassPanel = GameObject.FindObjectOfType<MissionPassPanel>();

            if (missionPassPanel != null)
            {
                missionPassPanel.JumpToFirst();
            }

            return missionPassPanel != null;
        }

        protected override IEnumerator PlaySteps()
        {
            HideSkipPanel();

            if (SetupMissionPassPanel() == false)
            {
                yield break;
            }

            missionPassPanel.HoldBeforeClose = true;
            Action onPurchaseClose = () => missionPassPanel.HoldBeforeClose = false;

            yield return PlayStep(Intro(), null);
            yield return PlayStep(HighlightLevel(), null);
            yield return PlayStep(HighlightRewardItem(), null);
            yield return PlayStep(HighlightUnlock(), () => OpenUnlock(onPurchaseClose));
        }

        private IEnumerator Intro()
        {
            Show(STEP_INTRO);

            yield return ShowSkipPanelWithDelay();

            // Save Emma
            Transform stepTransform = GetStep(0).transform;
            Transform emmaTransform = stepTransform.Find("Emma");
            emmaTransform.SetParent(stepTransform.parent);
            emmaTransform.SetAsFirstSibling();
        }

        private IEnumerator HighlightLevel()
        {
            // Load Emma
            Transform stepTransform = GetStep(1).transform;
            Transform emmaTransform = stepTransform.parent.Find("Emma");
            emmaTransform.SetParent(stepTransform);
            emmaTransform.SetAsFirstSibling();

            HideSkipPanel();
            Show(STEP_LEVEL);

            highlightObjectInfo = new HighlightObjectInfo(missionPassPanel.GetLevelRoot(), HighlightVisibleType.Active, true);
            highlightPanel.Register(highlightObjectInfo);

            yield return ShowSkipPanelWithDelay();
        }

        private IEnumerator HighlightRewardItem()
        {
            HideSkipPanel();
            yield return HideHighlightObject();

            Show(STEP_REWARDITEM);

            RectTransform activeRewardItem = missionPassPanel.GetActiveRewardItem(activeRewardItemIndex);
            RectTransform bonusElement = activeRewardItem.GetComponentInChildren<MissionPassNormalItem>().BonusElement.CachedTransform;

            if (activeRewardItem == null)
            {
                NextStep();
                yield break;
            }

            highlightObjectInfo = new HighlightObjectInfo(bonusElement, HighlightVisibleType.Alpha, true);
            highlightPanel.Register(highlightObjectInfo);

            yield return ShowSkipPanelWithDelay();
        }

        private IEnumerator HideHighlightObject()
        {
            highlightObjectInfo.SetCloneActive(isOn: false, keepFade: true);
            yield return new WaitForSeconds(.3f);
            highlightPanel.Dispose();
        }

        private IEnumerator HighlightUnlock()
        {
            HideSkipPanel();
            yield return HideHighlightObject();

            if (MyInfo.MissionPass.EnabledBonus)
            {
                yield break;
            }

            Show(STEP_OPEN_UNLOCK);

            RectTransform buttonTransform = missionPassPanel.GetUnlockButtonRoot();
            Animator buttonAnimator = buttonTransform.GetComponentInChildren<Animator>();
            buttonAnimator.enabled = false;
            highlightObjectInfo = new HighlightObjectInfo(buttonTransform, HighlightVisibleType.Active, true);
            highlightPanel.Register(highlightObjectInfo);

            buttonAnimator.enabled = true;
        }

        private IEnumerator ShowSkipPanelWithDelay()
        {
            HideSkipPanel();

            yield return new WaitForSeconds(skipPanelDelay);

            ShowSkipPanel();
        }

        private void ShowSkipPanel()
        {
            skipPanel.SetActive(true);
        }

        private void HideSkipPanel()
        {
            skipPanel.SetActive(false);
        }

        private void OpenUnlock(Action onPurchaseClose)
        {
            if (MyInfo.MissionPass.EnabledBonus)
            {
                onPurchaseClose?.Invoke();
                return;
            }

            highlightPanel.Dispose();

            missionPassPanel.OpenPurchasePopup(onPurchaseClose);
        }

        public void OnNextStep()
        {
            NextStep();
        }
    }
}