using System.Collections;
using Underc.Lobby;
using Underc.Popup;
using Underc.User;
using UnityEngine;

namespace Underc.Tutorial
{
    public class BuyFishTutorial : BaseTutorial
    {
        private readonly int STEP_FISHSTIREMENU      = 0;
        private readonly int STEP_SELECTFISH    = 1;
        private readonly int STEP_DETAIL        = 2;
        private readonly int STEP_EXIT          = 3;

        [Header("Open Fish Store")]
        public float showGrowMenuDelay = 0.5f;
        public float growMenuStepDelay = 0.5f;

        [Header("Select Fish")]
        public float selectFishStepDelay = 0.3f;

        [Header("Open Detail")]
        public float firstDetailStepDelay = 0.3f;
        public float secondDetailStepDelay = 1.0f;

        [Header("Exit")]
        public float exitStepDelay = 1.0f;

        [Header("Result")]
        public float showMissionDelay = 0.6f;
        public float resultStepDelay = 0.5f;

        protected override IEnumerator PlaySteps()
        {
            yield return PlayStep(ShowGrowMenu(), OpenFishStoreMenu);
            yield return PlayStep(SelectFish(), OpenDetail);
            yield return PlayStep(Detail(firstDetailStepDelay), BuyFish);
            yield return PlayStep(Detail(secondDetailStepDelay), BuyFish);
            yield return PlayStep(Exit(), CloseFishStoreMenu);
            yield return Result();
        }

        private IEnumerator ShowGrowMenu()
        {
            var lobbyMainView = GameObject.FindObjectOfType<OceanLobby>();
            lobbyMainView.Hide(false);

            yield return new WaitForSeconds(showGrowMenuDelay);

            // lobbyMainView.ShowMenu(true, "Grow");

            yield return new WaitForSeconds(growMenuStepDelay);

            Show(STEP_FISHSTIREMENU);
        }

        private IEnumerator SelectFish()
        {
            while (GameObject.FindObjectOfType<FishStorePopup>() == false)
            {
                yield return null;
            }

            yield return new WaitForSeconds(selectFishStepDelay);

            Show(STEP_SELECTFISH);
        }

        private IEnumerator Detail(float delay)
        {
            yield return new WaitForSeconds(delay);

            Show(STEP_DETAIL);
        }

        private IEnumerator Exit()
        {
            yield return new WaitForSeconds(exitStepDelay);

            Show(STEP_EXIT);
        }

        private IEnumerator Result()
        {
            var lobbyMainView = GameObject.FindObjectOfType<OceanLobby>();
            yield return new WaitForSeconds(showMissionDelay);

            // lobbyMainView.ShowMenu(true, "Mission");

            yield return new WaitForSeconds(resultStepDelay);
        }

        private void BuyFish()
        {
            var fishStorePopup = GameObject.FindObjectOfType<FishStorePopup>();
            fishStorePopup.FishDetailPage.Buy();
        }

        private void OpenFishStoreMenu()
        {
            var lobbyMainView = GameObject.FindObjectOfType<OceanLobby>();
            lobbyMainView.OpenFishStoreInTutorial();
        }
        
        private void CloseFishStoreMenu()
        {
            var fishStorePopup = GameObject.FindObjectOfType<FishStorePopup>();
            fishStorePopup.CloseWithSync();
        }

        private void OpenDetail()
        {
            var fishStorePopup = GameObject.FindObjectOfType<FishStorePopup>();
            var bookDetail = MyInfo.Ocean.Book.GetBookInfoAtIndex(SeaItemType.f, 0);
            fishStorePopup.OpenItemDetail(bookDetail);
        }

        public void OnNextStep()
        {
            NextStep();
        }
    }
}