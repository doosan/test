using System.Collections;
using Gaga.Sound;
using Underc.Lobby;
using UnityEngine;

namespace Underc.Tutorial
{
    public class WelcomeIntro : BaseTutorial
    {
        private readonly int STEP_LETTER1 = 0;
        private readonly int STEP_LETTER2 = 1;

        [Space]
        public Animator commonAnim;
        public string closeTrigger = "Close";

        [Space]
        public GameObject intro;
        public float introDuration = 6.3f;
        public float introOceanPlayTime = 5.8f;

        protected override void Awake()
        {
            base.Awake();
            intro.SetActive(false);
        }

        protected override IEnumerator PlaySteps()
        {
            yield return null;

            SendTutorialStartGameLog();
            
            SendGameLogForStep(10);
            yield return PlayStep(ShowLetter1(), null, false);
            SendGameLogForStep(20);
            yield return PlayStep(ShowLetter2(), null, true);
            SendGameLogForStep(30);
            yield return CloseAnimation();
        }

        private IEnumerator ShowLetter1()
        {
            Show(STEP_LETTER1);

            LobbyManager lobbyView = null;

            while (true)
            {
                lobbyView = GameObject.FindObjectOfType<LobbyManager>();

                if (lobbyView != null)
                {
                    lobbyView.pauseStateTransition = true;
                    break;
                }

                yield return null;
            }
        }

        private IEnumerator ShowLetter2()
        {
            Show(STEP_LETTER2);

            yield return null;
        }

        private IEnumerator CloseAnimation()
        {
            intro.SetActive(true);
            SoundSystem.Instance.TurnDownWholeVolume(1, 0.25f, 0.3f);

            yield return null;

            commonAnim.SetTrigger(closeTrigger);

            yield return new WaitForSeconds(introOceanPlayTime);

            LobbyManager lobbyView = GameObject.FindObjectOfType<LobbyManager>();
            lobbyView.pauseStateTransition = false;

            if (introDuration > introOceanPlayTime)
            {
                yield return new WaitForSeconds(introDuration - introOceanPlayTime);
            }

            SoundSystem.Instance.RestoreWholeVolume(1, 0.0f, 0.3f);
        }

        public void OnButtonClicked()
        {
            NextStep();
        }

        private void SendTutorialStartGameLog()
        {
            UndercGameLog.Singular.TutorialStart();
            UndercGameLog.Firebase.TutorialStart();
        }
    }
}