using System.Collections;
using Underc.Net;
using Underc.Popup;
using UnityEngine;
using UnityEngine.UI;
using Gaga.UI;
using static Underc.Popup.ErrorPopup;
using System;
using Underc.Lobby;
using Underc.Effect;
using Underc.User;
using Gaga.Attribute;
using static Gaga.EasingFunction;
using Gaga.Sound;

namespace Underc.Tutorial
{
    public class WelcomeTutorial : BaseTutorial
    {
        private readonly int STEP_INTRO = 0;
        private readonly int STEP_CLAIM = 1;

        [Header("Intro")]
        public float introAutoSkipTime = 4.0f;

        [Header("Bonus")]
        public float bonusAutoSkipTime = 5.0f;
        public Animator bonusAnimator;
        public string bonusTrigger = "touch";
        [SerializeField] private Text bonusText;
        public bool autoStartBonus = true;
        [ConditionalShow("autoStartBonus")] public long startBonus = 0;
        public float bonusCountingTime = 2.0f;
        public Ease bonusCountingEase = Ease.Linear;
        public float bonusHideTime = 1.0f;
        public int bonusCoinEffectCount = 20;

        private Coroutine autoSkipCoroutine;
        private long bonusCoin;
        private bool collected;

        protected override IEnumerator PlaySteps()
        {
            SoundSystem.Instance.BgmVolume = LobbyManager.BGM_VOLUME_DOWN;

            SendHomeFirstGameLog();

            yield return PlayStep(Intro(), SkipIntro);
            SendGameLogForStep(40);
            yield return PlayStep(OpwnWelcomeBonus(), null);
            SendGameLogForStep(50);

            SoundSystem.Instance.BgmVolume = LobbyManager.BGM_VOLUME_NORMAL;
        }

        private IEnumerator Intro()
        {
            Show(STEP_INTRO);

            yield return null;
            StartAutoSkip(introAutoSkipTime, SkipIntro);
        }

        private IEnumerator OpwnWelcomeBonus()
        {
            Popups.ShowLoading(false);

            var reqStartTime = Time.time;
            var req = NetworkSystem.HTTPRequester.CollectStartBonus();
            yield return req.WaitForResponse();

            Popups.HideLoading();

            if(req.isSuccess == false )
            {
                Popups.NetworkError(ActionType.Exit);
                yield break;
            }

            Show(STEP_CLAIM);

            bonusCoin = req.data.data.coin;
            var startBonusCoin = autoStartBonus ? (long)((float)bonusCoin * 0.5f) : startBonus;
            bonusText.SetNumber(startBonusCoin, true);
            bonusText.SetNumber(bonusCoin, true, bonusCountingTime, bonusCountingEase);

            StartAutoSkip(bonusAutoSkipTime, Collect);
        }

        private IEnumerator OnCollect()
        {
            yield return new WaitForSeconds(bonusHideTime);
            NextStep();
        }

        public void SkipIntro()
        {
            StopAutoSkip();
            NextStep();
        }

        public void Collect()
        {
            if (bonusCoin == 0)
            {
                return;
            }

            if (collected)
            {
                return;
            }

            collected = true;

            var topUI = GameObject.FindObjectOfType<LobbyManager>().TopUI;

            var endPosition = topUI.GetCoinIconPosition();
            var startPosition = bonusText.transform.position;

            EffectSystem.Instance.Coin(count: bonusCoinEffectCount,
                                       startPosition: startPosition,
                                       endPosition: endPosition,
                                       scaleTarget: topUI.GetCoinIcon(),
                                       onFirstCoinArrived: ()=>
                                       {
                                           MyInfo.Coin += bonusCoin;
                                       },
                                       onCoinArrived: () =>
                                       {
                                           if (topUI != null)
                                           {
                                               topUI.CoinIconAnimation();
                                           }
                                       });

            StopAutoSkip();
            bonusAnimator.SetTrigger(bonusTrigger);
            StartCoroutine("OnCollect");
        }

        private void StartAutoSkip(float time, Action onComplete)
        {
            autoSkipCoroutine = StartCoroutine(AutoSkip(introAutoSkipTime, onComplete));
        }

        private void StopAutoSkip()
        {
            if (autoSkipCoroutine != null)
            {
                StopCoroutine(autoSkipCoroutine);
            }

            autoSkipCoroutine = null;
        }

        private IEnumerator AutoSkip(float time, Action onComplete)
        {
            float t = 0.0f;

            while (t < time)
            {
                yield return null;
                t += Time.deltaTime;
            }

            StopAutoSkip();

            onComplete?.Invoke();
        }

        private void SendHomeFirstGameLog()
        {
            UndercGameLog.Singular.HomeFirst();
            UndercGameLog.Firebase.HomeFirst();
        }
    }
}