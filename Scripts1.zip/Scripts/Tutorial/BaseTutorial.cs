using System;
using System.Collections;
using DG.Tweening;
using UnityEngine;

namespace Underc.Tutorial
{
    public abstract class BaseTutorial : MonoBehaviour
    {
        #pragma warning disable 0649
        [SerializeField] GameObject[] stepList;
        #pragma warning restore 0649
        
        protected Action onComplete;
        private CanvasGroup[] stepCanvasGroupList;
        private GameObject background;

        public float hideDuration = 0.2f;

        private bool nextStep;

        protected virtual void Awake()
        {
            SetupCanvasGroups(); 
            HideAll();
        }

        public void Init(GameObject background)
        {
            this.background = background;
        }

        private void SetupCanvasGroups()
        {
            stepCanvasGroupList = new CanvasGroup[stepList.Length];
            for (int i = 0; i < stepList.Length; i++)
            {
                var step = stepList[i];
                var cv = step.GetComponent<CanvasGroup>();
                if (cv == null)
                {
                    cv = step.AddComponent<CanvasGroup>();
                }

                stepCanvasGroupList[i] = cv;
            }
        }

        public void Play(Action onComplete)
        {
            this.onComplete = onComplete;

            StartCoroutine("PlayCoroutine");
        }

        private IEnumerator PlayCoroutine()
        {
            yield return PlaySteps();
            onComplete();
        }

        protected abstract IEnumerator PlaySteps();

        protected IEnumerator PlayStep(IEnumerator step, Action execute)
        {
            yield return step;

            nextStep = false;
            while (nextStep == false)
            {
                yield return null;
            }

            HideAll(hideDuration);
            yield return new WaitForSeconds(hideDuration);

            if (execute != null)
            {
                execute();
            }
        }

        protected IEnumerator PlayStep(IEnumerator step, Action execute, bool hideChapter = true) 
        {
            yield return step;

            nextStep = false;
            while (nextStep == false)
            {
                yield return null;
            }

            if (hideChapter == true)
            {
                HideAll(hideDuration);
                yield return new WaitForSeconds(hideDuration);
            }

            if (execute != null)
            {
                execute();
            }
        }

        protected void NextStep()
        {
            nextStep = true;
        }

        protected void HideAll()
        {
            HideAll(0.0f);
        }

        protected void HideAll(float duration)
        {
            for (int i = 0; i < stepCanvasGroupList.Length; i++)
            {
                var step = stepCanvasGroupList[i];

                if (step.gameObject.activeInHierarchy == true)
                {
                    step.DOKill(false);

                    if (duration > 0.0f)
                    {
                        step.DOFade(0.0f, duration).OnComplete(()=>{step.gameObject.SetActive(false);});
                    }
                    else
                    {
                        step.gameObject.SetActive(false);
                    }

                    SetInteractable(step, true);
                }
            }
        }

        protected bool Show(int index)
        {
            HideAll();

            if (index >= stepCanvasGroupList.Length)
            {
                return false;
            }

            var step = stepCanvasGroupList[index];
            step.gameObject.SetActive(true);
            step.alpha = 1.0f;
            
            return true;
        }

        protected GameObject GetStep(int index)
        {
            if (index >= stepList.Length)
            {
                return null;
            }

            var step = stepList[index];
            return step;
        }

        protected void SetInteractable(int index, bool value)
        {
            if (index >= stepCanvasGroupList.Length)
            {
                return;
            }

            var step = stepCanvasGroupList[index];
            SetInteractable(step, value);
        }

        protected void SetInteractableAll(bool value)
        {
            for (int i = 0; i < stepCanvasGroupList.Length; i++)
            {
                SetInteractable(stepCanvasGroupList[i], value);
            }
        }

        private void SetInteractable(CanvasGroup cg, bool value)
        {
            cg.interactable = value;
            cg.blocksRaycasts = value;
        }

        public void SetActiveBackground(bool isOn)
        {
            background.SetActive(isOn);
        }

        public void SendGameLogForStep(int stepID)
        {
            UndercGameLog.Fobis.TutorialStep(stepID);
        }

        public void SendGameLogForSeaStep(int stepID)
        {
            UndercGameLog.Fobis.TutorialSeaStep(stepID);
        }
    }
}