using System.Collections;
using Gaga.Popup;
using TMPro;
using Underc.Lobby;
using Underc.Ocean;
using Underc.Popup;
using Underc.User;
using UnityEngine;

namespace Underc.Tutorial
{
    public class UnlockSeaTutorial : BaseTutorial
    {
        private readonly int STEP_GROWMENU      = 0;
        private readonly int STEP_SELECTFISH    = 1;
        private readonly int STEP_DETAIL        = 2;
        private readonly int STEP_EXIT          = 3;
        private readonly int STEP_BACK_TO_SLOT  = 4;

        [Header("Prologue")]
        public string prologueTrigger = "Prologue";
        public float prologueAnimationTime = 2.5f;
        [SerializeField] private GameObject prologueObject;
        public float prologueAfterDelay = 1.2f;
        public float prologueTextSkipTime = 7.5f;

        [Header("Intro")]
        [SerializeField] private GameObject introObject;
        [SerializeField] private TextMeshProUGUI introText;
        public float introAfterDelay = 1.2f;
        public float introTextSkipTime = 7.5f;
        public float oceanEnterDuration = 3f;

        [Header("Open Grow")]
        public float growMenuStepDelay = 0.5f;
        public float growMoveListDelay = 0.3f;
        public float growMoveListDuration = 0.5f;
        [SerializeField] private RectTransform growFishArrow;
        [SerializeField] private RectTransform growFishButton;

        [Header("Select Fish")]
        public float selectFishStepDelay = 0.3f;

        [Header("Open Detail")]
        public float detailStepDelay = 0.3f;

        [Header("Exit Grow")]
        public float exitStepDelay = 1.0f;

        private BaseBookInfo freeFishBook;

        protected override void Awake()
        {
            base.Awake();

            prologueObject.SetActive(false);
            introObject.SetActive(false);
        }

        protected override IEnumerator PlaySteps()
        {
            yield return ShowPrologue();
            yield return ShowIntro();

            freeFishBook = MyInfo.Ocean.Book.GetFreeBookInfo(SeaItemType.f);

            if (freeFishBook != null)
            {
                SendGameLogForSeaStep(30);
           
                yield return PlayStep(ShowGrowMenu(), OpenGrowMenu);
                yield return PlayStep(SelectFish(), OpenDetail);

                yield return PlayStep(Detail(detailStepDelay), BuyFish);
                yield return PlayStep(Exit(), CloseGrowMenu);
                
                yield return SeaStoryCollection();
            }
            else
            {
                var lobbyManager = GameObject.FindObjectOfType<LobbyManager>();
                lobbyManager.OceanLobby.Show(true);
                lobbyManager.TopUI.OceanLobbyStyle();
                lobbyManager.TopUI.Show(true);
            }

            var savedSlotPlayInfo = MyInfo.SlotGame.GetSlotPlayInfo();
            bool isBackToSlot = savedSlotPlayInfo.IsValid;
            
            if (isBackToSlot)
            {
                yield return PlayStep(WaitForSeaStoryCollect(), BackToSlot);
            }
            else
            {
                yield return PlayStep(WaitForSeaStoryCollect(), GoToGameLobby);
            }

            freeFishBook = null;
        }

        private IEnumerator ShowPrologue()
        {
            var lobbyManager = GameObject.FindObjectOfType<LobbyManager>();
            lobbyManager.OceanView.ZoomDefault(oceanEnterDuration);

            var anim = lobbyManager.OceanView.Sea.GetComponentInChildren<Animator>();
            anim.SetTrigger(prologueTrigger);

            yield return new WaitForSeconds(prologueAnimationTime);

            prologueObject.SetActive(true);
            yield return new WaitForSeconds(prologueTextSkipTime);
            prologueObject.SetActive(false);

            yield return new WaitForSeconds(prologueAfterDelay);
        }

        private IEnumerator ShowIntro()
        {
            var lobbyManager = GameObject.FindObjectOfType<LobbyManager>();

            ///
            Sea2D sea2d = lobbyManager.OceanView.Sea;
            yield return sea2d.ShowIntroCoroutine();
            
            introText.text = sea2d.IntroMessage;

            ///
            introObject.SetActive(true);
            yield return new WaitForSeconds(introTextSkipTime);
            introObject.SetActive(false);

            yield return new WaitForSeconds(introAfterDelay);
        }

        private IEnumerator ShowGrowMenu()
        {
            var lobbyManager = GameObject.FindObjectOfType<LobbyManager>();
            lobbyManager.OceanLobby.Show(true);
            lobbyManager.TopUI.OceanLobbyStyle();
            lobbyManager.TopUI.Show(true);

            yield return new WaitForSeconds(growMenuStepDelay);
            SendGameLogForSeaStep(40);
            Show(STEP_GROWMENU);
        }

        private IEnumerator SelectFish()
        {
            while (GameObject.FindObjectOfType<FishStorePopup>() == false)
            {
                yield return null;
            }

            yield return null;

            var growPopup = GameObject.FindObjectOfType<FishStorePopup>();

            while (growPopup.SelectedInventory == null)
            {
                yield return null;
            }

            yield return new WaitForSeconds(growMoveListDelay);
            growPopup.SelectedInventory.GoTo(freeFishBook.ID, growMoveListDuration);

            yield return new WaitForSeconds(growMoveListDuration);
            yield return new WaitForSeconds(selectFishStepDelay);

            var growInventoryItems = growPopup.GetComponentsInChildren<FishStoreInventoryItem>();
            Vector3 targetPos = Vector3.zero;

            foreach (var item in growInventoryItems)
            {
                if (item.BookInfo.ID == freeFishBook.ID)
                {
                    targetPos = item.transform.position;
                    break;
                }
            }

            Show(STEP_SELECTFISH);
            growFishArrow.position = targetPos;
            growFishButton.position = targetPos;
        }

        private IEnumerator Detail(float delay)
        {
            yield return new WaitForSeconds(delay);

            Show(STEP_DETAIL);
        }

        private IEnumerator Exit()
        {
            yield return new WaitForSeconds(exitStepDelay);

            Show(STEP_EXIT);
        }

        private IEnumerator SeaStoryCollection()
        {
            var lobbyManager = GameObject.FindObjectOfType<LobbyManager>();

            while (PopupSystem.Instance.Count > 0)
            {
                yield return null;
            }

            yield return null;
            TutorialSystem.Instance.Interactable = false;
            yield return lobbyManager.SeaStoryReward();
            TutorialSystem.Instance.Interactable = true;
        }

        private IEnumerator WaitForSeaStoryCollect()
        {
            var lobbyManager =  GameObject.FindObjectOfType<LobbyManager>();
            yield return new WaitForSeconds(0.2f);

            while (lobbyManager.IsSeaStoryRewardRunning)
            {
                yield return null;
            }

            SendGameLogForSeaStep(90);
            SendGameLogForSeaStep(100);

            Show(STEP_BACK_TO_SLOT);
        }

        private void BuyFish()
        {
            SendGameLogForSeaStep(70);

            var growPopup = GameObject.FindObjectOfType<FishStorePopup>();
            growPopup.FishDetailPage.Buy();
        }

        private void OpenGrowMenu()
        {
            SendGameLogForSeaStep(50);

            var lobbyMainView = GameObject.FindObjectOfType<OceanLobby>();
            lobbyMainView.OpenFishStoreInTutorial(FishStorePopupTabIndex.Fish);
        }
        
        private void CloseGrowMenu()
        {
            SendGameLogForSeaStep(80);

            var growPopup = GameObject.FindObjectOfType<FishStorePopup>();
            growPopup.CloseWithSync();
        }

        private void OpenDetail()
        {
            SendGameLogForSeaStep(60);
            var growPopup = GameObject.FindObjectOfType<FishStorePopup>();
            var bookDetail = MyInfo.Ocean.Book.GetBookInfo(SeaItemType.f, freeFishBook.ID);
            growPopup.OpenItemDetail(bookDetail);
        }

        private void BackToSlot()
        {
            SendGameLogForSeaStep(110);
            
            var backToSlotButton = GameObject.FindObjectOfType<BackToSlotButton>();
            backToSlotButton.Play();

            var lobbyManager = GameObject.FindObjectOfType<LobbyManager>();
            lobbyManager.StopAllCoroutines();
        }

        private void GoToGameLobby()
        {
            SendGameLogForSeaStep(110);

            var lobbyManager = GameObject.FindObjectOfType<LobbyManager>();
            lobbyManager.SetState(LobbyManager.State.ExitOcean);
        }

        public void OnNextStep()
        {
            NextStep();
        }
    }
}