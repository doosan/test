namespace Underc.Tutorial
{
    // 인덱스값을 서버에 저장하므로 인덱스 숫자를 바꿔서는 안됨.

    public enum TutorialChapter
    {
        Welcome          = 1,
        // 2 - 제거된 값
        PlaySlot         = 3,
        // 4 - 제거된 값
        // UniqueSwimmer    = 5,
        UnlockSea        = 6,

        NewSea           = 100,
        FirstVisitToSea  = 101,

        MissionPass      = 200
    }
}