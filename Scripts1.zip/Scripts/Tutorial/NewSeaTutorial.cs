using System.Collections;
using Underc.Popup;
using UnityEngine;

namespace Underc.Tutorial
{
    public class NewSeaTutorial : BaseTutorial
    {
        private readonly int STEP_SELECTSEA      = 0;

        [Header("Select Sea")]
        public float selectSeaStepDelay = 0.3f;
        [SerializeField] private Transform selectPointRoot;
        [SerializeField] private Transform selectPoint;
        [SerializeField] private Vector2 selectPointOffset;

        protected override IEnumerator PlaySteps()
        {
            yield return PlayStep(SelectSea(), EnterSea);
        }

        private IEnumerator SelectSea()
        {
            while (GameObject.FindObjectOfType<StoryMapPopup>() == false)
            {
                yield return null;
            }

            yield return new WaitForSeconds(selectSeaStepDelay);

            Show(STEP_SELECTSEA);

            var oceanStoryPopup = GameObject.FindObjectOfType<StoryMapPopup>();
            var seaPos = oceanStoryPopup.GetLatestedUnlockedSeaPosition();

            selectPointRoot.transform.position = new Vector3(seaPos.x, seaPos.y, selectPointRoot.transform.position.z);
            selectPoint.transform.localPosition = selectPointOffset;
        }

        private void EnterSea()
        {
            var storyMapPopup = GameObject.FindObjectOfType<StoryMapPopup>();
            storyMapPopup.ChangeMySea(storyMapPopup.CurrentUnlockedSeaID, isSuccess =>
            {
                if (isSuccess)
                {
                    storyMapPopup.Close();
                }
            });
        }

        public void OnSelectSea()
        {
            NextStep();
        }
    }
}