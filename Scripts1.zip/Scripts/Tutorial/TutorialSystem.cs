using Gaga.AssetBundle;
using Gaga.System;
using Gaga.UI;
using System;
using System.Collections;
using System.Collections.Generic;
using Underc.Net;
using Underc.Util;
using UnityEngine;

namespace Underc.Tutorial
{
    public class TutorialSystem : CanvasSingleton<TutorialSystem>
    {
        public bool IsInPlay
        {
            get => playCoroutine != null;
        }

        private readonly string INFO_NAME           = "TutorialInfo";

        private class PlayInfo
        {
            public TutorialChapter chapter;
            public Action onComplete;
        }

        public delegate void TutorialDelegate(TutorialChapter chapter);
        public event TutorialDelegate onStart;
        public event TutorialDelegate onComplete;

        private TutorialInfo tutorialInfo;
        private Gaga.AssetBundle.AssetBundle assetBundle;
        private Queue<PlayInfo> playQueue;
        private Coroutine playCoroutine;
        private GameObject background;

        protected override void OnInitialize(string popupLayerName, int resolutionWidth, int resolutionHeight, ScreenMatchMode match, int pixelsPerUnit, int depth)
        {
            base.OnInitialize(popupLayerName, resolutionWidth, resolutionHeight, match, pixelsPerUnit, depth);

            playQueue = new Queue<PlayInfo>();
            SetupBackground();
        }

        private void SetupBackground()
        {
            background = new GameObject("Background");
            background.transform.SetParent(root, false);
            background.transform.SetAsFirstSibling();

            var tr = background.AddComponent<RectTransform>();
            tr.anchorMin = new Vector2(0,0);
            tr.anchorMax = new Vector2(1,1);
            tr.anchoredPosition = Vector2.zero;
            tr.sizeDelta = Vector2.zero;

            background.AddComponent<EmptyGraphic>();
            background.SetActive(false);
        }

        public void LoadAssets(Action<bool> onLoadComplete = null)
        {
            if (assetBundle != null)
            {
                if (onLoadComplete != null)
                {
                    onLoadComplete(true);
                }
                return;
            }

            AssetBundleSystem.Instance.Load(AssetBundleLoadType.Load
                                            ,Address.CDN_ASSETBUNDLES
                                            ,AssetBundleName.TUTORIAL
                                            ,(success, ab)=>
                                            {
                                                if (success == true && ab != null)
                                                {
                                                    assetBundle = ab;
                                                    tutorialInfo = assetBundle.GetAsset<TutorialInfo>(INFO_NAME);
                                                }

                                                if (onLoadComplete != null)
                                                {
                                                    onLoadComplete(success);
                                                }
                                            });
        }

        public void Play(TutorialChapter chapter, Action onComplete = null)
        {
            PlayInfo playInfo = new PlayInfo();
            playInfo.chapter = chapter;
            playInfo.onComplete = onComplete;

            playQueue.Enqueue(playInfo);

            if (playCoroutine == null)
            {
                playCoroutine = StartCoroutine("PlayCoroutine");
            }
        }

        private IEnumerator PlayCoroutine()
        {
            background.SetActive(true);

            while (playQueue.Count > 0)
            {
                var playInfo = playQueue.Dequeue();
                yield return Tutorial(playInfo.chapter);

                if (playInfo.onComplete != null)
                {
                    playInfo.onComplete();
                }
            }

            playCoroutine = null;
            background.SetActive(false);
        }

        private IEnumerator Tutorial(TutorialChapter chapter)
        {
            if (assetBundle == null)
            {
                bool abLoadSuccess = false;
                LoadAssets(success=>
                {
                    abLoadSuccess = success;
                });

                if (abLoadSuccess == false)
                {
                    yield break;
                }
            }

            Debug.Log("TUTORIAL START :: "+chapter.ToString());

            if (onStart != null)
            {
                onStart(chapter);
            }

            var tutorialItem = tutorialInfo.Get(chapter);

            if (tutorialItem == null)
            {
                yield break;
            }

            bool isComplete = false;

            var tutorialInstance = Instantiate(tutorialItem.tutorial.gameObject, Vector3.zero, Quaternion.identity, root).GetComponent<BaseTutorial>();
            tutorialInstance.transform.SetAsLastSibling();

            tutorialInstance.Init(background);
            tutorialInstance.Play(()=>
            {
                isComplete = true;
            });

            while (isComplete == false)
            {
                yield return null;
            }

            Destroy(tutorialInstance.gameObject);

            if (onComplete != null)
            {
                onComplete(chapter);
            }

            Debug.Log("TUTORIAL END :: "+chapter.ToString());
        }
    }
}