using System.Collections;
using Gaga.Popup;
using Underc.Lobby;
using Underc.Popup;
using Underc.User;
using UnityEngine;

namespace Underc.Tutorial
{
    public class UniqueSwimmerTutorial : BaseTutorial
    {
        private readonly int STEP_GROWMENU      = 0;
        private readonly int STEP_SELECTFISH    = 1;
        private readonly int STEP_DETAIL        = 2;
        private readonly int STEP_EXIT          = 3;
        private readonly int STEP_BACK_TO_SLOT  = 4;

        [Header("Open Grow")]
        public float growMenuStepDelay = 0.5f;

        [Header("Select Fish")]
        public float selectFishStepDelay = 0.3f;

        [Header("Open Detail")]
        public float detailStepDelay = 0.3f;

        [Header("Exit Grow")]
        public float exitStepDelay = 1.0f;
        
        protected override IEnumerator PlaySteps()
        {
            if (MyInfo.Ocean.GetCurrentSea().SwimmerItemCount + MyInfo.Ocean.Inventory.SwimmerItemCount > 0)
            {
                yield break;
            }

            SendGameLogForSeaStep(30);

           
            yield return PlayStep(ShowGrowMenu(), OpenGrowMenu);
            yield return PlayStep(SelectFish(), OpenDetail);

            yield return PlayStep(Detail(detailStepDelay), BuyFish);
            yield return PlayStep(Exit(), CloseGrowMenu);
            
            yield return SeaStoryCollection();

            var savedSlotPlayInfo = MyInfo.SlotGame.GetSlotPlayInfo();
            bool isBackToSlot = savedSlotPlayInfo.IsValid;
            
            if (isBackToSlot)
            {
                yield return PlayStep(WaitForSeaStoryCollect(), BackToSlot);
            }
            else
            {
                yield return PlayStep(WaitForSeaStoryCollect(), GoToGameLobby);
            }
        }

        private IEnumerator ShowGrowMenu()
        {
            yield return new WaitForSeconds(growMenuStepDelay);
            SendGameLogForSeaStep(40);
            Show(STEP_GROWMENU);
        }

        private IEnumerator SelectFish()
        {
            while (GameObject.FindObjectOfType<FishStorePopup>() == false)
            {
                yield return null;
            }

            yield return new WaitForSeconds(selectFishStepDelay);

            Show(STEP_SELECTFISH);
        }

        private IEnumerator Detail(float delay)
        {
            yield return new WaitForSeconds(delay);

            Show(STEP_DETAIL);
        }

        private IEnumerator Exit()
        {
            yield return new WaitForSeconds(exitStepDelay);

            Show(STEP_EXIT);
        }

        private IEnumerator SeaStoryCollection()
        {
            var lobbyManager = GameObject.FindObjectOfType<LobbyManager>();

            while (PopupSystem.Instance.Count > 0)
            {
                yield return null;
            }

            yield return null;
            TutorialSystem.Instance.Interactable = false;
            yield return lobbyManager.SeaStoryReward();
            TutorialSystem.Instance.Interactable = true;
        }

        private IEnumerator WaitForSeaStoryCollect()
        {
            var lobbyManager =  GameObject.FindObjectOfType<LobbyManager>();
            yield return new WaitForSeconds(0.2f);

            while (lobbyManager.IsSeaStoryRewardRunning)
            {
                yield return null;
            }

            SendGameLogForSeaStep(90);
            SendGameLogForSeaStep(100);

            Show(STEP_BACK_TO_SLOT);
        }

        private void BuyFish()
        {
            SendGameLogForSeaStep(70);

            var growPopup = GameObject.FindObjectOfType<FishStorePopup>();
            growPopup.FishDetailPage.Buy();
        }

        private void OpenGrowMenu()
        {
            SendGameLogForSeaStep(50);

            var lobbyMainView = GameObject.FindObjectOfType<OceanLobby>();
            lobbyMainView.OpenFishStoreInTutorial(FishStorePopupTabIndex.UniqueSwimmer);
        }
        
        private void CloseGrowMenu()
        {
            SendGameLogForSeaStep(80);

            var growPopup = GameObject.FindObjectOfType<FishStorePopup>();
            growPopup.CloseWithSync();
        }

        private void OpenDetail()
        {
            SendGameLogForSeaStep(60);
            var growPopup = GameObject.FindObjectOfType<FishStorePopup>();
            var bookDetail = MyInfo.Ocean.Book.GetBookInfoAtIndex(SeaItemType.s, 0);
            growPopup.OpenItemDetail(bookDetail);
        }

        private void BackToSlot()
        {
            SendGameLogForSeaStep(110);
            
            var backToSlotButton = GameObject.FindObjectOfType<BackToSlotButton>();
            backToSlotButton.Play();

            var lobbyManager = GameObject.FindObjectOfType<LobbyManager>();
            lobbyManager.StopAllCoroutines();

        }

        private void GoToGameLobby()
        {
            SendGameLogForSeaStep(110);

            var oceanLobby = GameObject.FindObjectOfType<OceanLobby>();
            oceanLobby.OpenGame();
        }

        public void OnNextStep()
        {
            NextStep();
        }
    }
}