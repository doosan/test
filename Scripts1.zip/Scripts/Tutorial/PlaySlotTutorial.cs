using System.Collections;
using SlotGame.Machine;
using SlotGame.UI;
using Underc.Lobby;
using Underc.Scene;
using UnityEngine;
using Gaga.Popup;
using Gaga.UI;
using Underc.User;

namespace Underc.Tutorial
{
    public class PlaySlotTutorial : BaseTutorial
    {
        public static int VALID_SPINS           = 1;

        private readonly int STEP_SELECTSLOT    = 0;
        private readonly int STEP_PLAYSLOT_1    = 1;
        private readonly int STEP_PLAYSLOT_2    = 2;

        [Header("Select Slot")]
        public float selectSlotStepDelay = 2.0f;
        public float moveSlotDuration = 1.0f;

        [Header("Result")]
        public float resultStepDelay = 1.0f;

        private long currentSpins;

        protected override IEnumerator PlaySteps()
        {
            SendLobbyFirstGameLog();
            SendGameLogForStep(110);
            yield return PlayStep(ShowSlotList(), SelectSlot);
            SendGameLogForStep(120);

            long spins = MyInfo.spins;

            if (spins == 0)
            {
                SendSlotFirstGameLog();
                yield return PlayStep(ReadySpin(STEP_PLAYSLOT_1), PlaySlot);
                SendGameFirstGameLog();
                SendGameLogForStep(130);
                spins++;
            }

            if (spins == 1)
            {
                yield return PlayStep(ReadySpin(STEP_PLAYSLOT_2), PlaySlot);
                SendGameLogForStep(140);
            }

            SendTutorialCompleteGameLog();

            yield return Result();
        }

        private IEnumerator ShowSlotList()
        {
            var slotListView = GameObject.FindObjectOfType<SlotListView>();

            while (slotListView.IsShow() == false)
            {
                yield return null;
            }

            yield return new WaitForSeconds(selectSlotStepDelay);

            slotListView.GoTo(MyInfo.Tutorial.tutorialSlotID, moveSlotDuration);

            yield return new WaitForSeconds(moveSlotDuration);

            Show(STEP_SELECTSLOT);
        }

        private IEnumerator ReadySpin(int showStepIndex)
        {
            while (UnityEngine.SceneManagement.SceneManager.GetActiveScene().name != SceneSystem.GameScene 
                   && UnityEngine.SceneManagement.SceneManager.GetActiveScene().name != SceneSystem.GameScenePortrait)
            {
                yield return null;
            }

            SlotMachine slotMachine = null;
            while (slotMachine == null)
            {
                slotMachine = GameObject.FindObjectOfType<SlotMachine>();
                yield return null;
            } 

            yield return WaitForBigwinOrJackpot(slotMachine);

            Show(showStepIndex);
        }

        private IEnumerator Result()
        {
            SlotMachine slotMachine = GameObject.FindObjectOfType<SlotMachine>();

            yield return WaitForBigwinOrJackpot(slotMachine);
            yield return new WaitForSeconds(resultStepDelay);
        }

        private IEnumerator WaitForBigwinOrJackpot(SlotMachine slotMachine)
        {
            while (true)
            {
                if (slotMachine.CurrentState == SlotMachineState.IDLE)
                {
                    break;
                }
                else if (slotMachine.CurrentState == SlotMachineState.HIT_BIGWIN || slotMachine.CurrentState == SlotMachineState.HIT_JACKPOT)
                {
                    while (PopupSystem.Instance.Count == 0 && slotMachine.CurrentState != SlotMachineState.IDLE)
                    {
                        yield return null;
                    }

                    SetActiveBackground(false);

                    while (PopupSystem.Instance.Count > 0 && slotMachine.CurrentState != SlotMachineState.IDLE)
                    {
                        yield return null;
                    }
                    
                    SetActiveBackground(true);
                }

                yield return null;
            }
        }

        private void SelectSlot()
        {
            var slotListView = GameObject.FindObjectOfType<SlotListView>();
            var slotCard = slotListView.GetSlotCard(MyInfo.Tutorial.tutorialSlotID);
            slotListView.OnSlotCardClickHandler(MyInfo.Tutorial.tutorialSlotID, slotCard.CurrentSkin);
        }

        private void PlaySlot()
        {
            var slotButtomUI = GameObject.FindObjectOfType<BottomUI>();

            ButtonSelector btSelector = slotButtomUI.GetSpinButton().GetComponent<ButtonSelector>();
            if (btSelector == null)
            {
                btSelector = slotButtomUI.GetSpinButton().gameObject.AddComponent<ButtonSelector>();
            }
            
            btSelector.Select();
            slotButtomUI.OnSpinButtonClick();
        }

        public void OnNextStep()
        {
            NextStep();
        }

        private void SendLobbyFirstGameLog()
        {
            UndercGameLog.Singular.LobbyFirst();
            UndercGameLog.Firebase.LobbyFirst();
        }

        private void SendSlotFirstGameLog()
        {
            UndercGameLog.Singular.SlotFirst();
            UndercGameLog.Firebase.SlotFirst();
        }

        private void SendGameFirstGameLog()
        {
            UndercGameLog.Singular.GameFirst();
            UndercGameLog.Firebase.GameFirst();
        }

        private void SendTutorialCompleteGameLog()
        {
            UndercGameLog.Singular.CompleteTutorial();
            UndercGameLog.Firebase.CompleteTutorial();
        }
    }
}