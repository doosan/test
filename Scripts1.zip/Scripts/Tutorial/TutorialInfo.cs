using UnityEngine;
using System;

namespace Underc.Tutorial
{
	[CreateAssetMenu(fileName="TutorialInfo", menuName="Underc/Tutorial/Info")]
	public class TutorialInfo : ScriptableObject
	{
        [Serializable]
        public class Item
        {
            public TutorialChapter chapter;
            public BaseTutorial tutorial;
        }

        #pragma warning disable 0649
		[SerializeField] private Item[] items;
        #pragma warning restore 0649

        public Item Get(TutorialChapter chapter)
        {
            for (int i = 0; i < items.Length; i++)
            {
                var item = items[i];
                if (item.chapter == chapter)
                {
                    return item;
                }
            }

            return null;
        }

        public bool Contains(TutorialChapter chapter)
        {
            return Get(chapter) != null;
        }
	}
}
