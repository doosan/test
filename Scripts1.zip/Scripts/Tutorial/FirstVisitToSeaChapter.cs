using System.Collections;
using TMPro;
using Underc.Lobby;
using Underc.Ocean;
using UnityEngine;

namespace Underc.Tutorial
{
    public class FirstVisitToSeaChapter : BaseTutorial
    {
        [Header("Intro")]
        [SerializeField] private GameObject introObject;
        [SerializeField] private TextMeshProUGUI introText;
        public float introAfterDelay = 0.5f;
        public float introTextSkipTime = 6.0f;

        protected override void Awake()
        {
            base.Awake();

            introObject.SetActive(false);
        }

        protected override IEnumerator PlaySteps()
        {
            yield return ShowIntro();
        }

        private IEnumerator ShowIntro()
        {
            var lobbyManager = GameObject.FindObjectOfType<LobbyManager>();

            ///
            Sea2D sea = lobbyManager.OceanView.Sea;
            yield return sea.ShowIntroCoroutine();
            
            introText.text = sea.IntroMessage;

            ///
            introObject.SetActive(true);
            yield return new WaitForSeconds(introTextSkipTime);
            introObject.SetActive(false);

            yield return new WaitForSeconds(introAfterDelay);
        }
    }
}