using Underc.Net.Client;
using Underc.User;

namespace Underc.Net
{
    public sealed class HTTPHandler
    {
        public void Do(GetAssetFileResponse response)
        {
            MyInfo.Update(response.data);
        }

        public void Do(UserCoreResponse response)
        {
            MyInfo.Update(response.user);
            MyInfo.Deal.Update(response.deal);
        }

        public void Do(SlotListResponse response, string order)
        {
            MyInfo.Update(response.data, order);
        }

        public void Do(SeaListResponse response)
        {
            MyInfo.Ocean.UpdateSeaComing(response.coming);
            MyInfo.Ocean.UpdateSeaList(response.data);
        }

        public void Do(SeaMineResponse response)
        {
            MyInfo.Ocean.UpdateSeaMine(response.data);
        }

        public void Do(FishBookListResponse response)
        {
            MyInfo.Ocean.Book.UpdateFishBookList(response.data);
            MyInfo.Alarms.UpdateBookNewFishes(response.data);
        }

        public void Do(SwimmerBookListResponse response)
        {
            MyInfo.Ocean.Book.UpdateSwimmerBookList(response.data);
            MyInfo.Alarms.UpdateBookNewSwimmers(response.data);
        }

        public void Do(SeaItemListResponse response)
        {
            MyInfo.Ocean.UpdateSeaItemList(MyInfo.Ocean.CurrentSeaID, response.data);
            MyInfo.Alarms.UpdateInventoryNewFishes(response.data.unplaced);
        }

        public void Do(ProfileResponse response)
        {
            ProfileData profileData = response.data;
            MyInfo.Profile.Update(profileData);
            MyInfo.VipClass.Update(profileData.vip, profileData.vip_reset, profileData.vip_benefit, profileData.vip_rate_type);
        }

        public void Do(VipResetResponse response)
        {
            MyInfo.VipClass.Update(response.vip, response.vip_reset);
            MyInfo.VipClass.UpdateIsReseted(response.vip_reset.Length > 0);
        }

        public void Do(ShopResponse response)
        {
            MyShop myShop = MyInfo.Shop;
            myShop.Coin.Update(response.coin, response.best_index, response.most_index);
            myShop.CoinSale.Update(response.sale);
            myShop.CoinCoupon.Update(response.coupon);
            MyInfo.VipClass.Update(VipBenefitTableItem.CoinPackages, response.vip);
        }

        public void Do(OceanBonusResponse response)
        {
            MyInfo.OceanBonus.Update(response.data);
        }

        public void Do(OceanBonusClaimResponse response)
        {
            MyInfo.OceanBonus.Update(response.data);
        }

        public void Do(CasinoBonusResponse response)
        {
            if (response.data != null)
            {
                MyInfo.CasinoBonus.Update(response.data);
            }
        }

        public void Do(WelcomeBackClaimResponse response)
        {
            MyInfo.CasinoBonus.Update(response.type, response.value);
        }

        public void Do(TutorialSlotResponse response)
        {
            MyInfo.Update(response.data);
        }

        public void Do(SeaStoryResponse response)
        {
            MyInfo.Ocean.CurrentSeaStory.Update(response.data);
        }

        public void Do(DailyMissionPointClaimResponse response)
        {
            MyInfo.DailyMission.Update(response.data);
        }

        public void Do(ServerInfoResponse response)
        {
            AppService.SetServerTimeZone(response.data.tz);
        }
        
        public void Do(MissionResponse response)
        {
            var missionData = response.data;
            if (missionData.daily_quest != null)
            {
                MyInfo.DailyMission.Update(response.ts, missionData.daily_quest);
            }

            if (missionData.clam_harvest != null)
            {
                 MyInfo.ClamHarvest.Update(missionData.clam_harvest, missionData.clam_harvest.item);
            }

            if (missionData.aqua_blitz != null)
            {
                MyInfo.AquaBlitz.Update(response.ts, missionData.aqua_blitz);
            }

            if (missionData.ocean_pass != null
                && missionData.ocean_pass.free != null)
            {
                MyInfo.MissionPass.Update(missionData.ocean_pass);
            }
        }
    }
}