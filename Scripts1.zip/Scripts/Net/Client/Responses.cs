
using System;
using SlotGame.Machine;
using Underc.Lobby;

namespace Underc.Net.Client
{
    [Serializable]
    public class ClientResponse
    {
        public bool isSuccess;
        public long statusCode;
        public string rawData;
        public string userid;
        public string sessid;
        public long ts;
        public int ret;
        public string error;
    }

    public class VersionResponse : ClientResponse
    {
        public VersionData latest;
        public VersionData min;
    }

    [Serializable]
    public sealed class UserCoreResponse : ClientResponse
    {
        public UserData user;
        public OfferData deal;
    }

    [Serializable]
    public sealed class UnityAdsNextResponse : GameResponse
    {
        public UnityAdsNextData data;
    }

    [Serializable]
    public sealed class UnityAdsClaimResponse : GameResponse
    {
        public UnityAdsClaimData data;
    }

    [Serializable]
    public sealed class UnityAdsCheckResponse : GameResponse
    {
        public UnityAdsCheckData data;
    }

    [Serializable]
    public sealed class TutorialSlotResponse : ClientResponse
    {
        public TutorialSlotData data;
    }

    [Serializable]
    public sealed class SwimmerBookListResponse : GameResponse
    {
        public SwimmerBookListData data;
    }

    [Serializable]
    public class StartBonusResponse : ClientResponse
    {
        public StartBonusData data;
    }

    [Serializable]
    public sealed class VoteOpenResponse : ClientResponse
    {
        public long reward;
        public int dailycnt;
        public int[] exist_sea;
        public VoteData[] data;
    }

    [Serializable]
    public sealed class VoteResponse : ClientResponse
    {
        public long reward;
    }

    [Serializable]
    public sealed class VoteScoreResponse : GameResponse
    {
        public string[] pic_url;
        public string[] pic_title;
        public int[] sea_score;
        public int[] exist_sea;
    }

    [Serializable]
    public sealed class SlotListResponse : ClientResponse
    {
        public SlotListData data;
    }

    [Serializable]
    public sealed class SettingResponse : GameResponse
    {
        public SettingData data;
    }

    [Serializable]
    public sealed class SellFishResponse : GameResponse
    {
        public SellFishData data;
    }

    [Serializable]
    public sealed class SeaMineResponse : GameResponse
    {
        public SeaMineData data;
    }

    [Serializable]
    public sealed class SeaListResponse : GameResponse
    {
        public SeaData[] data;
        public SeaData coming;
    }

    [Serializable]
    public sealed class SeaItemMoveResponse : GameResponse
    {
        public SeaItemMoveData data;
    }

    [Serializable]
    public sealed class SeaItemListResponse : GameResponse
    {
        public SeaItemListData data;
    }

    [Serializable]
    public sealed class SeaItemBuyResponse : GameResponse
    {
        public SeaItemBuyUserData user;
        public SeaItemBuySeaData sea;
    }

    [Serializable]
    public sealed class SeaClearResponse : GameResponse
    {
        public SeaClearData data;
    }

    [Serializable]
    public sealed class RegisterResponse : ClientResponse
    {
        public string pwd;
    }

    [Serializable]
    public class QuestClamCollectResponse : ClientResponse
    {
        public QuestClamCollectData data;
    }

    public class PurchaseResponse : ClientResponse
    {
        public long coin;
        public long pearl;
        public long ticket;
        public long golden;
        public long obsidian;
        public long xp_booster;
        public long pearl_booster;
        public int fish;
        public long bonus_coin;
        public int cnt;
        public OfferData deal;
        public int vip_class;
        public long vip_point;
    }

    [Serializable]
    public class ProfileResponse : ClientResponse
    {
        public ProfileData data;
    }

    [Serializable]
    public class VipResetResponse : ClientResponse
    {
        public VipData vip;
        public VipResetData[] vip_reset;
    }

    [Serializable]
    public sealed class OceansPassResponse :ClientResponse
    {
        public OceanPassMissionData pass;
    }

    [Serializable]
    public sealed class OceanPassClaimResponse :ClientResponse
    {
        public OceanPassClaimData pass;
    }

    [Serializable]
    public sealed class AquaBlitzClaimResponse : ClientResponse
    {
        public CommonRewardData[] reward;
        public int mission_pass_step;
        public int aqua_blitz_step;    
        public long aqua_blitz_curr;  // 마지막 블리츠 보상 일때는 0 이 와야함
    }

    [Serializable]
    public sealed class OceanBonusResponse : ClientResponse
    {
        public OceanBonusData data;
    }

    [Serializable]
    public sealed class OceanBonusClaimResponse :ClientResponse
    {
        public OceanBonusClaimData data;
    }

    [Serializable]
    public sealed class NotiResponse : ClientResponse
    {
        public NotiData[] data;
    }

    [Serializable]
    public class NotiCheckResponse : ClientResponse
    {
        public MaintenanceData[] check;
    }

    [Serializable]
    public class AdminNoticeResponse : ClientResponse
    {
        public AdminNoticeData[] data;
    }

    [Serializable]
    public class AdminEventResponse : ClientResponse
    {
        public AdminEventData[] data;
    }

    [Serializable]
    public sealed class LoginResponse : ClientResponse
    {
        public TimeData time;
        public long reg_ts;
    }

    [Serializable]
    public sealed class InboxRespnose : ClientResponse
    {
        public InboxItemData[] data;
    }

    [Serializable]
    public sealed class InboxClaimRespnose : ClientResponse
    {
        public InboxItemRewardData data;
    }

    [Serializable]
    public sealed class GetSettingResponse : ClientResponse
    {
        public string[] keys;
        public string[] values;
    }

    [Serializable]
    public sealed class GetAssetFileResponse : GameResponse
    {
        public GetAssetFileData data;
    }

    [Serializable]
    public sealed class GameSpinResponse : GameResponse
    {
        public SpinData data;
        public SpinQuestData spin_quest;
        public DailyMissionData daily_quest;
        public AquaBlitzMissionSpinData aqua_blitz_mission;
        public QuestClamData quest_clam;
        public LevelData level;
        public ChallengeData challenge;
        public SpinNotiData noti;
        public RandomBonusData random_bonus;
    }

    [Serializable]
    public sealed class GameSpecialResponse :GameResponse
    {
        public SpecialData data;
        public DailyMissionData daily_quest;
        public AquaBlitzMissionSpinData aqua_blitz_mission;
    }

    [Serializable]
    public class GameResponse : ClientResponse
    {
        public string slotid;
    }

    [Serializable]
    public sealed class GameEnterResponse :GameResponse
    {
        public EnterData data;
        public SpinQuestData spin_quest;
        public DailyMissionData daily_quest;
        public QuestClamData quest_clam;
        public ChallengeData challenge;
        public EnterLevelData level;
        public AquaBlitzMissionSpinData aqua_blitz_mission;
    }

    [Serializable]
    public sealed class GameChoiceResponse :GameResponse
    {
        public ChoiceData data;
        public DailyMissionData daily_quest;
        public AquaBlitzMissionSpinData aqua_blitz_mission;
    }

    [Serializable]
    public sealed class GameBetResponse :GameResponse
    {
        public BetData data;
    }

    [Serializable]
    public sealed class FishInfoResponse : GameResponse
    {
        public FishInfoData data;
    }

    [Serializable]
    public sealed class FishBookListResponse : GameResponse
    {
        public FishBookListData data;
    }

    [Serializable]
    public class FBRequestResponse : ClientResponse
    {
        public string[] requests;
        public int[] results;
    }

    [Serializable]
    public class PlatformDisconnectResponse{}

    [Serializable]
    public class PlatformConnectResponse : ClientResponse
    {
        public string required;  // login: 재로그인 필요, register: 재가입 필요
        public string pwd;
    }

    [Serializable]
    public class FanpageRewardResponse : ClientResponse
    {
        public FanpageRewardData data;
    }

    public class DailyBonusClaimResponse : ClientResponse
    {
        public long daily_bonus;

        public long coin_per_streak;
        public long streak_max;
        public long streak_day;
        public long streak_bonus;

        public long starting_coin;
        public long fish_cnt;
        public long fish_bonus;

        public long vip_bonus;
        public float vip_rate;
        public string vip_rate_type;

        public long limit_fish_cnt;

        public DailyBonusRewardData[] reward;
    }

    [Serializable]
    public class DailyBonusRewardData
    {
        public string rwd; /// s_pickax
        public long val;
    }

    public class WelcomeBackClaimResponse : ClientResponse
    {
        public int[] type;
        public long[] value;
    }

    [Serializable]
    public class CollectSpinQuestResponse : ClientResponse
    {
        public SpinQuestCollectData data;
    }

    [Serializable]
    public sealed class ClapsResponse : ClientResponse
    {
        public ClapsData[] data;
    }

    [Serializable]
    public sealed class ClapResponse : ClientResponse
    {
        public ClapData data;
    }

    [Serializable]
    public sealed class CheckBetResponse :ClientResponse
    {
        public CheckBetData data;
    }

    public class CasinoBonusResponse : ClientResponse
    {
        public CasinoBonusData data;
    }

    [Serializable]
    public sealed class ShopResponse : GameResponse
    {
        public ShopCoinData[] coin;
        public ShopSaleData sale;
        public ShopCouponItemData[] coupon;
        public int best_index;
        public int most_index;
        public VipBenefitTableItemData vip;
    }

    [Serializable]
    public sealed class ObsidianRewardResponse : GameResponse
    {
        public ObsidianRewardData data;
    }

    [Serializable]
    public sealed class GoldenRewardResponse : GameResponse
    {
        public GoldenRewardData data;
    }

    [Serializable]
    public sealed class OfferResponse : ClientResponse
    {
        public OfferData[] offer;
        public OfferData deal;
    }

    [Serializable]
    public sealed class DealResponse : ClientResponse
    {
        public OfferData deal;
    }

    [Serializable]
    public sealed class FreeBonusClaimResponse : ClientResponse
    {
        public FreeBonusClaimData data;
    }

    [Serializable]
    public sealed class CouponResponse : ClientResponse
    {
        public CouponData[] data;
    }

    [Serializable]
    public sealed class SeaStoryResponse : ClientResponse
    {
        public SeaStoryData data;
    }

    [Serializable]
    public sealed class SeaStoryCalimResponse : ClientResponse
    {
        public SeaStoryClaimData data;
    }

    [Serializable]
    public sealed class DailyQuestResponse : ClientResponse
    {
        public DailyMissionData data;
    }

    [Serializable]
    public sealed class DailyMissionPointClaimResponse : ClientResponse
    {
        public DailyMissionPointClaimData data;
    }

    [Serializable]
    public sealed class DailyMissionItemClaimResponse : ClientResponse
    {
        public int prev_step;
        public CommonRewardData[] reward;

        public DailyMissionData daily_quest;

        public int mission_pass_step;
    }

    [Serializable]
    public sealed class ClamHarvestResponse : ClientResponse
    {
        public ClamHarvestData data;
        public PickaxPurchaseItemData[] item;
    }

    [Serializable]
    public sealed class HarvestResponse : ClientResponse
    {
        public HarvestData data;
    }

    [Serializable]
    public sealed class TargetResponse : ClientResponse
    {
        public string address;
        public string type;
    }

    [Serializable]
    public sealed class UserDeleteResponse : ClientResponse
    {
    }

    [Serializable]
    public sealed class MissionResponse : ClientResponse
    {
        public MissionData data;
    }

    [Serializable]
    public sealed class ServerInfoResponse : ClientResponse
    {
        public ServerInfoData data;
    }
    
    public sealed class MissionPassClaimResponse : ClientResponse
    {
        public MissionPassClaimData pass;
    }

    [Serializable]
    public sealed class MissionPassClaimAllResponse : ClientResponse
    {
        public MissionPassClaimData[] free;
        public MissionPassClaimData[] buy;
        
        public bool IsFreeValid()
        {
            return free != null && free.Length > 0;
        }

        public bool IsBuyValid()
        {
            return buy != null && buy.Length > 0;
        }
    }
}