using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using LitJson;
using Gaga;
using System.Text;

namespace Underc.Net.Client
{
    public enum RetryError
    { 
        None,
        NetworkOrHttp,
        JsonParsing
    }

    public class RestClient : MonoBehaviour
    {
        public const int DEFAULT_TIMEOUT                   = 10;
        public const int DEFAULT_RETRY                     = 3;
        public const float DEFAULT_INTERVAL                = .333333f;

        private Dictionary<string, object> defaultMessageDic;
        private StringBuilder stringBuilder = new StringBuilder();

        public event Action<string> onErrorLogOccurred;

        private Dictionary<RetryError, int> retryCounts;
        private RetryError RetryErrorInTest;

        public sealed class RequestInfo<T> where T : ClientResponse
        {
            public T data;
            public bool isDone;
        }

        public sealed class Request<T> : IRequest<T>
                                       where T : ClientResponse
        {
            public T data
            {
                get => info != null ? info.data : null;
            }

            public bool isDone
            {
                get => info != null ? info.isDone : false;
            }

            public bool isSuccess
            {
                get => data.isSuccess == true && data.ret == 0;
            }

            private RequestInfo<T> info;

            public Request(RequestInfo<T> info)
            {
                this.info = info;
            }

            public IEnumerator WaitForResponse()
            {
                while (isDone == false)
                {
                    yield return null;
                }
            }
        }

        private void Awake()
        {
            defaultMessageDic = new Dictionary<string, object>();
            retryCounts = new Dictionary<RetryError, int>();
        }

        public void SetRetryErrorInTest(string value)
        {
            Enum.TryParse(value, out RetryErrorInTest);
        }

        public void AddDefaultMessage(string key, object value)
        {
            if (defaultMessageDic.ContainsKey(key) == true)
            {
                defaultMessageDic[key] = value;
            }
            else
            {
                defaultMessageDic.Add(key, value);
            }
        }

        public void RemoveDefaultMessage(string key)
        {
            if (defaultMessageDic.ContainsKey(key) == true)
            {
                defaultMessageDic.Remove(key);
            }
        }

        public void ClearDefaultMessages()
        {
            defaultMessageDic.Clear();
        }

        public Request<T> Post<T>(string uri, Hashtable body, Action<T> onComplete, int timeOut = DEFAULT_TIMEOUT, int retry = DEFAULT_RETRY, bool sendErrorLog = true) where T : ClientResponse, new()
        {
            return Send<T>(uri, body, UnityWebRequest.kHttpVerbPOST, onComplete, timeOut, retry, sendErrorLog);
        }

        public Request<T> Post<T>(string uri, Hashtable body, int timeOut = DEFAULT_TIMEOUT, int retry = DEFAULT_RETRY, bool sendErrorLog = true) where T : ClientResponse, new()
        {
            return Send<T>(uri, body, UnityWebRequest.kHttpVerbPOST, null, timeOut, retry, sendErrorLog);
        }

        public Request<T> Get<T>(string uri, Action<T> onComplete, int timeOut = DEFAULT_TIMEOUT, int retry = DEFAULT_RETRY, bool sendErrorLog = true) where T : ClientResponse, new()
        {
            return Send<T>(uri, null, UnityWebRequest.kHttpVerbGET, onComplete, timeOut, retry, sendErrorLog);
        }

        public Request<T> Get<T>(string uri, int timeOut = DEFAULT_TIMEOUT, int retry = DEFAULT_RETRY, bool sendErrorLog = true) where T : ClientResponse, new()
        {
            return Send<T>(uri, null, UnityWebRequest.kHttpVerbGET, null, timeOut, retry, sendErrorLog);
        }

        public Request<T> Put<T>(string uri, Hashtable body, Action<T> onComplete, int timeOut = DEFAULT_TIMEOUT, int retry = DEFAULT_RETRY, bool sendErrorLog = true) where T : ClientResponse, new()
        {
            return Send<T>(uri, body, UnityWebRequest.kHttpVerbPUT, onComplete, timeOut, retry, sendErrorLog);
        }

        public Request<T> Put<T>(string uri, Hashtable body, int timeOut = DEFAULT_TIMEOUT, int retry = DEFAULT_RETRY, bool sendErrorLog = true) where T : ClientResponse, new()
        {
            return Send<T>(uri, body, UnityWebRequest.kHttpVerbPUT, null, timeOut, retry, sendErrorLog);
        }

        public Request<T> Delete<T>(string uri, Action<T> onComplete, int timeOut = DEFAULT_TIMEOUT, int retry = DEFAULT_RETRY, bool sendErrorLog = true) where T : ClientResponse, new()
        {
            return Send<T>(uri, null, UnityWebRequest.kHttpVerbDELETE, onComplete, timeOut, retry, sendErrorLog);
        }

        public Request<T> Delete<T>(string uri, int timeOut = DEFAULT_TIMEOUT, int retry = DEFAULT_RETRY, bool sendErrorLog = true) where T : ClientResponse, new()
        {
            return Send<T>(uri, null, UnityWebRequest.kHttpVerbDELETE, null, timeOut, retry, sendErrorLog);
        }

        private Request<T> Send<T>(string uri, Hashtable body, string method, Action<T> onComplete, int timeOut = DEFAULT_TIMEOUT, int retry = DEFAULT_RETRY, bool sendErrorLog = true) where T : ClientResponse, new()
        {
            string jsonString = null;

            if (body != null)
            {
                foreach (var defaultMessageItem in defaultMessageDic)
                {
                    body[defaultMessageItem.Key] = defaultMessageItem.Value;
                }

                jsonString = JsonMapper.ToJson(body);
            }

            var reqInfo = new RequestInfo<T>();
            var req = new Request<T>(reqInfo);
            StartCoroutine(SendCoroutine<T>(method, uri, jsonString, onComplete, timeOut, retry, reqInfo, sendErrorLog));
            return req;
        }

        private void ResetRetryCount()
        {
            retryCounts.Clear();
        }

        private int ConsumeRetryCount(RetryError mode, int initialCount)
        {
            int remainCount = -1;
            if (mode != RetryError.None)
            {
                if (retryCounts.ContainsKey(mode) == false)
                {
                    retryCounts.Add(mode, initialCount);
                }

                remainCount = retryCounts[mode];
                remainCount -= 1;
                retryCounts[mode] = remainCount;
            }
            return remainCount;
        }

        private IEnumerator SendCoroutine<T>(string method, string uri, string jsonString, Action<T> onComplete, int timeOut, int retry, RequestInfo<T> info, bool sendErrorLog) where T : ClientResponse, new()
        {
            Debug.LogFormat("[RestClient] Request - method : {0} , uri : {1} , json : {2}",method.ToString(), uri, jsonString);

            ResetRetryCount();

            while (true)
            {
                using (UnityWebRequest unityWebRequest = new UnityWebRequest(uri, method.ToString()))
                {
                    unityWebRequest.SetRequestHeader("Content-Type", "application/json");
                    unityWebRequest.SetRequestHeader("Cache-Control", "max-age=0, no-cache, no-store");
                    unityWebRequest.SetRequestHeader("Pragma", "no-cache");
                    unityWebRequest.timeout = timeOut;
                    unityWebRequest.downloadHandler = new DownloadHandlerBuffer();

                    if (String.IsNullOrEmpty(jsonString) == false)
                    {
                        byte[] byteData = System.Text.Encoding.ASCII.GetBytes(jsonString.ToCharArray());
                        unityWebRequest.uploadHandler = new UploadHandlerRaw(byteData);
                    }

                    yield return unityWebRequest.SendWebRequest();

                    bool isSuccess = true;
                    if (unityWebRequest.result == UnityWebRequest.Result.ConnectionError || unityWebRequest.result == UnityWebRequest.Result.ProtocolError)
                    {
                        isSuccess = false;
                    }

                    T resp;
                    int remainCount = -1;
                    if (isSuccess == true 
                        && unityWebRequest.downloadHandler != null
                        && RetryErrorInTest != RetryError.NetworkOrHttp)
                    {
                        string respJsonString = unityWebRequest.downloadHandler.text;

                        if (String.IsNullOrEmpty(respJsonString) == false
                            && RetryErrorInTest != RetryError.JsonParsing)
                        {
                            Debug.LogFormat("[RestClient] Response - success : {0}, code : {1}, json : {2}",isSuccess,unityWebRequest.responseCode, respJsonString);
                            resp = ConvertJsonToObject<T>(respJsonString);
                            resp.rawData = respJsonString;
                        }
                        else
                        {
                            Debug.LogFormat("[RestClient] Response - success : {0}, code : {1}, JSON parsing error : {2}",isSuccess,unityWebRequest.responseCode, respJsonString);

                            remainCount = ConsumeRetryCount(RetryError.JsonParsing, retry);
                            if (remainCount > -1)
                            {
                                Debug.LogFormat("[RestClient] Retry - remain count : {0}", remainCount);
                                yield return new WaitForSeconds(DEFAULT_INTERVAL);
                                continue;
                            }

                            resp = new T();
                            resp.ret = 1;
                            resp.error = string.Format(System.Globalization.CultureInfo.InvariantCulture, "Json parsing error ({0})", unityWebRequest.responseCode);
                            resp.rawData = "";
                        }
                    }
                    else
                    {
                        Debug.LogFormat("[RestClient] Response - success : {0} , code : {1} , error : {2}\n{3}",isSuccess,unityWebRequest.responseCode,unityWebRequest.error,jsonString);
                        remainCount = ConsumeRetryCount(RetryError.NetworkOrHttp, retry);
                        if (remainCount > -1)
                        {
                            Debug.LogFormat("[RestClient] Retry - remain count : {0}", remainCount);
                            yield return new WaitForSeconds(DEFAULT_INTERVAL);
                            continue;
                        }

                        resp = new T();
                        resp.ret = 1;
                        resp.error = string.IsNullOrEmpty(unityWebRequest.error) ? "Network Error" : unityWebRequest.error;
                    }

                    resp.isSuccess = isSuccess;
                    resp.statusCode = unityWebRequest.responseCode;

                    if (resp.isSuccess == true)
                    {
                        UpdateServerTime(resp.ts);
                    }
                    
                    if (resp.isSuccess == false 
                       || resp.ret > 0 
                       || string.IsNullOrEmpty(resp.error) == false)
                    {
                        if (sendErrorLog)
                        {
                            OnErrorLog(jsonString, resp.rawData, unityWebRequest.responseCode, unityWebRequest.downloadedBytes, (retry - remainCount));
                        }
                    }
                    
                    if (onComplete != null)
                    {
                        onComplete(resp);
                    }

                    if (info != null)
                    {
                        info.data = resp;
                        info.isDone = true;
                    }

                    break;
                }
            }
        }

        private T ConvertJsonToObject<T>(string jsonString) where T : ClientResponse
        {
            T obj = (T)JsonUtility.FromJson(jsonString, typeof(T));
            return obj;
        }

        private void UpdateServerTime(long timeStamp)
        {
            GlobalTime.Instance.SetTimeStamp(timeStamp);
        }

        private void OnErrorLog(string req, string resp, long statusCode, ulong downloadedBytes, int retryCount)
        {
            stringBuilder.Length = 0;

            stringBuilder.Append("statusCode : ");
            stringBuilder.Append(statusCode);
            stringBuilder.Append(", downloadedBytes : ");
            stringBuilder.Append(downloadedBytes);
            stringBuilder.Append(", retryCount : ");
            stringBuilder.Append(retryCount);
            stringBuilder.Append(", req : ");
            stringBuilder.Append(req);
            stringBuilder.Append(", resp : ");
            stringBuilder.Append(resp);

            var value = stringBuilder.ToString();
            Debug.Log("Error Log : " +value);

            onErrorLogOccurred?.Invoke(value);
        }
    }
}