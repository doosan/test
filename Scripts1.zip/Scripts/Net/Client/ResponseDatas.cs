using System;
using Underc.User;

namespace Underc
{
    [Serializable]
    public sealed class CheckBetData
    {
        public long[] rookies;
        public long[] min_levels;
        public long[] high_roller;
        public long[] min_coin;
        public int high_unlock_level;
    }

    [Serializable]
    public class QuestClamData
    {
        public long unlock;
        public string mission;
        public long curr;
        public long goal;

        public long reward_coin;
        public long reward_pearl;
        public long reward_ticket;
    }

    [Serializable]
    public sealed class QuestClamCollectData
    {
        public long reward_coin;
        public long reward_pearl;
        public long reward_ticket;
        public string next_mission;
        public long next_goal;
    }

    [Serializable]  
    public sealed class SeaItemBuySeaData
    {
        public int happiness;
        public float star;
        public int item_cnt;
        public long[] clear;
    }

    [Serializable]  
    public sealed class SeaItemBuyUserData
    {
        // 1. 구매하는 아이템의 타입에 따라 전달 받는 데이터의 조합이 다릅니다. 
        //   - 물고기 구매시 : { coin, pearl }
        //   - 테마 구매시 : { pearl }
        //   - 유니크 스위머 구매시 : { pearl, ticket } 
        // 2. 로직상 일괄적으로 Serializing 되기 때문에 전달 받지 않은 값에 0이 들어가 있고, 사용해서는 안됩니다.
        public long coin;
        public long pearl;
        public long ticket;
    }

    [Serializable]
    public sealed class SeaItemListData
    {
        public SeaItemListSeaData sea;
        public SeaItemListItemsData placed;
        public SeaItemListItemsData unplaced;
    }

    [Serializable]
    public sealed class SeaItemListSeaData
    {
        public long capa;
    }

    [Serializable]
    public sealed class SeaItemListItemsData
    {
        public string[] types;
        public int[] ids;
        public int[] cnts;
        public int[] news;
    }

    [Serializable]
    public sealed class SeaItemMoveData
    {
        public long hp;
        public long star1_hp;
        public int unlock_id;
        public long[] clear;
    }

    [Serializable]
    public sealed class SeaMineData
    {
        public int sea;
        public string name;
        public int capa;
        public int item_cnt;
        public int unlock;
    }

    [Serializable]
    public sealed class SellFishData
    {
        public int fish;
        public long add_coin;
        public long coin;
    }

    [Serializable]
    public sealed class SettingData
    {
        public string[] fields;
        public string[] values;
    }

    [Serializable]
    public sealed class VoteData
    {
        public string id;//userid 가 아니라 해당 데이터의 id
        public string nick;
        public int pic_num;
        public string pic_url;
        public string sea_url;
        public string pic_title;
    }

    [Serializable]
    public sealed class SpinNotiData
    {
        public long ts;
    }

    [Serializable]
    public class SpinQuestData
    {
        public string mission;
        public long curr;
        public long goal;

        public long reward_coin;
        public long reward_pearl;
        public long reward_ticket;

        public int step;
    }

    [Serializable]
    public class SpinQuestCollectData
    {
        public long reward_coin;
        public long reward_pearl;
        public long reward_ticket;
        public string next_mission;
        public long next_goal;
        public long next_reward_coin;
        public long next_reward_pearl;
        public long next_reward_ticket;
        public int next_step;
    }

    [Serializable]
    public class StartBonusData
    {
        public long coin;
    }

    [Serializable]
    public sealed class SwimmerBookListData
    {
        public long update_ts;
        public SwimmerBookList swimmers;
        public int[] new_fishes;
        public int free_id;
        public int free_state;  // 획득 여부, 0 - 미획득 , 1 - 획득
    }

    [Serializable]
    public sealed class SwimmerBookList
    {
        public int[] ids;
        public int[] min_levels;
        public int[] pearls;
        public int[] tickets;
        public int[] points;
    }

    [Serializable]
    public sealed class TimeData
    {
        public float poll;
        public float check_poll;
    }

    [Serializable]  
    public sealed class TutorialSlotData
    {
        public string slotid;
        public int back_to_slot_after_swimmer_tuto;
    }

    [Serializable]
    public sealed class UnityAdsCheckData
    {
        public int dailycnt;
        public bool avail;
    }

    [Serializable]
    public sealed class UnityAdsClaimData
    {
        public long reward;
        public long coin;
    }

    [Serializable]
    public sealed class UnityAdsNextData
    {
        public int dailycnt;
        public long[] wheel;
    }

    [Serializable]
    public sealed class UserData
    {
        public LevelData level;
        public long coin;
        public long pearl;
        public long ticket;
        public long spins;
        public long pearl_booster_end_ts;
        public AlarmsData alarms;
        public int vip_class;
        public long vip_reset_ts;
    }

    [Serializable]
    public sealed class AlarmsData
    {
        public long inbox;
    }

    [Serializable]
    public sealed class VersionData
    {
        public string ver;
        public string img;
    }

    [Serializable]  
    public sealed class ChallengeData
    {
        public int pearl_booster;
        public int pearl_booster_level;
        public int noti;
        public int noti_level;
        public int sea;
        public int sea_level;
        public long reward_coin;
    }

    [Serializable]
    public class CasinoBonusData
    {
        //public DailyMissionBonusData quest;
        //public ClamHarvestBonusData harvest;
        //public OceanPassDataObsolete pass;
        public GoldenBonusData golden;
        public ObsidianBonusData obsidian;
        public DailyBonusData daily;
        public FreeBonusData free;
    }

    [Serializable]
    public sealed class GoldenBonusData
    {
        public long free_ts;
        public long key;
        public int unlock;
    }

    [Serializable]
    public sealed class ObsidianBonusData
    {
        public long free_ts;
        public long key;
        public int times;
        public int unlock;
    }

    [Serializable]
    public sealed class DailyBonusData
    {
        public int available;
        public long claim_ts;
    }

    [Serializable]
    public sealed class FreeBonusData
    {
        public long coin;
        public int index;
        public long start_ts;
        public long end_ts;
    }

    [Serializable]
    public class SeaData
    {
        public int sea;
        public string name;
        public int step;
        public int unlock_level;
        public long bonus;
        public long curr;
        public long all;
        public int status;
    }

    [Serializable]
    public sealed class SeaClearData
    {
        public int star;
        public long reward;
        public int sea;
    }

    [Serializable]
    public sealed class RewardData
    {
        public const string RANDOM = "rand";
        public const string COIN = "coin";
        public const string PEARL = "pearl";
        public const string TICKET = "ticket";
        public const string GOLDEN = "golden";
        public const string OBSIDIAN = "obsidian";
        public const string XP_BOOSTER = "xp_booster";
        public const string PEARL_TICKET_BOOSTER = "pearl_booster";
        public const string FISH = "fish";
        public const string VIP_POINT = "vip_point";
        public const string SILVER_PICKAXE = "s_pickaxe";
        public const string GOLD_PICKAXE = "g_pickaxe";

        public RewardType Type
        {
            get
            {
                if (type == RewardType.none)
                {
                    if (Enum.TryParse(typeStr, out type))
                    {
                    }
                    else
                    {
                        Debug.LogWarning($"==== 타입을 변환하지 못했습니다. {typeStr} -> {type}");
                    }
                }
                return type;
            }
        }
        private RewardType type = RewardType.none;
        public string typeStr;
        public long value;
        public long additionalCoin;     // 물고기에 붙어있는 코인 보너스 값
        public long additionalVipCoin;  // VIP 코인 보너스 값
        public long additionalVipPoint; // 상점의 코인에 붙어있는 VIP 포인트 값
        public long openCount;
        public bool openAds;
        public bool openBuy;
        public float openPrice;
        public VipBenefitTableItemInfo tableItemInfo;

        public RewardData(): this(string.Empty, 0L) {}

        public RewardData(string typeStr,
                          long value,
                          long additionalCoin = 0,
                          long additionalVipCoin = 0,
                          long additionalVipPoint = 0,
                          long openCount = 0, 
                          bool openAds = false, 
                          bool openBuy = false,
                          float openPrice = 0f,
                          VipBenefitTableItemInfo tableItemInfo = new VipBenefitTableItemInfo())
        {
            this.typeStr = typeStr;
            this.value = value;
            this.additionalCoin = additionalCoin;
            this.additionalVipCoin = additionalVipCoin;
            this.additionalVipPoint = additionalVipPoint;
            this.openCount = openCount;
            this.openAds = openAds;
            this.openBuy = openBuy;
            this.openPrice = openPrice;
            this.tableItemInfo = tableItemInfo;
        }

        public bool IsValid()
        {
            return string.IsNullOrEmpty(typeStr) == false && value > 0;
        } 

        public override string ToString()
        {
            return string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0}:{1}",typeStr,value);
        }
    }

    [Serializable]
    public sealed class ProfileData
    {
        public string nick;
        public int pic_num = -1;
        public string pic_url;
        public int level;
        public int seas;
        public long max_win;
        public long tot_win;
        public long clap_sent;

        public VipResetData[] vip_reset;
        public VipData vip;
        public VipBenefitTableData[] vip_benefit;
        public VipBenefitTableTypeData vip_rate_type;
    }

    [Serializable]
    public sealed class VipResetData
    {
        public int range_index;
        public float coe;
        public int begin_month;
        public int end_month;
        public long point;
    }

    [Serializable]
    public sealed class VipData
    {
        public int vip_class;
        public long xp;
        public long next_xp;
    }

    [Serializable]
    public class VipBenefitTableItemData
    {
        public string vip_class;
        public float bonus_rate;
        public string vip_rate_type;
    }

    [Serializable]
    public sealed class VipBenefitTableTypeData
    {
        public string shop_type;
        public string vip_type;
        public string daily_type;
        public string congrats_type;
        public string daily_quest_type;
        public string harvest_type;
        public string mission_pass_type;
        public string chest_type;
        public string sea_type;
        public string share_post_type;
        public string fan_page_type;
    }

    [Serializable]
    public sealed class VipBenefitTableData
    {
        public int vip_class;
        public float coin_packages;
        public float vip_points;
        public float daily_bonus;
        public float huge_bonus;
        public float daily_quest;
        public float harvest;
        public float mission_pass;
        public float chest;
        public float sea;
        public float share_post_gift;
        public float fan_page_gift;
        public bool vip_support;
    }

    [Serializable]
    public sealed class OceanPassMissionData : OceanPassDataObsolete
    {
        public OceanPassMissionFreeData free;
        public OceanPassMissionBuyData buy;
    }

    [Serializable]
    public class OceanPassMissionFreeData : OceanPassDataObsolete
    {
        public string[] types;
        public long[] values;
        public int[] status;  // 상태(0: 미션 미완료, 1: 미션 완료, 2: 보상 완료)
    }

    // status 상태(0: 보상 미완료, 2: 보상 완료)
    [Serializable]
    public sealed class OceanPassMissionBuyData : OceanPassMissionFreeData
    {
        public string itemid;
        public float price;
        public float sale_price;
        public bool sale;
        public bool bonus;
        public long vip_point;
    }

    [Serializable]
    public class OceanPassDataObsolete
    {
        public long unlock;
        public int season;
        public long end_ts;
        public long close_ts;
        public int step;
        public long curr;
        public long all; 
        public string mission;
        public long min_bet;
        public int n;
        public bool clear;
    }

    [Serializable]
    public class OceanPassClaimData
    {
        public int n;
    }

    [Serializable]
    public sealed class OceanBonusClaimData
    {
        public string type;
        public long bonus;
    }

    [Serializable]
    public sealed class NotiData
    {
        public long ts;
        public string type;
        public long uid;
        public string nick;
        public long win;
        public string sid;
        public int pic;
        public string url;
    }

    [Serializable]
    public class AdminNoticeData
    {
        public uint id;
        public int pos;
        public string img;
        public string btn;
        public ulong start_ts;
        public ulong end_ts;
        public int target1;
        public int target2;
        public string link;
        public string ver;

        public override string ToString()
        {
            return String.Format(System.Globalization.CultureInfo.InvariantCulture, "id : {0}, pos : {1}, img : {2}, btn : {3}, start_ts : {4}, end_ts : {5}, target1 : {6}, target2 : {7}, link : {8}, ver : {9}"
                                 ,id, pos, img, btn, start_ts, end_ts, target1, target2, link, ver);
        }
    }

    [Serializable]
    public sealed class AdminEventData : AdminNoticeData
    {
        public string win_type;
        public long cur;
        public long win_count;
        public long reward;
    }

    [Serializable]
    public class MaintenanceData
    {
        public static readonly string ID_APP = "app";

        public long start;
        public long end;
        public string id;//앱 점검인 경우 app, 슬롯 점검인 경우 슬롯의 아이디(1001) 가 전달된다

        public override string ToString()
        {
            return string.Format(System.Globalization.CultureInfo.InvariantCulture, "id: {0}, start: {1}, end: {2}", id, start, end);
        }
    }

    [Serializable]
    public sealed class EnterLevelData
    {
        public long pearl_booster_add_sec;
    }

    [Serializable]
    public sealed class LevelData
    {
        public long current;
        public float xp;
        public float xp_base;
        public float next_xp;
        public long levelup_bonus;
        public long levelup_bonus_added;
        public int vip_class;
        public long vip_point;
        public string unlock_swimmer;
        public long max_bet;
        public bool any_bet;
        public string unlock_slot;
        public long booster_end_ts;
        public long pearl_booster_end_ts;
        public long pearl_booster_add_sec;
        public RandomBonusData random_bonus;
        public GrowthData growth;
    }

    public enum InboxItemType
    {
        None = 0,

        //Facebook
        FacebookLogin = 11,
        FacebookLoginBonus = 12,
        WelcomBonus = 13,

        //Collect
        SeasonGift = 21,
        CSReward = 22,
        OceanPassReward = 23,
        AppUpdateReward = 24,

        //friends
        InviteReward = 31,
        CollectGift = 32,

        //Send
        SendGift1Week = 41,
        SendGift2Week = 42,
        InviteFriends = 43,
    }

    [Serializable]
    public sealed class InboxItemData
    {
        public ulong id;
        public int type;
        public string rwd;
        public long val;
        public string msg;
        public int picn;
        public string pic;
        public long xpr;

        public static bool IsCollectableItem(InboxItemType itemType)
        {
            return itemType == InboxItemType.SeasonGift
                || itemType == InboxItemType.CSReward
                || itemType == InboxItemType.OceanPassReward
                || itemType == InboxItemType.InviteReward
                || itemType == InboxItemType.CollectGift
                || itemType == InboxItemType.AppUpdateReward
                || itemType == InboxItemType.FacebookLoginBonus
                || itemType == InboxItemType.WelcomBonus;
        }

        public static bool IsSendableItem(InboxItemType itemType)
        {
            return itemType == InboxItemType.SendGift1Week
                || itemType == InboxItemType.SendGift2Week
                || itemType == InboxItemType.InviteFriends;
        }
        
        public static bool IsDeletableItem(InboxItemType itemType)
        {
            if (itemType == InboxItemType.FacebookLogin)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public override string ToString()
        {
            return string.Format(System.Globalization.CultureInfo.InvariantCulture, "[{0}: '{1}' type: {2} rwd: {3} val: {4} picn: {5} pic: {6} xpr: {7}]",id, msg, type, rwd, val, picn, pic, xpr);
        }
    }

    [Serializable]
    public sealed class InboxItemRewardData
    {
        public string rwd;
        public long val;
    }

    [Serializable]
    public sealed class GetAssetFileData
    {
        public string asset_file;
    }

    [Serializable]
    public sealed class FishInfoData
    {
        public int total;
        public int sea;
    }

    [Serializable]
    public sealed class FishBookListData
    {
        public long update_ts;
        public FishBookList fishes;
        public int[] new_fishes;
        public int free_id;
        public int free_state;  // 획득 여부, 0 - 미획득 , 1 - 획득
    }

    [Serializable]
    public sealed class FishBookList
    {
        public int[] ids;
        public int[] min_levels;
        public int[] pearls;
        public long[] coins;
        public int[] points;
    }

    [Serializable]
    public class FanpageRewardData
    {
        public string rwd;
        public long val;
        public int is_mystery;
    }

    [Serializable]  
    public sealed class ClapsData
    {
        public int pic;
        public string url;
    }

    [Serializable]  
    public sealed class ClapData
    {
        public long bonus;
    }

    [Serializable]
    public class ShopSaleData
    {
        public int sale;
        public long end_dt;
    }

    [Serializable]
    public class ShopCouponItemData
    {
        public int coupon_id; /// 프로토콜에 쿠폰 ID 가 비어있는데?
        public int index;
        public int bonus_rate;
        public string coupon_target;
        public long expire_time;
        public int cnt;
    }

    [Serializable]
    public class ShopCoinData
    {
        public string itemid;
        public long vip_point;
        public float price;
        public long coin;
        public long vip_bonus;
    }

    [Serializable]
    public sealed class ObsidianRewardData
    {
        public int fish;
        public int times;
        public long free_ts;
        public long key;
        public long bonus_coin;
        public bool buy;
        public float price;
        public long vip_bonus;
        public float vip_rate;
        public string vip_type;
    }

    [Serializable]
    public sealed class GoldenRewardData
    {
        public int fish;
        public long free_ts;
        public long key;
        public long bonus_coin;
        public int ads;
        public long vip_bonus;
        public float vip_rate;
        public string vip_type;
    }

    [Serializable]
    public sealed class OceanBonusData
    {
        public long clean;
        public long clean_ts;
        public long max_feed;
        public long feed;
        public long feed_ts;
    }

    [Serializable]
    public sealed class OfferData
    {
        public string type;
        public int offer_id;
        public string img_path;
        public string item_id;
        public long vip_point;
        public float price_was;
        public float price;
        public long coin;
        public string more;
        public long end_ts;
        public OfferBenefitData[] benefit;

        public bool IsValid { get { return offer_id != 0;}}
    }

    [Serializable]
    public sealed class OfferBenefitData
    {
        public string rwd;//RewardData 클래스에 정의된 상수들이 값으로 들어옴
        public long val;
    }

    [Serializable]
    public sealed class FreeBonusClaimData
    {
        public long coin;
        public FreeBonusData next;
    }

    [Serializable]
    public sealed class CouponData
    {
        public int coupon_id;
        public string img_url;
        public CouponItemData[] coupon;
    }

    [Serializable]
    public sealed class CouponItemData
    {
        public int bonus_rate;
        public string coupon_target;
        public long expire_time;
        public int cnt;
    }

    [Serializable]
    public sealed class SeaStoryData
    {
        public long[] points;
        public long[] rewards;
        public int step;
        public long point;
        public long not_claimed_point;
        public long prize;
        public SeaStoryCollectedData collected;
        public int new_sea;
    }

    [Serializable]
    public sealed class SeaStoryCollectedData
    {
        public long point;
        public int[] types;
        public int[] ids;
        public int[] cnts;
        public int[] news;

        public bool HasNewFish()
        {
            if (news == null)
            {
                return false;
            }

            for (int i = 0; i < news.Length; i++)
            {
                if (news[i] == 1)
                {
                    return true;
                }
            }

            return false;
        }
    }

    [Serializable]
    public sealed class SeaStoryClaimData
    {
        public long reward;
        public int step;
        public long point;
        public long not_claimed_point;
        public int new_sea;
        public SeaStoryPlacedData placed;
        public long vip_bonus;
        public float vip_rate;
        public string vip_rate_type;
    }

    [Serializable]
    public sealed class SeaStoryPlacedData
    {
        public int[] swimmer_ids; 
        public int[] swimmer_cnts; 
        public int[] fish_ids; 
        public int[] fish_cnts;

        public bool IsEmpty
        {
            get
            {
                return (swimmer_ids == null || swimmer_ids.Length == 0) && 
                       (fish_ids == null || fish_ids.Length == 0);
            }
        } 
    }

    [Serializable]
    public sealed class RandomBonusData
    {
        public int type; // 0:fish , 1:swimmer, 2:pearl, 3:ticket
        public int id;
        public long value;
        public int is_new; //0 : false, 1 : true
        public long is_prize; // 0 : none

        public bool IsNew => is_new > 0;
        public bool IsPrize => is_prize > 0;
    }

    [Serializable]
    public sealed class GrowthData
    {
        public int shop;
        public int daily;
        public int free;
        public int feed;
        public int chest;
        public int congrat;

        public bool IsValid
        {
            get
            {
                return shop > 0 
                       || daily > 0
                       || free > 0
                       || feed > 0
                       || chest > 0
                       || congrat > 0;
            }
        }
    }

    [Serializable]
    public sealed class MissionPassData
    {
        public long end_ts;
        public int season;
        public int step;
        public long curr;
        public long all;
        public MissionPassItemData free;
        public MissionPassBuyItemData buy;
    }

    [Serializable]
    public class MissionPassItemData
    {
        public string[] types;
        public long[] values;
        public int[] status;
    }

   [Serializable]
    public class MissionPassBuyItemData : MissionPassItemData
    {
        public string itemid;
        public long vip_point;
        public float price;
        public float sale_price;
        public bool bonus;
        public bool mission_box;
    }

    [Serializable]
    public sealed class DailyMissionData
    {
        public int is_unlock;
        public int unlock;

        public int prev_step;
        public int step;
        public string mission;
        public long curr;
        public long all;
        public long require;
        public long daily_end_ts;

        public long[] mp_point;

        public long weekly_curr;
        public long weekly_all;
        public long weekly_end_ts;

        public int n;
    }

    [Serializable]
    public sealed class DailyMissionPointClaimData
    {
        public CommonRewardData[] reward;
    }

    [Serializable]
    public sealed class CommonRewardData
    {
        public string rwd;  
        public long val;

        public CommonRewardData(string rwd, long val)
        {
            this.rwd = rwd;
            this.val = val;
        }
    }

    [Serializable]
    public sealed class AquaBlitzData
    {
        public int season;
        public int step;
        public string[] types;
        public long[] values;
        public int[] status;
        public int[] big;
        public long end_ts;
        public long curr;
        public long all;
        public AquaBlitzMissionData[] mission;
        public long mission_end_ts;
    }

    [Serializable]
    public sealed class AquaBlitzMissionData
    {
        public int slotid;
        public string mission;
        public long curr;
        public long all;
        public long requirement;
        public int status; // { 0: normal, 1: under repair }
        public AquaBlitzMissionRewardData[] reward;
    }

    [Serializable]
    public sealed class AquaBlitzMissionSpinData
    {
        public long curr;
        public long all;
        public int index;
    }

    [Serializable]
    public sealed class AquaBlitzMissionRewardData
    {
        public string rwd;
        public long val;
    }

    [Serializable]
    public sealed class ClamHarvestData
    {
        public long start_ts;
        public long end_ts;
        public ClamHarvestClamData gold;
        public ClamHarvestClamData silver;
        public PickaxPurchaseItemData[] item;
    }

    [Serializable]
    public sealed class ClamHarvestClamData
    {
        public int clam_index;
        public int pickaxe;      
        public int max_pickaxe;
        public CommonRewardData[] reward;
    }

    [Serializable]
    public sealed class PickaxPurchaseItemData
    {
        public string rwd;
        public int val;
        public float price;
        public string itemid;
    }

    [Serializable]
    public sealed class HarvestData
    {
        public string type;
        public int clam_index;
        public int pickaxe;
        public long remaining_bonus;
        public int use_pickaxe;
        public CommonRewardData[] reward;
        public PickaxPurchaseItemData[] item;
        public int mission_pass_step;
    }

    [Serializable]
    public sealed class ServerInfoData
    {
        public string tz;
    }

    [Serializable]
    public sealed class MissionData
    {
        public DailyMissionData daily_quest;
        public MissionPassData ocean_pass;
        public ClamHarvestData clam_harvest;
        public AquaBlitzData aqua_blitz;
    }

    [Serializable]
    public sealed class MissionPassClaimData
    {
        public int type;
        public int n;
        public string rwd;
        public long val;
        public long val2;
    }
}