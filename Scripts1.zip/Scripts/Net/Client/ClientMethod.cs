public enum ClientMethod
{
    GET,
    POST,
    PUT,
    DELETE
}