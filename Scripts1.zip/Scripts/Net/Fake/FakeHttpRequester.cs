using System;
using System.Collections;
using Underc.Net.Client;
using Underc.User;
using UnityEngine;

namespace Underc.Net
{
    public interface IRequest<T>
    {
        bool isSuccess { get; }

        T data { get; }

        IEnumerator WaitForResponse();
    }

    public class FakeRequest<T> : IRequest<T> where T : ClientResponse
    {
        public bool isSuccess
        {
            get => data.isSuccess == true && data.ret == 0;
        }

        private T loadedData;
        public T data
        {
            get;
            private set;
        }

        public FakeRequest()
        {
        }

        public void LoadResponse(T response)
        {
            if (response == null)
            {
                Debug.LogWarning("==== LoadResponse : response is null");
            }
            else
            {
                loadedData = response;
            }
        }

        public void UpdateData()
        {
            data = loadedData;
            if (data != null)
            {
                data.isSuccess = true;
                data.ret = 0;
            }
        }

        public IEnumerator WaitForResponse()
        {
            while (data == null)
            {
                yield return null;
            }
        }
    }

    public class FakeHttpRequester : MonoBehaviour
    {
        public static FakeHttpRequester Instance
        {
            get
            {
                if (instance == null)
                {
                    var instanceObject = new GameObject("FakeHttpRequester");
                    DontDestroyOnLoad(instanceObject);

                    instance = instanceObject.AddComponent<FakeHttpRequester>();
                }

                return instance;
            }
        }

        public DailyQuestResponse LoadedDailyQuestResponse
        {
            private get;
            set;
        }
        public Func<DailyMissionPointClaimResponse> LoadedDailyMissionPointClaimResponse
        {
            private get;
            set;
        }
        public Func<DailyMissionItemClaimResponse> LoadedDailyMissionItemClaimResponse
        {
            private get;
            set;
        }
        public DailyBonusClaimResponse LoadedDailyBonusClaimResponse
        {
            private get;
            set;
        }
        public Func<ClamHarvestResponse> LoadedClamHarvestResponse
        {
            private get;
            set;
        }
        public GameSpinResponse LoadedGameSpinResponse
        {
            private get;
            set;
        }
        public GameEnterResponse LoadedGameEnterResponse
        {
            private get;
            set;
        }
        public Func<CasinoBonusResponse> LoadedCasinoBonusResponse
        {
            private get;
            set;
        }
        public Func<OceansPassResponse> LoadedOceanPassResponse
        {
            private get;
            set;
        }
        public Func<ClamHarvestClamType, int, HarvestResponse> LoadedHarvestResponse
        {
            private get;
            set;
        }
        public Func<RewardType, int, PurchaseResponse> LoadedPurchasePickaxResponse
        {
            private get;
            set;
        }
        public Func<string, int, PurchaseResponse> LoadedPurchaseCoinResponse
        {
            private get;
            set;
        }
        public Func<OfferInfo, PurchaseResponse> LoadedPurchaseOfferResponse
        {
            private get;
            set;
        }
        public Func<ClientResponse> LoadedPurchaseMissionPassResponse
        {
            private get;
            set;
        }
        public Func<ShopResponse> LoadedShopResponse
        {
            private get;
            set;
        }
        public ProfileResponse LoadedProfileResponse
        {
            private get;
            set;
        }
        public OfferResponse LoadedOfferResponse
        {
            private get;
            set;
        }

        public OfferResponse LoadedOfferBuyResponse
        {
            private get;
            set;
        }

        public Func<UnityAdsNextResponse> LoadedUnityAdsNextResponse
        {
            private get;
            set;
        }

        public UnityAdsClaimResponse LoadedUnityAdsClaimResponse
        {
            private get;
            set;
        }

        public AdminEventResponse LoadedAdminEventResponse
        {
            private get;
            set;
        }

        public Func<MissionPassClaimAllResponse> LoadedMissionPassClaimAllPreviewResponse
        {
            private get;
            set;
        }

        public Func<MissionPassClaimAllResponse> LoadedMissionPassClaimAllResponse
        {
            private get;
            set;
        }

        public Func<int, int, MissionPassClaimResponse> LoadedMissionPassClaimResponse
        {
            private get;
            set;
        }

        public Func<NotiResponse> LoadedNotiResponse
        {
            private get;
            set;
        }
        
        public Func<MissionResponse> LoadedMissionResponse
        {
            private get;
            set;
        }

        public Func<long, long, ClapResponse> LoadedClapResponse
        {
            private get;
            set;
        }

        public Func<int, AquaBlitzClaimResponse> LoadedAquaBlitzClaimResponse
        {
            private get;
            set;
        }
        
        public Func<int, AquaBlitzClaimResponse> LoadedAquaBlitzMissionClaimResponse
        {
            private get;
            set;
        }

        public Func<UserCoreResponse> LoadedUserCore
        {
            private get;
            set;
        }

        public VipResetResponse LoadedVipReset
        {
            private get;
            set;
        }

        private static FakeHttpRequester instance;
        private float fakeDelay = 0.1f;

        private FakeRequest<T> FakeLoad<T>(Func<T> FakeResponse, Action<T> onComplete = null) where T : ClientResponse
        {
            var req = new FakeRequest<T>();
            if (FakeResponse != null)
            {
                req.LoadResponse(FakeResponse());
            }

            StartCoroutine(FakeLoadCoroutine(req, onComplete));
            return req;
        }

        private FakeRequest<T> FakeLoad<T>(T fakeResponse, Action<T> onComplete = null) where T : ClientResponse
        {
            var req = new FakeRequest<T>();
            req.LoadResponse(fakeResponse);

            StartCoroutine(FakeLoadCoroutine(req, onComplete));
            return req;
        }

        private IEnumerator FakeLoadCoroutine<T>(FakeRequest<T> req, Action<T> onComplete) where T : ClientResponse
        {
            yield return new WaitForSeconds(fakeDelay);
            req.UpdateData();
        }

        public FakeRequest<DailyQuestResponse> DailyQuest(Action<DailyQuestResponse> onComplete = null)
        {
            var req = new FakeRequest<DailyQuestResponse>();
            req.LoadResponse(LoadedDailyQuestResponse);

            StartCoroutine(FakeLoadCoroutine("", req, onComplete));
            return req;
        }

        public FakeRequest<DailyMissionPointClaimResponse> DailyMissionPointClaim(Action<DailyMissionPointClaimResponse> onComplete = null)
        {
            var req = new FakeRequest<DailyMissionPointClaimResponse>();
            req.LoadResponse(LoadedDailyMissionPointClaimResponse());

            StartCoroutine(FakeLoadCoroutine("weekly_reward_claim", req, onComplete));
            return req;
        }

        public FakeRequest<DailyMissionItemClaimResponse> DailyMissionItemClaim(Action<DailyMissionItemClaimResponse> onComplete = null)
        {
            var req = new FakeRequest<DailyMissionItemClaimResponse>();
            req.LoadResponse(LoadedDailyMissionItemClaimResponse());

            StartCoroutine(FakeLoadCoroutine("daily_quest_claim", req, onComplete));
            return req;
        }

        public FakeRequest<DailyBonusClaimResponse> DailyBonusClaim(Action<DailyBonusClaimResponse> onComplete = null)
        {
            var req = new FakeRequest<DailyBonusClaimResponse>();
            req.LoadResponse(LoadedDailyBonusClaimResponse);

            StartCoroutine(FakeLoadCoroutine("daily_bonus_claim", req, onComplete));
            return req;
        }

        public FakeRequest<ClamHarvestResponse> ClamHarvest(Action<ClamHarvestResponse> onComplete = null)
        {
            var req = new FakeRequest<ClamHarvestResponse>();
            req.LoadResponse(LoadedClamHarvestResponse());

            StartCoroutine(FakeLoadCoroutine("", req, onComplete));
            return req;
        }

        public FakeRequest<GameSpinResponse> GameSpin(Action<GameSpinResponse> onComplete = null)
        {
            var req = new FakeRequest<GameSpinResponse>();
            req.LoadResponse(LoadedGameSpinResponse);

            StartCoroutine(FakeLoadCoroutine("spin", req, onComplete));
            return req;
        }

        public FakeRequest<GameEnterResponse> GameEnter(Action<GameEnterResponse> onComplete = null)
        {
            var req = new FakeRequest<GameEnterResponse>();
            req.LoadResponse(LoadedGameEnterResponse);

            StartCoroutine(FakeLoadCoroutine("enter", req, onComplete));
            return req;
        }

        public FakeRequest<CasinoBonusResponse> CasinoBonus(Action<CasinoBonusResponse> onComplete = null)
        {
            return FakeLoad("casino_bonus", LoadedCasinoBonusResponse, onComplete);
        }

        public FakeRequest<OceansPassResponse> OceanPass(Action<OceansPassResponse> onComplete = null)
        {
            return FakeLoad("", LoadedOceanPassResponse, onComplete);
        }

        public FakeRequest<HarvestResponse> Harvest(ClamHarvestClamType type, int index, Action<HarvestResponse> onComplete = null)
        {
            var req = new FakeRequest<HarvestResponse>();
            req.LoadResponse(LoadedHarvestResponse(type, index));

            StartCoroutine(FakeLoadCoroutine($"{type}_harvest", req, onComplete));
            return req;
        }

        public FakeRequest<PurchaseResponse> PurchasePickax(RewardType type, int value, Action<PurchaseResponse> onComplete = null)
        {
            var req = new FakeRequest<PurchaseResponse>();
            req.LoadResponse(LoadedPurchasePickaxResponse(type, value));

            StartCoroutine(FakeLoadCoroutine("purchase_pickax", req, onComplete));
            return req;
        }

        public FakeRequest<PurchaseResponse> PurchaseCoin(string itemID,
                                                          int couponIndex,
                                                          Action<PurchaseResponse> onComplete = null)
        {
            var req = new FakeRequest<PurchaseResponse>();
            req.LoadResponse(LoadedPurchaseCoinResponse(itemID, couponIndex));

            StartCoroutine(FakeLoadCoroutine("purchase_coin", req, onComplete));
            return req;
        }

        public FakeRequest<PurchaseResponse> PurchaseOffer(OfferInfo offerInfo,
                                                           Action<PurchaseResponse> onComplete = null)
        {
            var req = new FakeRequest<PurchaseResponse>();
            req.LoadResponse(LoadedPurchaseOfferResponse(offerInfo));

            StartCoroutine(FakeLoadCoroutine("purchase_offer", req, onComplete));
            return req;
        }

        public FakeRequest<ClientResponse> PurchaseMissionPass(string itemID, Action<ClientResponse> onComplete = null)
        {
            var req = new FakeRequest<ClientResponse>();
            req.LoadResponse(LoadedPurchaseMissionPassResponse());

            StartCoroutine(FakeLoadCoroutine($"purchase_{itemID}", req, onComplete));
            return req;
        }

        public FakeRequest<ShopResponse> Shop(Action<ShopResponse> onComplete = null)
        {
            var req = new FakeRequest<ShopResponse>();
            req.LoadResponse(LoadedShopResponse());

            StartCoroutine(FakeLoadCoroutine("shop", req, onComplete));
            return req;
        }

        public FakeRequest<ProfileResponse> Profile(Action<ProfileResponse> onComplete = null)
        {
            var req = new FakeRequest<ProfileResponse>();
            req.LoadResponse(LoadedProfileResponse);

            StartCoroutine(FakeLoadCoroutine("profile", req, onComplete));
            return req;
        }

        public FakeRequest<OfferResponse> Offer(Action<OfferResponse> onComplete = null)
        {
            var req = new FakeRequest<OfferResponse>();
            req.LoadResponse(LoadedOfferResponse);

            StartCoroutine(FakeLoadCoroutine("offer", req, onComplete));
            return req;
        }

        public FakeRequest<OfferResponse> OfferBuy(Action<OfferResponse> onComplete = null)
        {
            var req = new FakeRequest<OfferResponse>();
            req.LoadResponse(LoadedOfferResponse);

            StartCoroutine(FakeLoadCoroutine("offer_buy", req, onComplete));
            return req;
        }

        public FakeRequest<UnityAdsNextResponse> UnityAdsNext(Action<UnityAdsNextResponse> onComplete = null)
        {
            var req = new FakeRequest<UnityAdsNextResponse>();
            req.LoadResponse(LoadedUnityAdsNextResponse());

            StartCoroutine(FakeLoadCoroutine("unity_ads_next", req, onComplete));
            return req;
        }

        public FakeRequest<UnityAdsClaimResponse> UnityAdsClaim(Action<UnityAdsClaimResponse> onComplete = null)
        {
            var req = new FakeRequest<UnityAdsClaimResponse>();
            req.LoadResponse(LoadedUnityAdsClaimResponse);

            StartCoroutine(FakeLoadCoroutine("unity_ads_claim", req, onComplete));
            return req;
        }

        public FakeRequest<AdminEventResponse> AdminEvent(Action<AdminEventResponse> onComplete = null)
        {
            var req = new FakeRequest<AdminEventResponse>();
            req.LoadResponse(LoadedAdminEventResponse);
            
            StartCoroutine(FakeLoadCoroutine("event", req, onComplete));
            return req;
        }
        
        public FakeRequest<MissionResponse> Mission(Action<MissionResponse> onComplete = null)
        {
            var req = new FakeRequest<MissionResponse>();
            req.LoadResponse(LoadedMissionResponse());

            StartCoroutine(FakeLoadCoroutine("mission", req, onComplete));
            return req;
        }

        public FakeRequest<NotiResponse> Noti(Action<NotiResponse> onComplete = null)
        {
            var req = new FakeRequest<NotiResponse>();
            req.LoadResponse(LoadedNotiResponse());

            StartCoroutine(FakeLoadCoroutine("notis", req, onComplete));
            return req;
        }

        public FakeRequest<ClapResponse> Clap(long uid, long ts, Action<ClapResponse> onComplete = null)
        {
            var req = new FakeRequest<ClapResponse>();
            req.LoadResponse(LoadedClapResponse(uid, ts));

            StartCoroutine(FakeLoadCoroutine("clap", req, onComplete));
            return req;
        }

        public FakeRequest<AquaBlitzClaimResponse> AquaBlitzPointClaim(int rewardIndex, Action<AquaBlitzClaimResponse> onComplete = null)
        {
            var req = new FakeRequest<AquaBlitzClaimResponse>();
            req.LoadResponse(LoadedAquaBlitzClaimResponse(rewardIndex));
            
            StartCoroutine(FakeLoadCoroutine("aqua_blitz_claim", req, onComplete));
            return req;
        }

        public FakeRequest<AquaBlitzClaimResponse> AquaBlitzMissionClaim(int missionIndex, Action<AquaBlitzClaimResponse> onComplete = null)
        {
            var req = new FakeRequest<AquaBlitzClaimResponse>();
            req.LoadResponse(LoadedAquaBlitzMissionClaimResponse(missionIndex));

            StartCoroutine(FakeLoadCoroutine("aqua_blitz_mission_claim", req, onComplete));
            return req;
        }

        public FakeRequest<MissionPassClaimAllResponse> MissionPassClaimAllPreview(Action<MissionPassClaimAllResponse> onComplete = null)
        {
            var req = new FakeRequest<MissionPassClaimAllResponse>();
            req.LoadResponse(LoadedMissionPassClaimAllPreviewResponse());

            StartCoroutine(FakeLoadCoroutine("mission_pass_claim_all_preview", req, onComplete));
            return req;
        }

        public FakeRequest<MissionPassClaimAllResponse> MissionPassClaimAll(Action<MissionPassClaimAllResponse> onComplete = null)
        {
            var req = new FakeRequest<MissionPassClaimAllResponse>();
            req.LoadResponse(LoadedMissionPassClaimAllResponse());

            StartCoroutine(FakeLoadCoroutine("mission_pass_claim_all", req, onComplete));
            return req;
        }

        public FakeRequest<MissionPassClaimResponse> MissionPassClaim(int step, int type, Action<MissionPassClaimResponse> onComplete = null)
        {
            var req = new FakeRequest<MissionPassClaimResponse>();
            req.LoadResponse(LoadedMissionPassClaimResponse(step, type));

            StartCoroutine(FakeLoadCoroutine("mission_pass_claim", req, onComplete));
            return req;
        }

        public FakeRequest<UserCoreResponse> UserCore(Action<UserCoreResponse> onComplete = null)
        {
            var req = new FakeRequest<UserCoreResponse>();
            req.LoadResponse(LoadedUserCore());

            StartCoroutine(FakeLoadCoroutine("user_core", req, onComplete));
            return req;
        }

        public FakeRequest<VipResetResponse> VipReset(Action<VipResetResponse> onComplete = null)
        {
            var req = new FakeRequest<VipResetResponse>();
            req.LoadResponse(LoadedVipReset);

            StartCoroutine(FakeLoadCoroutine("vip_reset", req, onComplete));
            return req;
        }

        private FakeRequest<T> FakeLoad<T>(string name, Func<T> FakeResponse, Action<T> onComplete = null) where T : ClientResponse
        {
            var req = new FakeRequest<T>();
            if (FakeResponse != null)
            {
                req.LoadResponse(FakeResponse());
            }

            StartCoroutine(FakeLoadCoroutine(name, req, onComplete));
            return req;
        }

        private IEnumerator FakeLoadCoroutine<T>(string name, FakeRequest<T> req, Action<T> onComplete) where T : ClientResponse
        {
            yield return new WaitForSeconds(fakeDelay);
            req.UpdateData();

            Debug.Log($"==== FakeLoad : {name}\njson: {JsonUtility.ToJson(req.data)}");

            onComplete?.Invoke(req.data);
        }
    }
}