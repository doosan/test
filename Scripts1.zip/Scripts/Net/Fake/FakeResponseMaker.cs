using Underc.Net.Client;

namespace Underc.Net
{
    public class FakeResponseMaker
    {
        private static long ts = 1;

        public static T New<T>() where T : ClientResponse, new()
        {
            T response = new T();
            response.ts = ts;
            ts += 1;
            return response;
        }
    }
}