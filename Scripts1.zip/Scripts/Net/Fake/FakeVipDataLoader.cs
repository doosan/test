using System;
using System.Collections;
using System.Collections.Generic;
using Underc.Net.Client;
using Underc.Popup;
using Underc.User;
using UnityEngine;

namespace Underc.Net
{
    public class FakeVipDataLoader : MonoBehaviour
    {
        public static FakeVipDataLoader Instance
        {
            get
            {
                if (instance == null)
                {
                    var instanceObject = new GameObject("FakeVipDataMaker");
                    GameObject.DontDestroyOnLoad(instanceObject);

                    instance = instanceObject.AddComponent<FakeVipDataLoader>();
                }

                return instance;
            }
        }
        private static FakeVipDataLoader instance;

        private List<ShopCoinData> shopCoinDatas;
        private List<ShopCouponItemData> shopCouponItemDatas;
        private ShopSaleData shopSaleData;
        private ProfileData profileData;

        public FakeVipDataLoader()
        {
            
        }

        public void SetupShopResponse()
        {
            FakeHttpRequester.Instance.LoadedShopResponse = () =>
            {
                var shopResponse = new ShopResponse();
                shopResponse.coin = shopCoinDatas.ToArray();
                if (shopSaleData != null)
                {
                    shopResponse.sale = shopSaleData;
                }
                if (shopCouponItemDatas != null)
                {
                    shopResponse.coupon = shopCouponItemDatas.ToArray();
                }
                shopResponse.best_index = 0;
                shopResponse.most_index = 3;

                VipClassType vipClass = MyInfo.VipClass.Type;
                float bonusRate = MyInfo.VipClass.GetCurrent_VipBenefitTableItemInfo(VipBenefitTableItem.CoinPackages).bonusRate;
                shopResponse.vip = MakeBenefitTableItemData(vipClass, bonusRate);

                return shopResponse;
            };
        }

        public void MakeShopSaleData()
        {
            shopSaleData = new ShopSaleData();
            shopSaleData.sale = 3;
            shopSaleData.end_dt = RemainingSeconds(60 * 60 * 24);
        }

        public void ResetShopMultipleDatas()
        {
            shopSaleData = null;
            shopCouponItemDatas = null;
        }

        private VipBenefitTableItemData MakeBenefitTableItemData(VipClassType vipClass, float bonusRate)
        {
            var shopVipData = new VipBenefitTableItemData();
            shopVipData.vip_class = vipClass.ToString();
            shopVipData.bonus_rate = bonusRate;
            return shopVipData;
        }

        public void MakeShopCouponDatas()
        {
            shopCouponItemDatas = new List<ShopCouponItemData>()
            {
                MakeShopCouponItemData(0, 100, "above20", RemainingSeconds(60 * 60), 1),
                MakeShopCouponItemData(1, 50, "all", RemainingSeconds(60 * 60 * 3), 3)
            };
        }

        protected long RemainingSeconds(long remainingSeconds)
        {
            DateTime now = DateTime.Now.ToLocalTime();
            TimeSpan span = (now - new DateTime(1970, 1, 1, 0, 0, 0, 0).ToLocalTime());
            long nowSeconds = (long)span.TotalSeconds;

            return nowSeconds + remainingSeconds;
        }

        private ShopCouponItemData MakeShopCouponItemData(int index,
                                                          int bonusRate,
                                                          string couponTarget,
                                                          long expireTime,
                                                          int cnt)
        {
            var shopCouponItemData = new ShopCouponItemData();
            shopCouponItemData.index = index;
            shopCouponItemData.bonus_rate = bonusRate;
            shopCouponItemData.coupon_target = couponTarget;
            shopCouponItemData.expire_time = expireTime;
            shopCouponItemData.cnt = cnt;
            return shopCouponItemData;
        }

        public void MakeShopCoinDatas()
        {
            shopCoinDatas = new List<ShopCoinData>()
            {
                MakeShopCoinData("shop.coins.100",
                                 5400,
                                 99.99f,
                                 2002600000,
                                 1001300000),
                MakeShopCoinData("shop.coins.50",
                                 2400,
                                 49.99f,
                                 667400000,
                                 333700000),
                MakeShopCoinData("shop.coins.20",
                                 840,
                                 19.99f,
                                 213500000,
                                 106750000),
                MakeShopCoinData("shop.coins.10",
                                 360,
                                 9.99f,
                                 86700000,
                                 43350000),
                MakeShopCoinData("shop.coins.5",
                                 150,
                                 4.99f,
                                 33300000,
                                 16650000),
                MakeShopCoinData("shop.coins.2",
                                 60,
                                 1.99f,
                                 9300000,
                                 4650000)
            };
        }

        private ShopCoinData MakeShopCoinData(string itemID,
                                              long vipPoint,
                                              float price,
                                              long coin,
                                              long vipBonus)
        {
            var shopCoinData = new ShopCoinData();
            shopCoinData.itemid = itemID;
            shopCoinData.vip_point = vipPoint;
            shopCoinData.price = price;
            shopCoinData.coin = coin;
            shopCoinData.vip_bonus = vipBonus;
            return shopCoinData;
        }

        public void SetupProfileResponse(ProfileData originData,
                                         long xp,
                                         long nextXp,
                                         VipClassType vipClass,
                                         VipResetData[] vipReset)
        {
            var profileData = new ProfileData();
            profileData.nick      = originData.nick;
            profileData.pic_num   = originData.pic_num;
            profileData.pic_url   = originData.pic_url;
            profileData.level     = originData.level;
            profileData.seas      = originData.seas;
            profileData.max_win   = originData.max_win;
            profileData.tot_win   = originData.tot_win;
            profileData.clap_sent = originData.clap_sent;

            _SetupProfileResponse(profileData, xp, nextXp, vipClass, vipReset);
        }

        public void SetupProfileResponse(
            long xp,
            long nextXp,
            VipClassType vipClass,
            VipResetData[] vipReset = null
        )
        {
            _SetupProfileResponse(new ProfileData(),
                                  xp,
                                  nextXp,
                                  vipClass,
                                  vipReset);
        }

        private void _SetupProfileResponse(
            ProfileData profileData,
            long xp, 
            long nextXp, 
            VipClassType vipClass, 
            VipResetData[] vipReset = null
        )
        {
            var vipData = new VipData();
            vipData.xp = xp;
            vipData.next_xp = nextXp;
            vipData.vip_class = (int)vipClass;

            var vipBenefitTableDatas = new VipBenefitTableData[7];
            for (int i = 0; i < 7; i++)
            {
                VipBenefitTableData vipBenefitData = null;
                switch (i)
                {
                    case 0:
                        vipBenefitData = MakeVipBenefitData(
                            coinPackages: 1f,
                            vipPoints: 1f,
                            dailyBonus: 1f,
                            hugeBonus: 1f,

                            dailyQuest: 1f,
                            harvest: 1f,
                            missionPass: 1f,

                            chest: 1f,
                            sea: 1f,
                            sharePostGift: 1f,
                            fanPageGift: 1f,
                            vipSupport: false
                        );
                        break;

                    case 1:
                        vipBenefitData = MakeVipBenefitData(
                            coinPackages: 1.3f,
                            vipPoints: 2f,
                            dailyBonus: 1.3f,
                            hugeBonus: 1.3f,

                            dailyQuest: 1.3f,
                            harvest: 1.3f,
                            missionPass: 1.3f,

                            chest: 1.3f,
                            sea: 1.3f,
                            sharePostGift: 1.3f,
                            fanPageGift: 1.3f,
                            vipSupport: false
                        );
                        break;

                    case 2:
                        vipBenefitData = MakeVipBenefitData(
                            coinPackages: 1.5f,
                            vipPoints: 3f,
                            dailyBonus: 1.5f,
                            hugeBonus: 1.5f,

                            dailyQuest: 1.5f,
                            harvest: 1.5f,
                            missionPass: 1.5f,

                            chest: 1.5f,
                            sea: 1.5f,
                            sharePostGift: 1.5f,
                            fanPageGift: 1.5f,
                            vipSupport: false
                        );
                        break;

                    case 3:
                        vipBenefitData = MakeVipBenefitData(
                            coinPackages: 2f,
                            vipPoints: 4f,
                            dailyBonus: 1.8f,
                            hugeBonus: 1.8f,

                            dailyQuest: 2f,
                            harvest: 2f,
                            missionPass: 2f,

                            chest: 1.8f,
                            sea: 1.8f,
                            sharePostGift: 1.8f,
                            fanPageGift: 1.8f,
                            vipSupport: false
                        );
                        break;

                    case 4:
                        vipBenefitData = MakeVipBenefitData(
                            coinPackages: 3f,
                            vipPoints: 5f,
                            dailyBonus: 2.5f,
                            hugeBonus: 2.5f,

                            dailyQuest: 3f,
                            harvest: 3f,
                            missionPass: 3f,

                            chest: 2.5f,
                            sea: 2.5f,
                            sharePostGift: 2.5f,
                            fanPageGift: 2.5f,
                            vipSupport: true
                        );
                        break;

                    case 5:
                        vipBenefitData = MakeVipBenefitData(
                            coinPackages: 4f,
                            vipPoints: 6f,
                            dailyBonus: 3f,
                            hugeBonus: 3f,

                            dailyQuest: 4f,
                            harvest: 4f,
                            missionPass: 4f,

                            chest: 3f,
                            sea: 3f,
                            sharePostGift: 3f,
                            fanPageGift: 3f,
                            vipSupport: true
                        );
                        break;

                    case 6:
                        vipBenefitData = MakeVipBenefitData(
                            coinPackages: 7f,
                            vipPoints: 7f,
                            dailyBonus: 5f,
                            hugeBonus: 5f,

                            dailyQuest: 7f,
                            harvest: 7f,
                            missionPass: 7f,

                            chest: 5f,
                            sea: 5f,
                            sharePostGift: 5f,
                            fanPageGift: 5f,
                            vipSupport: true
                        );
                        break;
                }

                vipBenefitTableDatas[i] = vipBenefitData;
            }

            var vipBenefitTableType = new VipBenefitTableTypeData();
            vipBenefitTableType.shop_type = "per";
            vipBenefitTableType.vip_type = "mul";
            vipBenefitTableType.daily_type = "per";
            vipBenefitTableType.congrats_type = "mul";
            vipBenefitTableType.daily_quest_type = "per";
            vipBenefitTableType.harvest_type = "mul";
            vipBenefitTableType.mission_pass_type = "per";
            vipBenefitTableType.chest_type = "mul";
            vipBenefitTableType.sea_type = "per";
            vipBenefitTableType.share_post_type = "mul";
            vipBenefitTableType.fan_page_type = "per";

            profileData.vip = vipData;
            profileData.vip_benefit = vipBenefitTableDatas;
            profileData.vip_rate_type = vipBenefitTableType;
            profileData.vip_reset = vipReset;

            var profileResponse = new ProfileResponse();
            profileResponse.data = profileData;

            FakeHttpRequester.Instance.LoadedProfileResponse = profileResponse;
        }

        private VipBenefitTableData MakeVipBenefitData(float coinPackages,
                                                       float vipPoints,
                                                       float dailyBonus,
                                                       float hugeBonus,
                                                       float dailyQuest,
                                                       float harvest,
                                                       float missionPass,
                                                       float chest,
                                                       float sea,
                                                       float sharePostGift,
                                                       float fanPageGift,
                                                       bool vipSupport)
        {
            var vipBenefitData = new VipBenefitTableData();
            vipBenefitData.coin_packages = coinPackages;
            vipBenefitData.vip_points = vipPoints;
            vipBenefitData.daily_bonus = dailyBonus;
            vipBenefitData.huge_bonus = hugeBonus;
            vipBenefitData.daily_quest = dailyQuest;
            vipBenefitData.harvest = harvest;
            vipBenefitData.mission_pass = missionPass;
            vipBenefitData.chest = chest;
            vipBenefitData.sea = sea;
            vipBenefitData.share_post_gift = sharePostGift;
            vipBenefitData.fan_page_gift = fanPageGift;
            vipBenefitData.vip_support = vipSupport;
            return vipBenefitData;
        }

        public IEnumerator LoadProfile()
        {
            Popups.ShowLoading();
            IRequest<ProfileResponse> req = FakeHttpRequester.Instance.Profile();
            yield return req.WaitForResponse();
            Popups.HideLoading();

            if (req.isSuccess)
            {
                ProfileData profileData = req.data.data;
                MyInfo.VipClass.Update(profileData.vip, profileData.vip_reset, profileData.vip_benefit, profileData.vip_rate_type);
            }
        }
    }
}