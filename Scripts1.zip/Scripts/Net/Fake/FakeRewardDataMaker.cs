using System;
using System.Collections.Generic;
using System.Linq;
using Underc.User;
using UnityEngine;

namespace Underc.Net
{
    public class FakeRewardData
    {
        public RewardType type;
        public long value;

        public FakeRewardData(RewardType type, long value)
        {
            this.type = type;
            this.value = value;
        }
    }

    public class FakeRewardDataMaker : MonoBehaviour
    {
        public static FakeRewardDataMaker Instance
        {
            get
            {
                if (instance == null)
                {
                    var instanceObject = new GameObject("FakeRewardDataMaker");
                    GameObject.DontDestroyOnLoad(instanceObject);

                    instance = instanceObject.AddComponent<FakeRewardDataMaker>();
                }

                return instance;
            }
        }
        private static FakeRewardDataMaker instance;

        private List<Func<FakeRewardData>> commonDataMakers;
        private List<Func<FakeRewardData>> clonedDataMakers;
        private Dictionary<RewardType, Func<FakeRewardData>> specificDataMakers;

        public FakeRewardDataMaker()
        {
            commonDataMakers = new List<Func<FakeRewardData>>();
            commonDataMakers.Add(() => GetCoinData());      // coin
            commonDataMakers.Add(() => GetFishData());      // fish
            commonDataMakers.Add(() => GetXpBoosterData()); // xp_booster
            commonDataMakers.Add(() => GetGoldenData());    // golden
            commonDataMakers.Add(() => GetObsidianData());  // obsidian

            clonedDataMakers = new List<Func<FakeRewardData>>();

            specificDataMakers = new Dictionary<RewardType, Func<FakeRewardData>>();
            specificDataMakers.Add(RewardType.coin, () => GetCoinData());
            specificDataMakers.Add(RewardType.pearl, () => GetPearlData());
            specificDataMakers.Add(RewardType.ticket, () => GetTicketData());
            specificDataMakers.Add(RewardType.obsidian, () => GetObsidianData());
            specificDataMakers.Add(RewardType.golden, () => GetGoldenData());
            specificDataMakers.Add(RewardType.fish, () => GetFishData());
        }

        public List<FakeRewardData> GetCommonRewards(int count)
        {
            return MakeRandomRewards(count);
        }

        public List<FakeRewardData> GetSpecificRewards(List<RewardType> rewardTypes)
        {
            List<FakeRewardData> rewardDatas = new List<FakeRewardData>();
            foreach (RewardType rewardType in rewardTypes)
            {
                rewardDatas.Add(specificDataMakers[rewardType]());
            }
            return rewardDatas;
        }

        public List<FakeRewardData> GetClamHarvestRewards(int count)
        {
            List<FakeRewardData> rewards = MakeRandomRewards(count);
            rewards.Add(GetMissionPassPointData());
            return rewards;
        }

        public List<FakeRewardData> GetDailyMissionRewards(int count)
        {
            List<FakeRewardData> rewards = MakeRandomRewards(count);
            rewards.Add(GetMissionPassPointData());
            rewards.Add(GetDailyMissionPointData());
            rewards.Add(GetGoldPickaxData());
            return rewards;
        }

        public List<long> GetMissionPassPoints(int count)
        {
            List<long> passPoints = new List<long>();
            for (int i = 0; i < count; i++)
            {
                passPoints.Add(GetMissionPassPointData().value);
            }
            return passPoints;
        }

        public List<FakeRewardData> GetHarvestRewards(int count)
        {
            List<FakeRewardData> rewards = MakeRandomRewards(count, RewardType.coin);
            rewards.Add(GetMissionPassPointData());
            rewards.Insert(0, GetCoinData());

            return rewards;
        }

        private List<FakeRewardData> MakeRandomRewards(int count, params RewardType[] exceptTypes)
        {
            clonedDataMakers.Clear();
            clonedDataMakers.AddRange(commonDataMakers);

            List<FakeRewardData> rewardDatas = new List<FakeRewardData>();
            for (int i = 0; i < count; i++)
            {
                if (clonedDataMakers.Count == 0)
                {
                    break;
                }

                int limit = 10;
                while (limit > 0)
                {
                    int randomIndex = UnityEngine.Random.Range(0, clonedDataMakers.Count);
                    FakeRewardData randomRewardData = clonedDataMakers[randomIndex]();
                    if (exceptTypes == null 
                        || exceptTypes.Contains(randomRewardData.type) == false)
                    {
                        clonedDataMakers.RemoveAt(randomIndex);
                        rewardDatas.Add(randomRewardData);
                        break;
                    }

                    limit -= 1;
                }
            }
            return rewardDatas;
        }

        private FakeRewardData GetCoinData()
        {
            return new FakeRewardData(RewardType.coin, UnityEngine.Random.Range(10000, 1000001));
        }

        private FakeRewardData GetPearlData()
        {
            return new FakeRewardData(RewardType.pearl, UnityEngine.Random.Range(10000, 1000001));
        }

        private FakeRewardData GetTicketData()
        {
            return new FakeRewardData(RewardType.ticket, UnityEngine.Random.Range(10000, 1000001));
        }

        private FakeRewardData GetGoldenData()
        {
            return new FakeRewardData(RewardType.golden, UnityEngine.Random.Range(1, 4));
        }

        private FakeRewardData GetObsidianData()
        {
            return new FakeRewardData(RewardType.obsidian, UnityEngine.Random.Range(1, 4));
        }

        private FakeRewardData GetXpBoosterData()
        {
            return new FakeRewardData(RewardType.xp_booster, UnityEngine.Random.Range(60, 2401));
        }

        private FakeRewardData GetGoldPickaxData()
        {
            return new FakeRewardData(RewardType.g_pickaxe, 1);
        }

        private FakeRewardData GetFishData()
        {
            MyOceanBook oceanBook = MyInfo.Ocean.Book;
            int randomIndex = UnityEngine.Random.Range(0, oceanBook.GetBookInfoCount(SeaItemType.f));
            BaseBookInfo fishBookInfo = oceanBook.GetBookInfoAtIndex(SeaItemType.f, randomIndex);
            return new FakeRewardData(RewardType.fish, fishBookInfo.ID);
        }

        private FakeRewardData GetMissionPassPointData()
        {
            return new FakeRewardData(RewardType.mp_point, UnityEngine.Random.Range(1, 1000));
        }

        private FakeRewardData GetDailyMissionPointData()
        {
            return new FakeRewardData(RewardType.weekly_point, UnityEngine.Random.Range(1, 1000));
        }
    }
}