using UnityEngine;
using Gaga.System;
using System.Collections;
using System.Collections.Generic;
using Gaga.AssetBundle;

namespace Underc.Net
{
    public sealed class DownloadMonitor : GameObjectSingleton<DownloadMonitor>
    {
        private class Task
        {
            public string uri;
            public float elapsedTime;
            public bool enableCheckpoint;
        }

        private readonly string STATE_START             = "start";
        private readonly string STATE_CHECKPOINT        = "progress";
        private readonly string STATE_SUCCESS           = "success";
        private readonly string STATE_FAILURE           = "failure";

        private ObjectPool<Task> objectPool;
        private bool isInit = false;
        private float checkpointTime;
        private List<Task> taskList;
        private Coroutine updateTimeCoroutine;

		/// <param name="checkpointTime"> 해당 값(초)에 다운로드 경과시간이 지나면 로그를 보냄. </param>
        public void Initialize(float checkpointTime)
        {
            if (isInit)
            {
                return;
            }

            isInit = true;

            this.checkpointTime = checkpointTime;
            taskList = new List<Task>();

            objectPool = new ObjectPool<Task>(5
                                              ,() =>
                                              {
                                                  return new Task();
                                              });

            DownloadSystem.Instance.OnStart += OnStartHandler;
            DownloadSystem.Instance.OnSuccess += OnSuccessHandler;
            DownloadSystem.Instance.OnFail += OnFailHandler;

            AssetBundleSystem.Instance.OnStart += OnStartHandler;
            AssetBundleSystem.Instance.OnSuccess += OnSuccessHandler;
            AssetBundleSystem.Instance.OnFail += OnFailHandler;
        }

        private Task AddTask(string uri)
        {
            var task = GetTask(uri);

            if (task == null)
            {
                task = objectPool.Get();
                task.uri = uri;
                task.elapsedTime = 0;
                task.enableCheckpoint = true;

                taskList.Add(task);

                return task;
            }

            return null;
        }

        private bool RemoveTask(string uri)
        {
            var task = GetTask(uri);

            if (task != null)
            {
                taskList.Remove(task);
                objectPool.Return(task);

                return true;
            }

            return false;
        }

        private void RemoveTaskWithSendLog(string uri, string state)
        {
            var task = GetTask(uri);

            if (task != null)
            {
                var elapsedTime = task.elapsedTime;

                if (RemoveTask(uri))
                {
                    SendLog(uri, elapsedTime, state);
                }
            }
        }

        private void OnStartHandler(string uri)
        {
            OnStartHandler(uri, false);
        }

        private void OnStartHandler(string uri, bool alreadyDownloaded)
        {
            if (alreadyDownloaded)
            {
                return;
            }

            var task = AddTask(uri);

            if (task != null)
            {
                SendLog(task.uri, task.elapsedTime, STATE_START);
            }

            if (updateTimeCoroutine == null)
            {
                updateTimeCoroutine = StartCoroutine(UpdateTime());
            }
        }

        private void OnSuccessHandler(string uri)
        {
            RemoveTaskWithSendLog(uri, STATE_SUCCESS);
        }

        private void OnFailHandler(string uri)
        {
            RemoveTaskWithSendLog(uri, STATE_FAILURE);
        }

        private void OnCheckpointHandler(string uri)
        {
            RemoveTaskWithSendLog(uri, STATE_CHECKPOINT);
        }

        private void SendLog(string uri, float elapsedTime, string state)
        {
            Debug.LogFormat("Download Monitor - task count : {0} , uri : {1} , elapsed time : {2} , state : {3}", taskList.Count, uri, elapsedTime, state);
            UndercGameLog.Fobis.ResourcesDownload(uri, elapsedTime, state);
        }

        private IEnumerator UpdateTime()
        {
            var waitForSecond = new WaitForSeconds(0.1f);

            while (taskList.Count > 0)
            {
                yield return waitForSecond;

                for (int i = 0; i < taskList.Count; i++)
                {
                    var task = taskList[i];
                    task.elapsedTime += 0.1f;

                    if (task.elapsedTime >= checkpointTime && task.enableCheckpoint)
                    {
                        task.enableCheckpoint = false;
                        SendLog(task.uri, task.elapsedTime, STATE_CHECKPOINT);
                    }
                }
            }
            
            updateTimeCoroutine = null;
        }

        private Task GetTask(string uri)
        {
            for (int i = 0; i < taskList.Count; i++)
            {
                var task = taskList[i];

                if (task.uri == uri)
                {
                    return task;
                }
            }

            return null;
        }
    }
}