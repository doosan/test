namespace Underc.Net
{
    public static class Address 
    {
#if REAL
        private const string NAME                       = "Real";
        private const string PROTOCOL                   = "https";
        private const string IP                         = "live.aquuuacasino.com";
        private const string PORT                       = "443";
        private const string ID_API                     = "api";

        private const string PROTOCOL_ASSETBUNDLES      = "https";
        private const string IP_ASSETBUNDLES            = "aquuua-real.azureedge.net";
        private const string PORT_ASSETBUNDLES          = "443";
        private const string ID_ASSETBUNDLES            = "assetbundles";
#elif QA
        private const string NAME                       = "QA";
        private const string PROTOCOL                   = "https";
        private const string IP                         = "qa.aquuuacasino.com";
        private const string PORT                       = "10090";
        private const string ID_API                     = "api";
        
        private const string PROTOCOL_ASSETBUNDLES      = "https";
        private const string IP_ASSETBUNDLES            = "aquuua-real.azureedge.net";
        private const string PORT_ASSETBUNDLES          = "443";
        private const string ID_ASSETBUNDLES            = "assetbundlesqa";
#elif STAGE
        private const string NAME                       = "STAGE";
        private const string PROTOCOL                   = "https";
        private const string IP                         = "qa.aquuuacasino.com";
        private const string PORT                       = "443";
        private const string ID_API                     = "api";
        
        private const string PROTOCOL_ASSETBUNDLES      = "https";
        private const string IP_ASSETBUNDLES            = "aquuua-real.azureedge.net";
        private const string PORT_ASSETBUNDLES          = "443";
        private const string ID_ASSETBUNDLES            = "assetbundlesstage";
#else
        private const string NAME                       = "Dev";
        private const string PROTOCOL                   = "https";
        private const string IP                         = "dev.aquuuacasino.com";
        private const string PORT                       = "443";
        private const string ID_API                     = "api";

        private const string PROTOCOL_ASSETBUNDLES      = "https";
        private const string IP_ASSETBUNDLES            = "dev.aquuuacasino.com";
        private const string PORT_ASSETBUNDLES          = "443";
        private const string ID_ASSETBUNDLES            = "asset_bundles";
#endif

        private const string URI_FORMAT                 = "{0}://{1}:{2}/{3}";

        private static string forceURI;

        public static void SetForceURI(string uri)
        {
            if (string.IsNullOrEmpty(uri) == false)
            {
                forceURI = uri;
            }
        }

        private static bool UseForceURI
        {
            get
            {
                return string.IsNullOrEmpty(forceURI) == false;
            }
        }

#if DEV
        private static readonly string KEY_USE_CUSTOM_URI                = "key_dev_use_custom_uri";
        private static readonly string KEY_LATEST_SERVER_IP              = "key_dev_latest_ip";
        private static readonly string KEY_LATEST_SERVER_PORT            = "key_dev_latest_port";

        public static bool UseCustomURI
        {
            get
            {
                return UndercPrefs.GetLocalValue(KEY_USE_CUSTOM_URI, 0) == 1;
            }
            set
            {
                UndercPrefs.SetLocalValue(KEY_USE_CUSTOM_URI, value ? 1 : 0);
            }
        }

        public static string CustomIP
        {
            get
            {
                return UndercPrefs.GetLocalValue(KEY_LATEST_SERVER_IP, "");
            }
            set
            {
                UndercPrefs.SetLocalValue(KEY_LATEST_SERVER_IP, value);
            }
        }

        public static string CustomPort
        {
            get
            {
                return UndercPrefs.GetLocalValue(KEY_LATEST_SERVER_PORT, "");
            }
            set
            {
                UndercPrefs.SetLocalValue(KEY_LATEST_SERVER_PORT, value);
            }
        }

        private const string CUSTOM_NAME                = "Custom";
        private const string CUSTOM_PROTOCOL            = "https";

#endif

        public static string API
        {
            get
            {
                return "https://dev.aquuuacasino.com:8086/api";

                if (UseForceURI)
                {
                    return forceURI;
                }
#if DEV
                if (UseCustomURI)
                {
                    return MakeURI(CUSTOM_PROTOCOL, CustomIP, CustomPort, ID_API);
                }
#endif
                return MakeURI(PROTOCOL, IP, PORT, ID_API);
            }
        }

        public static string CDN_ASSETBUNDLES
        {
            get
            {
#if DEV
                if (UseCustomURI)
                {
                    return MakeURI(CUSTOM_PROTOCOL, CustomIP, CustomPort, ID_ASSETBUNDLES);
                }
#endif
                return MakeURI(PROTOCOL_ASSETBUNDLES, IP_ASSETBUNDLES, PORT_ASSETBUNDLES, ID_ASSETBUNDLES);
            }
        }

        public static string SERVER_NAME
        {
            get
            {
#if DEV
                if (UseCustomURI)
                {
                    return CUSTOM_NAME;
                }
#endif
                return NAME;
            }
        }

        private static string MakeURI(string protocol, string ip, string port, string id)
        {
           return string.Format(System.Globalization.CultureInfo.InvariantCulture, URI_FORMAT, protocol, ip, port, id);
        }
    }
}