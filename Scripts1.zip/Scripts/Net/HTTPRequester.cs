using Underc.Net.Client;
using UnityEngine;
using System;
using Underc.User;
using System.Collections;
using System.Collections.Generic;
using static Underc.Net.Client.RestClient;

namespace Underc.Net
{
    public sealed class HTTPRequester : MonoBehaviour
    {
        private RestClient client;
        private Hashtable cachedBody;

        private void Awake()
        {
            client = gameObject.AddComponent<RestClient>();
            client.onErrorLogOccurred += OnErrorLogOccurredHandler;

            cachedBody = new Hashtable(); 
        }

        private void OnErrorLogOccurredHandler(string log)
        {
            ErrorLog(log);
        }

        public void SetDefaultMessages(long userID, string sessID)
        {
            client.ClearDefaultMessages();
            client.AddDefaultMessage("userid", userID);
            client.AddDefaultMessage("sessid", sessID);
        }

        private Hashtable GetBody()
        {
            cachedBody.Clear();
            cachedBody["pos"] = MyInfo.Position;
            cachedBody["store"] = AppService.StoreIntValue;
            return cachedBody;
        }

        private void SetCommonLog(Hashtable body)
        {
            var epochReq = new epoch.Client.Util.EpochHttpRequests();
            var jsonStr = epochReq.ToString().Replace("body=", "");
            var logDic = PlayFab.Json.PlayFabSimpleJson.DeserializeObject(jsonStr, typeof(Dictionary<string, string>)) as Dictionary<string, string>;

            body["device_model"] = logDic["I_DeviceModel"];
            body["country"] = logDic["I_CountryCD"];
            body["ver"] = logDic["I_GameVersion"];
#if UNITY_EDITOR
            body["os"] = 1;
#else
            body["os"] = int.Parse(logDic["I_OS"]);
#endif
            body["os_ver"] = logDic["I_DeviceOSVersion"];
            body["tz"] = AppService.GetLocalTimeZone();
            body["sdk_ver"] = logDic["I_SDKVersion"];
            body["channel"] = logDic["I_ChannelType"];
#if UNITY_ANDROID || UNITY_IOS || UNITY_IPHONE
            body["adid"] = logDic["I_PlatformADID"];
#endif
        }

        private Request<ClientResponse> ErrorLog(string error, Action<ClientResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "log";
            body["data"] = error;

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT, 0, false);
        }

        public Request<RegisterResponse> Register(Action<RegisterResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "register";
            body["device_id"] = MyInfo.UUID;
            SetCommonLog(body);

            return client.Post(Address.API, body, onComplete);
        }

        public Request<LoginResponse> Login(string pfSessionTicket, bool isRevoke = false, Action<LoginResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "login";
            body["device_id"] = MyInfo.UUID;
            body["pf_sess"] = pfSessionTicket;
            body["ab_ver"] = Resources.Load<Build.AssetBundleVersion>("AssetBundleVersion").Version;
            if (isRevoke)
            {
                body["revoke"] = isRevoke;
            }

            DeepLinkSystem.Instance.LogActivatingStatus();

            var route = 1;
            var routeValue = 0;

            if (DeepLinkSystem.Instance.IsActivateByFacebook == true)
            {
                route = 2;
                routeValue = DeepLinkSystem.Instance.FacebokID;
            }
            else if (DeepLinkSystem.Instance.IsActivateByNotification == true)
            {
                route = 3;
                routeValue = DeepLinkSystem.Instance.NotificiatinoID;
            }

            DeepLinkSystem.Instance.ResetActivateData();

            body["route"] = route;
            body["route_value"] = routeValue;

            SetCommonLog(body);

            return client.Post(Address.API, body, onComplete);
        }

        public Request<ClientResponse> UserSet(string key, string value, Action<ClientResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "user_set";
            body["key"] = key;
            body["value"] = value;

            return client.Post(Address.API, body, onComplete);
        }

        public Request<GetSettingResponse> GetAllSettings(Action<GetSettingResponse> onComplete = null)
        {
            return GetSettings(null, onComplete);
        }

        public Request<GetSettingResponse> GetSettings(string[] keys, Action<GetSettingResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "user_get";
            if (keys == null)
            {
                keys = new string[0];
            }
            body["keys"] = keys;

            return client.Post(Address.API, body, onComplete);
        }

        public Request<GetSettingResponse> GetSetting(string key, Action<GetSettingResponse> onComplete = null)
        {
            return GetSettings(new string[]{key}, onComplete);
        }

        public Request<UserCoreResponse> UserCore(Action<UserCoreResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "user_core";

            return client.Post(Address.API, body, onComplete);
        }

        public Request<UserCoreResponse> UserCoreWithAlarms(Action<UserCoreResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "user_core";
            body["alarms"] = new string[]{"inbox"};

            return client.Post(Address.API, body, onComplete);
        }

        public Request<NotiResponse> Noti(Action<NotiResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "notis";

            return client.Post(Address.API, body, onComplete);
        }

        public Request<ClapResponse> Clap(long uid, long ts, Action<ClapResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "clap";
            body["uid"] = uid;
            body["ts"] = ts;

            return client.Post(Address.API, body, onComplete);
        }

        public Request<ClapsResponse> Claps(long ts, Action<ClapsResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "claps";
            body["ts"] = ts;

            return client.Post(Address.API, body, onComplete);
        }

        public Request<SeaClearResponse> SeaClear(int seaID, Action<SeaClearResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "sea_clear";
            body["sea"] = seaID;

            return client.Post(Address.API, body, onComplete);
        }

        public Request<ClientResponse> SeaMove(int seaID, Action<ClientResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "sea_move";
            body["sea"] = seaID;

            return client.Post(Address.API, body, onComplete);
        }

        public Request<SeaListResponse> SeaList(Action<SeaListResponse> onComplete = null)
        {
            Hashtable body = GetBody();
            body["req"] = "sea_list";

            return client.Post(Address.API, body, onComplete);
        }

        public Request<SeaMineResponse> SeaMine(Action<SeaMineResponse> onComplete = null)
        {
            Hashtable body = GetBody();
            body["req"] = "sea_mine";

            return client.Post(Address.API, body, onComplete);
        }

        public Request<FishInfoResponse> FishInfo(int seaID, int fishID, Action<FishInfoResponse> onComplete = null)
        {
            Hashtable body = GetBody();
            body["req"] = "fish_info";
            body["sea"] = seaID;
            body["fish"] = fishID;

            return client.Post(Address.API, body, onComplete);
        }

        public Request<SeaItemBuyResponse> FishBuy(int id, int count, Action<SeaItemBuyResponse> onComplete = null)
        {
            Hashtable body = GetBody();
            body["req"] = "fish_buy";
            body["id"] = id;
            body["cnt"] = count;

            return client.Post(Address.API, body, onComplete);
        }

        public Request<SeaItemBuyResponse> SwimmerBuy(int id, Action<SeaItemBuyResponse> onComplete = null)
        {
            Hashtable body = GetBody();
            body["req"] = "swimmer_buy";
            body["id"] = id;

            return client.Post(Address.API, body, onComplete);
        }

        public Request<FishBookListResponse> FishBookList(Action<FishBookListResponse> onComplete = null)
        {
            Hashtable body = GetBody();
            body["req"] = "fish_list";
            body["update_ts"] = 0; /// 서버에 캐시된 데이터가 아니라, 항상 새로운 데이터를 요청한다.

            return client.Post(Address.API, body, onComplete);
        }

        public Request<SwimmerBookListResponse> SwimmerBookList(Action<SwimmerBookListResponse> onComplete = null)
        {
            Hashtable body = GetBody();
            body["req"] = "swimmer_list";
            body["update_ts"] = 0; /// 서버에 캐시된 데이터가 아니라, 항상 새로운 데이터를 요청한다.

            return client.Post(Address.API, body, onComplete);
        }

        public Request<ClientResponse> FishBookListUnlock(Action<ClientResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "fish_list_unlock";

            return client.Post(Address.API, body, onComplete);
        }

        public Request<SeaItemListResponse> SeaItemList(int seaID, bool includeUnplaced, Action<SeaItemListResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "item_list";
            body["sea"] = seaID;
            body["unplaced"] = includeUnplaced;

            return client.Post(Address.API, body, onComplete);
        }

        public Request<ClientResponse> SeaItemListUnlock(int seaID, Action<ClientResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "item_list_unlock";
            body["sea"] = seaID;

            return client.Post(Address.API, body, onComplete);
        }

        public Request<SeaItemMoveResponse> SeaItemMove(int seaID, 
                                                        string fishes, 
                                                        string fish_cnts, 
                                                        string swimmers, 
                                                        string swimmer_cnts, 
                                                        Action<SeaItemMoveResponse> onComplete = null)
        {
            var body = GetBody();  
            body["req"] = "item_move";
            body["sea"] = seaID;
            body["fishes"] = fishes;
            body["fish_cnts"] = fish_cnts;
            body["swimmers"] = swimmers;
            body["swimmer_cnts"] = swimmer_cnts;

            return client.Post(Address.API, body, onComplete);
        }

        public Request<StartBonusResponse> CollectStartBonus(Action<StartBonusResponse> onComplete = null)
        {
            var body = GetBody();  
            body["req"] = "start_bonus_claim";

            return client.Post(Address.API, body, onComplete);
        }

        public Request<QuestClamCollectResponse> CollectQuestClam(Action<QuestClamCollectResponse> onComplete = null)
        {
            var body = GetBody();  
            body["req"] = "quest_claim";

            return client.Post(Address.API, body, onComplete);
        }

        public Request<CollectSpinQuestResponse> CollectSpinQuest(Action<CollectSpinQuestResponse> onComplete = null)
        {
            var body = GetBody();  
            body["req"] = "spin_quest_claim";

            return client.Post(Address.API, body, onComplete);
        }

        public Request<UnityAdsCheckResponse> UnityAdsCheck(Action<UnityAdsCheckResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "unity_ads_check";

            return client.Post(Address.API, body, onComplete);
        }

        public Request<UnityAdsNextResponse> UnityAdsNext(Action<UnityAdsNextResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "unity_ads_next";

            return client.Post(Address.API, body, onComplete);
        }

        public Request<UnityAdsClaimResponse> UnityAdsClaim(Action<UnityAdsClaimResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "unity_ads_claim";

            return client.Post(Address.API, body, onComplete);
        }

        public Request<GetAssetFileResponse> GetAssetFile(string platformName /* android | ios */, Action<GetAssetFileResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "get_asset_file";
            body["platform"] = platformName.ToString();
            body["client_version"] = Application.version;

            return client.Post(Address.API, body, onComplete);
        }

        public Request<SlotListResponse> SlotList(string sort, Action<SlotListResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "slot_list";
            body["sort"] = sort;

            return client.Post(Address.API, body, onComplete);
        }

        public Request<GameEnterResponse> GameEnter(string slotID, Action<GameEnterResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "enter";
            body["slotid"] = int.Parse(slotID);;

            return client.Post(Address.API, body, onComplete);
        }

        public Request<GameSpinResponse> GameSpin(string slotID, Action<GameSpinResponse> onComplete = null)
        {
            return GameSpin(slotID, null, -1, onComplete);
        }

        public Request<GameSpinResponse> GameSpin(string slotID, int[] syms, int cheat, Action<GameSpinResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "spin";
            body["slotid"] = int.Parse(slotID);

            if (syms != null && syms.Length > 0)
            {
                body["syms"] = syms;
            }

            if (cheat > -1)
            {
                body["cheat"] = cheat;
            }

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT, 0);
        }

        public Request<ClientResponse> GameLeave(string slotID, Action<ClientResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "leave";
            body["slotid"] = int.Parse(slotID);

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT, 0);
        }

        public Request<GameBetResponse> GameBet(string slotID, long totalBet, Action<GameBetResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "bet";
            body["bet"] = totalBet;
            body["slotid"] = int.Parse(slotID);

            return client.Post(Address.API, body, onComplete);
        }

        public Request<GameChoiceResponse> GameChoice(string slotID, int choice, Action<GameChoiceResponse> onComplete = null)
        {
            return GameChoice(slotID, choice, -1, onComplete);
        }

        public Request<GameChoiceResponse> GameChoice(string slotID, int choice,  int cheat, Action<GameChoiceResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "choice";
            body["slotid"] = int.Parse(slotID);
            body["choice"] = choice;

            if (cheat > -1)
            {
                body["cheat"] = cheat;
            }

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT, 0);
        }

        public void GameSpecial(string slotID, string act, int cheat, Action<GameSpecialResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "special";
            body["slotid"] = int.Parse(slotID);
            body["act"] = act;

            if (cheat > -1)
            {
                body["cheat"] = cheat;
            }

            client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT, 0);
        }

        public void KenoSpecial(string slotID, int[] extras, Action<GameSpecialResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "special";
            body["slotid"] = int.Parse(slotID);
            body["act"] = "pick";
            body["extras"] = extras;

            client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT, 0);
        }

        public Request<GameResponse> GameClear(string slotID, Action<GameResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "clear";
            body["slotid"] = int.Parse(slotID);

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT, 0);
        }

        public Request<ProfileResponse> Profile(Action<ProfileResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "profile";

            return client.Post(Address.API, body, onComplete);
        }

        public Request<ClientResponse> ProfileSet(string nick, long pic_num = -1, string pic_url = "", Action<ClientResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "profile_set";
            if (string.IsNullOrEmpty(nick) == false)
            {
                body["nick"] = nick;
            }

            if (pic_num != -1)
            {
                body["pic_num"] = pic_num;
            }
            if (string.IsNullOrEmpty(pic_url) == false)
            {
                body["pic_url"] = pic_url;
            }
            
            if (pic_num == -1 && string.IsNullOrEmpty(pic_url) == true)
            {
                Debug.LogError("pic_num과 pic_url 인자 모두 값이 비어있습니다.");
            }
            
            return client.Post(Address.API, body, onComplete);
        }

        public Request<ShopResponse> Shop(Action<ShopResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "shop";

            return client.Post(Address.API, body, onComplete);
        }

        public Request<GoldenRewardResponse> GoldenReward(bool ads, Action<GoldenRewardResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "golden_reward";
            body["ads"] = ads == true ? 1 : 0;

            return client.Post(Address.API, body, onComplete);
        }

        public Request<ObsidianRewardResponse> ObsidianReward(Action<ObsidianRewardResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "obsidian_reward";

            return client.Post(Address.API, body, onComplete);
        }

        public Request<OceansPassResponse> OceanPass(Action<OceansPassResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "ocean_pass";

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT, 3);
        }

        public Request<MissionResponse> Mission(Action<MissionResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "mission";

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT, 3);
        }

         // type - 0: free, 1 : buy, 2 : box
        public Request<MissionPassClaimResponse> MissionPassClaim(int step, int type, Action<MissionPassClaimResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "ocean_pass_claim";
            body["step"] = step;
            body["type"] = type;

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT, 3);
        }

        public Request<MissionPassClaimAllResponse> MissionPassClaimAll(Action<MissionPassClaimAllResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "ocean_pass_all_claim";

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT, 3);
        }

        public Request<MissionPassClaimAllResponse> MissionPassClaimAllPreview(Action<MissionPassClaimAllResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "ocean_pass_claim_preview";

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT, 3);
        }

        // free 보상이면 true, buy pass 보상이면 false
        public Request<OceanPassClaimResponse> OceanPassClaim(bool free, int step, Action<OceanPassClaimResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "ocean_pass_claim";
            body["step"] = step;
            body["free"] = free;

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT, 3);
        }

        public Request<AquaBlitzClaimResponse> AquaBlitzClaim(int step, Action<AquaBlitzClaimResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "aqua_blitz_claim";
            body["step"] = step;

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT, 3);
        }

        public Request<AquaBlitzClaimResponse> AquaBlitzMissionClaim(int missionIndex, Action<AquaBlitzClaimResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "aqua_blitz_mission_claim";
            body["index"] = missionIndex;

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT, 3);
        }

        public Request<OceanBonusResponse> OceanBonus(Action<OceanBonusResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "ocean_bonus";

            return client.Post(Address.API, body, onComplete, DEFAULT_TIMEOUT);
        }

        //clean, allin, feed
        public Request<OceanBonusClaimResponse> OceanBonusClaim(string type, Action<OceanBonusClaimResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "ocean_bonus_claim";
            body["type"] = type;

            return client.Post(Address.API, body, onComplete, DEFAULT_TIMEOUT);
        }

        public Request<CasinoBonusResponse> CasinoBonus(Action<CasinoBonusResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "casino_bonus";

            return client.Post(Address.API, body, onComplete, DEFAULT_TIMEOUT);
        }

        public Request<DailyBonusClaimResponse> DailyBonusClaim(Action<DailyBonusClaimResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "daily_bonus_claim";

            return client.Post(Address.API, body, onComplete, DEFAULT_TIMEOUT);
        }

        public Request<WelcomeBackClaimResponse> WelcomeBackClaim(Action<WelcomeBackClaimResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "welcome_back_claim";

            return client.Post(Address.API, body, onComplete, DEFAULT_TIMEOUT);
        }

        public Request<InboxRespnose> Inbox(Action<InboxRespnose> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "inbox";

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        }

        public Request<InboxClaimRespnose> InboxClaim(ulong inboxID, Action<InboxClaimRespnose> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "inbox_claim";
            body["id"] = inboxID;

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        }

        public Request<InboxRespnose> InboxSend(ulong inboxID,Action<InboxRespnose> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "inbox_claim";
            body["id"] = inboxID;

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        }

        public Request<InboxRespnose> InboxDelete(ulong inboxID,Action<InboxRespnose> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "inbox_del";
            body["id"] = inboxID;

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        }

        public Request<PlatformConnectResponse> PlatformConnect(string req, string tokenName, string tokenValue, Action<PlatformConnectResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = req;
            body["device_id"] = MyInfo.UUID;
            body[tokenName] = tokenValue;

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        }

        public Request<PlatformConnectResponse> FBDisconnect(Action<PlatformConnectResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "fb_disconnect";

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        }

        public Request<ClientResponse> FBSendFriends(string[] friednsIDs, Action<ClientResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "fb_friends";
            body["fb_game_ids"] = friednsIDs;

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        }

        public Request<ClientResponse> FBInvite(string requestID, Action<ClientResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "fb_request";
            body["type"] = "invite";
            body["request"] = requestID;

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        }

        public Request<FBRequestResponse> FBRequest(string[] requests, Action<FBRequestResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "fb_response";
            body["requests"] = requests;

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        }

        public Request<PurchaseResponse> Purchase(string sessionTicket, 
                                                  string itemID, 
                                                  int? offerID, 
                                                  int couponIndex,
                                                  ProductInfo productInfo,  
                                                  Action<PurchaseResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "purchase";
            body["position"] = MyInfo.Position;
            body["platform"] = productInfo.platform;
            body["pf_sess"] = sessionTicket;
            body["receipt"] = productInfo.receipt;
            body["currency"] = productInfo.currencyCode;
            body["price"] = productInfo.priceMultiplied;
            body["itemid"] = itemID;
            body["trxid"] = productInfo.transactionID;

            if (productInfo.platform == "android")
            {
                body["signature"] = productInfo.signature;
            }
            
            if(offerID != null
               && offerID.Value != -1)
            {
                body["offerid"] = offerID.Value;
            }
            
            /// 반드시 포함되어야 하는 파라미터 (사용하지 않을 때는 -1)
            body["coupon_index"] = couponIndex;

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        }

        public Request<AdminNoticeResponse> Notice(Action<AdminNoticeResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "notice";

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        }

        public Request<AdminEventResponse> Event(Action<AdminEventResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "event";

            return client.Post(Address.API, body, onComplete, DEFAULT_TIMEOUT);
        }

        public Request<FanpageRewardResponse> FanPageReward(string link_key, Action<FanpageRewardResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "fan_page_reward";
            body["link_key"] = link_key;

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        }

        public Request<VersionResponse> Version(Action<VersionResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "version";

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        }

        public Request<NotiCheckResponse> NotiCheck(Action<NotiCheckResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "noti_check";
            body["device_id"] = MyInfo.UUID;

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        }

        public Request<VoteOpenResponse> VoteOpen(Action<VoteOpenResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "vote_open";

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);   
        }

        public Request<VoteResponse> Vote(string id, Action<VoteResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "vote";
            body["id"] = id;

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);   
        }

        public Request<ClientResponse> VoteCapture(int seaid, string title, byte[] img, Action<ClientResponse> onComplete = null)
        {
            var body = GetBody();

            body["req"] = "vote_capture";
            body["id"] = seaid;
            body["title"] = title;
            body["img"] = img;

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);   
        }

        public Request<VoteScoreResponse> VoteScore(Action<VoteScoreResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "vote_score";

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);  
        } 

        public Request<TutorialSlotResponse> TutorialSlot(Action<TutorialSlotResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "tutorial_slot";

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        }

        public Request<CheckBetResponse> CheckBet(string slotID, Action<CheckBetResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "check_bet";
            body["slotid"] = int.Parse(slotID);

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        }

        public Request<DealResponse> Deal(Action<DealResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "deal";

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        }

        public Request<OfferResponse> Offer(string trigger, long winMultiplier, Action<OfferResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "offer";
            body["trigger"] = trigger;
            body["win_mul"] = winMultiplier;

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        }

        public Request<OfferResponse> OfferBuy(int offerID, Action<OfferResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "offer_buy";
            body["offer_id"] = offerID;

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        } 

        public Request<CouponResponse> Coupon(Action<CouponResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "coupon";

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        }

        public Request<ClientResponse> CouponClaim(int couponID, Action<ClientResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "coupon_claim";
            body["coupon_id"] = couponID;

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        }

        public Request<FreeBonusClaimResponse> FreeBonusClaim(Action<FreeBonusClaimResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "free_bonus_claim";

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        }

        public Request<SeaStoryResponse> SeaStory(int seaID, Action<SeaStoryResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "sea_story";
            body["sea"] = seaID;

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT, 0);
        }

        public Request<SeaStoryCalimResponse> SeaStoryClaim(int seaID, Action<SeaStoryCalimResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "sea_story_claim";
            body["sea"] = seaID;

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        }

        public Request<DailyQuestResponse> DailyQuest(Action<DailyQuestResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "daily_quest";

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        }

        public Request<DailyMissionPointClaimResponse> DailyMissionPointClaim(Action<DailyMissionPointClaimResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "weekly_reward_claim";

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        }

        public Request<DailyMissionItemClaimResponse> DailyMissionItemClaim(Action<DailyMissionItemClaimResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "daily_quest_claim";

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        }

        public Request<ClamHarvestResponse> ClamHarvest(Action<ClamHarvestResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "clam_harvest";

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        }

        public Request<HarvestResponse> Harvest(ClamHarvestClamType type, int index, Action<HarvestResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = $"{type}_harvest";
            body["index"] = index;

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        }

        public Request<TargetResponse> Target(string platform, Action<TargetResponse> onComplete = null)
        {
            var body = GetBody();
            body.Clear();

            body["req"] = "target";
            body["platform"] = platform;
            body["version"] = Application.version;

            return client.Post(Address.API, body, onComplete, RestClient.DEFAULT_TIMEOUT);
        }

        public Request<UserDeleteResponse> UserDelete(string appleToken, string appleCode, Action<UserDeleteResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "user_delete";
            if (string.IsNullOrEmpty(appleToken) == false)
            {
                body["token"] = appleToken;
            }
            if (string.IsNullOrEmpty(appleCode) == false)
            {
                body["code"] = appleCode;
            }

            return client.Post(Address.API, body, onComplete, DEFAULT_TIMEOUT);
        }

        public Request<ServerInfoResponse> ServerInfo(Action<ServerInfoResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "server_info";

            return client.Post(Address.API, body, onComplete, DEFAULT_TIMEOUT);
        }

        public Request<VipResetResponse> VipReset(Action<VipResetResponse> onComplete = null)
        {
            var body = GetBody();
            body["req"] = "vip_reset";

            return client.Post(Address.API, body, onComplete, DEFAULT_TIMEOUT);
        }
    }
}