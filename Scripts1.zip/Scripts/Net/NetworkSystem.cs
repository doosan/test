using UnityEngine;

namespace Underc.Net
{
    public static class NetworkSystem
    {
        private static bool isInitialize;
        private static bool isConnected;
        
        private static HTTPRequester httpRequester;
        public static HTTPRequester HTTPRequester
        {
            get
            {
                return httpRequester;
            }
        }

        private static HTTPHandler httpHandler;
        public static HTTPHandler HTTPHandler
        {
            get
            {
                return httpHandler;
            }
        }
        public static void Initialize()
        {
            if (isInitialize)
            {
                return;
            }

            isInitialize = true;

            var networkSystemObj = new GameObject("NetworkSystem");
            GameObject.DontDestroyOnLoad(networkSystemObj);

            httpRequester = new GameObject("HttpRequester").AddComponent<HTTPRequester>();
            httpRequester.transform.SetParent(networkSystemObj.transform);

            httpHandler = new HTTPHandler();
        }

        public static string IP
        {
            get
            {
                return epoch.Client.Util.Util.GetIP;
            }
        }
    }
}