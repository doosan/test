using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using DG.Tweening;
using Gaga.Sound;
using Gaga.System;
using Gaga.Util;
using Underc.Ocean;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.Util
{
    public enum ScreenshotLogoAlign
    {
        LeftBottom, RightBottom, Hide
    }

    public class ScreenshotSystem : CanvasSingleton<ScreenshotSystem>
    {
        public Texture2D LatestProfileSea
        {
            get;
            private set;
        }

        private RectTransform screenshotLogo;
        private Image bg;
        private RectTransform logoRect;
        private Image logoImage;
        private SoundPlayer soundPlayer;

        private Dictionary<Camera, bool> cameraEnables;

        protected override void OnInitialize(string popupLayerName, int resolutionWidth, int resolutionHeight, ScreenMatchMode match, int pixelsPerUnit, int depth)
        {
            base.OnInitialize(popupLayerName, resolutionWidth, resolutionHeight, match, pixelsPerUnit, depth);

            SetupSoundPlayer();
            SetupLogo();
        }

        private void SetupSoundPlayer()
        {
            soundPlayer = Instantiate(Resources.Load("ScreenshotSoundPlayer") as GameObject).GetComponent<SoundPlayer>();
            soundPlayer.transform.SetParent(root, false);
        }
        
        public void SetupLogo() 
        {
            screenshotLogo = Instantiate(Resources.Load<GameObject>("ScreenshotLogo")).GetComponent<RectTransform>();
            screenshotLogo.transform.SetParent(root, false);

            bg = screenshotLogo.Find("Bg").GetComponent<Image>();

            Transform logoTransform = screenshotLogo.Find("Logo");
            logoRect = logoTransform.GetComponent<RectTransform>();
            logoImage = logoTransform.GetComponent<Image>();

            Color originColor = logoImage.color;
            logoImage.color = new Color(originColor.r, originColor.g, originColor.b, 0);
        }

        public void TakeProfileSea(Action onComplete)
        {
            ApplyAlign(ScreenshotLogoAlign.Hide);
            StartCoroutine(TakeProfileSeaCoroutine(onComplete));
        }

        private IEnumerator TakeProfileSeaCoroutine(Action onComplete)
        {
            if (cameraEnables == null)
            {
                cameraEnables = new Dictionary<Camera, bool>();
            }

            /// 바다만 남기고 모든 카메라 끔
            if (cameraEnables.Count == 0)
            {
                foreach (Camera camera in Camera.allCameras)
                {
                    if (camera.GetComponentInParent<OceanView>() != null)
                    {
                        continue;
                    }

                    cameraEnables.Add(camera, camera.enabled);
                    camera.enabled = false;
                }
            }

            yield return new WaitForEndOfFrame();

            CacheProfileSea();

            /// 다시 복구
            foreach (KeyValuePair<Camera, bool> pair in cameraEnables)
            {
                Camera camera = pair.Key;
                bool enabled = pair.Value;
                camera.enabled = enabled;
            }
            cameraEnables.Clear();

            onComplete?.Invoke();
        }

        public void Take(Action<Texture2D> onEnd)
        {
            soundPlayer.Play();
            ApplyAlign(ScreenshotLogoAlign.Hide);

            StartCoroutine(TakeCoroutine(onEnd));
        }

        private IEnumerator TakeCoroutine(Action<Texture2D> onEnd)
        {
            yield return FlashScreen();
            Texture2D ss = GetScreenShot();

            if (onEnd != null)
            {
                onEnd.Invoke(ss);
            }

            yield break;
        }

        public void TakeAndShare(Action onBegin = null, 
                                 Action onEnd = null,
                                 ScreenshotLogoAlign align = ScreenshotLogoAlign.RightBottom)
        {
            soundPlayer.Play();
            ApplyAlign(align);

            StartCoroutine(TakeAndShareCoroutine(onBegin, onEnd));
        }

        private void ApplyAlign(ScreenshotLogoAlign align)
        {
            if (align == ScreenshotLogoAlign.LeftBottom)
            {
                logoRect.gameObject.SetActive(true);
                logoRect.anchorMin = new Vector3(0, 0);
                logoRect.anchorMax = new Vector3(0, 0);
                logoRect.anchoredPosition = new Vector2(131, 30);
            }
            else if (align == ScreenshotLogoAlign.RightBottom)
            {
                logoRect.gameObject.SetActive(true);
                logoRect.anchorMin = new Vector3(1, 0);
                logoRect.anchorMax = new Vector3(1, 0);
                logoRect.anchoredPosition = new Vector2(-131, 30);
            }
            else if (align == ScreenshotLogoAlign.Hide)
            {
                logoRect.gameObject.SetActive(false);
            }
        }

        private IEnumerator TakeAndShareCoroutine(Action onBegin, Action onEnd)
        {
            if (onBegin != null)
            {
                onBegin.Invoke();
            }

            float fadeDuration = .25f;
            yield return FlashScreen(fadeDuration);

            Texture2D ss = GetScreenShot();
            
            string filePath = Path.Combine(Application.temporaryCachePath,
                                           StringMaker.New()
                                                      .Append("Aquuuacasino_")
                                                      .Append(DateTime.Now.ToString("yyyyMMdd"))
                                                      .Append(".png")
                                                      .Build());

            Debug.Log("filepath: " + filePath);
            File.WriteAllBytes(filePath, ss.EncodeToPNG());

            // To avoid memory leaks
            GameObject.Destroy(ss);
            logoImage.DOFade(0f, fadeDuration);

            if (onEnd != null)
            {
                onEnd.Invoke();
            }

            string message = StringMaker.New()
                                        .Append(Environment.NewLine)
                                        .Append("Endless sea aquarium at your fingertips while playing thrilling slot games!")
                                        .Append(Environment.NewLine)
                                        .Append(Environment.NewLine)
                                        .Append("Let's Join Aquuua Casino NOW.")
                                        .Append(Environment.NewLine)
                                        .Append("Click to Play: https://rebrand.ly/Click-to-Play")
                                        .Append(Environment.NewLine)
                                        .Build();

            new NativeShare().AddFile(filePath)
                             .SetTitle("Aquuua Casino - Slots") // Title of the share dialog on Android platform, Effects on Android only.
                             .SetSubject("Aquuua Casino - Slots")
                             .SetText(message)
                             .Share();
        }

        private IEnumerator FlashScreen(float duration = 0.25f)
        {
            WaitForSeconds waitForFade = new WaitForSeconds(duration);
            bg.DOFade(1f, duration).SetEase(Ease.OutCirc);
            yield return waitForFade;

            Color originColor = logoImage.color;
            logoImage.color = new Color(originColor.r, originColor.g, originColor.b, 1f);
            bg.DOFade(0f, duration);
            yield return waitForFade;
            yield return new WaitForEndOfFrame();
        }

        public Texture2D GetScreenShot()
        {
            return GetScreenShot(Screen.width, Screen.height, new Rect(0f,0f,Screen.width, Screen.height));
        }

        public Texture2D GetScreenShot(int textureW, int textureH, Rect rect)
        {
            Texture2D ss = new Texture2D(textureW, textureH, TextureFormat.RGBA32, false);
            ss.ReadPixels(rect, 0, 0);
            ss.Apply();

            return ss;
        }

        private void CacheProfileSea()
        {
            // 타겟 텍스쳐 비율 유지
            if (LatestProfileSea == null)
            {
                //float profileSeaScale = Screen.width / 470;
                //int profileSeaHeight = (int)(178 * profileSeaScale);
                LatestProfileSea = new Texture2D(Screen.width, Screen.height, TextureFormat.RGBA32, false);
            }

            var rect = new Rect(
                0f,
                0,
                LatestProfileSea.width,
                LatestProfileSea.height
            );
            LatestProfileSea.ReadPixels(rect, 0, 0);
            LatestProfileSea.Apply();
        }
    }
}
