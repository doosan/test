﻿using UnityEngine;
using UnityEngine.Events;

namespace Underc.Util
{
    public class AnimationEventTrigger : MonoBehaviour
    {
        public UnityEvent OnTrigger;
        public UnityEvent OnTrigger2;
        public UnityEvent OnTrigger3;
        public UnityEvent OnTrigger4;

        public void Trigger()
        {
            if (OnTrigger != null)
            {
                OnTrigger.Invoke();
            }
        }

        public void Trigger2()
        {
            if (OnTrigger2 != null)
            {
                OnTrigger2.Invoke();
            }
        }

        public void Trigger3()
        {
            if (OnTrigger3 != null)
            {
                OnTrigger3.Invoke();
            }
        }

        public void Trigger4()
        {
            if (OnTrigger4 != null)
            {
                OnTrigger4.Invoke();
            }
        }
    }

}
