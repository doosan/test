using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using System.Linq;
using Gaga.Util;

namespace Underc.Util.Editor
{
    public class SwitchSceneMenu
    {
        private static SwitchSceneMenu instance;
        private const string SCENE_PATH_LOBBY                = "Assets/0.UNDERC/Lobby/Scenes/LobbyScene.unity";
        private const string SCENE_PATH_GAME                 = "Assets/0.UNDERC/Game/Scenes/GameScene.unity";
        private const string SCENE_PATH_GAME_PORTRAIT        = "Assets/0.UNDERC/Game/Scenes/GameScenePortrait.unity";
        private const string SCENE_PATH_INTRO                = "Assets/0.UNDERC/Intro/Scenes/IntroScene.unity";

        private static Queue<Transform> expandingTargets = new Queue<Transform>();

        static SwitchSceneMenu() 
        {
            instance = new SwitchSceneMenu();
        }
        
        [MenuItem("Underc/SwitchScene/Intro", false, 1)]
        public static void SwitchSceneToIntro()
        {
            EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo();

            EditorSceneManager.OpenScene(SCENE_PATH_INTRO);
            ExpandHierarchy3();
        }

        [MenuItem("Underc/SwitchScene/Lobby", false, 2)]
        public static void SwitchSceneToLobby()
        {
            EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo();
            
            EditorSceneManager.OpenScene(SCENE_PATH_LOBBY);
            ExpandHierarchy3();
        }

        [MenuItem("Underc/SwitchScene/Game", false, 3)]
        public static void SwitchSceneToGame()
        {
            EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo();
            
            EditorSceneManager.OpenScene(SCENE_PATH_GAME);
            ExpandHierarchy3();
        }

        [MenuItem("Underc/SwitchScene/Game(Portrait)", false, 4)]
        public static void SwitchSceneToGamePortrait()
        {
            EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo();
            
            EditorSceneManager.OpenScene(SCENE_PATH_GAME_PORTRAIT);
            ExpandHierarchy3();
        }

        [MenuItem("Underc/SwitchScene/Ocean2D", false, 5)]
        public static void SwitchSceneToOcean2D()
        {
            EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo();
            
            EditorSceneManager.OpenScene(EditorResources.FindAssetPath("Ocean2D", ".unity"));
            ExpandHierarchy3();
        }

        [MenuItem("Underc/Expand Hierarchy Until 3 Depth", false, 2)]
        public static void ExpandHierarchy3()
        {
            foreach (GameObject rootObject in EditorSceneManager.GetActiveScene().GetRootGameObjects())
            {
                ScrapeExpandingTargets(rootObject.transform, 3);
            }
            EditorApplication.update += instance.OnUpdate;
        }

        private void OnUpdate()
        {
            if (expandingTargets.Count == 0)
            {
                EditorApplication.update -= instance.OnUpdate;
                return;
            }
            
            EditorApplication.ExecuteMenuItem("Window/General/Hierarchy");
            EditorWindow hierarchy = EditorWindow.focusedWindow;

            Selection.activeObject = expandingTargets.Dequeue();
            hierarchy.SendEvent(new Event { keyCode = KeyCode.RightArrow, type = EventType.KeyDown });
        }

        private static void ScrapeExpandingTargets(Transform parent, int until, int count = 1)
        {
            foreach (Transform child in parent)
            {
                expandingTargets.Enqueue(child);

                if (child.childCount > 0 && count < until)
                {
                    ScrapeExpandingTargets(child, until, count + 1);
                }
            }
        }
    }
}
