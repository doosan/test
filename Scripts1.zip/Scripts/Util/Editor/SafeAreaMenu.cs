using Gaga.UI;
using UnityEditor;
using UnityEngine;

namespace Underc.Util.Editor
{
    public class SafeAreaMenu
    {
        [MenuItem("Underc/SafeArea/Default", false, 0)]
        public static void Default()
        {
            SafePanel.SetDefaultSafeArea();
        }

        private static void SetHorizontalSafeArea(float rate, bool isLeft)
        {
            var margin = Screen.width * rate;
            
            var rect = new Rect(x: isLeft ? margin : 0.0f, y: 0.0f, Screen.width - margin, Screen.height);
            //SafePanel.SetCustomSafeArea(rect);
        }

        private static void SetVerticalSafeArea(float rate, bool isBottom)
        {
            var margin = Screen.height * rate;

            var rect = new Rect(x: 0.0f, y: isBottom ? margin : 0.0f, Screen.width, Screen.height - margin);
            //SafePanel.SetCustomSafeArea(rect);
        }

        [MenuItem("Underc/SafeArea/iPhoneX Left", false, 11)]
        public static void iPhoneX_Left()
        {
            SetHorizontalSafeArea(0.054187192f, true);
        }

        [MenuItem("Underc/SafeArea/iPhoneX Right", false, 12)]
        public static void iPhoneX_Right()
        {
            SetHorizontalSafeArea(0.054187192f, false);
        }

        [MenuItem("Underc/SafeArea/iPhoneX Top", false, 13)]
        public static void iPhoneX_Top()
        {
            SetVerticalSafeArea(0.054187192f, isBottom: false);
        }

        [MenuItem("Underc/SafeArea/iPhoneX Bottom", false, 14)]
        public static void iPhoneX_Bottom()
        {
            SetVerticalSafeArea(0.054187192f, isBottom: true);
        }

        [MenuItem("Underc/SafeArea/Galaxy s10 Left", false, 21)]
        public static void GalaxyS10_Left()
        {
            SetHorizontalSafeArea(0.046929825f, true);
        }

        [MenuItem("Underc/SafeArea/Galaxy s10 Right", false, 22)]
        public static void GalaxyS10_Right()
        {
            SetHorizontalSafeArea(0.046929825f, false);
        }
    }
}
