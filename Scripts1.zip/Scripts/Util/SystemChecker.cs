using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

namespace Underc.Util
{
    public class SystemChecker
    {
        #if UNITY_ANDROID
        public static int ReadAndroidSdkLevel() 
        {
            var clazz = AndroidJNI.FindClass("android/os/Build$VERSION");
            var fieldID = AndroidJNI.GetStaticFieldID(clazz, "SDK_INT", "I");
            var sdkLevel = AndroidJNI.GetStaticIntField(clazz, fieldID);
            return sdkLevel;
        }
        #endif

        public static bool IsPointerOverUI(string parentName)
        {
            PointerEventData eventDataCurrentPosition = new PointerEventData(EventSystem.current);
            eventDataCurrentPosition.position = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
            List<RaycastResult> results = new List<RaycastResult>();
            if (EventSystem.current != null)
            {
                EventSystem.current.RaycastAll(eventDataCurrentPosition, results);
            }

            bool result = false;
            if (string.IsNullOrEmpty(parentName) == false)
            {
                result = results.Count > 0;
            }
            else
            {
                foreach (RaycastResult rr in results)
                {
                    if (rr.gameObject.transform.parent.name == parentName)
                    {
                        result = true;
                        break;
                    }
                }    
            }
            
            return result;
        }
    }
}