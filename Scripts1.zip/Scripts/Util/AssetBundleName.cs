using Gaga.Util;
using UnityEngine;

namespace Underc.Util
{
    public static class AssetBundleName
    {
        public static string ROOT_MANIFEST                  = "assetbundles";
        public static string EFFECT                         = "effect";
        public static string SLOT_POSTERS                   = "slot_posters";
        public static string TOP_UI                         = "top_ui";
        public static string REWARD_BONUS_UI                = "reward_bonus_ui";
        public static string VIP_BONUS_BADGE                = "vip_bonus_badge";
        public static string SEA_THUMBNAIL                  = "sea_thumbnail";
        public static string TUTORIAL                       = "tutorial";
        public static string SOUND_GLOBAL                   = "sound_global";
        public static string ICON_PROFILE                   = "icon_profile";
        public static string ICON_SLOTS                     = "icon_slots";
        public static string ICON_FISH                      = "icon_fish";
        public static string LOADING_SCREEN                 = "loading_screens";
        public static string COMMON_TEXTURES                = "common_textures";
        public static string COMMON_FONTS                   = "common_fonts";

        public static string RootManifest(string assetbundleVersion)
        {
            return $"{ROOT_MANIFEST}_{assetbundleVersion}";
        }

        public static string Sea(int seaId)
        {
            return $"sea_{seaId}";
        }

        public static string LobbyCasino(int id)
        {
            return $"lobbycasino_{id}";
        }

        public static string Paytable(string slotID)
        {
            return $"paytable_{slotID}";
        }

        private static string platformName = "";
        public static string ReadPlatformName()
        {
            if (string.IsNullOrEmpty(platformName) == true)
            {
                switch (Application.platform)
                {
                    case RuntimePlatform.WindowsPlayer:
                    case RuntimePlatform.WindowsEditor:
                    platformName = "android";
                    break;

                    case RuntimePlatform.OSXPlayer:
                    case RuntimePlatform.OSXEditor:
                    platformName = "android";
                    break;

                    case RuntimePlatform.Android:
                    platformName = "android";
                    break;

                    case RuntimePlatform.IPhonePlayer:
                    platformName = "ios";
                    break;
                }
            }
            
            return platformName;
        }
    }
}