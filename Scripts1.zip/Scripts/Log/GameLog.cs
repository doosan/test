using System.Collections.Generic;
using Gaga.System;

namespace Underc
{
    public static class GameLog
    {
        private static ObjectPool<Log> pool;

        private static void SetupPool()
        {
            pool = new ObjectPool<Log>
            (
                2,
                ()=>
                {
                    return new Log();
                }
            );
        }

        public static Log New(string logID, string detailID)
        {
            if (pool == null)
            {
                SetupPool();
            }

            var log = pool.Get();
            log.Initialize(logID, detailID);

            return log;
        }

        public sealed class Log
        {
#if GGDEV
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
#endif
            private Dictionary<string, object> customLogItems = new Dictionary<string, object>();
            private string logID;
            private string detailID;

            public Log Initialize(string logID, string detailID)
            {
                this.logID = logID;
                this.detailID = detailID;

                customLogItems.Clear();

                return this;
            }

            public void Send()
            {
#if GGDEV
                sb.Length = 0;
                
                foreach (var item in customLogItems)
                {
                    sb.Append("[");
                    sb.Append(item.Key);
                    sb.Append(":");
                    sb.Append(item.Value);
                    sb.Append("]");
                }

                string customLogs = sb.ToString();
                Debug.LogFormat("GameLog Result (logID:{0}, detailID:{1}, custom:{2})", logID, detailID, customLogs);
#endif

                epoch.Client.Log.Log.Instance.SendGameLog
                (
                    logID, 
                    detailID, 
                    customLogItems,
                    result =>
                    {
                        pool.Return(this);
                    }
                );
            }

            public void Abort()
            {
                pool.Return(this);
            }

            public Log Append(string key, object value)
            {
                if (customLogItems.ContainsKey(key))
                {
                    customLogItems[key] = value;
                }
                else
                {
                    customLogItems.Add(key, value);
                }

                return this;
            }
        }
    }
}