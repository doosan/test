using Underc.User;

namespace Underc
{
    public sealed class SingularLog
    {
        private GameLog.Log CommonLog(string logID, string detailID)
        {
            var log = GameLog.New(logID, detailID);
            log.Append("uid", string.IsNullOrEmpty(MyInfo.ID) ? 0 : long.Parse(MyInfo.ID));

            return log;
        }

        private void Send(string key, int value)
        {
            CommonLog("singular", key)
                   .Append(key, value)
                   .Send();
        }

        private void SendPurchase(string key, double price, string currencyCode)
        {
            CommonLog("singular", key)
                   .Append(key, 1)
                   .Append("amount", price)
                   .Append("currency", currencyCode)
                   .Send();
        }

        public void AdsStart()
        {
            Send("Ads_start" , 1);
        }

        public void AdsFinish()
        {
            Send("Ads_finish" , 1);
        }

        public void LobbyFirst()
        {
            Send("Lobby_First", 1);
        }

        public void SlotFirst()
        {
            Send("slot_first", 1);
        }

        public void GameFirst()
        {
            Send("Game_First", 1);
        }

        public void CompleteTutorial()
        {
            Send("Complete_Tutorial", 1);
        }

        public void TutorialStart()
        {
            Send("Tutorial_Start", 1);
        }

        public void HomeFirst()
        {
            Send("Home_First", 1);
        }

        public void OpenShop()
        {
            Send("open_shop", 1);
        }

        public void OpenDeal()
        {
            Send("open_deal", 1);
        }

        public void D0Spin400()
        {
            Send("D0_spin400", 1);
        }

        public void Lv75()
        {
            Send("Lv75", 1);
        }

        public void Lv100()
        {
            Send("Lv100", 1);
        }

        public void D1login()
        {
            Send("D1_login", 1);
        }

        public void D2login()
        {
            Send("D2_login", 1);
        }

        public void D7Spin600()
        {
            Send("D7_spin600", 1);
        }

        public void FirstAllin()
        {
            Send("first_allin", 1);
        }

        public void PurchaseFirst( double price, string currencyCode)
        {
            SendPurchase("purchase_first", price, currencyCode);
        }
    }
}