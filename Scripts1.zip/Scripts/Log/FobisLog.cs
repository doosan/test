using Underc.Popup;
using Underc.User;

namespace Underc
{
    public sealed class FobisLog
    {
        private GameLog.Log CommonLog(string logID, string detailID)
        {
            var log = GameLog.New(logID, detailID);
            log.Append("uid", string.IsNullOrEmpty(MyInfo.ID) ? 0 : long.Parse(MyInfo.ID));

            return log;
        }
        
        private string GetPositionName()
        {
            // 1:바다로비, 2:슬롯로비, slotID:인게임
            if (MyInfo.Position == MyInfo.POSITION_LOBBY_OCEAN)
            {
                return "sea";
            }
            else if (MyInfo.Position == MyInfo.POSITION_LOBBY_SLOT)
            {
                return "lobby";
            }
            else
            {
                var slotPreset = MyInfo.SlotGame.SlotPresetList.Find(MyInfo.Position);
                return slotPreset == null ? "" : slotPreset.name;
            }
        }

        public void AccountJoin()
        {
            CommonLog("account", "join").Send();
        }

        public void AccountLink(string startTime, int startType, string endTime, int endType, int endResult)
        {
            CommonLog("account", "link")
                   .Append("start_dt", startTime)
                   .Append("start_type", startType) //1 : facebook
                   .Append("end_dt", endTime)
                   .Append("end_type", endType) //1 : facebook
                   .Append("end_result", endResult) //1: 성공, 2: 취소, 3: 실패 
                   .Send();
        }   

        public void PopupBackButton(int btnType)
        {
            CommonLog("popup", "back_button")
                   .Append("btn_type", btnType)
                   .Send();
        }

        public void PopupAllowPush(int btnType)
        {
            CommonLog("popup", "allow_push")
                   .Append("btn_type", btnType)
                   .Append("level", MyInfo.Level)
                   .Append("position", MyInfo.Position)
                   .Append("vip_point", MyInfo.VipClass.Xp)
                   .Append("vip_level", (int)MyInfo.VipClass.Type)
                   .Send();
        }

        public void PopupStar(int btnType)
        {
            var cnt = UndercPrefs.GetRemoteValue(RateusPopup.KEY_OPEN_COUNT, "1");

            CommonLog("popup", "star")
                   .Append("btn_type", btnType)
                   .Append("level", MyInfo.Level)
                   .Append("position", MyInfo.Position)
                   .Append("review_times", cnt)
                   .Append("vip_point", MyInfo.VipClass.Xp)
                   .Append("vip_level", (int)MyInfo.VipClass.Type)
                   .Send();
        }

        public void SystemOption()
        {
            SystemOption(-1, 0);
        }

        public void SystemOption(int optionType, int value)
        {
            CommonLog("system", "option")
                    .Append("option_type", optionType)
                    .Append("option_value", value)
                    .Append("position", MyInfo.Position)
                    .Append("slotnm", GetPositionName())
                    .Send();
        }

        public void AccountNameEdit()
        {
            CommonLog("account", "name_edit")
                   .Append("now", AppService.Now())
                   .Send();
        }

        public void AccountProfileSave()
        {
            CommonLog("account", "profile_save")
                   .Append("now", AppService.Now())
                   .Send();
        }

        public void AccountProfileEdit()
        {
            CommonLog("account", "profile_edit")
                   .Append("now", AppService.Now())
                   .Send();
        }

        public void ButtonInbox(int btnType)
        {
            CommonLog("button", "inbox")
                    .Append("btn_type", btnType)
                    .Append("level", MyInfo.Level)
                    .Send();
        }

        public void TutorialStep(int stepID)
        {
            CommonLog("tutorial","step")
                   .Append("tutorial_step", stepID)
                   .Send();
        }

        public void TutorialSeaStep(int stepID)
        {
            CommonLog("tutorial","sea_step")
                   .Append("tutorial_sea_step", stepID)
                   .Send();
        }

        public void ButtonLobbyMenu(int btnType)
        {
            CommonLog("button", "lobby_menu")
                    .Append("btn_type", btnType)
                    .Append("level" , MyInfo.Level)
                    .Send();
        }

        public void ButtonSeaDetails(int btnType)
        {
            CommonLog("button", "sea_details")
                       .Append("btn_type", btnType)
                       .Append("level", MyInfo.Level)
                       .Append("sea_id", MyInfo.Ocean.CurrentSeaID)
                       .Send();
        }

        public void ButtonSeaMenu(int btnType)
        {
            CommonLog("button", "sea_menu")
                    .Append("btn_type", btnType)
                    .Append("level", MyInfo.Level)
                    .Send();
        }

        public void ButtonSlot(int btnType)
        {
            CommonLog("button", "slot")
                    .Append("btn_type", btnType)
                    .Append("slotid", MyInfo.SlotGame.currentSlotID)
                    .Append("slotnm", MyInfo.SlotGame.SlotPresetList.Find(int.Parse(MyInfo.SlotGame.currentSlotID)).name)
                    .Append("level", MyInfo.Level)
                    .Append("vip_point", MyInfo.VipClass.Xp)
                    .Append("vip_level", (int)MyInfo.VipClass.Type)
                    .Send();
        }

        public void RewardAdOpen(string startTime, string endTime, int adType, long coinBefore, long coinEarn, long coinAfter)
        {
            CommonLog("reward", "ad_open")
                    .Append("start_dt", startTime)
                    .Append("end_dt", endTime)
                    .Append("ad_type", adType) // 1:UnityAds
                    .Append("coin_bf", coinBefore)
                    .Append("coin_ch", coinEarn)
                    .Append("coin_af", coinAfter)
                    .Append("level", MyInfo.Level)
                    .Send();
        }

        public void RewardAdPopOpen(string startTime, string endTime, int adType, long coinBefore, long coinEarn, long coinAfter)
        {
            CommonLog("reward", "ad_pop_open")
                    .Append("start_dt", startTime)
                    .Append("end_dt", endTime)
                    .Append("ad_type", adType) // 1:UnityAds
                    .Append("coin_bf", coinBefore)
                    .Append("coin_ch", coinEarn)
                    .Append("coin_af", coinAfter)
                    .Append("level", MyInfo.Level)
                    .Send();
        }

        public void ButtonFishInfo(int fishID)
        {
            CommonLog("button", "fish_info")
                   .Append("fish_id", fishID)
                   .Send();
        }

        public void ButtonFishStore(int btnType, int itemID = -1)
        {
            CommonLog("button", "fish_store")
                    .Append("btn_type", btnType)
                    .Append("level", MyInfo.Level)
                    .Append("sea_id", MyInfo.Ocean.CurrentSeaID)
                    .Append("item_id", itemID)
                    .Send();
        }

        public void ButtonInventory(int btnType)
        {
            CommonLog("button", "inventory")
                    .Append("btn_type", btnType)
                    .Append("level", MyInfo.Level)
                    .Send();
        }

        public void ButtonCasinoLobby(int btnType)
        {
            CommonLog("button", "casino_lobby")
                   .Append("btn_type", btnType)
                   .Append("level", MyInfo.Level)
                   .Send();
        }

		/// <param name="btnType"> 1: 개별 보상 버튼(보상들 버튼들) 2: 컬렉트 올 버튼 3: 언락 미션 패스 버튼 4: 닫기 버튼 </param>
        public void ButtonMissionPass(int btnType)
        {
            CommonLog("button", "mission_pass")
                   .Append("btn_type", btnType)
                   .Append("level", MyInfo.Level)
                   .Append("position", MyInfo.Position)
                   .Append("vip_point", MyInfo.VipClass.Xp)
                   .Append("vip_level", (int)MyInfo.VipClass.Type)
                   .Send();
        }

        /// <param name="btnType"> 1: 미션 패스 구매 버튼  2: 미션 패스 번들 구매버튼  3:슈퍼패스 구매버튼   4: 닫기 버튼 </param>
        public void ButtonMissionPassBuy(int btnType)
        {
            CommonLog("button", "mission_pass_buy")
                   .Append("btn_type", btnType)
                   .Append("level", MyInfo.Level)
                   .Append("position", MyInfo.Position)
                   .Append("vip_point", MyInfo.VipClass.Xp)
                   .Append("vip_level", (int)MyInfo.VipClass.Type)
                   .Send();
        }

        public void PopupOffer(string packType, int packID, string packBonus, string productID)
        {
            int packBonusNum = 0;
            if (string.IsNullOrEmpty(packBonus) == false)
            {
                var packBonusVal = packBonus.Replace("%", "");
                if (int.TryParse(packBonusVal, out packBonusNum) == false)
                {
                    packBonusNum = 0;
                }
            }

            CommonLog("button", "offer_popup")
                   .Append("pack_type", packType)
                   .Append("pack_id", packID)
                   .Append("pack_bonus", packBonusNum)
                   .Append("product_id", productID)
                   .Append("position", MyInfo.Position)
                   .Append("slotnm", GetPositionName())
                   .Append("vip_point", MyInfo.VipClass.Xp)
                   .Append("vip_level", (int)MyInfo.VipClass.Type)
                   .Send();
        }

        public void SlotAllIn(long totalBet)
        {
            CommonLog("slot", "all_in")
                    .Append("coin_af", MyInfo.Coin)
                    .Append("bet_ch", totalBet)
                    .Append("slotid", MyInfo.SlotGame.currentSlotID)
                    .Append("slotnm", MyInfo.SlotGame.SlotPresetList.Find(int.Parse(MyInfo.SlotGame.currentSlotID)).name)
                    .Append("level", MyInfo.Level)
                    .Send();
        }

        public void ResourcesDownload(string uri, float elapsedTime, string state)
        {
            CommonLog("resources", "resources_download")
                    .Append("path", uri)
                    .Append("sec", elapsedTime)
                    .Append("state", state)
                    .Append("slotnm", GetPositionName())
                    .Append("position", MyInfo.Position)
                    .Send();
        }

        public void PushTracking(int id)
        {
            CommonLog("push", "push_tracking")
                    .Append("push_id", id)
                    .Append("level", MyInfo.Level)
                    .Append("vip_point", MyInfo.VipClass.Xp)
                    .Append("vip_level", (int)MyInfo.VipClass.Type)
                    .Send();
        }

        /// <param name="buttonType"> 1 : 팝업 하단 버튼, 2 : 닫기 버튼 </param>
        public void NoticeButton(int buttonType, uint popupID, int executeType, int executeDetail)
        {
            TargetToMove location = (TargetToMove)executeType;
            string slotName = "";

            if (location == TargetToMove.Slot)
            {
                var slotPreset = MyInfo.SlotGame.SlotPresetList.Find(executeDetail);
                
                if (slotPreset != null)
                {
                    slotName = slotPreset.name;
                }
            }

            CommonLog("popup", "notice_button")
                    .Append("button_type", buttonType)
                    .Append("level", MyInfo.Level)
                    .Append("coin_af", MyInfo.Coin)
                    .Append("vip_level", (int)MyInfo.VipClass.Type)
                    .Append("position", executeType)
                    .Append("slotnm", slotName)
                    .Append("popupID", popupID)
                    .Send();
        }

        /// <param name="buttonType"> 1 : 팝업 하단 버튼, 2 : 닫기 버튼 </param>
        public void EventButton(int buttonType, uint eventID, int executeType, int executeDetail, string winType, long winCount)
        {
            TargetToMove location = (TargetToMove)executeType;
            string slotName = "";

            if (location == TargetToMove.Slot)
            {
                var slotPreset = MyInfo.SlotGame.SlotPresetList.Find(executeDetail);
                
                if (slotPreset != null)
                {
                    slotName = slotPreset.name;
                }
            }

            CommonLog("popup", "event_button")
                    .Append("button_type", buttonType)
                    .Append("level", MyInfo.Level)
                    .Append("coin_af", MyInfo.Coin)
                    .Append("vip_level", (int)MyInfo.VipClass.Type)
                    .Append("position", executeType)
                    .Append("slotnm", slotName)
                    .Append("win_type", winType)
                    .Append("mission", winCount)
                    .Append("eventid", eventID)
                    .Send();
        }

        public void NewSlotPopupFirstView(int popupID, string slotID)
        {
            CommonLog("popup", "new_slot_popup_first_view")
                    .Append("popupid", popupID)
                    .Append("level", MyInfo.Level)
                    .Append("coin_af", MyInfo.Coin)
                    .Append("vip_level", (int)MyInfo.VipClass.Type)
                    .Append("slotid", slotID)
                    .Append("slotnm", MyInfo.SlotGame.SlotPresetList.Find(int.Parse(slotID)).name)
                    .Send();
        }

        public void NewSlotPosterFirstView(string slotID)
        {
            CommonLog("poster", "new_slot_poster_first_view")
                    .Append("level", MyInfo.Level)
                    .Append("coin_af", MyInfo.Coin)
                    .Append("vip_level", (int)MyInfo.VipClass.Type)
                    .Append("slotid", slotID)
                    .Append("slotnm", MyInfo.SlotGame.SlotPresetList.Find(int.Parse(slotID)).name)
                    .Send();
        }

        /// <param name="enterType"> 1 : 공지팝업, 2 : 포스터 </param>
        public void NewSlotFirstEnter(string slotID, int enterType, int popupID, int popupViewCount, int posterViewCount)
        {
            CommonLog("slot", "new_slot_first_enter")
                    .Append("slotid", slotID)
                    .Append("slotnm", MyInfo.SlotGame.SlotPresetList.Find(int.Parse(slotID)).name)
                    .Append("enter_type", enterType)
                    .Append("popupid", popupID)
                    .Append("slot_popup_view_count", popupViewCount)
                    .Append("poster_view_count", posterViewCount)
                    .Append("vip_level", (int)MyInfo.VipClass.Type)
                    .Append("level", MyInfo.Level)
                    .Append("coin_af", MyInfo.Coin)
                    .Send();
        }
    }
}