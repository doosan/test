namespace Underc
{
    public static class UndercGameLog
    {
        // ------------------ 모든 로그에 기본 값(값이 없을 때)은 아래와 같은 형태여야함.
        // 숫자형
        // 코드값: -1
        // 숫자값(재화값등) : 0

        // 문자형
        // 빈값 = ""
        // -------------------------------------------------------------------------

        public static FobisLog Fobis{get;} = new FobisLog();
        public static SingularLog Singular{get;} = new SingularLog();
        public static FirebaseLog Firebase{get;} = new FirebaseLog();
    }
}