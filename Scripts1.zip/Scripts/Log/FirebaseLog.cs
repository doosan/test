using Firebase.Analytics;
using Underc.User;

namespace Underc
{
    public sealed class FirebaseLog
    {
        public static bool enabled = false;

        private Parameter uidParam;

        private Parameter GetUidParam()
        {
            if (uidParam == null)
            {
                uidParam = new Parameter("uid", string.IsNullOrEmpty(MyInfo.ID) ? "" : MyInfo.ID);
            }

            return uidParam;
        }

        private void Send(string key)
        {
            if (enabled == false)
            {
                Debug.Log("Firebase 이벤트 비활성화");
                return;
            }

            Firebase.Analytics.FirebaseAnalytics.LogEvent(key, GetUidParam());
        }

        private void SendPurchase(string key, double price, string currencyCode)
        {
            if (enabled == false)
            {
                Debug.Log("Firebase 이벤트 비활성화");
                return;
            }

            Parameter priceParam = new Parameter("value", price);
            Parameter currencyCodeParam = new Parameter("currency", currencyCode);
            
            Firebase.Analytics.FirebaseAnalytics.LogEvent(key, GetUidParam(), priceParam, currencyCodeParam);
        }

        public void AdsStart()
        {
            Send("Ads_start");
        }

        public void AdsFinish()
        {
            Send("Ads_finish");
        }

        public void LobbyFirst()
        {
            Send("Lobby_First");
        }

        public void SlotFirst()
        {
            Send("slot_first");
        }

        public void GameFirst()
        {
            Send("Game_First");
        }

        public void CompleteTutorial()
        {
            Send("Complete_Tutorial");
        }

        public void TutorialStart()
        {
            Send("Tutorial_Start");
        }

        public void HomeFirst()
        {
            Send("Home_First");
        }

        public void OpenShop()
        {
            Send("open_shop");
        }

        public void OpenDeal()
        {
            Send("open_deal");
        }

        public void D0Spin400()
        {
            Send("D0_spin400");
        }

        public void Lv75()
        {
            Send("Lv75");
        }

        public void Lv100()
        {
            Send("Lv100");
        }

        public void D1login()
        {
            Send("D1_login");
        }

        public void D2login()
        {
            Send("D2_login");
        }

        public void D7Spin600()
        {
            Send("D7_spin600");
        }

        public void FirstAllin()
        {
            Send("first_allin");
        }

        public void PurchaseFirst( double price, string currencyCode)
        {
            SendPurchase("purchase_first", price, currencyCode);
        }
    }
}