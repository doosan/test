#if UNITY_ANDROID || UNITY_EDITOR
using epoch.Client.Push;
using System;
using System.Collections;
using Unity.Notifications.Android;
using UnityEngine;

namespace Underc.Notification
{
    public sealed class AndroidNotificationPlatform : INotificationPlatform
    {
        private readonly string CHANNEL_DEFAULT_ID          = "default_ch";
        private readonly string CHANNEL_DEFAULT_NAME        = "default channel";
        private readonly string KEY_FIRST_SETUP             = "key_aos_noti_init";

        private bool isEnabled;

        public AndroidNotificationPlatform()
        {
            SetupDefaultChannel();
            SetupNotificationState();
            SetupNotificationHandler();
        }

        private void SetupDefaultChannel()
        {
            var channel = new AndroidNotificationChannel()
            {
                Id = CHANNEL_DEFAULT_ID,
                Name = CHANNEL_DEFAULT_NAME,
                Importance = Importance.Default,
                Description = "Generic notifications",
            };
            
            AndroidNotificationCenter.RegisterNotificationChannel(channel);
        }

        private void SetupNotificationState()
        {
            Push.GetPushNotification(result =>
            {
                var sdkVer = GetSDKInt();
                Debug.Log("AndroidNotificationPlatform api level : " + sdkVer);

                // 안드로이드 api level 33 (os13) 이상부터 푸시 동의 팝업이 뜸.
                if (sdkVer >= 33)
                {
                    SetEnable(result.SetPushOption == PushOption.On);
                }
                else
                {
                    // api level 33 미만 안드로이드는 첫 애플리케이션 실행시 자동으로 푸시 설정을 on으로 한다.
                    var isFirstSetup = UndercPrefs.GetLocalValue(KEY_FIRST_SETUP, 0) == 0;
                    if (isFirstSetup)
                    {
                        UndercPrefs.SetLocalValue(KEY_FIRST_SETUP, 1);
                        SetEnable(true);
                    }
                    else
                    {
                        isEnabled = result.SetPushOption == PushOption.On;
                    }
                }
            });
        }

        private void SetupNotificationHandler()
        {
            AndroidNotificationCenter.OnNotificationReceived += OnNotificationReceived;
        }

        private int GetSDKInt() 
        {
            using (var version = new AndroidJavaClass("android.os.Build$VERSION")) 
            {
                return version.GetStatic<int>("SDK_INT");
            }
        }

        private void OnNotificationReceived(AndroidNotificationIntentData data)
        {
#if !REAL
            var msg = "Notification received : " + data.Id + "\n";
            msg += "\n Notification received: ";
            msg += "\n .Title: " + data.Notification.Title;
            msg += "\n .Body: " + data.Notification.Text;
            msg += "\n .Channel: " + data.Channel;
            Debug.Log(msg);
#endif
        }

        public INotificationOption CreateOption()
        {
            return new AndroidNotificationOption();
        }

        public void SetEnable(bool isOn)
        {
            isEnabled = isOn;

            Push.SetPushNotification(_Option: isOn ? PushOption.On : PushOption.Off);
        }

        public IEnumerator SetEnableCoroutine(bool isOn)
        {
            isEnabled = isOn;

            bool waitForComplete = true;
            Push.SetPushNotification(_Option: isOn ? PushOption.On : PushOption.Off,
                                     _Result: (PushResult pushResult) => waitForComplete = false);
            while (waitForComplete == true)
            {
                yield return null;
            }
        }
        
        public bool IsEnabled
        {
            get
            {
                return isEnabled;
            }
        }

        public bool Determined
        {
            get
            {
                return false;
            }
        }

        public void SendNotification(INotificationOption notification)
        {
            if (notification == null)
            {
                throw new ArgumentNullException(nameof(notification));
            }

            if (!(notification is AndroidNotificationOption notiData))
            {
                throw new InvalidOperationException("Notification provided to ScheduleNotification isn't an AndroidNotificationData.");
            }

            if (notification.Repeats 
                && notification.RepeatInterval != null
                && notification.RepeatInterval.Value.TotalSeconds > 0)
            {
                notification.DeliveryTime = DateTime.Now.ToLocalTime() + notification.RepeatInterval.Value;
            }

            if (notification.Id.HasValue)
            {
                AndroidNotificationCenter.SendNotificationWithExplicitID(notiData.InternalNotification
                                                                         ,CHANNEL_DEFAULT_ID
                                                                         ,notiData.Id.Value);
            }
            else
            {
                int notificationId = AndroidNotificationCenter.SendNotification(notiData.InternalNotification
                                                                                ,CHANNEL_DEFAULT_ID);

                notification.Id = notificationId;
            }

        }

        public void CancelNotification(int notificationId)
        {
            AndroidNotificationCenter.CancelScheduledNotification(notificationId);
        }

        public void CancelAllNotifications()
        {
            AndroidNotificationCenter.CancelAllScheduledNotifications();
        }

        public void ClearAllDeliveredNotifications()
        {
            AndroidNotificationCenter.CancelAllDisplayedNotifications();
        }
    }
}
#endif