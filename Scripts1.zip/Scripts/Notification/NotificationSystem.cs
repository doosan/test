// 간단한 푸시기능 제공.
// AOS, iOS 특화 기능 분류는 제외하고 같이 동작하도록 구현함.
// AOS같은 경우 채널링 기능을 지원하지않고 기본채널로 묶어서 처리.

using System;
using System.Collections;
using Gaga.System;

namespace Underc.Notification
{
    public sealed class NotificationSystem : Singleton<NotificationSystem>
    {
        private bool isInit;
        private INotificationPlatform platform;

        public void Initialize()
        {
            if (isInit)
            {
                return;
            }

            isInit = true;

#if !UNITY_EDITOR && UNITY_ANDROID
            epoch.Client.Push.Push.Initialize(epoch.Client.Util.PushPlatform.Google);
#elif !UNITY_EDITOR && UNITY_IOS
            epoch.Client.Push.Push.Initialize(epoch.Client.Util.PushPlatform.IOS);          
#endif   

            InitPlatform();
        }

        private void InitPlatform()
        {
#if UNITY_EDITOR
            platform = null;
#elif UNITY_ANDROID
            platform = new AndroidNotificationPlatform();
#elif UNITY_IOS
            platform = new IOSNotificationPlatform();
#endif
        }

        public void SetEnable(bool isOn)
        {
            if (platform != null)
            {
                platform.SetEnable(isOn);
            }
        }

        public IEnumerator SetEnableCoroutine(bool isOn)
        {
            if (platform != null)
            {
                yield return platform.SetEnableCoroutine(isOn);
            }
            yield break;
        }

        public bool IsEnabled
        {
            get
            {
                if (platform == null)
                {
                    return false;
                }

                return platform.IsEnabled;
            }
        }

        public bool Determined
        {
            get
            {
                if (platform == null)
                {
                    return false;
                }

                return platform.Determined;
            }
        }

        public void SendNotification(string title, string body, DateTime deliveryTime)
        {
            SendNotification(int.MinValue, title, null, body, deliveryTime);
        }

        public void SendNotification(string title, string body, TimeSpan repeatInterval)
        {
            SendNotification(int.MinValue, title, null, body, null, repeatInterval);
        }

        public void SendNotification(string title, string subTitle, string body, DateTime deliveryTime)
        {
            SendNotification(int.MinValue, title, subTitle, body, deliveryTime);
        }

        public void SendNotification(string title, string subTitle, string body, TimeSpan repeatInterval)
        {
            SendNotification(int.MinValue, title, subTitle, body, null, repeatInterval);
        }

        public void SendNotification(int id, string title, string body, DateTime deliveryTime)
        {
            SendNotification(id, title, null, body, deliveryTime);
        }

        public void SendNotification(int id, string title, string body, TimeSpan repeatInterval)
        {
            SendNotification(id, title, null, body, null, repeatInterval);
        }

        public void SendNotification(int id, string title, string subTitle, string body, DateTime deliveryTime)
        {
            SendNotification(id, title, subTitle, body, deliveryTime, null);
        }

        public void SendNotification(int id, string title, string subTitle, string body, TimeSpan repeatInterval)
        {
            SendNotification(id, title, subTitle, body, null, repeatInterval);
        }

        private void SendNotification(int id, string title, string subTitle, string body, DateTime? deliveryTime, TimeSpan? repeatInterval)
        {
            if (platform == null)
            {
                return;
            }

            var option = platform.CreateOption();

            if (id != int.MinValue)
            {
                option.Id = id;
            }

            option.Title = title;
            option.Subtitle = subTitle;   
            option.Body = body;
            // 프로젝트에서 뱃지넘버를 사용하지않으므로 강제로 0으로 지정
            option.BadgeNumber = 0;

            if (repeatInterval != null)
            {
                option.Repeats = true;
                option.RepeatInterval = repeatInterval.Value;
            }
            else
            {
                option.Repeats = false;
                option.DeliveryTime = deliveryTime.Value;
            }
             
            platform.SendNotification(option);
        }

        public void CancelNotification(int id)
        {
            if (platform == null)
            {
                return;
            }

            platform.CancelNotification(id);
        }

        public void CancelAllNotifications()
        {
            if (platform == null)
            {
                return;
            }

            platform.CancelAllNotifications();
        }

        public void ClearAllDeliveredNotifications()
        {
            if (platform == null)
            {
                return;
            }
            
            platform.ClearAllDeliveredNotifications();
        }
    }
}