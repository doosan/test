#if UNITY_IOS || UNITY_EDITOR
using System;
using System.Collections;
using Underc.Popup;
using Unity.Notifications.iOS;

namespace Underc.Notification
{
    public sealed class IOSNotificationPlatform : INotificationPlatform
    {
        //private readonly string CHANNEL_DEFAULT_ID          = "default_ch";
        //private readonly string CHANNEL_DEFAULT_NAME        = "default channel";

        public IOSNotificationPlatform(){}

        public INotificationOption CreateOption()
        {
            return new IOSNotificationOption();
        }

        public void SetEnable(bool isOn)
        {
            if (iOSNotificationCenter.GetNotificationSettings().AuthorizationStatus == AuthorizationStatus.NotDetermined)
            {
                if (isOn)
                {
                    var authorizationOption = AuthorizationOption.Alert | AuthorizationOption.Sound | AuthorizationOption.Badge;
                    new AuthorizationRequest(authorizationOption, true);
                }
            }
            else // A-1. iOS 에서는 AuthorizationStatus.NotDetermined 상태 이외에는 
                 // A-2. Noti 설정을 바꿀 수 있는 방법이 없기 때문에 안내 팝업으로 대신한다.
            {
                Popups.IosNotiSetting()
                      .Async();
            }
        }

        public IEnumerator SetEnableCoroutine(bool isOn)
        {
            if (iOSNotificationCenter.GetNotificationSettings().AuthorizationStatus == AuthorizationStatus.NotDetermined)
            {
                if (isOn)
                {
                    var authorizationOption = AuthorizationOption.Alert | AuthorizationOption.Sound | AuthorizationOption.Badge;
                    var req = new AuthorizationRequest(authorizationOption, true);
                    while (req.IsFinished == false)
                    {
                        yield return null;
                    }
                }
            }
            else // A-1. iOS 에서는 AuthorizationStatus.NotDetermined 상태 이외에는 
                 // A-2. Noti 설정을 바꿀 수 있는 방법이 없기 때문에 안내 팝업으로 대신한다.
            {
                yield return Popups.IosNotiSetting()
                                   .Async()
                                   .WaitForClose();
            }

            yield break;
        }

        public bool IsEnabled
        {
            get
            {
                return iOSNotificationCenter.GetNotificationSettings().AuthorizationStatus == AuthorizationStatus.Authorized;
            }
        }

        public bool Determined
        {
            get
            {
                return iOSNotificationCenter.GetNotificationSettings().AuthorizationStatus != AuthorizationStatus.NotDetermined;
            }
        }

        public void SendNotification(INotificationOption notification)
        {
            if (notification == null)
            {
                throw new ArgumentNullException(nameof(notification));
            }

            if (!(notification is IOSNotificationOption notiData))
            {
                throw new InvalidOperationException("Notification provided to ScheduleNotification isn't an IOSNotificationData.");
            }

            iOSNotificationCenter.ScheduleNotification(notiData.InternalNotification);
        }

        public void CancelNotification(int notificationId)
        {
            iOSNotificationCenter.RemoveScheduledNotification(notificationId.ToString());
        }

        public void CancelAllNotifications()
        {
            iOSNotificationCenter.RemoveAllScheduledNotifications();
        }

        public void ClearAllDeliveredNotifications()
        {
            iOSNotificationCenter.RemoveAllDeliveredNotifications();
        }
    }
}
#endif