using System;
using System.Collections;

namespace Underc.Notification
{
    public interface INotificationPlatform
    {
        INotificationOption CreateOption();
        void SetEnable(bool isOn);
        IEnumerator SetEnableCoroutine(bool isOn);
        bool IsEnabled{get;}
        bool Determined{get;}
        void SendNotification(INotificationOption notification);
        void CancelNotification(int notificationId);
        void CancelAllNotifications();
        void ClearAllDeliveredNotifications();
    }
}