using System;
using Underc.User;

namespace Underc.Notification
{
    public static class UndercNotifications
    {
        private static string TITLE = "AQUUUA CASINO";

        private static int testLocalPushType;
        public static void SetTestPush(int type)
        {
            testLocalPushType = type;
        }

        public static void SetNotifications(bool isOn)
        {
            var noti = NotificationSystem.Instance;
            noti.CancelAllNotifications();

            if (noti.IsEnabled == false)
            {
                return;
            }

            if (isOn)
            {
                // 먹이주기
                if (MyInfo.OceanBonus.FeedRemainingSec > 0)
                {
                    var id = 1000000001;
                    var body = "🧂Feed Bonus is ready!\n👉Tap to Claim your 🎁BONUS";
                    var deliveryTime = DateTime.Now.ToLocalTime() + TimeSpan.FromSeconds(MyInfo.OceanBonus.FeedRemainingSec);
                    noti.SendNotification(id, TITLE, body, deliveryTime);

                    Debug.LogFormat("Notification (Feed) - RemainSec : {0} , Date : {1}",MyInfo.OceanBonus.FeedRemainingSec, deliveryTime.ToString("yyyy.MM.dd.HH.mm.ss")); 
                }

                // 오션패스 새 시즌오픈
                if (MyInfo.MissionPass.EndRemainingSec > 0)
                {
                    var id = 1000000002;
                    var body = "🛎NEW Mission Pass season starts now!\n👉Tap to join and check out 😄";
                    var deliveryTime = DateTime.Now.ToLocalTime() + TimeSpan.FromSeconds(MyInfo.MissionPass.EndRemainingSec);
                    noti.SendNotification(id, TITLE, body, deliveryTime);

                    Debug.LogFormat("Notification (OceanPassOpen) - RemainSec : {0} , Date : {1}",MyInfo.MissionPass.EndRemainingSec, deliveryTime.ToString("yyyy.MM.dd.HH.mm.ss")); 
                }

                // 이끼닦이 
                if (MyInfo.OceanBonus.CleanRemainingSec > 0)
                {
                    var id = 1000000003;
                    var body = "😎Come & Enjoy Aquuua Casino!\n👍Don’t miss out lots of fun!";
                    var deliveryTime = DateTime.Now.ToLocalTime() + TimeSpan.FromSeconds(MyInfo.OceanBonus.CleanRemainingSec);
                    noti.SendNotification(id, TITLE, body, deliveryTime);

                    Debug.LogFormat("Notification (NotConnected) - RemainSec : {0} , Date : {1}", MyInfo.OceanBonus.CleanRemainingSec, deliveryTime.ToString("yyyy.MM.dd.HH.mm.ss")); 
                }

                // 데일리스탬프
                if (MyInfo.CasinoBonus.DailyBonusRemainingSec > 0)
                {
                    var id = 1000000004;
                    var body = "Your 🎁Free Daily Bonus is ready ⚡\n📲Tap to claim + spin + win!";
                    var deliveryTime = DateTime.Now.ToLocalTime() + TimeSpan.FromSeconds(MyInfo.CasinoBonus.DailyBonusRemainingSec);
                    noti.SendNotification(id, TITLE, body, deliveryTime);

                    Debug.LogFormat("Notification (DailyBonus) - RemainSec : {0} , Date : {1}",MyInfo.CasinoBonus.DailyBonusRemainingSec, deliveryTime.ToString("yyyy.MM.dd.HH.mm.ss")); 
                }

                // 황금상자
                if (MyInfo.CasinoBonus.GoldenFreeRemainingSec > 0)
                {
                    var id = 1000000005;
                    var body = "Claim your FREE 💥Chest!\n😎TAP to win FISH + FREE Coins!";
                    var deliveryTime = DateTime.Now.ToLocalTime() + TimeSpan.FromSeconds(MyInfo.CasinoBonus.GoldenFreeRemainingSec);
                    noti.SendNotification(id, TITLE, body, deliveryTime);

                    Debug.LogFormat("Notification (GoldChest) - RemainSec : {0} , Date : {1}",MyInfo.CasinoBonus.GoldenFreeRemainingSec, deliveryTime.ToString("yyyy.MM.dd.HH.mm.ss")); 
                }

                // 흑요석상자
                if (MyInfo.CasinoBonus.ObsidianFreeRemainingSec > 0)
                {
                    var id = 1000000006;
                    var body = "🎁EPIC Chest is ready\n😍Get lovely fish+huge coins now❗";
                    var deliveryTime = DateTime.Now.ToLocalTime() + TimeSpan.FromSeconds(MyInfo.CasinoBonus.ObsidianFreeRemainingSec);
                    noti.SendNotification(id, TITLE, body, deliveryTime);

                    Debug.LogFormat("Notification (ObsidianChest) - RemainSec : {0} , Date : {1}",MyInfo.CasinoBonus.ObsidianFreeRemainingSec, deliveryTime.ToString("yyyy.MM.dd.HH.mm.ss")); 
                }

                // 프리코인 보너스
                if (MyInfo.CasinoBonus.FreeBonusRemainingSec > 0)
                {
                    var id = 1000000007;
                    var body = "🎁Your HUGE BONUS is ready! 🎁\n💜Don’t miss out!";
                    var deliveryTime = DateTime.Now.ToLocalTime() + TimeSpan.FromSeconds(MyInfo.CasinoBonus.FreeBonusRemainingSec);
                    noti.SendNotification(id, TITLE, body, deliveryTime);

                    Debug.LogFormat("Notification (ObsidianChest) - RemainSec : {0} , Date : {1}",MyInfo.CasinoBonus.FreeBonusRemainingSec, deliveryTime.ToString("yyyy.MM.dd.HH.mm.ss")); 
                }

                // 미접속자 알림 24시간 간격.
                // iOS에서 로컬푸시등록은 64개가 최대치이므로
                // iOS를 기준으로 총 푸시 갯수가 64개를 넘지않도록 배치한다.
                // 일단 50일까지 등록함.
                // 24:00:00 ~168:00:00 (24시간 ~7 일) - 2,000,000 coin
                // 192:00:00 ~ 336:00:00 (8일 ~14 일) - $ 3 worth of coin
                // 360:00:00 ~ 504:00:00 (15일 ~21 일) - $ 6 worth of coin
                // 528:00:00 ~ 672:00:00 (22일 ~28 일) - $ 12 worth of coin
                // 672:00:01 이상(28일 이상) - $ 15 worth of coin
                {
                    // 24 , 48 , 72, 96, 120, 144, 168

                    string[] coinRewardList = new string[]{"2,000,000", "$ 3 worth of", "$ 6 worth of", "$ 12 worth of", "$ 15 worth of"};

                    int dayCount = 7;
                    int lastDayCount = 22;

                    for (int groupIndex = 0; groupIndex < coinRewardList.Length; groupIndex++)
                    {
                        var days = groupIndex + 1 == coinRewardList.Length ? lastDayCount : dayCount;
                        var rewardValue = coinRewardList[groupIndex];
                        var startDay = dayCount * groupIndex;

                        for (int day = 1; day <= days; day++)
                        {
                            var targetDay = startDay + day;

                            var id = 1000000008;
                            var body = string.Format(System.Globalization.CultureInfo.InvariantCulture, "🎁Claim {0} coin BONUS ! 🎁\n😭WE'VE MISSED YOU!\n👉Tap to Spin and Win!", rewardValue);
                            var deliveryTime = DateTime.Now.ToLocalTime() + TimeSpan.FromDays(targetDay);

                            noti.SendNotification(id, TITLE, body, deliveryTime);

                            Debug.LogFormat("Notification (Unconnected) -  - Day : {0}, Reward : {1}, Date : {2}", targetDay, rewardValue, deliveryTime.ToString("yyyy.MM.dd.HH.mm.ss")); 
                        }
                    }
                }

                SendTestPush(noti);
            }
        }

        public static void ReleaseNotificationLog()
        {
            Debug.Log("Notification ReleaseNotificationLog");

            if (DeepLinkSystem.Instance.HasData)
            {
                var datas = DeepLinkSystem.Instance.FindDatas(DeepLinkSystem.PROTOCOL_PUSH_LOG);

                if (datas != null)
                {
                    for (int i = 0; i < datas.Count; i++)
                    {
                        var data = datas[i];
                        var parameter = data.GetParameter("id");

                        if (string.IsNullOrEmpty(parameter) == false)
                        {
                            int id = int.MinValue;

                            if (int.TryParse(parameter, out id))
                            {
                                Debug.LogFormat("Notification ReleaseNotificationLog : Send log (id:{0})", id);

                                UndercGameLog.Fobis.PushTracking(id);
                                DeepLinkSystem.Instance.RemoveData(data);
                            }
                        }
                    }
                }
                else
                {
                    Debug.Log("Notification ReleaseNotificationLog : deeplink data is null.");
                }
            }
        }

        private static void SendTestPush(NotificationSystem noti)
        {
            if (testLocalPushType == 1)
            {
                var id = 1000000001;
                var title = "TestPush";
                var body = "This is test!\n👉Tap~~";
                var deliveryTime = DateTime.Now.ToLocalTime() + TimeSpan.FromSeconds(10);
                noti.SendNotification(id, title, body, deliveryTime);
            }

            testLocalPushType = 0;
        }
    }
}