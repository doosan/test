using epoch.Client.IAP;
using epoch.Client.Util;
using Gaga.System;
using Gaga.Util;
using Google.Play.Billing;
using Google.Play.Billing.Internal;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Underc.Net;
using Underc.Net.Client;
using Underc.Popup;
using Underc.User;
using UnityEngine;
using UnityEngine.Purchasing;

namespace Underc
{
    public class ProductInfo
    {
        public Product product;
        public string platform;

        // used in android & ios both
        public string transactionID;
        public string receipt;

        // used in android only
        public string signature;

        public string currencyCode;
        public long priceMultiplied;
        public double priceOrigin;
    }

    public class ConsumeInfo
    {
        public bool IsSuccess
        {
            get; private set;
        }

        public string Error
        {
            get; private set;
        }

        public CustomYield.WaitForComplete WaitForComplete
        {
            get; private set;
        }

        public ConsumeInfo()
        {
            WaitForComplete = new CustomYield.WaitForComplete();
        }

        public void UpdateResult(IAPResult result)
        {
            IsSuccess = result.IsSuccess();
            Error = result.GetMessage();

            WaitForComplete.Done();
        }
    }

    [System.Serializable]
    public class LatestPurchaseItemInfo
    {
        public string itemID;
        public int offerID;
        public int couponIndex;

        public LatestPurchaseItemInfo(string itemID, int offerID, int couponIndex)
        {
            this.itemID = itemID;
            this.offerID = offerID;
            this.couponIndex = couponIndex;
        }

        public override string ToString()
        {
            return StringMaker.New()
                              .Append("itemID : " + itemID)
                              .Append(", offerID : " + offerID)
                              .Append(", couponIndex : " + couponIndex)
                              .Build();
        }
    }

    public class FakePurchaseInfo : PurchaseInfo
    {
        private System.Random random = new System.Random();

        public FakePurchaseInfo()
        {
            UpdateProduct();
        }

        public void UpdateProduct()
        {
            string platform;
#if UNITY_ANDROID
            platform = "android";
#elif UNITY_IOS || UNITY_IPHONE
            platform = "ios";
#elif UNITY_STANDALONE_WIN
            platform = "windows";
#elif UNITY_STANDALONE_OSX
            platform = "mac";
#endif

            // dev 서버에서 결제 통과를 위한 가짜 데이터
            string randomTransactionID = CreateFakeTransactionID();
            string randomReceipt = RandomString(10);
            ProductInfo = new ProductInfo()
            {
                product = null,
                platform = platform,
                transactionID = randomTransactionID,
                receipt = randomReceipt,
                signature = "",
                currencyCode = "USD",
                priceMultiplied = 100
            };
        }

        protected string RandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(chars, length)
                                        .Select(s => s[random.Next(s.Length)])
                                        .ToArray());
        }
    }

    public class UserCancelledPurchaseInfo : PurchaseInfo
    {
        public UserCancelledPurchaseInfo()
        {
            IsSuccess = false;
            Error = "UserCancelled";
        }
    }

    public class PurchaseInfo
    {
        public ProductInfo ProductInfo
        {
            get; 
            protected set;
        }

        public bool IsSuccess
        {
            get; 
            protected set;
        }

        public bool IsDuplicateTransaction
        {
            get => Error == "DuplicateTransaction";
        }

        public bool IsUserCancelled
        {
            get => Error == "UserCancelled";
        }

        public string Error
        {
            get; 
            protected set;
        }

        public CustomYield.WaitForComplete WaitForComplete
        {
            get; private set;
        }

        public PurchaseInfo()
        {
            WaitForComplete = new CustomYield.WaitForComplete();
        }

        public void UpdateResult(IAPResult result)
        {
            IsSuccess = result.IsSuccess();
            Error = result.GetMessage();

            if (IsSuccess)
            {
                UpdateProduct(result.ReceiptProduct);
            }

            WaitForComplete.Done();
        }

        public void UpdateProduct(Product product)
        {
#if UNITY_ANDROID
            //구글은 영수증 검증에 필요한 데이터들이 PayLoad Json 안에 담겨 있기 때문에, 편하게 추출하고자 GooglePurchaseData 클래스와 FromJson 함수를 제공해드립니다.
            // PayloadData에선 receipt와 signature를 얻어올 수 있으며,
            // JsonData에선 orderID, packageName, productID, productToken 등을 얻어올 수 있습니다.
            PayloadData payloadData = GooglePurchaseData.FromJson(product.receipt).PayloadData;
            ProductMetadata productMetadata = product.metadata;
            ProductInfo = new ProductInfo()
            {
                product = product,
                platform = "android",
                transactionID = product.transactionID,
                receipt = payloadData.json,
                signature = payloadData.signature,
                currencyCode = productMetadata.isoCurrencyCode,
                priceMultiplied = (long)(productMetadata.localizedPrice * 100),
                priceOrigin = Decimal.ToDouble(productMetadata.localizedPrice)
            };
#elif UNITY_IOS || UNITY_IPHONE
            //IOS는 ReceiptData에 IOSTransactionID를 그대로 담아 전송하면 됩니다.
            string transactionReceipt = IAP.GetIOSReceiptData(product);
            ProductMetadata productMetadata = product.metadata;
            ProductInfo = new ProductInfo()
            {
                product = product,
                platform = "ios",
                transactionID = product.transactionID,
                receipt = transactionReceipt,
                signature = string.Empty,
                currencyCode = productMetadata.isoCurrencyCode,
                priceMultiplied = (long)(productMetadata.localizedPrice * 100),
                priceOrigin = Decimal.ToDouble(productMetadata.localizedPrice)
            };
#endif
        }

        protected string CreateFakeTransactionID()
        {
            return string.Format("FakeTransaction{0}", UnityEngine.Random.Range(1,100));
        }
    }

    public class PurchaseInPending
    {
        public PurchaseInfo purchaseInfo;
        public bool isInPending;

        public PurchaseInPending(PurchaseInfo purchaseInfo)
        {
            this.purchaseInfo = purchaseInfo;
            isInPending = true;
        }
    }

    public enum PurchaseFailStep
    { 
        None,
        StorePurchaseFail = 1,
        ExchangeFail      = 2,
        ConsumeFail       = 3
    }

    public class PurchaseSystem : GameObjectSingleton<PurchaseSystem>
    {
        public bool IsFailed
        {
            get;
            private set;
        }
        public bool IsUserCancelled
        {
            get;
            private set;
        }
        public bool ShowReward
        {
            private get;
            set;
        }
        public CustomYield.WaitForComplete WaitForInit
        {
            get;
            private set;
        }
        public PurchaseFailStep FailStep
        { 
            get; 
            set; 
        }
        private PurchaseFailStep targetFailStep;

        private const string KEY_LATEST_PURCHASE_ITEM_INFO = "key_latest_purchase_item_info";

        private Dictionary<string, StoreProduct> storeProducts = new Dictionary<string, StoreProduct>();
        private Queue<PurchaseInfo> purchaseInfos = new Queue<PurchaseInfo>();
        private List<RewardData> rewardDatas = new List<RewardData>();
        private event Action onInit;

        private HashSet<string> exchangesHistory = new HashSet<string>();
        private Dictionary<string, PurchaseInfo> purchasesInPending = new Dictionary<string, PurchaseInfo>();

        private bool isInSearch;
        private bool initOnce;

        private GooglePlayStoreImpl giap;
        private IStoreController storeContollerCache;
        private Action<Product> deferredPurchaseListenerCache;

        private string itemID;
        private int? offerID;
        private int couponIndex;
        private Action onFail;

        private PurchaseInfo purchasedInfo;

        public RewardData GetRewardData(RewardType rewardType)
        {
            return rewardDatas.FirstOrDefault(rewardData => rewardData.Type == rewardType);
        }

        public void InitStoreItems()
        {
            WaitForInit = new CustomYield.WaitForComplete();

#if UNITY_ANDROID == true
            IAP.SetMarketStore(StoreOption.GooglePlayStore);
#elif UNITY_IOS == true || UNITY_IPHONE == true
            IAP.SetMarketStore(StoreOption.AppleInAppStore);
#endif

            // 위에서 세팅한 마켓 정보를 가지고 IAP를 Initialilze 합니다.
            // 마켓 Init시 PlayFab 및 UnityIAP와 연동하여 몇가지 정보를 가져오므로, Init 타이밍은 PlayFab 로그인 이후에 호출해야 합니다.
#if UNITY_EDITOR == false
            IAP.InitializePurchase(OnInitialized);
#else
            initOnce = true;
#endif
        }

        public IEnumerator CheckIfStoreInit(Action<string> onFail)
        {
            if (initOnce == false)
            {
                Popups.ShowLoading();
                InitStoreItems();

                bool timeOut = false;
                float timeBegin = Time.time;
                while (initOnce == false)
                {
                    float timePassed = Time.time - timeBegin;
                    if (timePassed > 10)
                    {
                        timeOut = true;
                        break;
                    }

                    yield return null;
                }

                Popups.HideLoading();
                if (timeOut == true)
                {
                    onFail?.Invoke("Failed to initialze the store.");
                }
            }

            yield break;
        }

        private void OnInitialized(IAPResult result)
        {
            Debug.Log("==== OnInitialized : " + result.ToString());
            initOnce = true;

            storeProducts.Clear();
            if (result.IsSuccess())
            {
                foreach (StoreProduct item in IAP.GetStoreItemData())
                {
                    // Result에 현재 PlayFab Catalog에 등록된 아이템들이 epoch.Client.IAP.StoreProduct List를 포함하여 Return됩니다.
                    // epoch.Client.IAP.IAP.GetStoreItemData()를 호출하여 어디서든 Catalog Data를 사용할 수 있습니다.
                    storeProducts.Add(item.ItemID, item);
                    Debug.Log("==== Store Item : " + item.Store + ", " + item.ItemID + ", " + item.Despcription + ", " + item.PurchasePrice);
                }
            }

            WaitForInit.Done();
            onInit?.Invoke();

            ReadPendingPurchases();

#if UNITY_EDITOR == false && UNITY_ANDROID == true
            PrepareBillingStateDisconnected();
#endif

#if UNITY_EDITOR == false
            PrepareStoreController();
            //if (storeContollerCache != null)
            //{
            //    foreach (Product product in storeContollerCache.products.all)
            //    {
            //        if (product == null)
            //        {
            //            continue;
            //        }

            //        StringMaker.StringInfo stringInfo = StringMaker.New();
            //        stringInfo.Append("==== Product : ");
            //        ProductDefinition productDefinition = product.definition;
            //        if (productDefinition != null)
            //        {
            //            stringInfo.Append(productDefinition.storeSpecificId);
            //            stringInfo.Append(", ");
            //        }
            //        ProductMetadata productMetadata = product.metadata;
            //        if (productMetadata != null)
            //        {
            //            stringInfo.Append(productMetadata.isoCurrencyCode.ToString());
            //            stringInfo.Append(", ");
            //            stringInfo.Append(productMetadata.localizedPrice.ToString());
            //        }
            //        Debug.Log(stringInfo.Build());
            //    }
            //}
#endif
        }

        private PurchaseInfo BuyProduct(string productID, Action onComplete = null)
        {
            var purchaseInfo = new PurchaseInfo();
            IAP.BuyProductID(productID, /* OnPurchaseSuccess */(IAPResult result) =>
            {
                purchaseInfo.UpdateResult(result);
                onComplete?.Invoke();
            });

            return purchaseInfo;
        }

        private ConsumeInfo ConsumeItem(Product product, Action onComplete = null)
        {
            var consumeInfo = new ConsumeInfo();
            IAP.ConsumeItem(product, /* OnConsumeSuccess */(IAPResult result) =>
            {
                consumeInfo.UpdateResult(result);
                onComplete?.Invoke();
            });

            return consumeInfo;
        }

        private void PrepareStoreController()
        {
            Type iapType = typeof(IAP);
            FieldInfo iapFieldInfo = iapType.GetField("IAPInterface",
                                                      BindingFlags.Static | BindingFlags.NonPublic);
            if (iapFieldInfo == null) return;

#if UNITY_ANDROID == true
            IAPGooglePlayStore iiap = iapFieldInfo.GetValue(null) as IAPGooglePlayStore;
            if (iiap == null) return;

            Type iiapType = typeof(IAPGooglePlayStore);
            FieldInfo iiapFieldInfo = iiapType.GetField("StoreController",
                                                         BindingFlags.Static | BindingFlags.NonPublic);
            if (iiapFieldInfo == null) return;

            storeContollerCache = iiapFieldInfo.GetValue(iiap) as IStoreController;

#elif UNITY_IOS == true || UNITY_IPHONE == true
            IAPAppleInAppStore iiap = iapFieldInfo.GetValue(null) as IAPAppleInAppStore;
            if (iiap == null) return;

            Type iiapType = typeof(IAPAppleInAppStore);
            FieldInfo iiapFieldInfo = iiapType.GetField("StoreController",
                                                         BindingFlags.Static | BindingFlags.NonPublic);
            if (iiapFieldInfo == null) return;

            storeContollerCache = iiapFieldInfo.GetValue(iiap) as IStoreController;
#endif
        }

        /// <summary>
        /// 0. CS-3891 이슈를 수정하기 위한 코드입니다.
        /// 1. 게임 플레이 중 특정 시점에 billingStateListener 인스턴스의 OnBillingServiceDisconnected 이벤트와 OnBillingSetupFinished 이벤트가 호출됩니다.
        /// 2. 이 때 결제 모듈이 관련된 프로퍼티들을 다시 세팅하는데, 이 과정 중에 앞서 IAP.InitializePurchase() 메서드를 통해 세팅되었던 _deferredPurchaseListener 콜백의 값이 유실됩니다.
        /// 3. 이에 따라 상점 초기화 시점에 미리 해당 콜백 값을 저장해 두고 추후 OnBillingSetupFinished 이벤트가 호출되었을 때 외부에서 직접 그 값을 다시 할당해 줍니다.
        /// </summary>
        private void PrepareBillingStateDisconnected()
        {
            // Getting IAPGooglePlayStore
            Type iapType = typeof(IAP);
            FieldInfo iapFieldInfo = iapType.GetField("IAPInterface",
                                                      BindingFlags.Static | BindingFlags.NonPublic);
            if (iapFieldInfo == null) return;

            IAPGooglePlayStore iiap = iapFieldInfo.GetValue(null) as IAPGooglePlayStore;
            if (iiap == null) return;

            // Getting GooglePlayStoreImpl
            Type iiapType = typeof(IAPGooglePlayStore);
            FieldInfo iiapFieldInfo = iiapType.GetField("GoogleExtensions",
                                                        BindingFlags.Static | BindingFlags.NonPublic);
            if (iiapFieldInfo == null) return;

            giap = iiapFieldInfo.GetValue(iiap) as GooglePlayStoreImpl;
            if (giap == null) return;

            Type giapType = typeof(GooglePlayStoreImpl);
            // Getting deferredPurchaseListener
            FieldInfo giapFieldInfo = giapType.GetField("_deferredPurchaseListener",
                                                        BindingFlags.Instance | BindingFlags.NonPublic);
            if (giapFieldInfo == null) return;

            deferredPurchaseListenerCache = giapFieldInfo.GetValue(giap) as Action<Product>;
            if (deferredPurchaseListenerCache == null) return;

            // Getting BillingClientStateListener
            giapFieldInfo = giapType.GetField("_billingClientStateListener",
                                              BindingFlags.Instance | BindingFlags.NonPublic);
            if (giapFieldInfo == null) return;

            BillingClientStateListener billingStateListener = giapFieldInfo.GetValue(giap) as BillingClientStateListener;
            if (billingStateListener == null) return;

            Debug.Log("==== billingStateListener : " + billingStateListener);
            billingStateListener.OnBillingSetupFinished += OnBillingSetupFinished;
        }

        private void OnBillingSetupFinished(AndroidJavaObject billingResult)
        {
            StartCoroutine(ResetDeferredPurchaseListenerCoroutine());
        }

        public IEnumerator ResetDeferredPurchaseListenerCoroutine()
        {
            Debug.Log("==== ResetDeferredPurchaseListenerCoroutine");
            /// 등록된 다른 이벤트보다 뒤늦게 호출하기 위함
            yield return null;

            Type giapType = typeof(GooglePlayStoreImpl);
            FieldInfo giapFieldInfo = giapType.GetField("_billingClientReady",
                                                        BindingFlags.Instance | BindingFlags.NonPublic);
            if (giapFieldInfo == null) yield break;

            bool billingReady = (bool)giapFieldInfo.GetValue(giap);
            if (billingReady == true)
            {
                MethodInfo giapMethodInfo = giapType.GetMethod("SetDeferredPurchaseListener");
                giapMethodInfo.Invoke(giap, new object[] { deferredPurchaseListenerCache });
            }
        }

        public Queue<PurchaseInfo> GetPendingPurchases()
        {
            return purchaseInfos;
        }

        /// Consume 처리가 되지 않아 아직 구매 중인 상품으로 잡혀 있는 상품의 경우
        /// 구매 처리가 완료 되기 전까지 같은 이름의 상품은 구매가 되지 않습니다.
        /// Consume 처리가 되지 않은 상품의 경우 IAP가 초기화 될 때 epochSDK내에 품목들이 저장됩니다.
        /// epoch.Client.IAP.IAP.GetRemainTransactions() 로 Consume 되지 않은 상품들을 받아 올 수 있습니다.
        public void ReadPendingPurchases()
        {
            Debug.Log("==== SearchPendingPurchase : " + isInSearch);
            if (isInSearch == false)
            {
                StartCoroutine(_ReadPendingPurchases(1f));
            }
        }

        private IEnumerator _ReadPendingPurchases(float delay)
        {
            isInSearch = true;
            yield return new WaitForSeconds(delay);

            IAP.GetRemainTransactions(products =>
            {
                if (products != null)
                {
                    Debug.Log("==== Purchase Remain Transactions : " + products.Count);
                    foreach (Product product in products)
                    {
                        var purchaseInfo = new PurchaseInfo();
                        purchaseInfo.UpdateProduct(product);
                        purchaseInfos.Enqueue(purchaseInfo);
                        Debug.Log("==== \tPurchase Remain Transactions id: " + purchaseInfo.ProductInfo.product.definition.storeSpecificId);
                    }
                }

                isInSearch = false;
            });
        }

        private void ConsumeFailStep()
        {
            targetFailStep = FailStep;
            FailStep = PurchaseFailStep.None;
        }

        private bool CheckFailStep(PurchaseFailStep currFailStep)
        {
            bool result = false;

            if (targetFailStep != PurchaseFailStep.None
                && (int)currFailStep >= (int)targetFailStep)
            {
                result = true;
            }

            return result;
        }

        private IEnumerator Exchange()
        {
            if (IsFailed)
            {
                yield break;
            }
            else if (CheckFailStep(PurchaseFailStep.ExchangeFail))
            {
                OpenFailPopup(targetFailStep.ToString(), null);
                yield break;
            }

            Debug.Log("==== Purchase Step 2 - Exchange");
            ProductInfo productInfo = purchasedInfo.ProductInfo;
            if (productInfo != null
                && exchangesHistory.Contains(productInfo.transactionID) == false)
            {
                Debug.Log("==== Purchase Step 2-1");
                Popups.ShowLoading();
                /// 서버에 구매한 상품 데이터 보내기
                var req = NetworkSystem.HTTPRequester.Purchase(sessionTicket: Auth.AccountSystem.SessionTicket,
                                                               itemID: itemID,
                                                               offerID: offerID,
                                                               couponIndex: couponIndex,
                                                               productInfo: productInfo);
                yield return req.WaitForResponse();
                Popups.HideLoading();

                if (req.isSuccess == false
                    && req.data.error != "1022" /* 이미 확인되어 서버에 반영된 영수증이면 발생하는 에러 넘버 */)
                {
                    OpenFailPopup(req.data.error, purchasedInfo);
                    yield break;
                }

                Debug.Log("==== Purchase Step 2-2");
                /// 1022 에러에 대해 Fail 팝업을 띄우기 않은 이유는 Epoch 에 상품 소비를 요청하기 위함
                if (req.data.error != "1022")
                {
                    ExtractRewardDatas(req.data);
                }

                // 첫 결제시 로그를 전송.
                if (req.data.cnt == 1)
                {
                    UndercGameLog.Firebase.PurchaseFirst(productInfo.priceOrigin, productInfo.currencyCode);
                    UndercGameLog.Singular.PurchaseFirst(productInfo.priceOrigin, productInfo.currencyCode);
                }

                MyInfo.VipClass.Update(req.data.vip_class, req.data.vip_point);
                MyInfo.Deal.Update(req.data.deal);

                exchangesHistory.Add(productInfo.transactionID);
            }

            yield break;
        }

        public void ExtractRewardDatas(PurchaseResponse purchaseResponse)
        {
            ExtractRewardDatas(purchaseResponse.coin,
                               purchaseResponse.pearl,
                               purchaseResponse.ticket,
                               purchaseResponse.golden,
                               purchaseResponse.obsidian,
                               purchaseResponse.xp_booster,
                               purchaseResponse.pearl_booster,
                               purchaseResponse.fish,
                               purchaseResponse.bonus_coin,
                               purchaseResponse.vip_point);
        }

        private void ExtractRewardDatas(long coin,
                                        long pearl,
                                        long ticket,
                                        long golden, 
                                        long obsidian, 
                                        long xpBooster, 
                                        long pearlTicketBooster,
                                        int fish,
                                        long bonusCoin,
                                        long vipPoint)
        {
            rewardDatas.Clear();
            if (coin > 0)
            {
                rewardDatas.Add(new RewardData(RewardData.COIN, coin, additionalVipPoint: vipPoint));
            }
            if (pearl > 0)
            {
                rewardDatas.Add(new RewardData(RewardData.PEARL, pearl));
            }
            if (ticket > 0)
            {
                rewardDatas.Add(new RewardData(RewardData.TICKET, ticket));
            }
            if (golden > 0)
            {
                rewardDatas.Add(new RewardData(RewardData.GOLDEN, golden));
            }
            if (obsidian > 0)
            {
                rewardDatas.Add(new RewardData(RewardData.OBSIDIAN, obsidian));
            }
            if (xpBooster > 0)
            {
                rewardDatas.Add(new RewardData(RewardData.XP_BOOSTER, xpBooster));
            }
            if (pearlTicketBooster > 0)
            {
                rewardDatas.Add(new RewardData(RewardData.PEARL_TICKET_BOOSTER, pearlTicketBooster));
            }
            if (fish > 0)
            {
                rewardDatas.Add(new RewardData(RewardData.FISH, fish, additionalCoin: bonusCoin));
            }
            if (coin == 0
                && vipPoint > 0)
            {
                rewardDatas.Add(new RewardData(RewardData.VIP_POINT, vipPoint));
            }
        }

        private IEnumerator Consume()
        {
            if (IsFailed)
            {
                yield break;
            }
            else if (IsFakeEnvironment())
            {
                yield break;
            }
            else if (CheckFailStep(PurchaseFailStep.ConsumeFail))
            {
                OpenFailPopup(targetFailStep.ToString(), null);
                yield break;
            }

            /// Epoch 에 상품 소비 시도
            Debug.Log("==== Purchase Step 3 - Consume : " + IsFailed);
            ProductInfo productInfo = purchasedInfo.ProductInfo;
            if (productInfo != null)
            {
                Popups.ShowLoading();
                ConsumeInfo consumeInfo = ConsumeItem(productInfo.product);
                yield return consumeInfo.WaitForComplete;
                Popups.HideLoading();

                if (consumeInfo.IsSuccess == false)
                {
                    OpenFailPopup(consumeInfo.Error, purchasedInfo);
                    yield break;
                }

                string itemID = productInfo.product.definition.storeSpecificId;
                if (purchasesInPending.ContainsKey(itemID) == true)
                {
                    purchasesInPending.Remove(itemID);
                }
            }

            yield break;
        }

        private void WriteLatestPurchaseItemInfo()
        {
            /// 구매 복원이 일어날 때는 itemID 이외의 값은 알 수 없으므로 로컬에 따로 저장해 둠
            int latestOfferID = (offerID != null) ? offerID.Value : -1;
            int latestCouponIndex = couponIndex;
            LatestPurchaseItemInfo itemInfo = new LatestPurchaseItemInfo(itemID, latestOfferID, latestCouponIndex);

            string latestPurchaseItemInfo = JsonUtility.ToJson(itemInfo);
            UndercPrefs.SetLocalValue(KEY_LATEST_PURCHASE_ITEM_INFO, latestPurchaseItemInfo);
        }

        private void ReadLatestPurchaseItemInfo()
        {
            string localValue = UndercPrefs.GetLocalValue(KEY_LATEST_PURCHASE_ITEM_INFO);
            UndercPrefs.SetLocalValue(KEY_LATEST_PURCHASE_ITEM_INFO, "");

            couponIndex = -1;
            offerID = null;
            if (string.IsNullOrEmpty(localValue) == false)
            {
                LatestPurchaseItemInfo latestPurchaseItemInfo = JsonUtility.FromJson<LatestPurchaseItemInfo>(localValue);
                Debug.Log("==== ReadLatestPurchaseItemInfo : " + latestPurchaseItemInfo);
                if (latestPurchaseItemInfo.itemID == itemID)
                {
                    offerID = latestPurchaseItemInfo.offerID;
                    couponIndex = latestPurchaseItemInfo.couponIndex;
                }
            }
            else
            {
                Debug.Log("==== ReadLatestPurchaseItemInfo : empty");
            }
        }

        public IEnumerator PendingPurchase(string itemID, PurchaseInfo pendingPurchaseInfo, bool showReward)
        {
            this.itemID = itemID;
            this.purchasedInfo = pendingPurchaseInfo;
            this.ShowReward = showReward;

            ReadLatestPurchaseItemInfo();

            yield return Exchange();
            yield return Consume();
            yield return Reward();
        }

        public bool IsFakeEnvironment()
        {
#if DEV
            return true;
#else
            return false;
#endif
        }

        public IEnumerator Purchase(string itemID, 
                                    int? offerID = null, 
                                    int couponIndex = -1,
                                    Action onFail = null, 
                                    bool showReward = true)
        {
            this.itemID = itemID;
            this.offerID = offerID;
            this.couponIndex = couponIndex;
            this.onFail = onFail;
            this.ShowReward = showReward;

            IsFailed = false;
            IsUserCancelled = false;
            purchasedInfo = null;
            ConsumeFailStep();

            yield return StorePurchase();
            yield return Exchange();
            yield return Consume();
            yield return Reward();
        }

        private IEnumerator StorePurchase()
        {
            if (CheckFailStep(PurchaseFailStep.StorePurchaseFail))
            {
                OpenFailPopup(targetFailStep.ToString(), new UserCancelledPurchaseInfo());
                yield break;
            }
            else if (IsFakeEnvironment())
            {
                purchasedInfo = new FakePurchaseInfo();
                yield break;
            }
            
            Debug.Log("=== Purchase Step 1 - Purchase : " + itemID);
#if UNITY_EDITOR == false && (UNITY_ANDROID == true || UNITY_IOS == true || UNITY_IPHONE == true)
            if (storeProducts.ContainsKey(itemID) == false)
            {
                Popups.ShowLoading();
                
                float timeBegin = Time.time;
                float timePassed = 0f;
                while (storeProducts.ContainsKey(itemID) == false
                       && timePassed < 3f)
                {
                    timePassed = Time.time - timeBegin;
                    yield return null;
                }

                Popups.HideLoading();

                if (storeProducts.ContainsKey(itemID) == false)
                {
                    Debug.LogWarning("스토어에 존재하지 않는 상품이므로 결제 요청을 하지 않습니다 : " + itemID + ", " + storeProducts.Count);
                    OpenFailPopup("Store pruducts are not ready.", null);
                    yield break;
                }
            }
#endif
            /// Epoch 에 상품 구매 요청
            Debug.Log("=== Purchase Step 1-1 : " + itemID);
            Popups.ShowLoading();
            
            PurchaseInfo buyInfo = BuyProduct(itemID);
            yield return buyInfo.WaitForComplete;
            Popups.HideLoading();

            if (buyInfo.IsSuccess == false
                && buyInfo.IsDuplicateTransaction == false)
            {
                OpenFailPopup(buyInfo.Error, buyInfo);
                yield break;
            }
            else
            {
                WriteLatestPurchaseItemInfo();
            }

            purchasedInfo = buyInfo;

            Debug.Log("=== Purchase Step 1-2 : " + purchasedInfo.ProductInfo);
            if (purchasedInfo.ProductInfo == null)
            {
                // 중복된 구매 요청이면 이전에 저장해놓은 상품 정보를 리턴
                if (purchasedInfo.IsDuplicateTransaction == true
                    && purchasesInPending.ContainsKey(itemID) == true)
                {
                    purchasedInfo = purchasesInPending[itemID];
                }
            }
            else
            {
                // 중복된 구매 요청을 대비해 상품 정보를 저장
                purchasesInPending[purchasedInfo.ProductInfo.product.definition.storeSpecificId] = purchasedInfo;
            }
            yield break;
        }

        public IEnumerator Reward()
        {
            if (IsFailed)
            {
                yield break;
            }

            Debug.Log("=== Purchase Step 4 - Reward : " + ShowReward + ", " + rewardDatas.Count);
            if (ShowReward == true
                && rewardDatas.Count > 0)
            {
                yield return Popups.RewardView(rewardDatas: rewardDatas.ToArray(),
                                               location: RewardViewPopup.Location.Purchase)
                                   .WaitForClose();
                rewardDatas.Clear();
            }

            yield break;
        }

        private void OpenFailPopup(string message, PurchaseInfo purchaseInfo)
        {
            IsFailed = true;
            IsUserCancelled = purchaseInfo != null ?
                              purchaseInfo.IsUserCancelled :
                              false;
            onFail?.Invoke();

            if (purchaseInfo != null
                && purchaseInfo.ProductInfo != null)
            {
                message = purchaseInfo.ProductInfo.transactionID;
            }

            // 유저가 취소한 결제건은 무시
            if (IsUserCancelled == false 
                && string.IsNullOrEmpty(message) == false)
            {
                Popups.PurchaseFail(message)
                      .Async()
                      .Cache();
            }
        }
    }
}
