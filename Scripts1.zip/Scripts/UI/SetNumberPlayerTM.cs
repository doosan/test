using Gaga;
using Gaga.UI;
using UnityEngine;
using TMPro;
using Gaga.Util;

namespace Underc.UI
{
    public class SetNumberPlayerTM : MonoBehaviour
    {
        public enum PlayType
        {
            Manual,
            Awake,
            Enable,
            Start
        }

        [SerializeField] private PlayType playType;
        [SerializeField] private TextMeshProUGUI text;
        [SerializeField] private EasingFunction.Ease ease = EasingFunction.Ease.Linear;

        public TextMeshProUGUI Text
        {
            get => text;
        }

        public string prefix;
        public string suffix;

        public long startValue = 0L;
        public long endValue = 0L;
        public float duration = 1f;

        public bool useKMB = false;
        public StringUtils.KMBOption kmbOption = new StringUtils.KMBOption();

        private void Awake()
        {
            if (playType == PlayType.Awake)
            {
                Play();
            }
        }

        private void OnEnable()
        {
            if (playType == PlayType.Enable)
            {
                Play();
            }
        }

        private void Start()
        {
            if (playType == PlayType.Start)
            {
                Play();
            }
        }

        public void Play()
        {
            if (text == null)
            {
                return;
            }

            Play(startValue, endValue, duration, ease, prefix, suffix);
        }

        public void Play(long startValue, 
                         long endValue, 
                         float duration, 
                         EasingFunction.Ease ease, 
                         string prefix = "", 
                         string suffix = "")
        {
            text.SetNumber(startValue, true, prefix, suffix, 0.0f, EasingFunction.Ease.Linear, useKMB, kmbOption);
            text.SetNumber(endValue, true, prefix, suffix, duration, ease, useKMB, kmbOption);
        }

        public void Stop(bool reset = false)
        {
            var targetNum = reset ? 0L : endValue;
            text.SetNumber(targetNum, true, prefix, suffix, 0.0f);
        }
    }
}
