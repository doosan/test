using System;
using System.Collections;
using UnityEngine;

namespace Underc.UI
{
    public enum UpdateContentType
    { 
        First,
        Refresh,
    }

    [RequireComponent(typeof(RectTransform))]
    public abstract class BaseContentPanel : MonoBehaviour
    {
        public Action OnRefresh
        {
            protected get
            {
                if (onRefresh == null)
                {
                    Debug.LogWarning($"==== {gameObject.name}.onRefresh is null");
                }
                return onRefresh;
            }
            set
            {
                onRefresh = value;
            }
        }
        private Action onRefresh;

        public Action<string> OnError
        {
            protected get
            {
                if (onError == null)
                {
                    Debug.LogWarning($"==== {gameObject.name}.onError is null");
                }
                return onError;
            }
            set
            {
                onError = value;
            }
        }
        private Action<string> onError;

        public Action OnClose
        {
            protected get;
            set;
        }

        public abstract void Init();

        public abstract void Reset();

        public abstract bool Close();

        public abstract IEnumerator UpdateContent(UpdateContentType updateType);

        public abstract bool CanBack();
    }
}