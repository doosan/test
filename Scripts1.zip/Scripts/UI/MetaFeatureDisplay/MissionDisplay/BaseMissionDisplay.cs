using Gaga.Popup;
using Gaga.Util;
using System;
using System.Collections;
using TMPro;
using Underc.Net;
using Underc.Net.Client;
using Underc.Popup;
using Underc.User;
using UnityEngine;

namespace Underc.UI
{
    public class BaseMissionDisplay : BaseMetaFeatureDisplay
    {
        [Header("# Complete")]
        [SerializeField] protected TextMeshProUGUI nextTimeText;

        public Func<bool> CheckTimeout
        {
            private get;
            set;
        }
        public Action OnTimeout;

        private const float LOAD_INTERVAL = 3f;
        private static float latestLoadTime = 0;

        private Coroutine updateNextTimeCoroutine;

        protected void StopUpdateNextTime()
        {
            if (updateNextTimeCoroutine != null)
            {
                StopCoroutine(updateNextTimeCoroutine);
                updateNextTimeCoroutine = null;
            }
        }

        protected void UpdateNextTime(Func<long> GetRemainingSec,
                                      TextMeshProUGUI timeText = null,
                                      Func<bool> IsRewardInProgress = null,
                                      bool loadMission = true,
                                      bool show = true)
        {
            if (updateNextTimeCoroutine != null)
            {
                StopCoroutine(updateNextTimeCoroutine);
            }
            if (gameObject.activeInHierarchy)
            {
                updateNextTimeCoroutine = StartCoroutine(UpdateNextTimeCoroutine(
                    GetRemainingSec, 
                    timeText,
                    IsRewardInProgress, 
                    loadMission,
                    show
                ));
            }
        }

        protected IEnumerator UpdateNextTimeCoroutine(Func<long> GetRemainingSec,
                                                      TextMeshProUGUI timeText,
                                                      Func<bool> IsRewardInProgress,
                                                      bool loadMission,
                                                      bool show)
        {
            while (true)
            {
                long remainingSec = GetRemainingSec();
                //Debug.Log($"remainingSec : {remainingSec.ToSummaryDHMS()}");
                if (timeText != null)
                {
                    timeText.text = remainingSec.ToSummaryDHMS();
                }

                if (remainingSec <= 0)
                {
                    while (PopupSystem.Instance.IsOpen<MissionPassPopup>())
                    {
                        // 대기
                        yield return null;
                    }

                    if (IsRewardInProgress != null
                        && IsRewardInProgress())
                    {
                        // 종료
                        yield break;
                    }
                    else if (CheckTimeout != null
                             && CheckTimeout())
                    {
                        Debug.Log($"==== CheckTimeout : {GetType().Name}, {loadMission}, {show}");
                        if (loadMission)
                        {
                            yield return LoadMission();
                        }

                        if (show)
                        {
                            Show(isProgressive: false);
                        }

                        MyInfo.AquaBlitz.FindLatestMissionSpinIndex();
                        OnTimeout?.Invoke();
                        //Debug.Log($"==== {GetType().Name}.onTimeout()");
                        // 따로 인포 업데이트에 대한 리스너가 없기 때문에 셀프로 갱신
                    }
                }
                
                yield return MyInfo.CasinoBonus.WaitForTimeUpdate(this);
            }
        }

        protected IEnumerator LoadMission(Action onLoad = null)
        {
            if (Time.time - latestLoadTime > LOAD_INTERVAL)
            {
                latestLoadTime = Time.time;

                IRequest<MissionResponse> req;
                if (RunAsFake == false)
                {
                    req = NetworkSystem.HTTPRequester.Mission();
                }
                else
                {
                    req = FakeHttpRequester.Instance.Mission();
                }
                yield return req.WaitForResponse();

                if (req.isSuccess == true)
                {
                    NetworkSystem.HTTPHandler.Do(req.data);
                    onLoad?.Invoke();
                }
            }

            yield break;
        }
    }
}