using DG.Tweening;
using Gaga.UI;
using System;
using System.Collections.Generic;
using Underc.User;
using UnityEngine;

namespace Underc.UI
{
    public enum AquaBlitzDisplayAnimState
    { 
        Lock,
        Idle,
    }

    public class AquaBlitzDisplay : BaseMissionDisplay
    {
        [Header("# Aqua Blitz Display")]
        [SerializeField] private List<RadialGauge> radialGauges;
        
        public float Progress
        {
            get;
            private set;
        }

        private MyAquaBlitz AquaBlitz
        {
            get
            {
                if (aquaBlitz == null)
                {
                    aquaBlitz = MyInfo.AquaBlitz;
                }
                return aquaBlitz;
            }
        }
        private MyAquaBlitz aquaBlitz;

        private AquaBlitzDisplayAnimState animState;

        public override void Reset()
        {
            foreach (RadialGauge radialGauge in radialGauges)
            {
                radialGauge.SetProgress(value: 0f, animation: false);
            }
        }

        public override void Show(bool isProgressive, Action onComplete = null)
        {
            UpdateAnimState();
            UpdateContent(isProgressive, onComplete);
            if (animState == AquaBlitzDisplayAnimState.Idle)
            {
                UpdateNextTime(
                    GetRemainingSec: () => MyInfo.AquaBlitz.MissionEndRemainingSec,
                    timeText: nextTimeText
                );
            }
        }

        public override void Hide()
        {
            StopUpdateNextTime();
        }

        private void UpdateAnimState()
        {
            DailyMissionDisplayInfo dailyMissionDisplayInfo = MyInfo.DailyMission.DisplayInfo;
            bool isLock = dailyMissionDisplayInfo != null
                          && dailyMissionDisplayInfo.unlockState != FeatureDisplayUnlockState.Unlock;

            animState = isLock ?
                        AquaBlitzDisplayAnimState.Lock :
                        AquaBlitzDisplayAnimState.Idle;
        }

        private void UpdateContent(bool isProgressive, Action onComplete)
        {
            string slotID = MyInfo.SlotGame.currentSlotID;
            //Debug.Log($"==== UpdateContent() : {slotID}, {MyInfo.AquaBlitz.LatestMissionSpinIndex}, {AquaBlitz.GetCurrentMissionInfo()}");
            if (string.IsNullOrEmpty(slotID) == false
                && MyInfo.AquaBlitz.LatestMissionSpinIndex != -1)
            {
                AquaBlitzMissionInfo nextMissionInfo = AquaBlitz.GetCurrentMissionInfo();
                if (nextMissionInfo != null)
                {
                    Progress = nextMissionInfo.curr / (float)nextMissionInfo.all;

                    TweenCallback onCompleteTween = null;
                    if (onComplete != null)
                    {
                        onCompleteTween = () => onComplete.Invoke();
                    }
                    
                    foreach (RadialGauge radialGauge in radialGauges)
                    {
                        radialGauge.SetProgress(Progress, isProgressive, onCompleteTween);
                    }
                }
            }
        }
    }
}