using DG.Tweening;
using Gaga.Popup;
using Gaga.Sound;
using Gaga.Util;
using System;
using System.Collections;
using TMPro;
using Underc.Popup;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.UI
{
    public enum MissionPassDisplayAnimState
    {
        None,
        Lock,
        Idle,
        IdleBounce,
    }

    public class MissionPassDisplay : BaseMissionDisplay
    {
        [Header("# Mission Pass Display")]
        [SerializeField] private Animator animator;

        [Header("Badge")]
        [SerializeField] private GameObject badgeObject;
        [SerializeField] private TextMeshProUGUI badgeText;

        [Header("Lock")]
        [SerializeField] private float unlockDelay = .5f;
        [SerializeField] private SlantedText unlockLevelText;
        [SerializeField] private AnimatorParser unlockAnimation;
        [SerializeField] private SoundPlayer unlockSound;

        private MissionPassDisplayAnimState prevAnimState;
        private MissionPassDisplayAnimState currAnimState;
        private bool IsAnimStateChanged
        {
            get => currAnimState != prevAnimState;
        }

        private MyMissionPass MissionPass
        { 
            get
            {
                if (missionPass == null)
                {
                    missionPass = MyInfo.MissionPass;
                }
                return missionPass;
            }
        }
        private MyMissionPass missionPass;

        private void OnEnable()
        {
            MissionPass.onDisplayInfoUpdate -= OnDisplayInfoUpdate;
            MissionPass.onDisplayInfoUpdate += OnDisplayInfoUpdate;
        }

        private void OnDisable()
        {
            MissionPass.onDisplayInfoUpdate -= OnDisplayInfoUpdate;
        }

        public override void Reset()
        {
            SetAnimState(MissionPassDisplayAnimState.Idle);
        }

        public override bool IsInLock()
        {
            return currAnimState == MissionPassDisplayAnimState.Lock;
        }

        public void OpenMissionPassPopup()
        {
            UndercGameLog.Fobis.ButtonLobbyMenu(1);

            StartCoroutine(OpenMissionPassPopupCoroutine());
        }

        private IEnumerator OpenMissionPassPopupCoroutine()
        {
            PopupObject<MissionPassPopup> popupObject = null;
            popupObject = Popups.MissionPass(tab: MissionPassPopupTab.MissionPass,
                                             syncData: true,
                                             onInit: () =>
                                             {
                                                 if (popupObject != null)
                                                 {
                                                     popupObject.GetPopup().RunAsFake = RunAsFake;
                                                 }
                                             })
                                .Async()
                                .Cache();
            yield return popupObject.WaitForClose();
        }

        private void OnDisplayInfoUpdate()
        {
            Show(isProgressive: false);
        }

        public override void Show(bool isProgressive, Action onComplete = null)
        {
            UpdateAnimState();
            UpdateContent();
            if (currAnimState == MissionPassDisplayAnimState.Idle
                || currAnimState == MissionPassDisplayAnimState.IdleBounce)
            {
                UpdateNextTime(
                    GetRemainingSec: () => MyInfo.MissionPass.EndRemainingSec,
                    timeText: nextTimeText,
                    loadMission: true,
                    show: false
                );
            }
        }

        public override void Hide()
        {
            Reset();
            StopUpdateNextTime();
        }

        public IEnumerator UnlockCoroutine()
        {
            Unlock();
            nextTimeText.text = MyInfo.MissionPass.EndRemainingSec.ToSummaryDHMS();

            unlockSound.Play();
            yield return unlockAnimation.WaitForDuration(unlockDelay);
        }

        public void Unlock()
        {
            animator.SetBool(DailyMissionDisplayAnimState.Lock.ToString(), false);
        }

        private void SetAnimState(MissionPassDisplayAnimState nextAnimState)
        {
            //Debug.Log($"==== MissionPassDisplay.SetAnimState : {currAnimState} -> {nextAnimState}");
            prevAnimState = currAnimState;
            currAnimState = nextAnimState;
        }

        private void UpdateAnimState()
        {
            DailyMissionDisplayInfo dailyMissionDisplayInfo = MyInfo.DailyMission.DisplayInfo;
            bool isLock = dailyMissionDisplayInfo != null
                          && dailyMissionDisplayInfo.unlockState != FeatureDisplayUnlockState.Unlock;
            int badgeCount = MissionPass.TotalRewardCount;

            //Debug.Log($"==== MissionPassDisplay.UpdateAnimState : " +
            //          $"{bannerInfo.unlockState}, " +
            //          $"{MissionPass.EndRemainSec}, " +
            //          $"{MissionPass.AllCleared}, " +
            //          $"{MissionPass.TotalRewardCount}");

            MissionPassDisplayAnimState nextAnimState;
            if (isLock)
            {
                nextAnimState = MissionPassDisplayAnimState.Lock;
            }
            else
            {
                nextAnimState = (badgeCount > 0) ?
                                MissionPassDisplayAnimState.IdleBounce :
                                MissionPassDisplayAnimState.Idle;
            }

            SetAnimState(nextAnimState);
        }

        private void UpdateContent()
        {
            DailyMissionDisplayInfo displayInfo = MyInfo.DailyMission.DisplayInfo;
            bool isLock = displayInfo != null
                          && displayInfo.unlockState != FeatureDisplayUnlockState.Unlock;
            int unlockLevel = displayInfo.unlockLevel;

            // Badge
            int badgeCount = MissionPass.TotalRewardCount;
            badgeObject.SetActive(isLock == false && badgeCount > 0);
            badgeText.text = StringUtils.ToSingleUnit(badgeCount);

            // Level
            unlockLevelText.text = StringMaker.New()
                                              .Append("LV.")
                                              .Append(unlockLevel.ToString())
                                              .Build();

            //
            if (IsAnimStateChanged)
            {
                if (currAnimState == MissionPassDisplayAnimState.Lock)
                {
                    animator.SetBool(currAnimState.ToString(), true);
                }
                else
                {
                    animator.SetTrigger(currAnimState.ToString());
                }
            }
        }
    }
}
