using Gaga.Sound;
using Gaga.UI;
using Gaga.Util;
using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using Underc.User;
using UnityEngine;

namespace Underc.UI
{
    public enum DailyMissionDisplayAnimState
    {
        None,
        Lock,
        Idle,
        Complete,
    }

    public class DailyMissionDisplay : BaseMissionDisplay
    {
        [Header("# Daily Mission Display")]
        [SerializeField] private Animator animator;

        [Header("# Full")]
        [SerializeField] private AnimatorParser fullAnimation;
        [SerializeField] private SoundPlayer fullSound;
        [SerializeField] private TextMeshProUGUI nameText;

        [Header("# Respawn")]
        [SerializeField] private AnimatorParser respawnAnimation;
        [SerializeField] private SoundPlayer respawnSound;

        [Header("# Badge")]
        [SerializeField] private GameObject badgeObject;
        [SerializeField] private TextMeshProUGUI badgeText;

        [Header("# Lock")]
        [SerializeField] private float unlockDelay = .5f;
        [SerializeField] private SlantedText unlockLevelText;
        [SerializeField] private AnimatorParser unlockAnimation;
        [SerializeField] private SoundPlayer unlockSound;

        [Header("# Idle")]
        [SerializeField] private List<RadialGauge> radialGauges;
        [SerializeField] private float attentionDelay = 0f;
        [SerializeField] private AnimatorParser attentionAnimation;

        private DailyMissionDisplayAnimState prevAnimState;
        private DailyMissionDisplayAnimState currAnimState;
        private bool IsAnimStateChanged
        {
            get => prevAnimState != DailyMissionDisplayAnimState.None
                   && currAnimState != prevAnimState;
        }

        private MyDailyMission DailyMission
        {
            get
            {
                if (dailyMission == null)
                {
                    dailyMission = MyInfo.DailyMission;
                }
                return dailyMission;
            }
        }
        private MyDailyMission dailyMission;
        
        private CanvasGroup CachedCanvasGroup
        { 
            get
            {
                if (cachedCanvasGroup == null)
                {
                    cachedCanvasGroup = GetComponent<CanvasGroup>();
                }
                return cachedCanvasGroup;
            }
        }
        private CanvasGroup cachedCanvasGroup;

        public override void Reset()
        {
            SetAnimState(DailyMissionDisplayAnimState.Idle);
            UpdateAnimContent();

            unlockLevelText.text = "";

            badgeObject.SetActive(false);
            badgeText.text = "";

            foreach (RadialGauge radialGauge in radialGauges)
            {
                radialGauge.SetProgress(0f, false);
            }
        }

        public override void Show(bool isProgressive, Action onComplete = null)
        {
            UpdateAnimState();
            UpdateContent(isProgressive);
            if (currAnimState == DailyMissionDisplayAnimState.Idle
                || currAnimState == DailyMissionDisplayAnimState.Complete)
            {
                UpdateNextTime(
                    GetRemainingSec: () => DailyMission.MissionEndRemainingSec,
                    timeText: nextTimeText,
                    IsRewardInProgress: () => DailyMission.DisplayInfo != null
                                              && DailyMission.DisplayInfo.RewardInProgress
                );
            }
        }

        public override void Hide()
        {
            Reset();
            StopUpdateNextTime();
        }

        public override bool IsInLock()
        {
            return currAnimState == DailyMissionDisplayAnimState.Lock;
        }

        public IEnumerator UnlockCoroutine()
        {
            Unlock();

            unlockSound.Play();
            yield return unlockAnimation.WaitForDuration(unlockDelay);
        }

        public void Unlock()
        {
            animator.SetBool(DailyMissionDisplayAnimState.Lock.ToString(), false);
        }

        public IEnumerator Full()
        {
            if (nameText != null)
            {
                nameText.gameObject.SetActive(false);
            }

            fullAnimation.SetTrigger();
            fullSound.Play();

            yield return fullAnimation.WaitForDuration();
        }

        public IEnumerator Respawn()
        {
            respawnAnimation.SetTrigger();
            respawnSound.Play();

            SetAsVisible();
            yield return respawnAnimation.WaitForDuration();
        }

        private void SetAnimState(DailyMissionDisplayAnimState nextAnimState)
        {
            //Debug.Log("==== DailyMissionDisplay.SetAnimState : " + currAnimState + " -> " + nextAnimState);
            prevAnimState = currAnimState;
            currAnimState = nextAnimState;
        }

        public void UpdateAnimState()
        {
            DailyMissionDisplayInfo bannerInfo = DailyMission.DisplayInfo;
            bool isComplete = bannerInfo != null
                              && bannerInfo.unlockState == FeatureDisplayUnlockState.Unlock
                              && bannerInfo.Progress == 0f
                              && bannerInfo.step == 0;

            bool isLock = bannerInfo != null
                          && bannerInfo.unlockState != FeatureDisplayUnlockState.Unlock;

            DailyMissionDisplayAnimState nextAnimState = isComplete ? DailyMissionDisplayAnimState.Complete :
                                                         isLock ? DailyMissionDisplayAnimState.Lock :
                                                         DailyMissionDisplayAnimState.Idle;
            SetAnimState(nextAnimState);
        }

        public void UpdateContent(bool animation)
        {
            DailyMissionDisplayInfo displayInfo = DailyMission.DisplayInfo;
            if (displayInfo != null)
            {
                if (displayInfo.ConsumeStepChange() != 0)
                {
                    UpdateProgressContent(0f, false);
                }
                UpdateProgressContent(displayInfo.Progress, animation);
                UpdateOtherContent(displayInfo.BadgeCount, 
                                   displayInfo.unlockLevel);
                UpdateAnimContent();
            }
        }

        public void UpdateProgressContent(float value, bool animation)
        {
            //Debug.Log($"==== UpdateProgressContent : {name}, {value}");
            foreach (RadialGauge radialGauge in radialGauges)
            {
                if (radialGauge.Progress != value
                    && value != 0
                    && animation == true
                    && attentionDelay > 0f)
                {
                    ProgressDuration = attentionDelay + attentionAnimation.Duration;
                    StartCoroutine(SetDelayedProgress(value, animation));
                }
                else
                {
                    ProgressDuration = radialGauge.GaugeDelay + radialGauge.GaugeDuration;
                    radialGauge.SetProgress(value, animation);
                }
            }
        }

        private IEnumerator SetDelayedProgress(float value, bool animation)
        {
            yield return new WaitForSeconds(attentionDelay);
            if (attentionAnimation != null)
            {
                attentionAnimation.SetTrigger();
            }
            foreach (RadialGauge radialGauge in radialGauges)
            { 
                radialGauge.SetProgress(value, animation);
            }
        }

        public void UpdateOtherContent(int badgeCount, int unlockLevel)
        {
            // Badge
            //badgeObject.SetActive(badgeCount > 0);
            badgeText.text = badgeCount.ToString();

            // Level
            unlockLevelText.text = StringMaker.New()
                                              .Append("LV.")
                                              .Append(unlockLevel.ToString())
                                              .Build();

            // Time
            if (DailyMission.MissionEndRemainingSec > 0)
            {
                nextTimeText.text = DailyMission.MissionEndRemainingSec.ToSummaryDHMS();
            }
        }

        public void UpdateAnimContent()
        {
            if (IsAnimStateChanged)
            {
                if (currAnimState == DailyMissionDisplayAnimState.Complete)
                {
                    animator.SetTrigger(currAnimState.ToString());
                    SetAsVisible();
                }
                else if (currAnimState == DailyMissionDisplayAnimState.Lock)
                {
                    animator.SetBool(currAnimState.ToString(), true);
                }
                else if (prevAnimState == DailyMissionDisplayAnimState.Complete
                         && currAnimState == DailyMissionDisplayAnimState.Idle)
                {
                    animator.SetTrigger(currAnimState.ToString());
                }
            }
        }

        private void SetAsVisible()
        {
            if (CachedCanvasGroup != null)
            {
                CachedCanvasGroup.alpha = 1;
            }
        }
    }
}