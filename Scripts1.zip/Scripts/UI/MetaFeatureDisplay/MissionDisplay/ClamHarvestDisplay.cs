using Gaga.Popup;
using Gaga.Util;
using System;
using System.Collections;
using TMPro;
using Underc.Popup;
using Underc.User;
using UnityEngine;

namespace Underc.UI
{
    public enum ClamHarvestDisplayAnimState
    { 
        None,
        Lock,
        Wait,
        Open
    }

    public class ClamHarvestDisplay : BaseMissionDisplay
    {
        [Header("# Clam Harvest Display")]
        [SerializeField] private Animator animator;

        [Header("Badge")]
        [SerializeField] private GameObject badgeObject;
        [SerializeField] private TextMeshProUGUI badgeText;

        [Header("Lock")]
        [SerializeField] private SlantedText unlockLevelText;

        private ClamHarvestDisplayAnimState prevAnimState;
        private ClamHarvestDisplayAnimState currAnimState;
        private bool IsAnimStateChanged
        {
            get => prevAnimState != ClamHarvestDisplayAnimState.None
                   && currAnimState != prevAnimState;
        }
        public bool ShowBadge
        {
            private get;
            set;
        }

        private MyClamHarvest ClamHarvest
        {
            get
            {
                if (clamHarvest == null)
                {
                    clamHarvest = MyInfo.ClamHarvest;
                }
                return clamHarvest; 
            }
        }
        private MyClamHarvest clamHarvest;

        public override void Reset()
        {
            SetAnimState(ClamHarvestDisplayAnimState.Wait);
        }

        public override bool IsInLock()
        {
            return currAnimState == ClamHarvestDisplayAnimState.Lock;
        }

        public override void Show(bool isProgressive, Action onComplete = null)
        {
            UpdateAnimState();
            UpdateContent();
            UpdateNextTime();

            ClamHarvest.onDisplayInfoUpdate.RemoveListener(OnDisplayInfoUpdate);
            ClamHarvest.onDisplayInfoUpdate.AddListener(OnDisplayInfoUpdate);
        }

        public override void Hide()
        {
            Reset();
            StopUpdateNextTime();

            ClamHarvest.onDisplayInfoUpdate.RemoveListener(OnDisplayInfoUpdate);
        }

        public void Unlock()
        {
            animator.SetBool(ClamHarvestDisplayAnimState.Lock.ToString(), false);
        }

        private void OnDisplayInfoUpdate()
        {
            if (gameObject.activeInHierarchy)
            {
                UpdateAnimState();
                UpdateContent();
                UpdateNextTime();
            }
        }

        private void UpdateAnimState()
        {
            DailyMissionDisplayInfo dailyMissionDisplayInfo = MyInfo.DailyMission.DisplayInfo;

            bool isLock = dailyMissionDisplayInfo != null
                          && dailyMissionDisplayInfo.unlockState != FeatureDisplayUnlockState.Unlock;
            bool isOpen = isLock == false
                          && ClamHarvest.StartRemainingSec <= 0;


            ClamHarvestDisplayAnimState nextAnimState = isOpen ? ClamHarvestDisplayAnimState.Open :
                                                        isLock ? ClamHarvestDisplayAnimState.Lock :
                                                        ClamHarvestDisplayAnimState.Wait;
            SetAnimState(nextAnimState);
        }

        private void SetAnimState(ClamHarvestDisplayAnimState nextAnimState)
        {
            //Debug.Log("==== ClamHarvestDisplay.SetAnimState : " + currAnimState + " -> " + nextAnimState);
            prevAnimState = currAnimState;
            currAnimState = nextAnimState;
        }

        public void UpdateContent()
        {
            // Badge
            int pickaxCount = ClamHarvest.DisplayInfo.pickax;
            badgeObject.SetActive(ShowBadge == true && pickaxCount > 0);
            badgeText.text = pickaxCount.ToString();

            // Level
            int unlockLevel = MyInfo.DailyMission.DisplayInfo.unlockLevel;
            unlockLevelText.text = $"LV.{unlockLevel}";
                
            // Time
            long startRemainingSec = ClamHarvest.StartRemainingSec;
            if (startRemainingSec > 0)
            {
                nextTimeText.text = startRemainingSec.ToSummaryDHMS();
            }

            // Anim
            if (IsAnimStateChanged)
            {
                if (currAnimState == ClamHarvestDisplayAnimState.Open)
                {
                    animator.SetTrigger(currAnimState.ToString());
                }
                else if (currAnimState == ClamHarvestDisplayAnimState.Lock)
                {
                    animator.SetBool(currAnimState.ToString(), true);
                }
                else if (prevAnimState == ClamHarvestDisplayAnimState.Open
                         && currAnimState == ClamHarvestDisplayAnimState.Wait)
                {
                    animator.SetTrigger(currAnimState.ToString());
                }
            }
        }

        private void UpdateNextTime()
        {
            if (currAnimState == ClamHarvestDisplayAnimState.Wait)
            {
                UpdateNextTime(
                    GetRemainingSec: () => ClamHarvest.StartRemainingSec,
                    timeText: nextTimeText,
                    loadMission: false,
                    show: true
                );
            }
            else if (currAnimState == ClamHarvestDisplayAnimState.Open)
            {
                UpdateNextTime(
                    GetRemainingSec: () => ClamHarvest.EndRemainingSec,
                    loadMission: true,
                    show: false
                );
            }
        }

        public void OpenClamHarvestPopup()
        {
            StartCoroutine(OpenClamHarvestPopupCoroutine());
        }

        private IEnumerator OpenClamHarvestPopupCoroutine()
        {
            PopupObject<MissionPassPopup> popupObject = null;
            popupObject = Popups.MissionPass(tab: MissionPassPopupTab.ClamHarvest,
                                             onInit: () =>
                                             {
                                                 if (popupObject != null)
                                                 {
                                                     popupObject.GetPopup().RunAsFake = RunAsFake;
                                                 }
                                             })
                                .Async()
                                .Cache();
            yield return popupObject.WaitForClose();
        }
    }
}