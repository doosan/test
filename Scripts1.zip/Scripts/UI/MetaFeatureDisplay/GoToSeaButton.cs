using UnityEngine;
using Underc.User;
using UnityEngine.UI;
using Gaga.Util;

namespace Underc.UI
{
    [RequireComponent(typeof(Button))]
    public sealed class GoToSeaButton : BaseMetaFeatureDisplay
    {
        [SerializeField] private GameObject lockView;
        [SerializeField] private SlantedText lockText;

        private void OnEnable()
        {
            UpdateLock();
        }

        public override bool IsInLock()
        {
            return MyInfo.Ocean.IsSeaUnlocked == false;
        }

        private void UpdateLock()
        {
            var unlock = MyInfo.Ocean.IsSeaUnlocked;
            lockView.SetActive(!unlock);

            if (unlock == false)
            {
                lockText.text = StringMaker.New()
                                           .Append("LV.")
                                           .Append(MyInfo.Ocean.SeaUnlockLevel.ToString())
                                           .Build();
            }
        }
    }
}