using Gaga.Sound;
using Gaga.Util;
using System.Collections;
using Underc.User;
using UnityEngine;

namespace Underc.UI
{
    public class AquaBlitzIcon : BaseMissionIcon
    {
        [SerializeField] private AquaBlitzDisplay display;

        [Header("Full")]
        [SerializeField] private SoundPlayer fullSound;
        [SerializeField] private AnimatorParser fullAnimation;

        private AquaBlitzMissionInfo prevMissionInfo;
        private Coroutine fullCoroutine;

        public override MissionIconType Type
        {
            get => MissionIconType.AquaBlitz;
        }

        public override BaseMissionDisplay Display
        {
            get => display;
        }

        public override bool IsInFull
        {
            get => display.Progress >= 1;
        }

        public override void UpdateInfo(bool isProgressive)
        {
            display.Show(isProgressive: isProgressive);
        }

        public override IEnumerator UpdateInfoCoroutine()
        {
            display.Show(isProgressive: true, OnUpdateInfoComplete);
            yield break;
        }

        private void OnUpdateInfoComplete()
        {
            if (display.Progress >= 1)
            {
                Full();
            }
        }

        public override IEnumerator BeginCoroutine()
        {
            if (display.IsInLock() == false)
            {
                AquaBlitzMissionInfo missionInfo = MyInfo.AquaBlitz.GetCurrentMissionInfo();
                if (missionInfo != null
                    && missionInfo.missionFormatInfo != null)
                {
                    yield return NextCoroutine(missionInfo.missionFormatInfo);
                }
            }

            yield break;
        }

        public override void Full()
        {
            if (fullCoroutine == null)
            {
                fullCoroutine = StartCoroutine(FullCoroutine());
            }
        }

        private IEnumerator FullCoroutine()
        {
            if (CanvasGroup.alpha == 1)
            {
                fullSound.Play();
            }

            fullAnimation.SetTrigger();
            yield return fullAnimation.WaitForDuration();
            fullCoroutine = null;
        }

        protected override void CacheMissionInfo()
        {
            prevMissionInfo = MyInfo.AquaBlitz.GetCurrentMissionInfo().Clone();
        }

        protected override bool DiffMissionInfo()
        {
            AquaBlitzMissionInfo nextMissionInfo = MyInfo.AquaBlitz.GetCurrentMissionInfo();
            return prevMissionInfo != null
                   && prevMissionInfo.Equals(nextMissionInfo) == false;
        }

        protected override MissionFormatInfo GetMissionFormatInfo()
        {
            return MyInfo.AquaBlitz.GetCurrentMissionInfo().missionFormatInfo;
        }
    }
}
