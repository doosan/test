using Gaga.Popup;
using Gaga.Util;
using System;
using System.Collections;
using Underc.Popup;
using Underc.User;
using UnityEngine;

namespace Underc.UI
{
    public class DailyMissionIcon : BaseMissionIcon
    {
        [SerializeField] private DailyMissionDisplay display;
        [SerializeField] private AnimatorParser collectNowAnimation;

        public override MissionIconType Type
        {
            get => MissionIconType.DailyMission;
        }

        public override BaseMissionDisplay Display
        {
            get => display;
        }

        public override void UpdateInfo(bool isProgressive)
        {
            display.Show(isProgressive: isProgressive);
        }

        public override IEnumerator UpdateInfoCoroutine()
        {
            DailyMissionDisplayInfo displayInfo = MyInfo.DailyMission.DisplayInfo;
            if (displayInfo.CurrChange > 0
                && displayInfo.Progress == 1)
            {
                yield return WaitAndUpdateInfo();
            }
            else
            {
                display.Show(isProgressive: true);
                yield break;
            }
        }

        public override IEnumerator BeginCoroutine()
        {
            if (display.IsInLock() == false)
            {
                DailyMissionDisplayInfo displayInfo = MyInfo.DailyMission.DisplayInfo;
                if (displayInfo != null
                    && displayInfo.Progress < 1
                    && displayInfo.missionFormatInfo != null)
                {
                    yield return NextCoroutine(displayInfo.missionFormatInfo);
                }
            }

            yield break;
        }

        public override void Unlock()
        {
            display.Unlock();
        }

        public override IEnumerator UnlockCoroutine()
        {
            yield return SetActiveCoroutine(
                subCoroutine: display.UnlockCoroutine(),
                letMeSwitch: false
            );
        }

        public IEnumerator GetReward(Func<bool> IsInPlay, Func<BaseMissionIcon> GetActiveMissionIcon)
        {
            // 대기하다가
            while (IsInPlay() == false
                   || IsInState(MissionIconState.PopupOpen) == true
                   || PopupSystem.Instance.Count > 0)
            {
                Debug.Log($"==== GetReward() : {IsInPlay()}, {IsInState(MissionIconState.PopupOpen)}, {PopupSystem.Instance.Count > 0}");
                yield return null;
            }

            // 연출 로직 시작
            yield return SetActiveCoroutine(
                subCoroutine: GetRewardCoroutine(GetActiveMissionIcon),
                letMeSwitch: true
            );
        }

        private IEnumerator GetRewardCoroutine(Func<BaseMissionIcon> GetActiveIcon)
        {
            while (true)
            {
                BaseMissionIcon activeIcon = GetActiveIcon();
                if (activeIcon == this
                    && activeIcon.IsInState(MissionIconState.Switch) == false)
                {
                    // A-1. Switch 상태일 때는 대기,
                    // A-2. Switch 상태가 끝나면 이탈
                    break;
                }

                yield return null;
            }
            
            bool autoProgressEnabled = IsSlotMachineInHold == false;
            yield return new WaitForSeconds(display.ProgressDuration);

            // 1. 보상 획득 연출 팝업
            PopupObject<DailyMissionRewardPopup> rewardPopupObject = null;
            DailyMissionRewardPopup rewardPopup = null;
            rewardPopupObject = Popups.DailyMissionReward(
                dailyMissionDisplay: display,
                autoProgressEnabled: autoProgressEnabled,
                onOpen: () =>
                {
                    rewardPopup = rewardPopupObject.GetPopup();
                    rewardPopup.RunAsFake = display.RunAsFake;
                }
            ).Async().Cache();

            yield return rewardPopupObject.WaitForClose();

            if (rewardPopup.ConsumePointRewarded())
            {
                yield return rewardPopup.OriginPointGauge.ToComplete();
            }

            MyDailyMission dailyMission = MyInfo.DailyMission;
            // 2. 데일리 미션 스텝 연출
            MissionPassPopup missionPassPopup = rewardPopup.MissionPassPopup;
            yield return missionPassPopup.UpdateProgressiveContent(
                tab: MissionPassPopupTab.DailyMission, 
                contentType: UpdateSpecificContentType.Mission
            );

            // 3. 디스플레이 갱신
            display.Show(isProgressive: true);

            // 4. 데일리 미션 완료시 아이콘 제거
            if (dailyMission.DisplayInfo.step == 0)
            {
                OnRemove.Invoke();
            }

            // 5. 보상 진행 중 상태 지워주고
            dailyMission.DisplayInfo.ConsumeRewardInProgress();

            // 6. 마지막 미션이 아니었다면 데일리 퀘스트 배너 갱신 연출
            if (dailyMission.DisplayInfo.step > 0)
            {
                yield return display.Respawn();

                StartCoroutine(NextCoroutine(dailyMission.DisplayInfo.missionFormatInfo));
            }
        }
    }
}