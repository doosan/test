using System.Collections;
using UnityEngine;

namespace Underc.UI
{ 
    public class MissionPassIcon : BaseMissionIcon
    {
        [SerializeField] private MissionPassDisplay display;

        public override MissionIconType Type
        {
            get => MissionIconType.MissionPass;
        }

        public override BaseMissionDisplay Display
        {
            get => display;
        }

        public override void UpdateInfo(bool isProgressive)
        {
            display.Show(isProgressive: isProgressive);
        }

        public override IEnumerator UnlockCoroutine()
        {
            yield return display.UnlockCoroutine();
        }
    }
}