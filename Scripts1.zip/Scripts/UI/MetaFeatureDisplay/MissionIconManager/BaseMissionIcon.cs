using Gaga.Popup;
using Gaga.Sound;
using Gaga.System;
using Gaga.Util;
using SlotGame.Machine;
using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using Underc.Popup;
using Underc.Scene;
using Underc.User;
using UnityEngine;
using UnityEngine.Serialization;

namespace Underc.UI
{
    [Flags]
    public enum MissionIconState
    { 
        None = 0,
        Switch = 1,
        PopupOpen = 2
    }

    public enum MissionTextState
    {
        Next,
        Reset
    }

    [Serializable]
    public class MissionTextObject
    {
        public MissionTextState state;
        public GameObject gameObject;
    }

    public abstract class BaseMissionIcon : MonoBehaviour
    {
        [SerializeField] private MetaFeatureLockButton button;

        [Header("Switch")]
        [SerializeField] private AnimatorParser switchAnimation;

        [Header("Next Left")]
        [SerializeField] private List<MissionTextObject> missionTextObjectsLeft;
        [SerializeField] private TextMeshProUGUI nextMissionTextLeft;
        [SerializeField] private AnimatorParser nextAnimationLeft;

        [Header("Next Right")]
        [SerializeField] private List<MissionTextObject> missionTextObjectsRight;
        [FormerlySerializedAs("nextMissionText")]
        [SerializeField] private TextMeshProUGUI nextMissionTextRight;
        [FormerlySerializedAs("nextAnimation")]
        [SerializeField] private AnimatorParser nextAnimationRight;

        [Header("Sound")]
        [SerializeField] private SoundPlayer nextMissionSound;

        public abstract MissionIconType Type
        {
            get;
        }

        public MetaFeatureLockButton Button
        {
            get => button;
        }

        public virtual BaseMissionDisplay Display
        {
            get => null;
        }

        public virtual bool IsInFull
        {
            get => false; 
        }

        public RectTransform CachedTransform
        {
            get
            {
                if (cachedTransform == null)
                {
                    cachedTransform = GetComponent<RectTransform>();
                }
                return cachedTransform;
            }
        }
        private RectTransform cachedTransform;

        public CanvasGroup CanvasGroup
        {
            get
            {
                if (canvasGroup == null)
                {
                    canvasGroup = GetComponent<CanvasGroup>();
                }
                return canvasGroup;
            }
        }
        private CanvasGroup canvasGroup;

        public Action<int> OnActive
        {
            private get;
            set;
        }

        public virtual bool IsActive
        {
            get
            {
                return activeCount > 0;
            }
        }
        private int activeCount;

        public Action<MissionIconType> OnSwitch
        {
            private get;
            set;
        }

        // 미션 아이콘 전체 갱신
        public Action OnUpdate
        {
            private get;
            set;
        }

        public Action OnRemove
        {
            protected get;
            set;
        }

        public int Index
        {
            get;
            set;
        }

        private AnimatorParser NextAnimation
        {
            get => ScreenSystem.IsLandscape ? nextAnimationRight : nextAnimationLeft;
        }

        public TextMeshProUGUI NextMissionText
        {
            get => ScreenSystem.IsLandscape ? nextMissionTextRight : nextMissionTextLeft;
        }

        private SlotMachine slotMachine;
        private static MissionIconState State;

        public bool IsInState(MissionIconState state)
        {
            return (State & state) == state;
        }

        private void AddState(MissionIconState state)
        {
            State |= state;
            Debug.Log($"==== BaseMissionIcon.AddState : {State}");
        }

        private void RemoveState(MissionIconState state)
        {
            State &= ~state;
            Debug.Log($"==== BaseMissionIcon.RemoveState : {state} -> {State}");
        }

        protected bool IsSlotMachineInHold
        {
            get
            {
                return slotMachine != null
                       && slotMachine.holdType == SlotMachine.HoldType.On;
            }
        }

        private void PauseSlotMachine(bool value)
        {
            if (slotMachine != null)
            {
                if (value)
                {
                    slotMachine.Pause();
                }
                else
                {
                    slotMachine.Resume();
                }
            }
        }

        public void SetActive(bool value, bool letMeSwitch)
        {
            activeCount += (value == true) ? 1 : -1;
            if (value && letMeSwitch)
            {
                OnActive?.Invoke(Index);
            }
        }

        public void Init(SlotMachine slotMachine, int index)
        {
            this.slotMachine = slotMachine;
            this.Index = index;

            if (slotMachine != null)
            {
                Debug.Log($"==== {GetType().Name}.State = 0");
                State = 0;
            }
            activeCount = 0;
        }

        public abstract void UpdateInfo(bool isProgressive);

        public virtual IEnumerator UpdateInfoCoroutine() { yield break; }

        public virtual IEnumerator BeginCoroutine() { yield break; }

        public virtual void Unlock() { }

        public virtual IEnumerator UnlockCoroutine() 
        {
            yield break;
        }
        
        public void Click() 
        {
            string activeScene = SceneSystem.ActiveScene;
            bool isInGameScene = (activeScene == SceneSystem.GameScene || activeScene == SceneSystem.GameScenePortrait);

            bool isSlotMachineInIdle = slotMachine != null
                                        && (slotMachine.CurrentState == SlotMachineState.RESULT_END
                                            || slotMachine.CurrentState == SlotMachineState.IDLE);

            bool syncData = isInGameScene ? isSlotMachineInIdle : true;

            StartCoroutine(SetActiveCoroutine(
                subCoroutine: OpenMissionPassPopupCoroutine(
                    tab: (MissionPassPopupTab)(int)Type,
                    syncData: syncData
                ),
                letMeSwitch: false
            ));
        }

        private IEnumerator OpenMissionPassPopupCoroutine(MissionPassPopupTab tab, bool syncData)
        {
            AddState(MissionIconState.PopupOpen);
            
            PauseSlotMachine(true);

            CacheMissionInfo();

            PopupObject<MissionPassPopup> popupObject = null;
            popupObject = Popups.MissionPass(tab: tab,
                                             syncData: syncData,
                                             onInit: () => popupObject.GetPopup().RunAsFake = Display.RunAsFake)
                                .Async()
                                .Cache();
            yield return popupObject.WaitForClose();

            if (DiffMissionInfo())
            {
                StartCoroutine(NextCoroutine(GetMissionFormatInfo()));
            }

            OnUpdate?.Invoke();

            PauseSlotMachine(false);

            RemoveState(MissionIconState.PopupOpen);
        }

        protected virtual void CacheMissionInfo()
        {

        }

        protected virtual bool DiffMissionInfo()
        {
            return false;
        }

        protected virtual MissionFormatInfo GetMissionFormatInfo()
        {
            return null;
        }

        public virtual void Switch(bool showBadge = false)
        {
            OnSwitch?.Invoke(Type);
        }

        public IEnumerator ResetCoroutine()
        {
            UpdateMissionTextState(MissionTextState.Reset);
            nextMissionSound.Play();
            yield return NextAnimationCoroutine();
        }

        public IEnumerator NextCoroutine(MissionFormatInfo missionFormatInfo)
        {
            if (missionFormatInfo != null)
            {
                UpdateMissionTextState(MissionTextState.Next);
                NextMissionText.text = missionFormatInfo.GetFormat(missionFormatColor: MissionFormatColor.Brown, linebreak: "\n");
                nextMissionSound.Play();
                yield return SetActiveCoroutine(
                    subCoroutine: NextAnimationCoroutine(),
                    letMeSwitch: false
                );
            }
            else
            {
                Debug.LogWarning("==== MissionFormatInfo 가 존재하지 않습니다.");
            }

            yield break;
        }

        private void UpdateMissionTextState(MissionTextState state)
        {
            foreach (MissionTextObject missionTextObject in missionTextObjectsLeft)
            {
                missionTextObject.gameObject.SetActive(missionTextObject.state == state);
            }

            foreach (MissionTextObject missionTextObject in missionTextObjectsRight)
            {
                missionTextObject.gameObject.SetActive(missionTextObject.state == state);
            }
        }

        public virtual void Full()
        {

        }

        private IEnumerator NextAnimationCoroutine()
        {
            AnimatorParser nextAnimation = NextAnimation;
            nextAnimation.SetTrigger();
            yield return nextAnimation.WaitForDuration();
        }

        public IEnumerator SwitchCoroutine()
        {
            AddState(MissionIconState.Switch);
            yield return SetActiveCoroutine(
                subCoroutine: SwitchAnimationCoroutine(),
                letMeSwitch: false
            );
            RemoveState(MissionIconState.Switch);
        }

        private IEnumerator SwitchAnimationCoroutine()
        {
            switchAnimation.SetTrigger();
            yield return switchAnimation.WaitForDuration();
        }

        protected IEnumerator WaitAndUpdateInfo()
        {
            while (CanvasGroup.alpha != 1
                   || IsInState(MissionIconState.Switch) == true)
            {
                yield return null;
            }

            Display.Show(isProgressive: true);
            yield return new WaitForSeconds(Display.ProgressDuration);
        }

        protected IEnumerator SetActiveCoroutine(IEnumerator subCoroutine, bool letMeSwitch)
        {
            SetActive(true, letMeSwitch);
            yield return subCoroutine;
            SetActive(false, letMeSwitch);
        }
    }
}