using SlotGame.Machine;
using SlotGame.UI;
using System;
using System.Collections;
using System.Collections.Generic;
using Underc.Game;
using Underc.User;
using UnityEngine;
using UnityEngine.Serialization;

namespace Underc.UI
{
    public enum MissionIconType
    {
        MissionPass = 0,
        DailyMission = 1,
        ClamHarvest = 2,
        AquaBlitz = 3,
    }

    public enum MissionIconManagerState
    { 
        Normal,
        FullOfAquaBlitz,
    }

    [Flags]
    public enum MissionIconManagerPlayType
    {
        None = 0,
        BeginOnce = 1,
        SwitchOnce = 2,
        ResetOnce = 4,
    }

    [Serializable]
    public class MissionIconSpinDuration
    { 
        public MissionIconManagerState state;
        public float duration;
    }

    public class MissionIconManager : MonoBehaviour, IGameUiElement
    {
        [SerializeField] private bool checkTimeout;

        [FormerlySerializedAs("missionItem")]
        [SerializeField] List<BaseMissionIcon> missionIcons;
        [SerializeField] private List<BaseMissionIcon> missionIconsInPlay;
        [SerializeField] private List<MissionIconSpinDuration> dailyMissionDurations;
        [SerializeField] private List<MissionIconSpinDuration> aquaBlitzDurations;
        private Dictionary<MissionIconType, Dictionary<MissionIconManagerState, float>> allDurations;

        public IEnumerable<BaseMissionIcon> MissionIcons
        { 
            get
            {
                return missionIcons;
            }
        }

        public RectTransform CachedTransform
        { 
            get
            {
                if (cachedTransform == null)
                {
                    cachedTransform = GetComponent<RectTransform>();
                }
                return cachedTransform;
            }
        }
        private RectTransform cachedTransform;

        public DailyMissionIcon DailyMissionIcon
        {
            get;
            private set;
        }

        private Dictionary<MissionIconType, BaseMissionIcon> missionIconDict;

        private SlotMachine slotMachine;

        private bool initOnce;
        private bool isInShow;
        private bool isInSetup;
        private bool beginOnce;

        private bool isActiveIndexChanged;
        private int activeIndex;
        private int switchIndex;
        private Coroutine playCoroutine;

        public bool IsInPlay()
        {
            return playCoroutine != null;
        }

        void IGameUiElement.Initialize(GameUI gameUI, TopUI topUI)
        {
            
        }

        void IGameUiElement.Show(bool animation)
        {
            isInShow = true;
            CheckToPlay();
        }

        void IGameUiElement.Hide(bool animation)
        {
            isInShow = false;
        }

        private void OnDisable()
        {
            isInSetup = false;
            isInShow = false;
            beginOnce = false;

            slotMachine = null;

            if (playCoroutine != null)
            {
                StopCoroutine(playCoroutine);
                playCoroutine = null;
            }
        }

        public BaseMissionIcon GetIcon(MissionIconType type)
        {
            return missionIconDict[type];
        }

        public List<BaseMissionIcon> GetAllIcon()
        {
            return missionIcons;
        }

        public BaseMissionIcon GetActiveMissionIcon()
        {
            BaseMissionIcon result = null;
            if (activeIndex < missionIcons.Count)
            {
                result = missionIcons[activeIndex];
            }

            return result;
        }

        private void OnSwitch(MissionIconType type)
        {
            Debug.Log($"==== OnSwitch : {type}");
            BaseMissionIcon missionIcon = missionIconDict[type];
            switchIndex = missionIcon.Index;

            UpdateActiveIcon(missionIcons);
        }

        private void OnUpdate()
        {
            foreach (BaseMissionIcon missionIcon in missionIconsInPlay)
            {
                missionIcon.Display.Show(isProgressive: false);
            }
        }

        public void Setup()
        {
            isInSetup = true;

            Init();
            ResetDisplays();
            RemoveListeners();
            AddListeners();

            bool isInGameScene = GetComponentInParent<BottomUI>() != null;
            if (isInGameScene)
            {
                Register();
            }
        }

        private void ResetDisplays()
        {
            foreach (BaseMissionIcon missionIcon in missionIcons)
            {
                BaseMissionIcon thisMissionIcon = missionIcon;
                missionIcon.Display.Reset();
                missionIcon.Display.CheckTimeout = () =>
                {
                    // 게임 씬에 바로 붙어있으면서 && 화면에 보이는 상태에서 허용
                    return checkTimeout && (thisMissionIcon.CanvasGroup.alpha == 1);
                };
            }
        }

        public void Setup(SlotMachine slotMachine)
        {
            this.slotMachine = slotMachine;

            Setup();
            CheckToPlay();
        }

        public void Unlock()
        {
            AddMissionIcons();

            int startIndex = 0;
            activeIndex = startIndex;
            switchIndex = startIndex;
            UpdateActiveIcon(missionIconsInPlay);

            CheckToPlay();
        }

        private void Init()
        {
            if (initOnce == false)
            {
                initOnce = true;

                missionIconDict = new Dictionary<MissionIconType, BaseMissionIcon>();
                for (int i = 0; i < missionIcons.Count; i++)
                {
                    BaseMissionIcon missionIcon = missionIcons[i];
                    missionIcon.gameObject.SetActive(true);
                    missionIcon.Init(slotMachine, i);

                    missionIconDict.Add(missionIcon.Type, missionIcon);

                    switch (missionIcon.Type)
                    {
                        case MissionIconType.DailyMission:
                            DailyMissionIcon = missionIcon as DailyMissionIcon;
                            break;
                    }
                }

                allDurations = new Dictionary<MissionIconType, Dictionary<MissionIconManagerState, float>>();
                var durations = new Dictionary<MissionIconManagerState, float>();
                allDurations.Add(MissionIconType.DailyMission, durations);
                foreach (MissionIconSpinDuration spinDuration in dailyMissionDurations)
                {
                    durations[spinDuration.state] = spinDuration.duration;
                }

                durations = new Dictionary<MissionIconManagerState, float>();
                allDurations.Add(MissionIconType.AquaBlitz, durations);
                foreach (MissionIconSpinDuration spinDuration in aquaBlitzDurations)
                {
                    durations[spinDuration.state] = spinDuration.duration;
                }
            }
        }

        private void CheckToPlay()
        {
            if (isInShow == true
                && isInSetup == true
                && IsMissionIconsInLock() == false
                && beginOnce == false)
            {
                beginOnce = true;

                Play(MissionIconManagerPlayType.BeginOnce);
            }
        }

        private void AddListeners()
        {
            foreach (BaseMissionIcon missionIcon in missionIcons)
            {
                missionIcon.Button.OnClick.AddListener(missionIcon.Click);
                missionIcon.OnActive = OnActive;
                missionIcon.OnSwitch = OnSwitch;
                missionIcon.OnUpdate = OnUpdate;
                missionIcon.OnRemove = () => OnRemove(missionIcon.Type);
                missionIcon.Display.OnTimeout = OnTimeout;
            }
        }

        private void RemoveListeners()
        {
            foreach (BaseMissionIcon missionIcon in missionIcons)
            {
                missionIcon.Button.OnClick.RemoveListener(missionIcon.Click);
                missionIcon.OnActive = null;
                missionIcon.OnSwitch = null;
                missionIcon.OnUpdate = null;
                missionIcon.OnRemove = null;
                missionIcon.Display.OnTimeout = null;
            }
        }

        private bool IsMissionIconsInLock()
        {
            DailyMissionDisplayInfo bannerInfo = MyInfo.DailyMission.DisplayInfo;
            return bannerInfo != null
                   && bannerInfo.unlockState != FeatureDisplayUnlockState.Unlock;
        }

        private void Register()
        {
            AddMissionIcons();

            // 아쿠아 블리츠 미션 아이템을 클릭해서 슬롯에 접속한 경우에만 시작 인덱스를 아쿠아 블리츠 아이콘으로 바꿔 줌
            bool isAquaBlitzMissionClicked = MyInfo.AquaBlitz.ConsumeMissionClicked() == true;
            
            int startIndex = 0;
            if (isAquaBlitzMissionClicked == true
                && IsMissionIconsInLock() == false)
            {
                startIndex = missionIconsInPlay.FindIndex(icon => icon.Type == MissionIconType.AquaBlitz);
            }

            activeIndex = startIndex;
            switchIndex = startIndex;
            UpdateActiveIcon(missionIconsInPlay);
        }

        private void AddMissionIcons()
        {
            //
            bool hasAquaBlitzMissionIndex = MyInfo.AquaBlitz.LatestMissionSpinIndex != -1;
            bool isDailyMissionCleared = MyInfo.DailyMission.DisplayInfo.step == 0;
            DailyMissionDisplayInfo bannerInfo = MyInfo.DailyMission.DisplayInfo;
            bool isMissionIconsInLock = bannerInfo != null
                                        && bannerInfo.unlockState != FeatureDisplayUnlockState.Unlock;

            missionIconsInPlay.Clear();

            //Debug.Log($"==== AddMissionIcons : {hasAquaBlitzMissionIndex}, {isMissionIconsInLock}, {isDailyMissionCleared}");
            if (hasAquaBlitzMissionIndex == false    // A-1. 아쿠아 블리츠 미션 슬롯이 아니거나
                || isMissionIconsInLock == true      // A-2. 데일리 미션이 잠금 상태이거나
                || isDailyMissionCleared == false)   // A-3. 데일리 미션이 완료 상태가 아니라면
            {
                missionIconsInPlay.Add(GetIcon(MissionIconType.DailyMission));
            }
            if (hasAquaBlitzMissionIndex)
            {
                missionIconsInPlay.Add(GetIcon(MissionIconType.AquaBlitz));
            }

            UpdateMissionIconIndex();
        }

        private void UpdateMissionIconIndex()
        {
            for (int i = 0; i < missionIconsInPlay.Count; i++)
            {
                BaseMissionIcon missionIcon = missionIconsInPlay[i];
                missionIcon.Index = i;
            }
        }

        public void Play(MissionIconManagerPlayType playType)
        {
            if (playCoroutine != null)
            {
                StopCoroutine(playCoroutine);
                playCoroutine = null;
            }

            playCoroutine = StartCoroutine(PlayCoroutine(playType));
        }

        private void UpdateActiveIcon(List<BaseMissionIcon> targetMissionIcons)
        {
            isActiveIndexChanged = activeIndex != switchIndex;
            activeIndex = switchIndex;

            for (int i = 0; i < missionIcons.Count; i++)
            {
                BaseMissionIcon missionIcon = missionIcons[i];
                missionIcon.CanvasGroup.alpha = 0;
                missionIcon.CanvasGroup.interactable = false;
            }

            if (activeIndex >= 0)
            {
                BaseMissionIcon currentMissionIcon = targetMissionIcons[activeIndex];
                currentMissionIcon.CanvasGroup.alpha = 1;
                currentMissionIcon.CanvasGroup.interactable = true;
                currentMissionIcon.CachedTransform.SetAsLastSibling();

                currentMissionIcon.Display.gameObject.SetActive(true);
            }
        }

        private void OnActive(int activeIndex)
        {
            Debug.Log($"==== OnActive : {activeIndex}");
            switchIndex = activeIndex;
        }

        private void OnTimeout()
        {
            if (activeIndex < missionIconsInPlay.Count)
            {
                // 갱신된 미션 데이터에는 현재 슬롯이 아쿠아 블리츠 미션이 아니게 될 확률이 높다.
                AddMissionIcons();

                //
                MissionIconType currentMissionIconType = missionIconsInPlay[activeIndex].Type;
                MissionIconManagerPlayType playType = MissionIconManagerPlayType.None;
                if (currentMissionIconType == MissionIconType.AquaBlitz)
                {
                    playType |= MissionIconManagerPlayType.SwitchOnce;
                }
                playType |= MissionIconManagerPlayType.ResetOnce;

                int startIndex = 0;
                activeIndex = startIndex;
                switchIndex = startIndex;
                UpdateActiveIcon(missionIconsInPlay);

                Play(playType);
            }
        }

        private void OnRemove(MissionIconType type)
        {
            Debug.Log($"==== OnRemove : {type}");
            bool hasAquaBlitzIcon = missionIconsInPlay.FindIndex(icon => icon.Type == MissionIconType.AquaBlitz) != -1;
            if (hasAquaBlitzIcon
                && missionIconsInPlay.Count >= 2)
            {
                //
                int removingIndex = missionIconsInPlay.FindIndex(icon => icon.Type == type);
                if (removingIndex != -1)
                {
                    // B-1. 제거된 이후 Timeout 으로 인해 다시 추가될 수 있어
                    // B-2. 그 때의 연출을 위해 미리 Idle 상태로 보냄
                    BaseMissionIcon icon = missionIconsInPlay[removingIndex];
                    icon.Display.Reset();

                    missionIconsInPlay.RemoveAt(removingIndex);
                }

                UpdateMissionIconIndex();

                //
                int startIndex = 0;
                activeIndex = startIndex;
                switchIndex = startIndex;
                UpdateActiveIcon(missionIconsInPlay);

                Play(MissionIconManagerPlayType.SwitchOnce);
            }
        }

        private IEnumerator PlayCoroutine(MissionIconManagerPlayType playType)
        {
            Func<MissionIconManagerPlayType, bool> _ConsumePlayType = (MissionIconManagerPlayType targetType) =>
            {
                bool result = (playType & targetType) == targetType;
                if (result)
                {
                    playType &= ~targetType;
                    Debug.Log($"==== _ConsumePlayType : {result}, {targetType}, {playType}");
                }
                return result;
            };

            while (true)
            {
                bool isInLock = false;
                foreach (BaseMissionIcon missionIcon in missionIconsInPlay)
                {
                    if (missionIcon.Display != null
                        && missionIcon.Display.IsInLock() == true)
                    {
                        isInLock = true;
                        break;
                    }
                }

                // A-1. 락이면 대기
                if (isInLock)
                {
                    yield return null;
                    continue;
                }

                // A-2. 시작 연출
                BaseMissionIcon currentMissionIcon = missionIconsInPlay[activeIndex];
                if (_ConsumePlayType(MissionIconManagerPlayType.BeginOnce))
                {
                    yield return currentMissionIcon.BeginCoroutine();
                }

                // A-3. 전환 연출
                UpdateActiveIcon(missionIconsInPlay);
                currentMissionIcon = missionIconsInPlay[activeIndex];

                if (isActiveIndexChanged
                    || _ConsumePlayType(MissionIconManagerPlayType.SwitchOnce))
                {
                    yield return currentMissionIcon.SwitchCoroutine();

                    // 회전 연출 이후 아쿠아 블리츠 가득참 연출 전용
                    if (currentMissionIcon.IsInFull)
                    {
                        currentMissionIcon.Full();
                    }
                }

                if (_ConsumePlayType(MissionIconManagerPlayType.ResetOnce))
                {
                    yield return currentMissionIcon.ResetCoroutine();
                }

                float timeBegin = Time.time;
                float timePassed = 0;
                float duration;
                while (true)
                {
                    MissionIconManagerState state = MissionIconManagerState.Normal;
                    foreach (BaseMissionIcon missionIcon in missionIconsInPlay)
                    {
                        if (missionIcon.Type == MissionIconType.AquaBlitz
                            && missionIcon.IsInFull == true)
                        {
                            state = MissionIconManagerState.FullOfAquaBlitz;
                        }
                    }

                    Dictionary<MissionIconManagerState, float> durations = allDurations[currentMissionIcon.Type];
                    duration = durations[state];

                    if (timePassed > duration || activeIndex != switchIndex)
                    {
                        //Debug.Log($"==== break : {timePassed} > {duration} || {activeIndex} != {switchIndex}");
                        break;
                    }

                    if (currentMissionIcon.IsActive)
                    {
                        timeBegin = Time.time - timePassed;
                        timePassed = Time.time - timeBegin;
                        //Debug.Log($"==== TimeBegin : {timeBegin}, TimePassed : {timePassed}");
                    }
                    else
                    {
                        timePassed = Time.time - timeBegin;
                    }
                        
                    yield return null;
                }

                // Read Next Index
                string reason = (activeIndex == switchIndex) ? "In order" : "Out of order";
                if (activeIndex == switchIndex)
                {
                    switchIndex += 1;
                }
                if (switchIndex >= missionIconsInPlay.Count)
                {
                    switchIndex = 0;
                }

                Debug.Log($"==== Switch Index : {reason}, "
                          + $"{timePassed} / {duration}, "
                          + $"{activeIndex} → {switchIndex}");
            }
        }
    }
}