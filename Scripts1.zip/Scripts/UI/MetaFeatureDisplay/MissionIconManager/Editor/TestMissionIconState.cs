using NUnit.Framework;
using System;
using Underc.UI;

namespace Tests
{
    public class TestMissionIconState
    {
        [Test]
        public void NewBitwiseSimplePasses()
        {
            // 1. Arrange
            MissionIconState state = MissionIconState.None;

            // 2. Action
            state |= MissionIconState.Switch;
            state |= MissionIconState.PopupOpen;

            Assert.AreEqual(MissionIconState.Switch | MissionIconState.PopupOpen, state);

            // 3. Assert
            state &= ~MissionIconState.Switch;
            Assert.AreEqual(MissionIconState.PopupOpen, state);

            state &= ~MissionIconState.PopupOpen;
            Assert.AreEqual(MissionIconState.None, state);
        }
    }
}
