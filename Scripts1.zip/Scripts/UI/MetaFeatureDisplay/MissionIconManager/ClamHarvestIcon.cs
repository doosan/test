using UnityEngine;

namespace Underc.UI
{
    public class ClamHarvestIcon : BaseMissionIcon
    {
        [SerializeField] private ClamHarvestDisplay display;

        public override MissionIconType Type
        {
            get => MissionIconType.ClamHarvest;
        }

        public override BaseMissionDisplay Display
        {
            get => display;
        }

        public override void UpdateInfo(bool isProgressive)
        {
            display.Show(isProgressive: isProgressive);
        }

        public override void Unlock()
        {
            display.Unlock();
        }

        public override void Switch(bool showBadge)
        {
            display.ShowBadge = showBadge;

            base.Switch(showBadge);
        }
    }
}