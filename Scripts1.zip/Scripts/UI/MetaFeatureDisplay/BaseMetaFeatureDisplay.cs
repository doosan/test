using System;
using UnityEngine;

namespace Underc.UI
{
    public abstract class BaseMetaFeatureDisplay : MonoBehaviour
    {
        public bool RunAsFake
        {
            set;
            get;
        }

        public RectTransform CachedTransform
        {
            get
            {
                if (cachedTransform == null)
                {
                    cachedTransform = GetComponent<RectTransform>();
                }
                return cachedTransform;
            }
        }
        private RectTransform cachedTransform;

        public float ProgressDuration
        {
            get;
            protected set;
        }

        public virtual bool IsInLock()
        {
            return false;
        }

        public virtual void Reset()
        {

        }

        public virtual void Show(bool isProgressive, Action onComplete = null)
        {
        }

        public virtual void Hide()
        {

        }

    }
}