using Gaga;
using Gaga.Util;
using System;
using System.Collections;
using TMPro;
using Underc.Tutorial;
using Underc.User;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace Underc.UI
{
    public enum ChestDisplayType
    {
        Golden,
        Obsidian
    }

    public enum ChestDisplayState
    {
        None,
        Lock,
        Clear,
        Disabled,
        Normal
    }

    public class ChestDisplay : BaseMetaFeatureDisplay
    {
        [SerializeField] private ChestDisplayType type;
        [SerializeField] private Button openButton;

        [Space]
        [SerializeField] private Animator chestAnimator;
        [SerializeField] private AnimatorParser clearAnimation;
        [SerializeField] private GameObjectVisibleToggle freeVisibleToggle;
        [FormerlySerializedAs("freeTimeText")]
        [SerializeField] private TextMeshProUGUI remainingSecText;
        [SerializeField] private GameObject KeyContainer;
        [SerializeField] private TextMeshProUGUI keyText;
        [SerializeField] private SlantedText unlockLevelText;

        private Func<long> GetRemainingSec;
        private Func<long> GetKey;
        private Func<int> GetUnlockLevel;

        private MyCasinoBonus casinoBonus;
        private Coroutine updateCoroutine;

        private long remainingSec;
        private long key;
        private int unlockLevel;

        private ChestDisplayState state;

        public override void Reset()
        {
            casinoBonus = MyInfo.CasinoBonus;

            if (type == ChestDisplayType.Golden)
            {
                GetRemainingSec = () => casinoBonus.GoldenFreeRemainingSec;
                GetKey = () => casinoBonus.GoldenKey;
                GetUnlockLevel = () => casinoBonus.GoldenUnlock;
            }
            else if (type == ChestDisplayType.Obsidian)
            {
                GetRemainingSec = () => casinoBonus.ObsidianFreeRemainingSec;
                GetKey = () => casinoBonus.ObsidianKey;
                GetUnlockLevel = () => casinoBonus.ObsidianUnlock;
            }
            else
            {
                GetRemainingSec = null;
                GetKey = null;
                GetUnlockLevel = null;
            }

            SetState(ChestDisplayState.Lock);
        }

        public override void Show(bool isProgressive, Action onComplete = null)
        {
            UpdateAnimState();

            StartCoroutine(UpdateCoroutine());
        }

        public override bool IsInLock()
        {
            return state == ChestDisplayState.Lock;
        }

        private void UpdateAnimState()
        {
            if (TutorialSystem.Instance.IsInPlay == false)
            {
                MyCasinoBonus casinoBonus = MyInfo.CasinoBonus;
                if (type == ChestDisplayType.Obsidian
                    && casinoBonus.ObsidianUnlock == 0)
                {
                    Unlock();
                }

                if (type == ChestDisplayType.Golden
                    && casinoBonus.GoldenUnlock == 0)
                {
                    Unlock();
                }
            }
        }

        private void SetState(ChestDisplayState state, bool autoTrigger = true)
        {
            if (this.state != state)
            {
                this.state = state;
                if (autoTrigger == true
                    && chestAnimator != null)
                {
                    chestAnimator.SetTriggerDistinct(state.ToString());
                }

                if (openButton != null)
                {
                    openButton.interactable = state == ChestDisplayState.Normal
                                              || state == ChestDisplayState.Lock;
                }
            }
        }

        public void Unlock()
        {
            if (state == ChestDisplayState.Lock
                && unlockLevel == 0)
            {
                SetState(ChestDisplayState.Clear, autoTrigger: false);
            }
        }

        public void UpdateContent()
        {
            remainingSec = GetRemainingSec();
            if (freeVisibleToggle != null)
            {
                freeVisibleToggle.IsOn = remainingSec == 0;
            }

            if (remainingSecText != null)
            {
                remainingSecText.text = remainingSec.ToSummaryDHMS();
            }

            ///
            key = GetKey();
            if (KeyContainer != null)
            {
                KeyContainer.SetActive(key > 0);
            }
            if (keyText != null)
            {
                keyText.text = StringUtils.ToSingleUnit(key);
            }

            ///
            unlockLevel = GetUnlockLevel();
            if (unlockLevelText != null)
            {
                unlockLevelText.text = StringMaker.New()
                                                  .Append("LV.")
                                                  .Append(unlockLevel.ToString())
                                                  .Build();
            }
        }

        public override void Hide()
        {
            SetState(ChestDisplayState.Lock);

            if (updateCoroutine != null)
            {
                StopCoroutine(updateCoroutine);
                updateCoroutine = null;
            }
        }

        private IEnumerator UpdateCoroutine()
        {
            while (true)
            {
                ///
                if (state != ChestDisplayState.Lock)
                {
                    SetState((remainingSec == 0 || key > 0) ?
                             ChestDisplayState.Normal :
                             ChestDisplayState.Disabled);
                }

                UpdateContent();

                yield return casinoBonus.WaitForTimeUpdate(this);
            }
        }
    }
}