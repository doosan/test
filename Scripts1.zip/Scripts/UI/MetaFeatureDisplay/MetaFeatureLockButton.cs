using Gaga.Sound;
using Underc.Transition;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Underc.UI
{
    [RequireComponent(typeof(BaseMetaFeatureDisplay))]
    public class MetaFeatureLockButton : MonoBehaviour
    {
        [Header("Lock Button Shaker")]
        [SerializeField] private UnityEvent onClick;
        [SerializeField] private Button button;
        [SerializeField] private TransformShaker shaker;
        [SerializeField] private SoundPlayer lockSound;
        [SerializeField] private SoundPlayer clickSound;

        public UnityEvent OnClick
        {
            get => onClick;
        }

        private BaseMetaFeatureDisplay metaFeatureDisplay;

        private void OnEnable()
        {
            metaFeatureDisplay = GetComponent<BaseMetaFeatureDisplay>();

            button.onClick.AddListener(_OnClick);
        }

        private void OnDisable()
        {
            button.onClick.RemoveListener(_OnClick);
        }

        private void _OnClick()
        {
            if (metaFeatureDisplay.IsInLock())
            {
                shaker?.Do();
                lockSound?.Play();
            }
            else
            {
                onClick?.Invoke();
                clickSound?.Play();
            }
        }
    }
}