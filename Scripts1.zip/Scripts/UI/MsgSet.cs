using UnityEngine;

namespace Underc.UI
{
    public class MsgSet : MonoBehaviour
    {
        public static string FullOfSea(long max)
        {
            return string.Format(System.Globalization.CultureInfo.InvariantCulture, "Maximum object capacity of\n{0} is reached for this sea.", max);
        }

        public static string FullOfUniqueSwimmer()
        {
            return "Existing in this sea.";
        }

        public static string LevelLock(long level)
        {
            return string.Format(System.Globalization.CultureInfo.InvariantCulture, "Unlocked at level {0}.", level);
        }

        public static string ClearOfSea()
        {
            return "You can only buy fish in the sea\nwhere story is in progress.\nTry using the inventory instead.";
        }
    }
}
