using UnityEngine;
using UnityEngine.UI;
using TMPro;
using Gaga.Util;
using System;
using System.Collections.Generic;

namespace Underc.UI
{
    [RequireComponent(typeof(RectTransform))]
    public sealed class SeaStoryChapterView : MonoBehaviour
    {
        [Header("Bonus")]
        [SerializeField] private Animator goalAnimator;
        [SerializeField] private Animator bonusAnimator1;
        [SerializeField] private Animator bonusAnimator2;
        [SerializeField] private Animator bonusAnimator3;

        [Header("Anim Trigger")]
        [SerializeField] private string idleTrigger = "Idle";
        [SerializeField] private string reachedTrigger = "Reached";
        [SerializeField] private string completeTrigger = "Complete";
        [SerializeField] private string endTrigger = "End";

        [Header("Gauge")]
        [SerializeField] private Slider mainSlider;
        [SerializeField] private Slider guideSlider;
        [SerializeField] private ParticleSystem mainSliderEffect;

        [Header("Text")]
        [SerializeField] private TextMeshProUGUI progressText;

        public event Action<int, int, SeaStoryBonusState, RectTransform> onBonusClick;

        private RectTransform cachedTrasnform;
        public RectTransform CachedTransform
        {
            get
            {
                if (cachedTrasnform == null)
                {
                    cachedTrasnform = GetComponent<RectTransform>();
                }

                return cachedTrasnform;
            }
        }

        private SeaStoryChapterInfo info;
        private int chapterIndex;
        private List<RectTransform> bonusTrasnforms;
        private bool isEffectActive;

        public void Awake()
        {
            mainSlider.value = 0.0f;

            bonusTrasnforms = new List<RectTransform>();
            bonusTrasnforms.Add(bonusAnimator1.GetComponent<RectTransform>());
            bonusTrasnforms.Add(bonusAnimator2.GetComponent<RectTransform>());
            bonusTrasnforms.Add(bonusAnimator3.GetComponent<RectTransform>());
            bonusTrasnforms.Add(goalAnimator.GetComponent<RectTransform>());

            if (guideSlider != null)
            {
                guideSlider.value = 0.0f;
            }

            SetupEffect();
        }

        private void OnEnable()
        {
            if (info == null)
            {
                return;
            }

            UpdateState(info);
        }

        private void OnDisable()
        {
            if (isEffectActive == false)
            {
                mainSliderEffect.gameObject.SetActive(false);
            }
        }

        private void SetupEffect()
        {
            var effectMainModule = mainSliderEffect.main;
            effectMainModule.stopAction = ParticleSystemStopAction.Disable;

            isEffectActive = false;
            mainSliderEffect.gameObject.SetActive(false);
        }

        public void Initialize(SeaStoryChapterInfo info, int index)
        {
            chapterIndex = index;
            this.info = info;
            mainSlider.value = 1.0f;

            var sliderWidth = mainSlider.fillRect.GetComponent<RectTransform>().GetWorldRect().width;
            var sliderStartPosX = mainSlider.fillRect.position.x - (sliderWidth * mainSlider.fillRect.pivot.x);
            var bonus1PosX = sliderWidth * ((float)info.GetRelativeBonus1() / (float)info.GetRelativeGoal()) + sliderStartPosX;
            var bonus2PosX = sliderWidth * ((float)info.GetRelativeBonus2() / (float)info.GetRelativeGoal()) + sliderStartPosX;
            var bonus3PosX = sliderWidth * ((float)info.GetRelativeBonus3() / (float)info.GetRelativeGoal()) + sliderStartPosX;
            var bonusPosZ = transform.parent.position.z;

            bonusAnimator1.transform.position = new Vector3(bonus1PosX, bonusAnimator1.transform.position.y, bonusPosZ);
            bonusAnimator2.transform.position = new Vector3(bonus2PosX, bonusAnimator2.transform.position.y, bonusPosZ);
            bonusAnimator3.transform.position = new Vector3(bonus3PosX, bonusAnimator3.transform.position.y, bonusPosZ);

            mainSlider.value = 0.0f;

            UpdateState(info);
        }

        private void UpdateState(SeaStoryChapterInfo info)
        {
            SetBonus1State(info.bonus1State);
            SetBonus2State(info.bonus2State);
            SetBonus3State(info.bonus3State);
            SetGoalState(info.goalState);
        }

        public void SetBonus1State(SeaStoryBonusState state)
        {
            info.bonus1State = state;
            bonusAnimator1.SetTrigger(GetAnimationTrigger(state));
        }

        public void SetBonus2State(SeaStoryBonusState state)
        {
            info.bonus2State = state;
            bonusAnimator2.SetTrigger(GetAnimationTrigger(state));
        }

        public void SetBonus3State(SeaStoryBonusState state)
        {
            info.bonus3State = state;
            bonusAnimator3.SetTrigger(GetAnimationTrigger(state));
        }

        public void SetGoalState(SeaStoryBonusState state)
        {
            info.goalState = state;
            goalAnimator.SetTrigger(GetAnimationTrigger(state));
        }

        public RectTransform GetBonus1()
        {
            return bonusTrasnforms[0];
        }

        public RectTransform GetBonus2()
        {
            return bonusTrasnforms[1];
        }

        public RectTransform GetBonus3()
        {
            return bonusTrasnforms[2];
        }

        public RectTransform GetGoal()
        {
            return bonusTrasnforms[3];
        }

        public void SetMainSliderValue(float value)
        {
            mainSlider.value = value;
        }

        public void SetGuideSliderValue(float value)
        {
            if (guideSlider != null)
            {
                guideSlider.value = value;
            }
        }

        public void SetProgressText(long total, long current)
        {
            if (progressText == null)
            {
                return;
            }

            var value = StringMaker.New()
                                   .Append(StringUtils.ToComma(current))
                                   .Append(" / ")
                                   .Append(StringUtils.ToComma(total))
                                   .Build();

            progressText.text = value;
        }

        private string GetAnimationTrigger(SeaStoryBonusState state)
        {
            var trigger = "";
            
            if (state == SeaStoryBonusState.Reached)
            {
                trigger = reachedTrigger;
            }
            else if (state == SeaStoryBonusState.Complete)
            {
                trigger = completeTrigger;
            } 
            else if (state == SeaStoryBonusState.End)
            {
                trigger = endTrigger;
            }
            else
            {
                trigger = idleTrigger;
            }

            return trigger;
        }

        public void BonusClick(int index)
        {
            var tr = bonusTrasnforms[index];

            SeaStoryBonusState state = SeaStoryBonusState.Idle;

            if(index == 0)
            {
                state = info.bonus1State;
            }
            else if(index == 1)
            {
                state = info.bonus2State;
            }
            else if(index == 2)
            {
                state = info.bonus3State;
            }
            else if(index == 3)
            {
                state = info.goalState;
            }

            onBonusClick?.Invoke(chapterIndex, index, state, tr);
        }

        public void ShowEffect()
        {
            if (isEffectActive)
            {
                return;
            }

            ShowEffectForce();
        }

        public void ShowEffectForce()
        {
            if (mainSliderEffect == null)
            {
                return;
            }

            isEffectActive = true;

            mainSliderEffect.gameObject.SetActive(false);

            var effectMainModule = mainSliderEffect.main;
            effectMainModule.loop = true;

            mainSliderEffect.gameObject.SetActive(true);
        }

        public void HideEffect(bool immediately = false)
        {
            if (isEffectActive == false)
            {
                return;
            }

            HideEffectForce(immediately);
        }

        public void HideEffectForce(bool immediately = false)
        {
            isEffectActive = false;

            if (mainSliderEffect == null
                || mainSliderEffect.gameObject.activeInHierarchy == false)
            {
                return;
            }

            if (immediately)
            {
                mainSliderEffect.gameObject.SetActive(false);
                return;
            }

            var effectMainModule = mainSliderEffect.main;
            effectMainModule.loop = false;

            mainSliderEffect.Stop();
        }
    }
}