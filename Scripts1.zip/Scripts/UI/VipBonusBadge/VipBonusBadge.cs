using Gaga;
using Gaga.Sound;
using Gaga.Util;
using System;
using System.Collections;
using TMPro;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;
using static Gaga.Util.CustomYield;

namespace Underc.UI
{
    public class VipBonusBadge : MonoBehaviour
    {
        [SerializeField] private GameObjectVisibleToggle classVisibleToggle;
        [SerializeField] private Text itemValueText;
        [SerializeField] private TextMeshProUGUI classNameText;
        [SerializeField] private AnimatorParser stayAnimation;
        [SerializeField] private AnimatorParser showAnimation;
        [SerializeField] private float showAnimDelay = .1f;
        [SerializeField] private AnimatorParser hideAnimation;
        [SerializeField] private float addingDoneDelay = .5f;
        
        [Header("Sound")]
        [SerializeField] private SoundPlayer showSound;
        [SerializeField] private SoundPlayer addSound;

        public bool CanOpen
        {
            get;
            private set;
        }

        private RectTransform targetTransform;
        private long vipBonus;
        private VipBenefitTableItemInfo tableItemInfo;

        private float addingDoneDuration;
        private Action onVipBonusAdding;
        private Action onVipBonusAddingDone;

        private SimpleWaitForDone waitForVipBonusAdding = new SimpleWaitForDone();

        public void Setup(RectTransform targetTransform, long vipBonus, VipBenefitTableItemInfo tableItemInfo)
        {
            this.targetTransform = targetTransform;
            this.vipBonus = vipBonus;
            this.tableItemInfo = tableItemInfo;

            CanOpen = tableItemInfo.bonusRate > 1;

            VipClassType vipClassType = MyInfo.VipClass.Type;
            string vipClassName = MyInfo.VipClass.Name;

            classVisibleToggle.TurnOnByNameInMultiple(vipClassType.ToString());
            itemValueText.text = tableItemInfo.ToString();
            classNameText.text = vipClassName;

            stayAnimation.SetTrigger();
        }

        public SimpleWaitForDone Show(float addingDoneDuration = .35f, 
                                      Action onVipBonusAdding = null, 
                                      Action onVipBonusAddingDone = null)
        {
            this.addingDoneDuration = addingDoneDuration;
            this.onVipBonusAdding = onVipBonusAdding;
            this.onVipBonusAddingDone = onVipBonusAddingDone;

            if (CanOpen)
            {
                StartCoroutine(RunAnimationCoroutine(showAnimation, showAnimDelay));
                showSound.Play();
                waitForVipBonusAdding.Ready();
            }
            else
            {
                waitForVipBonusAdding.Done();
            }
            return waitForVipBonusAdding;
        }

        public void Hide()
        {
            StartCoroutine(RunAnimationCoroutine(hideAnimation));
        }

        private IEnumerator RunAnimationCoroutine(AnimatorParser targetAnimation, float delay = 0f)
        {
            if (delay > 0)
            {
                yield return new WaitForSeconds(delay);
            }

            targetAnimation.SetTrigger();
            yield return targetAnimation.WaitForDuration();
        }

        public void AddVipBonus()
        {
            addSound.Play();
            onVipBonusAdding?.Invoke();
            Invoke("VipBonusAddingDone", addingDoneDuration + addingDoneDelay);
        }

        private void VipBonusAddingDone()
        {
            onVipBonusAddingDone?.Invoke();
            waitForVipBonusAdding.Done();
        }
    }
}
