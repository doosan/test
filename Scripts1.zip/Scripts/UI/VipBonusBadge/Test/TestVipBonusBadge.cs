using Gaga;
using Gaga.Popup;
using System.Collections;
using System.Collections.Generic;
using Underc;
using Underc.Effect;
using Underc.LoadingScreen;
using Underc.Net;
using Underc.Net.Client;
using Underc.Popup;
using Underc.UI;
using Underc.User;
using Underc.Util;
using UnityEngine;

public class TestVipBonusBadge : TestSceneScaffold
{
    [SerializeField] private VipClassType vipClassType;
    [SerializeField] private RectTransform uiRoot;
    [SerializeField] private SeaStoryBonusEffect seaStoryBonusEffect;

    private TopUI topUI;

    private long rewardCoin;
    private long vipBonus;
    private VipBenefitTableItemInfo tableItemInfo;

    private List<RewardData> rewardDatas;
    private VipBonusBadge vipBonusBadge;

    private IEnumerator Start()
    {
        yield return SetupAndLoad(new BaseLoadingItem[]
        {
            new LoginLoadingItem(),
            new HTTPLoadingItem<UserCoreResponse>(
                () => NetworkSystem.HTTPRequester.UserCoreWithAlarms(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<FishBookListResponse>(
                () => NetworkSystem.HTTPRequester.FishBookList(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<MissionResponse>(
                () => NetworkSystem.HTTPRequester.Mission(), 
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<ProfileResponse>(
                () => NetworkSystem.HTTPRequester.Profile(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new ABFishLoadingItem(),
            new ABLoadingItem(AssetBundleName.EFFECT),
            new TopUILoadingItem(),
            new RewardBonusUILoadingItem(),
            new VipBonusBadgeLoadingItem(),
        });
    }

    private void SetupTopUI()
    {
        if (topUI == null)
        {
            topUI = TopUISystem.Instance.Get(parent: uiRoot);
            topUI.Use(TopUiItem.Home,
                      TopUiItem.Coin,
                      TopUiItem.Shop,
                      TopUiItem.Profile,
                      TopUiItem.PearlAndTicket,
                      TopUiItem.Setting);
            topUI.OrderAsDefault();
        }

        topUI.Reset();
        topUI.Hide(false);
    }

    public void ShowVipBonusBadge()
    {
        if (vipBonusBadge == null)
        {
            vipBonusBadge = VipBonusBadgeSystem.Instance.Get(uiRoot);
        }

        vipBonusBadge.Setup(targetTransform: null,
                            vipBonus: 0,
                            tableItemInfo: new VipBenefitTableItemInfo(1.5f, "per"));
        vipBonusBadge.Show();
    }

    public void HideVipBonusBadge()
    {
        vipBonusBadge.Hide();
    }

    public void OpenDailyBonusPopup()
    {
        MyInfo.VipClass.Update((int)vipClassType);

        var dailyBonusClaimResponse = new DailyBonusClaimResponse();
        dailyBonusClaimResponse.daily_bonus = 600000;
        dailyBonusClaimResponse.coin_per_streak = 100000;

        dailyBonusClaimResponse.streak_bonus = 600000;
        dailyBonusClaimResponse.streak_day = 1;
        dailyBonusClaimResponse.streak_max = 7;

        dailyBonusClaimResponse.starting_coin = 1000;
        dailyBonusClaimResponse.fish_cnt = 36;
        dailyBonusClaimResponse.fish_bonus = 36000;
        dailyBonusClaimResponse.limit_fish_cnt = 1000;

        long totalBonus = dailyBonusClaimResponse.daily_bonus +
                          dailyBonusClaimResponse.streak_bonus +
                          dailyBonusClaimResponse.fish_bonus;
        tableItemInfo = MyInfo.VipClass.GetCurrent_VipBenefitTableItemInfo(VipBenefitTableItem.DailyBonus);
        vipBonus = (long)(totalBonus * tableItemInfo.bonusRate) - totalBonus;
        dailyBonusClaimResponse.vip_bonus = vipBonus;
        dailyBonusClaimResponse.vip_rate = tableItemInfo.bonusRate;
        dailyBonusClaimResponse.vip_rate_type = tableItemInfo.type.ToString();

        var dailyBonusClaimReward = new DailyBonusRewardData();
        dailyBonusClaimReward.rwd = "s_pickaxe";
        dailyBonusClaimReward.val = 1;
        dailyBonusClaimResponse.reward = new DailyBonusRewardData[]
        {
            dailyBonusClaimReward
        };

        FakeHttpRequester.Instance.LoadedDailyBonusClaimResponse = dailyBonusClaimResponse;

        PopupObject<DailyBonusPopup> popupObject = null;
        popupObject = Popups.DailyBonus(onOpen: () =>
                                        {
                                            if (popupObject != null)
                                            {
                                                popupObject.GetPopup().RunAsFake = true;
                                            }
                                        })
                            .Async()
                            .Cache();
    }

    public void OpenSeaStoryBonusEffect()
    {
        MyInfo.VipClass.Update((int)vipClassType);

        StartCoroutine(SeaStoryBonusEffectCoroutine());
    }

    private IEnumerator SeaStoryBonusEffectCoroutine()
    {
        SetupTopUI();
        topUI.Show(true);
        yield return new WaitForSeconds(.5f);

        rewardCoin = 1000000;
        tableItemInfo = MyInfo.VipClass.GetCurrent_VipBenefitTableItemInfo(VipBenefitTableItem.Sea);
        vipBonus = (long)(rewardCoin * tableItemInfo.bonusRate) - rewardCoin;

        seaStoryBonusEffect.gameObject.SetActive(true);
        yield return seaStoryBonusEffect.Play(
            rewardCoin,
            vipBonus,
            tableItemInfo,
            onReward: (Vector2 rewardPos) =>
            {
                var endPos = topUI.GetCoinIconPosition();
                EffectSystem.Instance.Coin(20,
                                           rewardPos,
                                           endPos,
                                           topUI.GetCoinIcon(),
                                           null,
                                           onComplete: completeType => topUI.Hide(true),
                                           () => MyInfo.Coin += (rewardCoin + vipBonus),
                                           () => topUI.CoinIconAnimation());
            }
        );
    }

    public void OpenCoinBubblePopup()
    {
        MyInfo.VipClass.Update((int)vipClassType);

        rewardCoin = 1000000;
        tableItemInfo = MyInfo.VipClass.GetCurrent_VipBenefitTableItemInfo(VipBenefitTableItem.Sea);
        vipBonus = (long)(rewardCoin * tableItemInfo.bonusRate) - rewardCoin;

        PopupObject<CoinBubblePopup> popupObject = null;
        popupObject = Popups.CoinBubble(rewardCoin, 
                                        vipBonus,
                                        tableItemInfo,
                                        CoinBubblePopupState.None,
                                        () =>
                                        {
                                            CoinBubblePopup popup = popupObject.GetPopup();
                                            RangeValue yVelocityOrigin = popup.yVelocity;
                                            popup.yVelocity = new RangeValue(yVelocityOrigin.max, yVelocityOrigin.max);
                                            popup.ResetBubbles(1);
                                            popup.SetState(CoinBubblePopupState.Start);
                                        });
    }

    public void OpenAccomplishedPopup()
    {
        MyInfo.VipClass.Update((int)vipClassType);

        rewardCoin = 1000000;
        tableItemInfo = MyInfo.VipClass.GetCurrent_VipBenefitTableItemInfo(VipBenefitTableItem.Sea);
        vipBonus = (long)(rewardCoin * tableItemInfo.bonusRate) - rewardCoin;

        Popups.Accomplished(rewardCoin, vipBonus, tableItemInfo);
    }

    public void OpenRewardViewPopup()
    {
        MyInfo.VipClass.Update((int)vipClassType);

        if (rewardDatas == null)
        {
            rewardDatas = new List<RewardData>();
        }

        rewardDatas.Clear();
        rewardDatas.Add(GetFishData());

        Popups.RewardView(
            rewardDatas: rewardDatas.ToArray(),
            openType: Random.Range(0, 2) == 0 ? 
                      RewardViewPopup.OpenType.GoldenChest : 
                      RewardViewPopup.OpenType.ObsidianChest
        );
    }

    private RewardData GetFishData()
    {
        MyOceanBook oceanBook = MyInfo.Ocean.Book;
        int randomIndex = Random.Range(0, oceanBook.GetBookInfoCount(SeaItemType.f));
        BaseBookInfo fishBookInfo = oceanBook.GetBookInfoAtIndex(SeaItemType.f, randomIndex);

        rewardCoin = 1000000;
        tableItemInfo = MyInfo.VipClass.GetCurrent_VipBenefitTableItemInfo(VipBenefitTableItem.Sea);
        vipBonus = (long)(rewardCoin * tableItemInfo.bonusRate) - rewardCoin;

        var fishData = new RewardData(RewardData.FISH, fishBookInfo.ID);
        fishData.additionalCoin = rewardCoin;
        fishData.additionalVipCoin = vipBonus;
        fishData.tableItemInfo = tableItemInfo;
        return fishData;
    }
}
