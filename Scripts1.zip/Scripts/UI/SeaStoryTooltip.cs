using UnityEngine;
using TMPro;

namespace Underc.UI
{
    public sealed class SeaStoryTooltip : MonoBehaviour
    {
        public RectTransform target;
        public Vector2 offset; 

        [Space]
        [SerializeField] private TextMeshProUGUI msgText;
        private bool isFlip;

        private RectTransform root;
        private RectTransform cachedTrasnform;

        private void Awake()
        {
            root = GetComponentInParent<Canvas>().GetComponent<RectTransform>();
            cachedTrasnform = GetComponent<RectTransform>();
        }

        public void Show(string msg, bool flip = false)
        {
            gameObject.SetActive(false);
            gameObject.SetActive(true);

            msgText.text = msg;

            isFlip = flip;

            var flipX = flip ? -1.0f : 1.0f;
            cachedTrasnform.localScale = new Vector3(flipX, 1.0f, 1.0f);
            msgText.transform.localScale = new Vector3(flipX, 1.0f, 1.0f);

            Update();
        }

        public void Hide()
        {
            gameObject.SetActive(false);
        }

        private void Update()
        {
            if (target == null)
            {
                return;
            }

            if (target.gameObject.activeInHierarchy == false)
            {
                Hide();
                return;
            }

            var offsetX = (isFlip ? -offset.x : offset.x) * (root.lossyScale.x * 100.0f);
            var offsetY = offset.y * (root.lossyScale.y * 100.0f);
            cachedTrasnform.position = target.position + new Vector3(offsetX, offsetY, 0.0f);
        }
    }
}