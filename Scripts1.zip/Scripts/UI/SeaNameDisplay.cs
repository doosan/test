using UnityEngine;
using DG.Tweening;
using Underc.Lobby;
using Underc.Popup;
using Underc.User;
using UnityEngine.UI;
using TMPro;

namespace Underc.UI
{
    public sealed class SeaNameDisplay : MonoBehaviour
    {
        [SerializeField] private Text nativeText;
        [SerializeField] private TextMeshProUGUI tmproText;

        private void Awake()
        {
            MyInfo.Ocean.OnCurrentSeaChanged += OnSeaChangedHandler;
        }

        private void OnDestroy()
        {
            MyInfo.Ocean.OnCurrentSeaChanged -= OnSeaChangedHandler;
        }

        private void OnSeaChangedHandler(int id, string seaName, int star)
        {
            UpdateText();
        }

        private void OnEnable()
        {
            UpdateText();
        }

        public void UpdateText()
        {
            string seaID = MyInfo.Ocean.CurrentSeaID.ToString();

            if (nativeText != null)
            {
                nativeText.text = seaID;
            }

            if (tmproText != null)
            {
                tmproText.text = seaID;
            }
        }
    }
}