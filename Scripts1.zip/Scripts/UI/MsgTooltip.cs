using System.Collections;
using TMPro;
using UnityEngine;

namespace Underc.UI
{
    public class MsgTooltip : MonoBehaviour
    {
#pragma warning disable 0649
        [SerializeField] private GameObject msgObject;
        [SerializeField] private TextMeshProUGUI msgText;
#pragma warning restore 0649

        private void OnDisable()
        {
            Hide();
        }

        public void Hide()
        {
            StopAllCoroutines();
            msgObject.SetActive(false);
        }

        public void Show(string msg, float duration, float delay = 0f)
        {
            msgText.text = msg;

            StopAllCoroutines();
            StartCoroutine(ShowMsgCoroutine(delay, duration));
        }

        private IEnumerator ShowMsgCoroutine(float delay, float duration)
        {
            yield return new WaitForSeconds(delay);
            msgObject.SetActive(true);
            yield return new WaitForSeconds(duration);
            msgObject.SetActive(false);
        }
    }
}
