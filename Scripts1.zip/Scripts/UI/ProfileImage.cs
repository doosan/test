using Gaga.Util;
using Underc.Net;
using Underc.Popup;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.UI
{
    public class ProfileImageInfo
    {
        public string url;
        public int num;

        public void Reset()
        {
            url = "";
            num = -1;
        }

        public void Update(string url)
        {
            this.url = url;
            this.num = -1;
        }

        public void Update(int num)
        {
            this.num = num;
            this.url = "";
        }
    }

    public class ProfileImage : MonoBehaviour
    {
        [SerializeField] private Image image;

        private MyProfile profile;
        private ProfileImageInfo info;
        private Coroutine coroutine;
        private bool isInLoading;

        public void ResetOnce()
        {
            profile = MyInfo.Profile;
            info = new ProfileImageInfo();
            info.Reset();
            image.color = new Color(1, 1, 1, 0);
            isInLoading = false;
        }

        private void OnDisable()
        {
            if (isInLoading)
            {
                HideLoading();
            }
        }

        private void ShowLoading()
        {
            Popups.ShowLoading();
            isInLoading = true;
        }

        private void HideLoading()
        {
            Popups.HideLoading();
            isInLoading = false;
        }

        public void UpdateImage()
        {
            string latestImageUrl = profile.PicUrl;
            int latestImageNum = profile.PicNum;
            if (string.IsNullOrEmpty(latestImageUrl) == false)
            {
                //Debug.Log($"==== UpdateImage() {latestImageUrl}");
                info.Update(latestImageUrl);

                ShowLoading();
                DownloadSystem.Instance.GetSprite(
                    url: latestImageUrl,
                    onComplete: (Sprite sprite) =>
                    {
                        SetImage(sprite);
                        HideLoading();
                    },
                    useCache: true
                );
            }
            else if (latestImageNum > 0)
            {
                //Debug.Log($"==== UpdateImage() {latestImageNum}");
                info.Update(latestImageNum);

                ShowLoading();
                ProfileIconSystem.Instance.GetAsync(
                    picIndex: latestImageNum,
                    onComplete: (Sprite sprite) =>
                    {
                        SetImage(sprite);
                        HideLoading();
                    }
                );
            }
            else
            {
                //Debug.Log("==== UpdateImage() nothing is done");
            }
        }

        public void SetImage(Sprite sprite)
        {
            if (sprite != null)
            {
                image.color = new Color(1, 1, 1, 1);
                image.sprite = sprite;
                image.ScaleToFit(sprite);
            }
            else
            {
                image.color = new Color(1, 1, 1, 0);
                image.sprite = null;
            }
        }
    }
}