using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;

namespace Underc.UI
{
    public class HighlightObjectInfo
    {
        public RectTransform originTransform;
        public HighlightVisibleType visibleType;
        public bool initialActive;
        public RectTransform clonedTransform;

        private CanvasGroup originCanvasGroup;
        private CanvasGroup clonedCanvasGroup;

        public HighlightObjectInfo(RectTransform originTransform, HighlightVisibleType visibleType, bool initialActive)
        {
            this.originTransform = originTransform;
            this.visibleType = visibleType;
            this.initialActive = initialActive;
            clonedTransform = null;

            originCanvasGroup = null;
        }

        public void Clone(Transform parent)
        {
            if (clonedTransform == null)
            {
                if (visibleType == HighlightVisibleType.Alpha)
                {
                    originCanvasGroup = originTransform.GetComponent<CanvasGroup>();
                    if (originCanvasGroup == null)
                    {
                        originCanvasGroup = originTransform.gameObject.AddComponent<CanvasGroup>();
                    }
                }

                //
                clonedTransform = GameObject.Instantiate(originTransform.gameObject, parent).GetComponent<RectTransform>();
                clonedTransform.transform.position = Vector3.zero;

                clonedCanvasGroup = clonedTransform.GetComponent<CanvasGroup>();
                if (clonedCanvasGroup == null)
                {
                    clonedCanvasGroup = clonedTransform.gameObject.AddComponent<CanvasGroup>();
                }
                SetInteractable(clonedCanvasGroup, false);
            }
        }

        public void SetCloneActive(bool isOn, bool keepFade = false)
        {
            if (visibleType == HighlightVisibleType.Active)
            {
                originTransform.gameObject.SetActive(!isOn);
                clonedTransform.gameObject.SetActive(isOn);
            }
            else if (visibleType == HighlightVisibleType.Alpha)
            {
                int originAlpha = isOn ? 0 : 1;
                originCanvasGroup.alpha = originAlpha;
                
                float targetAlpha = isOn ? 1 : 0;
                clonedCanvasGroup.alpha = originAlpha;

                if (keepFade == false)
                {
                    clonedCanvasGroup.DOFade(targetAlpha, .3f);
                    clonedTransform.gameObject.SetActive(isOn);
                }
                else
                {
                    clonedCanvasGroup.DOFade(targetAlpha, .3f)
                                     .OnUpdate(() => clonedTransform.gameObject.SetActive(clonedCanvasGroup.alpha > 0));
                }

                SetInteractable(originCanvasGroup, !isOn);
            }
        }

        private void SetInteractable(CanvasGroup canvasGroup, bool value)
        {
            canvasGroup.interactable = value;
            canvasGroup.blocksRaycasts = value;
        }

        public void Dispose()
        {
            if (clonedTransform != null)
            {
                GameObject.Destroy(clonedTransform.gameObject);
                clonedTransform = null;
            }
        }
    }

    public enum HighlightVisibleType
    { 
        Active,
        Alpha   // 게임 오브젝트를 껐다 켜면 애니메이터가 초기화되기 때문에 Alpha 값만 조정하는 옵션을 두어 방지
    }

    public class HighlightPanel : MonoBehaviour
    {
        private List<HighlightObjectInfo> infos;
        private CanvasGroup rootCanvasGroup;
        private Vector3[] corners;

        public void Register(HighlightObjectInfo info)
        {
            if (infos == null)
            {
                infos = new List<HighlightObjectInfo>();
            }
            infos.Add(info);

            if (corners == null)
            {
                corners = new Vector3[4];
            }

            InitRootCanvasGroup();
            info.Clone(transform);
            info.SetCloneActive(info.initialActive);
            UpdatePositionAndSize();
        }

        public void Dispose()
        {
            if (infos != null && infos.Count > 0)
            {
                foreach (HighlightObjectInfo info in infos)
                {
                    info.SetCloneActive(false);
                    info.Dispose();
                }
                infos.Clear();
            }
        }

        protected virtual void Update()
        {
            UpdatePositionAndSize();
        }

        private void UpdatePositionAndSize()
        {
            if (infos != null)
            {
                foreach (HighlightObjectInfo info in infos)
                {
                    RectTransform originObject = info.originTransform;
                    RectTransform clonedObject = info.clonedTransform;

                    clonedObject.position = originObject.position;
                    clonedObject.sizeDelta = GetWorldRect(originObject).size;
                }
            }
        }

        private void InitRootCanvasGroup()
        {
            if (rootCanvasGroup == null)
            {
                rootCanvasGroup = GetComponent<CanvasGroup>();
                if (rootCanvasGroup == null)
                {
                    rootCanvasGroup = gameObject.AddComponent<CanvasGroup>();
                }
            }
        }

        private Rect GetWorldRect(RectTransform rt)
        {
            rt.GetWorldCorners(corners);
            Vector3 topLeft = corners[0];
            Vector2 rectTransformSize = new Vector2(rt.rect.size.x, rt.rect.size.y);

            return new Rect(topLeft, rectTransformSize);
        }
    }
}