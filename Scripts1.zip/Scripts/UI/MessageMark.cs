﻿using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;

namespace Underc.UI
{
    public class MessageMark : MonoBehaviour
    {
        public bool Enabled 
        { 
            get
            {
                return _enabled;
            }
            set
            {
                _enabled = value;
            }
        }
        private bool _enabled = true;
        
        #pragma warning disable 0649
        [SerializeField] private CanvasGroup canvasGroup;
        [SerializeField] private RectTransform rectTransform;
        [SerializeField] private float duration = 3f;
        #pragma warning restore 0649
        private Vector2 originPosition;
        private Sequence sequence;

        private void Awake()
        {
            originPosition = rectTransform.anchoredPosition;
        }
    
        public void Show(bool withAnimation, float delay = 0f)
        {
            if (Enabled == false)
            {
                gameObject.SetActive(false);
                return;
            }
            
            canvasGroup.gameObject.SetActive(true);
            if (withAnimation == true)
            {
                canvasGroup.alpha = 1;
                rectTransform.anchoredPosition = originPosition;

                sequence = DOTween.Sequence();
                sequence.Insert(0f, canvasGroup.DOFade(0, .295f).From().SetEase(Ease.OutQuint));
                sequence.Insert(0f, rectTransform.DOAnchorPosY(rectTransform.anchoredPosition.y + 30, .395f).From().SetEase(Ease.OutBack));
                sequence.SetDelay(delay);

                StopAllCoroutines();
                StartCoroutine(WaitToEnd());
            }
        }

        private IEnumerator WaitToEnd()
        {
            yield return new WaitForSeconds(duration);

            sequence = DOTween.Sequence();
            sequence.Insert(0f, canvasGroup.DOFade(0, .295f).SetEase(Ease.InQuint));
            sequence.Insert(0f, rectTransform.DOAnchorPosY(rectTransform.anchoredPosition.y + 30, .395f).SetEase(Ease.InBack));
        }

        public void Hide()
        {
            if (Enabled == false)
            {
                gameObject.SetActive(false);
                return;
            }
            
            canvasGroup.gameObject.SetActive(false);

            if (sequence != null)
            {
                StopAllCoroutines();
                
                sequence.Kill();
                sequence = null;
            }
        }
    }
}
