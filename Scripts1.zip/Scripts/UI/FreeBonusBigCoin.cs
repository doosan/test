using UnityEngine;
using System.Collections;
using Gaga.Sound;
using TMPro;
using Gaga.Util;
using Gaga.UI;
using DG.Tweening;
using Gaga;
using System;

namespace Underc.UI
{
    [RequireComponent(typeof(Animator))]
    public sealed class FreeBonusBigCoin : MonoBehaviour
    {
        public enum PlayType
        {
            Ready,
            Collect
        }

        [SerializeField] private GameObject coin;
        [SerializeField] private AnimatorParser onAnimation;

        [Header("Move")]
        [SerializeField] private RectTransform movingSource;
        [SerializeField] private RectTransform movingTarget;
        [SerializeField] private float movingDuration;
        [SerializeField] private AnimationCurve movingCurve;
        [SerializeField] private SoundPlayer moveSound;

        [Header("Collect")]
        [SerializeField] private float triggerDelay;
        [SerializeField] private AnimatorParser collectAnimation;
        [SerializeField] private SoundPlayer collectSound;

        [Header("Text")]
        [SerializeField] private TextMeshProUGUI coinText;
        [SerializeField] private bool useKMB = false;
        [SerializeField] private float coinCountingDuration = 1.0f;
        [SerializeField] private EasingFunction.Ease coinCountingEase;

        private Animator animator;
        private bool isCollect;
        private bool isComplete;

        private long coinValue;

        private float originPosX;

        private void Awake()
        {
            animator = GetComponent<Animator>();
        }

        public void Play(PlayType playType, long coin)
        {
            isCollect = false;
            isComplete = false;

            if (animator == null)
            {
                return;
            }

            coinValue = coin;
            coinText.SetNumber(0, true);

            if (playType == PlayType.Ready)
            {
                animator.SetTrigger("On");
            }
            else if (playType == PlayType.Collect)
            {
                _CollectBigCoin();
            }
        }

        public void CollectBigCoin()
        {
#if GGDEV
            Gaga.DeveloperTools.DeveloperTools.Instance.IsOn = false;
#endif

            if (originPosX == 0)
            {
                originPosX = movingSource.position.x;
            }

            _CollectBigCoin(RevertBigCoin);
        }

        private void RevertBigCoin()
        {
            Vector3 position = movingSource.position;
            movingSource.position = new Vector3(originPosX, position.y, position.z);

            onAnimation.SetTrigger();
        }

        private void _CollectBigCoin(Action onComplete = null)
        {
            StartCoroutine(CollectCoroutine(onComplete));
        }

        private IEnumerator CollectCoroutine(Action onComplete)
        {
            moveSound.Play();
            movingSource.DOMoveX(movingTarget.position.x, movingDuration)
                        .SetEase(movingCurve);

            yield return new WaitForSeconds(triggerDelay);

            collectAnimation.SetTrigger();
            yield return collectAnimation.WaitForDuration();

            onComplete?.Invoke();
        }

        public IEnumerator WaitForCollect()
        {
            while (isCollect == false)
            {
                yield return null;
            }
        }

        public IEnumerator WaitForComplete()
        {
            while (isComplete == false)
            {
                yield return null;
            }
        }

        public void OnCollected()
        {
            isCollect = true;
        }

        public void OnComplete()
        {
            isComplete = true;
        }

        public Vector2 GetCoinPosition()
        {
            return coin.transform.position;
        }

        public void CoinCounting()
        {
            collectSound.Play();
            if (useKMB)
            {
                coinText.SetNumber(coinValue, StringUtils.GeneralKMBOption(), coinCountingDuration, coinCountingEase);
            }
            else
            {
                coinText.SetNumber(coinValue, true, coinCountingDuration, coinCountingEase);
            }
        }
    }
}