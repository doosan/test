using UnityEngine;
using DG.Tweening;
using Underc.Lobby;
using Underc.User;
using UnityEngine.UI;
using TMPro;
using Gaga.Util;
using System.Collections;
using System;
using Gaga.Sound;
using Underc.Popup;
using Underc.Ocean;

namespace Underc.UI
{
    public sealed class SeaStoryHUD : MonoBehaviour
    {
        [Header("HUD")]
        [SerializeField] private Transform hud;
        [SerializeField] private Transform hudDefaultRoot;
        [SerializeField] private TextMeshProUGUI titleText;
        public bool updateTitleGuideMode = false;
        [SerializeField] private GameObject hudProgressRoot;
        [SerializeField] private GameObject hudTitleRoot;
        [SerializeField] private Button showDetailButton;
        [SerializeField] private SeaStoryProgressBar progressBar;
        public Vector2 ProgressBarPosition{get => progressBar.transform.position; }
        [SerializeField] private GameObject hudCompleteRoot;
        [SerializeField] private TextMeshProUGUI hudCompleteSeaText;

        [Header("Detail")]
        [SerializeField] private SeaStoryDetailView detail;
        [SerializeField] private Transform hudDetailRoot;
        [SerializeField] private float detailShowDistance;
        [SerializeField] private float detailShowDuration;
        [SerializeField] private AnimationCurve detailShowEase;
        [SerializeField] private float detailHideDuration;
        [SerializeField] private AnimationCurve detailHideEase;
        [SerializeField] private TextMeshProUGUI detailMissionText;

        [Header("Sounds")]
        [SerializeField] private SoundPlayer detailShowSFX;
        [SerializeField] private SoundPlayer detailHideSFX;

        private LobbyManager lobbyManager;
        private float originLocalY;
        private Transform cachedTransform;
        private bool isDetailViewOpen;
        private Coroutine autoHideCoroutine;
        private Action onHide;

        private void Awake()
        {
            lobbyManager = GetComponentInParent<LobbyManager>();
            cachedTransform = transform;
            detail.gameObject.SetActive(false);
            isDetailViewOpen = false;

            progressBar.onChapterChange += OnChapterChangeHandler;
            detail.onInteractionBegin += OnDetailInteractionBeginHandler;
        }

        private void Start()
        {
            originLocalY = transform.localPosition.y;

            hudProgressRoot.SetActive(true);
            Reset();  
        }

        public void Reset()
        {
            var seaStory = MyInfo.Ocean.CurrentSeaStory;
            progressBar.Initialize(seaStory.Point);

            hudCompleteSeaText.text = MyInfo.Ocean.CurrentSeaID.ToString();
            UpdateTitle(true);
        }

        public void Refresh()
        {
            progressBar.ResetState();
        }

        public bool Interactable
        {
            get => showDetailButton.interactable;
            set
            {
                showDetailButton.interactable = value;
            }
        }

        private void UpdateTitle(bool isProgressOn)
        {
            var isComplete = MyInfo.Ocean.CurrentStar == MyOcean.MAX_STARS;

            if (isComplete)
            {
                hudCompleteRoot.SetActive(true);
                hudProgressRoot.SetActive(false);
                hudTitleRoot.SetActive(false);
            }
            else
            {
                hudCompleteRoot.SetActive(false);
                hudProgressRoot.SetActive(isProgressOn);
                hudTitleRoot.SetActive(!isProgressOn);
            }

            showDetailButton.gameObject.SetActive(isProgressOn);
        }

        private void StartAutoHide(float time)
        {
            StopAutoHide();
            autoHideCoroutine = StartCoroutine(AutoHideCoroutine(time));
        }

        private void StopAutoHide()
        {
            if (autoHideCoroutine != null)
            {
                StopCoroutine(autoHideCoroutine);
                autoHideCoroutine = null;
            }
        }

        private IEnumerator AutoHideCoroutine(float time)
        {
            yield return new WaitForSeconds(time);
            HideDetailView();
        }

        public void ShowDetailView()
        {
            ShowDetailView(null);
        }

        public void ShowDetailView(Action onHide)
        {
            ShowDetailView(0.0f,  onHide);
        }

        public void ShowDetailView(float autoHideTime, Action onHide)
        {
            if (isDetailViewOpen)
            {
                return;
            }

            isDetailViewOpen = true;
            this.onHide = onHide;

            Popups.SeaMission()
                  .Async()
                  .OnClose(()=>
                  {
                      detailMissionText.text = SeaSystem.Instance.CurrentMission;
                      detailShowSFX.Play();

                      UpdateTitle(false);

                      lobbyManager.NpcManager.Hide();
                      detail.gameObject.SetActive(true);
                      detail.Refresh();

                      hud.SetParent(hudDetailRoot);
                      hud.localPosition = Vector3.zero;

                      cachedTransform.DOKill(false);
                      cachedTransform.DOLocalMoveY(originLocalY + detailShowDistance, detailShowDuration)
                                     .SetEase(detailShowEase);

                      if (autoHideTime > 0.0f)
                      {
                         StartAutoHide(autoHideTime);
                      }
                  });

        }

        public void HideDetailView()
        {
            if (isDetailViewOpen == false)
            {
                return;
            }

            detailHideSFX.Play();

            StopAutoHide();
            isDetailViewOpen = false;

            UpdateTitle(true);

            cachedTransform.DOLocalMoveY(originLocalY, detailHideDuration)
                           .SetEase(detailHideEase)
                           .OnComplete(()=>
                           {
                               lobbyManager.NpcManager.Show();
                               cachedTransform.DOKill(false);
                               detail.gameObject.SetActive(false);

                               hud.SetParent(hudDefaultRoot);
                               hud.localPosition = Vector3.zero;

                               Popups.SeaStoryInfo()
                                     .Async()
                                     .OnClose(()=>
                                     {
                                         onHide?.Invoke();
                                         onHide = null;
                                     });
                           });
        }

        public SeaStoryProgressBar GetProgressBar()
        {
            return progressBar;
        }

        private void OnChapterChangeHandler(int chapter, bool isGuide)
        {
            if (updateTitleGuideMode == false && isGuide)
            {
                return;
            }

            if (titleText == null)
            {
                return;
            }

            chapter++;
            
            var title = StringMaker.New()
                                   .Append("SEA STORY ")
                                   .Append(MyInfo.Ocean.CurrentSeaID.ToString())
                                   .Append("-")
                                   .Append(chapter.ToString())
                                   .Build();
                                  

            titleText.text = title;
        }

        private void OnDetailInteractionBeginHandler()
        {
            StopAutoHide();
        }
    }
}