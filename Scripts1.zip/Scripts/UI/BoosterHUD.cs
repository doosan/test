using Underc.User;
using UnityEngine;
using UnityEngine.UI;
using Gaga.Util;
using TMPro;
using System.Collections.Generic;
using System.Collections;
using System;
using DG.Tweening;

namespace Underc.UI
{
    public sealed class BoosterHUD : MonoBehaviour
    {
        public enum BoosterState
        {
            Msg, Time
        }

        public enum BoosterType
        {
            XP,
            SecondaryCurrencies
        }

        #pragma warning disable 0649
        [SerializeField] private GameObject root;
        [SerializeField] private BoosterType booster;
        [SerializeField] private Text timeText;
        [SerializeField] private TextMeshProUGUI timeTextTMPro;
        [SerializeField] private Animator boosterAnim;
        [SerializeField] private string boosterAnimTrigger = "2x";
        [SerializeField] private GameObject[] boosterIcons;
        #pragma warning restore 0649

        private long currentPearl;
        private long currentTicket;

        private string remainSecStr;
        private BoosterState state;
        private Dictionary<BoosterState, float> durationByState;
        private Sequence switchingSequence;

        private void Awake()
        {
            root.SetActive(false);
            SetAllIconsActive(false);

            durationByState = new Dictionary<BoosterState, float>()
            {
                { BoosterState.Msg, 10f },
                { BoosterState.Time, 3f }
            };
        }

        private void OnEnable()
        {
            SetState(BoosterState.Msg);
        }

        private void Start()
        {
            if (booster == BoosterType.XP)
            {
                InitializeXP();
            }
            else if (booster == BoosterType.SecondaryCurrencies)
            {
                InitializeSecondaryCurrencies();
            }
        }

        private void InitializeXP()
        {
            MyInfo.Booster.onXpRemainSeconds += OnRemainSec;
            OnRemainSec(MyInfo.Booster.XPRemainSec);
        }

        private void InitializeSecondaryCurrencies()
        {
            MyInfo.Booster.onSecondaryCurrenciesRemainSeconds += OnRemainSec;
            OnRemainSec(MyInfo.Booster.SecondaryCurrenciesRemainSec);

            currentPearl = MyInfo.Pearl;
            currentTicket = MyInfo.Ticket;

            MyInfo.OnPearlsChanged += OnPearlsChanged;
            MyInfo.OnTicketsChanged += OnTicketsChanged;
        }

        private void OnDestroy()
        {
            MyInfo.OnPearlsChanged -= OnPearlsChanged;
            MyInfo.OnTicketsChanged -= OnTicketsChanged;

            MyInfo.Booster.onXpRemainSeconds -= OnRemainSec;
            MyInfo.Booster.onSecondaryCurrenciesRemainSeconds -= OnRemainSec;
        }

        private void OnPearlsChanged(long value)
        {
            if (booster == BoosterType.SecondaryCurrencies)
            {
                if (currentPearl < value)
                {
                    currentPearl = value;
                    PlayBoosterAnimation();
                }
            }
        }

        private void OnTicketsChanged(long value)
        {
            if (booster == BoosterType.SecondaryCurrencies)
            {
                if (currentTicket < value)
                {
                    currentTicket = value;
                    PlayBoosterAnimation();
                }
            }
        }

        private void OnRemainSec(long remainSec)
        {
            bool isActive = remainSec > 0;

            if (isActive == true)
            {
                if (root.activeInHierarchy == false)
                {
                    root.SetActive(true);
                    SetAllIconsActive(true);
                }

                remainSecStr = remainSec.ToSummaryDHMS();
            }
            else
            {
                if (root.activeInHierarchy == true)
                {
                    root.SetActive(false);
                    SetAllIconsActive(false);
                }
            }
        }

        private void PlayBoosterAnimation()
        {
            if (boosterAnim != null)
            {
                boosterAnim.SetTrigger(boosterAnimTrigger);
            }
        }

        public void SetTimeState()
        {
            SetState(BoosterState.Time);
        }

        private void SetNextState()
        {
            int stateLength = Enum.GetNames(typeof(BoosterState)).Length;
            int nextStateIndex = (int)state + 1;
            if (nextStateIndex >= stateLength)
            {
                nextStateIndex = 0;
            }
            BoosterState nextState = (BoosterState)nextStateIndex;
            SetState(nextState);
        }

        private void SetState(BoosterState state)
        {
            this.state = state;

            string stateName = StringMaker.New()
                                          .Append(state.ToString())
                                          .Append("Coroutine")
                                          .Build();
            StopAllCoroutines();
            StartCoroutine(stateName);
        }

        private IEnumerator MsgCoroutine()
        {
            SwitchingEffect();

            float duration = durationByState[state];
            SetText("2X BOOST");
            yield return new WaitForSeconds(duration);

            SetNextState();
        }

        private IEnumerator TimeCoroutine()
        {
            SwitchingEffect();

            float duration = durationByState[state];
            float timeBegin = Time.time;
            float timePassed = 0;
            while (timePassed < duration)
            {
                SetText(remainSecStr);
                timePassed = Time.time - timeBegin;

                yield return null;
            }

            SetNextState();
        }

        private void SetText(string value)
        {
            if (timeText != null)
            {
                timeText.text = value;
            }

            if (timeTextTMPro != null)
            {
                timeTextTMPro.text = value;
            }
        }

        private void SwitchingEffect()
        {
            if (timeTextTMPro != null)
            {
                timeTextTMPro.SetAlpha(0f);
                timeTextTMPro.DOKill(true);
                timeTextTMPro.DOFade(1f, .345f).SetEase(Ease.OutCirc);
            }

            if (timeText != null)
            {
                timeText.SetAlpha(0f);
                timeText.DOKill(true);
                timeText.DOFade(1f, .345f).SetEase(Ease.OutCirc);
            }
        }

        private void SetAllIconsActive(bool isOn)
        {
            if (boosterIcons == null)
            {
                return;
            }

            for (int i = 0; i < boosterIcons.Length; i++)
            {
                boosterIcons[i].SetActive(isOn);
            }
        }
    }
}