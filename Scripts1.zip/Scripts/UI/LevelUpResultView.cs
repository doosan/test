using DG.Tweening;
using Gaga;
using Underc.Effect;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using Underc.Game;
using Gaga.Sound;

namespace Underc.UI
{
    public sealed class LevelUpResultView : MonoBehaviour
    {
        [SerializeField] private TopUI topUI;

        [Header("Coin")]
        [SerializeField] private Transform bonusCoinStartPos;

        [Header("Fish")]
        [SerializeField] private CurveMovement fishItemEffect;
        [SerializeField] private Image fishThumbnail;
        [SerializeField] private float fishItemStartDelay = 0.8f;
        [SerializeField] private float fishStartSize = 1.1f;
        [SerializeField] private float fishEndSize = 0.3f;
        [SerializeField] private float fishScaleUpEndDelay = 0.1f;
        [SerializeField] private float fishScaleUpTime = 0.3f;
        [SerializeField] private AnimationCurve fishScaleUpEase;
        [SerializeField] private AnimationCurve fishMoveEase;
        [SerializeField] private SoundPlayer fishCollectSFX;

        private Transform fishItemTransform;
        private RectTransform fishThumbTransfrom;
        private FishPot fishPot;

        private void Awake()
        {
            fishItemTransform = fishItemEffect.transform;
            fishThumbTransfrom = fishThumbnail.GetComponent<RectTransform>();
        }

        private void OnEnable()
        {
            fishItemEffect.gameObject.SetActive(false);
        }

        public void Result(long bonus, 
                           LevelUpFishBonusInfo fishBonus, 
                           VipClassType vipClass, 
                           long vipPoint)
        {
            ResultCoin(bonus);

            if (fishBonus.IsValid())
            {
                ResultFish(fishBonus);
            }

            if (vipClass != VipClassType.none)
            {
                ResultVipPoint(vipClass, vipPoint);
            }
        }

        private void ResultVipPoint(VipClassType vipClass, long vipPoint)
        {
            if (vipPoint > 0)
            {
                if (topUI != null)
                {
                    var startPos = bonusCoinStartPos.position;
                    var endPos = topUI.GetProfileButtonPosition();

                    EffectSystem.Instance.VipClass(
                        vipClass.ToString(),
                        (int)Mathf.Min(vipPoint, 15),
                        startPos,
                        endPos,
                        topUI.GetProfileIcon(),
                        onComplete: null,
                        onFirstArrived: null, 
                        onArrived: () => topUI.ProfileAnimation()
                    );
                }
            }
        }

        private void ResultCoin(long bonus)
        {
            if (bonus > 0)
            {
                if (topUI != null)
                {
                    var coinStartPos = bonusCoinStartPos.position;
                    var coinEndPos = topUI.GetCoinIconPosition();

                    EffectSystem.Instance.Coin(coinStartPos
                                                ,coinEndPos
                                                ,topUI.GetCoinIcon()
                                                ,null
                                                ,null
                                                ,()=>
                                                {
                                                    MyInfo.Coin += bonus;
                                                }
                                                ,()=>
                                                {
                                                    topUI.CoinIconAnimation();
                                                });
                }
                else
                {
                    MyInfo.Coin += bonus;
                }
            }
        }

        private void ResultFish(LevelUpFishBonusInfo fishBonus)
        {
            StartCoroutine(ResultFishCoroutine(fishBonus));
        }

        private IEnumerator ResultFishCoroutine(LevelUpFishBonusInfo fishBonus)
        {
            if (fishBonus.icon != null)
            {
                if (fishPot != null)
                {
                    fishPot.Show();
                }

                fishItemEffect.gameObject.SetActive(true);

                fishThumbnail.sprite = fishBonus.icon;
                fishThumbnail.preserveAspect = fishBonus.preserveAspect;
                fishThumbTransfrom.sizeDelta = fishBonus.size;

                fishItemTransform.position = fishBonus.position;

                fishItemTransform.DOKill(false);
                fishItemTransform.localScale = Vector3.one;

                yield return new WaitForSeconds(fishItemStartDelay);

                fishItemTransform.DOScale(new Vector3(fishStartSize, fishStartSize, 1.0f), fishScaleUpTime)
                                .SetEase(fishScaleUpEase);

                yield return new WaitForSeconds(fishScaleUpTime + fishScaleUpEndDelay);

                fishCollectSFX.Play();

                if (fishPot == null)
                {
                    fishItemEffect.Move(topUI.GetHomePosition(), ()=>
                    {
                        topUI.HomeIconAnimation();
                        fishItemEffect.gameObject.SetActive(false);
                    });
                }
                else
                {
                    fishItemEffect.Move(fishPot.GetCollectPosition(), ()=>
                    {
                        fishPot.ShowBadge(fishBonus.isNew, fishBonus.isPrize);
                        fishPot.CollectAnimation();
                        fishPot.Hide();

                        fishItemEffect.gameObject.SetActive(false);
                    });
                }

                fishItemTransform.DOScale(new Vector3(fishEndSize, fishEndSize, 1.0f), fishItemEffect.duration)
                                 .SetEase(fishMoveEase);
                
            }
            else
            {
                fishItemEffect.gameObject.SetActive(false);
            }
        }

        public void SetFishPot(FishPot fishPot)
        {
            this.fishPot = fishPot;
        }
    }
}