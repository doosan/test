using UnityEngine;
using System.Collections;
using System;
using UnityEngine.UI;
using Gaga.Util;
using Gaga.Sound;
using SlotGame.UI;
using Underc.User;

namespace Underc.UI
{
    [RequireComponent(typeof(Animator))]
    public sealed class SeaStoryBonusEffect : MonoBehaviour
    {
        [SerializeField] private GameObject rewardPosition;
        [SerializeField] private Text bonusText;
        [SerializeField] private SetNumberPlayer numberPlayer;
        [SerializeField] private float numberPlayerEndDelay = .5f;

        [Header("Sound")]
        [SerializeField] private SoundPlayer appearSFX;
        [SerializeField] private SoundPlayer openSFX;

        [Header("Vip Bonus Badge")]
        [SerializeField] private RectTransform vipBonusBadgePosition;
        [SerializeField] private AnimatorParser showAnimation;
        [SerializeField] private AnimatorParser hideAnimation;

        private long reward;
        private long vipBonus;
        private VipBenefitTableItemInfo tableItemInfo;
        private Action<Vector2> onReward;

        private VipBonusBadge vipBonusBadge;

        private void Awake()
        {
            Stop();
        }

        public IEnumerator Play(long reward, long vipBonus, VipBenefitTableItemInfo tableItemInfo, Action<Vector2> onReward)
        {
            this.reward = reward;
            this.vipBonus = vipBonus;
            this.tableItemInfo = tableItemInfo;
            this.onReward = onReward;

            Reset();

            gameObject.SetActive(false);
            gameObject.SetActive(true);

            yield return showAnimation.WaitForDuration();
            yield return vipBonusBadge.Show(onVipBonusAdding: () => numberPlayer.Play());
            vipBonusBadge.Hide();

            hideAnimation.SetTrigger();
            yield return hideAnimation.WaitForDuration();
            Stop();
        }

        private void Reset()
        {
            // 보상 금액 세팅
            bonusText.text = StringUtils.ToComma(reward);
            numberPlayer.startValue = reward;
            numberPlayer.endValue = reward + vipBonus;

            // Vip 보너스 배지 세팅
            vipBonusBadge = VipBonusBadgeSystem.Instance.Get(vipBonusBadgePosition);
            vipBonusBadge.Setup(targetTransform: bonusText.GetComponent<RectTransform>(),
                                vipBonus: vipBonus,
                                tableItemInfo: tableItemInfo);
        }

        public void Stop()
        {
            onReward = null;
            StopAllCoroutines();
            gameObject.SetActive(false);

            if (vipBonusBadge != null)
            {
                VipBonusBadgeSystem.Instance.Return(vipBonusBadge);
                vipBonusBadge = null;
            }
        }

        public void HandleReward()
        {
            onReward?.Invoke(rewardPosition.transform.position);
        }

        public void PlayAppearSFX()
        {
            appearSFX.Play();
        }

        public void PlayOpenSFX()
        {
            openSFX.Play();
        }
    }
}