using Gaga;
using Gaga.System;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.UI
{
    public class Pagenation : MonoBehaviour
    {
#pragma warning disable 0649
        [SerializeField] private GameObjectVisibleToggle pageIndicatorRef;
#pragma warning restore 0649
        private GameObjectPool<GameObjectVisibleToggle> pageIndicatorPool;
        private List<GameObjectVisibleToggle> pageIndicators;
        private int pageCount;
        private Action<int> onPageIndexChanged;

        private void Awake()
        {
            pageIndicatorRef.gameObject.SetActive(false);
        }

        public void Setup(int pageCount, int startingIndex, Action<int> onPageIndexChanged)
        {
            this.pageCount = pageCount;
            this.onPageIndexChanged = onPageIndexChanged;

            // Init
            if (pageIndicatorPool == null)
            {
                pageIndicatorPool = pageIndicatorRef.CreatePool<GameObjectVisibleToggle>(
                    rootName: "PageIndicatorPool",
                    parent: transform,
                    size: 3
                );

                pageIndicators = new List<GameObjectVisibleToggle>();
            }

            // Reset
            for (int i = 0; i < pageIndicators.Count; i++)
            {
                GameObjectVisibleToggle pageIndicator = pageIndicators[i];
                pageIndicator.GetComponent<Button>()
                             .onClick
                             .RemoveAllListeners();
                pageIndicatorPool.Return(pageIndicators[i]);
            }
            pageIndicators.Clear();

            // Add
            for (int i = 0; i < pageCount; i++)
            {
                int index = i;

                GameObjectVisibleToggle pageIndicator = pageIndicatorPool.Get();
                pageIndicator.transform.SetParent(transform, false);
                pageIndicators.Add(pageIndicator);

                pageIndicator.GetComponent<Button>()
                             .onClick
                             .AddListener(() => onPageIndexChanged?.Invoke(index));
            }

            SetPageIndicator(startingIndex);
        }

        public void SetPageIndicator(int index)
        {
            if (pageIndicators != null && index < pageIndicators.Count)
            {
                for (int i = 0; i < pageIndicators.Count; i++)
                {
                    GameObjectVisibleToggle indicator = pageIndicators[i];
                    indicator.IsOn = index == i;
                    indicator.gameObject.SetActive(pageCount > 1);
                }
            }
        }
    }
}