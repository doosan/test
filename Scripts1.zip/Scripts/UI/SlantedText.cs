﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

namespace Underc.UI
{
    [ExecuteInEditMode]
    public class SlantedText : MonoBehaviour
    {
        [Serializable]
        public sealed class CharacterInfo
        {
            public char character;
            public float width;
            public float offsetX;
        }

        [SerializeField] private Text[] texts;
        [SerializeField] private float defaultTextWidth = 100.0f;
        [SerializeField] private float verticalSpace = 10.0f;
        [SerializeField] private CharacterInfo[] charWidths = null;
        [SerializeField] private string currentString = string.Empty;

        private void UpdateTexts(string value)
        {
            if (texts == null || texts.Length == 0)
            {
                return;
            }

            currentString = value;

            if (string.IsNullOrEmpty(currentString))
            {
                ClearTexts();
                return;
            }

            var length = currentString.Length;
            var allWidth = GetStringWidth(value);

            var fistChInfo = GetCharWidth(value[0]);
            var firstChOffset = fistChInfo == null ? 0 : fistChInfo.offsetX;
            var firstChWidth = fistChInfo == null ? defaultTextWidth : fistChInfo.width;
            var startPosX = -allWidth * 0.5f + firstChWidth * 0.5f - firstChOffset * 0.5f;
            var targetX = startPosX;

            for (int i = 0; i < texts.Length; ++i)
            {
                var text = texts[i];
                if (i >= length)
                {
                    text.gameObject.SetActive(false);
                    continue;
                }

                var character = currentString[i];
                var charInfo = GetCharWidth(character);

                if( charInfo != null )
                {
                    targetX += charInfo.offsetX;
                }

                text.gameObject.SetActive(true);
                text.text = character.ToString();

                var textPosX = targetX;
                var textPosY = i * verticalSpace;
                text.transform.localPosition = new Vector2(textPosX, textPosY);

                if ( charInfo != null )
                {
                    targetX += charInfo.width;
                }
                else
                {
                    targetX += defaultTextWidth;
                }
            }
        }

        private float GetStringWidth(string value)
        {
            float ret = 0;
            for( int i = 0; i < value.Length; ++i)
            {
                var ch = value[i];
                var chInfo = GetCharWidth(ch);
                if ( chInfo == null )
                {
                    ret += defaultTextWidth;
                }
                else
                {
                    ret += chInfo.width + chInfo.offsetX;
                }
            }

            return ret;
        }

        private CharacterInfo GetCharWidth(char character)
        {
            CharacterInfo ret = null;

            foreach( var ch in charWidths)
            {
                if ( ch.character == character )
                {
                    ret = ch;
                    break;
                }
            }

            return ret;
        }

        private void ClearTexts()
        {
            for (int i = 0; i < texts.Length; ++i)
            {
                var text = texts[i];
                text.text = string.Empty;
                text.gameObject.SetActive(false);
            }
        }


        public string text
        {
            set
            {
                UpdateTexts(value);
            }
            get
            {
                var sb = new System.Text.StringBuilder();
                for (int i = 0; i < texts.Length; ++i)
                {
                    sb.Append(texts[i].text);
                }

                return sb.ToString();
            }
        }

#if UNITY_EDITOR
        private void Update()
        {
            if (!Application.isPlaying)
            {
                text = currentString;
            }
        }
#endif
    }
}