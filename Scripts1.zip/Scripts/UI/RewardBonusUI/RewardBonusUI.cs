using DG.Tweening;
using System.Collections.Generic;
using Underc.User;
using UnityEngine;
using UnityEngine.Serialization;

namespace Underc.UI
{
    public class RewardBonusUI : MonoBehaviour
    {
        [Header("BottomUI")]
        [FormerlySerializedAs("bottom")]
        [SerializeField] private GameBottomUI bottomUI = null;

        public GameBottomUI BottomUI
        {
            get => bottomUI;
        }

        public bool IsActive
        {
            get
            {
                return bottomUI.MissionIconManager.gameObject.activeSelf
                       || bottomUI.Obsidian.gameObject.activeSelf
                       || bottomUI.Golden.gameObject.activeSelf
                       || bottomUI.GotoSea.gameObject.activeSelf;
            }
        }

        private const float GAUGE_POSITION_WHEN_EXISTS_FISH = 75f;
        private const float RIGHTUI_MOVE_DISTANCE = 220.0f;
        private const float BOTTOMUI_MOVE_DISTANCE = -220.0f;

        private List<RewardInfo> rewardInfos;

        private void OnEnable()
        {
            Reset();
        }

        public void Reset()
        {
            bottomUI.Setup(null);
            bottomUI.CloseAll();
            bottomUI.CachedTransform.anchoredPosition = new Vector2(0, BOTTOMUI_MOVE_DISTANCE);
        }

        public void Setup(List<RewardInfo> rewardInfos)
        {
            this.rewardInfos = rewardInfos;

            bool clamHarvestVisible = RewardContains(RewardType.s_pickaxe) 
                                      || RewardContains(RewardType.g_pickaxe);
            bool obsidianVisible = RewardContains(RewardType.obsidian);
            bool goldenVisible = RewardContains(RewardType.golden);
            bool gotoSeaVisible = RewardContains(RewardType.fish);

            Setup(clamHarvestVisible,
                  obsidianVisible,
                  goldenVisible,
                  gotoSeaVisible);
        }

        private bool RewardContains(RewardType rewardType)
        {
            bool result = false;
            foreach (RewardInfo rewardInfo in rewardInfos)
            {
                if (rewardInfo.type == rewardType)
                {
                    result = true;
                    break;
                }
            }

            return result;
        }

        public void Setup(bool clamHarvestVisible = false,
                          bool obsidianChestVisible = false, 
                          bool goldenChestVisible = false, 
                          bool gotoSeaVisible = false)
        {
            // 보상 팝업의 Bonus UI 에서는 항상 보이도록
            bottomUI.MissionIconManager.gameObject.SetActive(clamHarvestVisible);
            if (clamHarvestVisible)
            {
                BaseMissionIcon missionIcon = bottomUI.MissionIconManager.GetIcon(MissionIconType.ClamHarvest);
                missionIcon.Switch(showBadge: true);
            }

            //
            bottomUI.Obsidian.gameObject.SetActive(obsidianChestVisible);
            bottomUI.Golden.gameObject.SetActive(goldenChestVisible);
            bottomUI.GotoSea.gameObject.SetActive(gotoSeaVisible);
        }

        public void Show()
        {
            bottomUI.CachedTransform
                    .DOAnchorPosY(0f, 0.3f)
                    .SetEase(Ease.OutSine);

            bottomUI.Show();
        }

        public void Hide()
        {
            bottomUI.CachedTransform
                    .DOAnchorPosY(BOTTOMUI_MOVE_DISTANCE, 0.3f)
                    .SetEase(Ease.OutSine)
                    .OnComplete(() => bottomUI.Hide());
        }
    }
}
