using Gaga.AssetBundle;
using Gaga.System;
using System;
using Underc.Util;
using UnityEngine;

namespace Underc.UI
{
    public class RewardBonusUISystem : GameObjectSingleton<RewardBonusUISystem> 
    {
        private GameObjectPool<RewardBonusUI> pool;
        private GameObject poolRoot;

        public RewardBonusUI Get(Transform parent = null)
        {
            var bottomUI = pool.Get();
            if (parent != null)
            {
                bottomUI.transform.SetParent(parent, false);
            }

            return bottomUI;
        }

        public void Return(RewardBonusUI bonusUI)
        {
            pool.Return(bonusUI);
        }

        public void Preload(Action<bool> onComplete, Action<int> onProgress)
        {
            if (pool == null)
            {
                AssetBundleSystem.Instance.Load(
                    loadType: AssetBundleLoadType.Load,
                    url: Net.Address.CDN_ASSETBUNDLES,
                    assetBundleName: AssetBundleName.REWARD_BONUS_UI,
                    onLoadComplete: (bool success, Gaga.AssetBundle.AssetBundle assetBundle) =>
                    {
                        if (success)
                        {
                            SetupPool(assetBundle);
                        }

                        onComplete(success);
                    },
                    onLoadProgress: progress =>
                    {
                        int progressVal = (int)(progress * 100.0f);
                        onProgress(progressVal);
                    }
                );
            }
            else
            {
                onProgress(100);
                onComplete(true);
            }
        }

        private void SetupPool(Gaga.AssetBundle.AssetBundle assetBundle)
        {
            if (pool == null)
            {
                poolRoot = new GameObject("PoolRoot");
                poolRoot.transform.SetParent(transform);

                pool = new GameObjectPool<RewardBonusUI>(
                    root: poolRoot,
                    size: 2,
                    () =>
                    {
                        var newBonusUI = assetBundle.GetGameObject("RewardBonusUI", true)
                                                    .GetComponent<RewardBonusUI>();
                        return newBonusUI;
                    }
                );
            }
        }
    }
}