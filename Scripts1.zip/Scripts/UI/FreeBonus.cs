using Underc.User;
using UnityEngine;
using UnityEngine.UI;
using Gaga.Util;
using TMPro;
using System.Collections.Generic;
using System.Collections;
using System;
using Gaga;
using Underc.Lobby;
using Underc.Net;
using Underc.Popup;
using Underc.Effect;
using Gaga.UI;
using static Gaga.EasingFunction;

namespace Underc.UI
{
    public sealed class FreeBonus : MonoBehaviour
    {
        private enum State
        {
            ProgressState, //보너스 진행중
            CompleteState, //보너스 수령 가능 
            ClaimState     //보너스 수령
        }

        [Header("Info")]
        [SerializeField] private TextMeshProUGUI coinText;
        [SerializeField] private TextMeshProUGUI timeText;
        [SerializeField] private Animator claimAnimator;
        [SerializeField] private FreeBonusBigCoin bigCoin;
        [SerializeField] private int bonusEffectCount = 25;
        [SerializeField] private Transform bonusEffectStartPos;
        [SerializeField] private int bigBonusEffectCount = 50;

        [Header("Sliders")]
        [SerializeField] private Slider stepSlider1;
        [SerializeField] private Slider stepSlider2;
        [SerializeField] private Slider stepSlider3;
        [SerializeField] private Slider stepSlider4;

        [Header("Text Group")]
        [SerializeField] private GameObject normalBonus;
        [SerializeField] private GameObject hugeBonus;

        [Header("Reward")]
        [SerializeField] private GameObject rewardCoinRoot;
        [SerializeField] private TextMeshProUGUI rewardCoinText;
        [SerializeField] private bool rewardCoinUseKMB = false;
        public float rewardCoinCountingDuration = 1.0f;
        public Ease rewardCoinCountingEase;

        private List<Slider> stepSliders;
        private LobbyManager lobbyManager;
        private State state;
        private long rewardCoin;

        private bool tempInteractable;

        private void Awake()
        {
            lobbyManager = GetComponentInParent<LobbyManager>();

            stepSliders = new List<Slider>();
            stepSliders.Add(stepSlider1);
            stepSliders.Add(stepSlider2);
            stepSliders.Add(stepSlider3);
            stepSliders.Add(stepSlider4);
            stepSliders.Add(null);
        }

        private void OnEnable()
        {
            StartCoroutine("FSM");
        }

        private IEnumerator FSM()
        {
            if (MyInfo.CasinoBonus.IsFreeBonusReady)
            {
                state = State.CompleteState; 
            }
            else
            {
                state = State.ProgressState; 
            }
            
            while (true)
            {
                var stateName = state.ToString();
                yield return StartCoroutine(stateName); 
            }
        }

        private IEnumerator ProgressState()
        {
            while (state == State.ProgressState)
            {
                if (MyInfo.CasinoBonus.IsFreeBonusReady)
                {
                    state = State.CompleteState;
                    break;
                }

                UdpateSliders();
                UpdateTimeInfo();

                yield return MyInfo.CasinoBonus.WaitForTimeUpdate(this);
            }
        }

        private IEnumerator CompleteState()
        {
            claimAnimator.SetTrigger("On");

            UdpateSliders();

            if (IsLastIndex())
            {
                bigCoin.Play(FreeBonusBigCoin.PlayType.Ready, 0);

                normalBonus.SetActive(false);
                hugeBonus.SetActive(true);
            }
            else
            {
                normalBonus.SetActive(true);
                hugeBonus.SetActive(false);
            }

            while (state == State.CompleteState)
            {
                yield return null;
            }

            if (state != State.ClaimState)
            {
                claimAnimator.SetTrigger("Press");
            }
        }

        private IEnumerator ClaimState()
        {
            rewardCoinRoot.SetActive(false);

            tempInteractable = false;
            bool isLastIndex = IsLastIndex();

            if (lobbyManager != null)
            {
                tempInteractable = lobbyManager.Interactable;
                lobbyManager.Interactable = false;
            }

            var req = NetworkSystem.HTTPRequester.FreeBonusClaim();
            float t = 0.0f;
            bool isShowLoading = false;

            while (req.isDone == false)
            {
                if (t > 1.0f && isShowLoading == false)
                {
                    isShowLoading = true;
                    Popups.ShowLoading();
                }

                yield return null;
                t += Time.deltaTime;
            }

            rewardCoin = 0;

            if (req.isSuccess)
            {
                var rewardData = req.data.data;

                if (rewardData != null)
                {
                    rewardCoin = rewardData.coin;
                    
                    if (rewardCoin > 0 && rewardData.next != null)
                    {
                        MyInfo.CasinoBonus.Update(rewardData.next);
                    }
                }

                UndercGameLog.Fobis.ButtonLobbyMenu(5);
            }

            if (isShowLoading)
            {
                Popups.HideLoading();
            }

            claimAnimator.SetTrigger("Press");

            if (rewardCoin > 0)
            {
               StartCoroutine(CollectCoin(isLastIndex, rewardCoin));
            }
            else
            {
                RestoreLobbyInteractable();
            }

            claimAnimator.SetTrigger("Press");
            state = State.ProgressState;
        }

        private void RestoreLobbyInteractable()
        {
            if (lobbyManager != null)
            {
                lobbyManager.Interactable = tempInteractable;
            }
        }

        private IEnumerator CollectCoin(bool isLastIndex, long rewardCoin)
        {
            var endPos = lobbyManager == null ? new Vector2(0.0f, 10.0f) : lobbyManager.TopUI.GetCoinIconPosition();
            var scaleTarget = lobbyManager == null ? null : lobbyManager.TopUI.GetCoinIcon();

            bool waitForCoinEffect = true;
            if (isLastIndex)
            {
                bigCoin.Play(FreeBonusBigCoin.PlayType.Collect, rewardCoin);

                yield return bigCoin.WaitForCollect();

                var startPos = bigCoin.GetCoinPosition();

                EffectSystem.Instance.Coin (count: bigBonusEffectCount,
                                            startPosition: startPos,
                                            endPosition: endPos,
                                            scaleTarget: scaleTarget,
                                            onComplete: completeType => waitForCoinEffect = false,
                                            onFirstCoinArrived: () => MyInfo.Coin += rewardCoin,
                                            onCoinArrived: () =>
                                            {
                                                if (lobbyManager != null)
                                                {
                                                    lobbyManager.TopUI.CoinIconAnimation();
                                                }
                                            });

                yield return bigCoin.WaitForComplete();
            }
            else
            {
                rewardCoinRoot.SetActive(true);
                rewardCoinText.SetNumber(0, false);
                var startPos = bonusEffectStartPos.position;

                EffectSystem.Instance.Coin (count: bonusEffectCount,
                                            startPosition: startPos,
                                            endPosition: endPos,
                                            onComplete: completeType => waitForCoinEffect = false,
                                            onFirstCoinArrived: () => MyInfo.Coin += rewardCoin,
                                            onCoinArrived: () =>
                                            {
                                                if (lobbyManager != null)
                                                {
                                                    lobbyManager.TopUI.CoinIconAnimation();
                                                }
                                            });
            }
            RestoreLobbyInteractable();

            while (waitForCoinEffect)
            {
                yield return null;
            }

            yield return LoadCasinoBonus();
        }

        private IEnumerator LoadCasinoBonus()
        {
            Popups.ShowLoading(false);
            var casinoBonusReq = NetworkSystem.HTTPRequester.CasinoBonus();
            yield return casinoBonusReq.WaitForResponse();
            Popups.HideLoading();

            if (casinoBonusReq.isSuccess == true)
            {
                NetworkSystem.HTTPHandler.Do(casinoBonusReq.data);
            }
            yield break;
        }

        public void Claim()
        {
            if (state == State.CompleteState)
            {
                state = State.ClaimState;
            }
        }

        private void UdpateSliders()
        {
            for (int index = 0; index < stepSliders.Count; index++)
            {
                var slider = stepSliders[index];

                if (slider != null)
                {
                    slider.interactable = false;

                    if (index < MyInfo.CasinoBonus.FreeBonusIndex)
                    {
                        slider.value = 1.0f;
                    }
                    else if (index > MyInfo.CasinoBonus.FreeBonusIndex)
                    {
                        slider.value = 0.0f;
                    }
                    else
                    {
                        float currentValue =  GlobalTime.Instance.GetTimeStamp() - MyInfo.CasinoBonus.FreeBonusStartTimeStamp;
                        float sliderValue = currentValue / (float)MyInfo.CasinoBonus.FreeBonusTotalSec;
                        slider.value = sliderValue;
                    }
                }
            }
        }

        private void UpdateTimeInfo()
        {
            coinText.text = StringUtils.ToKMB(MyInfo.CasinoBonus.FreeBonusCoin);

            TimeSpan ts = TimeSpan.FromSeconds(MyInfo.CasinoBonus.FreeBonusRemainingSec);
            timeText.text = ts.ToString("hh\\:mm\\:ss");
        }

        private bool IsLastIndex()
        {
            return MyInfo.CasinoBonus.FreeBonusIndex == 4;
        }

        public void RewardCoinCounting()
        {
            if (rewardCoinUseKMB)
            {
                rewardCoinText.SetNumber(rewardCoin, StringUtils.GeneralKMBOption(), rewardCoinCountingDuration, rewardCoinCountingEase);
            }
            else
            {
                rewardCoinText.SetNumber(rewardCoin, true, rewardCoinCountingDuration, rewardCoinCountingEase);
            }
        }
    }
}