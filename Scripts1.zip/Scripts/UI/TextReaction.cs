using DG.Tweening;
using Gaga.Util;
using TMPro;
using UnityEngine;

namespace Underc.UI
{
    public class TextReaction : MonoBehaviour
    {
#pragma warning disable
        [SerializeField] private TextMeshProUGUI targetText;
        [SerializeField] private string msgOrigin = "COPY";
        [SerializeField] private string msgReact = "COPIED";
#pragma warning restore
        private float copiedDuration = .345f;
        private Ease copiedEase = Ease.OutCirc;
        private Sequence sequence;

        private void Start()
        {
            sequence = DOTween.Sequence();
            sequence.AppendCallback(() =>
                    {
                        targetText.text = msgReact;
                        targetText.SetAlpha(0f);
                    })
                    .Append(targetText.DOFade(1f, copiedDuration).SetEase(copiedEase))
                    .AppendCallback(() =>
                    {
                        targetText.text = msgOrigin;
                        targetText.SetAlpha(0f);
                    })
                    .Append(targetText.DOFade(1f, copiedDuration).SetEase(copiedEase));
            sequence.SetAutoKill(false);
            sequence.Pause();
        }

        public void Do()
        {
            sequence.Restart();
        }
    }
}
