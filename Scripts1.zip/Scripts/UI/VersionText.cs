using Gaga.AssetBundle;
using Gaga.Util;
using Underc.Net;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.UI
{
    [RequireComponent(typeof(Text))]
    public sealed class VersionText : MonoBehaviour
    {
        private void Awake()
        {
            AssetBundleSystem.Instance.OnDisplayVersionChanged.AddListener(OnAssetbundleVersionChanged);
            GetComponent<Text>().text = AppService.GetAppVersion();
        }

        private void OnDestroy()
        {
            AssetBundleSystem.Instance.OnDisplayVersionChanged.RemoveListener(OnAssetbundleVersionChanged);
        }

        private void OnAssetbundleVersionChanged()
        {
            GetComponent<Text>().text = AppService.GetAppVersion();
        }
    }
}