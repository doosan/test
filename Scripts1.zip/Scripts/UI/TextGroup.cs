using Gaga.System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.UI
{
    public class TextGroup : MonoBehaviour
    {
        [SerializeField] private GameObject textPoolRoot;
        [SerializeField] private Text textRef;

        public string TextValue
        {
            private get
            {
                return textValue;
            }
            set
            {
                textValue = value;
                UpdateText();
            }
        }
        private string textValue;

        private string latestTextValue;

        private GameObjectPool<Text> textPool;
        private List<Text> texts;

        private RectTransform CachedTransform
        {
            get
            {
                if (cachedTransform == null)
                {
                    cachedTransform = GetComponent<RectTransform>();
                }
                return cachedTransform;
            }
        }
        private RectTransform cachedTransform;

        private void Init()
        {
            textPool = new GameObjectPool<Text>(
                root: textPoolRoot,
                size: 4,
                create: () =>
                {
                    var text = Instantiate(textRef);
                    return text;
                }
            );

            texts = new List<Text>();
        }

        private void UpdateText()
        {
            if (textPool == null)
            {
                Init();
            }

            if (string.IsNullOrEmpty(TextValue) == false
                && TextValue != latestTextValue)
            {
                Debug.Log($"==== {latestTextValue} -> {TextValue}");
                foreach (Text text in texts)
                {
                    textPool.Return(text);
                }
                texts.Clear();

                foreach (char c in TextValue)
                {
                    Text text = textPool.Get();
                    text.text = c.ToString();
                    text.transform.SetParent(CachedTransform);
                    texts.Add(text);
                }
            }

            latestTextValue = TextValue;
        }
    }
}