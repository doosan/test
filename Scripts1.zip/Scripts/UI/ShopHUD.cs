using System.Collections;
using System.Collections.Generic;
using Underc.User;
using UnityEngine;
using TMPro;
using Gaga.Util;

namespace Underc.UI
{
    public class ShopHUD : MonoBehaviour
    {
        public enum ShopState
        {
            None = 0,
            Shop = 1,
            Sale = 2,
            ShopDeal = 3,
            SaleDeal = 4
        }

        private readonly int ANIM_STATE = Animator.StringToHash("State");

#pragma warning disable 0649
        [SerializeField] private Animator stateAnim = null;

        [Header("Deal")]
        [SerializeField] private TextMeshProUGUI dealTimeText = null;
        [SerializeField] private TextMeshProUGUI dealTimeTextWithSale = null;

        [Header("Sale")]
        [SerializeField] private TextMeshProUGUI saleTimeText = null;
        [SerializeField] private TextMeshProUGUI saleTimeTextWithDeal = null;
#pragma warning restore 0649


        private ShopState currentState;

        private void OnEnable()
        {
            MyInfo.Deal.onChange += OnDealChanged;
            MyInfo.Shop.CoinSale.onTimeUpdate.AddListener(OnSaleUpdated);
        }

        private void OnDisable()
        {
            MyInfo.Deal.onChange -= OnDealChanged;
            MyInfo.Shop.CoinSale.onTimeUpdate.RemoveListener(OnSaleUpdated);
            currentState = ShopState.None;
        }

        private void Start()
        {
            CheckShopStatus();
            UpdateDealTime();
        }

        private void OnDealChanged(MyDeal deal)
        {
            CheckShopStatus();
            UpdateDealTime();
        }

        private void OnSaleUpdated()
        {
            CheckShopStatus();
            UpdateSaleTime();
        }

        private void CheckShopStatus()
        {
            ShopState newState = DetermineShopState();
            ChangeState(newState);
        }

        private ShopState DetermineShopState()
        {
            ShopState newState = currentState;

            bool hasDeal = MyInfo.Deal.HasDeal;
            bool hasSale = MyInfo.Shop.CoinSale.HasSale;

            if (hasDeal == false && hasSale == false)
            {
                newState = ShopState.Shop;
            }
            else if (hasDeal == false && hasSale == true)
            {
                newState = ShopState.Sale;
            }
            else if (hasDeal == true && hasSale == false)
            {
                newState = ShopState.ShopDeal;
            }
            else if (hasDeal == true && hasSale == true)
            {
                newState = ShopState.SaleDeal;
            }

            return newState;
        }

        private void ChangeState(ShopState newState)
        {
            if (newState == ShopState.None || currentState == newState)
            {
                return;
            }

            currentState = newState;
            int stateInt = (int)currentState;

            stateAnim.SetInteger(ANIM_STATE, stateInt);

            StartCoroutine(GetStateLoop());
        }

        private IEnumerator GetStateLoop()
        {
            switch (currentState)
            {
                case ShopState.Shop:
                    return ShopStateLoop();

                case ShopState.Sale:
                    return SaleStateLoop();

                case ShopState.ShopDeal:
                    return ShopDealStateLoop();

                case ShopState.SaleDeal:
                    return SaleDealStateLoop();

                default:
                    return null;
            }
        }


        private IEnumerator ShopStateLoop()
        {
            while (currentState == ShopState.Shop)
            {
                yield return null;
            }
        }

        private IEnumerator SaleStateLoop()
        {
            while (currentState == ShopState.Sale)
            {
                yield return null;
            }
        }

        private IEnumerator ShopDealStateLoop()
        {
            while (currentState == ShopState.ShopDeal)
            {
                yield return null;
            }
        }

        private IEnumerator SaleDealStateLoop()
        {
            while (currentState == ShopState.SaleDeal)
            {
                yield return null;
            }
        }

        private void UpdateSaleTime()
        {
            TextMeshProUGUI relativeSaleTimeText = null;
            if (currentState == ShopState.Sale)
            {
                relativeSaleTimeText = saleTimeText;
            }
            else if (currentState == ShopState.SaleDeal)
            {
                relativeSaleTimeText = saleTimeTextWithDeal;
            }

            if (relativeSaleTimeText != null)
            {
                relativeSaleTimeText.text = MyInfo.Shop.CoinSale.RemainingSec.ToSummaryDHMS();
            }
        }

        private void UpdateDealTime()
        {
            TextMeshProUGUI relativeSaleTimeText = null;
            if (currentState == ShopState.ShopDeal)
            {
                relativeSaleTimeText = dealTimeText;
            }
            else if (currentState == ShopState.SaleDeal)
            {
                relativeSaleTimeText = dealTimeTextWithSale;
            }

            if (relativeSaleTimeText != null)
            {
                relativeSaleTimeText.text = MyInfo.Deal.RemainingSec.ToSummaryDHMS();
            }
        }
    }
}