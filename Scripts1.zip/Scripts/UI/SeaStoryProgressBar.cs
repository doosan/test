using UnityEngine;
using System.Collections.Generic;
using Gaga.UI;
using DG.Tweening;
using Underc.User;
using System;
using Gaga.Util;

namespace Underc.UI
{
    public enum SeaStoryBonusState
    {
        Idle, // 기본상태
        Reached, // 보너스 도달
        Complete, // 보너스 수령
        End // 보너스 수령 완료
    }

    public sealed class SeaStoryChapterInfo
    {
        public long start;

        public long bonus1;
        public long bonus2;
        public long bonus3;
        public long goal;

        public SeaStoryBonusState bonus1State;
        public SeaStoryBonusState bonus2State;
        public SeaStoryBonusState bonus3State;
        public SeaStoryBonusState goalState;

        public long GetRelativeGoal()
        {
            return goal - start;
        }

        public long GetRelativeBonus1()
        {
            return bonus1 - start;
        }

        public long GetRelativeBonus2()
        {
            return bonus2 - start;
        }

        public long GetRelativeBonus3()
        {
            return bonus3 - start;
        }
    }

    public sealed class SeaStoryProgressBar : MonoBehaviour
    {
        private sealed class SeaStoryChapter
        {
            public SeaStoryChapterInfo info;
            public SeaStoryChapterView view;

            public SeaStoryChapter(SeaStoryChapterView view, SeaStoryChapterInfo info)
            {
                this.view = view;
                this.info = info;
            }
        }

        public struct NextBonusInfo
        {
            public int chapterIndex;
            public long remainPoint;
            public string remainPointText;
            public RectTransform target;
            public bool isGoal;

            public bool IsValid => target != null;
        }

        public event Action<int, bool> onChapterChange;

        [SerializeField] private ListView listView;
        public ListView ListView{get => listView;}

        [SerializeField] private SeaStoryChapterView seaStoryChapter1;
        [SerializeField] private SeaStoryChapterView seaStoryChapter2;
        [SerializeField] private SeaStoryChapterView seaStoryChapter3;

        [Space]
        public float guidePagingAnimationTime = 1.0f;

        public event Action<int, int, SeaStoryBonusState, RectTransform> onBonusClick;

        private List<SeaStoryChapter> seaStoryChapters;
        private long mainValue;
        private long guideValue;

        private void Awake()
        {
            SetEffectActive(false);
        }
        
        public void Initialize(long value)
        {
            var seaStory = MyInfo.Ocean.CurrentSeaStory;
            SeaStoryChapterInfo[] infoList = new SeaStoryChapterInfo[MySeaStory.CHAPTER_COUNT];

            for (int chapterIndex = 0; chapterIndex < infoList.Length; chapterIndex++)
            {
                SeaStoryChapterInfo info = new SeaStoryChapterInfo();
                info.start = chapterIndex == 0 ? 0 : infoList[chapterIndex - 1].goal;
                info.bonus1 = seaStory.GetPoint(chapterIndex, 0);
                info.bonus2 = seaStory.GetPoint(chapterIndex, 1);
                info.bonus3 = seaStory.GetPoint(chapterIndex, 2);
                info.goal = seaStory.GetPoint(chapterIndex, 3);

                infoList[chapterIndex] = info;
            }

            Initialize(value, infoList[0], infoList[1], infoList[2]);
        }

        public void Initialize(long value, SeaStoryChapterInfo chapter1, SeaStoryChapterInfo chapter2, SeaStoryChapterInfo chapter3)
        {
            mainValue = 0;
            guideValue = 0;

            seaStoryChapter1.Initialize(chapter1, 0);
            seaStoryChapter2.Initialize(chapter2, 1);
            seaStoryChapter3.Initialize(chapter3, 2);

            seaStoryChapter1.onBonusClick -= onBonusClick;
            seaStoryChapter2.onBonusClick -= onBonusClick;
            seaStoryChapter3.onBonusClick -= onBonusClick;

            seaStoryChapter1.onBonusClick += onBonusClick;
            seaStoryChapter2.onBonusClick += onBonusClick;
            seaStoryChapter3.onBonusClick += onBonusClick;

            seaStoryChapters = new List<SeaStoryChapter>();
            seaStoryChapters.Add(new SeaStoryChapter(seaStoryChapter1, chapter1));
            seaStoryChapters.Add(new SeaStoryChapter(seaStoryChapter2, chapter2));
            seaStoryChapters.Add(new SeaStoryChapter(seaStoryChapter3, chapter3));

            listView.RemoveAllItems(false);

            foreach (var chapter in seaStoryChapters)
            {
                listView.AddItem(chapter.view.CachedTransform);
            }

            SetMainValue(value, true, false);
            SetGuideValue(value, false);

            ResetState();
        }

        public void ResetState()
        {
            for (int index = 0; index < seaStoryChapters.Count; index++)
            {
                var chapter = seaStoryChapters[index];

                if (chapter.info.bonus1State == SeaStoryBonusState.Complete)
                {
                    SetBonusState(index, 0, SeaStoryBonusState.End);
                }

                if (chapter.info.bonus2State == SeaStoryBonusState.Complete)
                {
                    SetBonusState(index, 1, SeaStoryBonusState.End);
                }

                if (chapter.info.bonus3State == SeaStoryBonusState.Complete)
                {
                    SetBonusState(index, 2, SeaStoryBonusState.End);
                }
            }
        }

        private bool IsInitialize()
        {
            return seaStoryChapters != null && seaStoryChapters.Count > 0;
        }

        private void PrintInitializeWarning()
        {
            Debug.Log("You must initialize first.");
        }

        public void SetMainValue(long value, bool enableListMovement = true, bool enablePagingAnimation = true, bool updateText = true)
        {
            if (IsInitialize() == false)
            {
                PrintInitializeWarning();
                return;
            }

            SetMainValue(value, 0.0f, Ease.Linear, enableListMovement, enablePagingAnimation, updateText);
        }

        public void SetMainValue(long value, float duration, Ease ease = Ease.Linear, bool enableListMovement = true, bool enablePagingAnimation = true, bool updateText = true)
        {
            if (IsInitialize() == false)
            {
                PrintInitializeWarning();
                return;
            }

            if (duration == 0.0f)
            {
                mainValue = value;
                SetValue(value, false, true, enablePagingAnimation, SeaStoryBonusState.End, updateText);
            }
            else
            {
                SetValue(mainValue, false, true, enablePagingAnimation, SeaStoryBonusState.End, updateText);

                DOTween.Kill("seaStoryMainSlider", false);
                DOTween.To(()=> mainValue,
                           v => {
                                    mainValue = v;
                                    SetValue(mainValue, false, enableListMovement, enablePagingAnimation, SeaStoryBonusState.Reached, updateText); 
                                },
                           value,
                           duration)
                       .SetEase(ease)
                       .SetId("seaStoryMainSlider");
            }
        }

        public void SetGuideValue(long value, bool enablePagingAnimation = true, bool enableListMovement = true, bool updateText = true)
        {
            if (IsInitialize() == false)
            {
                PrintInitializeWarning();
                return;
            }
            
            guideValue = value;

            if (guideValue < mainValue)
            {
                SetValue(mainValue, true, false, false, SeaStoryBonusState.Idle, updateText);
            }
            else
            {
                SetValue(value, true, enableListMovement, enablePagingAnimation, SeaStoryBonusState.Idle, updateText);
            }
        }

        public void SetGuideValue(long value, float duration, Ease ease = Ease.Linear, bool enablePagingAnimation = true, bool updateText = true)
        {
            if (IsInitialize() == false)
            {
                PrintInitializeWarning();
                return;
            }

            if (value < mainValue)
            {
                value = mainValue;
            }

            if (duration == 0.0f || (guideValue <= mainValue && value <= mainValue))
            {
                guideValue = value;
                SetValue(value, true, true, enablePagingAnimation, SeaStoryBonusState.End, updateText);
            }
            else
            {
                SetValue(guideValue, true, true, enablePagingAnimation, SeaStoryBonusState.End, updateText);

                DOTween.Kill("seaStoryGuideSlider", false);
                DOTween.To(()=> guideValue,
                           v => {
                                    guideValue = v;
                                    SetValue(guideValue, true, true, enablePagingAnimation, SeaStoryBonusState.Reached, updateText); 
                                },
                           value,
                           duration)
                       .SetEase(ease)
                       .SetId("seaStoryGuideSlider");
            }
        }

        private void SetValue(long value, bool isGuide, bool enableListMovement, bool enablePagingAnimation, SeaStoryBonusState completeState, bool updateText)
        {
            int chapterIndex = 0;

            for (int index = 0; index < seaStoryChapters.Count; index++)
            {
                var chapter = seaStoryChapters[index];
                var chapterGoal = chapter.info.GetRelativeGoal();
                var chapterValue = value - chapter.info.start;

                if (index + 1 < seaStoryChapters.Count 
                        && value > chapter.info.goal)
                {
                    chapterValue = chapterGoal;
                }

                if (chapter.info.goal < value)
                {
                    chapterIndex = index;

                    if (isGuide)
                    {
                        chapter.view.SetGuideSliderValue(1.0f);
                    }
                    else
                    {
                        chapter.view.SetMainSliderValue(1.0f);
                    }
                }
                else
                {
                    if (chapterValue < 0)
                    {
                        chapterValue = 0;
                    }
                    else
                    {
                        chapterIndex = index;
                    }

                    float sliderVal = chapterValue / (float)chapterGoal;

                    if (isGuide)
                    {
                        chapter.view.SetGuideSliderValue(sliderVal);
                    }
                    else
                    {
                        chapter.view.SetMainSliderValue(sliderVal);
                    }
                }

                if (updateText)
                {
                    chapter.view.SetProgressText(chapterGoal, chapterValue);
                }

                var bonus1State = CalcBonusState(value, chapter.info.bonus1, chapter.info.bonus1State, completeState);
                if (bonus1State != chapter.info.bonus1State)
                {
                    chapter.view.SetBonus1State(bonus1State);
                }

                var bonus2State = CalcBonusState(value, chapter.info.bonus2, chapter.info.bonus2State, completeState);
                if (bonus2State != chapter.info.bonus2State)
                {
                    chapter.view.SetBonus2State(bonus2State);
                }

                var bonus3State = CalcBonusState(value, chapter.info.bonus3, chapter.info.bonus3State, completeState);
                if (bonus3State != chapter.info.bonus3State)
                {
                    chapter.view.SetBonus3State(bonus3State);
                }

                var goalState = CalcBonusState(value, chapter.info.goal, chapter.info.goalState, completeState);
                if (goalState != chapter.info.goalState)
                {
                    chapter.view.SetGoalState(goalState);
                }
            }

            if (enableListMovement)
            {
                if (enablePagingAnimation)
                {
                    listView.GoTo(chapterIndex, guidePagingAnimationTime);
                }
                else
                {
                    listView.GoTo(chapterIndex);
                }

                onChapterChange?.Invoke(chapterIndex, isGuide);
            }
        }

        // chapterIndex : 0 ~ 2
        // bonusIndex : 0 ~ 2 (bonus), 3 (goal)
        public void SetBonusState(int chapterIndex, int bonusIndex, SeaStoryBonusState state)
        {
            if (IsInitialize() == false)
            {
                PrintInitializeWarning();
                return;
            }

            chapterIndex = Mathf.Clamp(chapterIndex, 0, 2);
            bonusIndex = Mathf.Clamp(bonusIndex, 0, 3);

            SeaStoryChapter chapter = seaStoryChapters[chapterIndex];

            if (bonusIndex == 0)
            {
                chapter.view.SetBonus1State(state);
            }
            else if (bonusIndex == 1)
            {
                chapter.view.SetBonus2State(state);
            }
            else if (bonusIndex == 2)
            {
                chapter.view.SetBonus3State(state);
            }
            else
            {
                chapter.view.SetGoalState(state);
            }
        }

        private SeaStoryBonusState CalcBonusState(long value, long bonusValue, SeaStoryBonusState currentState, SeaStoryBonusState targetState)
        {
            if (bonusValue <= value)
            {
                if (currentState == SeaStoryBonusState.Idle)
                {
                    return targetState;
                }
                else
                {
                    return currentState;
                }
            }
            else
            {
                if (currentState != SeaStoryBonusState.End && currentState != SeaStoryBonusState.Complete)
                {
                    return SeaStoryBonusState.Idle;
                }
                else
                {
                    return currentState;
                }
            }
        }

        public NextBonusInfo GetNextTarget()
        {
            NextBonusInfo info = new NextBonusInfo();

            for (int index = 0; index < seaStoryChapters.Count; index++)
            {
                var chapterInfo = seaStoryChapters[index].info;
                var chapterView = seaStoryChapters[index].view;

                info.chapterIndex = index;

                if (chapterInfo.bonus1 > mainValue)
                {
                    info.remainPoint = chapterInfo.bonus1 - mainValue;
                    info.target = chapterView.GetBonus1();
                    break;
                }

                if (chapterInfo.bonus2 > mainValue)
                {
                    info.remainPoint = chapterInfo.bonus2 - mainValue;
                    info.target = chapterView.GetBonus2();
                    break;
                }

                if (chapterInfo.bonus3 > mainValue)
                {
                    info.remainPoint = chapterInfo.bonus3 - mainValue;
                    info.target = chapterView.GetBonus3();
                    break;
                }

                if (chapterInfo.goal > mainValue)
                {
                    info.remainPoint = chapterInfo.goal - mainValue;
                    info.target = chapterView.GetGoal();
                    info.isGoal = true;
                    break;
                }
            }

            StringUtils.KMBOption option = StringUtils.GeneralKMBOption();
            info.remainPointText = StringUtils.ToKMB(info.remainPoint, option);

            return info;
        }

        public void SetEffectActive(bool isOn)
        {
            int targetChapterIndex = -1;

            if (isOn)
            {
                var nextTarget = GetNextTarget();
                
                if (nextTarget.IsValid)
                {
                    targetChapterIndex = nextTarget.chapterIndex;
                }
            }

            if (seaStoryChapters != null)
            {
                for (int index = 0; index < seaStoryChapters.Count; index++)
                {
                    var chapterView = seaStoryChapters[index].view;

                    if (index == targetChapterIndex)
                    {
                        chapterView.ShowEffectForce();
                    }
                    else
                    {
                        chapterView.HideEffectForce();
                    }
                }
            }
        }
    }
}