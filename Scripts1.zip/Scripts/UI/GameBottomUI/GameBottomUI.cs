using System;
using System.Collections.Generic;
using Underc.Popup;
using Underc.Scene;
using Underc.Util;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.UI
{
    [Serializable]
    public class GameBottomUiSpaceInfo
    {
        public float referenceWidth;
        public float sideSpace;
        public float centerSpace;
    }

    [ExecuteInEditMode]
    public class GameBottomUI : MonoBehaviour
    {
        [SerializeField] private List<GameObject> closingTargets;

        [Header("Button")]
        [SerializeField] private MissionIconManager missionIconManager;
        [SerializeField] private ChestDisplay obsidian;
        [SerializeField] private ChestDisplay golden;
        [SerializeField] private GameObject inboxObject;
        [SerializeField] private GoToSeaButton gotoSea;

        [Header("Space")]
        [SerializeField] private GameBottomUiSpaceInfo spaceInfo1280;
        [SerializeField] private GameBottomUiSpaceInfo spaceInfo1559;
        [SerializeField] private LayoutElement leftSpaceLayoutElement;
        [SerializeField] private LayoutElement rightSpaceLayoutElement;
        [SerializeField] private LayoutElement centerSpaceLayoutElement;

        [Space]
        [SerializeField] private float cachedWidth;
        [SerializeField] private float widthGap;
        [SerializeField] private float sideSpace;
        [SerializeField] private float centerSpace;
        [SerializeField] private float sideSpaceMutipler;
        [SerializeField] private float centerSpaceMutipler;

        public RectTransform CachedTransform
        {
            get
            {
                if (cachedTransform == null)
                {
                    cachedTransform = GetComponent<RectTransform>();
                }
                return cachedTransform;
            }
        }
        private RectTransform cachedTransform;

        public MissionIconManager MissionIconManager
        {
            get => missionIconManager;
        }
        public ChestDisplay Golden
        {
            get => golden;
        }
        public ChestDisplay Obsidian
        {
            get => obsidian;
        }
        public GoToSeaButton GotoSea
        {
            get => gotoSea;
        }
        public ChestOpener ChestOpener
        {
            get => chestOpener;
        }

        private BaseMetaFeatureDisplay[] featureDisplays;
        private ChestOpener chestOpener;
        private Action onGotoOcean;

        public void Setup(Action onGotoOcean)
        {
            this.onGotoOcean = onGotoOcean;

            missionIconManager.Setup();
            MissionIconManager.GetIcon(MissionIconType.MissionPass).Switch();

            featureDisplays = GetComponentsInChildren<BaseMetaFeatureDisplay>(true);
            foreach (BaseMetaFeatureDisplay featureDisplay in featureDisplays)
            {
                featureDisplay.Reset();
            }

            if (chestOpener == null)
            {
                chestOpener = gameObject.AddComponent<ChestOpener>();
                chestOpener.Setup();
            }
        }

        public void OpenGoldenChest()
        {
            chestOpener.OpenGolden();

            UndercGameLog.Fobis.ButtonLobbyMenu(6);
        }

        public void OpenObsidianChest()
        {
            chestOpener.OpenObsidian();

            UndercGameLog.Fobis.ButtonLobbyMenu(7);
        }


        public void OpenInbox()
        {
            Popups.GameProfile(2).Async().Cache();

            UndercGameLog.Fobis.ButtonLobbyMenu(4);
        }

        public void GotoOceanLobby()
        {
            onGotoOcean?.Invoke();

            UndercGameLog.Fobis.ButtonLobbyMenu(3);
        }

        public void Show()
        {
            if (featureDisplays != null)
            {
                foreach (BaseMetaFeatureDisplay featureDisplay in featureDisplays)
                {
                    if (featureDisplay.gameObject.activeInHierarchy)
                    {
                        featureDisplay.Show(isProgressive: false);
                    }
                }
            }
        }

        public void Hide()
        {
            if (featureDisplays != null)
            {
                foreach (BaseMetaFeatureDisplay featureDisplay in featureDisplays)
                {
                    featureDisplay.Hide();
                }
            }
        }

        public void CloseAll()
        {
            foreach (GameObject closingTarget in closingTargets)
            {
                closingTarget.SetActive(false);
            }

            if (featureDisplays != null)
            {
                foreach (BaseMetaFeatureDisplay featureDisplay in featureDisplays)
                {
                    featureDisplay.gameObject.SetActive(false);
                }
            }
            inboxObject.SetActive(false);
        }

        private void Update()
        {
            float bottomWidth = CachedTransform.rect.width;
            if (cachedWidth != bottomWidth)
            {
                float referenceWidthGap = spaceInfo1559.referenceWidth - spaceInfo1280.referenceWidth;
                float sideSpaceGap = spaceInfo1559.sideSpace - spaceInfo1280.sideSpace;
                sideSpaceMutipler = sideSpaceGap / referenceWidthGap;

                float centerSpaceGap = spaceInfo1559.centerSpace - spaceInfo1280.centerSpace;
                centerSpaceMutipler = centerSpaceGap / referenceWidthGap;

                widthGap = bottomWidth - spaceInfo1280.referenceWidth;
                sideSpace = spaceInfo1280.sideSpace + widthGap * sideSpaceMutipler;
                centerSpace = spaceInfo1280.centerSpace + widthGap * centerSpaceMutipler;

                leftSpaceLayoutElement.preferredWidth = sideSpace;
                rightSpaceLayoutElement.preferredWidth = sideSpace;
                centerSpaceLayoutElement.preferredWidth = centerSpace;

                cachedWidth = bottomWidth;
            }
        }
    }
}
