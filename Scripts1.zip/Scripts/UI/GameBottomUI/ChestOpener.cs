using Gaga.Popup;
using Gaga.System;
using System.Collections;
using System.Collections.Generic;
using Underc.Net;
using Underc.Popup;
using Underc.User;
using UnityEngine;

namespace Underc.UI
{
    public enum ChestOpenerState
    {
        None,
        Reset,
        LoadGoldenReward,
        LoadObsidianReward,
        PurchaseChest,
        OpenReward,
        ReopenReward,
        CheckVipLevelUp
    }

    public class ChestOpener : MonoBehaviour
    {
        public bool IsInPlay
        {
            get => stateQueue.CurrentState != ChestOpenerState.None;
        }

        private StateQueue<ChestOpenerState> stateQueue;
        private PopupObject<RewardViewPopup> popupObject;

        private List<RewardData> rewardDatas;
        private RewardViewPopup.OpenType openType;

        private bool getMoreChanceOnce;

        public void Setup()
        {
            stateQueue = new StateQueue<ChestOpenerState>(host: this);
            rewardDatas = new List<RewardData>();
        }

        public void OpenGolden()
        {
            stateQueue.Add(ChestOpenerState.Reset);
            stateQueue.Add(ChestOpenerState.LoadGoldenReward);
            stateQueue.Add(ChestOpenerState.OpenReward);
        }

        public void OpenObsidian()
        {
            stateQueue.Add(ChestOpenerState.Reset);
            stateQueue.Add(ChestOpenerState.LoadObsidianReward);
            stateQueue.Add(ChestOpenerState.OpenReward);
        }
        
        private void OnReopenClick()
        {
            if (openType == RewardViewPopup.OpenType.GoldenChest)
            {
                stateQueue.Add(ChestOpenerState.LoadGoldenReward);
            }
            else if (openType == RewardViewPopup.OpenType.ObsidianChest)
            {
                stateQueue.Add(ChestOpenerState.LoadObsidianReward);
            }
            stateQueue.Add(ChestOpenerState.ReopenReward);
        }

        #region States
        private IEnumerator ResetCoroutine()
        {
            popupObject = null;

            rewardDatas.Clear();
            openType = RewardViewPopup.OpenType.None;

            getMoreChanceOnce = false;

            yield break;
        }

        private IEnumerator CheckVipLevelUpCoroutine()
        {
            if (MyInfo.VipClass.ConsumeLevelUp())
            {
                if (popupObject != null)
                {
                    yield return popupObject.WaitForClose();
                }

                yield return Popups.VipLevelUpCoroutine();
            }

            yield break;
        }

        private IEnumerator ReopenRewardCoroutine()
        {
            if (popupObject != null)
            {
                RewardViewPopup rewardViewPopup = popupObject.GetPopup();
                if (rewardDatas.Count > 0)
                {
                    // 팝업 열린 상태에서 상자 정보만 전달
                    rewardViewPopup.Reopen(rewardDatas: rewardDatas.ToArray());
                }
            }
            
            yield break;
        }

        private IEnumerator OpenRewardCoroutine()
        {
            if (rewardDatas.Count > 0)
            {
                /// 팝업 열기
                popupObject = Popups.RewardView(
                    rewardDatas: rewardDatas.ToArray(),
                    openType: openType,
                    onReopenClick: OnReopenClick,
                    onComplete: () => stateQueue.Add(ChestOpenerState.CheckVipLevelUp)
                );
            }
            yield break;
        }

        private IEnumerator LoadGoldenRewardCoroutine()
        {
            bool isAds = ReadAdsFromRewardData();

            Popups.ShowLoading();
            var req = NetworkSystem.HTTPRequester.GoldenReward(isAds);
            yield return req.WaitForResponse();
            Popups.HideLoading();

            rewardDatas.Clear();
            if (req.isSuccess == true)
            {
                GoldenRewardData data = req.data.data;

                MyInfo.CasinoBonus.Update(data);

                rewardDatas.Add(new RewardData(typeStr: RewardData.FISH,
                                               value: data.fish,
                                               additionalCoin: data.bonus_coin,
                                               additionalVipCoin: data.vip_bonus,
                                               openCount: data.key,
                                               openAds: data.ads == 1 && GetMoreChanceOnce() == false ? 
                                                        true : 
                                                        false,
                                               tableItemInfo: new VipBenefitTableItemInfo(data.vip_rate, data.vip_type)));
                openType = RewardViewPopup.OpenType.GoldenChest;
            }
            else
            {
                OpenErrorPopup(req.data.error);
            }
        }

        private IEnumerator LoadObsidianRewardCoroutine()
        {
            bool isBuy = ReadBuyFromRewardData();

            // 구매 버튼을 눌렀을 때는 결제 기능을 통해 상품을 얻어야 함
            if (isBuy == true)
            {
                PurchaseSystem purchaseSystem = PurchaseSystem.Instance;
                yield return purchaseSystem.Purchase(itemID: "chest2",
                                                     showReward: false);

                if (purchaseSystem.IsFailed == true)
                {
                    // 결제 실패시 내부에서 에러 팝업을 띄우고 있음, 버튼만 다시 활성화시켜 줌
                    popupObject.GetPopup().OpenButtonsInteractable(true);
                    // 보상 연출을 진행하지 않기 위해
                    stateQueue.Reset();
                    yield break;
                }
            }
            
            Popups.ShowLoading();
            var req = NetworkSystem.HTTPRequester.ObsidianReward();
            yield return req.WaitForResponse();
            Popups.HideLoading();

            rewardDatas.Clear();
            if (req.isSuccess == true)
            {
                ObsidianRewardData data = req.data.data;
                MyInfo.CasinoBonus.Update(data);

                rewardDatas.Add(new RewardData(typeStr: RewardData.FISH,
                                               value: data.fish,
                                               additionalCoin: data.bonus_coin,
                                               additionalVipCoin: data.vip_bonus,
                                               openCount: data.key,
                                               openBuy: data.buy == true && GetMoreChanceOnce() == false ? 
                                                        true : 
                                                        false,
                                               openPrice: data.price,
                                               tableItemInfo: new VipBenefitTableItemInfo(data.vip_rate, data.vip_type)));
                openType = RewardViewPopup.OpenType.ObsidianChest;
            }
            else
            {
                OpenErrorPopup(req.data.error);
            }

            yield break;
        }

        private bool GetMoreChanceOnce()
        {
            bool result = getMoreChanceOnce;
            getMoreChanceOnce = true;

            return result;
        }

        private bool ReadBuyFromRewardData()
        {
            bool result = false;
            if (rewardDatas.Count > 0)
            {
                result = rewardDatas[0].openBuy;
            }

            return result;
        }

        private bool ReadAdsFromRewardData()
        {
            bool result = false;
            if (rewardDatas.Count > 0)
            {
                result = rewardDatas[0].openAds;
            }

            return result;
        }

        private void OpenErrorPopup(string message)
        {
            stateQueue.Reset();

            Popups.Error(message)
                  .Async()
                  .Cache();
        }
        #endregion
    }
}
