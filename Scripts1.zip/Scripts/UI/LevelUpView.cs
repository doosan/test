using System.Collections;
using Gaga.UI;
using Gaga.Attribute;
using Underc.User;
using UnityEngine;
using TMPro;
using Gaga.Sound;
using UnityEngine.UI;
using Underc.Ocean;
using UnityEngine.Events;
using Gaga;
using Gaga.Util;

namespace Underc.UI
{
    public struct LevelUpFishBonusInfo
    {
        public Sprite icon;
        public Vector3 position;
        public Vector2 size;
        public bool preserveAspect;
        public bool isNew;
        public bool isPrize;

        public bool IsValid()
        {
            return icon != null;
        }
    }

    public sealed class LevelUpView : MonoBehaviour
    {
        [System.Serializable] public class CliamEvent : UnityEvent<long, LevelUpFishBonusInfo, VipClassType, long> {};
        
#pragma warning disable 0649
        [SerializeField] private Animator animator;
        [SerializeField] private float levelUpTime;

        [Separator("Bonus")]
        [SerializeField, LabelOverride("Level")] private TextMeshProUGUI levelText;
        [SerializeField, LabelOverride("Coin")] private TextMeshProUGUI bonusCoinText;
        [SerializeField, LabelOverride("VIP")] private TextMeshProUGUI vipPointText;
        [SerializeField] private GameObjectVisibleToggle classSymbolVisibleToggle;

        [Separator("Fish Bonus")]
        [SerializeField, LabelOverride("Root")] private LayoutElement fishBonus;
        [SerializeField, LabelOverride("Thumbnail")] private Image fishThumbnail;
        [SerializeField] private GameObject fishNewTag;
        [SerializeField, LabelOverride("Thumb PreserveAspect")] private bool fishThumbPreserveAspect = true;

        [Separator("Sound")]
        [SerializeField] private SoundPlayer levelupSFX;

        [Separator("Event")]
        public CliamEvent onClaim;
#pragma warning restore 0649

        private long currentLevel;
        private long currentBonusCoin;

        public void Show(long level, 
                         long bonusCoin, 
                         VipClassType vipClass, 
                         long vipPoint, 
                         RandomBonusData randomBonus)
        {
            currentLevel = level;

            StopAllCoroutines();
            StartCoroutine(AnimationCoroutine(level, bonusCoin, vipClass, vipPoint, randomBonus));
        }

        public void Hide()
        {
            StopAllCoroutines();
        }

        private IEnumerator AnimationCoroutine(long level, 
                                               long bonusCoin, 
                                               VipClassType vipClass, 
                                               long vipPoint, 
                                               RandomBonusData randomBonus)
        {
            var fishThumbnailRt = fishThumbnail.GetComponent<RectTransform>();

            LevelUpFishBonusInfo fishBonusInfo = new LevelUpFishBonusInfo();

            if (randomBonus != null)
            {
                fishBonusInfo.isNew = randomBonus.IsNew;
                fishBonusInfo.isPrize = randomBonus.IsPrize;
            }

            if (currentBonusCoin > 0)
            {
                currentBonusCoin = 0;
                ClaimBonus(currentBonusCoin, fishBonusInfo, VipClassType.none, 0); 
                // 이상한 부분, 0으로 세팅한 후 노티?, 민석님께 문의하기
            }

            currentBonusCoin = bonusCoin;

            levelText.text = level.ToString();
            bonusCoinText.SetNumber(bonusCoin, StringUtils.GeneralKMBOption(1000000));
            classSymbolVisibleToggle.TurnOnByNameInMultiple(vipClass.ToString());
            vipPointText.SetNumber(vipPoint, StringUtils.GeneralKMBOption(1000000));

            bool hasRandomBonus = randomBonus != null && randomBonus.id > 0;
            if (hasRandomBonus)
            {
                fishBonus.gameObject.SetActive(true);
                fishThumbnail.gameObject.SetActive(true);
                fishNewTag.SetActive(randomBonus.IsNew);

                SeaItemType fishType = randomBonus.type == 0 ? SeaItemType.f : SeaItemType.s;
                int fishID = randomBonus.id;
                Sprite fishIcon = FishIconSystem.Instance.GetFishIcon(fishType, fishID);
                fishBonus.preferredHeight = ReadFishHeight(fishType, fishID);
                
                if (fishIcon != null)
                {
                    fishThumbnail.sprite = fishIcon;
                    fishThumbnail.preserveAspect = fishThumbPreserveAspect;

                    fishBonusInfo.icon = fishIcon;
                    fishBonusInfo.size = fishThumbnailRt.sizeDelta;
                    fishBonusInfo.preserveAspect = fishThumbPreserveAspect;
                }
            }
            else
            {
                fishBonus.gameObject.SetActive(false);
            }

            animator.SetTrigger("show");
            levelupSFX.Play();

            yield return new WaitForSeconds(levelUpTime);

            fishBonusInfo.position = fishThumbnailRt.position;
            fishThumbnail.gameObject.SetActive(false);

            currentBonusCoin = 0;
            ClaimBonus(bonusCoin, fishBonusInfo, vipClass, vipPoint);

            animator.SetTrigger("hide");
        }

        private float ReadFishHeight(SeaItemType fishType, int fishID)
        {
            float result = 200f;
            if (fishType == SeaItemType.f)
            {
                if (fishID == 107
                      || fishID == 108
                      || fishID == 109
                      || fishID == 110
                      || fishID == 111
                      || fishID == 115
                      || fishID == 116)
                {
                    result = 250f;
                }
            }
                   
            return result;
        }

        private void ClaimBonus(long bonus, LevelUpFishBonusInfo fishBonus, VipClassType vipClass, long vipPoint)
        {
            onClaim?.Invoke(bonus, fishBonus, vipClass, vipPoint);
        }
        
        public void TestActionNormalLevelUp()
        {
#if GGDEV_TEST
            Show(100, 100000, VipClassType.gold, 999, null);
#endif
        }

         public void TestActionFishLevelUp()
        {
#if GGDEV_TEST
            RandomBonusData data = new RandomBonusData();
            data.id = UnityEngine.Random.Range(1, 130);
            data.type = 0;
            data.value = 1;
            
            Show(100, 100000, VipClassType.diamond, 999, data);
#endif
        }
    }
}