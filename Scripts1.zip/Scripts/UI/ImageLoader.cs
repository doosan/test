﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using Underc.Net;
using Gaga.UI;

namespace Underc.UI
{
    public class ImageLoader : MonoBehaviour
    {
        [SerializeField] private Image image = null;
        [SerializeField] private GameObject progressIndicator = null;
        [SerializeField] private BaseLoadingIndicator loadingIndicator = null;
        [SerializeField] private GameObject fallbackObject = null;
        [SerializeField] private bool useCache = false;
        public bool useNativeSize;

        public Image Image { get => image; }
        public string URL { get; private set; }
        public bool IsLoading { get; private set; }
        public Sprite sprite
        {
            get => image == null ? null : image.sprite;
            set
            {
                if (image != null)
                {
                    image.sprite = value;
                }
            }
        }

        public Color color
        {
            get => image == null ? Color.white : image.color;
            set
            {
                if (image != null)
                {
                    image.color = value;
                }
            }
        }

        private DownloadSystem.ID currentDownloadID;
        private Action<ImageLoader> onLoadCompleteListener;

        private void Awake()
        {
            if (image == null)
            {
                image = GetComponent<Image>();
            }

            HideFallback();
            HideLoadIndicator();
        }

        public void Clear()
        {
            if (string.IsNullOrEmpty(currentDownloadID.value))
            {
                DownloadSystem.Instance.Abort(currentDownloadID);
                currentDownloadID.value = null;
            }

            onLoadCompleteListener = null;
            URL = string.Empty;

            HideLoadIndicator();
            HideFallback();
        }

        private void ShowLoadIndicator()
        {
            if (progressIndicator != null)
            {
                progressIndicator.SetActive(true);
            }

            if (loadingIndicator != null)
            {
                loadingIndicator.Show();
            }
        }

        private void HideLoadIndicator()
        {
            if (progressIndicator != null)
            {
                progressIndicator.SetActive(false);
            }

            if (loadingIndicator != null)
            {
                loadingIndicator.Hide();
            }
        }

        private void HideFallback()
        {
            if (fallbackObject != null)
            {
                fallbackObject.SetActive(false);
            }
        }

        private void ShowFallback()
        {
            if (fallbackObject != null)
            {
                fallbackObject.SetActive(true);
            }
        }

        public void LoadFromRemote(string url, Action<ImageLoader> onComplete = null)
        {
            URL = url;
            onLoadCompleteListener = onComplete;
            IsLoading = true;

            ShowLoadIndicator();

            Debug.LogFormat("ImageLoader: {0}", url);
            if (useCache && DownloadSystem.Instance.HasCachedSprite(URL) == true)
            {
                Debug.LogFormat("   ImageLoader {0} cached", url);
                var sprite = DownloadSystem.Instance.GetCachedSprite(url);
                SetSprite(sprite);
            }
            else if (DownloadSystem.Instance.HasTask(URL) == true)
            {
                Debug.LogFormat("   ImageLoader {0} already loading", url);

                DownloadSystem.Instance.AddTaskListener(URL, (loadURL) =>
                {
                    Debug.LogFormat("   ImageLoader {0} wait compelte", loadURL);

                    var sprite = DownloadSystem.Instance.GetCachedSprite(loadURL);
                    SetSprite(sprite);
                });
            }
            else
            {
                Debug.LogFormat("   ImageLoader {0} new load", url);
                currentDownloadID = DownloadSystem.Instance.GetSprite(URL, (loadedSprite) =>
                {
                    SetSprite(loadedSprite);
                }, useCache);
            }
        }

        private Sprite ConvertToSprite(Texture2D texture, float pivotX = 0.5f, float pivotY = 0.5f)
        {
            if (texture == null) return null;
            else return Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), new Vector2(pivotX, pivotY));
        }

        public void SetSprite(Sprite sprite)
        {
            if (image == null)
            {
                ShowFallback();
                return;
            }

            HideLoadIndicator();
            HideFallback();

            image.sprite = sprite;
            image.enabled = sprite != null;
            currentDownloadID.value = null;

            if (sprite != null && useNativeSize == true)
            {
                image.SetNativeSize();
            }

            IsLoading = false;

            if (onLoadCompleteListener != null)
            {
                onLoadCompleteListener(this);
                onLoadCompleteListener = null;
            }
        }
    }
}