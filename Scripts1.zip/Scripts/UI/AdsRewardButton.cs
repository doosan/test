using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Underc.UI
{
    [RequireComponent(typeof(Button))]
    public class AdsRewardButton : MonoBehaviour
    {
        public UnityEvent onFinish = new UnityEvent();
        public UnityEvent onFail = new UnityEvent();

        public bool Interactable
        {
            set 
            {
                Button.interactable = value;
            }
        }

        private Button Button
        {
            get
            {
                if (button == null)
                {
                    button = GetComponent<Button>();
                }
                return button;
            }
        }
        private Button button;

        public ButtonMode Mode
        {
            get; private set;
        }

        private const AdsPlacement Placement = AdsPlacement.RewardKey;

        private void Awake()
        {
            Button.onClick.AddListener(OnButtonClick);
        }

        public void SetMode(ButtonMode mode)
        {
            this.Mode = mode;
        }

        public bool IsLoaded()
        {
            return AdsSystem.Instance.IsLoaded(Placement);
        }

        private void OnAdsState(AdsPlacement adsPlacement, AdsState adsState)
        {
            string adsPlacementID = adsPlacement.ToString();

            switch (adsState)
            {
                case AdsState.Completed:
                    onFinish.Invoke();
                    break;

                case AdsState.FailedToShow:
                case AdsState.Skipped:
                case AdsState.Unknown:
                    Debug.LogWarning($"AdsState : {adsState}" + 
                                     $"\nAdsPlacementID : {adsPlacementID}");
                    onFail.Invoke();
                    break;
            }
        }

        private void OnButtonClick()
        {
            // 광고형 버튼 상태이면 광고 재생 후 클릭 알림
            if (Mode == ButtonMode.AdsReward)
            {
                if (AdsSystem.Instance.IsLoaded(Placement) == true)
                {
                    AdsSystem.Instance.Show(Placement, OnAdsState);
                }
                else
                {
                    Debug.LogWarning("Ads are not prepared.");
                    onFail.Invoke();
                }
            }
            else
            {
                onFinish.Invoke();
            }
        }

        public enum ButtonMode
        {
            AdsReward, JustButton,
        }
    }
}
