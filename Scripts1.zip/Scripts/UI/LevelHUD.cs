using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using Underc.User;
using TMPro;

namespace Underc.UI
{
    public sealed class LevelHUD : MonoBehaviour
    {
        #pragma warning disable 0649
        [SerializeField] private TextMeshProUGUI levelText;
        [SerializeField] private Slider xpGauge;
        [SerializeField] private float gaugeAnimationTime = 0.3f;
        [SerializeField] private Ease gaugeAnimationEase = Ease.Linear;
        [SerializeField] private float gaugeShowMin = 0.01f;
        [SerializeField] private float gaugeShowMax = 0.995f;
        [SerializeField] private RectTransform gaugeBar;
        [SerializeField] private ParticleSystem gaugeParticle;
        [SerializeField] private LevelUpView levelUpView;
        [SerializeField] private LevelUpResultView levelUpResultView;
        public LevelUpResultView LevelUpResultView => levelUpResultView;
        public RectTransform XpGaugeTransform
        {
            get
            {
                if (xpGaugeTransform == null)
                {
                    xpGaugeTransform = xpGauge.GetComponent<RectTransform>();
                }
                return xpGaugeTransform;
            }
        }
        private RectTransform xpGaugeTransform;
        #pragma warning restore 0649

        private void Awake()
        {
            SetupGaugeParticle();
        }

        private void OnEnable()
        {
            SetLevel(MyInfo.Level);
            SetXP(MyInfo.BaseXP, MyInfo.CurrentXP, MyInfo.NextXP, false);
        }

        private void SetupGaugeParticle()
        {
            gaugeParticle.Stop();
            var main = gaugeParticle.main;
            main.duration = gaugeAnimationTime;
        }   

        public void SetLevel(long level)
        {
            levelText.text = level.ToString();
        }

        public void SetXP(float xp, bool animation)
        {
            xpGauge.DOKill(false);

            var animationTime = animation ? gaugeAnimationTime : 0.0f;

            if (animationTime > 0.0f)
            {
                if (xp != xpGauge.value)
                {
                    gaugeParticle.Stop();
                    gaugeParticle.Play();
                }
                
                xpGauge.DOValue(xp, gaugeAnimationTime)
                       .SetEase(gaugeAnimationEase);
            }
            else
            {
                xpGauge.value = xp;
            }
        }

        public void SetXP(float baseXP, float currXP, float nextXP, bool animation)
        {
            var xp = CalculateXpValue(currXP, baseXP, nextXP);
            SetXP(xp, animation);
        }

        public void ShowLevelUP(long level, long bonusCoin, VipClassType vipClassType, long vipPoint, RandomBonusData randomBonus)
        {
            levelUpView.Show(level, bonusCoin, vipClassType, vipPoint, randomBonus);
        }

        private float CalculateXpValue(float currentXP, float baseXP, float nextXP)
        {
            return (currentXP - baseXP) / (nextXP - baseXP);
        }
    }
}