using System;
using Gaga.Util;
using Underc.Popup;
using Underc.User;
using UnityEngine;
using UnityEngine.UI;

namespace Underc.UI
{
    public sealed class SeaStoryDetailView : MonoBehaviour
    {
        public event Action onInteractionBegin;

        [SerializeField] private SeaStoryProgressBar progressBar;

        [Header("Bonus ToolTip")]
        [SerializeField] private SeaStoryTooltip goalTooltip;
        [SerializeField] private SeaStoryTooltip bonusTooltip;
        [SerializeField] private float goalToolTipLimitMin;
        [SerializeField] private float bonusToolTipLimitMax;

        [Header("Next ToolTip")]
        [SerializeField] private SeaStoryTooltip nextTooltip;
        [SerializeField] private string nextToolTipPrefix = "Need+ ";
        [SerializeField] private float nextToolTipBonusOffsetY = 0.6f;
        [SerializeField] private float nextToolTipGoalOffsetY = 2.4f;

        [Space]
        [SerializeField] private string msgCollected;
        [SerializeField] private string msgBonusCoin;
        [SerializeField] private string msgBubbleParty;
        [SerializeField] private string msgLastGoal;

        private int currentIndex;
        private bool listViewDragCheckOnce;

        private SeaStoryProgressBar.NextBonusInfo nextBonusInfo;

        private void Awake()
        {
            progressBar.onBonusClick += OnBonusClickHandler;
        }

        private void Update()
        {
            UpdateCurrentIndex();

            if (progressBar.ListView.IsDragging)
            {
                HideAllBonusTooltips();

                if (listViewDragCheckOnce)
                {
                    listViewDragCheckOnce = false;
                    onInteractionBegin?.Invoke();
                }
            }

            if (nextTooltip.gameObject.activeInHierarchy == false
                && nextBonusInfo.target != null 
                && nextBonusInfo.target.gameObject.activeInHierarchy)
            {
                UpdateNextToolTip();
            }
        }

        private void UpdateCurrentIndex()
        {
            var itemCount = progressBar.ListView.GetCount();
            float dist = float.MaxValue;

            for (int itemIndex = 0; itemIndex < itemCount; itemIndex++)
            {
                var item = progressBar.ListView.GetItem(itemIndex);
                var tempDist = Vector2.Distance(Vector2.zero, item.position);

                if (tempDist < dist)
                {
                    currentIndex = itemIndex;
                    dist = tempDist;
                }
            }
        }

        public void Refresh()
        {
            listViewDragCheckOnce = true;
            HideAllBonusTooltips();

            var seaStory = MyInfo.Ocean.CurrentSeaStory;
            progressBar.Initialize(seaStory.Point);

            nextBonusInfo = progressBar.GetNextTarget();
            UpdateNextToolTip();

            progressBar.SetEffectActive(true);
        }

        private void UpdateNextToolTip()
        {
            if (nextBonusInfo.IsValid)
            {
                var nextMsg = string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0}{1}", nextToolTipPrefix, nextBonusInfo.remainPointText);

                nextTooltip.target = nextBonusInfo.target;
                nextTooltip.offset = new Vector2(0.0f, nextBonusInfo.isGoal ? nextToolTipGoalOffsetY : nextToolTipBonusOffsetY);
                
                nextTooltip.Show(nextMsg);
            }
            else
            {
                nextTooltip.target = null;
                nextTooltip.Hide();
            }
        }

        private void OnBonusClickHandler(int chapterIndex, int stepIndex, SeaStoryBonusState state, RectTransform target)
        {
            onInteractionBegin?.Invoke();

            HideAllBonusTooltips();

            if (stepIndex + 1 >= MySeaStory.STEP_COUNT)
            {
                goalTooltip.target = target;
                bool tooltipFlip = GetTooltipFlip(target, true);

                if (state == SeaStoryBonusState.Idle)
                {
                    var msg = "";

                    if (chapterIndex + 1 >= MySeaStory.CHAPTER_COUNT)
                    {
                        msg = msgLastGoal;
                    }
                    else
                    {
                        msg = GetRewardMessage(msgBubbleParty, chapterIndex, 3, true);
                    }
        
                    goalTooltip.Show(msg, tooltipFlip);
                }
                else
                {
                    goalTooltip.Show(msgCollected, tooltipFlip);
                }

                UndercGameLog.Fobis.ButtonSeaDetails(3);
            }
            else
            {
                bonusTooltip.target = target;

                bool tooltipFlip = GetTooltipFlip(target, false);

                if (state == SeaStoryBonusState.Idle)
                {
                    var msg = GetRewardMessage(msgBonusCoin, chapterIndex, 0);
                    bonusTooltip.Show(msg, tooltipFlip);
                }
                else
                {
                    bonusTooltip.Show(msgCollected, tooltipFlip);
                }

                UndercGameLog.Fobis.ButtonSeaDetails(2);
            }
        }

        public void HideAllBonusTooltips()
        {
            if (goalTooltip != null)
            {
                goalTooltip.Hide();
            }

            if (bonusTooltip != null)
            {
                bonusTooltip.Hide();
            }
        }

        private bool GetTooltipFlip(RectTransform target, bool isGoalTooltip)
        {
            if (isGoalTooltip)
            {
                return target.position.x <= goalToolTipLimitMin;
            }   
            else
            {
                return target.position.x >= bonusToolTipLimitMax;
            }
        }

        private string GetRewardMessage(string format, int chapterIndex, int setpIndex, bool useKMB = false)
        {
            long reward = MyInfo.Ocean.CurrentSeaStory.GetReward(chapterIndex, setpIndex);
            StringUtils.KMBOption option = StringUtils.GeneralKMBOption();
            return string.Format(System.Globalization.CultureInfo.InvariantCulture, format, (useKMB ? StringUtils.ToKMB(reward, option) : StringUtils.ToComma(reward)));
        }

        public void Next()
        {
            onInteractionBegin?.Invoke();

            var maxIndex = progressBar.ListView.GetCount() - 1;
            var nextIndex = currentIndex + 1;
            nextIndex = Mathf.Clamp(nextIndex, 0, maxIndex);

            progressBar.ListView.GoTo(nextIndex, 0.6f);
        }

        public void Prev()
        {
            onInteractionBegin?.Invoke();

            var maxIndex = progressBar.ListView.GetCount() - 1;
            var prevIndex = currentIndex - 1;
            prevIndex = Mathf.Clamp(prevIndex, 0, maxIndex);

            progressBar.ListView.GoTo(prevIndex, 0.6f);
        }

        public void OpenInfo()
        {
            onInteractionBegin?.Invoke();
            Popups.SeaStoryInfo().Async();
            UndercGameLog.Fobis.ButtonSeaDetails(1);
        }

    }
}