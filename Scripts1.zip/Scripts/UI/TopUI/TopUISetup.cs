using System.Collections;
using UnityEngine;

namespace Underc.UI
{
    public class TopUISetup
    {
        public static TopUI CoinBonusStyle(Transform parent)
        {
            TopUI topUI = TopUISystem.Instance.Get(parent);
            topUI.Use(TopUiItem.Coin);
            topUI.Reset();
            topUI.Hide(false);

            return topUI;
        }
    }
}