using System.Collections;
using System.Collections.Generic;
using Underc;
using Underc.LoadingScreen;
using Underc.Net;
using Underc.Net.Client;
using Underc.UI;
using Underc.User;
using Underc.Util;
using UnityEngine;

public class TestTopUI : TestSceneScaffold
{
    [SerializeField] private RectTransform uiRoot;

    private TopUI topUI;

    private IEnumerator Start()
    {
        yield return SetupAndLoad(new BaseLoadingItem[]
        {
            new LoginLoadingItem(),
            new HTTPLoadingItem<UserCoreResponse>(
                () => NetworkSystem.HTTPRequester.UserCoreWithAlarms(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<SeaListResponse>(
                () => NetworkSystem.HTTPRequester.SeaList(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<FishBookListResponse>(
                () => NetworkSystem.HTTPRequester.FishBookList(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new HTTPLoadingItem<ProfileResponse>(
                () => NetworkSystem.HTTPRequester.Profile(),
                resp => NetworkSystem.HTTPHandler.Do(resp)
            ),
            new ABFishLoadingItem(),
            new ABFishIconLoadingItem(),
            new ProfileIconLoadingItem(),
            new ABLoadingItem(AssetBundleName.EFFECT),
            new TopUILoadingItem(),
            new ProfileFirstPicLoadingItem(),
        });

        SetupTopUI();
    }

    private void SetupTopUI()
    {
        if (topUI == null)
        {
            topUI = TopUISystem.Instance.Get(parent: uiRoot);
            topUI.UseCoin = true;
            topUI.UseProfile = true;
            topUI.UseLevel = false;
            topUI.UseSecondaryCurrencies = true;

            topUI.UseHomeButton = true;
            topUI.UseShopButton = true;
            topUI.UseSettingButton = true;
        }

        topUI.Reset();
        topUI.Hide(false);
    }

    public void SlotLobby()
    {
        topUI.SlotLobbyStyle();
        topUI.Show(false);
    }

    public void OceanLobby()
    {
        topUI.OceanLobbyStyle();
        topUI.Show(false);
    }

    public void ProfileCoin()
    {
        topUI.Use(TopUiItem.Profile,
                  TopUiItem.Coin);
        topUI.Order(TopUiItem.Profile,
                    TopUiItem.Coin);
    }

    public void ProfileCoinPearlAndTicket()
    {
        topUI.Use(TopUiItem.Profile,
                  TopUiItem.Coin,
                  TopUiItem.PearlAndTicket);
        topUI.Order(TopUiItem.Profile,
                    TopUiItem.Coin,
                    TopUiItem.PearlAndTicket);
    }

    public void Coin()
    {
        topUI.Use(TopUiItem.Coin);
        topUI.Show(false);
    }

    public void CoinPearlAndTicket()
    {
        topUI.Use(TopUiItem.Coin,
                  TopUiItem.PearlAndTicket);
        topUI.OrderAsDefault();
        topUI.Show(false);
    }

    public void CoinPearlAndTicketLevel()
    {
        topUI.Use(TopUiItem.Coin,
                  TopUiItem.PearlAndTicket,
                  TopUiItem.Level);
        topUI.OrderAsDefault();
        topUI.Show(false);
    }

    public void CoinLevel()
    {
        topUI.Use(TopUiItem.Coin,
                  TopUiItem.Level);
        topUI.OrderAsDefault();
        topUI.Show(false);
    }

    public void LevelUp()
    {
        topUI.Show(false);
        topUI.LevelHUD.ShowLevelUP(10, 1000000, VipClassType.gold, 50, null);
    }

    private List<int> tallFishes = new List<int>()
    {
        107, 108, 109, 110, 111, 115, 116
    };
    public void LevelUpWithFish()
    {
        var randomBonusData = new RandomBonusData();
        randomBonusData.type = 0;

        MyOceanBook oceanBook = MyInfo.Ocean.Book;
        int randomIndex = Random.Range(0, oceanBook.GetBookInfoCount(SeaItemType.f));
        BaseBookInfo fishBookInfo = oceanBook.GetBookInfoAtIndex(SeaItemType.f, randomIndex);
        //BaseBookInfo fishBookInfo = null;
        //while (fishBookInfo == null)
        //{
        //    int randomIndex = Random.Range(0, tallFishes.Count);
        //    fishBookInfo = oceanBook.GetBookInfo(SeaItemType.f, tallFishes[randomIndex]);
        //}

        randomBonusData.id = fishBookInfo.ID;
        randomBonusData.is_prize = 1;
        randomBonusData.value = 50;

        topUI.Show(false);
        topUI.LevelHUD.ShowLevelUP(10, 1000000, VipClassType.gold, 50, randomBonusData);
    }
}
