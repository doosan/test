using System;
using Gaga.AssetBundle;
using Gaga.System;
using Underc.Util;
using UnityEngine;

namespace Underc.UI
{
    public sealed class TopUISystem : GameObjectSingleton<TopUISystem>
    {
        private GameObjectPool<TopUI> pool;
        private GameObjectPool<TopUI> poolPortrait;
        private GameObject poolRoot;

        public void Preload(Action<bool> onComplete, Action<int> onProgress)
        {
            if (pool != null)
            {
                onProgress(100);
                onComplete(true);
                return;
            }

            AssetBundleSystem.Instance.Load(AssetBundleLoadType.Load
                                            ,Net.Address.CDN_ASSETBUNDLES
                                            ,AssetBundleName.TOP_UI
                                            ,(success, ab) =>
                                            {
                                                if (success)
                                                {
                                                    SetupPool(ab);
                                                }
                                                
                                                onComplete(success);
                                            }
                                            ,progress =>
                                            {
                                                int progressVal = (int)(progress * 100.0f);
                                                onProgress(progressVal);
                                            });
        }

        private void SetupPool(Gaga.AssetBundle.AssetBundle ab)
        {
            if (pool != null)
            {
                return;
            }

            poolRoot = new GameObject("PoolRoot");
            poolRoot.transform.SetParent(transform);

            pool = new GameObjectPool<TopUI>(poolRoot
                                             ,3
                                             ,() =>
                                             {
                                                 var newTopUI = ab.GetGameObject("TopUI", true).GetComponent<TopUI>();
                                                 return newTopUI;
                                             });

            poolPortrait = new GameObjectPool<TopUI>(poolRoot
                                             ,3
                                             ,() =>
                                             {
                                                 var newTopUI = ab.GetGameObject("TopUIPortrait", true).GetComponent<TopUI>();
                                                 newTopUI.IsPortrait = true;
                                                 return newTopUI;
                                             });
        }

        public TopUI Get(Transform parent = null, bool isLandscape = true)
        {
            TopUI ui = isLandscape ? pool.Get() : poolPortrait.Get();
            if (ui == null)
            {
                Debug.LogError("==== TopUISystem.Get() TopUI 인스턴스가 null 입니다.");
            }
            ui.Reset();

            if (parent != null)
            {
                ui.transform.SetParent(parent, false);
            }

            return ui;
        }

        public void Return(TopUI obj)
        {
            if(obj.IsLandscape == true)
            {
                pool.Return(obj);
            }
            else
            {
                poolPortrait.Return(obj);
            }
        }
    }
}