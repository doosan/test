using UnityEngine;
using UnityEngine.UI;
using Gaga.UI;
using Gaga.AssetBundle;
using Gaga.Attribute;
using DG.Tweening;
using Underc.User;
using Underc.Util;
using Gaga.Util;
using Underc.Popup;
using SlotGame.Machine;
using TMPro;
using System.Collections;
using Gaga;
using Gaga.Sound;
using Underc.Lobby;
using Underc.Net;
using System;
using Underc.Scene;
using UnityEngine.Serialization;
using System.Collections.Generic;
using UnityEngine.Events;

namespace Underc.UI
{
    public enum TopUiItem
    {
        Home,
        Coin,
        Shop,
        Profile,
        PearlAndTicket,
        Level,
        Setting
    }

    public sealed class TopUI : MonoBehaviour
    {
        [Serializable]
        public class SettingMenuItemInfo
        {
            public SettingMenuItemType type;
            public GameObject gameObject;
        }

        public enum HomeButtonDisplayType
        {
            Basic,
            Sea
        }

        [Flags]
        public enum SettingMenuItemType
        {
            Help = 1,
            System = 2,
            Paytable = 4
        }

#pragma warning disable 0649
        [SerializeField] private RectTransform infoRoot;
        [SerializeField] private RectTransform bg;

        [Separator("LeftSide")]
        [Space]
        [Header("Coin")]
        [SerializeField] private RectTransform coin;
        [SerializeField] private TextMeshProUGUI myCoinText;
        [SerializeField] private Transform coinIcon;
        [SerializeField] private GameObject coinEffect;

        [Separator("Right Side")]
        [SerializeField] private Button profileButton;
        [SerializeField] private RectTransform profileTransform;
        [SerializeField] private ProfileImage profileImage;

        [Header("Secondary Currencies")]
        [SerializeField] private RectTransform secondaryCurrenciesRoot;
        [SerializeField] private SoundPlayer secondaryCurrencieSFX;

        [Header("Pearl")]
        [SerializeField] private TextMeshProUGUI myPearlText;
        [SerializeField] private Transform pearlIcon;
        [SerializeField] private Animator pearlEffectAnim;

        [Header("Ticket")]
        [SerializeField] private TextMeshProUGUI myTicketText;
        [SerializeField] private Transform ticketIcon;
        [SerializeField] private Animator ticketEffectAnim;

        [Separator("Level")]
        [SerializeField] private LevelHUD levelHUD;
        [SerializeField] private RectTransform levelRectTransform;
        [SerializeField] private GameObject levelupView;

        [Separator("Center")]
        [Header("Shop")]
        [SerializeField] private RectTransform shopButton;
        [SerializeField] private RectTransform shopButtonCenter;

        [Separator("Home")]
        [SerializeField] private RectTransform homeButtonRoot;
        [FormerlySerializedAs("homeButtonNormal")]
        [SerializeField] private Button homeButtonBasic;
        [SerializeField] private Button homeButtonSea;

        [Separator("Settings")]
        [SerializeField] private Button settingButton;
        [SerializeField] private GameObject settingMenu;
        [SerializeField] private GameObject settingMenuBlockPanel;
        [SerializeField] private Animator settingMenuItemRoot;
        [SerializeField] private float settingMenuCloseDelay = 0.3f;
        [FormerlySerializedAs("settingMenuItems")]
        [SerializeField] private List<SettingMenuItemInfo> settingMenuItemInfos;

        [SerializeField] private GameObject paytableGuideTooltip;
        [SerializeField] private AnimatorParser paytableGuideTooltipEndAnimation;
        [SerializeField] private float paytableGuideTooltipDuration = 6f;
#pragma warning restore 0649
        public AnimatorParser PaytableGuideTooltipEndAnimation
        {
            get => paytableGuideTooltipEndAnimation;
        }
        public GameObject PaytableGuideTooltip
        {
            get => paytableGuideTooltip;
        }
        public float PaytableGuideTooltipDuration
        {
            get => paytableGuideTooltipDuration;
        }

        public LevelHUD LevelHUD
        {
            get => levelHUD;
        }

        public UnityEvent OnPayTable;

        public delegate void homeButtonClickDelegate();
        public event homeButtonClickDelegate OnHomeButtonClicked;

        private readonly float MOVE_DISTANCE = 150.0f;
        private readonly float NUMBER_DURATION = 0.5f;

        private HomeButtonDisplayType homeButtonDisplayMode = HomeButtonDisplayType.Basic;
        private Dictionary<TopUiItem, RectTransform> topUiItemTransforms;

        public RectTransform BgTransform
        {
            get => bg;
        }
        public float BgHalfWidth
        {
            get
            {
                if (bgHalfWidth == 0f)
                {
                    bgHalfWidth = BgTransform.rect.width / 2;
                }
                return bgHalfWidth;
            }
        }
        private float bgHalfWidth = 0f;

        private bool useHomeButton;
        public bool UseHomeButton
        {
            get{return useHomeButton;}
            set
            {
                useHomeButton = value;
                UpdateHomeButtonDisplay();
                homeButtonRoot.gameObject.SetActive(useHomeButton);
            }
        }

        public bool InteratableHomeButton
        {
            get{ return homeButtonBasic.interactable;}
            set
            {
                homeButtonBasic.interactable = value;
                homeButtonSea.interactable = value;
            }
        }

        private bool useSettingButton;
        public bool UseSettingButton
        {
            get{return useSettingButton;}
            set
            {
                useSettingButton = value;
                settingButton.gameObject.SetActive(value);
            }
        }

        public bool InteratableSettingButton
        {
            get{ return settingButton.interactable;}
            set{ settingButton.interactable = value;}
        }

        private bool useShopButton;
        public bool UseShopButton
        {
            get{return useShopButton;}
            set
            {
                useShopButton = value;
                shopButton.gameObject.SetActive(value);
            }
        }

        private bool useCoin;
        public bool UseCoin
        {
            get{return useCoin;}
            set
            {
                useCoin = value;
                coin.gameObject.SetActive(value);
            }
        }

        public bool InteratableProfileButton
        {
            get 
            {
                bool result = false;
                if (profileButton != null)
                {
                    result = profileButton.interactable;
                }

                return result;
            }
            set 
            { 
                if (profileButton != null)
                {
                    profileButton.interactable = value; 
                }
            }
        }

        private bool useProfile;
        public bool UseProfile
        {
            get => useProfile;
            set
            {
                useProfile = value;
                profileTransform.gameObject.SetActive(value);
            }
        }

        private bool useSecondaryCurrencies;
        public bool UseSecondaryCurrencies
        {
            get{return useSecondaryCurrencies;}
            set
            {
                useSecondaryCurrencies = value;
                if (secondaryCurrenciesRoot != null)
                {
                    secondaryCurrenciesRoot?.gameObject.SetActive(value);
                }
            }
        }

        private bool useLevel;
        public bool UseLevel
        {
            get{return useLevel;}
            set
            {
                useLevel = value;
                levelHUD.gameObject.SetActive(value);
            }
        }

        public bool IsLandscape { get { return IsPortrait == false; } }
        public bool IsPortrait { get; set; }

        private RectTransform settingButtonRectTransform;

        private Vector2 defaultShopButtonUiPos;
        private Vector2 defaultHomeButtonUiPos;
        private Vector2 defaultSettingButtonUiPos;
        private Vector2 defaultInfoRootUiPos;

        private long myCoin;
        private long myPearl;
        private long myTicket;

        public static TopUI New(Transform parent)
        {
            TopUI topUI = null;
            var ab = AssetBundleSystem.Instance.GetLoadedAssetBundle(AssetBundleName.TOP_UI);

            if (ab != null)
            {
                if (parent == null)
                {
                    topUI = ab.GetGameObject("TopUI", true).GetComponent<TopUI>();
                }
                else
                {
                    topUI = ab.GetGameObject("TopUI", parent).GetComponent<TopUI>();
                }
            }

            return topUI;
        }

        private void Awake()
        {
            settingButtonRectTransform = settingButton.GetComponent<RectTransform>();
            levelupView.SetActive(true);

            UseSecondaryCurrencies = true;
            UseCoin = true;
            UseLevel = true;
            UseShopButton = true;

            SetupDefaultPositions();
            SetupTopUiTransforms();

            profileImage?.ResetOnce();
        }

        private void OnEnable()
        {
            Reset();
        }

        private void OnDisable()
        {
            MyInfo.OnCoinsChanged -= OnCoinsChangedHandler;
            MyInfo.OnPearlsChanged -= OnPearlsChangedHandler;
            MyInfo.OnTicketsChanged -= OnTicketsChangedHandler;
            MyInfo.Profile.OnPicUpdated -= OnPicUpdated;
        }

        public void UpdateBG()
        {
            bool needBgOff = useShopButton == true
                             && useLevel == false
                             && useSecondaryCurrencies == false
                             && useCoin == false;

            bg.gameObject.SetActive(needBgOff == false);
        }

        public void Reset()
        {
            SetupLevelHUD();
            CloseSettingMenu(false);

            myCoin = MyInfo.Coin;
            myPearl = MyInfo.Pearl;
            myTicket = MyInfo.Ticket;

            MyInfo.OnCoinsChanged -= OnCoinsChangedHandler;
            MyInfo.OnPearlsChanged -= OnPearlsChangedHandler;
            MyInfo.OnTicketsChanged -= OnTicketsChangedHandler;

            MyInfo.OnCoinsChanged += OnCoinsChangedHandler;
            MyInfo.OnPearlsChanged += OnPearlsChangedHandler;
            MyInfo.OnTicketsChanged += OnTicketsChangedHandler;

            MyInfo.Profile.OnPicUpdated -= OnPicUpdated;
            MyInfo.Profile.OnPicUpdated += OnPicUpdated;

            coinEffect.SetActive(false);

            SetCoin(MyInfo.Coin, 0.0f);
            SetPearl(MyInfo.Pearl, 0.0f);
            SetTicket(MyInfo.Ticket, 0.0f);

            //Debug.Log("==== TopUI.Reset()");
            profileImage?.UpdateImage();

            InteratableHomeButton = true;
            InteratableSettingButton = true;
            InteratableProfileButton = true;

            paytableGuideTooltip.SetActive(false);

            Show(false);
        }

        private void SetupDefaultPositions()
        {
            defaultShopButtonUiPos = shopButton.anchoredPosition;
            defaultHomeButtonUiPos = homeButtonRoot.anchoredPosition;
            defaultSettingButtonUiPos = settingButtonRectTransform.anchoredPosition;
            defaultInfoRootUiPos = infoRoot.anchoredPosition;
        }

        private void SetupTopUiTransforms()
        {
            topUiItemTransforms = new Dictionary<TopUiItem, RectTransform>()
            {
                { TopUiItem.Coin, coin },
                { TopUiItem.Shop, shopButton },
                { TopUiItem.Profile, profileTransform },
                { TopUiItem.PearlAndTicket, secondaryCurrenciesRoot },
                { TopUiItem.Level, levelRectTransform }
            };
        }

        private void SetupLevelHUD()
        {
            levelHUD.SetLevel(MyInfo.Level);
            levelHUD.SetXP(MyInfo.BaseXP, MyInfo.CurrentXP, MyInfo.NextXP, false);
        }

        private void OnPicUpdated()
        {
            //Debug.Log("==== TopUI.OnPicUpdated()");
            profileImage?.UpdateImage();
        }

        private void OnCoinsChangedHandler(long coin)
        {
            SetCoin(coin, NUMBER_DURATION);

            if (coin > myCoin)
            {
                CoinEffect();
            }

            myCoin = coin;
        }

        private void OnPearlsChangedHandler(long pearl)
        {
            SetPearl(pearl, NUMBER_DURATION);

            if (pearl > myPearl)
            {
                PearlEffect();
            }

            myPearl = pearl;
        }

        private void OnTicketsChangedHandler(long ticket)
        {
            SetTicket(ticket, NUMBER_DURATION);

            if (ticket > myTicket)
            {
                TicketEffect();
            }

            myTicket = ticket;
        }

        private void SetCoin(long value, float duration)
        {
            myCoinText.SetNumber(value, true, duration, EasingFunction.Ease.Linear);
        }

        private void SetPearl(long value, float duration)
        {
            if (myPearlText != null)
            {
                var kmbOption = GetKMBOption();
                myPearlText.SetNumber(value, kmbOption, duration, EasingFunction.Ease.Linear);
            }
            
        }

        private void SetTicket(long value, float duration)
        {
            if (myTicketText != null)
            {
                var kmbOption = GetKMBOption();
                myTicketText.SetNumber(value, kmbOption, duration, EasingFunction.Ease.Linear);
            }
        }

        private StringUtils.KMBOption GetKMBOption()
        {
            var kmbOption = StringUtils.DefaultKMBOption();
            kmbOption.kiloStartingPoint = 0;
            kmbOption.ignoreDecimalPointUnderKilos = true;
            kmbOption.minLength = 3;
            kmbOption.space = false;
            kmbOption.ignorZeroDecimalPoint = true;
            kmbOption.startingValue = 10000;

            return kmbOption;
        }

        public void OnCoinButtonClick()
        {
            #if GGDEV
            Gaga.DeveloperTools.DeveloperTools.Instance.IsOn = !Gaga.DeveloperTools.DeveloperTools.Instance.IsOn;
            #endif
        }
        
        public void OnLobbyButtonClick()
        {
            if (OnHomeButtonClicked != null)
            {
                OnHomeButtonClicked.Invoke();
            }
        }

        public void OnShopButtonClick()
        {
            UndercGameLog.Singular.OpenShop();
            UndercGameLog.Firebase.OpenShop();
            StartCoroutine(OpenShop());
        }

        private IEnumerator OpenShop()
        {
            var slotMachine = GameObject.FindObjectOfType<SlotMachine>();
            if (slotMachine != null)
            {
                slotMachine.Pause();

                UndercGameLog.Fobis.ButtonSlot(8);
            }
            else
            {
                var lobbyManager = GameObject.FindObjectOfType<LobbyManager>();
                if (lobbyManager != null)
                {
                    if (lobbyManager.CurrentState == LobbyManager.State.ExecuteOcean)
                    {
                        UndercGameLog.Fobis.ButtonSeaMenu(12);
                    }
                    else if (lobbyManager.CurrentState == LobbyManager.State.ExecuteGame)
                    {
                        UndercGameLog.Fobis.ButtonLobbyMenu(8);
                    }
                }
            }

            yield return Popups.Shop()
                               .Async()
                               .Cache()
                               .WaitForClose();

            yield return OfferSystem.Instance.OpenShop();

                  
            if (slotMachine != null)
            {
                slotMachine.Resume();
            }
        }

        public void OnDealButtonClick()
        {
            UndercGameLog.Singular.OpenDeal();
            UndercGameLog.Firebase.OpenDeal();
            
            StartCoroutine(OpenDealCoroutine());
        }

        private IEnumerator OpenDealCoroutine()
        {
            var slotMachine = GameObject.FindObjectOfType<SlotMachine>();
            if (slotMachine != null)
            {
                slotMachine.Pause();
            }

            Action _ResumeSpins = () =>
            {
                if (slotMachine != null)
                {
                    slotMachine.Resume();
                }
            };

            Popups.ShowLoading();

            var req = NetworkSystem.HTTPRequester.Deal();
            yield return req.WaitForResponse();
            MyInfo.Deal.Update(req.data.deal);

            Popups.HideLoading();

            if (req.isSuccess)
            {
                OfferInfo offerInfo = MyInfo.Deal.CurrentDeal;
                Popups.Offer(offerInfo)
                      .Async()
                      .Cache()
                      .OnClose(_ResumeSpins);
            }
            else
            {
                Popups.Error(req.data.error)
                      .Async()
                      .OnClose(_ResumeSpins);
            }
        }

        public void OnProfileClick()
        {
            OpenGameProfilePopup(tabIndex: 0);
        }

        public void OpenSettingMenu()
        {
            StopCoroutine("CloseSettingMenuWithDelay");

            settingMenu.SetActive(false);
            settingMenu.SetActive(true);

            settingMenuItemRoot.gameObject.SetActive(true);
            settingMenuBlockPanel.SetActive(true);
        }

        public void CloseSettingMenu(bool animation)
        {
            settingMenuBlockPanel.SetActive(false);

            if (animation)
            {
                StopCoroutine("CloseSettingMenuWithDelay");
                StartCoroutine("CloseSettingMenuWithDelay");
            }
            else
            {
                settingMenuItemRoot.gameObject.SetActive(false);
                settingMenu.gameObject.SetActive(false);
            }
        }

        private IEnumerator CloseSettingMenuWithDelay()
        {
            settingMenuItemRoot.SetTrigger("Close");

            yield return new WaitForSeconds(settingMenuCloseDelay);

            settingMenuItemRoot.gameObject.SetActive(false);
            settingMenu.gameObject.SetActive(false);
        }

        public void OnPayTableButtonClick()
        {
            OnPayTable?.Invoke();
            CloseSettingMenu(false);
        }

        public void OnSystemButtonClick()
        {
            OpenGameSettingPopup(0);
            CloseSettingMenu(false);
        }

        public void OnHelpButtonClick()
        {
            OpenGameSettingPopup(1);
            CloseSettingMenu(false);
        }

        public void OpenGameSettingPopup(int tabIndex)
        {
            Popups.GameSetting(tabIndex).Async().Cache();
        }

        public void OpenGameProfilePopup(int tabIndex)
        {
            Popups.GameProfile(tabIndex).Async().Cache();
        }

        public void ShowMainHUD(bool animation, float delay = 0.0f)
        {
            infoRoot.DOKill(false);
            shopButton.DOKill(false);

            if (animation == true)
            {
                infoRoot.DOAnchorPosY(defaultInfoRootUiPos.y, 0.3f)
                        .SetEase(Ease.OutQuint)
                        .SetDelay(delay);


                shopButton.DOAnchorPosY(defaultShopButtonUiPos.y, 0.3f).SetEase(Ease.OutQuint);
            }
            else
            {
                infoRoot.anchoredPosition = new Vector2(infoRoot.anchoredPosition.x, defaultInfoRootUiPos.y);
                shopButton.anchoredPosition = new Vector2(shopButton.anchoredPosition.x, defaultShopButtonUiPos.y);
            }
        }

        public void ShowHomeButton(bool animation, float delay = 0.0f)
        {
            homeButtonRoot.DOKill(false);

            if (animation == true)
            {
                homeButtonRoot.DOAnchorPos(defaultHomeButtonUiPos, 0.3f)
                              .SetEase(Ease.OutExpo)
                              .SetDelay(delay);
            }
            else
            {
                homeButtonRoot.anchoredPosition = defaultHomeButtonUiPos;
            }
        }

        public void ShowSettingButton(bool animation, float delay = 0.0f)
        {
            settingButtonRectTransform.DOKill(false);

            if (animation == true)
            {
                settingButtonRectTransform.DOAnchorPos(defaultSettingButtonUiPos, 0.3f)
                                          .SetEase(Ease.OutExpo)
                                          .SetDelay(delay);
            }
            else
            {
                settingButtonRectTransform.anchoredPosition = defaultSettingButtonUiPos;
            }
        }

        public void Show(bool animation)
        {
            ShowMainHUD(animation, 0.12f);
            ShowHomeButton(animation, 0.2f);
            ShowSettingButton(animation, 0.3f);
        }

        public void HideMainHUD(bool animation, float delay = 0.0f)
        {
            infoRoot.DOKill(false);
            shopButton.DOKill(false);

            if (animation == true)
            {
                infoRoot.DOAnchorPosY(defaultInfoRootUiPos.y + MOVE_DISTANCE, delay).SetEase(Ease.OutQuint);
                shopButton.DOAnchorPosY(defaultShopButtonUiPos.y + MOVE_DISTANCE, delay + 0.2f).SetEase(Ease.OutQuint);
            }
            else
            {
                SetRelativeAnchoredPosition(infoRoot, 0, MOVE_DISTANCE);
                SetRelativeAnchoredPosition(shopButton, 0, MOVE_DISTANCE);
            }
        }

        public void HideHomeButton(bool animation, float delay = 0.0f)
        {
            homeButtonRoot.DOKill(false);

            if (animation == true)
            {
                homeButtonRoot.DOAnchorPos(new Vector2(defaultHomeButtonUiPos.x - MOVE_DISTANCE, defaultHomeButtonUiPos.y + MOVE_DISTANCE), 0.3f)
                              .SetEase(Ease.InOutQuint)
                              .SetDelay(delay);
            }
            else
            {
                SetRelativeAnchoredPosition(homeButtonRoot, -MOVE_DISTANCE, MOVE_DISTANCE);
            }
        }

        public void HideSettingButton(bool animation, float delay = 0.0f)
        {
            settingButtonRectTransform.DOKill(false);

            if (animation == true)
            {
                settingButtonRectTransform.DOAnchorPos(new Vector2(defaultSettingButtonUiPos.x + MOVE_DISTANCE, defaultSettingButtonUiPos.y + MOVE_DISTANCE), 0.3f)
                                          .SetEase(Ease.InOutQuint)
                                          .SetDelay(delay);
            }
            else
            {
                SetRelativeAnchoredPosition(settingButtonRectTransform, MOVE_DISTANCE, MOVE_DISTANCE);
            }
        }

        public void OrderAsDefault()
        {
            Order(TopUiItem.Coin,
                  TopUiItem.Shop,
                  TopUiItem.Profile,
                  TopUiItem.PearlAndTicket,
                  TopUiItem.Level);
        }

        public void Order(params TopUiItem[] items)
        {
            for (int i = 0; i < items.Length; i++)
            {
                TopUiItem item = items[i];
                RectTransform itemTransform;
                // Home 버튼과 Setting 버튼은 정렬 대상이 아님
                if (topUiItemTransforms.TryGetValue(item, out itemTransform))
                {
                    itemTransform.SetAsLastSibling();
                }
            }
        }

        public void Use(params TopUiItem[] items)
        {
            foreach (TopUiItem item in Enum.GetValues(typeof(TopUiItem)))
            {
                Use(item, false);
            }
            foreach (TopUiItem item in items)
            {
                Use(item, true);
            }
        }

        private void Use(TopUiItem item, bool value)
        {
            switch (item)
            {
                case TopUiItem.Home:
                    UseHomeButton = value;
                    break;

                case TopUiItem.Coin:
                    UseCoin = value;
                    break;

                case TopUiItem.Shop:
                    UseShopButton = value;
                    break;

                case TopUiItem.Profile:
                    UseProfile = value;
                    break;

                case TopUiItem.PearlAndTicket:
                    UseSecondaryCurrencies = value;
                    break;

                case TopUiItem.Level:
                    UseLevel = value;
                    break;

                case TopUiItem.Setting:
                    UseSettingButton = value;
                    break;
            }
        }

        public void OceanLobbyStyle()
        {
            Use(TopUiItem.Coin,
                TopUiItem.Shop,
                TopUiItem.Profile,
                TopUiItem.PearlAndTicket,
                TopUiItem.Setting);
            OrderAsDefault();
        }

        public void SlotLobbyStyle()
        {
            Use(TopUiItem.Coin,
                TopUiItem.Shop,
                TopUiItem.Profile,
                TopUiItem.Level,
                TopUiItem.Setting);
            OrderAsDefault();
            SetSettingMenuItemType(SettingMenuItemType.Help
                                   | SettingMenuItemType.System);
        }

        public void Hide(bool animation)
        {
            HideMainHUD(animation, 0.3f);
            HideHomeButton(animation, 0.0f);
            HideSettingButton(animation, 0.0f);
        }

        private void SetRelativeAnchoredPosition(RectTransform tr, float x, float y)
        {
            var tempPos = tr.anchoredPosition;
            tempPos.x += x;
            tempPos.y += y;
            tr.anchoredPosition = tempPos;
        }

        public void CoinIconAnimation()
        {
            coinIcon.DOKill(true);
            coinIcon.DOScale(new Vector3(1.5f, 1.5f, 1.0f), 0.3f).SetEase(Ease.OutBack).From();
        }

        public void ProfileAnimation()
        {
            profileTransform.DOKill(true);
            profileTransform.DOScale(new Vector3(1.5f, 1.5f, 1.0f), 0.3f).SetEase(Ease.OutBack).From();
        }

        public void PearlIconAnimation()
        {
            pearlIcon.DOKill(true);
            pearlIcon.DOScale(new Vector3(1.5f, 1.5f, 1.0f), 0.3f).SetEase(Ease.OutBack).From();
        }

        public void TicketIconAnimation()
        {
            ticketIcon.DOKill(true);
            ticketIcon.DOScale(new Vector3(1.5f, 1.5f, 1.0f), 0.3f).SetEase(Ease.OutBack).From();
        }

        public void HomeIconAnimation()
        {
            homeButtonBasic.transform.DOKill(true);
            homeButtonBasic.transform.DOScale(new Vector3(1.5f, 1.5f, 1.0f), 0.3f).SetEase(Ease.OutBack).From();
        }

        private void CoinEffect()
        {
            coinEffect.SetActive(false);
            coinEffect.SetActive(true);
        }

        private void PearlEffect()
        {
            secondaryCurrencieSFX.Play();
            pearlEffectAnim.SetTrigger("Collect");
        }

        private void TicketEffect()
        {
            secondaryCurrencieSFX.Play();
            ticketEffectAnim.SetTrigger("Collect");
        }

        public Transform GetCoinIcon()
        {
            return coinIcon;
        }

        public Vector2 GetCoinIconPosition()
        {
            return coinIcon.position;
        }

        public Transform GetProfileIcon()
        {
            return profileTransform;
        }

        public Vector2 GetProfileButtonPosition()
        {
            return profileTransform.position;
        }

        public Transform GetPearlIcon()
        {
            return pearlIcon;
        }

        public Vector2 GetPearlIconPosition()
        {
            return pearlIcon.position;
        }

        public Transform GetTicketIcon()
        {
            return ticketIcon;
        }

        public Vector2 GetTicketIconPosition()
        {
            return ticketIcon.position;
        }

        public Vector2 GetSecondaryCurrenciesPosition()
        {
            return secondaryCurrenciesRoot.position;
        }

        public Vector2 GetShopPosition()
        {
            return shopButtonCenter.position;
        }

        public Vector2 GetLevelPosition()
        {
            return levelRectTransform.position;
        }

        public Vector2 GetHomePosition()
        {
            return homeButtonBasic.transform.position;
        }

        public void SetHomeButtonDisplayType(HomeButtonDisplayType homeButtonDisplayMode)
        {
            this.homeButtonDisplayMode = homeButtonDisplayMode;
            UpdateHomeButtonDisplay();
        }

        private void UpdateHomeButtonDisplay()
        {
            homeButtonBasic.gameObject.SetActive(homeButtonDisplayMode == HomeButtonDisplayType.Basic);
            homeButtonSea.gameObject.SetActive(homeButtonDisplayMode == HomeButtonDisplayType.Sea);
        }

        public void SetSettingMenuItemType(SettingMenuItemType targetType)
        {
            foreach (SettingMenuItemInfo info in settingMenuItemInfos)
            {
                SettingMenuItemType itemType = info.type;
                GameObject gameObject = info.gameObject;

                gameObject.SetActive(false);
                gameObject.SetActive((itemType & targetType) > 0);
            }
        }
    }
}