using DG.Tweening;
using UnityEngine;
using Gaga.System;
using Gaga.UI;
using System;
using UnityEngine.UI;

namespace Underc.UI
{
    public sealed class LoadingIndicator : BaseLoadingIndicator
    {
        #region static
        private const string ROOT_NAME = "SingletonObjects";
        private static GameObjectPool<LoadingIndicator> pool;
        private static LoadingIndicator prefab;

        public static void Initialize()
        {
            GameObject root = GameObject.Find(ROOT_NAME);
            if (root == null)
            {
                root = new GameObject(ROOT_NAME);
                DontDestroyOnLoad(root);
            }

            prefab = Resources.Load<LoadingIndicator>("LoadingIndicator");
            pool = new GameObjectPool<LoadingIndicator>(root, 2, () =>
            {
                return Instantiate(prefab);
            });
        }

        public static LoadingIndicator Get(Transform parent = null, bool autoReturn = true)
        {
            LoadingIndicator indicator = pool.Get();

            if (parent != null)
            {
                indicator.SetParent(parent);
            }

            indicator.autoReturn = autoReturn;
            return indicator;
        }

        public static void Return(LoadingIndicator indicator)
        {
            pool.Return(indicator);
        }
        #endregion

        [Serializable]
        public class Properties
        {
            public float showDuration = 0.25f;
            public Ease showEase = Ease.InCubic;
            public float hideDuration = 0.2f;
            public Ease hideEase = Ease.OutCubic;
            public bool blocksRaycasts = true;
        }

        [SerializeField] private Image icon;
        [SerializeField] private float iconDelay = 0.6f;

        [Space]
        [SerializeField] private CanvasGroup canvasGroup = null;
        [SerializeField] private Properties defaultProperteis = null;
        public bool autoReturn = true;

        private Properties overridedProperties;
        private Properties currentProperteis;

        private bool isActvie;
        public override bool IsActive
        {
            get => isActvie;
        }

        protected override void Awake()
        {
            base.Awake();
            canvasGroup.alpha = 0f;
            ResetIcon();
        }

        private void ResetIcon()
        {
            icon.color = new Color(1.0f, 1.0f, 1.0f, 0.0f);
        }

        public void SetProperteis(float showDuration  = 0.25f, Ease showEase = Ease.InCubic,
                                  float hideDuration = 0.2f, Ease hideEase = Ease.OutCubic)
        {
            overridedProperties = new Properties()
            {
                showDuration = showDuration,
                showEase = showEase,
                hideDuration = hideDuration,
                hideEase = hideEase
            };
        }

        private void SelectProperties()
        {
            currentProperteis = overridedProperties ?? defaultProperteis;
        }

        public override BaseLoadingIndicator Show(bool blocksRaycast = true)
        {
            isActvie = true;

            SelectProperties();

            gameObject.SetActive(true);
            canvasGroup.blocksRaycasts = blocksRaycast;
            canvasGroup.DOKill();
            canvasGroup.DOFade(1, currentProperteis.showDuration).SetEase(currentProperteis.showEase);

            icon.DOKill(false);

            if (icon.color.a > 0.0f)
            {
                icon.DOColor(new Color(1.0f, 1.0f, 1.0f, 1.0f), 0.1f);
            }
            else
            {
                icon.DOColor(new Color(1.0f, 1.0f, 1.0f, 1.0f), 0.1f).SetDelay(iconDelay);
            }

            return this;
        }

        public override void Hide(Action onComplete = null)
        {
            isActvie = false;

            SelectProperties();
            
            canvasGroup.DOKill();
            canvasGroup.DOFade(0, currentProperteis.hideDuration)
                       .SetEase(currentProperteis.hideEase)
                       .OnComplete(()=>
                       {
                           ResetIcon();
                           OnHideComplete();

                           if (onComplete != null)
                           {
                               onComplete();
                           }
                       });

            icon.DOKill(false);
        }

        private void OnHideComplete()
        {
            if (autoReturn == true)
            {
                overridedProperties = null;
                Return(this);
            }
            else
            {
                gameObject.SetActive(false);
            }
        }
    }
}