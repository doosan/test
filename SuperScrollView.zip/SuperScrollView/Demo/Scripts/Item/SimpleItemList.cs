﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace SuperScrollView
{
    public class SimpleItemList : MonoBehaviour
    {
        public Text mNameList;  
        public List<SimpleItem> mItemList;
        public void Init()
        {           
        }       
    }
}
