﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace SuperScrollView
{
    public class LoadComplexItem : MonoBehaviour
    {
        public GameObject mRoot1;
        public GameObject mRoot;
        public Text mText;
        public GameObject mArrow;
        public GameObject mWaitingIcon;
    }
}
