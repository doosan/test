using TMPro;
using UnityEngine;

namespace SlotKingdoms.UI
{
    public sealed class VersionText : MonoBehaviour
    {
        [SerializeField] private TextMeshProUGUI versionText;

        private void Awake()
        {
            GameAddress.OnAddressablesVersionUpdated.AddListener(WriteVersionText);
            WriteVersionText();
        }

        private void OnDestroy()
        {
            GameAddress.OnAddressablesVersionUpdated.RemoveListener(WriteVersionText);
        }

        private void WriteVersionText()
        {
            if (versionText != null)
            {
                versionText.text = GameService.GetAppVersion();
            }
        }
    }
}