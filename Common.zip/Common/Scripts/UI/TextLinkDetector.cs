using System;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;

namespace SlotKingdoms
{
    public enum TextLinkId
    {
        TermsOfService,
        PrivacyPolicy,
    }

    public class TextLinkDetector : MonoBehaviour, IPointerClickHandler
    {
        [SerializeField] TextMeshProUGUI text;

        private Camera uiCamera;

        public void OnPointerClick(PointerEventData eventData)
        {
            int linkIndex = TMP_TextUtilities.FindIntersectingLink(text, eventData.position, GetUiCamera());
            if (linkIndex != -1)
            {
                // 링크 정보 가져오기
                TMP_LinkInfo linkInfo = text.textInfo.linkInfo[linkIndex];
                string linkIdStr = linkInfo.GetLinkID();
                if (Enum.TryParse(linkIdStr, out TextLinkId linkId))
                {
                    // 링크 ID에 따른 액션 수행
                    Debug.Log($"Clicked on link ID: {linkIdStr}");
                    GameService.OpenTextLink(linkId);
                }
            }
        }

        private Camera GetUiCamera()
        {
            if (uiCamera == null)
            {
                Canvas canvas = GetComponentInParent<Canvas>();
                uiCamera = (canvas.renderMode == RenderMode.ScreenSpaceOverlay) ?
                           Camera.main : 
                           canvas.worldCamera;
            }
            return uiCamera;
        }
    }
}
