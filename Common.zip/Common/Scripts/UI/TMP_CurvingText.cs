using UnityEngine;
using System.Collections;
using SlotKingdoms.Attribute;


namespace SlotKingdoms.UI
{
    [System.Serializable]
    public class CurvedInfo
    {
        public int TextLen = 0;
        public int CurveScale = 0;
    }
  

    /// <summary>
    /// Base class for drawing a Text Pro text following a particular curve
    /// </summary>
    [ExecuteInEditMode]
    public class TMP_CurvingText : MonoBehaviour
    {
        public TMPro.TMP_Text[] m_TextComponents;

        public AnimationCurve VertexCurve = new AnimationCurve(new Keyframe(0, 0), new Keyframe(0.25f, 2.0f), new Keyframe(0.5f, 0), new Keyframe(0.75f, 2.0f), new Keyframe(1, 0f));

        [Header("문자열변경")]
        public string SetAllText = "";

        [Space]
        [Header("고정문자열")]
        public float CurveScale = 1.0f;
                
        [Header("가변문자열")]
        public CurvedInfo[] MyCurvedInfo;

        private Coroutine coroutine;

        void Awake()
        {
            // list로 받아 들인 값이 없으면 Default로 현재 Object에서 찾는다.
            if (0 == m_TextComponents.Length)
            {
                m_TextComponents.Push(gameObject.GetComponent<TMPro.TMP_Text>());
            }

            //m_TextComponent = gameObject.GetComponent<TMPro.TMP_Text>();

            // 문자열 세팅
            foreach (var info in m_TextComponents)
            {
                if (SetAllText.Length > 0)
                {
                    info.text = SetAllText;
                }
            }
        }

       
        float FindCurveScale()
        {
            float iSelectCurveScale = CurveScale;

            int textLength = m_TextComponents[0].text.Length;            
            int closestTextLen = -1;

            foreach (var info in MyCurvedInfo)
            {
                // textLength값과 같거나 TextLen보다 작은 가장 큰 CurveScale 값을 반환합니다.
                if (info.TextLen <= textLength && info.TextLen > closestTextLen)
                {
                    closestTextLen = info.TextLen;
                    iSelectCurveScale = info.CurveScale;
                }
            }

            return iSelectCurveScale;
        }


        void Start()
        {
            if(null != coroutine)
            {
                StopCoroutine(coroutine);
            }

            coroutine = StartCoroutine(CurvedText());
        }

        private void OnEnable()
        {
            if (null != coroutine)
            {
                StopCoroutine(coroutine);
            }

            coroutine = StartCoroutine(CurvedText());
        }

        private AnimationCurve CopyAnimationCurve(AnimationCurve curve)
        {
            AnimationCurve newCurve = new AnimationCurve();

            newCurve.keys = curve.keys;

            return newCurve;
        }


        /// <summary>
        ///  Method to curve text along a Unity animation curve.
        /// </summary>
        /// <param name="textComponent"></param>
        /// <returns></returns>
        IEnumerator CurvedText()
        {
            VertexCurve.preWrapMode = WrapMode.Clamp;
            VertexCurve.postWrapMode = WrapMode.Clamp;

            //Mesh mesh = m_TextComponent.textInfo.meshInfo[0].mesh;
                       
            Vector3[] vertices;
            Matrix4x4 matrix;

            while (true)
            {
                for (int z = 0; z < m_TextComponents.Length; z++)
                {
                    // 문자열 세팅
                    if (SetAllText.Length > 0)
                    {
                        m_TextComponents[z].text = SetAllText;
                    }

                    m_TextComponents[z].havePropertiesChanged = true; // Need to force the TextMeshPro Object to be updated.                                                                    

                    // 문자열이 가변일경우를 위해 해당 문자열에 해당하는 Scale값을 찾는다.
                    float SelectCurveScale = FindCurveScale();

                    float old_CurveScale = SelectCurveScale;

                    AnimationCurve old_curve = CopyAnimationCurve(VertexCurve);

                    if (!m_TextComponents[z].havePropertiesChanged && old_CurveScale == SelectCurveScale  && old_curve.keys[1].value == VertexCurve.keys[1].value)
                    {
                        yield return null;
                        continue;
                    }

                    old_CurveScale = SelectCurveScale ;
                    old_curve = CopyAnimationCurve(VertexCurve);

                    m_TextComponents[z].ForceMeshUpdate(); // Generate the mesh and populate the textInfo with data we can use and manipulate.

                    TMPro.TMP_TextInfo textInfo = m_TextComponents[z].textInfo;
                    int characterCount = textInfo.characterCount;


                    if (characterCount == 0)
                        continue;

                    //vertices = textInfo.meshInfo[0].vertices;
                    //int lastVertexIndex = textInfo.characterInfo[characterCount - 1].vertexIndex;

                    float boundsMinX = m_TextComponents[z].bounds.min.x;  //textInfo.meshInfo[0].mesh.bounds.min.x;
                    float boundsMaxX = m_TextComponents[z].bounds.max.x;  //textInfo.meshInfo[0].mesh.bounds.max.x;

                    for (int k = 0; k < characterCount; k++)
                    {
                        if (!textInfo.characterInfo[k].isVisible)
                            continue;

                        int vertexIndex = textInfo.characterInfo[k].vertexIndex;

                        // Get the index of the mesh used by this character.
                        int materialIndex = textInfo.characterInfo[k].materialReferenceIndex;

                        vertices = textInfo.meshInfo[materialIndex].vertices;

                        // Compute the baseline mid point for each character
                        Vector3 offsetToMidBaseline = new Vector2((vertices[vertexIndex + 0].x + vertices[vertexIndex + 2].x) / 2, textInfo.characterInfo[k].baseLine);
                        //float offsetY = VertexCurve.Evaluate((float)i / characterCount + loopCount / 50f); // Random.Range(-0.25f, 0.25f);

                        // Apply offset to adjust our pivot point.
                        vertices[vertexIndex + 0] += -offsetToMidBaseline;
                        vertices[vertexIndex + 1] += -offsetToMidBaseline;
                        vertices[vertexIndex + 2] += -offsetToMidBaseline;
                        vertices[vertexIndex + 3] += -offsetToMidBaseline;

                        // Compute the angle of rotation for each character based on the animation curve
                        float x0 = (offsetToMidBaseline.x - boundsMinX) / (boundsMaxX - boundsMinX); // Character's position relative to the bounds of the mesh.
                        float x1 = x0 + 0.0001f;
                        float y0 = VertexCurve.Evaluate(x0) * SelectCurveScale ;
                        float y1 = VertexCurve.Evaluate(x1) * SelectCurveScale ;

                        Vector3 horizontal = new Vector3(1, 0, 0);
                        //Vector3 normal = new Vector3(-(y1 - y0), (x1 * (boundsMaxX - boundsMinX) + boundsMinX) - offsetToMidBaseline.x, 0);
                        Vector3 tangent = new Vector3(x1 * (boundsMaxX - boundsMinX) + boundsMinX, y1) - new Vector3(offsetToMidBaseline.x, y0);

                        float dot = Mathf.Acos(Vector3.Dot(horizontal, tangent.normalized)) * 57.2957795f;
                        Vector3 cross = Vector3.Cross(horizontal, tangent);
                        float angle = cross.z > 0 ? dot : 360 - dot;

                        matrix = Matrix4x4.TRS(new Vector3(0, y0, 0), Quaternion.Euler(0, 0, angle), Vector3.one);

                        vertices[vertexIndex + 0] = matrix.MultiplyPoint3x4(vertices[vertexIndex + 0]);
                        vertices[vertexIndex + 1] = matrix.MultiplyPoint3x4(vertices[vertexIndex + 1]);
                        vertices[vertexIndex + 2] = matrix.MultiplyPoint3x4(vertices[vertexIndex + 2]);
                        vertices[vertexIndex + 3] = matrix.MultiplyPoint3x4(vertices[vertexIndex + 3]);

                        vertices[vertexIndex + 0] += offsetToMidBaseline;
                        vertices[vertexIndex + 1] += offsetToMidBaseline;
                        vertices[vertexIndex + 2] += offsetToMidBaseline;
                        vertices[vertexIndex + 3] += offsetToMidBaseline;
                    }


                    // Upload the mesh with the revised information
                    m_TextComponents[z].UpdateVertexData();                    
                }

                //yield return new WaitForSeconds(0.025f);
                yield return null;
            }
        }
    }
}
