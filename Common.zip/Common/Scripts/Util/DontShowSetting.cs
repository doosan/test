using System.Collections.Generic;
using UnityEngine;

namespace SlotKingdoms
{
    public class DontShowSetting
    {
        private const char TimestampSeparator = '_';
        private const char DataSeparator = ',';

        public int CoolTime
        {
            private get;
            set;
        } = 60 * 60 * 24;

        private string prefKey;
        private Dictionary<long, long> timestamps;

        public DontShowSetting(string prefKey)
        {
            this.prefKey = prefKey;

            timestamps = new Dictionary<long, long>();
        }

        public long Get(uint id)
        {
            long timestamp;
            timestamps.TryGetValue(id, out timestamp);
            return timestamp;
        }

        public void Set(uint id)
        {
            timestamps[id] = GlobalTime.Instance.GetTimeStamp();
        }

        public void Save()
        {
            if (timestamps.Count == 0)
            {
                PlayerPrefs.DeleteKey(prefKey);
            }
            else
            {
                var timestampLogs = new List<string>();
                foreach (KeyValuePair<long, long> pair in timestamps)
                {
                    long id = pair.Key;
                    long timestamp = pair.Value;

                    string timestampLog = StringMaker.New()
                                                     .Append(id.ToString())
                                                     .Append(TimestampSeparator.ToString())
                                                     .Append(timestamp.ToString())
                                                     .Build();
                    timestampLogs.Add(timestampLog);
                }

                string timestampLogsStr = timestampLogs.ToEachString(DataSeparator.ToString());
                PlayerPrefs.SetString(prefKey, timestampLogsStr);
                Debug.LogFormat($"==== NoticeSystem SaveToggleData: {timestampLogsStr}");
            }
        }

        public void Load()
        {
            timestamps.Clear();

            string timestampLogsStr = PlayerPrefs.GetString(prefKey, "");
            if (string.IsNullOrEmpty(timestampLogsStr) == false)
            {
                string[] timestampLogs = timestampLogsStr.Split(DataSeparator);
                foreach (string timestampLog in timestampLogs)
                {
                    if (string.IsNullOrEmpty(timestampLog) == true)
                    {
                        continue;
                    }

                    string[] timestampPair = timestampLog.Split(TimestampSeparator);
                    if (timestampPair.Length < 2)
                    {
                        continue;
                    }

                    long id;
                    long timestamp;
                    if (long.TryParse(timestampPair[0], out id) == false
                        || long.TryParse(timestampPair[1], out timestamp) == false)
                    {
                        continue;
                    }

                    if (IsInDontShow(timestamp) == true)
                    {
                        timestamps.Add(id, timestamp);
                    }
                }
            }
        }

        public bool IsInDontShow(long timestamp)
        {
            long now = GlobalTime.Instance.GetTimeStamp();
            long passedTime = now - timestamp;
            //Debug.Log($"==== IsInDontShow : {passedTime} / {CoolTime}");
            return passedTime < CoolTime;
        }
    }
}