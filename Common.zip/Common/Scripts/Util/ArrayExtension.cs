using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace SlotKingdoms
{
    public static class ArrayExtension
    {
        public static T[] Push<T>(this T[] array, T value)
        {
            if (array == null) throw new ArgumentNullException("array");
            if (value == null) throw new ArgumentNullException("value");

            Array.Resize(ref array, array.Length + 1);
            array[array.GetUpperBound(0)] = value;
            return array;
        }
        public static int FindIndex<T>(this T[] array, Func<T, bool> converter)
        {
            if (array == null) throw new ArgumentNullException("array");
            if (converter == null) throw new ArgumentNullException("converter");

            int index = 0;
            foreach (var item in array)
            {
                if(converter(item))
                {
                    break;
                }
                index++;
            }
            return index;
        }
    }
}
