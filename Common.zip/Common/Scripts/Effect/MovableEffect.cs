using SlotKingdoms.Attribute;
using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace SlotKingdoms.Effect
{
    [DisallowMultipleComponent]
    public sealed class MovableEffect : MonoBehaviour
    {
        public enum State
        {
            StartEffect,
            Move,
            EndEffect
        }

        [Serializable]
        public sealed class Preset
        {
            public float startDelay;
            public GameObject startEffect;
            public bool startEffectAutoDisable = false;

            [Space]
            public float moveDelay;
            public CurveMovement movableEffect;
            public bool movableEffectAutoDisable = false;

            [Space]
            public float endDuration;
            public GameObject endEffect;

            [Space] 
            public bool hasText = false;
            public TextMeshProUGUI text;

            public float TotalDuration
            {
                get
                {
                    return moveDelay + movableEffect.duration + endDuration;
                }
            }
        }

        [SerializeField] private List<Preset> presets;
        private Preset currentPreset;
        private Action onComplete;
        private Action<State> onStateChange;
        private bool isQuit = false;

        private void Awake()
        {
            for (int i = 0; i < presets.Count; i++)
            {
                Stop(presets[i]);
            }
        }

        private void OnApplicationQuit()
        {
            isQuit = true;
        }

        private void OnDisable()
        {
            Stop();
        }

        public void AddPreset(Preset preset)
        {
            if (presets.Contains(preset))
            {
                return;
            }

            presets.Add(preset);
        }

        public void RemovePreset(Preset preset)
        {
            if (presets.Contains(preset) == false)
            {
                return;
            }

            presets.Remove(preset);
        }

        public Preset GetPreset()
        {
            return GetPreset(0);
        }

        public Preset GetPreset(int index)
        {
            if (index >= presets.Count)
            {
                Debug.Log("presetIndex가 presets 길이를 벗어남.");
                return null;
            }

            return presets[index];
        }

        public void Play(Vector3 from, Vector3 to, Action _onComplete = null, Action<State> _onStateChange = null)
        {
            Play(0, from, to, false, _onComplete, _onStateChange);
        }

        public void Play(Vector3 to, Action _onComplete = null, Action<State> _onStateChange = null)
        {
            Play(0, transform.position, to, false, _onComplete, _onStateChange);
        }

        public void Play(int presetIndex, Vector3 from, Vector3 to, Action _onComplete = null, Action<State> _onStateChange = null)
        {
            Play(presetIndex, from, to, false, _onComplete, _onStateChange);
        }

        public void Play(int presetIndex, Vector3 to, Action _onComplete = null, Action<State> _onStateChange = null)
        {
            Play(presetIndex, transform.position, to, false, _onComplete, _onStateChange);
        }

        public void PlayLocal(Vector3 from, Vector3 to, Action _onComplete = null, Action<State> _onStateChange = null)
        {
            Play(0, from, to, true, _onComplete, _onStateChange);
        }

        public void PlayLocal(Vector3 to, Action _onComplete = null, Action<State> _onStateChange = null)
        {
            Play(0, transform.localPosition, to, true, _onComplete, _onStateChange);
        }

        public void PlayLocal(int presetIndex, Vector3 from, Vector3 to, Action _onComplete = null, Action<State> _onStateChange = null)
        {
            Play(presetIndex, from, to, true, _onComplete, _onStateChange);
        }

        public void PlayLocal(int presetIndex, Vector3 to, Action _onComplete = null, Action<State> _onStateChange = null)
        {
            Play(presetIndex, transform.localPosition, to, true, _onComplete, _onStateChange);
        }

        private void Play(int presetIndex, Vector3 from, Vector3 to, bool isLocalPosition, Action _onComplete, Action<State> _onStateChange)
        {
            if (currentPreset != null)
            {
                Debug.Log("이미 플레이 중입니다.");
                return;
            }

            Preset preset = GetPreset(presetIndex);

            if (preset == null)
            {
                return;
            }

            onComplete = _onComplete;

            currentPreset = preset;
            StartCoroutine(PlayCoroutine(currentPreset, from, to, isLocalPosition, _onStateChange));
        }

        public IEnumerator WaitForPlayComplete(Vector3 from, Vector3 to, Action<State> _onStateChange = null)
        {
            yield return WaitForPlayComplete(0, from, to, false, _onStateChange);
        }

        public IEnumerator WaitForPlayComplete(Vector3 to, Action<State> _onStateChange = null)
        {
            yield return WaitForPlayComplete(0, transform.position, to, false, _onStateChange);
        }

        public IEnumerator WaitForPlayComplete(int presetIndex, Vector3 from, Vector3 to, Action<State> _onStateChange = null)
        {
            yield return WaitForPlayComplete(presetIndex, from, to, false, _onStateChange);
        }

        public IEnumerator WaitForPlayComplete(int presetIndex, Vector3 to, Action<State> _onStateChange = null)
        {
            yield return WaitForPlayComplete(presetIndex, transform.position, to, false, _onStateChange);
        }

        public IEnumerator WaitForLocalPlayComplete(Vector3 from, Vector3 to, Action<State> _onStateChange = null)
        {
            yield return WaitForPlayComplete(0, from, to, true, _onStateChange);
        }

        public IEnumerator WaitForLocalPlayComplete(Vector3 to, Action<State> _onStateChange = null)
        {
            yield return WaitForPlayComplete(0, transform.localPosition, to, true, _onStateChange);
        }

        public IEnumerator WaitForLocalPlayComplete(int presetIndex, Vector3 from, Vector3 to, Action<State> _onStateChange = null)
        {
            yield return WaitForPlayComplete(presetIndex, from, to, true, _onStateChange);
        }

        public IEnumerator WaitForLocalPlayComplete(int presetIndex, Vector3 to, Action<State> _onStateChange = null)
        {
            yield return WaitForPlayComplete(presetIndex, transform.localPosition, to, true, _onStateChange);
        }

        private IEnumerator WaitForPlayComplete(int presetIndex, Vector3 from, Vector3 to, bool isLocalPosition, Action<State> _onStateChange)
        {
            bool isDone = false;

            Play(presetIndex, from, to, isLocalPosition, () => isDone = true, _onStateChange);

            while (isDone == false)
            {
                yield return null;
            }
        }

        public void Stop(bool ignoreEffectActivationReset = false)
        {
            if (isQuit)
            {
                return;
            }

            if (currentPreset == null)
            {
                return;
            }

            Stop(currentPreset, ignoreEffectActivationReset);
            currentPreset = null;

            if (onComplete != null)
            {
                onComplete.Invoke();
            }

            onComplete = null;
        }

        private void Stop(Preset preset, bool ignoreEffectActivationReset = false)
        {
            preset.movableEffect.Stop();

            StopAllCoroutines();

            if (ignoreEffectActivationReset == false)
            {
                SetEffectActive(preset.movableEffect.gameObject, false);
                SetEffectActive(preset.startEffect, false);
                SetEffectActive(preset.endEffect, false);
            }
        }

        private IEnumerator PlayCoroutine(Preset preset, Vector3 from, Vector3 to, bool isLocalPosition, Action<State> _onStateChange)
        {
            SetEffectActive(preset.movableEffect.gameObject, false);
            SetEffectActive(preset.startEffect, false);
            SetEffectActive(preset.endEffect, false);

            bool isMoveComplete = false;

            Action MoveComplete = () =>
            {
                isMoveComplete = true;
            };

            yield return new WaitForSeconds(preset.startDelay);

            DispatchStateEvent(_onStateChange, State.StartEffect);

            SetEffectActive(preset.startEffect, true);
            SetEffectPosition(preset.startEffect, from, isLocalPosition);

            yield return new WaitForSeconds(preset.moveDelay);

            if (preset.startEffectAutoDisable)
            {
                SetEffectActive(preset.startEffect, false);
            }

            DispatchStateEvent(_onStateChange, State.Move);

            SetEffectActive(preset.movableEffect.gameObject, true);
            SetEffectPosition(preset.movableEffect.gameObject, from, isLocalPosition);

            if (isLocalPosition)
            {
                preset.movableEffect.LocalMove(to, MoveComplete);
            }
            else
            {
                preset.movableEffect.Move(to, MoveComplete);
            }

            while (isMoveComplete == false)
            {
                yield return null;
            }

            if (preset.movableEffectAutoDisable)
            {
                SetEffectActive(preset.movableEffect.gameObject, false);
            }

            DispatchStateEvent(_onStateChange, State.EndEffect);

            SetEffectActive(preset.endEffect, true);
            SetEffectPosition(preset.endEffect, to, isLocalPosition);

            yield return new WaitForSeconds(preset.endDuration);

            Stop();
        }

        private void DispatchStateEvent(Action<State> action, State state)
        {
            if (action != null)
            {
                action.Invoke(state);
            }
        }

        private void SetEffectPosition(GameObject effect, Vector3 position, bool isLocalPosition)
        {
            if (effect != null)
            {
                if (isLocalPosition)
                {
                    effect.transform.localPosition = position;
                }
                else
                {
                    effect.transform.position = position;
                }
            }
        }

        private void SetEffectActive(GameObject effect, bool isOn)
        {
            if (effect != null)
            {
                effect.SetActive(isOn);
            }
        }
    }
}