using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.AddressableAssets.ResourceLocators;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.ResourceManagement.ResourceLocations;

namespace SlotKingdoms
{
    /// <summary>
    /// Addressable 에 등록된 에셋을 로드합니다. 동적으로 에셋 로드가 필요할 때, Resources.Load() 대신 이용 부탁드릅니다.
    /// </summary>
    public class AddressablesLoader : GameObjectSingleton<AddressablesLoader>
    {
        public event Action<string> OnLoadStart;
        public event Action<string> OnLoadSuccess;
        public event Action<string> OnLoadFail;

        private Dictionary<string, string> loadFailErrors;

        public IResourceLocator NewCatalogLocator
        {
            set;
            private get;
        }

        public void Initialize()
        {
            loadFailErrors = new Dictionary<string, string>();
            //Addressables.InternalIdTransformFunc = OnInternalIdTransform;
        }

        public bool ConsumeLoadFailError(string name, out string error)
        {
            bool result = loadFailErrors.TryGetValue(name, out string _error);
            if (result)
            {
                loadFailErrors.Remove(name);
            }
            error = _error;
            return result;
        }

        private string OnInternalIdTransform(IResourceLocation location)
        {
            string internalId = location.InternalId;
            Debug.Log($"OnInternalIdTransform : {internalId}");
            return internalId;
        }

        public void LoadNewCatalog(int newAddressablesVersion)
        {
            StartCoroutine(LoadCatalogCoroutine(newAddressablesVersion));
        }

        private IEnumerator LoadCatalogCoroutine(int addressablesVersion)
        {
            string catalogFileName = $"catalog_{Application.version}_{addressablesVersion}.json";
            string catalogUrl = $"{GameAddress.AddressablesRoute}/{catalogFileName}";

            Debug.Log($"LoadCatalogCoroutine 1 : {catalogUrl}");
            AsyncOperationHandle<IResourceLocator> handle = Addressables.LoadContentCatalogAsync(catalogUrl, false);
            yield return handle;
            NewCatalogLocator = handle.Result;
            Debug.Log($"LoadCatalogCoroutine 2 : {NewCatalogLocator.LocatorId}");
        }

        public IEnumerator PreloadAssetBundleCoroutine(string name, Action<float> onProgress, Action<bool> onComplete)
        {
            NotifyLoadStart(name);

            AsyncOperationHandle handle = Addressables.DownloadDependenciesAsync(name, false);
            while (handle.Status == AsyncOperationStatus.None)
            {
                onProgress?.Invoke(handle.PercentComplete);
                
                yield return null;
            }

            bool isSuccess = handle.Status == AsyncOperationStatus.Succeeded;
            if (isSuccess)
            {
                NotifyLoadSuccess(name);
            }
            else
            {
                NotifyLoadFail(name, handle.Status, handle.DebugName, handle.OperationException);
            }

            onComplete?.Invoke(isSuccess);
            //Addressables.Release(handle); //Release the operation handle
        }

        public T LoadComponent<T>(string name, bool instantiate = true) where T : MonoBehaviour
        {
            T component = null;
            
            GameObject gameObject = LoadGameObject(name, instantiate);
            if (gameObject != null)
            {
                component = gameObject.GetComponent<T>();
            }

            return component;
        }

        public IEnumerator LoadComponentCoroutine<T>(string name, bool instantiate = true, Action<float> onProgress = null, Action<T> onComplete = null) where T : MonoBehaviour
        {
            yield return LoadGameObjectCoroutine(
                name,
                instantiate,
                onProgress,
                (GameObject gameObject) =>
                {
                    if (gameObject != null)
                    {
                        T component = gameObject.GetComponent<T>();
                        onComplete(component);
                    }
                    else
                    {
                        onComplete(null);
                    }
                }
            );
        }

        public GameObject LoadGameObject(string name, bool instantiate = true) 
        {
            GameObject gameObject = null;

            AsyncOperationHandle<GameObject> handle = _LoadAssetAsync<GameObject>(name);
            handle.WaitForCompletion();

            if (handle.Status == AsyncOperationStatus.Succeeded)
            {
                gameObject = instantiate == true ?
                             Instantiate(handle.Result) :
                             handle.Result;
            }
            else
            {
                NotifyLoadFail(name, handle.Status, handle.DebugName, handle.OperationException);
            }

            //Addressables.Release(handle);
            return gameObject;
        }

        private IEnumerator LoadGameObjectCoroutine(string name, bool instantiate = true, Action<float> onProgress = null, Action<GameObject> onComplete = null)
        {
            NotifyLoadStart(name);

            AsyncOperationHandle<GameObject> handle = _LoadAssetAsync<GameObject>(name);
            while (handle.IsDone == false)
            {
                onProgress?.Invoke(handle.PercentComplete);
                //Debug.Log($"Loading progress: {handle.PercentComplete * 100}%");
                yield return null;
            }

            if (handle.Status == AsyncOperationStatus.Succeeded)
            {
                NotifyLoadSuccess(name);

                GameObject instance = instantiate == true ?
                                      Instantiate(handle.Result) :
                                      handle.Result;
                onComplete?.Invoke(instance);
            }
            else
            {
                NotifyLoadFail(name, handle.Status, handle.DebugName, handle.OperationException);

                onComplete?.Invoke(null);
            }

            //Addressables.Release(handle);
            yield break;
        }

        private AsyncOperationHandle<IList<T>> _LoadAssetsAsync<T>(string label) where T : UnityEngine.Object
        {
            IList<IResourceLocation> locations = null;
            if (NewCatalogLocator != null)
            {
                NewCatalogLocator.Locate(label, typeof(T), out locations);
            }

#if SKDEBUG
            if (locations != null)
            {
                foreach (IResourceLocation location in locations)
                {
                    LogResourceLocation(location);
                }
            }
#endif

            AsyncOperationHandle<IList<T>> handle = locations != null ?
                                                    Addressables.LoadAssetsAsync<T>(locations, null) :      
                                                    Addressables.LoadAssetsAsync<T>(label, null);
            return handle;
        }

        private AsyncOperationHandle<T> _LoadAssetAsync<T>(string name) where T : UnityEngine.Object
        {
            IResourceLocation location = null;
            if (NewCatalogLocator != null)
            {
                NewCatalogLocator.Locate(name, typeof(T), out IList<IResourceLocation> locations);
                if (locations.Count > 0)
                {
                    location = locations[0];
                }

#if SKDEBUG
                LogResourceLocation(location);
#endif
            }

            AsyncOperationHandle<T> handle = location != null ?
                                             Addressables.LoadAssetAsync<T>(location) :
                                             Addressables.LoadAssetAsync<T>(name);
            return handle;
        }

        private void LogResourceLocation(IResourceLocation location)
        {
            string assetLog = $"LoadAssetAsync : {location.PrimaryKey}, {location.ProviderId}";
            foreach (IResourceLocation _location in location.Dependencies)
            {
                assetLog += $", Depencency : {_location.PrimaryKey}, {_location.ProviderId}";
            }
            Debug.Log(assetLog);
        }

        /// <summary>
        /// 다른 메서드들과 달리 (bool instantiate) 파라미터가 없습니다.
        /// </summary>
        public T LoadAsset<T>(string name) where T : UnityEngine.Object
        {
            T asset = null;
           
            AsyncOperationHandle<T> handle = _LoadAssetAsync<T>(name);
            handle.WaitForCompletion();

            if (handle.Status == AsyncOperationStatus.Succeeded)
            {
                asset = handle.Result;
            }
            else
            {
                NotifyLoadFail(name, handle.Status, handle.DebugName, handle.OperationException);
            }

            //Addressables.Release(handle);
            return asset;
        }

        public IEnumerator LoadAssetCoroutine<T>(string name, Action<float> onProgress = null, Action<T> onComplete = null) where T : UnityEngine.Object
        {
            NotifyLoadStart(name);

            AsyncOperationHandle<T> handle = _LoadAssetAsync<T>(name);
            while (handle.IsDone == false)
            {
                //Debug.Log($"[AddressablesLoader.LoadAssetCoroutine] : {name}, {handle.PercentComplete}");
                onProgress?.Invoke(handle.PercentComplete);
                yield return null;
            }
            
            if (handle.Status == AsyncOperationStatus.Succeeded)
            {
                NotifyLoadSuccess(name);

                T asset = handle.Result;
                onComplete?.Invoke(asset);
            }
            else
            {
                NotifyLoadFail(name, handle.Status, handle.DebugName, handle.OperationException);

                onComplete?.Invoke(null);
            }

            //Addressables.Release(handle);
            yield break;
        }

        public IEnumerator LoadAssetsCoroutine<T>(string label, bool instantiate = true, Action<float> onProgress = null, Action<List<T>> onComplete = null) where T : UnityEngine.Object
        {
            NotifyLoadStart(label);

            AsyncOperationHandle<IList<T>> handle = _LoadAssetsAsync<T>(label);
            while (handle.IsDone == false)
            {
                onProgress?.Invoke(handle.PercentComplete);
                yield return null;
            }

            if (handle.Status == AsyncOperationStatus.Succeeded)
            {
                NotifyLoadSuccess(label);

                var assetList = new List<T>();
                foreach (var asset in handle.Result)
                {
                    assetList.Add(instantiate == true ?
                                  Instantiate(asset) :
                                  asset);
                }
                onComplete?.Invoke(assetList);
            }
            else
            {
                NotifyLoadFail(label, handle.Status, handle.DebugName, handle.OperationException);

                onComplete?.Invoke(null);
            }

            // 메모리 관리를 위해 로드된 에셋 해제
            //Addressables.Release(handle);
        }

        private void NotifyLoadFail(string name, AsyncOperationStatus status, string debugName, Exception exception)
        {
            Debug.LogWarning($"OnLoadFail : {name}, {status}, {debugName}, {exception}");
            loadFailErrors[name] = $"{status}: {exception}";

            OnLoadFail?.Invoke(name);
        }

        private void NotifyLoadSuccess(string name)
        {
            Debug.Log($"OnLoadSuccess : {name}");
            OnLoadSuccess?.Invoke(name);
        }

        private void NotifyLoadStart(string name)
        {
            Debug.Log($"OnLoadStart : {name}");
            OnLoadStart?.Invoke(name);
        }

    }
}