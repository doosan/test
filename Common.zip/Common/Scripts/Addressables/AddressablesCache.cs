
using SlotKingdoms.Popup;
using SlotKingdoms.UI;
using System;
using System.Collections;
using UnityEngine;

namespace SlotKingdoms
{
    public class AddressablesCache : GameObjectSingleton<AddressablesCache>
    {
        public GameObjectPool<AttackProfile> AttackProfilePoolForTown
        {
            get;
            private set;
        }
        public GameObjectPool<AttackProfile> AttackProfilePoolForAttack
        {
            get;
            private set;
        }
        public GameObjectPool<BuildEffect> BuildEffectPool
        {
            get;
            private set;
        }
        public Town StartingTownInstance
        {
            get;
            private set;
        }

        public Transform CachedTransform
        {
            get
            {
                if (cachedTransform == null)
                {
                    cachedTransform = transform;
                }
                return cachedTransform;
            }
        }
        private Transform cachedTransform;

        public IEnumerator LoadAttackProfile(Action<float> onProgress, Action onComplete, Action<string> onError)
        {
            string key = "AttackProfile";
            yield return AddressablesLoader.Instance.LoadComponentCoroutine<AttackProfile>(
                name: key,
                instantiate: false,
                onProgress: onProgress,
                onComplete: attackProfile => {
                    AttackProfilePoolForTown = new GameObjectPool<AttackProfile>(
                        root: gameObject, 
                        size: 5,
                        create: () => Instantiate(attackProfile)
                    );
                    AttackProfilePoolForAttack = new GameObjectPool<AttackProfile>(
                        root: gameObject, 
                        size: 5,
                        create: () => Instantiate(attackProfile)
                    );
                }
            );

            if (AddressablesLoader.Instance.ConsumeLoadFailError(key, out string error))
            {
                onError?.Invoke(error);
            }

            onComplete?.Invoke();
        }

        public IEnumerator LoadBuildEffect(Action<float> onProgress, Action onComplete, Action<string> onError)
        {
            string key = "BuildEffect";

            yield return AddressablesLoader.Instance.LoadComponentCoroutine<BuildEffect>(
                name: key,
                instantiate: false,
                onProgress: onProgress,
                onComplete: buildEffect => {
                    BuildEffectPool = new GameObjectPool<BuildEffect>(
                        root: gameObject, 
                        size: 5, 
                        create: () => Instantiate(buildEffect)
                    );
                }
            );

            if (AddressablesLoader.Instance.ConsumeLoadFailError(key, out string error))
            {
                onError?.Invoke(error);
            }

            onComplete?.Invoke();
        }
 
        public IEnumerator LoadTown(Action<float> onProgress, Action onComplete, Action<string> onError)
        {
            string key = $"Town{GameInfo.townInfo.stage:D3}";

            yield return AddressablesLoader.Instance.LoadComponentCoroutine<Town>(
                name: $"Town{GameInfo.townInfo.stage:D3}",
                instantiate: true,
                onProgress: onProgress,
                onComplete: town => {
                    town.transform.SetParent(CachedTransform, false);
                    StartingTownInstance = town;
                }
            );

            if (AddressablesLoader.Instance.ConsumeLoadFailError(key, out string error))
            {
                onError?.Invoke(error);
            }

            onComplete?.Invoke();
        }
    }
}
