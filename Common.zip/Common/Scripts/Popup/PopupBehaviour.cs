using UnityEngine;
using System;
using System.Collections;
using SlotKingdoms.Attribute;
using SlotKingdoms.Net;
using UnityEngine.UI;
using System.Collections.Generic;
using SlotKingdoms.UI;

namespace SlotKingdoms.Popup
{
    // [DisallowMultipleComponent]
    public class PopupBehaviour : MonoBehaviour
    {
        [SerializeField] private GameObject root = null;

        [Header("TOP UI")]
        [SerializeField] private TopUIUseType topUIUseType = TopUIUseType.None;
        [ConditionalHide("topUIUseType", (int)TopUIUseType.Use)]        
        [SerializeField] private TopUIUseInfo topUIUseInfo;

        [Header("Close Transition")]
        [SerializeField] private bool useCloseTransition = false;
        [ConditionalHide("useCloseTransition", true)]
        [SerializeField] private eTransitionType transitionType = eTransitionType.CloseTransition;
        
        public RectTransform RectTransform
        {
            get
            {
                if (cachedRectTrasnform == null)
                {
                    cachedRectTrasnform = GetComponent<RectTransform>();
                }
                return cachedRectTrasnform;
            }
        }

        private RectTransform cachedRectTrasnform;
        public Action closeDelegate;

        private bool isDone = false;
        public bool IsDone { get => isDone; set => isDone = value; }

        private bool isLoaded = false;
        public bool IsLoaded { get => isLoaded; set => isLoaded = value; }        
        public bool UseCloseTransition { get => useCloseTransition;}
        public eTransitionType TransitionType { get => transitionType; }

        private GraphicRaycaster graphicRaycaster = null;
        public GraphicRaycaster GraphicRaycaster { get => graphicRaycaster; set => graphicRaycaster = value; }
        public TopUIUseInfo TopUIUseInfo { get => topUIUseInfo; }
        public TopUIUseType TopUIUseType { get => topUIUseType; }

        public virtual IEnumerator Load()
        {
            isLoaded = true;
            yield return null;
        }

        public void SetActiveRoot(bool flag)
        {
            if(root != null) 
            {
                root.SetActive(flag);
            }
        }

        public virtual void Close()
        {
            PopupSystem.Instance.StartClosing(this);
            
            if (closeDelegate != null)
            {
                closeDelegate();
            }
            else
            {
                PopupSystem.Instance.Close(this);
            }
        }
        
        public IEnumerator WaitForClose()
        {
            isDone = false;

            while (!IsDone)
            {
                yield return null;
            }
        }

        public IEnumerator WaitForLoaded()
        {
            isLoaded = false;

            while (!isLoaded)
            {
                yield return null;
            }
        }

        public void SetInteractable(bool flag)
        {
            graphicRaycaster.enabled = flag;
        }

        public void OpenPopup(string popupName)
        {
            PopupSystem.Instance.OpenPopup(popupName);
        }
    }
}