using System;
using System.Collections;
using UnityEngine;

namespace SlotKingdoms.Popup
{
    public abstract class PreLoadingPopup : PopupBackable
    {
        [SerializeField] private CanvasGroup canvasGroup;
        [SerializeField] private GameObject root;

        protected sealed class Result
        {
            public bool isSuccess;
            public string message;
        }

        public bool IsInLoading
        {
            get;
            private set;
        }

        protected bool Interactable
        {
            set
            {
                if (canvasGroup != null)
                {
                    canvasGroup.interactable = value;
                    canvasGroup.blocksRaycasts = value;
                }
            }
        }

        private CameraDisabler cameraDisabler;
        private PopupAnimator popupAnimator;
        private bool isAnmationComplete;

        private void Awake()
        {
            SetupCameraDisabler();
            SetupPopupAnimator();

            root.SetActive(false);
        }

        private void SetupCameraDisabler()
        {
            cameraDisabler = GetComponent<CameraDisabler>();

            if (cameraDisabler != null)
            {
                cameraDisabler.onType = CameraDisabler.OnType.None;
                cameraDisabler.offType = CameraDisabler.OffType.None;
            }
        }

        private void SetupPopupAnimator()
        {
            popupAnimator = GetComponent<PopupAnimator>();

            if (popupAnimator != null)
            {
                popupAnimator.playOnEnable = false;
            }
        }

        protected override void OnEnable()
        {
            base.OnEnable();

            root.SetActive(false);
        }

        protected override void OnDisable()
        {
            base.OnDisable();

            IsInLoading = false;
        }

        public override void Close()
        {
            if (cameraDisabler != null)
            {
                cameraDisabler.Off();
            }

            base.Close();
        }

        // 팝업이 열릴 때 꼭 호출 해 줘야함.
        protected void StartLoading()
        {
            if (IsInLoading)
            {
                return;
            }

            IsInLoading = true;

            StartCoroutine(LoadingCoroutine());
        }

        private IEnumerator LoadingCoroutine()
        {
            Debug.Log("PreLoadingPopup - Start Loading");

            root.SetActive(false);
            //PopupSystem.Instance.ShowLoading();

            Result result = null;

            yield return OnLoading(r => result = r);

            Debug.Log("PreLoadingPopup - End Loading");

            //PopupSystem.Instance.HideLoading();
            
            if (result == null
                || result.isSuccess)
            {
                root.SetActive(true);
                
                if (popupAnimator != null)
                {
                    OnLoadComplete(result);

                    isAnmationComplete = false;

                    popupAnimator.onOpen.RemoveListener(OnAnimationOpenHandler);
                    popupAnimator.onOpen.AddListener(OnAnimationOpenHandler);

                    popupAnimator.Play();
                    Debug.Log("PreLoadingPopup - Start Animation : Open");

                    while (isAnmationComplete == false)
                    {
                        yield return null;
                    }

                    popupAnimator.onOpen.RemoveListener(OnAnimationOpenHandler);
                    Debug.Log("PreLoadingPopup - End Animation : Open");
                }
                else
                {
                    OnLoadComplete(result);
                }

                if (cameraDisabler != null)
                {
                    cameraDisabler.On();
                }
            }
            else
            {
                OnLoadComplete(result);
            }

            IsInLoading = false;
        }

        private void OnAnimationOpenHandler()
        {
            isAnmationComplete = true;
        }

        protected abstract IEnumerator OnLoading(Action<Result> onResult);
        protected abstract void OnLoadComplete(Result result);
    }
}
