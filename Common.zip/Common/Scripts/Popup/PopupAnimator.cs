using UnityEngine;
using System.Collections;
using UnityEngine.Events;
using System;

namespace SlotKingdoms.Popup
{
    [DisallowMultipleComponent, RequireComponent(typeof(PopupBehaviour))]
    public sealed class PopupAnimator : MonoBehaviour
    {
        private readonly string STATE_EMPTY = "";
        private readonly string STATE_OPEN = "OpenState";
        private readonly string STATE_CLOSE = "CloseState";

        private PopupBehaviour popup;

#pragma warning disable 0649
        public bool playOnEnable = true;
        [SerializeField] private Animator animator;
        [SerializeField] private float openDelayTime = 0;

        [Header("Open")]
        [SerializeField] private string openAnimation = "Open";
        [SerializeField] private string openTrigger;

        [Header("Close")]
        [SerializeField] private string closeAnimation = "Close";
        [SerializeField] private string closeTrigger = "Close";
#pragma warning restore 0649

        public Action onOpenAction = null;

        [Space]
        public UnityEvent onOpen;
        public UnityEvent onClose;
        public UnityEvent onCloseState;

        private string currentState;
        private string[] closeAnimations;

        private void Awake()
        {
            popup = GetComponent<PopupBehaviour>();

            if (animator != null)
            {
                popup.closeDelegate = OnClose;
            }

            closeAnimations = closeAnimation.Split(',');
        }

        private void OnEnable()
        {
            currentState = STATE_EMPTY;

            if (playOnEnable)
            {
                StartState(STATE_OPEN);
            }
        }

        private void OnDisable()
        {
            StopState();
        }

        private void OnClose()
        {
            if (currentState == STATE_CLOSE)
            {
                return;
            }

            if (animator != null)
            {
                StartState(STATE_CLOSE);
            }
            else
            {
                DispatchClose();
            }
        }

        public void Play()
        {
            if (currentState != STATE_EMPTY)
            {
                return;
            }

            StartState(STATE_OPEN);
        }

        private void StartState(string state)
        {
            if (currentState == state)
            {
                return;
            }

            StopState();

            currentState = state;

            if (animator != null)
            {
                StartCoroutine(state);
            }
            else
            {
                DispatchOpen();
            }
        }

        private void StopState()
        {
            currentState = STATE_EMPTY;
            StopAllCoroutines();
        }

        private IEnumerator OpenState()
        {
            if (openDelayTime > 0)
            {
                yield return new WaitForSeconds(openDelayTime);
            }
            if (string.IsNullOrEmpty(openAnimation) == true)
            {
                DispatchOpen();
                yield break;
            }

            if (string.IsNullOrEmpty(openTrigger) == false)
            {
                animator.SetTrigger(openTrigger);
                yield return new WaitForEndOfFrame();
            }

            while (IsAnimationPlay(openAnimation) == true && currentState == STATE_OPEN)
            {
                yield return null;
            }

            DispatchOpen();
        }

        private IEnumerator CloseState()
        {
            onCloseState?.Invoke();

            if (string.IsNullOrEmpty(closeAnimation) == true || string.IsNullOrEmpty(closeTrigger) == true)
            {
                DispatchClose();
                PopupSystem.Instance.Close(popup);
                yield break;
            }

            animator.SetTrigger(closeTrigger);
            yield return new WaitForEndOfFrame();

            while (IsAnimationPlay(closeAnimations) == true && currentState == STATE_CLOSE)
            {
                yield return null;
            }

            DispatchClose();
            PopupSystem.Instance.Close(popup);
        }

        private bool IsAnimationPlay(string[] animationNames)
        {
            string targetAnimName = "";

            for (int i = 0; i < animationNames.Length; i++)
            {
                var animationName = animationNames[i];

                if (animator.GetCurrentAnimatorStateInfo(0).IsName(animationName) == true)
                {
                    targetAnimName = animationName;
                    break;
                }
            }

            if (string.IsNullOrEmpty(targetAnimName) == false)
            {
                return animator.GetCurrentAnimatorStateInfo(0).normalizedTime < 1.0f;
            }

            return animator.GetNextAnimatorStateInfo(0).fullPathHash != 0;
        }

        private bool IsAnimationPlay(string animationName)
        {
            if (animator.GetCurrentAnimatorStateInfo(0).IsName(animationName) == true)
            {
                return animator.GetCurrentAnimatorStateInfo(0).normalizedTime < 1.0f;
            }
            else
            {
                return animator.GetNextAnimatorStateInfo(0).fullPathHash != 0;
            }
        }

        private void DispatchOpen()
        {
            onClose?.Invoke();
            SendMessage("OnAnimatorOpen", SendMessageOptions.DontRequireReceiver);
        }

        private void DispatchClose()
        {
            onClose?.Invoke();
            SendMessage("OnAnimatorClose", SendMessageOptions.DontRequireReceiver);
        }
    }
}