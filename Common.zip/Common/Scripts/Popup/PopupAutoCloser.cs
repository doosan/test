using UnityEngine;
using System.Collections;
using UnityEngine.Events;
using UnityEngine.Serialization;

namespace SlotKingdoms.Popup
{
    [RequireComponent(typeof(PopupBehaviour))]
    public sealed class PopupAutoCloser : MonoBehaviour
    {
        #pragma warning disable 0649
        [HideInInspector] public UnityEvent onTimesUp;

        [SerializeField, FormerlySerializedAs("autoCloseDuration")] private float duration = 10.0f;

        [SerializeField] private PopupClosingType type;
        #pragma warning restore 0649
        private PopupBehaviour popup;

        private void Awake()
        {
            popup = GetComponent<PopupBehaviour>();
        }

        private void OnEnable()
        {
            StopCoroutine("CloseCoroutine");
            StartCoroutine("CloseCoroutine");
        }

        private void OnDisable()
        {
            StopCoroutine("CloseCoroutine");
        }

        private IEnumerator CloseCoroutine()
        {
            float t = 0.0f;

            while (t < duration)
            {
                t += Time.deltaTime;
                yield return null;
            }

            yield return null;

            if (type == PopupClosingType.Self)
            {
                popup.Close();
            }
            else
            {
                onTimesUp.Invoke();
            }
        }
    }

    public enum PopupClosingType
    {
        Self, External
    }
}