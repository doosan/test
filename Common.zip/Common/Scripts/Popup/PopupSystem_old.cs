//using UnityEngine;
//using UnityEngine.UI;
//using System.Collections;
//using System.Collections.Generic;
//using DG.Tweening;
//using System;
//using System.Reflection;

//namespace SlotKingdoms.Popup
//{
//    public class PopupObject<T> where T : PopupBehaviour
//    {
//        #pragma warning disable 0649
//        private PopupSystem.PopupInfo popupInfo;

//        public PopupObject<T> OnInitialize(Action<T> onInitializeHandler)
//        {
//            MethodInfo initMethodInfo = onInitializeHandler == null ? null : onInitializeHandler.Method;
//            popupInfo.initMethodInfo = initMethodInfo;
//            object target = onInitializeHandler == null ? null : onInitializeHandler.Target;
//            popupInfo.initMethodTarget = target;
        
//            return this;
//        }

//        public PopupObject<T> OnOpen(Action onOpen)
//        {
//            popupInfo.openAction = onOpen;
//            return this;
//        }

//        public PopupObject<T> OnStartClosing(Action onStartClosing)
//        {
//            popupInfo.startClosingAction = onStartClosing;
//            return this;
//        }

//        public PopupObject<T> OnClose(Action onClose)
//        {
//            popupInfo.closeAction = onClose;
//            return this;
//        }

//        public PopupObject<T> OnError(Action onError)
//        {
//            popupInfo.errorAction = onError;
//            return this;
//        }

//        public PopupObject<T> Sequence()
//        {
//            return Sequence(int.MaxValue);
//        }

//        public PopupObject<T> Sequence(int index)
//        {
//            popupInfo.SequenceIndex = index;
//            return this;
//        }

//        public PopupObject<T> SetDelay(float delay)
//        {
//            popupInfo.delay = delay;
//            return this;
//        }

//        public PopupObject<T> SetOrder(int order)
//        {
//            popupInfo.order = order;
//            return this;
//        }

//        public PopupObject<T> SetBackgroundAlpha(float alpha, bool raycast = true)
//        {
//            popupInfo.bgAlpha = alpha;
//            popupInfo.bgRaycast = raycast;
//            return this;
//        }

//        public PopupObject<T> Cache()
//        {
//            popupInfo.useCache = true;
//            popupInfo.cacheID = popupInfo.addressableName;
//            return this;
//        }

//        public PopupObject<T> SetIgnoreCount(bool value)
//        {
//            popupInfo.ignoreCount = value;
//            return this;
//        }

//        public PopupObject<T> SetScreenMatchMode(ScreenMatchMode screenMatchMode)
//        {
//            popupInfo.screenMatchMode = screenMatchMode;
//            return this;
//        }

//        public PopupObject<T> SetLayer(string layerName)
//        {
//            popupInfo.layer = layerName;
//            return this;
//        }

//        public IEnumerator WaitForStartClosing()
//        {
//            bool idDone = false;
//            if (popupInfo.startClosingAction == null)
//            {
//                popupInfo.startClosingAction = ()=>
//                {
//                    idDone = true;
//                };
//            }
//            else
//            {
//                Action tempAction = popupInfo.startClosingAction;
//                popupInfo.startClosingAction = ()=>
//                {
//                    tempAction();
//                    idDone = true;
//                };
//            }

//            while (idDone == false)
//            {
//                yield return null;
//            }
//        }

//        public IEnumerator WaitForClose()
//        {
//            bool idDone = false;
//            if (popupInfo.closeAction == null)
//            {
//                popupInfo.closeAction = ()=>
//                {
//                    idDone = true;
//                };
//            }
//            else
//            {
//                Action tempAction = popupInfo.closeAction;
//                popupInfo.closeAction = ()=>
//                {
//                    tempAction();
//                    idDone = true;
//                };
//            }

//            while (idDone == false)
//            {
//                yield return null;
//            }
//        }

//        public T GetPopup()
//        {
//            if (popupInfo.popup.Target == null)
//            {
//                return null;
//            }
//            else
//            {
//                return popupInfo.popup.Target as T;
//            }
//        }
//    }

//    public sealed class PopupScaleMode
//    {
//        // UI Scale Mode중 constantPixelSize 만 일단 구현함.
//        public bool UseConstantPixelSize{get; private set;}
//        public float ScaleFactor{get; private set;}

//        public void Clear()
//        {
//            // Clear 호출 시 모든 값을 초기화
//            UseConstantPixelSize = false;
//        }

//        public void SetConstantPixelSize(float scaleFactor)
//        {
//            // 모드는 하나만 적용 가능하므로 설정 시 초기화 부터 
//            Clear();
            
//            UseConstantPixelSize = true;
//            ScaleFactor = scaleFactor;
//        }
//    }

//    public class PopupSystem1 : CanvasSingleton<PopupSystem>
//    {
//        public const float DEFAULT_BG_ALPHA = 0.5f;

//        public const int MAX_POPUP_COUNT = 30000;
//        private readonly int LOADING_INDICATOR_ORDER = MAX_POPUP_COUNT + 100;

//        public PopupScaleMode FixedPopupScaleMode{get; private set;}

//        internal abstract class BaseView<T> where T : MonoBehaviour
//        {
//            protected GameObjectPool<Canvas> canvasPool;
//            protected Transform parent;
//            public T Target{get; private set;}
//            protected Canvas canvas;
//            protected CanvasScaler canvasScaler;
//            protected string currentLayer;

//            public BaseView(GameObjectPool<Canvas> canvasPool, Transform parent, T target)
//            {
//                this.canvasPool = canvasPool;
//                this.parent = parent;

//                UpdateView(target);
//            }

//            public BaseView(GameObjectPool<Canvas> canvasPool, Transform parent)
//            {
//                this.canvasPool = canvasPool;
//                this.parent = parent;
//            }

//            public T GetTarget()
//            {
//                return Target;
//            }

//            public virtual void UpdateView(T value, ScreenMatchMode screenMatchMode = ScreenMatchMode.Expand, string layer = null)
//            {
//                if (Target == value || value == null)
//                {
//                    return;
//                }

//                if (Target != null)
//                {
//                    Destroy(Target);
//                }

//                Target = value;

//                if (canvas == null)
//                {
//                    canvas = CreateCanvas(screenMatchMode);
//                }
                
//                UpdateCanvas();
//                UdpateLayer(layer);

//                Target.transform.SetParent(canvas.transform, false);
//                Target.transform.localPosition = Vector3.zero;
//                Target.transform.localScale = Vector3.one;
//                Target.gameObject.SetActive(true);
//            }

//            protected virtual Canvas CreateCanvas(ScreenMatchMode screenMatchMode)
//            {
//                Canvas newCanvas = canvasPool.Get();
//                canvasScaler = newCanvas.GetComponent<CanvasScaler>();
//                if (canvasScaler != null)
//                {
//                    if (PopupSystem.Instance.FixedPopupScaleMode.UseConstantPixelSize)
//                    {
//                        canvasScaler.uiScaleMode = CanvasScaler.ScaleMode.ConstantPixelSize;
//                        canvasScaler.scaleFactor = PopupSystem.Instance.FixedPopupScaleMode.ScaleFactor;
//                    }
//                    else
//                    {
//                        canvasScaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;

//                        if (screenMatchMode == ScreenMatchMode.Expand)
//                        {
//                            canvasScaler.screenMatchMode = CanvasScaler.ScreenMatchMode.Expand;
//                        }
//                        else
//                        {
//                            canvasScaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;

//                            if (screenMatchMode == ScreenMatchMode.Width)
//                            {
//                                canvasScaler.matchWidthOrHeight = 0;
//                            }
//                            else
//                            {
//                                canvasScaler.matchWidthOrHeight = 1;
//                            }
//                        }
//                    }
//                }

//                newCanvas.transform.SetParent(parent, false);
//                return newCanvas;
//            }

//            protected virtual void UpdateCanvas()
//            {
//                canvas.name = Target.name.Replace("(Clone)", "");
//            }

//            public virtual void UdpateLayer(string layer)
//            {
//                if (string.IsNullOrEmpty(layer))
//                {
//                    layer = PopupSystem.Instance.DefaultLayer;
//                }

//                if (string.Equals(layer, currentLayer))
//                {
//                    return;
//                }

//                currentLayer = layer;

//                if (string.Equals(layer, PopupSystem.Instance.DefaultLayer))
//                {
//                    canvas.worldCamera = PopupSystem.Instance.Camera;
//                    canvas.gameObject.layer = LayerMask.NameToLayer(PopupSystem.Instance.DefaultLayer);
//                }
//                else
//                {
//                    var cameras = GameObject.FindObjectsOfType<Camera>();
//                    int layerInt = LayerMask.NameToLayer(layer);

//                    for (int i = 0; i < cameras.Length; i++)
//                    {
//                        var cam = cameras[i];

//                        if ((cam.cullingMask & (1 << layerInt)) != 0)
//                        {
//                            canvas.worldCamera = cam;
//                            break;
//                        }
//                    }

//                    canvas.gameObject.layer = layerInt;
//                }
//            }

//            public void SetAsLastSibling()
//            {
//                canvas.transform.SetAsLastSibling();
//            }

//            public void SetAsFirstSibling()
//            {
//                canvas.transform.SetAsFirstSibling();
//            }

//            public void SetSortingOrder(int order)
//            {
//                canvas.sortingOrder = order;
//            }

//            public int GetSortingOrder()
//            {
//                return canvas.sortingOrder;
//            }

//            public void Release(bool destoryTarget)
//            {
//                if (destoryTarget)
//                {
//                    Destroy(Target.gameObject);
//                    Target = null;
//                }

//                canvas.name = "Canvas";
//                canvasPool.Return(canvas);
//                canvasPool = null;
//                canvas = null;
//                parent = null;
//            }

//            public void SetActive(bool isOn)
//            {
//                canvas.gameObject.SetActive(isOn);
//            }

//            public bool IsValid()
//            {
//                return Target != null && canvasPool != null && parent != null && canvas != null;
//            }
//        }

//        internal class PopupView : BaseView<PopupBehaviour>
//        {
//            public PopupView(GameObjectPool<Canvas> canvasPool, Transform parent ) : base(canvasPool, parent){}
//            public PopupView(GameObjectPool<Canvas> canvasPool, Transform parent, PopupBehaviour target) : base(canvasPool, parent, target){} 

//            protected override void UpdateCanvas()
//            {
//                base.UpdateCanvas();
//                Vector2 refResolution = canvasScaler.referenceResolution;

//                var longerSide = Mathf.Max(canvasScaler.referenceResolution.x, canvasScaler.referenceResolution.y);
//                var shorterSide = Mathf.Min(canvasScaler.referenceResolution.x, canvasScaler.referenceResolution.y);

//                if (Target.orientation == PopupOrientationType.PortraitOnly)
//                {
//                    canvasScaler.referenceResolution = new Vector2(shorterSide, longerSide);
//                }
//                else
//                {
//                    canvasScaler.referenceResolution = new Vector2(longerSide, shorterSide);
//                }
//            }
//        }

//        internal class LoadingIndicatorView : BaseView<BaseLoadingIndicator>
//        {
//            public LoadingIndicatorView(GameObjectPool<Canvas> canvasPool, Transform parent ) : base(canvasPool, parent){}
//            public LoadingIndicatorView(GameObjectPool<Canvas> canvasPool, Transform parent, BaseLoadingIndicator target) : base(canvasPool, parent, target){}
//        }

//        internal class BackgroundView : BaseView<Image>
//        {
//            public BackgroundView(GameObjectPool<Canvas> canvasPool, Transform parent ) : base(canvasPool, parent){}
//            public BackgroundView(GameObjectPool<Canvas> canvasPool, Transform parent, Image target) : base(canvasPool, parent, target){}
//        }

//        internal class PopupInfo
//        {
//            public PopupSystem manager;
//            public string addressableName;
//            public bool unloadAssetBundleOnClose;

//            public string cacheID;
//            public PopupView popup;
//            public int order;
//            public float bgAlpha = DEFAULT_BG_ALPHA;
//            public bool bgRaycast = true;
//            public bool useAsync;
//            public bool useCache;
//            public object initMethodTarget;
//            public bool ignoreCount = false;
//            public MethodInfo initMethodInfo;
//            public Action openAction;
//            public Action closeAction;
//            public Action startClosingAction;
//            public Action errorAction;
//            public string layer;
//            public float delay;
//            public bool UseSequence { get { return sequenceIndex > -1; } }
//            private int sequenceIndex;
//            public ScreenMatchMode screenMatchMode = ScreenMatchMode.Expand;
//            public int SequenceIndex
//            {
//                get
//                {
//                    return sequenceIndex;
//                }
//                set
//                {
//                    sequenceIndex = value;
//                    if (UseSequence == true)
//                    {
//                        if (sequenceIndex >= manager.GetSequceCount())
//                        {
//                            manager.AddSequence(this);
//                        }
//                        else
//                        {
//                            manager.AddSequence(this, sequenceIndex);
//                        }
//                    }
//                }
//            }

//            public PopupInfo(PopupSystem manager, string addressableName)
//            {
//                this.manager = manager;
//                this.addressableName = addressableName;
//                sequenceIndex = -1;

//                popup = new PopupView(manager.canvasPool, manager.root);
//            }
//        }

//        public delegate void PopupCountDelegate(int count);
//        public PopupCountDelegate onCountChanged;
//        public Action<PopupBehaviour> onPopupOpen;
//        public Action<PopupBehaviour> onPopupStartClosing;
//        public Action<PopupBehaviour> onPopupClose;
//        public Action onSequeneceAllComplete;

//        private string popupLayerName;
//        private RectTransform cachedRoot;
//        private RectTransform canvasPoolRoot;
//        private int popupCount;
//        private Queue<PopupInfo> popupLoadBuffer;
//        private List<PopupInfo> popupInfoList;
//        private List<PopupInfo> sequencePopupInfoList;
//        private PopupInfo currentSequencePopupInfo;
//        private Dictionary<string, PopupBehaviour> cachedPopupInfoDic;
//        private BackgroundView backgroundView;
//        private bool isBackgroundPanelOn;

//        private GameObjectPool<Canvas> canvasPool;
        
//        public float backgroundShowDuration = 0.2f;
//        public float backgroundHideDuration = 0.2f;
//        public bool clearResourceOnClose = false;

//        // public BaseLoadingIndicator LoadingIndicator{get; private set;}
//        private LoadingIndicatorView loadingIndicator;

//        protected override void OnInitialize(string popupLayerName, int resolutionWidth, int resolutionHeight, ScreenMatchMode match, int pixelsPerUnit, int depth)
//        {
//            this.popupLayerName = popupLayerName;

//            popupInfoList = new List<PopupInfo>();
//            cachedPopupInfoDic = new Dictionary<string, PopupBehaviour>();
//            sequencePopupInfoList = new List<PopupInfo>();
//            popupLoadBuffer = new Queue<PopupInfo>();
//            FixedPopupScaleMode = new PopupScaleMode();

//            SetupCanvasPoolRoot();

//            base.OnInitialize(popupLayerName, resolutionWidth, resolutionHeight, match, pixelsPerUnit, depth);

//            SetupBackgroundPanel();
//            SetupCachedRoot();
//            SetupLoadingIndicator();

//            Clear();
//        }

//        protected override void SetupRenderes(string popupLayerName, 
//                                             int resolutionWidth, 
//                                             int resolutionHeight, 
//                                             ScreenMatchMode match, 
//                                             int pixelsPerUnit, 
//                                             int depth)
//        {
//            base.SetupRenderes(popupLayerName, resolutionWidth, resolutionHeight, match, pixelsPerUnit, depth);

//            Destroy(root.GetComponent<GraphicRaycaster>());
//            Destroy(root.GetComponent<CanvasScaler>());
//            Destroy(root.GetComponent<Canvas>());

//            root.transform.localScale = Vector3.one;

//            canvasPool = new GameObjectPool<Canvas>(canvasPoolRoot.gameObject
//                                                    ,3
//                                                    ,()=>
//                                                    {
//                                                        var go = new GameObject("Canvas");
//                                                        return CreateCanvas(go
//                                                                            ,popupLayerName
//                                                                            ,resolutionWidth
//                                                                            ,resolutionHeight
//                                                                            ,match
//                                                                            ,pixelsPerUnit);
//                                                    });
//        }

//        private void SetupBackgroundPanel()
//        {
//            RectTransform newPanel = new GameObject("BackgroundPanel").AddComponent<RectTransform>();
//            newPanel.anchorMin = new Vector2(0, 0);
//            newPanel.anchorMax = new Vector2(1, 1);
//            newPanel.anchoredPosition = Vector2.zero;
//            newPanel.sizeDelta = Vector2.zero;
            
//            var backgroundImage = newPanel.gameObject.AddComponent<Image>();
//            backgroundImage.color = new Color(0, 0, 0, 0);
//            backgroundImage.gameObject.SetActive(false);
//            backgroundImage.gameObject.layer = LayerMask.NameToLayer(popupLayerName);

//            backgroundView = new BackgroundView(canvasPool, root, backgroundImage);
//        }

//        private void SetupCachedRoot()
//        {
//            cachedRoot = new GameObject("CachedRoot").AddComponent<RectTransform>();
//            cachedRoot.SetParent(transform, false);
//            cachedRoot.SetAsFirstSibling();
//            cachedRoot.gameObject.SetActive(false);
//        }

//        private void SetupCanvasPoolRoot()
//        {
//            canvasPoolRoot = new GameObject("CanvasPool").AddComponent<RectTransform>();
//            canvasPoolRoot.SetParent(transform, false);
//            canvasPoolRoot.SetAsFirstSibling();
//            canvasPoolRoot.gameObject.SetActive(false);
//        }

//        private void SetupLoadingIndicator()
//        {
//            loadingIndicator = new LoadingIndicatorView(canvasPool, root);
//        }

//        private void OnEnable()
//        {
//            StartLoadPopups();
//        }

//        private void StartLoadPopups()
//        {
//            StopLoadPopups();
//            StartCoroutine(LoadPopups());
//        }

//        private void StopLoadPopups()
//        {
//            StopAllCoroutines();
//        }

//        private PopupObject<T> CreatePopupObject<T>(PopupInfo info) where T : PopupBehaviour
//        {
//            PopupObject<T> popupObject = new PopupObject<T>();
//            popupObject.GetType()
//                       .GetField("popupInfo", BindingFlags.NonPublic | BindingFlags.Instance)
//                       .SetValue(popupObject, info);

//            return popupObject;
//        }

//        public PopupObject<T> Open<T>(string addressableName) where T : PopupBehaviour
//        {
//            PopupInfo popupInfo = new PopupInfo(this, addressableName);
//            return Open<T>(popupInfo);
//        }

//        private PopupObject<T> Open<T>(PopupInfo info) where T : PopupBehaviour
//        {
//            if (popupInfoList.Count >= MAX_POPUP_COUNT)
//            {
//                Debug.Log("PopupSymstem - Popup is full.");
//                return null;
//            }

//            PopupObject<T> popupObject = CreatePopupObject<T>(info);
//            popupLoadBuffer.Enqueue(info);

//            Debug.Log("PopupSystem - Ready : " + info.addressableName);

//            return popupObject;
//        }

//        public void StartClosing(PopupBehaviour popup)
//        {
//            PopupInfo info = GetPopupInfo(popup);

//            if (info != null)
//            {
//                Debug.Log("PopupSystem - Start Closing : " + info.addressableName);
//                DispatchPopupStartClosing(info);
//            }
//        }

//        public void Close(PopupBehaviour popup)
//        {
//            Close(popup, false, true);
//        }

//        private void Close(PopupBehaviour popup, bool ignoreCloseAction, bool updateBackgroundPanel)
//        {
//            PopupInfo info = GetPopupInfo(popup);

//            if (info != null)
//            {
//                Debug.Log("PopupSystem - Close : " + info.addressableName);

//                if (info == currentSequencePopupInf61o)
//                {
//                    SequencePopupClosed();
//                }

//                if (ignoreCloseAction == false)
//                {
//                    DispatchPopupClose(info);
//                }

//                if (info.useCache)
//                {
//                    if (ReturnCachedPopup(info.cacheID) == false)
//                    {
//                        info.popup.Release(true);
//                    }
//                }
//                else
//                {
//                    info.popup.Release(true);
//                }

//                popupInfoList.Remove(info);
//                UpdateCount();
//            }
//            else
//            {
//                Destroy(popup.gameObject);
//            }

//            if (clearResourceOnClose)
//            {
//                UnloadUnusedAssets();
//            }

//            if (updateBackgroundPanel)
//            {
//                UpdateBackgroundPanel();
//            }
//        }

//        internal void UnregisterAll(bool ignoreCloseAction = true)
//        {
//            while (popupInfoList.Count > 0)
//            {
//                var info = popupInfoList[0];

//                if (ignoreCloseAction == false)
//                {
//                    DispatchPopupStartClosing(info);
//                }

//                Close(info.popup.Target, ignoreCloseAction, false);
//            }

//            UpdateCount();
//            UpdateBackgroundPanel();
//        }

//        private void SequencePopupClosed()
//        {
//            currentSequencePopupInfo = null;
            
//            if (GetSequceCount() == 0 )
//            {
//                if (onSequeneceAllComplete != null)
//                {
//                    onSequeneceAllComplete();
//                }
//            }
//        }

//        public void Clear(bool clearSequence = true, bool ignoreCloseAction = true)
//        {
//            if (popupInfoList == null)
//            {
//                return;
//            }

//            HideLoading();

//            if (clearSequence)
//            {
//                ClearSequence();
//            }

//            popupLoadBuffer.Clear();
//            UnregisterAll(ignoreCloseAction);

//            if (clearResourceOnClose)
//            {
//                UnloadUnusedAssets();
//            }

//            UpdateBackgroundPanel();
//            StopLoadPopups();
//            StartLoadPopups();
//        }

//        private IEnumerator LoadPopups()
//        {
//            while (true)
//            {
//                if (popupLoadBuffer != null && popupLoadBuffer.Count > 0)
//                {
//                    PopupInfo currentInfo = popupLoadBuffer.Dequeue();

//                    // Debug.Log("PopupSystem - Open : " + currentInfo.assetBundleObject);

//                    if (currentInfo.UseSequence)
//                    {
//                        if (IsNextSequence(currentSequencePopupInfo, currentInfo) == true)
//                        {
//                            currentSequencePopupInfo = currentInfo;
//                            RemoveSequence(currentSequencePopupInfo);
//                        }
//                        else
//                        {
//                            popupLoadBuffer.Enqueue(currentInfo);
//                            yield return null;
//                            continue;
//                        }
//                    }

//                    int popupIndex = CalcPopupOrderToIndex(currentInfo.order, popupInfoList);
//                    if (popupIndex >= popupInfoList.Count)
//                    {
//                        popupInfoList.Add(currentInfo);
//                    }
//                    else
//                    {
//                        popupInfoList.Insert(popupIndex, currentInfo);
//                    }

//                    UpdateCount();

//                    if (currentInfo.delay > 0.0f)
//                    {
//                        UpdateBackgroundPanel(true);
//                        yield return new WaitForSeconds(currentInfo.delay);
//                    }
//                    else
//                    {
//                        UpdateBackgroundPanel();
//                    }

//                    PopupBehaviour popup = null;

//                    if (ContainsCachedPopup(currentInfo.cacheID))
//                    {
//                        if (IsCachedPopupOpen(currentInfo.cacheID))
//                        {
//                            var cachedPopup = GetCachedPopup(currentInfo.cacheID);
//                            if (cachedPopup != null)
//                            {
//                                Close(cachedPopup);
//                            }
//                        }

//                        popup = GetCachedPopup(currentInfo.cacheID);
//                    }
//                    else
//                    {
//                        if (currentInfo.popup.Target == null)
//                        {
//                            ShowLoading();

//                            if (string.IsNullOrEmpty(currentInfo.addressableName) == false)
//                            {
//                                yield return LoadPopupFromAddressable(
//                                    currentInfo,
//                                    (PopupBehaviour popupBehaviour) =>
//                                    {
//                                        popup = popupBehaviour;
//                                    }
//                                );
//                            }
//                            else
//                            {
//                                Debug.LogError($"AddressableName 의 값이 비어 있습니다.");
//                            }

//                            HideLoading();

//                            if (currentInfo.useCache && popup != null)
//                            {
//                                AddCachedPopup(currentInfo.cacheID, popup);
//                            }
//                        }       
//                        else
//                        {
//                            popup = currentInfo.popup.Target;
//                        }                 
//                    }

//                    if (popup != null)
//                    {
//                        currentInfo.popup.UpdateView(popup, currentInfo.screenMatchMode, currentInfo.layer);
//                        DispatchPopupInitialize(currentInfo);
//                        yield return null;

//                        SortPopupOrder();
//                        UpdateBackgroundPanel();

//                        while (!currentInfo.popup.Target.gameObject.activeInHierarchy)
//                        {
//                            yield return null;
//                        }

//                        DispatchPopupOpen(currentInfo);
//                    }
//                    else
//                    {
//                        popupInfoList.Remove(currentInfo);
//                        UpdateCount();
//                        UpdateBackgroundPanel();

//                        if (currentInfo.errorAction != null)
//                        {
//                            currentInfo.errorAction();
//                        }

//                        if (currentInfo.startClosingAction != null)
//                        {
//                            currentInfo.startClosingAction();
//                        }

//                        if (currentInfo.closeAction != null)
//                        {
//                            currentInfo.closeAction();
//                        }
//                    }
//                }
//                else
//                {
//                    yield return null;
//                }
//            }
//        }

//        public void PopupOpen<T>(Action<T> onInitialize = null) where T : PopupBehaviour
//        {
//            GameObject obj = AddressablesLoader.Instance.LoadAsset<GameObject>(typeof(T).Name);
//            if (obj != null)
//            {
//                PopupBehaviour popup = Instantiate(obj).GetComponent<T>();
//            }

//        }

//        private IEnumerator LoadPopupFromAddressable(PopupInfo info, Action<PopupBehaviour> onLoadComplete)
//        {
//            PopupBehaviour popup = null;
//            GameObject popupObject = null;

//            yield return AddressablesLoader.Instance.LoadGameObjectCoroutine(
//                name: info.addressableName,
//                instantiate: false,
//                onCompleteAsync: (GameObject _popupObject) =>
//                {
//                    popupObject = _popupObject;
//                }
//            );

//            if (popupObject != null)
//            {
//                // 아직 활성화되지 않은 팝업의 OnEnable이 먼저 호출되는 문제를 막기 위함.
//                bool originActive = popupObject.activeSelf;
//                popupObject.SetActive(false);
//                popup = Instantiate(popupObject).GetComponent<PopupBehaviour>();
//                popupObject.SetActive(originActive);
//            }

//            onLoadComplete(popup);
//        }

//        private void DispatchPopupOpen(PopupInfo info)
//        {
//            if (info.openAction != null)
//            {
//                info.openAction();
//            }

//            if (onPopupOpen != null)
//            {
//                onPopupOpen.Invoke(info.popup.Target);
//            }
//        }

//        private void DispatchPopupStartClosing(PopupInfo info)
//        {
//            if (info.startClosingAction != null)
//            {
//                info.startClosingAction();
//            }

//            if (onPopupStartClosing != null)
//            {
//                onPopupStartClosing.Invoke(info.popup.Target);
//            }
//        }

//        private void DispatchPopupClose(PopupInfo info)
//        {
//            if (info.closeAction != null)
//            {
//                info.closeAction();
//            }

//            if (onPopupClose != null)
//            {
//                onPopupClose.Invoke(info.popup.Target);
//            }
//        }

//        private void DispatchPopupInitialize(PopupInfo info)
//        {
//            if (info.initMethodInfo != null)
//            {
//                info.initMethodInfo.Invoke(info.initMethodTarget, new object[] { info.popup.Target });
//            }
//        }

//        private void SortPopupOrder()
//        {
//            for (int i = 0; i < popupInfoList.Count; i++)
//            {
//                PopupInfo info = popupInfoList[i];

//                if (info.popup.IsValid())
//                {
//                    info.popup.SetSortingOrder(i);
//                }
//            }
//        }

//        private void UpdateBackgroundPanel(bool forceClearBackgroundAlpha = false)
//        {
//            if (popupInfoList.Count == 0)
//            {
//                if (sequencePopupInfoList.Count == 0)
//                {
//                    HideBackgroundPanel();
//                }

//                return;
//            }

//            float targetAlpha = 0.0f;
//            bool targetRaycast = true;
//            string targetLayer = null;

//            if (forceClearBackgroundAlpha == false && popupInfoList.Count > 0)
//            {
//                var targetInfo = popupInfoList[popupInfoList.Count - 1];
//                targetAlpha = targetInfo.bgAlpha;
//                targetRaycast = targetInfo.bgRaycast;
//                targetLayer = targetInfo.layer;
//            }

//            if (popupInfoList.Count == 1 && isBackgroundPanelOn)
//            {
//                ShowBackgroundPanel(targetAlpha, targetRaycast, targetLayer);
//                backgroundView.SetSortingOrder(-1);
//                backgroundView.SetAsFirstSibling();
//                LoadingAsLastSibling();
//                return;
//            }
//            else
//            {
//                ShowBackgroundPanel(targetAlpha, targetRaycast, targetLayer);
//            }

//            PopupInfo lastInfo = popupInfoList[popupInfoList.Count - 1];
//            backgroundView.SetAsLastSibling();

//            if (lastInfo.popup.IsValid())
//            {
//                var targetPopupOrder = lastInfo.popup.GetSortingOrder();

//                backgroundView.SetSortingOrder(targetPopupOrder);
//                lastInfo.popup.SetSortingOrder(targetPopupOrder + 1);
//                lastInfo.popup.SetAsLastSibling();
//            }

//            LoadingAsLastSibling();
//        }

//        private void ShowBackgroundPanel(float alpha, bool raycasat = true, string layer = null)
//        {
//            if (backgroundView.IsValid() == false) 
//            {
//                return;
//            }

//            isBackgroundPanelOn = true;
//            backgroundView.SetActive(true);
//            backgroundView.Target.raycastTarget = raycasat;
//            backgroundView.UdpateLayer(layer);

//            if (alpha == backgroundView.Target.color.a)
//            {
//                return;
//            }

//            backgroundView.Target.DOKill();

//            if (backgroundShowDuration > 0.0f)
//            {
//                backgroundView.Target.DOFade(alpha, backgroundShowDuration);
//            }
//            else
//            {
//                var tempColor = backgroundView.Target.color;
//                tempColor.a = alpha;
//                backgroundView.Target.color = tempColor;
//            }
//        }

//        private void HideBackgroundPanel()
//        {
//            if (backgroundView.IsValid() == false) 
//            {
//                return;
//            }

//            isBackgroundPanelOn = false;
//            backgroundView.Target.DOKill();

//            if (backgroundHideDuration > 0.0f)
//            {
//                backgroundView.Target.DOFade(0, backgroundHideDuration).OnComplete(() => { if (backgroundView.IsValid()) backgroundView.SetActive(false); });
//            }
//            else
//            {
//                var tempColor = backgroundView.Target.color;
//                tempColor.a = 0;
//                backgroundView.Target.color = tempColor;

//                if (backgroundView.IsValid())
//                {
//                    backgroundView.SetActive(false);
//                }
//            }
//        }

//        public int Count
//        {
//            get
//            {
//                return popupCount;
//            }
//            private set
//            {
//                if (popupCount == value)
//                {
//                    return;
//                }
//                popupCount = value;
//            }
//        }

//        private void UpdateCount()
//        {
//            var count = 0;
//            foreach (var info in popupInfoList)
//            {
//                if (info.ignoreCount == false)
//                {
//                    count++;
//                }
//            }

//            Count = count;

//            if (onCountChanged != null)
//            {
//                onCountChanged(Count);
//            }
//        }

//        private int CalcPopupOrderToIndex(int order, List<PopupInfo> infoList)
//        {
//            int orderIndex = infoList.Count;

//            for (int i = 0; i < infoList.Count; i++)
//            {
//                PopupInfo info = infoList[i];

//                if (order < info.order)
//                {
//                    orderIndex = i;
//                    break;
//                }
//            }

//            return orderIndex;
//        }

//        private PopupInfo GetPopupInfo(PopupBehaviour popup)
//        {
//            for (int i = 0; i < popupInfoList.Count; i++)
//            {
//                PopupInfo info = popupInfoList[i];

//                if (info.popup.Target == popup)
//                {
//                    return info;
//                }
//            }

//            return null;
//        }

//        private void AddSequence(PopupInfo info, int index)
//        {
//            sequencePopupInfoList.Insert(index, info);
//        }

//        private void AddSequence(PopupInfo info)
//        {
//            sequencePopupInfoList.Add(info);
//        }

//        private void RemoveSequence(PopupInfo info)
//        {
//            sequencePopupInfoList.Remove(info);
//        }

//        private bool IsNextSequence(PopupInfo currentSequenceInfo, PopupInfo targetInfo)
//        {
//            var targetSequencePopupInfo = GetSequceCount() > 0 ? sequencePopupInfoList[0] : null;
//            return currentSequenceInfo == null && targetSequencePopupInfo == targetInfo;
//        }

//        public int GetSequceCount()
//        {
//            return sequencePopupInfoList.Count;
//        }

//        public void ClearSequence()
//        {
//            currentSequencePopupInfo = null;

//            if (sequencePopupInfoList != null)
//            {
//                sequencePopupInfoList.Clear();
//            }
//        }

//        public bool IsCachedPopupOpen(string gameObjectName)
//        {
//            if (ContainsCachedPopup(gameObjectName))
//            {
//                for (int i = 0; i < popupInfoList.Count; i++)
//                {
//                    var tempInfo = popupInfoList[i];
//                    if (tempInfo.popup.Target != null && tempInfo.cacheID == gameObjectName)
//                    {
//                        return true;
//                    }
//                }
//            }

//            return false;
//        }

//        private void AddCachedPopup(string id, PopupBehaviour popup)
//        {
//            if (ContainsCachedPopup(id) == true)
//            {
//                return;
//            }

//            cachedPopupInfoDic.Add(id, popup);
//            ReturnCachedPopup(id);
//        }

//        public void AddCachedPopup<T>(string addressableName, Action<bool> onComplete = null) where T : PopupBehaviour
//        {
//            PopupInfo popupInfo = new PopupInfo(this, addressableName);
//            popupInfo.useAsync = false;
//            AddCachedPopup<T>(popupInfo, onComplete);
//        }

//        public void AddCachedPopupAsync<T>(string addressableName, Action<bool> onComplete = null) where T : PopupBehaviour
//        {
//            PopupInfo popupInfo = new PopupInfo(this, addressableName);
//            popupInfo.useAsync = true;
//            AddCachedPopup<T>(popupInfo, onComplete);
//        }

//        private void AddCachedPopup<T>(PopupInfo info, Action<bool> onComplete) where T : PopupBehaviour
//        {
//            string id = null;

//            if (string.IsNullOrEmpty(info.addressableName) == false)
//            {
//                id = info.addressableName;
//            }
//            else
//            {
//                if (onComplete != null)
//                {
//                    onComplete(false);
//                }

//                return;
//            }

//            if (ContainsCachedPopup(id) == true)
//            {
//                if (onComplete != null)
//                {
//                    onComplete(true);
//                }
                
//                return;
//            }

//            info.useCache = true;
//            info.cacheID = id;

//            PopupBehaviour popup = null;
//            if (string.IsNullOrEmpty(info.addressableName) == false)
//            {
//                StartCoroutine(LoadPopupFromAddressable(
//                    info, 
//                    onLoadComplete: (PopupBehaviour _popup) =>
//                    {
//                        popup = _popup;

//                        if (popup != null)
//                        {
//                            AddCachedPopup(info.cacheID, popup);
//                        }

//                        if (onComplete != null)
//                        {
//                            onComplete(popup != null);
//                        }
//                    }
//                ));
//            }
//            else
//            {
//                Debug.LogError("AddressableName 의 값이 비어 있습니다.");
//            }
//        }

//        public void RemoveCachedPopup(string gameObjectName)
//        {
//            if (ContainsCachedPopup(gameObjectName) == false)
//            {
//                return;
//            }
//            if (IsCachedPopupOpen(gameObjectName) == false)
//            {
//                var cachedPopup = GetCachedPopup(gameObjectName);
//                Destroy(cachedPopup.gameObject);
//            }

//            cachedPopupInfoDic.Remove(gameObjectName);
//        }

//        public void RemoveAllCachedPopups()
//        {
//            foreach (var item in cachedPopupInfoDic)
//            {
//                string id = item.Key;
//                if (IsCachedPopupOpen(id) == false)
//                {
//                    var cachedPopup = GetCachedPopup(id);
//                    Destroy(cachedPopup.gameObject);
//                }
//            }
//            cachedPopupInfoDic.Clear();
//        }

//        public bool ContainsCachedPopup(string id)
//        {
//            return string.IsNullOrEmpty(id) ? false : cachedPopupInfoDic.ContainsKey(id);
//        }

//        private PopupBehaviour GetCachedPopup(string id)
//        {
//            return ContainsCachedPopup(id) ? cachedPopupInfoDic[id] : null;
//        }

//        private bool ReturnCachedPopup(string id)
//        {
//            if (ContainsCachedPopup(id))
//            {
//                PopupBehaviour popup = GetCachedPopup(id);
//                var info = GetPopupInfo(popup);
                
//                if (info != null)
//                {
//                    info.popup.Release(false);
//                }

//                popup.transform.SetParent(cachedRoot, false);

//                return true;
//            }

//            return false;
//        }

//        public bool IsOpen<T>() where T : PopupBehaviour
//        {
//            for (int i = 0; i < popupInfoList.Count; i++)
//            {
//                var info = popupInfoList[i];
//                if (info.popup.Target is T)
//                {
//                    return true;
//                }
//            }

//            return false;
//        }

//        public bool IsOpen(string name)
//        {
//            for (int i = 0; i < popupInfoList.Count; i++)
//            {
//                var info = popupInfoList[i];
//                if (info.addressableName == name)
//                {
//                    return true;
//                }
//            }

//            return false;
//        }

//        public bool IsPeek<T>() where T : PopupBehaviour
//        {
//            bool result = false;
//            if (popupInfoList.Count >= 1)
//            {
//                PopupView frontPopup = popupInfoList[popupInfoList.Count - 1].popup;
//                // 첫 번째 팝업이 타겟 팝업이거나
//                if (frontPopup.Target != null
//                    && frontPopup.Target is T)
//                {
//                    //Debug.Log("frontPopup : " + typeof(T) + " vs " + frontPopup.Target);
//                    result = true;
//                }

//                if (popupInfoList.Count >= 2)
//                {
//                    PopupView secondPopup = popupInfoList[popupInfoList.Count - 2].popup;

//                    // 첫 번째 팝업이 아직 로드되지 않은 상태에서
//                    // 두 번째 팝업이 타겟 팝업이면
//                    if ((frontPopup.Target == null || frontPopup.Target.gameObject.activeInHierarchy == false)
//                        && secondPopup.Target is T)
//                    {
//                        //Debug.Log("secondPopup : " + typeof(T) + " vs " + secondPopup.Target);
//                        result = true;
//                    }
//                }
//            }
//            return result;
//        }

//        private void UnloadUnusedAssets()
//        {
//            Resources.UnloadUnusedAssets();
//            GC.Collect();
//            Debug.Log("!!!! GC.Collect() !!!!");
//        }

//        public void SetIndicator(BaseLoadingIndicator obj)
//        {
//            loadingIndicator.UpdateView(obj);
//            loadingIndicator.Target.gameObject.SetActive(false);
//        }

//        public void ShowLoading(bool blocksRaycasts = true)
//        {
//            if (loadingIndicator.IsValid() == false)
//            {
//                return;
//            }

//            loadingIndicator.SetActive(true);
//            loadingIndicator.Target.Show(blocksRaycasts);
//        }

//        public void HideLoading()
//        {
//            if (loadingIndicator.IsValid() == false)
//            {
//                return;
//            }

//            loadingIndicator.Target.Hide(()=>
//            {
//                loadingIndicator.SetActive(false);
//            });
//        }

//        private void LoadingAsLastSibling()
//        {
//            if (loadingIndicator.IsValid() == false)
//            {
//                return;
//            }

//            loadingIndicator.SetSortingOrder(LOADING_INDICATOR_ORDER);
//            loadingIndicator.Target.transform.SetAsLastSibling();
//        }

//        public bool IsLoading()
//        {
//            return loadingIndicator.Target != null && loadingIndicator.Target.IsActive;
//        }

//        public void BackgroundHideImmediate()
//        {
//            backgroundView.SetActive(false);
//        }
//    }
//}