using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace SlotKingdoms.Popup
{
    [RequireComponent(typeof(PopupBehaviour)), DisallowMultipleComponent]
    public sealed class CameraDisabler : MonoBehaviour 
    {
        private static int useCount = 0;

        public enum OnType
        {
            None,
            Awake,
            Start,
            OnEnable
        }

        public enum OffType
        {
            None,
            OnDisable
        }

        public LayerMask targetLayers;
        public OnType onType = OnType.OnEnable;
        public OffType offType = OffType.OnDisable;
        #pragma warning disable 0649
        [SerializeField] private List<Camera> exceptCameras;
        [SerializeField] private List<string> exceptCameraNames;
        [SerializeField] private float delay;
        #pragma warning restore 0649

        private static List<Camera> allTargetCameras = new List<Camera>();
        private List<Camera> targetCameras = new List<Camera>();

        public bool IsOn{get; private set;}

        private void Awake()
        {
            if (onType == OnType.Awake)
            {
                On();
            }
        }

        private void Start()
        {
            if (onType == OnType.Start)
            {
                On();
            }
        }

        private void OnEnable()
        {
            if (onType == OnType.OnEnable)
            {
                On();
            }
        }

        private void OnDisable()
        {
            if (offType == OffType.OnDisable)
            {
                Off();
            }
        }

        public void On()
        {
            if (IsOn)
            {
                return;
            }

            IsOn = true;
            useCount++;

            if (useCount == 1)
            {
                Debug.Log("CameraDisabler - On!!!");
            }

            StartCoroutine(OnCoroutine());
        }

        private IEnumerator OnCoroutine()
        {
            if (delay > 0)
            {
                yield return new WaitForSeconds(delay);
            }

            var allCams = Camera.allCameras;

            for (int i = 0; i < allCams.Length; i++)
            {
                var cam = allCams[i];

                if (exceptCameras.Contains(cam)
                    || exceptCameraNames.Contains(cam.name)
                    || allTargetCameras.Contains(cam))
                {
                    continue;
                }

                if ((cam.cullingMask & targetLayers.value) != 0)
                {
                    cam.enabled = false;
                    allTargetCameras.Add(cam);
                    targetCameras.Add(cam);
                    Debug.Log("CameraDisabler disable - " + cam.gameObject.name);
                }
            }

            yield break;
        }

        public void Off()
        {
            if (IsOn == false)
            {
                return;
            }

            IsOn = false;
            useCount--;

            Debug.Log("CameraDisabler - Off!!!");
            for (int i = targetCameras.Count - 1; i >= 0; i--)
            {
                Camera cam = targetCameras[i];
                if (cam != null)
                {
                    cam.enabled = true;
                    allTargetCameras.Remove(cam);
                    Debug.Log("CameraDisabler enable - " + cam.gameObject.name);
                }
            }
            targetCameras.Clear();

            StopAllCoroutines();

            if (useCount <= 0)
            {
                useCount = 0;

                Debug.Log("CameraDisabler - All Off!!!");

                for (int i = 0; i < allTargetCameras.Count; i++)
                {
                    Camera cam = allTargetCameras[i];

                    if (cam != null)
                    {
                        cam.enabled = true;
                        Debug.Log("CameraDisabler enable - " + cam.gameObject.name);
                    }
                }

                 allTargetCameras.Clear();
            }
        }

        public static void Clear()
        {
            useCount = 0;

            Debug.Log("CameraDisabler - Reset!!!");

            for (int i = 0; i < allTargetCameras.Count; i++)
            {
                var cam = allTargetCameras[i];
                
                if (cam != null)
                {
                    cam.enabled = true;
                }
            }

            allTargetCameras.Clear();
        }
    }
}