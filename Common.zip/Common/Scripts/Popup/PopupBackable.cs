

namespace SlotKingdoms.Popup
{
    public class PopupBackable : PopupBehaviour, IBackable
    {
        protected bool allowBackButton = true;

        #region implement IBackable

        protected virtual void OnEnable()
        {
            BackButtonSystem.Instance.Add(this);
        }

        protected virtual void OnDisable()
        {
            BackButtonSystem.Instance.Remove(this);
        }

        public virtual bool CanBack()
        {
            return allowBackButton;
        }

        public virtual void GoBack()
        {
            Close();
        }
        #endregion
    }
}
