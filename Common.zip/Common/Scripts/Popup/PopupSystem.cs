using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using System;
using SlotKingdoms.Transition;
using System.Collections;
using SlotKingdoms.UI;
using UnityEngine.Events;
using System.Runtime.InteropServices.WindowsRuntime;

namespace SlotKingdoms.Popup
{
    public class PopupSystem : CanvasSingleton<PopupSystem>
    {
        private Dictionary<string, PopupBehaviour> cachedPopupInfoDic = new();
        private Dictionary<string, BackgroundPanel> backgroundPanelDic = new();
        private List<PopupBehaviour> openPopupList = new();

        private Transform topUIRoot = null;
        private Transform cacheRoot = null;

        private GameObject indicatorPoolRoot = null;
        private GameObjectPool<LoadingIndicator> indicatorPool = null;

        private GameObject backgroundPanelPoolRoot = null;
        private GameObjectPool<BackgroundPanel> backgroundPanelPool = null;

        private LoadingIndicator currentIndicator = null;
        private TopUI topUI = null;

        private UnityEvent openEvent = new();
        public UnityEvent OpenEvent { get => openEvent; }

        private UnityEvent allCloseEvent = new();
        public UnityEvent AllCloseEvent { get => allCloseEvent; }

        public bool IsPopupOpened<T>() where T : PopupBehaviour
        {
            bool result = false;
            foreach (PopupBehaviour openPopup in openPopupList)
            {
                if (openPopup is T)
                {
                    result = true;
                    break;
                }
            }
            return result;
        }

        protected override void OnInitialize(string popupLayerName, int resolutionWidth, int resolutionHeight, ScreenMatchMode match, int pixelsPerUnit, int depth)
        {
            //this.popupLayerName = popupLayerName;

            base.OnInitialize(popupLayerName, resolutionWidth, resolutionHeight, match, pixelsPerUnit, depth);
        }

        public IEnumerator PrepareAssetsCoroutine(Action<float> onProgress, Action onComplete, Action<string> onError)
        {
            Func<string, Transform, bool, RectTransform> CreateTransform = (name, t, active) =>
            {
                Transform tr = new GameObject(name).transform;
                tr.gameObject.SetActive(active);
                tr.SetParent(t, false);
                return tr.AddComponent<RectTransform>();
            };

            topUIRoot = CreateTransform("topUIRoot", root, true);
            topUIRoot.AddComponent<SingleRangedResizer>();
            cacheRoot = CreateTransform("cacheRoot", canvas, false);

            int addressablesAssetCount = 2;
            float progressBegin = 0f;
            float progressStep = 1f / addressablesAssetCount;
            // BackgroundPanel 로드
            backgroundPanelPoolRoot = CreateTransform("backgroundPanelPoolRoot", canvas, false).gameObject;
            BackgroundPanel panel = null;
            yield return AddressablesLoader.Instance.LoadComponentCoroutine<BackgroundPanel>(
                "BackgroundPanel", 
                false,
                (float value) => {
                    onProgress?.Invoke(progressBegin + value * progressStep);
                },
                onComplete: _panel => {
                    onProgress?.Invoke(progressBegin + progressStep);
                    panel = _panel;
                    if (panel == null)
                    {
                        onError?.Invoke("Failed to load BackgroundPanel.");
                    }
                }
            );
            backgroundPanelPool = new GameObjectPool<BackgroundPanel>(backgroundPanelPoolRoot, 2, () =>
            {
                panel.OnReturn = () => backgroundPanelPool.Return(panel);
                return Instantiate(panel);
            });

            progressBegin += progressStep;
            // LoadingIndicator 로드
            indicatorPoolRoot = CreateTransform("indicatorPoolRoot", canvas, false).gameObject;
            LoadingIndicator indicator = null;
            yield return AddressablesLoader.Instance.LoadComponentCoroutine<LoadingIndicator>(
                "LoadingIndicator", 
                false,
                (float value) => {
                    onProgress?.Invoke(progressBegin + value * progressStep);
                },
                onComplete: _indicator => {
                    onProgress?.Invoke(progressBegin + progressStep);
                    indicator = _indicator;
                    if (indicator == null)
                    {
                        onError?.Invoke("Failed to load LoadingIndicator.");
                    }
                }
            );
            indicatorPool = new GameObjectPool<LoadingIndicator>(indicatorPoolRoot, 2, () =>
            {
                return Instantiate(indicator);
            });

            Clear();

            onComplete?.Invoke();
        }

        public void Clear()
        {

        }

        public PopupBehaviour OpenPopup(string popupName)
        {
            OpenEvent.Invoke();
            string n = popupName;

            ShowBackgroundPanel(n);
            ShowLoading();

            PopupBehaviour obj;
            if (cachedPopupInfoDic.ContainsKey(n))
            {
                obj = cachedPopupInfoDic[n];
            }
            else
            {
                obj = AddressablesLoader.Instance.LoadComponent<PopupBehaviour>(n);
                if (obj != null)
                {
                    cachedPopupInfoDic.Add(n, obj);
                    obj.GraphicRaycaster = obj.AddComponent<Canvas>().AddComponent<GraphicRaycaster>();
                }
            }

            if (obj != null)
            {
                obj.transform.SetParent(root.transform, false);
                openPopupList.Add(obj);
            }
            else
            {
                //
            }
            obj.gameObject.name = n;
            HideLoading();
            return obj;
        }

        public T OpenPopup<T>() where T : PopupBehaviour
        {
            OpenEvent.Invoke();
            T obj;
            string n = typeof(T).Name;

            ShowBackgroundPanel(n);
            ShowLoading();

            if (cachedPopupInfoDic.ContainsKey(n))
            {
                obj = cachedPopupInfoDic[n] as T;
            }
            else
            {
                obj = AddressablesLoader.Instance.LoadComponent<T>(n);
                if (obj != null)
                {
                    cachedPopupInfoDic.Add(n, obj);
                    obj.GraphicRaycaster = obj.AddComponent<Canvas>().AddComponent<GraphicRaycaster>();
                }
            }

            if (obj != null)
            {
                obj.transform.SetParent(root.transform, false);
                openPopupList.Add(obj);
            }
            else
            {
                //
            }
            obj.gameObject.name = n;
            HideLoading();
            return obj;
        }

        public void OpenLoadPopup<T>(Action<T> onInitialize = null, Action<T> onOpen = null) where T : PopupBehaviour
        {
            OpenEvent.Invoke();
            StartCoroutine(OpenPopupCoroutine<T>(onInitialize, onOpen));
        }

        public IEnumerator OpenPopupWaitForClose<T>(Action<T> onInitialize = null, Action<T> onOpen = null) where T : PopupBehaviour
        {
            OpenEvent.Invoke();
            yield return OpenPopupCoroutine<T>(onInitialize, onOpen, true);
        }

        public IEnumerator OpenPopupCoroutine<T>(Action<T> onInitialize = null, Action<T> onOpen = null, bool waitForClose = false) where T : PopupBehaviour
        {
            ShowLoading();

            T obj = null;
            string n = typeof(T).Name;
            ShowBackgroundPanel(n);
            if (cachedPopupInfoDic.ContainsKey(n))
            {
                obj = cachedPopupInfoDic[n] as T;
                obj.SetActiveRoot(false);
            }
            else
            {
                GameObject prefab = AddressablesLoader.Instance.LoadAsset<GameObject>(n);
                if (prefab != null)
                {
                    obj = Instantiate(prefab, cacheRoot).GetComponent<T>();
                    obj.SetActiveRoot(false);
                    cachedPopupInfoDic.Add(n, obj);
                    obj.GraphicRaycaster = obj.AddComponent<Canvas>().AddComponent<GraphicRaycaster>();
                }
            }

            if (obj.TopUIUseType != TopUIUseType.None)
            {
                UIManager.Instance.HideTopUI();
            }

            obj.transform.SetParent(root.transform, false);
            obj.gameObject.name = n;
            openPopupList.Add(obj);
            onInitialize?.Invoke(obj);
            yield return obj.Load();

            HideLoading();
            obj.SetActiveRoot(true);

            if (obj.TopUIUseType == TopUIUseType.Use)
            {
                Action showTopUI = () =>
                {
                    topUI = UIManager.Instance.ShowTopUI(obj.TopUIUseInfo);
                    topUI.transform.SetParent(topUIRoot.transform, false);
                    topUIRoot.SetAsLastSibling();
                };

                PopupAnimator popupAnimator = obj.GetComponent<PopupAnimator>();
                if (popupAnimator != null)
                {
                    popupAnimator.onOpenAction = showTopUI;
                }
                else
                {
                    showTopUI.Invoke();
                }
            }

            onOpen?.Invoke(obj);
            if (waitForClose)
            {
                yield return obj.WaitForClose();
            }
        }

        public void OpenPopup<T>(Action<T> onInitialize = null, Action<T> onOpen = null) where T : PopupBehaviour
        {
            OpenLoadPopup<T>(onInitialize, onOpen);
        }

        public void OpenPopup<T>(eTransitionType type, Action<T> onInitialize = null, Action<T> onOpen = null) where T : PopupBehaviour
        {
            OpenEvent.Invoke();
            StartCoroutine(OpenPopupCoroutine<T>(type, null, null, onInitialize, onOpen));
        }

        public IEnumerator OpenPopupWaitForClose<T>(eTransitionType type, string imageType = null, string imageValue = null, Action<T> onInitialize = null, Action<T> onOpen = null) where T : PopupBehaviour
        {
            OpenEvent.Invoke();
            yield return OpenPopupCoroutine<T>(type, imageType, imageValue, onInitialize, onOpen, true);
        }

        public IEnumerator OpenPopupCoroutine<T>(eTransitionType type, string imageType, string imageValue, Action<T> onInitialize = null, Action<T> onOpen = null, bool waitForClose = false) where T : PopupBehaviour
        {
            ShowLoading();
            while (!TransitionSystem.Instance.TransitionDic.ContainsKey(type))
            {
                yield return null;
            }
            HideLoading();
            Transition.Transition transition = TransitionSystem.Instance.OnTransiton(type);

            if (imageType != null && imageValue != null)
            {
                transition.ProfileImage.SetImage(imageType, imageValue);
            }

            T obj = null;
            string n = typeof(T).Name;
            ShowBackgroundPanel(n, false);
            if (cachedPopupInfoDic.ContainsKey(n))
            {
                obj = cachedPopupInfoDic[n] as T;
                obj.SetActiveRoot(false);
            }
            else
            {
                GameObject prefab = AddressablesLoader.Instance.LoadAsset<GameObject>(n);
                if (prefab != null)
                {
                    obj = Instantiate(prefab, cacheRoot).GetComponent<T>();
                    obj.SetActiveRoot(false);
                    cachedPopupInfoDic.Add(n, obj);
                    obj.GraphicRaycaster = obj.AddComponent<Canvas>().AddComponent<GraphicRaycaster>();

                }
            }
            while (!transition.IsAniState("Idle") || obj == null)
            {
                yield return null;
            }

            if (obj.TopUIUseType != TopUIUseType.None)
            {
                UIManager.Instance.HideTopUI();
            }

            obj.transform.SetParent(root.transform, false);
            obj.gameObject.name = n;
            openPopupList.Add(obj);
            onInitialize?.Invoke(obj);
            yield return obj.Load();

            //while (!obj.IsLoaded)
            //{
            //    yield return null;
            //}

            while(!transition.IsMinPlay)
            {
                yield return null;
            }

            transition.PlayOut();

            while (transition.IsAniState("Idle"))
            {
                yield return null;
            }

            obj.SetActiveRoot(true);

            if (obj.TopUIUseType == TopUIUseType.Use)
            {
                Action showTopUI = () =>
                {
                    topUI = UIManager.Instance.ShowTopUI(obj.TopUIUseInfo);
                    topUI.transform.SetParent(topUIRoot.transform, false);
                    topUIRoot.SetAsLastSibling();
                };

                PopupAnimator popupAnimator = obj.GetComponent<PopupAnimator>();
                if (popupAnimator != null)
                {
                    popupAnimator.onOpenAction = showTopUI;
                }
                else
                {
                    showTopUI.Invoke();
                }
            }

            onOpen?.Invoke(obj);
            if (waitForClose)
            {
                yield return obj.WaitForClose();
            }
        }

        public void StartClosing(PopupBehaviour popup)
        {
            if (topUI != null)
            {
                topUI.Hide();
                topUI = null;
            }
        }

        public void Close(PopupBehaviour popup)
        {
            if (popup.UseCloseTransition)
            {
                StartCoroutine(CloseCoroutine(popup));
            }
            else
            {
                popup.IsDone = true;
                popup.transform.SetParent(cacheRoot.transform, false);
                HideBackgroundPanel(popup.gameObject.name);
                openPopupList.Remove(popup);

                if (openPopupList.Count == 0)
                {
                    AllCloseEvent.Invoke();
                }
                //sortValue = sortValue - 10;
            }
        }

        public IEnumerator CloseCoroutine(PopupBehaviour popup)
        {
            ShowLoading();
            while (!TransitionSystem.Instance.TransitionDic.ContainsKey(popup.TransitionType))
            {
                yield return null;
            }
            HideLoading();
            Transition.Transition transition = TransitionSystem.Instance.OnTransiton(popup.TransitionType);

            while (!transition.IsAniState("Idle"))
            {
                yield return null;
            }

            transition.PlayOut();
            while (transition.IsAniState("Idle"))
            {
                yield return null;
            }
            popup.gameObject.SetActive(false);
            while (transition.gameObject.activeSelf)
            {
                yield return null;
            }
            popup.IsDone = true;
            popup.transform.SetParent(cacheRoot.transform, false);
            popup.gameObject.SetActive(true);
            HideBackgroundPanel(popup.GetType().Name);
            openPopupList.Remove(popup);

            if (openPopupList.Count == 0)
            {
                AllCloseEvent.Invoke();
            }
        }

        public void ShowLoading(bool visible = true)
        {
            if (currentIndicator == null)
            {
                currentIndicator = indicatorPool.Get();
                currentIndicator.transform.SetParent(root.transform, false);
                if (!visible)
                {
                    currentIndicator.StopAllCoroutines();
                }
            }
        }

        public void HideLoading()
        {

            if (currentIndicator != null)
            {
                indicatorPool.Return(currentIndicator);
                currentIndicator = null;
            }
        }

        public void ShowBackgroundPanel(string n, bool visible = true)
        {
            if (!backgroundPanelDic.ContainsKey(n))
            {
                BackgroundPanel back = backgroundPanelPool.Get();
                back.enabled = visible;
                if (!visible)
                {
                    back.SetA();
                }
                back.transform.SetParent(root.transform, false);
                backgroundPanelDic.Add(n, back);

            }
        }

        public void HideBackgroundPanel(string n)
        {
            if (backgroundPanelDic.ContainsKey(n))
            {
                backgroundPanelPool.Return(backgroundPanelDic[n]);
                backgroundPanelDic.Remove(n);
            }
        }

        public void SetBackgroundPanelAlpha(string n, float alpha)
        {
            if (backgroundPanelDic.ContainsKey(n))
            {
                var bg = backgroundPanelDic[n].transform.GetComponent<CanvasGroup>();
                bg.alpha = alpha;
            }
        }

        public void RemoveCachedPopup(string key)
        {
            if(cachedPopupInfoDic.ContainsKey(key))
            {
                cachedPopupInfoDic.Remove(key);
            }
        }

        //private void SetSortOder(Transform tr)
        //{
        //    tr.GetComponent<Canvas>().overrideSorting = true;
        //    tr.GetComponent<Canvas>().sortingOrder = sortValue;
        //    sortValue += 10;
        //}

        //private void SubSortValue()
        //{
        //    sortValue -= 10;
        //    sortValue = sortValue < 10 ? 10 : sortValue;
        //}
    }
}