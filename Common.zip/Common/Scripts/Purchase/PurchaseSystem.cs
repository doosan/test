using epoch.Client.IAP;
using epoch.Client.Util;
using SlotKingdoms.Net;
using SlotKingdoms.Popup;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using UnityEngine;
using UnityEngine.Purchasing;
using UnityEngine.UI;

namespace SlotKingdoms
{
    public class ProductInfo
    {
        public Product product;
        public string platform;

        // used in android & ios both
        public string transactionID;
        public string receipt;

        // used in android only
        public string signature;

        public string currencyCode;
        public long priceMultiplied;
        public double priceOrigin;
    }

    public class ConsumeInfo
    {
        public bool IsSuccess
        {
            get; private set;
        }

        public string Error
        {
            get; private set;
        }

        public CustomYield.WaitForComplete WaitForComplete
        {
            get; private set;
        }

        public ConsumeInfo()
        {
            WaitForComplete = new CustomYield.WaitForComplete();
        }

        public void UpdateResult(IAPResult result)
        {
            IsSuccess = result.IsSuccess();
            Error = result.GetMessage();

            WaitForComplete.Done();
        }
    }

    [System.Serializable]
    public class LatestPurchaseItemInfo
    {
        public string itemID;
        public int offerID;
        public int shopOfferID;
        public int couponIndex;
        public string passType;

        public LatestPurchaseItemInfo(string itemID, int offerID, int shopOfferID, int couponIndex, string passType)
        {
            this.itemID = itemID;
            this.offerID = offerID;
            this.shopOfferID = shopOfferID;
            this.couponIndex = couponIndex;
            this.passType = passType;
        }

        public override string ToString()
        {
            return StringMaker.New()
                              .Append($"itemID : {itemID}")
                              .Append($", offerID : {offerID}")
                              .Append($", couponIndex : {couponIndex}")
                              .Append($", passType : {passType}")
                              .Build();
        }
    }

    public class FakePurchaseInfo : PurchaseInfo
    {
        private System.Random random = new System.Random();

        public FakePurchaseInfo()
        {
            UpdateProduct();
        }

        public void UpdateProduct()
        {
            string platform;
#if UNITY_ANDROID
            platform = "android";
#elif UNITY_IOS || UNITY_IPHONE
            platform = "ios";
#elif UNITY_STANDALONE_WIN || UNITY_WSA
            platform = "ms";
#elif UNITY_STANDALONE_OSX
            platform = "mac";
#endif

            // dev 서버에서 결제 통과를 위한 가짜 데이터
            string randomTransactionID = CreateFakeTransactionID();
            string randomReceipt = RandomString(10);
            ProductInfo = new ProductInfo()
            {
                product = null,
                platform = platform,
                transactionID = randomTransactionID,
                receipt = randomReceipt,
                signature = "",
                currencyCode = "USD",
                priceMultiplied = 100
            };
        }

        protected string RandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(chars, length)
                                        .Select(s => s[random.Next(s.Length)])
                                        .ToArray());
        }
    }

    public class UserCancelledPurchaseInfo : PurchaseInfo
    {
        public UserCancelledPurchaseInfo()
        {
            IsSuccess = false;
            Error = "UserCancelled";
        }
    }

    public class PurchaseInfo
    {
        public ProductInfo ProductInfo
        {
            get; 
            protected set;
        }

        public bool IsSuccess
        {
            get; 
            protected set;
        }

        public bool IsDuplicateTransaction
        {
            get => Error == "DuplicateTransaction";
        }

        public bool IsUserCancelled
        {
            get => Error == "UserCancelled";
        }

        public string Error
        {
            get; 
            protected set;
        }

        public CustomYield.WaitForComplete WaitForComplete
        {
            get; private set;
        }

        public PurchaseInfo()
        {
            WaitForComplete = new CustomYield.WaitForComplete();
        }

        public void UpdateResult(IAPResult result)
        {
            IsSuccess = result.IsSuccess();
            Error = result.GetMessage();
            Debug.Log($"==== UpdateResult().result : {result.ToString()}");

            if (IsSuccess)
            {
                UpdateProduct(result.PayOnItemData);
            }

            Debug.Log($"==== UpdateResult().transactionID : {ProductInfo?.transactionID}");
            WaitForComplete.Done();
        }

        public void UpdateProduct(PayOnItemData itemData)
        {
//#if UNITY_ANDROID
//            //구글은 영수증 검증에 필요한 데이터들이 PayLoad Json 안에 담겨 있기 때문에, 편하게 추출하고자 GooglePurchaseData 클래스와 FromJson 함수를 제공해드립니다.
//            // PayloadData에선 receipt와 signature를 얻어올 수 있으며,
//            // JsonData에선 orderID, packageName, productID, productToken 등을 얻어올 수 있습니다.
//            PayloadData payloadData = GooglePurchaseData.FromJson(product.receipt).PayloadData;
//            ProductMetadata productMetadata = product.metadata;
//            ProductInfo = new ProductInfo()
//            {
//                product = product,
//                platform = "android",
//                transactionID = payloadData.JsonData.orderId,
//                receipt = payloadData.json,
//                signature = payloadData.signature,
//                currencyCode = productMetadata.isoCurrencyCode,
//                priceMultiplied = (long)(productMetadata.localizedPrice * 100),
//                priceOrigin = Decimal.ToDouble(productMetadata.localizedPrice)
//            };
//#elif UNITY_IOS || UNITY_IPHONE
//            //IOS는 ReceiptData에 IOSTransactionID를 그대로 담아 전송하면 됩니다.
//            string transactionReceipt = IAP.GetIOSReceiptData(product);
//            ProductMetadata productMetadata = product.metadata;
//            ProductInfo = new ProductInfo()
//            {
//                product = product,
//                platform = "ios",
//                transactionID = product.transactionID,
//                receipt = transactionReceipt,
//                signature = string.Empty,
//                currencyCode = productMetadata.isoCurrencyCode,
//                priceMultiplied = (long)(productMetadata.localizedPrice * 100),
//                priceOrigin = Decimal.ToDouble(productMetadata.localizedPrice)
//            };
//#elif UNITY_WSA
//            ProductMetadata productMetadata = product.metadata;
//            IAPMicrosoftStore microsoftStoreIAP = new IAPMicrosoftStore();
            
//            ProductInfo = new ProductInfo()
//            {
//                product = product,
//                platform = "ms",
//                transactionID = product.transactionID,
//                receipt = microsoftStoreIAP.GetPayonReceiptData(product),
//                signature = string.Empty,
//                currencyCode = productMetadata.isoCurrencyCode,
//                priceMultiplied = (long)(productMetadata.localizedPrice * 100),
//                priceOrigin = Decimal.ToDouble(productMetadata.localizedPrice)
//            };
//#endif
        }

        protected string CreateFakeTransactionID()
        {
            return string.Format("FakeTransaction{0}", UnityEngine.Random.Range(1,100));
        }
    }

    public class PurchaseInPending
    {
        public PurchaseInfo purchaseInfo;
        public bool isInPending;

        public PurchaseInPending(PurchaseInfo purchaseInfo)
        {
            this.purchaseInfo = purchaseInfo;
            isInPending = true;
        }
    }

    public enum PurchaseFailStep
    { 
        None,
        StorePurchaseFail = 1,
        StorePurchaseAndQuit = 2,
        ExchangeFail      = 3,
        ConsumeFail       = 4
    }

    public class PurchaseSystem : GameObjectSingleton<PurchaseSystem>
    {
        public bool IsFailed
        {
            get;
            private set;
        }
        public bool IsSuccess
        {
            get
            {
                return !IsFailed;
            }
        }
        public bool IsUserCancelled
        {
            get;
            private set;
        }
        public bool ShowReward
        {
            private get;
            set;
        }
        public PurchaseFailStep FailStep
        { 
            get; 
            set; 
        }
        private PurchaseFailStep targetFailStep;

        public bool RunAsFake
        {
            private get;
            set;
        }

        private const string KEY_LATEST_PURCHASE_ITEM_INFO = "key_latest_purchase_item_info";
        private const string KEY_LATEST_PURCHASE_ITEM_INFO_WITH_ID = "key_lpi_info";

        private Dictionary<string, StoreProduct> storeProducts = new Dictionary<string, StoreProduct>();
        private Queue<PurchaseInfo> purchaseInfos = new Queue<PurchaseInfo>();
        private List<PurchaseRewardInfo> rewardDatas = new List<PurchaseRewardInfo>();

        private HashSet<string> exchangesHistory = new HashSet<string>();
        private Dictionary<string, PurchaseInfo> purchasesInPending = new Dictionary<string, PurchaseInfo>();

        private bool isInSearch;
        private bool initOnce;

        private IStoreController storeContollerCache;
        private Action<Product> deferredPurchaseListenerCache;

        private string itemID;
        private int? offerID;
        private int? shopOfferID;
        private int couponIndex;
        public string passType;
        private Action onFail;

        private PurchaseInfo purchasedInfo;

        public PurchaseRewardInfo GetRewardData(PurchaseRewardType rewardType)
        {
            return rewardDatas.FirstOrDefault(rewardData => rewardData.Type == rewardType);
        }

        public void InitStoreItems()
        {
            Debug.Log("==== iap.InitStoreItems()");
#if UNITY_EDITOR == false
            if (!IAP.IsInitialized())
            {
                StoreOption eStore = TargetAsStoreOption(GameConfig.RuntimeTarget);

                string languageCode = Locale.GetLanguageCode();
                string countryCode = Locale.GetCountryCode();
                Enum.TryParse(languageCode, out LanguageCode eStoreLaguage);
                Enum.TryParse(countryCode, out CountryCode eStoreCountry);
                Enum.TryParse(GetCurrencyCodeFromCountryCode(countryCode), out CurrencyCode eStoreCurrency);

                EpochIAPSettings settings = new EpochIAPSettings();
                settings.SetMarketStore(eStore);
                settings.SetStoreLocale(eStoreLaguage, eStoreCountry, eStoreCurrency);
                settings.GetCurrencyCode();
                IAP.InitializePurchase(settings, OnIAPInitialized);
            }
#else
            initOnce = true;
#endif
        }


        void OnIAPInitialized(IAPResult _Result)
        {
            Debug.Log($"OnIAPInitialized : {_Result}");

            storeProducts.Clear();
            if (_Result.IsSuccess())
            {
                initOnce = true;
                foreach (StoreProduct item in IAP.GetStoreItemData())
                {
                    storeProducts.Add(item.ItemID, item);
                    Debug.Log("==== Store Item : " + item.Store + ", " + item.ItemID + ", " + item.Despcription + ", " + item.PurchasePrice);
                }
            }

            ReadPendingPurchases();
        }

        public string GetCurrencyCodeFromCountryCode(string countryCode)
        {
            RegionInfo region = new RegionInfo(countryCode);
            return region.ISOCurrencySymbol;
        }

        private StoreOption TargetAsStoreOption(RuntimeTarget runtimeTarget)
        {
            return runtimeTarget == RuntimeTarget.Android ? StoreOption.GooglePlayStore :
                   runtimeTarget == RuntimeTarget.iOS ? StoreOption.AppleInAppStore :
                   runtimeTarget == RuntimeTarget.WSAPlayer ? StoreOption.MicrosoftStore :
                   StoreOption.None;
        }

        public IEnumerator CheckIfStoreInit(Action<string> onFail)
        {
            if (initOnce == false)
            {
                PopupSystem.Instance.ShowLoading();
                InitStoreItems();

                bool timeOut = false;
                float timeBegin = Time.time;
                while (initOnce == false)
                {
                    float timePassed = Time.time - timeBegin;
                    if (timePassed > 10)
                    {
                        timeOut = true;
                        break;
                    }

                    yield return null;
                }

                PopupSystem.Instance.HideLoading();
                if (timeOut == true)
                {
                    string failMessage = "Failed to initialize the SHOP.";
#if UNITY_WSA
                    failMessage = "Please, log in to your Microsoft Account at the Microsoft Store to access Aquuua Casino shop.";
#endif

                    onFail?.Invoke(failMessage);
                }
            }

            yield break;
        }

        private PurchaseInfo BuyProduct(string productID, Action onComplete = null)
        {
            var purchaseInfo = new PurchaseInfo();
            IAP.BuyProductID(productID, /* OnPurchaseSuccess */(IAPResult result) =>
            {
                purchaseInfo.UpdateResult(result);
                onComplete?.Invoke();
            });

            return purchaseInfo;
        }

        private ConsumeInfo ConsumeItem(Product product, Action onComplete = null)
        {
            var consumeInfo = new ConsumeInfo();
            //IAP.ConsumeItem(product, /* OnConsumeSuccess */(IAPResult result) =>
            //{
            //    consumeInfo.UpdateResult(result);
            //    onComplete?.Invoke();
            //});

            return consumeInfo;
        }

        public Queue<PurchaseInfo> GetPendingPurchases()
        {
            return purchaseInfos;
        }

        public void ReadPendingPurchases()
        {
            Debug.Log($"ReadPendingPurchases : {isInSearch}");
            if (isInSearch == false)
            {
                StartCoroutine(ReadPendingPurchasesCoroutine());
            }
        }

        private IEnumerator ReadPendingPurchasesCoroutine()
        {
            isInSearch = true;

            IAP.GetRemainTransactions((PayOnRemainTransaction transaction) =>
            {
                if (transaction.ResultCode == epoch.Client.Result.ResultCode.Success)
                {
                    if (transaction.RemainTransactionList.Count > 0)
                    {
                        Debug.Log($"transaction.RemainTransactionList.Count : {transaction.RemainTransactionList.Count}");
                        foreach (PayOnItemData item in transaction.RemainTransactionList)
                        {
                            var purchaseInfo = new PurchaseInfo();
                            purchaseInfo.UpdateProduct(item);
                            purchaseInfos.Enqueue(purchaseInfo);
                            Debug.Log($"\tremainTransactionItem : {item.ProductId}, {item.OrderId}");
                        }
                    }
                }

                isInSearch = false;
            });

            yield break;
        }

        private void ConsumeFailStep()
        {
            targetFailStep = FailStep;
            FailStep = PurchaseFailStep.None;
        }

        private bool CheckFailStep(PurchaseFailStep currFailStep)
        {
            bool result = false;

            if (targetFailStep != PurchaseFailStep.None
                && (int)currFailStep >= (int)targetFailStep)
            {
                result = true;
            }

            return result;
        }

        private IEnumerator Exchange()
        {
            if (IsFailed)
            {
                yield break;
            }
            else if (CheckFailStep(PurchaseFailStep.ExchangeFail))
            {
                OpenFailPopup(targetFailStep.ToString(), null);
                yield break;
            }

            Debug.Log("==== Purchase Step 2 - Exchange");
            ProductInfo productInfo = purchasedInfo.ProductInfo;
            if (productInfo != null
                && exchangesHistory.Contains(productInfo.transactionID) == false)
            {
                Debug.Log("==== Purchase Step 2-1");
                //PopupSystem.Instance.ShowLoading(true);
                /// 서버에 구매한 상품 데이터 보내기
                Request<PurchaseResponse> req = NetworkSystem.Requester.Purchase(
                    sessionTicket: "" /*Auth.AccountSystem.SessionTicket*/,
                    itemID: itemID
                );
                yield return req.WaitForResponse();
                //PopupSystem.Instance.ShowLoading(false);

                if (req.IsSuccess == false
                    && req.Data.error != "1022" /* 이미 확인되어 서버에 반영된 영수증이면 발생하는 에러 넘버 */)
                {
                    OpenFailPopup(req.Data.error, purchasedInfo);
                    yield break;
                }

                Debug.Log("==== Purchase Step 2-2");
                /// 1022 에러에 대해 Fail 팝업을 띄우기 않은 이유는 Epoch 에 상품 소비를 요청하기 위함
                if (req.Data.error != "1022")
                {
                    ExtractRewardDatas(req.Data);
                }

                // 첫 결제시 로그를 전송.
                if (req.Data.cnt == 1)
                {
                    //UndercGameLog.Firebase.PurchaseFirst(productInfo.priceOrigin, productInfo.currencyCode);
                    //UndercGameLog.Singular.PurchaseFirst(productInfo.priceOrigin, productInfo.currencyCode);
                }

                exchangesHistory.Add(productInfo.transactionID);
            }

            yield break;
        }

        public void ExtractRewardDatas(PurchaseResponse purchaseResponse)
        {
            ExtractRewardDatas(purchaseResponse.coin);
        }

        private void ExtractRewardDatas(long coin)
        {
            rewardDatas.Clear();
            if (coin > 0)
            {
                rewardDatas.Add(new PurchaseRewardInfo(PurchaseRewardType.Coin, coin));
            }
        }

        private IEnumerator Consume()
        {
            if (IsFailed)
            {
                yield break;
            }
            else if (IsFakeEnvironment())
            {
                yield break;
            }
            else if (CheckFailStep(PurchaseFailStep.ConsumeFail))
            {
                OpenFailPopup(targetFailStep.ToString(), null);
                yield break;
            }

            /// Epoch 에 상품 소비 시도
            Debug.Log("==== Purchase Step 3 - Consume : " + IsFailed);
            ProductInfo productInfo = purchasedInfo.ProductInfo;
            if (productInfo != null)
            {
                PopupSystem.Instance.ShowLoading();
                ConsumeInfo consumeInfo = ConsumeItem(productInfo.product);
                yield return consumeInfo.WaitForComplete;
                PopupSystem.Instance.HideLoading();

                if (consumeInfo.IsSuccess == false)
                {
                    OpenFailPopup(consumeInfo.Error, purchasedInfo);
                    yield break;
                }

                string itemID = productInfo.product.definition.storeSpecificId;
                if (purchasesInPending.ContainsKey(itemID) == true)
                {
                    purchasesInPending.Remove(itemID);
                }
            }

            yield break;
        }

        private void ResetLatestPurchaseItemInfo(string itemID)
        {
            WriteLatestPurchaseItemInfo(itemID, "");
        }

        private void WriteLatestPurchaseItemInfo(string itemID)
        {
            /// 구매 복원이 일어날 때는 itemID 이외의 값은 알 수 없으므로 로컬에 따로 저장해 둠
            int latestOfferID = offerID != null ? offerID.Value : -1;
            int latestShopOfferID = shopOfferID != null ? shopOfferID.Value : -1;
            int latestCouponIndex = couponIndex;
            string latestPassType = passType; 
            LatestPurchaseItemInfo itemInfo = new LatestPurchaseItemInfo(itemID, latestOfferID, latestShopOfferID, latestCouponIndex, latestPassType);

            WriteLatestPurchaseItemInfo(itemID, JsonUtility.ToJson(itemInfo));
        }

        private void WriteLatestPurchaseItemInfo(string itemID, string itemInfo)
        {
            PlayerPrefs.SetString($"{KEY_LATEST_PURCHASE_ITEM_INFO_WITH_ID}_{itemID}", itemInfo);
        }

        private void ReadLatestPurchaseItemInfo(string itemID)
        {
            string localValue = PlayerPrefs.GetString(KEY_LATEST_PURCHASE_ITEM_INFO);   // 패치 이전에 저장 중이던 값
            PlayerPrefs.SetString(KEY_LATEST_PURCHASE_ITEM_INFO, "");   

            if (string.IsNullOrEmpty(localValue))
            {
                localValue = PlayerPrefs.GetString($"{KEY_LATEST_PURCHASE_ITEM_INFO_WITH_ID}_{itemID}");
            }
            ResetLatestPurchaseItemInfo(itemID);

            couponIndex = -1;
            offerID = null;
            shopOfferID = null;
            passType = "";
            if (string.IsNullOrEmpty(localValue) == false)
            {
                LatestPurchaseItemInfo latestPurchaseItemInfo = JsonUtility.FromJson<LatestPurchaseItemInfo>(localValue);
                Debug.Log("==== ReadLatestPurchaseItemInfo : " + latestPurchaseItemInfo);
                if (latestPurchaseItemInfo.itemID == itemID)
                {
                    offerID = latestPurchaseItemInfo.offerID;
                    shopOfferID = latestPurchaseItemInfo.shopOfferID;
                    couponIndex = latestPurchaseItemInfo.couponIndex;
                    passType = latestPurchaseItemInfo.passType;
                }
            }
            else
            {
                Debug.Log("==== ReadLatestPurchaseItemInfo : empty");
            }
        }

        public IEnumerator PendingPurchase(string itemID, PurchaseInfo pendingPurchaseInfo, bool showReward)
        {
            this.itemID = itemID;
            this.purchasedInfo = pendingPurchaseInfo;
            this.ShowReward = showReward;

            ReadLatestPurchaseItemInfo(itemID);

            yield return Exchange();
            yield return Consume();
            yield return Reward();
        }

        public bool IsFakeEnvironment()
        {
#if DEV
            return true;
#else
            return false;
#endif
        }

        public IEnumerator Purchase(string itemID, 
                                    int? offerID = null, 
                                    int? shopOfferID = null,
                                    int couponIndex = -1,
                                    string passType = "",
                                    Action onFail = null, 
                                    bool showReward = true)
        {
            this.itemID = itemID;
            this.offerID = offerID;
            this.shopOfferID = shopOfferID;
            this.couponIndex = couponIndex;
            this.passType = passType;
            this.onFail = onFail;
            this.ShowReward = showReward;

            IsFailed = false;
            IsUserCancelled = false;
            purchasedInfo = null;
            ConsumeFailStep();

            yield return StorePurchase();
            yield return Exchange();
            yield return Consume();
            yield return Reward();
        }

        private IEnumerator StorePurchase()
        {
            if (CheckFailStep(PurchaseFailStep.StorePurchaseFail))
            {
                OpenFailPopup(targetFailStep.ToString(), new UserCancelledPurchaseInfo());
                yield break;
            }
            else if (IsFakeEnvironment())
            {
                purchasedInfo = new FakePurchaseInfo();
                yield break;
            }
            
            Debug.Log("=== Purchase Step 1 - Purchase : " + itemID);
#if UNITY_EDITOR == false && (UNITY_ANDROID == true || UNITY_IOS == true || UNITY_IPHONE == true || UNITY_WSA)
            if (storeProducts.ContainsKey(itemID) == false)
            {
                PopupSystem.Instance.ShowLoading();
                
                float timeBegin = Time.time;
                float timePassed = 0f;
                while (storeProducts.ContainsKey(itemID) == false
                       && timePassed < 3f)
                {
                    timePassed = Time.time - timeBegin;
                    yield return null;
                }

                PopupSystem.Instance.HideLoading();

                if (storeProducts.ContainsKey(itemID) == false)
                {
                    Debug.LogWarning("스토어에 존재하지 않는 상품이므로 결제 요청을 하지 않습니다 : " + itemID + ", " + storeProducts.Count);
                    OpenFailPopup("Store pruducts are not ready.", null);
                    yield break;
                }
            }
#endif
            /// Epoch 에 상품 구매 요청
            Debug.Log("=== Purchase Step 1-1 : " + itemID);
            PopupSystem.Instance.ShowLoading();

            WriteLatestPurchaseItemInfo(itemID);

            PurchaseInfo buyInfo = BuyProduct(itemID);
            yield return buyInfo.WaitForComplete;
            PopupSystem.Instance.HideLoading();

            if (CheckFailStep(PurchaseFailStep.StorePurchaseAndQuit))
            {
                Application.Quit();
                yield break;
            }

            if (buyInfo.IsSuccess == false
                && buyInfo.IsDuplicateTransaction == false)
            {
                ResetLatestPurchaseItemInfo(itemID);
                OpenFailPopup(buyInfo.Error, buyInfo);
                yield break;
            }
            
            purchasedInfo = buyInfo;

            Debug.Log("=== Purchase Step 1-2 : " + purchasedInfo.ProductInfo);
            if (purchasedInfo.ProductInfo == null)
            {
                // 중복된 구매 요청이면 이전에 저장해놓은 상품 정보를 리턴
                if (purchasedInfo.IsDuplicateTransaction == true
                    && purchasesInPending.ContainsKey(itemID) == true)
                {
                    purchasedInfo = purchasesInPending[itemID];
                }
            }
            else
            {
                // 중복된 구매 요청을 대비해 상품 정보를 저장
                purchasesInPending[purchasedInfo.ProductInfo.product.definition.storeSpecificId] = purchasedInfo;
            }
            yield break;
        }

        public IEnumerator Reward()
        {
            if (IsFailed)
            {
                yield break;
            }

            Debug.Log("=== Purchase Step 4 - Reward : " + ShowReward + ", " + rewardDatas.Count);
            if (ShowReward == true
                && rewardDatas.Count > 0)
            {
                //PopupObject<RewardViewPopup> popupObject = null;
                //popupObject = Popups.RewardView(rewardDatas: rewardDatas.ToArray(),
                //                                location: RewardViewPopup.Location.Purchase,
                //                                onInit: () => popupObject.GetPopup().RunAsFake = RunAsFake);
                //yield return popupObject.WaitForClose();
                rewardDatas.Clear();
            }

            yield break;
        }

        private void OpenFailPopup(string message, PurchaseInfo purchaseInfo)
        {
            IsFailed = true;
            IsUserCancelled = purchaseInfo != null ?
                              purchaseInfo.IsUserCancelled :
                              false;
            onFail?.Invoke();

            if (purchaseInfo != null
                && purchaseInfo.ProductInfo != null)
            {
                message = purchaseInfo.ProductInfo.transactionID;
            }

            // 유저가 취소한 결제건은 무시
            if (IsUserCancelled == false 
                && string.IsNullOrEmpty(message) == false)
            {
                //Popups.PopupOpen<PurchaseFailPopup>(p=>p.Init(message))
                //      .Cache();
            }
        }
    }
}
