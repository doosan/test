using epoch.Client;
using epoch.Client.Auth;
using epoch.Client.Util;
using Facebook.Unity;
using SlotKingdoms.Net;
using SlotKingdoms.Popup;
using System;
using System.Collections;
using UnityEngine;
using static epoch.Client.Util.TimeZone;

namespace SlotKingdoms
{
    public enum EpochLoginType
    {
        None = 0,
        Init,
        InitFailed,
        LoggingIn,
        LoggedIn,
        LoginFailed,
        FacebookLoggingIn,
        FacebookLoggedIn,
        FacebookLoginFailed
    }

    public enum GameLoginType
    { 
        None = 0,
        LoggingIn,
        LoggedIn,
        LoginFailed,
        NeedEpochLogin,
    }

    public enum LinkPlatform
    {
        Facebook,
        Apple
    }

    public enum FirstLoginType
    {
        None,
        Guest,
        Facebook,
        Apple
    }

    public class AccountSystem : Singleton<AccountSystem>
    {
        public Func<string, string, Action<LoginResponse>, IRequest<LoginResponse>> LoginFunc
        {
            private get;
            set;
        }

        public string Pid
        {
            get;
            private set;
        }
        public string AccessToken
        {
            get;
            private set;
        }

        public bool IsInited
        {
            get => EpochLoginState.CurrState != EpochLoginType.None;
        }

        public bool IsInEpochInit
        {
            get => EpochLoginState.CurrState == EpochLoginType.Init;
        }

        public bool IsEpochInitFailed
        {
            get => EpochLoginState.CurrState == EpochLoginType.InitFailed;
        }

        public bool IsEpochLoginRequired
        {
            get
            {
                EpochLoginType currState = EpochLoginState.CurrState;
                return currState == EpochLoginType.LoggingIn
                       || currState == EpochLoginType.LoginFailed;
            }
        }

        public bool IsGameLoggingIn
        {
            get => (int)GameLoginState.CurrState <= (int)GameLoginType.LoggingIn;
        }

        public bool IsGameLoggedIn
        {
            get
            {
                GameLoginType currGameLoginState = GameLoginState.CurrState;
                return currGameLoginState == GameLoginType.LoggedIn;
            }
        }

        public EnumState<EpochLoginType> EpochLoginState
        {
            get;
            private set;
        } = new EnumState<EpochLoginType>(showLog: true);

        public EnumState<GameLoginType> GameLoginState
        {
            get;
            private set;
        } = new EnumState<GameLoginType>(showLog: true);

        private AuthResult authResult;
        private FirstLoginType firstLoginType;
        private bool isLinkedAnotherAccount;
        private Profiles loginProfilesData;

        public bool HasProviderInfo()
        {
            bool result = false;
            bool isLoggedIn = Epoch.Instance.IsLoggedIn();
            Debug.Log($"[AccountSystem.HasProviderInfo 1] {isLoggedIn}");
            if (isLoggedIn)
            {
                var providerInfos = Epoch.Instance.UserInfo.GetProviderList();
                Debug.Log($"[AccountSystem.HasProviderInfo 2] {providerInfos.Count}");
                foreach (ECProviderInfo info in providerInfos)
                {
                    result = true;
                    Debug.Log($"[AccountSystem.HasProviderInfo 3] {info.Name}");
                }
            }
            return result;
        }

        public void Init()
        {
            EpochLoginState.Set(EpochLoginType.Init);

            RuntimeTarget runtimeTarget = GameConfig.RuntimeTarget;
            DownloadPlatform downloadPlatform = runtimeTarget == RuntimeTarget.iOS ? DownloadPlatform.AppStore :
                                                runtimeTarget == RuntimeTarget.Android ? DownloadPlatform.GooglePlay :
                                                DownloadPlatform.MSStore;

            BuildType buildType = GameConfig.BuildType;
            Zone zone = buildType == BuildType.Real ? Zone.REAL :
                        (buildType == BuildType.QA || buildType == BuildType.Stage) ? Zone.QA :
                        Zone.DEV;

            EpochTimeZoneType timeZoneType = buildType == BuildType.Real || buildType == BuildType.QA || buildType == BuildType.Stage ? 
                                             EpochTimeZoneType.CST :
                                             EpochTimeZoneType.KST;

            EpochSettings settings = new EpochSettings();
            settings.SetPackageName(Application.identifier);
            settings.SetDownloadPlatform(downloadPlatform);
            settings.SetZone(zone);
            settings.SetTimeZoneInfo(timeZoneType);
            settings.SetAutoLogin(true);

            Epoch.Initialize(settings, result =>
            {
                if (result.IsSuccess())
                {
                    if (Epoch.Instance.IsLoggedIn())
                    {
                        LoginProcess(result.GetAuthResult());
                    }
                    else
                    {
                        EpochLoginState.Set(EpochLoginType.LoggingIn);
                    }
                }
                else
                {
                    EpochLoginState.Set(EpochLoginType.InitFailed);
                }
            });
        }

        public void Logout()
        {
            if (Epoch.Instance.IsLoggedIn())
            {
                Epoch.Instance.UserInfo.Logout(callback: (AuthResult autoResult) =>
                {
                    Debug.Log("[AccountSystem.Logout]");
                });
            }
        }

        public void PrepareLogin()
        {
            EpochLoginType epochLoginState = EpochLoginState.CurrState;
            if (epochLoginState == EpochLoginType.LoginFailed || epochLoginState == EpochLoginType.FacebookLoginFailed)
            {
                EpochLoginState.Set(EpochLoginType.LoggingIn);
            }

            GameLoginState.Set(GameLoginType.None);
        }

        public IEnumerator Login(FirstLoginType firstLoginType)
        {
            this.firstLoginType = firstLoginType;

            if (GameConfig.RuntimeTarget == RuntimeTarget.iOS
                || GameConfig.RuntimeTarget == RuntimeTarget.Android)
            {
                yield return EpochLogin();
                yield return GameLogin();
                SetFacebookProfile();
                ChatLogin();
            }
            else
            {
                Debug.LogError("UWP 플랫폼은 아직 Epoch 로그인을 지원하지 않습니다.");
            }

            yield break;
        }

        private IEnumerator EpochLogin()
        {
            Debug.Log("Epoch Login");
            while (EpochLoginState.CurrState == EpochLoginType.Init)
            {
                // 초기화 완료 대기
                yield return null;
            }

            if (EpochLoginState.CurrState == EpochLoginType.LoggingIn)
            {
                yield return GuestLogin();
            }
            
            if (EpochLoginState.CurrState == EpochLoginType.LoggedIn)
            {
                if (firstLoginType == FirstLoginType.Facebook)
                {
                    yield return FacebookLink();
                }
            }
        }

        private IEnumerator GuestLogin()
        {
            // 로그인 가능한 상태
            Auth.Login(
                authPlatform: AuthPlatform.Guest,
                resultCallBack: result =>
                {
                    LoginProcess(result);
                }
            );

            yield return new WaitUntil(() => EpochLoginState.CurrState != EpochLoginType.LoggingIn);
        }

        private IEnumerator GameLogin()
        {
            Debug.Log("GameLogin");

            if (EpochLoginState.CurrState == EpochLoginType.LoggedIn
                || EpochLoginState.CurrState == EpochLoginType.FacebookLoggedIn)
            {
                GameLoginState.Set(GameLoginType.LoggingIn);

                Pid = authResult.PlayFabId;
                AccessToken = authResult.SessionTicket;

                if (LoginFunc == null)
                {
                    LoginFunc = NetworkSystem.Login;
                }
                IRequest<LoginResponse> req = LoginFunc.Invoke(Pid, AccessToken, null);
                yield return req.WaitForResponse();

                bool isSuccess = req.IsSuccess;
                if (isSuccess)
                {
                    LoginData loginData = req.Data.data;
                    loginProfilesData = loginData.userProfiles;
                    SignalRInfo signalRInfo = loginData.signalRInfo;
                    if (signalRInfo != null)
                    {
                        NetworkSystem.ChatHandler.Pid = Pid;
                        NetworkSystem.ChatHandler.AccessToken = signalRInfo.accessToken;
                    }
                }

                GameLoginState.Set(isSuccess ? GameLoginType.LoggedIn : GameLoginType.LoginFailed);
            }
            else
            {
                GameLoginState.Set(GameLoginType.NeedEpochLogin);
            }
        }

        private void SetFacebookProfile()
        {
            Debug.Log($"SetFacebookProfile : {GameLoginState.CurrState}");
            if (GameLoginState.CurrState == GameLoginType.LoggedIn)
            {
                if (firstLoginType == FirstLoginType.Facebook)
                {
                    // 이미 페이스북에 연동된 계정으로 로그인하는 상황일 때는 SetProfile 호출하면 안 됨
                    if (ConsumeIsLinkedAnotherAccount() == false)
                    {
                        Debug.LogFormat($"FB.API(me)");
                        FB.API(
                            "me?fields=name,picture.height(240)",
                            HttpMethod.GET,
                            (IGraphResult result) =>
                            {
                                Debug.Log($"on FB.API(me)");
                                Debug.Log(result.RawResult);
                                if (string.IsNullOrEmpty(result.Error) && result.ResultDictionary != null)
                                {
                                    // 프로필 이름 표시
                                    string profileName = result.ResultDictionary["name"].ToString();

                                    // 프로필 이미지 로드
                                    IDictionary pictureData = (IDictionary)result.ResultDictionary["picture"];
                                    IDictionary pictureUrlData = (IDictionary)pictureData["data"];
                                    string imageUrl = pictureUrlData["url"].ToString();

                                    var profilesData = new Profiles();
                                    profilesData.imageType = eProfilesImageType.Url.ToString();
                                    profilesData.imageValue = imageUrl;
                                    profilesData.nickName = profileName;
                                    NetworkSystem.Requester.SetProfile(Pid, profilesData);
                                }
                                else
                                {
                                    Debug.LogError("Error getting profile info: " + result.Error);
                                }
                            }
                        );
                    }
                }
                else if (firstLoginType == FirstLoginType.Guest)
                {
                    var profilesData = new Profiles();
                    profilesData.imageType = eProfilesImageType.Index.ToString();
                    profilesData.imageValue = UnityEngine.Random.Range(1, ProfileIconLoader.Instance.Count+1).ToString(); // 1 부터 (현재는) 48 까지
                    profilesData.nickName = loginProfilesData.nickName;
                    NetworkSystem.Requester.SetProfile(Pid, profilesData);
                }
            }
        }

        private bool ConsumeIsLinkedAnotherAccount()
        {
            bool result = isLinkedAnotherAccount;
            isLinkedAnotherAccount = false;

            return result;
        }

        private void ChatLogin()
        {
            Debug.Log("Chat Login");
            if (GameLoginState.CurrState == GameLoginType.LoggedIn)
            {
                NetworkSystem.ChatHandler.InitAndConnectChat();
            }
        }

        private IEnumerator FacebookLink()
        {
            EpochLoginState.Set(EpochLoginType.FacebookLoggingIn);

            Platform Platform = firstLoginType == FirstLoginType.Facebook ? Platform.FaceBook :
                                firstLoginType == FirstLoginType.Apple ? Platform.IosApple :
                                Platform.None;
            Auth.Link(
                platform: Platform,
                _ResultCallBack: (LinkResult linkResult) =>
                {
                    if (linkResult.IsSuccess())
                    {
                        EpochLoginState.Set(EpochLoginType.FacebookLoggedIn);
                    }
                    // 로그인한 SNS 계정이 다른 계정에 연동돼있을 경우 해당 계정으로 로그인하는 프로세스
                    else if (linkResult.GetErrorCode() == Result.DetailCode.AlreadyLinkedAnotherAccount)
                    {
                        PopupSystem.Instance.OpenPopup<WarningPopup>().Init(
                            message: "", 
                            titleMessage: linkResult.GetMessage(),
                            useCloseButton: false,
                            onYes: () =>
                            {
                                Auth.LoginToAlreadyLinkedAnotherAccount(linkResult, (AuthResult loginResult) =>
                                {
                                    if (authResult.IsSuccess())
                                    {
                                        isLinkedAnotherAccount = true;
                                    }

                                    LoginProcess(loginResult);
                                });
                            },
                            onNo: () =>
                            {
                                EpochLoginState.Set(EpochLoginType.FacebookLoginFailed);
                            }
                        );
                    }
                    else
                    {
                        EpochLoginState.Set(EpochLoginType.FacebookLoginFailed);
                        Debug.LogWarning($"==== Epoch Link Fail, {linkResult.GetErrorCode()} / {linkResult.GetMessage()}");
                    }
                }
            );

            while (EpochLoginState.CurrState == EpochLoginType.FacebookLoggingIn)
            {
                yield return null;
            }
        }

        private void LoginProcess(AuthResult authResult)
        {
            if (authResult.IsSuccess())
            {
                this.authResult = authResult;
                EpochLoginState.Set(EpochLoginType.LoggedIn);
            }
            else
            {
                EpochLoginState.Set(EpochLoginType.LoginFailed);

                if (authResult.RestrictData != null)
                {
                    Debug.Log($"==== Epoch Authentication Fail, Restrict Data, " +
                              $"PID : {authResult.RestrictData.PID} / " +
                              $"RegistrationData : {authResult.RestrictData.registrationDate} / " +
                              $"RemainTimeForUnlock : {authResult.RestrictData.remainTimeForUnlock} / " +
                              $"WrongPasswordAttempt : {authResult.RestrictData.wrongPasswordAttempt}");
                }

                Debug.Log($"LoginProcess : {authResult.GetResultCode()}, {authResult.GetDetailCode()}, {authResult.GetMessage()}, {authResult.GetErrorCode()}");
                if (authResult.GetErrorCode() == Result.DetailCode.NotAvailableAccountForDormancy)
                {

                }
                else
                {
                    
                }
            }
        }
    }
}