using System;
using System.Collections.Generic;
using System.Linq;

using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace SlotKingdoms.Sound
{
    [Serializable]
    public class AudioItem
    {
        public string key;
        public AudioClip value;
    }

    public enum AudioPoolType
    {
        Single, KeyValue, List
    }

    public enum AudioTriggerType
    {
        None, OnEnable, OnDisable, MouseDown
    }

    public class FakeSoundPlayer : SoundPlayer
    {
        public override void Play()
        {

        }
    }

    public class SoundPlayer : MonoBehaviour, IPointerDownHandler
    {
        public AudioClip AudioClip
        {
            get { return audioItems[0].value; }
        }

        public AudioPoolType poolType;
        public List<AudioItem> audioItems = new List<AudioItem>() { new AudioItem() }; // 기본값으로 하나 넣어준다.

        public int depth = 0;
        public bool isBgm;
        public AudioTriggerType triggerType;
        public bool stopWhenDisabled = false;
        public SoundPlayType playType;
        public bool overlap = true;
        public bool overwrite = false;
        public float delay = 0f;
        public int repeat = 1;
        public float fadeIn = 0f;
        public float fadeOut = 0f;
        public float volume = 1f;
        public float pitch = 1f;
        public float freezing = 0f;

        public string Key
        {
            get; private set;
        }
        private UnityEvent OnEnabled
        {
            get
            {
                if (onEnabled == null) onEnabled = new UnityEvent();
                return onEnabled;
            }
        }
        private UnityEvent onEnabled;
        private UnityEvent OnDisabled
        {
            get
            {
                if (onDisabled == null) onDisabled = new UnityEvent();
                return onDisabled;
            }
        }
        private UnityEvent onDisabled;

        private UnityEvent OnMouseDowned
        {
            get
            {
                if (onMouseDowned == null) onMouseDowned = new UnityEvent();
                return onMouseDowned;
            }
        }
        private UnityEvent onMouseDowned;
        private float pauseTime;

        private Button button;

        #region Unity Method
        private void Awake()
        {
            Key = overwrite ?
                  $"sound_{gameObject.name}" :
                  $"sound_{gameObject.name}{GetInstanceID()}";
            button = GetComponent<Button>();
            AddListener();
        }

        private void OnDestroy()
        {
            RemoveListener();
        }

        private void OnEnable()
        {
            OnEnabled.Invoke();
        }

        private void OnDisable()
        {
            if (stopWhenDisabled)
            {
                Stop();
            }

            OnDisabled.Invoke();
        }
        #endregion

        #region Implemented Method
        public void OnPointerDown(PointerEventData eventData)
        {
            if (button != null)
            {
                // 활성화된 버튼일 때만 사운드 플레이
                if (button.interactable == true)
                {
                    OnMouseDowned.Invoke();
                }
            }
            else
            {
                OnMouseDowned.Invoke();
            }
        }
        #endregion

        #region Custom Method
        private void AddListener()
        {
            switch (triggerType)
            {
                case AudioTriggerType.OnEnable:
                    OnEnabled.AddListener(Play);
                    break;

                case AudioTriggerType.OnDisable:
                    OnDisabled.AddListener(Stop);
                    break;

                case AudioTriggerType.MouseDown:
                    OnMouseDowned.AddListener(Play);
                    break;
            }
        }

        private void RemoveListener()
        {
            switch (triggerType)
            {
                case AudioTriggerType.OnEnable:
                    OnEnabled.RemoveListener(Play);
                    break;

                case AudioTriggerType.OnDisable:
                    OnDisabled.RemoveListener(Stop);
                    break;

                case AudioTriggerType.MouseDown:
                    OnMouseDowned.RemoveListener(Play);
                    break;
            }
        }
        
        public void PlayWithAudioKey(string audioKey)
        {
            AudioItem found = audioItems.FirstOrDefault((AudioItem audioItem) => audioItem.key == audioKey);
            if (found == null) return;
            
            Stop();
            Play(found.value);
        }

        public void PlayWithDuration(float duration)
        {
            if (duration > 0)
            {
                Play(AudioClip, delay, duration, null);
            }
            else
            {
                Stop();
            }
        }

        public void PlayWithDelay(float delay)
        {
            Play(AudioClip, delay, 0.0f, null);
        }

        public void PlayWithPitch(float pitch)
        {
            Play(AudioClip, delay, 0.0f, pitch);
        }

        public virtual void Play()
        {
            Play(AudioClip, delay, 0.0f, null);
        }

        private void Play(AudioClip audioClip)
        {
            Play(audioClip, delay, 0.0f, null);
        }

        private void Play(AudioClip audioClip, float delay, float duration, float? overridePitch, float time = 0)
        {
            // overwrite가 체크되면 플레이 중인 같은 이름의 사운드를 멈추고 다시 플레이를 시작합니다.
            if (overwrite == true && IsInPlay() == true)
            {
                SoundSystem.Instance.Stop(Key, fadeOut);
            }

            if (overlap == true || IsInPlay() == false)
            {
                SoundSystem.Instance.Play(Key, 
                                          audioClip, 
                                          playType, 
                                          delay, 
                                          repeat, 
                                          fadeIn, 
                                          fadeOut, 
                                          duration, 
                                          depth, 
                                          isBgm, 
                                          volume, 
                                          overridePitch == null ? pitch : overridePitch.Value, 
                                          freezing,
                                          time);
            }
        }

        public void Stop()
        {
            SoundSystem.Instance.Stop(Key, fadeOut);
        }

        public void Pause()
        {
            var source = SoundSystem.Instance.GetAudioSource(Key);
            if( source != null )
            {
                pauseTime = source.time;
            }

            SoundSystem.Instance.Stop(Key, fadeOut);
        }

        public void Resume()
        {
            Play(AudioClip, delay, 0.0f, null, pauseTime);
            pauseTime = 0;
        }

        public void ChangeVolume(float value)
        {
            SoundSystem.Instance.ChangeVolume(Key, value);
        }

        public void ChangeMasterVolume(float value)
        {
            if (isBgm == true)
            {
                SoundSystem.Instance.BgmVolume = value;
            }
            else
            {
                SoundSystem.Instance.SfxVolume = value;
            }
        }

        public void ChangePitch(float value, float duration)
        {
            SoundSystem.Instance.ChangePitch(Key, value, duration);
        }

        public bool IsInPlay()
        {
            return SoundSystem.Instance.IsInPlay(Key);
        }
        #endregion
    }
}