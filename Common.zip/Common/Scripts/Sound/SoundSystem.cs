using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

using UnityEngine;

namespace SlotKingdoms.Sound
{
    public enum AudioLatency
    {
        BestLatency = 256, Default = 512, BestPerformance = 1024
    }

    [Flags]
    public enum SoundProofDepthType
    {
        None= 0,
        Bgm = 1,
        Sfx = 2,
    }

    public struct SoundProofDepthInfo
    {
        public int value;
        public SoundProofDepthType type;

        public SoundProofDepthInfo(int value, SoundProofDepthType type)
        {
            this.value = value;
            this.type = type;
        }
    }

    public class SoundSystem : GameObjectSingleton<SoundSystem>
    {
        public float BgmVolumeLimit 
        { 
            private get
            {
                return bgmVolumeLimit;
            } 
            set
            {
                bgmVolumeLimit = value;
                BgmVolume = value;
            } 
        }

        private float bgmVolumeLimit;
        public float BgmVolume
        {
            set
            {
                value = Mathf.Clamp(value, 0, BgmVolumeLimit);
                if (bgmVolume != value)
                {
                    bgmVolume = value;
                    ChangeMasterVolume(isBgm: true, value: bgmVolume);
                }
            }
        }

        public float SfxVolumeLimit 
        { 
            private get
            {
                return sfxVolumeLimit; 
            }
            set
            {
                sfxVolumeLimit = value;
                SfxVolume = value;
            }
        }
        private float sfxVolumeLimit;
        public float SfxVolume
        {
            set
            {
                value = Mathf.Clamp(value, 0, SfxVolumeLimit);
                if (sfxVolume != value)
                {
                    sfxVolume = value;
                    ChangeMasterVolume(isBgm: false, value: sfxVolume);
                }
            }
        }

        private const int INITIAL_POOL_SIZE = 10;

        [SerializeField] private float bgmVolume = 1;
        [SerializeField] private float sfxVolume = 1;

        private GameObjectPool<AudioSource> audioSourcePool;
        private GameObject poolRoot;
        private GameObject inPlaying;
        private Coroutine wholeFade;
        [SerializeField] private List<SoundInfo> soundsInPlay;
        private List<SoundInfo> soundsInFade;

        [SerializeField] private List<SoundProofDepthInfo> soundproofDepthInfos;
        private HashSet<string> fadeOutList;

        private void Awake()
        {
            Initialize();
            AudioSettings.OnAudioConfigurationChanged += OnAudioConfigurationChanged;
        }

        private void OnAudioConfigurationChanged(bool deviceWasChanged)
        {
            Debug.Log(deviceWasChanged ? "==== Device was changed" : "==== Reset was called");
            
        }

        public void Initialize()
        {
            if (poolRoot != null)
            {
                return;
            }

            poolRoot = new GameObject("AudioSourcePool");
            poolRoot.transform.SetParent(transform);

            inPlaying = new GameObject("InPlaying");
            inPlaying.transform.SetParent(poolRoot.transform);

            audioSourcePool = new GameObjectPool<AudioSource>(
                root: poolRoot,
                size: INITIAL_POOL_SIZE,
                create: CreateAudioSource,
                autoPooling: true,
                autoActivating: true
            );

            soundsInPlay = new List<SoundInfo>();
            soundsInFade = new List<SoundInfo>();
            fadeOutList = new HashSet<string>();

            soundproofDepthInfos = new List<SoundProofDepthInfo>();
        }

        private AudioSource CreateAudioSource()
        {
             var container = new GameObject("AudioSource");
            container.transform.SetParent(poolRoot.transform);

            var audioSource = container.AddComponent<AudioSource>();
            return audioSource;
        }

        public bool IsInPlay(string key)
        {
            return soundsInPlay.Exists((SoundInfo sound) => sound.key == key);
        }

        public void Play(string key,
                         AudioClip audioClip,
                         SoundPlayType type = SoundPlayType.Once,
                         float delay = 0f,
                         int repeat = 1,
                         float fadeIn = 0f,
                         float fadeOut = 0f,
                         float duration = 0f,
                         int depth = 0,
                         bool isBgm = false,
                         float volume = 1f,
                         float pitch = 1f,
                         float freezing = 0f,
                         float time = 0f)
        {
            if (audioClip == null) return;
            // 같은 사운드가 지정한 시간 안에 여러번 플레이되는 것을 방지
            if (soundsInPlay.Exists((SoundInfo sound) => (sound.timestamp + freezing) >= Time.time && sound.key == key) == false)
            {
                _Play(key,
                      audioClip,
                      type,
                      delay,
                      repeat,
                      fadeIn,
                      fadeOut,
                      duration,
                      depth,
                      isBgm,
                      volume,
                      pitch,
                      time);
            }
        }

        private void _Play(string key,
                           AudioClip audioClip,
                           SoundPlayType type = SoundPlayType.Once,
                           float delay = 0f,
                           int repeat = 1,
                           float fadeIn = 0f,
                           float fadeOut = 0f,
                           float duration = 0f,
                           int depth = 0,
                           bool isBgm = false,
                           float volume = 1f,
                           float pitch = 1f,
                           float time = 0f)
        {
            AudioSource audioSource = audioSourcePool.Get();
            while (audioSource == null)
            {
                audioSource = audioSourcePool.Get();
            }
            audioSource.transform.SetParent(inPlaying.transform);
            audioSource.time = time;
            audioSource.playOnAwake = false;
            audioSource.clip = audioClip;
            audioSource.gameObject.name = audioClip.name;
            audioSource.loop = type == SoundPlayType.Loop || repeat > 1;
            audioSource.pitch = pitch;

            var sound = new SoundInfo();
            sound.key = key;
            sound.timestamp = Time.time;
            sound.type = type;
            sound.audioSource = audioSource;
            sound.volume = volume;
            sound.masterVolume = isBgm == true ? bgmVolume : sfxVolume;
            sound.repeat = repeat;
            sound.duration = duration;
            sound.depth = depth;
            sound.isBgm = isBgm;
            sound.fadeOut = fadeOut;
            sound.depthType = isBgm ? SoundProofDepthType.Bgm : SoundProofDepthType.Sfx;
            if (sound.isBgm == true)
            {
                SoundInfo found = soundsInPlay.FirstOrDefault((SoundInfo finding) => finding.isBgm == true);
                if (found != null) Stop(found);
            }

            soundsInPlay.Add(sound);

            sound.play = StartCoroutine(PlayCoroutine(sound, delay, fadeIn));
        }

        public void FadeOutWhenDestroyed(string key)
        {
            if (fadeOutList.Contains(key) == false)
            {
                fadeOutList.Add(key);
            }
        }

        public void StopAll()
        {
            for (int i = soundsInPlay.Count - 1; i >= 0; i--)
            {
                SoundInfo sound = soundsInPlay[i];
                if (fadeOutList.Contains(sound.key))
                {
                    Stop(key: sound.key, fadeOut: 0.4f);
                }
                else
                {
                    if (sound.play != null)
                    {
                        StopCoroutine(sound.play);
                        sound.play = null;
                    }

                    Return(sound.audioSource);
                    soundsInPlay.RemoveAt(i);
                }
            }
        }

        // 같은 사운드를 모두 정지
        public void Stop(string key, float fadeOut = 0f)
        {
            for (int i = soundsInPlay.Count - 1; i >= 0; i--)
            {
                SoundInfo sound = soundsInPlay[i];
                if (sound.key != key) continue;

                soundsInPlay.RemoveAt(i);

                if (sound.audioSource != null)
                {
                    StartCoroutine(StopCoroutine(sound, fadeOut));
                }
            }
        }

        private void Return(AudioSource audioSource)
        {
            if (audioSource != null)
            {
                audioSource.Stop();
                audioSource.transform.SetParent(poolRoot.transform);
                audioSource.gameObject.name = "AudioSource";
                audioSourcePool.Return(audioSource);
            }
        }

        public void StopBGM(float fadeOut = 1f)
        {
            SoundInfo found = soundsInPlay.FirstOrDefault((SoundInfo finding) => finding.isBgm == true);
            if (found != null)
            {
                Stop(key: found.key, fadeOut: fadeOut);
            }
        }

        public void PauseAll()
        {
            foreach (SoundInfo soundInfo in soundsInPlay)
            {
                AudioSource audioSource = soundInfo.audioSource;
                if (audioSource.isPlaying)
                {
                    soundInfo.audioSource.Pause();
                }
            }
        }

        public void ResumeAll()
        {
            foreach (SoundInfo soundInfo in soundsInPlay)
            {
                AudioSource audioSource = soundInfo.audioSource;
                if (audioSource.isPlaying == false)
                {
                    soundInfo.audioSource.UnPause();
                }
            }
        }

        public void DebugAll()
        {
            foreach (SoundInfo soundInfo in soundsInPlay)
            {
                DebugSoundInfo(soundInfo);
            }
        }

        private void DebugSoundInfo(SoundInfo soundInfo)
        {
            AudioSource audioSource = soundInfo.audioSource;
            Debug.Log("==== DebugSoundInfo");
            Debug.Log($"mute : {audioSource.mute}\n" +
                      $"bypassEffects : {audioSource.bypassEffects}\n" +
                      $"bypassListenerEffects : {audioSource.bypassListenerEffects}\n" +
                      $"bypassReverbZones : {audioSource.bypassReverbZones}\n" +
                      $"priority : {audioSource.priority}\n" +
                      $"volume : {audioSource.volume}\n" +
                      $"pitch : {audioSource.pitch}\n" +
                      $"panStereo : {audioSource.panStereo}\n" +
                      $"spatialBlend : {audioSource.spatialBlend}\n" +
                      $"reverbZoneMix : {audioSource.reverbZoneMix}\n" +
                      $"dopplerLevel : {audioSource.dopplerLevel}\n" +
                      $"spread : {audioSource.spread}\n" +
                      $"rolloffMode : {audioSource.rolloffMode}\n" +
                      $"minDistance : {audioSource.minDistance}\n" +
                      $"maxDistance : {audioSource.maxDistance}");
        }

        public AudioSource GetAudioSource(string key)
        {
            for (int i = soundsInPlay.Count - 1; i >= 0; i--)
            {
                SoundInfo sound = soundsInPlay[i];
                if (sound.key == key)
                {
                    return sound.audioSource;
                }
            }

            return null;
        }

        // 해당 사운드만 정지
        private void Stop(SoundInfo sound)
        {
            int foundIndex = soundsInPlay.FindIndex((SoundInfo finding) => finding == sound);
            if (foundIndex != -1)
            {
                soundsInPlay.RemoveAt(foundIndex);

                if (sound.audioSource != null)
                {
                    // BGM이 전환될 때 FadeOut 되면서 이명같이 불편한 느낌이 들어 sound.fadeOut에서 0으로 바꿈
                    StartCoroutine(StopCoroutine(sound, 0)); 
                }
            }
        }

        private IEnumerator StopCoroutine(SoundInfo sound, float fadeOut)
        {
            sound.fade = StartCoroutine(FadeVolumeCoroutine(audioSource: sound.audioSource,
                                                            duration: fadeOut,
                                                            valueBegin: FilterSoundproof(sound),
                                                            valueEnd: 0));
            yield return sound.fade;
            sound.fade = null;

            if (sound.play != null)
            {
                StopCoroutine(sound.play);
                sound.play = null;
            }

            Return(sound.audioSource);
        }

        private IEnumerator PlayCoroutine(SoundInfo sound, float delay, float fadeIn)
        {
            if (delay > 0)
            {
                yield return new WaitForSeconds(delay);
            }

            if (sound.audioSource != null)
            {
                sound.audioSource.Play();
            }

            float timeBegin = Time.time;
            float fadeInDuration = fadeIn;
            if( sound.duration > 0 && fadeInDuration > sound.duration)
            {
                fadeInDuration = sound.duration;
            }
            
            if (fadeIn > 0)
            {
                var startTime = Time.time;
                sound.fade = StartCoroutine(FadeVolumeCoroutine(audioSource: sound.audioSource,
                                                                duration: fadeInDuration,
                                                                valueBegin: 0,
                                                                valueEnd: FilterSoundproof(sound)));
                yield return sound.fade;
                sound.fade = null;
            }
            else
            {
                ChangeAudioVolume(sound.audioSource, FilterSoundproof(sound));
            }

            if (sound.type == SoundPlayType.Loop)
            {
                while (true)
                {
                    float timePassed = Time.time - timeBegin;
                    // Loop 타입이라도 정해진 duration이 있다면 딱 그 만큼만 플레이 하고 탈출
                    if (sound.duration > 0 && timePassed > sound.duration)
                    {
                        break;
                    }
                    
                    yield return null;
                }
            }
            else
            {
                while (sound.repeat > 0)
                {
                    float timePassed = Time.time - timeBegin;

                    if ((sound.duration > 0 && timePassed > sound.duration) 
                        || (sound.audioSource != null && timePassed > sound.audioSource.clip.length))
                    {
                        timeBegin = Time.time;
                        sound.repeat -= 1;
                        if (sound.audioSource != null && sound.repeat > 0)
                        {
                            sound.audioSource.time = 0;
                        }

                        yield return null;
                    }

                    yield return null;
                }
            }
            
            Stop(sound);
        }


        public void TurnDownWholeVolume(int depth, 
                                        float duration, 
                                        float turnDownVolume = 0.0f, 
                                        SoundProofDepthType depthType = SoundProofDepthType.Bgm | SoundProofDepthType.Sfx)
        {
            soundproofDepthInfos.Add(new SoundProofDepthInfo(depth, depthType));
            soundproofDepthInfos.OrderByDescending(info => info.value);

            FadeWholeVolume(duration: duration, 
                            delay: 0.0f, 
                            filteredVolume: turnDownVolume,
                            depthType: depthType);
        }

        public void RestoreWholeVolume(int depth, 
                                       float duration, 
                                       float delay, 
                                       SoundProofDepthType depthType = SoundProofDepthType.Bgm | SoundProofDepthType.Sfx)
        {
            soundproofDepthInfos.Remove(new SoundProofDepthInfo(depth, depthType));

            FadeWholeVolume(duration: duration, 
                            delay: delay,
                            filteredVolume: 0f,
                            depthType: depthType);
        }

        private void FadeWholeVolume(float duration, 
                                     float delay = 0f, 
                                     float filteredVolume = 0.0f, 
                                     SoundProofDepthType depthType = SoundProofDepthType.Bgm | SoundProofDepthType.Sfx)
        {
            soundsInFade.Clear();
            foreach (SoundInfo sound in soundsInPlay)
            {
                float volumeEnd = FilterSoundproof(sound, filteredVolume);

                if (sound.audioSource == null
                    || sound.audioSource.volume == volumeEnd // 볼륨이 같으면 스킵
                    || (sound.depthType & depthType) == 0)   // DepthType 이 겹치지 않으면 스킵
                {
                    continue;
                }

                if (sound.fade != null)
                {
                    StopCoroutine(sound.fade);
                    sound.fade = null;
                }

                soundsInFade.Add(sound);

                sound.volumeBegin = sound.audioSource.volume;
                sound.volumeEnd = volumeEnd;
                sound.volumeDiff = sound.volumeEnd - sound.volumeBegin;
            }

            if (soundsInFade.Count > 0)
            {
                if (wholeFade != null)
                {
                    StopCoroutine(wholeFade);
                }
                wholeFade = StartCoroutine(FadeWholeVolumeCoroutine(duration, delay));
            }
        }

        public void ChangeVolume(string key, float volume)
        {
            int soundIndex = soundsInPlay.FindIndex((SoundInfo sound) => sound.key == key);
            if (soundIndex > -1)
            {
                SoundInfo sound = soundsInPlay[soundIndex];
                sound.volume = volume;

                ChangeAudioVolume(sound.audioSource, FilterSoundproof(sound));
            }
        }

        private IEnumerator FadeVolumeCoroutine(AudioSource audioSource, float duration, float valueBegin, float valueEnd)
        {
            float timeBegin = Time.time;
            float diff = valueEnd - valueBegin;
            ChangeAudioVolume(audioSource, valueBegin);
            while (true)
            {
                float timePassed = Time.time - timeBegin;
                if (timePassed >= duration)
                {
                    ChangeAudioVolume(audioSource, valueEnd);
                    break;
                }

                float progress = timePassed / duration;
                ChangeAudioVolume(audioSource, valueBegin + (diff * progress));
                yield return null;
            }
        }

        private void ChangeAudioVolume(AudioSource audioSource, float value)
        {
            if (audioSource != null)
            {
                audioSource.volume = value;
            }
        }

        private void ChangeAudioPitch(AudioSource audioSource, float value)
        {
            if (audioSource != null)
            {
                audioSource.pitch = value;
            }
        }

        private IEnumerator ChangePitchCoroutine(AudioSource audioSource, float valueEnd, float duration)
        {
            if (duration <= 0)
            {
                ChangeAudioPitch(audioSource, valueEnd);
                yield break;
            }

            float timeBegin = Time.time;
            float valueBegin = audioSource.pitch;
            float valueDiff = valueEnd - valueBegin;
            while (true)
            {
                float timePassed = Time.time - timeBegin;
                if (timePassed >= duration)
                {
                    ChangeAudioPitch(audioSource, valueEnd);
                    break;
                }

                float progress = timePassed / duration;
                ChangeAudioPitch(audioSource, valueBegin + (valueDiff * progress));
                yield return null;
            }
        }

        public void ChangePitch(string key, float pitch, float duration)
        {
            int soundIndex = soundsInPlay.FindIndex((SoundInfo sound) => sound.key == key);
            if (soundIndex > -1)
            {
                SoundInfo sound = soundsInPlay[soundIndex];
                if (sound.audioSource != null)
                {
                    StartCoroutine(ChangePitchCoroutine(sound.audioSource, pitch, duration));
                }
            }
        }

        private IEnumerator FadeWholeVolumeCoroutine(float duration, float delay)
        {
            yield return new WaitForSeconds(delay);

            float timeBegin = Time.time;
            while (true)
            {
                float timePassed = Time.time - timeBegin;
                if (timePassed >= duration)
                {
                    break;
                }
                
                float progress = timePassed / duration;
                foreach (SoundInfo sound in soundsInFade)
                {
                    ChangeAudioVolume(sound.audioSource, 
                                      sound.volumeBegin + (sound.volumeDiff * progress));
                }

                yield return null;
            }

            foreach (SoundInfo sound in soundsInFade)
            {
                ChangeAudioVolume(sound.audioSource, sound.volumeEnd);
            }

            wholeFade = null;
        }

        private void ChangeMasterVolume(bool isBgm, float value)
        {
            foreach (SoundInfo sound in soundsInPlay)
            {
                if (sound == null || sound.isBgm != isBgm) continue;

                sound.masterVolume = value;
                ChangeAudioVolume(sound.audioSource, FilterSoundproof(sound));
            }
        }

        private float FilterSoundproof(SoundInfo sound, float filteredVolume = 0.0f)
        {
            float originVolume = sound.volume * sound.masterVolume;
            return sound.depth >= GetHighestSoundproofDepth(sound) ?
                   originVolume : 
                   Mathf.Min(originVolume, filteredVolume);
        }

        private int GetHighestSoundproofDepth(SoundInfo sound)
        {
            int result = 0;
            foreach (SoundProofDepthInfo depthInfo in soundproofDepthInfos)
            { 
                if ((sound.depthType & depthInfo.type) > 0) // 뎁스 타입이 겹치는 첫번째 값을 리턴
                {
                    result = depthInfo.value;
                    break;
                }
            }

            return result;
        }

        [Serializable]
        private class SoundInfo
        {
            public string key;
            public float timestamp;

            // OnDestory 때 사라질 수 있는 게임 오브젝트
            public AudioSource audioSource;

            public Coroutine play;
            public Coroutine fade;
            public SoundPlayType type;
            
            public float masterVolume = 1f;
            public float volume = 1f;
            public float volumeBegin;
            public float volumeDiff;
            public float volumeEnd;
            public int repeat = 1;
            public float duration = 0f;
            public float fadeOut = 0f;

            public int depth;        
            public bool isBgm = false;
            public SoundProofDepthType depthType;
        }
    }

    public enum SoundPlayType
    {
        Once, Loop,
    }
}
