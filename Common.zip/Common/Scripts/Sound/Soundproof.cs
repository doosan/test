using UnityEngine;

namespace SlotKingdoms.Sound
{
    public class Soundproof : MonoBehaviour
    {
        #pragma warning disable 0649
        [SerializeField] private SoundPlayer targetSound;
        [SerializeField] private int depth = 1;
        [SerializeField] private float fadeOut = 0.1f;
        [SerializeField] private float fadeIn = .35f;
        [SerializeField] private float delayToRestore = .4f;
        [SerializeField, Range(0.0f, 1.0f)] private float volume = 0.0f;
#pragma warning restore 0649

        private bool needToRestore = false;

        private void OnEnable()
        {
            if (gameObject.transform.parent == null)
            {
                // 부모가 없으면 막 생성된 인스턴스 이므로 작업을 수행하지 않는다. 
                // e.g. Pool에 캐싱된 팝업들
                return;
            }

            needToRestore = true;

            SoundSystem.Instance.TurnDownWholeVolume(depth, fadeOut, volume);
            if (targetSound != null)
            {
                Invoke("OnDisable", targetSound.AudioClip.length);
            }
        }

        private void OnDisable()
        {
            Restore();
        }

        public void Restore()
        {
            if (needToRestore == true)
            {
                needToRestore = false;
                SoundSystem.Instance.RestoreWholeVolume(depth, fadeIn, delayToRestore);
            }
        }
    }
}