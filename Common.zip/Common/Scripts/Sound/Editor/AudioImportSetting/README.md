﻿# 모바일 최적화 된 오디오 파일 Import Setting 목록
- [Unity Audio Import Optimisation](https://www.gamasutra.com/blogs/ZanderHulme/20190107/333794/Unity_Audio_Import_Optimisation__getting_more_BAM_for_your_RAM.php#4) 포스팅을 따라서 Audio Import Setting 프리셋을 용도별로 저장해 보았습니다. 해당 포스트의 4. Suggested settings for mobile 항목과 세팅이 같은지 확인해 주세요.
- 아래 프리셋들은 자동화된 적용을 지원합니다. [Audio Import Settings 가이드](https://4ones1111.atlassian.net/wiki/spaces/2S/pages/488506575/Audio+Import+Settings) 문서를 참고해 주세요.

## 문서 정보
- 최초 작성일 : 2019년 5월 10일 금요일
- 최종 수정일 : 2019년 5월 14일 화요일
- 작성자 : 사업2실 박기용 (gypark@nm-4ones.com)

## Import Setting 목록 (Originals)
1. Dialogue : 대화음
2. Environmental long loops : 길게 반복되는 환경음
3. Environmental one-shots : 한번 실행되는 환경음
4. Foley : 효과음, 환경음 (발자국 소리, 옷이 펄럭이는 소리, 유리 깨지는 소리 등)
5. Footsteps : 발자국
6. Music (long pieces) : 음악 (긴 조각)
7. Music (stingers) : 음악 (짧게 찌르는?)
8. Non-dialogue vocalisations : 대화가 아닌 음성
9. Special FX (long) : 특수 효과 (긴 것)
10. Special FX (short) : 특수 효과 (짧은 것)
11. UI sounds (long) : UI 사운드 (긴 것)
12. UI sounds (short) : UI 사운드 (짧은 것)

## 분류 예시 (Slot 1. Musketeers)
- 6. Music (long pieces)
  - sound_bgm
  - sound_bgm_freespin
- 9. Special FX (long)
  - sound_bgm_jackpot
  - sound_effect_chain_burning
  - sound_effect_freespin_result
  - sound_effect_jackpot_popup
- 10. Special FX (short)
  - sound_effect_bigwin_popup
  - sound_effect_coin_adding
  - sound_effect_scatter_appeared
  - sound_effect_scatter_flash1
  - sound_effect_scatter_flash2
  - sound_effect_stacked_sword1
  - sound_effect_stacked_sword2
- 12. UI sounds (short)
  - sound_effect_button_down
  - sound_effect_spin_stops