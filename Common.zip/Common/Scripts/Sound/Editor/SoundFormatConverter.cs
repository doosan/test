using UnityEditor;
using UnityEngine;
using System.IO;
using System.Collections.Generic;
using System.Text;


#if UNITY_EDITOR_WIN
namespace SlotKingdoms
{
    public class SoundFormatConverter : EditorWindow
    {
        private string selectFolderPath = string.Empty;
        private int progressCurrentCount = 0;
        private int progressTotalCount = 0;
        private int fileCount = 0;
        private int existfileCount = 0;
        private List<FolderInfo> folderList = new List<FolderInfo>();
        private Vector2 scrollPos = new Vector2();
        private bool disableConvert = true;
        private bool allowOverwrite = false;

        private GUIStyle noticeStyle = new GUIStyle();
        private GUIStyle normalStyle = new GUIStyle();
        private GUIStyle completeStyle = new GUIStyle();
        private GUIStyle existStyle = new GUIStyle();

        private readonly string[] extensions = new[] { "*.mp3", "*.wav" };
        private readonly string ASSETS_NAME = "Assets";
        private readonly string[] originExtensions = new[] { ".ogg", ".mp3", ".wav" };       
        private readonly string META_NAME = ".meta";

        private class FolderInfo
        {
            public string root = string.Empty;
            public List<string> files = new List<string>();

            public bool RootMatch(string root)
            {
                if (root == this.root)
                {
                    return true;
                }
                return false;
            }
        }

        [MenuItem("Tools/SoundFormatConverter")]
        private static void ShowWindow()
        {
            EditorWindow.GetWindow<SoundFormatConverter>();
        }

        private void Awake()
        {
            noticeStyle.alignment = TextAnchor.MiddleLeft;
            noticeStyle.normal.textColor = Color.white;
            noticeStyle.fontSize = 14;

            normalStyle.normal.textColor = Color.red;
            normalStyle.fontStyle = FontStyle.Normal;
            normalStyle.fontSize = 11;

            completeStyle.normal.textColor = Color.grey;
            completeStyle.fontStyle = FontStyle.Italic;
            completeStyle.fontSize = 11;

            existStyle.normal.textColor = Color.green;
            existStyle.fontStyle = FontStyle.Italic;
            existStyle.fontSize = 11;
        }
        
        private void OnGUI()
        {
            EditorUtility.ClearProgressBar();

            SelectLocalSoundPath();
            disableConvert = true;

            if (string.IsNullOrEmpty(selectFolderPath) == false)
            {               
                GUILayout.Space(10);
                EditorGUILayout.LabelField(string.Empty, GUI.skin.horizontalSlider);
                
                DrawFileInfo();
                GUILayout.Space(10);
                EditorGUILayout.LabelField(string.Empty, GUI.skin.horizontalSlider);

                if (fileCount > 0)
                {
                    disableConvert = false;
                }
            }
            
            //---------------------------------------------------------------------
           
            EditorGUILayout.BeginHorizontal();

            EditorGUI.BeginDisabledGroup(disableConvert);
            if (GUILayout.Button("Convert", GUILayout.Width(250), GUILayout.Height(50)))
            {
                progressTotalCount = (allowOverwrite) ? (fileCount + existfileCount) : fileCount;
                if (EditorUtility.DisplayDialog("Sound File Convert", string.Format("총 {0}개의 파일을 변환합니다.", progressTotalCount), "yes", "no"))
                {
                    ConvertSoundFile();
                }
            }
            
            GUILayout.Space(10);
            EditorGUILayout.BeginVertical();
            GUILayout.Space(10);
            
            allowOverwrite = EditorGUILayout.ToggleLeft("파일 덮어쓰기 허용", allowOverwrite);
            if(allowOverwrite)
            {
                GUILayout.Label("변환 가능한 파일 갯수 : " + (fileCount + existfileCount), noticeStyle);
            }
            else
            {
                GUILayout.Label("변환 가능한 파일 갯수 : " + fileCount, noticeStyle);
            }

           
            EditorGUILayout.EndVertical();

            if(GUILayout.Button("Copy"))
            {
                CopyClipboard();
            }

            EditorGUI.EndDisabledGroup();
            EditorGUILayout.EndHorizontal();
            
            //---------------------------------------------------------------------

            GUILayout.Space(10);
        }

        private void ConvertSoundFile()
        {
            var directoryInfo = new DirectoryInfo(selectFolderPath);
            progressCurrentCount = 0;

            for (int extIndex = 0; extIndex < extensions.Length; extIndex++)
            {
                string extension = extensions[extIndex];
                FileInfo[] files = directoryInfo.GetFiles(extension, SearchOption.AllDirectories);

                for (int fileIndex = 0; fileIndex < files.Length; fileIndex++)
                {
                    var file = files[fileIndex];
                    string fromPath = file.FullName;
                    int assetIndex = fromPath.IndexOf(ASSETS_NAME) + ASSETS_NAME.Length;

                    // 유니티 내부 경로 변환 = Assets/.../Sounds/test.ogg , test.mp3
                    string changeFilePath = Application.dataPath + fromPath.Substring(assetIndex, fromPath.Length - assetIndex);

                     // 기존 경로 루트의 파일 검색
                    string originFilePath = GetOriginFileName(changeFilePath, extension);
                                       
                    if(string.IsNullOrEmpty(originFilePath))
                    {
                        Debug.Log("origin file is not found : " + changeFilePath);
                        continue;
                    }

                    // meta file 경로
                    string changeMetaPath = changeFilePath + META_NAME;
                    string originMetaPath = originFilePath + META_NAME;

                    // 0. 기존 사운드 파일과 변경하려는 사운드 파일 확장자가 같을 경우
                    if (File.Exists(changeFilePath))
                    {
                        // 덮어쓰기 허용 여부 
                        if (allowOverwrite == false)
                        {
                            continue;
                        }
                    }
                    else
                    {
                        // 1. 기존 사운드의 확장자 변환 ( file, (중요)meta )
                        File.Move(originFilePath, changeFilePath);
                        File.Move(originMetaPath, changeMetaPath);
                    }

                    // 2. 외부 파일 덮어쓰기
                    // Assets/.../...Sounds/test.mp3 overwrite
                    File.Copy(fromPath, changeFilePath, true);

                    // Progressing
                    AssetDatabase.Refresh();
                    OnProgress(file.FullName, file.Name, extension);
                }
            }
        }

        private void OnProgress(string fullName, string fileName, string extension)
        {
            progressCurrentCount++;
            float rate = (float)progressCurrentCount / (float)progressTotalCount;

            EditorUtility.DisplayProgressBar(
                string.Format("{0} converting {1}/{2}", extension, progressCurrentCount, progressTotalCount),
                fileName,
                rate);
        }

        private void SelectLocalSoundPath()
        {
            GUILayout.Space(10);
            EditorGUILayout.BeginHorizontal();
            GUILayout.Space(5);
           
            if (GUILayout.Button("폴더 선택", GUILayout.Width(200)))
            {
                selectFolderPath = EditorUtility.OpenFolderPanel("Select Sound Floder", "", "/");
                SetProgressCount();
            }

            GUILayout.Label("[현재 경로] " + selectFolderPath, EditorStyles.boldLabel);

            EditorGUILayout.EndHorizontal();
            GUILayout.Space(10);
        }

        private void DrawFileInfo()
        {
            if (selectFolderPath.Contains(ASSETS_NAME) == false)
            {
                GUILayout.Label("잘못된 경로");
                return;
            }

            EditorGUILayout.BeginVertical();

            scrollPos = EditorGUILayout.BeginScrollView(scrollPos, false, true);
            for (int index = 0; index < folderList.Count; index++)
            {
                var info = folderList[index];

                if (IsExistConvertFolder(info.root) == false)
                {
                    GUILayout.Label(string.Format("잘못된 경로 => {0}", info.root));
                    continue;
                }

                GUILayout.Label(string.Format("[{0}] {1}", index, info.root), EditorStyles.boldLabel);
                
                for (int fileIndex = 0; fileIndex < info.files.Count; fileIndex++)
                {
                    EditorGUILayout.BeginHorizontal();
                    GUILayout.Space(10);

                    var fullName = info.files[fileIndex];

                    if (IsExistConvertFile(fullName))
                    {
                        if (allowOverwrite)
                        {
                            GUILayout.Label("<Exist>" + string.Format(" - {0}", fullName), existStyle);
                        }
                        else
                        {
                            GUILayout.Label("<Complete>" + string.Format(" - {0}", fullName), completeStyle);
                        }
                    }
                    else
                    {
                        GUILayout.Label(string.Format(" - {0}", fullName), normalStyle);                        
                    }
                    EditorGUILayout.EndHorizontal();
                }
                
            }

            EditorGUILayout.EndScrollView();
            EditorGUILayout.EndVertical();
        }

        private void SetProgressCount()
        {
            fileCount = 0;
            existfileCount = 0;

            folderList.Clear();

            if (selectFolderPath.Contains(ASSETS_NAME) == false)
            {
                return;
            }
            
            var directoryInfo = new DirectoryInfo(selectFolderPath);
            int assetIndex = selectFolderPath.IndexOf(ASSETS_NAME);
            
            for (int extIndex = 0; extIndex < extensions.Length; extIndex++)
            {
                string extension = extensions[extIndex];
                FileInfo[] files = directoryInfo.GetFiles(extension, SearchOption.AllDirectories);
                
                for (int fileIndex = 0; fileIndex < files.Length; fileIndex++)
                {
                    string fileDir = files[fileIndex].DirectoryName;
                    fileDir = fileDir.Substring(assetIndex, fileDir.Length - assetIndex);
                  
                    if (IsExistConvertFolder(fileDir) == false)
                    {
                        continue;
                    }
                    
                    var info = folderList.Find(x => x.RootMatch(fileDir));

                    if (info == null)
                    {
                        info = new FolderInfo() { root = fileDir, files = new List<string>() };
                        folderList.Add(info);
                    }

                    string fullName = files[fileIndex].FullName;

                    info.files.Add(fullName);
                    
                    if (IsExistConvertFile(fullName))
                    {
                        existfileCount++;
                    }
                    else
                    {
                        fileCount++;
                    }                    
                }
            }
        }

        // 기존 경로 루트의 파일 검색
        private string GetOriginFileName(string changeFilePath, string changeExtension)
        {
            for (int i = 0; i < originExtensions.Length; i++)
            {
                string extension = originExtensions[i];
                string filePath = changeFilePath.Replace(changeExtension.Substring(1, changeExtension.Length - 1), extension);
                if(File.Exists(filePath))
                {
                    return filePath;
                }
            }

            return string.Empty;
        }

        private bool IsExistConvertFolder(string dirPath)
        {
            string path = Application.dataPath + dirPath;

            if(Directory.Exists(dirPath) == false)
            {
                return false;
            }

            return true;
        }

        private bool IsExistConvertFile(string fullPath)
        {
            int assetIndex = fullPath.IndexOf(ASSETS_NAME) + ASSETS_NAME.Length;
            string filePath = Application.dataPath + fullPath.Substring(assetIndex, fullPath.Length - assetIndex);
            
            if (File.Exists(filePath))
            {
                return true;
            }

            return false;
        }

        private void CopyClipboard()
        {
            var sb = new StringBuilder();

            sb.Append(string.Format("[총 파일 갯수 : {0}] [중복파일 갯수 : {1}]", (fileCount + existfileCount), existfileCount));
            sb.AppendLine();
            sb.AppendLine();

            for (int i = 0; i < folderList.Count; i++)
            {
                var info = folderList[i];

                sb.Append(info.root);
                sb.AppendLine();
                for (int rootIndex = 0; rootIndex < info.files.Count; rootIndex++)
                {
                    var file = info.files[rootIndex];
                    int slashIndex = file.LastIndexOf("\\") + 1;
                    string substringName = file.Substring(slashIndex, file.Length - slashIndex);
                    if (IsExistConvertFile(file))
                    {
                        sb.Append(" - " + substringName + " ----------------------------------------- <duplication>");                     
                    }
                    else
                    {
                        sb.Append(" - " + substringName);
                    }
                  
                    sb.AppendLine();
                }                
            }

            sb.ToString().CopyToClipboard();

            EditorUtility.DisplayDialog("Copy to Clipboard", "Complete Copy Text", "ok");
        }
    }
}
#endif
