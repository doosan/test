using UnityEditor;
using UnityEngine;

namespace SlotKingdoms.Sound
{
    [CustomEditor(typeof(SoundPlayer)), CanEditMultipleObjects]
    public class SoundPlayerInspector : UnityEditor.Editor
    {
        private SoundPlayer soundPlayer;

        private SerializedProperty audioItems;
        private SerializedProperty triggerType;
        private SerializedProperty stopWhenDisabled;
        private SerializedProperty overlap;
        private SerializedProperty overwrite;
        private SerializedProperty playType;
        private SerializedProperty repeat;
        private SerializedProperty delay;
        private SerializedProperty fadeIn;
        private SerializedProperty fadeOut;
        private SerializedProperty freezing;
        private SerializedProperty volume;
        private SerializedProperty pitch;
        private SerializedProperty isBgm;
        private SerializedProperty depth;

        private void OnEnable()
        {
            soundPlayer = (SoundPlayer)target;

            audioItems = serializedObject.FindProperty("audioItems");
            triggerType = serializedObject.FindProperty("triggerType");
            stopWhenDisabled = serializedObject.FindProperty("stopWhenDisabled");

            overlap = serializedObject.FindProperty("overlap");
            overwrite = serializedObject.FindProperty("overwrite");

            playType = serializedObject.FindProperty("playType");
            repeat = serializedObject.FindProperty("repeat");

            delay = serializedObject.FindProperty("delay");
            fadeIn = serializedObject.FindProperty("fadeIn");
            fadeOut = serializedObject.FindProperty("fadeOut");
            freezing = serializedObject.FindProperty("freezing");
            volume = serializedObject.FindProperty("volume");
            pitch = serializedObject.FindProperty("pitch");
            isBgm = serializedObject.FindProperty("isBgm");
            depth = serializedObject.FindProperty("depth");
        }

        private void ResizeList()
        {
        }
        
        public override void OnInspectorGUI()
        {
            serializedObject.Update();

            this.DrawScript<SoundPlayer>();

            EditorGUILayout.Separator();
            if (soundPlayer.poolType == AudioPoolType.Single)
            {
                EditorGUILayout.PropertyField(audioItems.GetArrayElementAtIndex(0)
                                                        .FindPropertyRelative("value"), 
                                              new GUIContent("Audio Clip"));
            }
            EditorGUILayout.PropertyField(triggerType);
            EditorGUILayout.PropertyField(stopWhenDisabled);

            EditorGUILayout.Separator();
            EditorGUILayout.PropertyField(overlap);
            EditorGUILayout.PropertyField(overwrite);
            EditorGUILayout.PropertyField(playType);
            if (soundPlayer.playType == SoundPlayType.Once)
            {
                EditorGUILayout.PropertyField(repeat);
            }

            EditorGUILayout.PropertyField(delay);
            EditorGUILayout.PropertyField(fadeIn);
            EditorGUILayout.PropertyField(fadeOut);
            EditorGUILayout.PropertyField(freezing);

            EditorGUILayout.Separator();
            EditorGUILayout.PropertyField(volume);
            EditorGUILayout.PropertyField(pitch);
            EditorGUILayout.PropertyField(isBgm);

            EditorGUILayout.Separator();
            EditorGUILayout.PropertyField(depth);

            serializedObject.ApplyModifiedProperties();
        }
    }
}