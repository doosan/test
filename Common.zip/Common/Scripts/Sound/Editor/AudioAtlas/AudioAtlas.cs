using System;
using System.Collections.Generic;
using UnityEngine;

namespace SlotKingdoms.Editor
{
    [CreateAssetMenu(fileName = "AudioAtlas", menuName = "SlotKingdoms/Audio Atlas")]
    public class AudioAtlas : ScriptableObject
	{
		public AudioImportSetting[] audioImportSettings;
		public List<AudioList> audioLists = new List<AudioList>();
	}

	[Serializable]
	public class AudioList
	{
		public string name;
		public UnityEngine.Object[] assets;
	}
}
