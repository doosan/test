using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditorInternal;
using UnityEngine;

namespace SlotKingdoms.Editor
{
	[CustomEditor(typeof(AudioAtlas), true)]
	public class AudioAtlasInspector : UnityEditor.Editor 
	{
		private AudioAtlas audioAtlas;
		private ReorderableList settingList;

		private SerializedProperty audioListsProp;
		private Dictionary<int, ReorderableList> audioLists;

		private void OnEnable()
		{
			audioAtlas = (AudioAtlas)target;

			List<AudioImportSetting> settings = EditorResources.LoadAll<AudioImportSetting>("t:AudioImportSetting");
			if (settings != null)
			{
				audioAtlas.audioImportSettings = settings.ToArray();

				// 추가 또는 삭제를 통해 세팅 파일의 개수에 맞게 AudioList를 맞춤
				// 1-1. 
				for (int i = 0; i < audioAtlas.audioImportSettings.Length; i++)
				{
					AudioImportSetting setting = audioAtlas.audioImportSettings[i];
					AudioList finding = audioAtlas.audioLists
												  .FirstOrDefault((AudioList audioList) => audioList.name == setting.name);
					if (finding != null) continue;

					audioAtlas.audioLists.Insert(i, new AudioList() { name = setting.name });
				}

				// 1-2. 
				for (int i = audioAtlas.audioLists.Count - 1; i >= 0; i--)
				{
					AudioList audioList = audioAtlas.audioLists[i];
					AudioImportSetting finding = audioAtlas.audioImportSettings
														   .FirstOrDefault((AudioImportSetting setting) => setting.name == audioList.name);
					if (finding != null) continue;

					audioAtlas.audioLists.RemoveAt(i);
				}
			}
			
			settingList = new ReorderableList(serializedObject,
											  serializedObject.FindProperty("audioImportSettings"),
											  false, true, false, false);
			settingList.drawHeaderCallback = (Rect rect) =>
			{
				EditorGUI.LabelField(new Rect(rect.x, rect.y, rect.width, EditorGUIUtility.singleLineHeight), "Audio Import Settings");
			};
			settingList.drawElementCallback = (Rect rect, int index, bool isActive, bool isFocused) =>
			{
				if (index == 0) EditorGUILayout.Separator();

				GUI.enabled = false;
				SerializedProperty element = settingList.serializedProperty.GetArrayElementAtIndex(index);
				EditorGUI.PropertyField(rect, element, GUIContent.none);
				GUI.enabled = true;
				
				DrawAudioList(index, element.objectReferenceValue);
			};
			settingList.elementHeight = EditorGUIUtility.singleLineHeight;
			
			audioListsProp = serializedObject.FindProperty("audioLists");
			audioLists = new Dictionary<int, ReorderableList>();
		}

		public override void OnInspectorGUI()
		{
			serializedObject.Update();

			GUI.enabled = false;
			SerializedProperty property = serializedObject.FindProperty("m_Script");
			EditorGUILayout.PropertyField(property, includeChildren: true, options: new GUILayoutOption[0]);
			GUI.enabled = true;

			settingList.DoLayoutList();

			EditorGUILayout.Separator();
			if (GUILayout.Button("Apply"))
			{
				AudioAtlasApply.Do(audioAtlas);
			}

			serializedObject.ApplyModifiedProperties();
		}

		private void DrawAudioList(int settingIndex, Object target)
		{
			if (target == null || settingIndex >= audioListsProp.arraySize) return;

			if (audioLists.ContainsKey(settingIndex) == false)
			{
				SerializedProperty audioListProp = audioListsProp.GetArrayElementAtIndex(settingIndex);
				
				audioLists.Add(settingIndex, 
							   new ReorderableList(serializedObject,
												   audioListProp.FindPropertyRelative("assets"),
												   true, true, true, true));
			}

			ReorderableList audioList = audioLists[settingIndex];
			audioList.drawHeaderCallback = (Rect rect) =>
			{
				EditorGUI.LabelField(rect, target.name);
			};
			audioList.drawElementCallback = (Rect rect, int audioIndex, bool isActive, bool isFocused) =>
			{
				SerializedProperty element = audioList.serializedProperty.GetArrayElementAtIndex(audioIndex);
				if (rect.Contains(Event.current.mousePosition))
				{
					PerformDrag(element);
				}

				EditorGUI.BeginChangeCheck();
				EditorGUI.ObjectField(rect, element, GUIContent.none);
				if (EditorGUI.EndChangeCheck() && 
					element.objectReferenceValue != null && 
					IsObjectAcceptable(element.objectReferenceValue) == false)
				{
					element.objectReferenceValue = null;
				}
			};
			audioList.elementHeight = EditorGUIUtility.singleLineHeight;
			audioList.DoLayoutList();
		}

		private void PerformDrag(SerializedProperty element)
		{
			switch (Event.current.type)
			{
				case EventType.DragUpdated:
				case EventType.DragPerform:
					UnityEngine.Object draggingObject = (UnityEngine.Object)DragAndDrop.objectReferences[0];
					bool isAcceptableType = IsObjectAcceptable(draggingObject);
					DragAndDrop.visualMode = (isAcceptableType) ? 
											 DragAndDropVisualMode.Copy : 
											 DragAndDropVisualMode.Rejected;
					
					if (Event.current.type == EventType.DragPerform)
					{
						DragAndDrop.AcceptDrag();
						element.objectReferenceValue = draggingObject;
					}

					Event.current.Use();
				break;
			}
		}

		private bool IsObjectAcceptable(UnityEngine.Object target)
		{
			return target is AudioClip ||
				   (target is DefaultAsset && IsDirectory(target));
		}

		private bool IsDirectory(UnityEngine.Object target)
		{
			string filePath = AssetDatabase.GetAssetPath(target);
			FileAttributes attr = File.GetAttributes(filePath);
			return (attr & FileAttributes.Directory) == FileAttributes.Directory;
		}
	}
}
