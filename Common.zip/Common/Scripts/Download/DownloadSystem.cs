using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine.Networking;

namespace SlotKingdoms.Net
{
    public sealed class DownloadSystem : GameObjectSingleton<DownloadSystem>
    {
        public struct ID
        {
            public string value;
        }

        private class Task
        {
            public event Action<string> OnDownloadComplete;

            public string id;
            public bool enabled;
            public string url;
            public bool useCache;
            public Type type;
            public object callbackMethodTarget;
            public MethodInfo callbackMethodInfo;
            public int retryCount = 0;

            public void Done()
            {
                if( OnDownloadComplete != null )
                {
                    OnDownloadComplete(url);
                }
            }

            public void Reset()
            {
                enabled = false;
                OnDownloadComplete = null;
                callbackMethodTarget = null;
                callbackMethodInfo = null;
                retryCount = 0;
            }
        }

#if DEV // Dev 빌드에서는 웹 서버에 업로드 된 이미지 파일에 접근이 안되고 있어 재시도 횟수를 줄임
        private readonly int MAX_RETRY = 0;
#else
        private readonly int MAX_RETRY = 3;
#endif

        public event Action<string> OnStart;
        public event Action<string> OnSuccess;
        public event Action<string> OnFail;


        private ulong idCount;
        private ObjectPool<Task> taskPool;
        private List<Task> taskList;
        private object[] resourceParam;
        private bool isDownloading;
        private List<Task> tempTaskList;

        private Dictionary<string, Sprite> spriteCache;

        public void Initialize()
        {
            idCount = 10000;
            
            resourceParam = new object[1];
            taskList = new List<Task>();
            tempTaskList = new List<Task>();

            taskPool = new ObjectPool<Task>(10
                                            ,()=>
                                            {
                                                return new Task();
                                            });

            spriteCache = new Dictionary<string, Sprite>();
        }

        private ID CreateID()
        {
            if (idCount == ulong.MaxValue)
            {
                idCount = 10000;
            }

            idCount++;

            var id = new ID();
            id.value = idCount.ToString();
            return id;
        }

        public void Abort(ID id)
        {
            for (int i = 0; i < taskList.Count; i++)
            {
                var targetTask = taskList[i];

                if (targetTask.id == id.value)
                {
                    targetTask.enabled = false;
                    break;
                }
            }
        }

        public void AbortAll()
        {
            for (int i = 0; i < taskList.Count; i++)
            {
                var targetTask = taskList[i];
                targetTask.enabled = false;
            }
        }

        public bool HasCachedSprite(string url)
        {
            return string.IsNullOrEmpty(url) == false
                   && spriteCache.ContainsKey(url) == true;
        }
        
        public void RemoveCachedSprite(string url, bool destroyImmediate = true)
        {
            if (spriteCache.ContainsKey(url) == false )
            {
                return;
            }

            if (destroyImmediate)
            {
                var sprite = spriteCache[url];
                var tex = sprite.texture;
                Texture2D.DestroyImmediate(tex);
                GameObject.DestroyImmediate(sprite);

            }
            
            spriteCache.Remove(url);
        }


        public Sprite GetCachedSprite(string url)
        {
            return HasCachedSprite(url) ? spriteCache[url] : null;
        }

        public ID GetSprite(string url, Action<Sprite> onComplete, bool useCache = false)
        {
            if (useCache == true && HasCachedSprite(url) == true)
            {
                Debug.Log("==== GetSprite 1");
                onComplete(GetCachedSprite(url));
                return new ID();
            }
            else
            {
                Debug.Log("==== GetSprite 2");
                var id = AddTask<Sprite>(url, onComplete, useCache);
                StartDownload();
                return id;
            }
        }

        private ID AddTask<T>(string url, Action<T> onComplete, bool useCache) where T : UnityEngine.Object
        {
            if (string.IsNullOrEmpty(url))
            {
                onComplete.Invoke(null);
                return new ID();
            }

            var id = CreateID();

            var task = taskPool.Get();
            task.id = id.value;
            task.enabled = true;
            task.url = url;
            task.useCache = useCache;
            task.type = typeof(T);

            if (onComplete != null)
            {
                task.callbackMethodInfo = onComplete.Method;
                task.callbackMethodTarget = onComplete.Target;
            }

            taskList.Add(task);

            return id;
        }

        private void RemoveTask(Task task)
        {
            task.Reset();
            taskList.Remove(task);
            taskPool.Return(task);
        }

        private void StartDownload()
        {
            Debug.Log("==== StartDownload : " + isDownloading);
            if (isDownloading == true)
            {
                return;
            }

            StartCoroutine(DownloadCoroutine());
        }

        private IEnumerator DownloadCoroutine()
        {
            isDownloading = true;

            while (taskList.Count > 0)
            {
                var task = taskList[0];
                resourceParam[0] = null;

                if (task.enabled == false)
                {
                    RemoveTask(task);
                    continue;
                }

                Debug.Log("------------------------------------------------------------");
                if ( task.retryCount == 0 )
                {
                    Debug.LogFormat("Download Start - type : {0} , url : {1}", task.type, task.url);
                }
                else
                {
                    Debug.LogFormat("Download Retry - type : {0} , url : {1} retryCount: {2}", task.type, task.url, task.retryCount);
                }

                if (task.type == typeof(Sprite))
                {
                    yield return DownloadTexture(task, resourceParam);
                }

                if (task.enabled == false)
                {
                    Debug.LogFormat("Download Aborted");
                }
                else if (resourceParam[0] == null)
                {
                    Debug.LogFormat("Download Failed");
                    if (task.retryCount < MAX_RETRY)
                    {
                        task.retryCount++;
                        Debug.LogFormat("Download retry");
                        continue;
                    }
                    else
                    {
                        if( OnFail != null )
                        {
                            OnFail(task.url);
                        }
                    }
                }
                else
                {
                    Debug.LogFormat("Download Success");
                    if( OnSuccess != null )
                    {
                        OnSuccess(task.url);
                    }
                }

                for (int i = 0; i < taskList.Count; i++)
                {
                    var targetTask = taskList[i];

                    if (targetTask.url == task.url)
                    {
                        if (targetTask.enabled == true)
                        {
                            if (targetTask.callbackMethodInfo != null )
                            {
                                targetTask.callbackMethodInfo.Invoke(targetTask.callbackMethodTarget, resourceParam);
                            }

                            targetTask.Done();
                        }

                        tempTaskList.Add(targetTask);
                    }
                }

                for (int i = 0; i < tempTaskList.Count; i++)
                {
                    RemoveTask(tempTaskList[i]);
                }

                tempTaskList.Clear();
            }

            isDownloading = false;
        }

        private IEnumerator DownloadTexture(Task task, object[] returnVal)
        {
            using (UnityWebRequest uwr = UnityWebRequest.Get(task.url))
            {
                DownloadHandlerTexture textureHandler = new DownloadHandlerTexture(true);
                uwr.downloadHandler = textureHandler;
                uwr.timeout = 10;

                if (OnStart != null )
                {
                    OnStart(task.url);
                }

                yield return uwr.SendWebRequest();

                bool isFailed = uwr.result == UnityWebRequest.Result.ConnectionError || uwr.result == UnityWebRequest.Result.ProtocolError;
                if (isFailed == false && task.enabled == true)
                {
                    Texture2D tex2D = textureHandler.texture;
                    Sprite sprite = Sprite.Create(tex2D, new Rect(0,0,tex2D.width,tex2D.height), new Vector2(0.5f, 0.5f), 100);
                    returnVal[0] = sprite;

                    if (task.useCache == true)
                    {
                        spriteCache[task.url] = sprite;
                    }
                }
            }
        }

        public bool HasTask(string url)
        {
            return GetTask(url) != null;
        }

        private Task GetTask(string url)
        {
            Task found = null;
            for (int i = 0; i < taskList.Count; i++)
            {
                var task = taskList[i];
                if ( task.enabled == true && task.url == url )
                {
                    found = task;
                    break;
                }
            }

            return found;
        }

        public ID GetDownloadID(string url)
        {
            var id = new ID();
            var task = GetTask(url);
            if (task != null)
            {
                id.value = task.id;
            }

            return id;
        }

        public void AddTaskListener(string url, Action<string> downloadHandler)
        {
            if (downloadHandler == null)
            {
                return;
            }

            Task task = GetTask(url);
            if (task == null)
            {
                downloadHandler?.Invoke(url);
            }
            else
            {
                task.OnDownloadComplete += downloadHandler;
            }
        }

        public void LoadSprites(IEnumerable<string> urls, Action<string> onComplete = null)
        {
            foreach (var url in urls)
            {
                LoadSprite(url, onComplete);
            }
        }

        public void LoadSprite(string url, Action<string> onComplete = null)
        {
            if (HasCachedSprite(url) == true)
            {
                if (onComplete != null)
                {
                    onComplete.Invoke(url);
                }
                return;
            }

            if (HasTask(url) == false)
            {
                AddTask<Sprite>(url, null, true);
            }

            AddTaskListener(url, onComplete);
            StartDownload();
        }
    }
}