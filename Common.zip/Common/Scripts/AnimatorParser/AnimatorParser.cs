using System;
using UnityEngine;

namespace SlotKingdoms
{
	[Serializable]
	public class AnimatorParser : MonoBehaviour
	{
		public string Trigger
		{
			get
			{
				string result = "";

				if (animator != null && animation != null)
				{
					result = trigger;
				}

				return result;
			}
		}

		public float Duration
		{
			get
			{
				float result = 0f;

				if (animator != null)
				{
					if (animation != null)
					{
						result = animation.length;
					}

					// 1. 애니메이터의 마지막 트랜지션이 Exit 상태로 완전히 빠져나가는 것을 기다릴 목적으로
					// 2. 지난 두 프레임의 정도의 시간을 더해줍니다.
					result += (Time.deltaTime * 2);
				}
				
				// Debug.Log("=== Duration : " + result);
				return result;
			}
		}

		#pragma warning disable 0649
		#pragma warning disable 0109
		[SerializeField] private Animator animator;
		[SerializeField] private int animationIndex;
		[SerializeField] private new AnimationClip animation;
		[SerializeField] private int triggerIndex;
		[SerializeField] private string trigger;
		private WaitForSeconds waitForDuration;
		private float targetDuration;
		#pragma warning restore 0109
		#pragma warning restore 0649

		public void SetTrigger()
        {
			string trigger = Trigger;
			if (string.IsNullOrEmpty(trigger) == false)
			{
				animator.SetTrigger(Trigger);
			}
			else
			{
				Debug.LogError($"[AnimatorParser.SetTrigger] trigger 값이 null 입니다");
			}
        }

		public void SetTrigger(string trigger)
        {
			animator.SetTrigger(trigger);
        }

		public YieldInstruction WaitForDuration(float offset = 0f)
        {
			float targetDuration = Duration + offset;
			if (targetDuration < 0)
            {
				targetDuration = 0;
			}

			if (this.targetDuration != targetDuration)
            {
				waitForDuration = new WaitForSeconds(targetDuration);
				this.targetDuration = targetDuration;
			}

			return waitForDuration;
		}

		public bool ContainsParameter(string paramName)
		{
			for (int i = 0; i < animator.parameters.Length; i++)
			{
				var param = animator.parameters[i];

				if (param.name == paramName)
				{
					return true;
				}
			}
			
			return false;
		}
	}

	public enum AnimationDurationType
	{
		ByAnimation,
		ByTime
	}
}

