using System.Linq;

using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;

namespace SlotKingdoms.Editor
{
    [CustomEditor(typeof(AnimatorParser))]
    public class AnimatorParserInspector : UnityEditor.Editor
    {
        [SerializeField] private SerializedProperty animator;
        [SerializeField] private SerializedProperty animationIndex;
        [SerializeField] private SerializedProperty animation;
        [SerializeField] private SerializedProperty triggerIndex;
        [SerializeField] private SerializedProperty trigger;

        private void OnEnable()
        {
            animator = serializedObject.FindProperty("animator");
            animationIndex = serializedObject.FindProperty("animationIndex");
            animation = serializedObject.FindProperty("animation");
            triggerIndex = serializedObject.FindProperty("triggerIndex");
            trigger = serializedObject.FindProperty("trigger");
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            
            EditorGUILayout.PropertyField(animator);

            var animatorField = animator.objectReferenceValue as Animator;
            if (animatorField == null) { return; }

            // 애니메이터에 포함된 애니메이션 클립들을 추출해 선택 가능한 인스펙터 UI를 제공합니다.
            AnimationClip[] animationClips = animatorField.runtimeAnimatorController.animationClips;
            if (animationClips.Length > 0)
            {
                animationIndex.intValue = EditorGUILayout.Popup("Selected Animation",
                                                                animationIndex.intValue, 
                                                                animationClips.Select(finding => finding.name).ToArray());

                if (animationIndex.intValue < animationClips.Length)
                {
                    animation.objectReferenceValue = animationClips[animationIndex.intValue];
                }
            }

            AnimatorController animatorController = animatorField.runtimeAnimatorController as AnimatorController;
            if (animatorController == null)
            {
                AnimatorOverrideController overrideController = animatorField.runtimeAnimatorController as AnimatorOverrideController;
                if (overrideController != null)
                {
                    animatorController = overrideController.runtimeAnimatorController as AnimatorController;
                }
            }

            if (animatorController != null)
            {
                // 애니메이터에 포함된 파라미터들을 추출해 선택 가능한 인스펙터 UI를 제공합니다.
                AnimatorControllerParameter[] parameters = animatorController.parameters;
                if (parameters.Length > 0)
                {
                    triggerIndex.intValue = EditorGUILayout.Popup(
                        "Selected Trigger",
                        triggerIndex.intValue,
                        parameters.Select(finding => finding.name).ToArray()
                    );
                    trigger.stringValue = (string)(parameters[triggerIndex.intValue].name);
                }
            }
            
            serializedObject.ApplyModifiedProperties();
        }
    }
}
