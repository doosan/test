using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Events;

public class AnimatorEventTrigger : MonoBehaviour
{
    public enum Type
    {
        Enter = 0,
        Exit = 1,
    }

    [Serializable]
    public class AnimatorEvent
    {
        public Type type;
        public string name;
        public UnityEvent OnTrigger;
    }

    [SerializeField] private List<AnimatorEvent> animatorEventList = null;

    public List<AnimatorEvent> AnimatorEventList { get => animatorEventList;}

    public List<UnityEvent> GetEvent(Type type, string name)
    {
        if (animatorEventList != null)
        {
            return animatorEventList.Where(x => x.type == type && x.name == name).Select(x => x.OnTrigger).ToList();
        }

        return null;
    }
}
