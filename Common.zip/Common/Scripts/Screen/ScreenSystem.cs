using SlotKingdoms.UI;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace SlotKingdoms
{
    public enum ScreenMatchMode
    {
        None,
        Width,
        Height,
        Expand
    }

    public class ScreenSystem : GameObjectSingleton<ScreenSystem>
    {
        class HidingRectValue
        {
            public readonly Rect left = new Rect(0, 0, 0, 1);
            public readonly Rect right = new Rect(1, 0, 0, 1);
            public readonly Rect bottom = new Rect(0, 0, 1, 0); 
            public readonly Rect top = new Rect(0, 1, 1, 0);
        }

        private readonly int TargetFrameRate = 60;

        private bool initOnce;
        private List<Camera> letterBoxCameras;
        private MultipleRangedResizer rangedResizer;

        private Camera letterBoxCamLeft;
        private Camera letterBoxCamRight;
        private Camera letterBoxCamBottom;
        private Camera letterBoxCamTop;
        private readonly HidingRectValue hidingRectValue = new HidingRectValue();

        public void Initialize()
        {
            if (initOnce == false)
            {
                initOnce = true;
                
                letterBoxCameras = new List<Camera>();

                SceneManager.sceneLoaded += OnSceneLoaded;

                Screen.sleepTimeout = SleepTimeout.NeverSleep;
                SetFrameRate(TargetFrameRate);

                letterBoxCamLeft = CreateLetterBoxCamera("LetterBoxLeft");
                letterBoxCamRight = CreateLetterBoxCamera("LetterBoxRight");
                letterBoxCamTop = CreateLetterBoxCamera("LetterBoxTop");
                letterBoxCamBottom = CreateLetterBoxCamera("LetterBoxBottom");

                // 우선 보이지 않도록 최소값 세팅
                letterBoxCamLeft.rect = hidingRectValue.left;
                letterBoxCamRight.rect = hidingRectValue.right;
                letterBoxCamBottom.rect = hidingRectValue.bottom;
                letterBoxCamTop.rect = hidingRectValue.top;
            }
        }

        private Camera CreateLetterBoxCamera(string name)
        {
            Camera letterBox = new GameObject(name).AddComponent<Camera>();
            letterBox.clearFlags = CameraClearFlags.SolidColor;
            letterBox.backgroundColor = Color.black;
            letterBox.cullingMask = 0;
            letterBox.orthographic = true;
            letterBox.depth = float.MaxValue;
            //letterBox.backgroundColor = Color.yellow;

            letterBox.transform.SetParent(transform, false);
            letterBox.transform.position = Vector3.zero;

            return letterBox;
        }

        public void SetFrameRate(int frameRate)
        {
            Application.targetFrameRate = frameRate;
#if UNITY_WSA
            QualitySettings.vSyncCount = 1;
#else
            QualitySettings.vSyncCount = 0;
#endif
        }

        public void SetResolution(int width, int height, ScreenMatchMode screenMatchMode = ScreenMatchMode.None)
        {
            int nextWidth = width;
            int nextHeight = height;
            if (screenMatchMode == ScreenMatchMode.Width)
            {
                float screenRatio = (float)Screen.height / (float)Screen.width;
                nextHeight = (int)(width * screenRatio);
            }
            else if (screenMatchMode == ScreenMatchMode.Height)
            {
                float screenRatio = (float)Screen.width / (float)Screen.height;
                nextWidth = (int)(height * screenRatio);
            }

            Debug.Log($"SetResolution : {width} x {height} -> {nextWidth} x {nextHeight}");
            Screen.SetResolution(nextWidth, nextHeight, true);
        }

        private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            GetRangedResizer(scene);
        }

        private void GetRangedResizer(Scene scene)
        {
            if (rangedResizer != null)
            {
                rangedResizer.onAspectRatioChanged.RemoveListener(UpdateCameraViewport);
                rangedResizer = null;
            }

            // 씬의 루트 게임 오브젝트들을 가져옵니다.
            GameObject[] rootObjects = scene.GetRootGameObjects();
            foreach (GameObject rootObject in rootObjects)
            {
                var sceneComponent = rootObject.GetComponent<BaseScene>();
                if (sceneComponent != null)
                {
                    rangedResizer = sceneComponent.GetComponentInChildren<MultipleRangedResizer>();
                    if (rangedResizer != null)
                    {
                        rangedResizer.onAspectRatioChanged.AddListener(UpdateCameraViewport);
                    }
                    break;
                }
            }
        }
        
        private void UpdateCameraViewport()
        {
            // Left and Right
            float remainingWidthRatio = 1 - rangedResizer.WidthRatio;
            float halfRemainingWidthRatio = remainingWidthRatio * 0.5f;
            float leftMargin = rangedResizer.WidthRatio + halfRemainingWidthRatio;

            Rect newRectLeft = new Rect(0, 0, halfRemainingWidthRatio, 1);
            Rect newRectRight = new Rect(leftMargin, 0, halfRemainingWidthRatio, 1);
            letterBoxCamLeft.rect = newRectLeft;
            letterBoxCamRight.rect = newRectRight;
            letterBoxCamLeft.gameObject.SetActive(newRectLeft != hidingRectValue.left);
            letterBoxCamRight.gameObject.SetActive(newRectRight != hidingRectValue.right);

            // Bottom and Top
            float remainingHeightRatio = 1 - rangedResizer.HeightRatio;
            float halfRemainingHeightRatio = remainingHeightRatio * 0.5f;
            float bottomMargin = rangedResizer.HeightRatio + halfRemainingHeightRatio;

            Rect newRectBottom = new Rect(0, 0, 1, halfRemainingHeightRatio);
            Rect newRectTop = new Rect(0, bottomMargin, 1, halfRemainingHeightRatio);
            letterBoxCamBottom.rect = newRectBottom;
            letterBoxCamTop.rect = newRectTop;
            letterBoxCamBottom.gameObject.SetActive(newRectBottom != hidingRectValue.bottom);
            letterBoxCamTop.gameObject.SetActive(newRectTop != hidingRectValue.top);
        }

        public void AddLetterBoxCam(Camera cam)
        {
            if (letterBoxCameras != null)
            {
                if (letterBoxCameras.Contains(cam))
                {
                    return;
                }

                letterBoxCameras.Add(cam);
            }
        }

        public void RemoveLetterBoxCam(Camera cam)
        {
            if (letterBoxCameras != null)
            {
                if (letterBoxCameras.Contains(cam) == false)
                {
                    return;
                }

                letterBoxCameras.Remove(cam);
            }
        }
    }
}
