using System;
using System.Collections;

namespace SlotKingdoms
{
    public interface IDeepLinkReward
    {
        bool IsProcessing();
        bool HasReward();
        void Claim(Action onComplete);
        IEnumerator WaitForClaim();
    }
}