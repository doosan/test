using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

#if UNITY_ANDROID
using Unity.Notifications.Android;
#elif UNITY_IOS || UNITY_IPHONE
using Unity.Notifications.iOS;
#endif

namespace SlotKingdoms
{
    public class DeepLinkData
    {
        public string Protocol { get; private set; }
        public bool HasParameter { get => parameters != null && parameters.Count > 0; }

        private Dictionary<string, string> parameters;
        public DeepLinkData(string protocol, Dictionary<string, string> queryParameter = null)
        {
            Protocol = protocol;
            parameters = queryParameter;
        }

        public string GetParameter(string key)
        {
            if (HasParameter == false || parameters.ContainsKey(key) == false)
            {
                return string.Empty;
            }

            return parameters[key];
        }
    }

    public class DeepLinkSystem : GameObjectSingleton<DeepLinkSystem>
    {
        public const string PROTOCOL_FANPAGE         = "fanpage";
        public const string PROTOCOL_PUSH_LOG        = "push_log";

        public bool IsActivateByNotification
        {
            get
            {
                return string.IsNullOrEmpty(lastProtocol) == false
                       && lastProtocol == PROTOCOL_PUSH_LOG;
            }
        }
        public bool IsActivateByFacebook
        {
            get
            {
                return string.IsNullOrEmpty(lastProtocol) == false
                       && lastProtocol == PROTOCOL_FANPAGE;
            }
        }

        public int NotificationID
        {
            get;
            private set;
        }

        public int FacebokID
        {
            get
            {
                if (IsActivateByFacebook == false)
                {
                    return 0;
                }
                else if (Int32.TryParse(GetParameter("id"), out int fbID))
                {
                    return fbID;
                }
                else
                {
                    return 0;
                }
            }
        }

        private List<DeepLinkData> dataList;
        public bool HasData { get => dataList != null && dataList.Count > 0; }

#if UNITY_ANDROID
        private AndroidNotificationIntentData lastNotificationIndtent;
#endif
        private Dictionary<string, string> lastQueryParameters;

        public string LastProtocol
        {
            get
            {
                return lastProtocol;
            }
            private set
            {
                Debug.Log($"==== DeepLinkSystem.LastProtocol : {lastProtocol} -> {value}");
                lastProtocol = value;
            }
        }
        private string lastProtocol;

        public void Initialize()
        {
            dataList = new List<DeepLinkData>();
            lastQueryParameters = new Dictionary<string, string>();

            Debug.Log("==== DeepLinkSystem.Initialize()");
            DetectNotificationIntent();
            Parse(Application.absoluteURL);

            Application.deepLinkActivated += OnDeepLinkActivated;
        }

        public void ResetDatas()
        {
            ResetDeepLinkData();
            ResetActivateData();
        }

        public void ResetDeepLinkData()
        {
            Debug.LogFormat("==== DeepLinkSystem.ResetDeepLinkData");

            if (lastQueryParameters != null)
            {
                lastQueryParameters.Clear();
            }

            if (dataList != null)
            {
                dataList.Clear();
            }
        }

        public void ResetActivateData()
        {
            Debug.LogFormat("==== DeepLinkSystem.ResetActivateData");

            LastProtocol = string.Empty;

#if UNITY_ANDROID
            lastNotificationIndtent = null;
#elif UNITY_IOS || UNITY_IPHONE
            //todo ios
#endif
        }

        public void ApplicationFocus(bool isFocus)
        {
            Debug.Log($"==== DeepLinkSystem.ApplicationFocus : {isFocus}");
            if (isFocus)
            {
                DetectNotificationIntent();
            }
        }

        //TODO:: 에폭에서 로컬 노티 지원하면 이 로직(DetectIntent)은 NotificationSystem으로 이동해야함.
        private void DetectNotificationIntent()
        {
#if UNITY_ANDROID
            lastNotificationIndtent = AndroidNotificationCenter.GetLastNotificationIntent();
            if (lastNotificationIndtent != null)
            {
                int id = lastNotificationIndtent.Id;
                string channel = lastNotificationIndtent.Channel;
                AndroidNotification notification = lastNotificationIndtent.Notification;
                Debug.LogFormat($"==== DeepLinkSystem.DetectNotificationIntent, id: {id}, channel: {channel}, intent: {notification.IntentData}");

                NotificationID = id;

                //TODO : 로컬 노티 로그를 보내는 부분을 에폭에서 지원하기 전까지 이 부분에서 로그를 보냄. 이후 제거
                Parse(("undercnoti://push_log?id=" + id.ToString()));
            }
            else
            {
                Debug.LogFormat("==== DeepLinkSystem.DetectNotificationIntent : null");
            }
#elif UNITY_IOS || UNITY_IPHONE
            //todo ios
#endif
        }

        public void LogActivatingStatus()
        {
            if (IsActivateByNotification == true)
            {
                Debug.LogFormat("==== DeepLinkSystem.ActivateByNotification. id: {0}", NotificationID);
            }
            else if (IsActivateByFacebook == true)
            {
                Debug.LogFormat("==== DeepLinkSystem.ActivateByFacebook id: {0}", FacebokID);
            }
            else
            {
                Debug.LogFormat("==== DeepLinkSystem.Activate");
            }
        }

        private void OnDeepLinkActivated(string url)
        {
            Debug.Log($"==== DeepLinkSystem.OnDeepLinkActivated : {url}");
            Parse(url);
        }

        public List<DeepLinkData> FindDatas(params string[] protocols)
        {
            return dataList.Where(data => protocols.Contains(data.Protocol)).ToList();
        }

        public void RemoveData(DeepLinkData data)
        {
            Debug.Log($"==== DeepLinkSystem.RemoveData : {data.Protocol}");
            dataList.Remove(data);
        }

        private void Parse(string uriString)
        {
            Debug.Log($"==== DeepLinkSystem.Parse 1 : {uriString}");
            ResetDatas();

            if (string.IsNullOrEmpty(uriString) == true)
            {
                Debug.Log("==== DeepLinkSystem.Parse 2 : null");
                return;
            }

            Uri uri;
            if (Uri.TryCreate(uriString, UriKind.Absolute, out uri) == false)
            {
                Debug.LogFormat($"==== DeepLinkSystem.Parse 3 : fail, {uriString}");
                return;
            }

            //접속한 주소의 쿼리 키밸류를 저장한다
            Dictionary<string, string> queryParameters = null;
            string query = uri.Query;
            if (string.IsNullOrEmpty(query) == false)
            {
                if (query.StartsWith("?") == true)
                {
                    query = query.Remove(0, 1);
                }

                string[] paramArr = query.Split('&');
                if (paramArr.Length > 0)
                {
                    queryParameters = new Dictionary<string, string>();
                    foreach (var kv in paramArr)
                    {
                        string key = null;
                        string value = null;
                        string[] keyValue = kv.Split('=');

                        if (keyValue.Length >= 2)
                        {
                            key = keyValue[0];
                            value = keyValue[1];
                        }

                        if (string.IsNullOrEmpty(key) == false 
                            && string.IsNullOrEmpty(value) == false
                            && queryParameters.ContainsKey(key) == false)
                        {
                            queryParameters.Add(key, value);
                        }
                    }
                }
            }

            if (queryParameters != null)
            {
                foreach (var kv in queryParameters)
                {
                    if (lastQueryParameters.ContainsKey(kv.Key))
                    {
                        continue;
                    }

                    lastQueryParameters.Add(kv.Key, kv.Value);
                }
            }

            //zempotunderc://www.aquuuacasino.com/fanpage
            var localPath = uri.LocalPath;
            LastProtocol = localPath.Split('/').Last();

            if (string.IsNullOrEmpty(lastProtocol) || string.Equals(lastProtocol, "/"))
            {
                if (string.IsNullOrEmpty(uri.Host))
                {
                    return;
                }

                LastProtocol = uri.Host;
            }

            Debug.LogFormat($"==== DeepLinkSystem.Parse 4, url: {uri.AbsoluteUri}, local: {localPath}, protocol: {lastProtocol}");

            var data = new DeepLinkData(lastProtocol, queryParameters);
            dataList.Add(data);

#if !REAL
            if (data.HasParameter)
            {
                foreach (var kv in queryParameters)
                {
                    Debug.LogFormat($"==== DeepLinkSystem.Parse 5-1, protocol: {data.Protocol}, key: {kv.Key}, value: {kv.Value}");
                }
            }
            else
            {
                Debug.LogFormat($"==== DeepLinkSystem.Parse 5-2, protocol: {data.Protocol}");
            }
#endif
        }

        public string GetParameter(string key)
        {
            if (lastQueryParameters != null && lastQueryParameters.TryGetValue(key, out string value))
            {
                return value;
            }
            else
            {
                return string.Empty;
            }
        }
    }
}
