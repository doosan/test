namespace SlotKingdoms
{
    public static class DeepLinkReward
    {
        public static IDeepLinkReward Fanpage{get; private set;} = new DeepLinkFanpageReward();
    }
}